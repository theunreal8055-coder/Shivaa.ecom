# Laxmi Abhushan Bullion Trading App
## UI/UX Design Layout & Screen Specifications

This document outlines the layout frames and key features of the **Laxmi Abhushan** mobile bullion trading application to help design and code generators understand the main frame and core elements of each screen.

---

## 🎨 Layout Vibe & Color Theme
* **Theme:** Dark mode, luxury fintech.
* **Palette:** Cool dark background, dark cards/containers, warm gold for accents, blue for BID (buy) rates, and rose/red for ASK (sell) rates.
* **Geometry:** Soft rounded corners for cards and inputs.

---

## 📱 Core Screen Layouts

### 1. Splash / Loading Screen
* **Glyph Logo:** Minimal gold diamond/coin icon in the center.
* **Brand Text:** "LAXMI ABHUSHAN" in clean uppercase letters.
* **Status:** Subtle loading indicator at the bottom.

### 2. Login & Signup Screens
* **Layout:** Centered form card over a dark background.
* **Input Fields:**
  - *Signup:* Trader Name, Contact Number (with country code), Company Name, Email, Password.
  - *Login:* Email, Password.
* **Buttons & Links:**
  - "Forgot Password?" link.
  - Primary "Sign In" / "Sign Up" button.
  - Toggle link at the bottom (e.g., "Don't have an account? Sign Up").

### 3. Live Rates Dashboard Screen
* **Top Header:** Company name "LAXMI" and a real-time connection status indicator.
* **Rates Ticker (Top Row):** Horizontal row of cards for key indices (Gold Rate, Silver Rate, USD/INR).
* **Live Commodities Board:** Vertical scroll list of rate cards (e.g., Gold RTGS 24K, Silver Future).
  - *Rate Tile Elements:* Commodity name, Purity label (e.g., 24K), side-by-side BID button (blue background) and ASK button (rose background) displaying live prices, and daily High/Low rate metrics.
* **Quick Actions:** Prominent "ENQUIRY" and "CHAT" buttons at the bottom.

### 4. Price Alerts Screen
* **Create Alert Form:**
  - Segmented control to choose between "GOLD" and "SILVER".
  - Toggle options for condition ("Drops Below" or "Rises Above").
  - Target price input field.
  - "ACTIVATE ALERT" submit button.
* **Active Alerts List:** Vertical list displaying set alerts. Each item shows the metal name, condition, target price, a toggle switch to enable/disable, and a delete button.

### 5. News Screen
* **Feed Layout:** Vertical scroll of news cards.
* **News Card Elements:** Category label (e.g., GLOBAL RESERVES), bold article headline, brief text summary preview, publisher name, and time elapsed.

### 6. Profile & Settings Screen
* **Trader Identification:** List card with rows for Name, Contact, Email (view-only), and Company Name.
* **Preferences Toggles:** Switch controls for "Rate Push Notifications" and "High Contrast Ticks".
* **Support Row:** Dual buttons for "WHATSAPP" and "VISIT US" (Google Maps).
* **Sign Out Button:** Clear, centered button at the bottom of the screen.

---

## 💡 Prompt for Design Generation (Copy-Paste Ready)

> **Prompt:** "Create a premium dark-themed mobile app UI mockup for a bullion trading app named 'Laxmi Abhushan'. Use a dark background with gold accents, blue for buy (BID) rates, and rose/red for sell (ASK) rates. Show a multi-screen interface with: (1) a clean welcome login card with email and password fields, (2) a live rate dashboard containing top horizontal index tickers, a vertical feed of commodity cards with side-by-side BID and ASK price buttons, and bottom enquiry/chat buttons, (3) a price alerts screen featuring a gold/silver selector, drop/rise toggles, and a list of active alerts with inline switch toggles, and (4) a profile settings screen showing trader details, toggle switches, and WhatsApp/Maps support buttons. Keep the layout minimal with soft rounded edges."
