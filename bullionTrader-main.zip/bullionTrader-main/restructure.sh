#!/bin/bash

# ==========================================
# BULLION TRADER PROJECT RESTRUCTURE SCRIPT
# ==========================================

set -e

echo "Starting project restructuring..."

# ==========================================
# CREATE ROOT STRUCTURE
# ==========================================

mkdir -p apps/ios
mkdir -p apps/android
mkdir -p apps/web

mkdir -p backend/api-gateway
mkdir -p backend/websocket-service
mkdir -p backend/auth-service
mkdir -p backend/notification-service

mkdir -p infrastructure/docker
mkdir -p infrastructure/kubernetes
mkdir -p infrastructure/terraform

mkdir -p architecture/ADRs
mkdir -p architecture/flows

mkdir -p docs

mkdir -p scripts/seed/firebase
mkdir -p scripts/migration
mkdir -p scripts/deployment

mkdir -p .github/workflows

# ==========================================
# MOVE IOS APP
# ==========================================

if [ -d "bullionTrader" ]; then
    mv bullionTrader apps/ios/
fi

if [ -d "bullionTrader.xcodeproj" ]; then
    mv bullionTrader.xcodeproj apps/ios/
fi

# ==========================================
# MOVE ANDROID APP
# ==========================================

if [ -d "android-app" ]; then
    mv android-app apps/android/
fi

# ==========================================
# MOVE DOCUMENTATION
# ==========================================

if [ -f "IMPLEMENTATION_PLAN.md" ]; then
    mv IMPLEMENTATION_PLAN.md docs/
fi

# ==========================================
# CREATE ENV FILES
# ==========================================

touch .env
touch .env.production
touch .env.example

touch README.md
touch .gitignore

# ==========================================
# IOS CLEAN ARCHITECTURE STRUCTURE
# ==========================================

mkdir -p apps/ios/bullionTrader/Core/Networking
mkdir -p apps/ios/bullionTrader/Core/Storage
mkdir -p apps/ios/bullionTrader/Core/Utilities
mkdir -p apps/ios/bullionTrader/Core/Extensions

mkdir -p apps/ios/bullionTrader/Features

mkdir -p apps/ios/bullionTrader/Shared/Components
mkdir -p apps/ios/bullionTrader/Shared/Theme
mkdir -p apps/ios/bullionTrader/Shared/Models

mkdir -p apps/ios/bullionTrader/App
mkdir -p apps/ios/bullionTrader/Resources

# ==========================================
# PROVIDER STRUCTURE
# ==========================================

mkdir -p apps/ios/bullionTrader/Services/Providers/Live
mkdir -p apps/ios/bullionTrader/Services/Providers/Mock
mkdir -p apps/ios/bullionTrader/Services/Providers/Sandbox

# ==========================================
# MOVE SERVICES
# ==========================================

if [ -f "apps/ios/bullionTrader/Services/LiveMetalsService.swift" ]; then
    mv apps/ios/bullionTrader/Services/LiveMetalsService.swift \
    apps/ios/bullionTrader/Services/Providers/Live/
fi

if [ -f "apps/ios/bullionTrader/Services/AngelOneMCXService.swift" ]; then
    mv apps/ios/bullionTrader/Services/AngelOneMCXService.swift \
    apps/ios/bullionTrader/Services/Providers/Live/
fi

if [ -f "apps/ios/bullionTrader/Services/SimulatedRateService.swift" ]; then
    mv apps/ios/bullionTrader/Services/SimulatedRateService.swift \
    apps/ios/bullionTrader/Services/Providers/Mock/
fi

# ==========================================
# MOVE FIREBASE SEEDER
# ==========================================

if [ -f "apps/ios/bullionTrader/Services/FirebaseSeeder.swift" ]; then
    mv apps/ios/bullionTrader/Services/FirebaseSeeder.swift \
    scripts/seed/firebase/
fi

# ==========================================
# MOVE FEATURE MODULES
# ==========================================

FEATURES=("Dashboard" "Booking" "News" "Profile" "Auth" "Alerts")

for feature in "${FEATURES[@]}"
do
    if [ -d "apps/ios/bullionTrader/Views/$feature" ]; then
        mv "apps/ios/bullionTrader/Views/$feature" \
        "apps/ios/bullionTrader/Features/"
    fi
done

# ==========================================
# MOVE SHARED ITEMS
# ==========================================

if [ -d "apps/ios/bullionTrader/Theme" ]; then
    mv apps/ios/bullionTrader/Theme/* \
    apps/ios/bullionTrader/Shared/Theme/ 2>/dev/null || true
fi

if [ -d "apps/ios/bullionTrader/Models" ]; then
    mv apps/ios/bullionTrader/Models/* \
    apps/ios/bullionTrader/Shared/Models/ 2>/dev/null || true
fi

# ==========================================
# MOVE APP FILES
# ==========================================

if [ -f "apps/ios/bullionTrader/bullionTraderApp.swift" ]; then
    mv apps/ios/bullionTrader/bullionTraderApp.swift \
    apps/ios/bullionTrader/App/
fi

if [ -f "apps/ios/bullionTrader/ContentView.swift" ]; then
    mv apps/ios/bullionTrader/ContentView.swift \
    apps/ios/bullionTrader/App/
fi

# ==========================================
# CLEANUP EMPTY DIRECTORIES
# ==========================================

rm -rf apps/ios/bullionTrader/Views 2>/dev/null || true
rm -rf apps/ios/bullionTrader/Theme 2>/dev/null || true
rm -rf apps/ios/bullionTrader/Models 2>/dev/null || true

# ==========================================
# FINAL OUTPUT
# ==========================================

echo ""
echo "=========================================="
echo "Project restructuring completed."
echo "=========================================="
echo ""

tree -L 3