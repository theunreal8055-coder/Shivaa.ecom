// ============================================================================
// @bulliontrader/shared-types — Common TypeScript types for BullionTrader
// ============================================================================

// ---------------------------------------------------------------------------
// Metal & Purity Types
// ---------------------------------------------------------------------------

/** Supported metals on the platform */
export type Metal = 'GOLD' | 'SILVER';

/** Gold purity variants available for trading */
export type GoldPurity = '999' | '995' | '916' | '750' | 'guinee' | 'petal';

/** Silver purity variants available for trading */
export type SilverPurity = '999' | '925';

// ---------------------------------------------------------------------------
// Rate / Price Types  (broadcast by ingestion-worker)
// ---------------------------------------------------------------------------

/** Price data for a single metal */
export interface MetalRate {
  /** Base price without badla/markup */
  bid: number;
  /** Price with badla/markup added */
  ask: number;
  /** MCX reference price */
  base_mcx: number;
}

/** Top-level payload the ingestion worker broadcasts via Supabase Realtime */
export interface RatePayload {
  timestamp: string;
  gold: MetalRate;
  silver: MetalRate;
}

// ---------------------------------------------------------------------------
// User & Auth Types
// ---------------------------------------------------------------------------

/** Platform user roles */
export type UserRole = 'user' | 'admin' | 'dealer';

/** User profile stored in the `profiles` table */
export interface UserProfile {
  id: string;
  full_name: string;
  phone: string;
  business_name?: string;
  city: string;
  role: UserRole;
  fcm_token?: string;
  preferences: Record<string, any>;
  created_at: string;
  updated_at: string;
}

// ---------------------------------------------------------------------------
// Order Types
// ---------------------------------------------------------------------------

/** Direction of a booking order */
export type OrderType = 'buy' | 'sell';

/** Lifecycle status of a booking order */
export type OrderStatus = 'pending' | 'confirmed' | 'delivered' | 'cancelled';

/** A buy/sell booking request placed by a user */
export interface Order {
  id: string;
  user_id: string;
  commodity_name: string;
  type: OrderType;
  quantity: number;
  unit: string;
  rate_at_booking: number;
  total_amount: number;
  status: OrderStatus;
  customer_name: string;
  customer_phone: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

// ---------------------------------------------------------------------------
// Price Alert Types
// ---------------------------------------------------------------------------

/** Whether the alert fires when price goes above or below the target */
export type AlertDirection = 'above' | 'below';

/** A user-configured price alert */
export interface PriceAlert {
  id: string;
  user_id: string;
  metal: Metal;
  commodity_name: string;
  target_price: number;
  direction: AlertDirection;
  is_active: boolean;
  is_triggered: boolean;
  triggered_at?: string;
  notification_sent: boolean;
  created_at: string;
}

// ---------------------------------------------------------------------------
// Dealer Configuration
// ---------------------------------------------------------------------------

/** Admin-configurable dealer settings that affect rate calculation */
export interface DealerConfig {
  gold_badla_markup: number;
  silver_badla_markup: number;
  import_duty_percent: number;
  gst_percent: number;
  usd_to_inr: number;
  is_market_open: boolean;
}

// ---------------------------------------------------------------------------
// API Response Wrapper
// ---------------------------------------------------------------------------

/** Standard envelope for all JSON API responses */
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// ---------------------------------------------------------------------------
// Market News
// ---------------------------------------------------------------------------

/** A market news article or update */
export interface MarketNews {
  id: string;
  title: string;
  summary: string;
  content?: string;
  source: string;
  category: string;
  image_url?: string;
  is_published: boolean;
  published_at: string;
}
