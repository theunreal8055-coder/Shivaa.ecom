import dotenv from 'dotenv';

dotenv.config();

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`❌ Missing required environment variable: ${name}`);
  }
  return value;
}

const isDev = (process.env.NODE_ENV || 'development') === 'development';

export const config = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  supabaseUrl: requireEnv('SUPABASE_URL'),
  supabaseServiceRoleKey: requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
  supabaseAnonKey: process.env.SUPABASE_ANON_KEY || '',
  isDev,
  // Public URL of the frontend used for OAuth redirect targets.
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:8080',
  // Comma-separated list of allowed CORS origins in production.
  allowedOrigins: (process.env.ALLOWED_ORIGINS || '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean),
  // Secret used to sign stateless CSRF tokens for the Kite OAuth flow.
  // Falls back to the service-role key (always present) so the flow is never unsigned.
  kiteStateSecret: process.env.KITE_STATE_SECRET || requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
} as const;

// Fail fast: in production, refuse to start with an unsafe CORS configuration.
if (!isDev) {
  if (config.allowedOrigins.length === 0) {
    throw new Error('❌ ALLOWED_ORIGINS must be set in production (comma-separated origin list).');
  }
  if (config.allowedOrigins.includes('*')) {
    throw new Error('❌ ALLOWED_ORIGINS cannot be "*" when credentials are enabled.');
  }
}
