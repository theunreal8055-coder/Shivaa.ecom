type LogLevel = 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';

function formatMessage(level: LogLevel, message: string, meta?: Record<string, unknown>): string {
  const timestamp = new Date().toISOString();
  const base = `[${timestamp}] [${level}] ${message}`;
  if (meta && Object.keys(meta).length > 0) {
    return `${base} ${JSON.stringify(meta)}`;
  }
  return base;
}

export const logger = {
  info(message: string, meta?: Record<string, unknown>) {
    console.log(formatMessage('INFO', message, meta));
  },
  warn(message: string, meta?: Record<string, unknown>) {
    console.warn(formatMessage('WARN', message, meta));
  },
  error(message: string, meta?: Record<string, unknown>) {
    console.error(formatMessage('ERROR', message, meta));
  },
  debug(message: string, meta?: Record<string, unknown>) {
    if (process.env.NODE_ENV === 'development') {
      console.debug(formatMessage('DEBUG', message, meta));
    }
  },
};
