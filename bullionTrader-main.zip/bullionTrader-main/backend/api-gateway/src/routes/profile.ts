import { Router, Request, Response, NextFunction } from 'express';
import { supabase } from '../supabase.js';
import { requireAuth } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { z } from 'zod';
import { logger } from '../utils/logger.js';

const router: Router = Router();

const updateProfileSchema = z.object({
  full_name: z.string().max(100).optional(),
  phone: z.string().max(20).optional(),
  business_name: z.string().max(100).optional(),
  city: z.string().max(50).optional(),
  fcm_token: z.string().max(500).optional(),
  preferences: z.object({
    pushOn: z.boolean().optional(),
    highContrast: z.boolean().optional(),
  }).optional(),
});

// GET /api/profile - Fetch combined user profile
router.get('/', requireAuth, async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      res.status(401).json({ success: false, error: 'Unauthorized' });
      return;
    }

    // 1. Fetch from Supabase Auth admin panel
    const { data: { user }, error: userError } = await supabase.auth.admin.getUserById(userId);
    if (userError || !user) {
      logger.error('Error fetching auth user info', { error: userError?.message || 'No user found' });
      res.status(404).json({ success: false, error: 'User auth record not found' });
      return;
    }

    // 2. Fetch from database profiles table (handles missing columns gracefully using select('*') fallbacks)
    const { data: dbProfile, error: dbError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (dbError) {
      logger.warn('Error reading profiles table', { error: dbError.message });
    }

    // 3. Construct combined object with safe fallbacks
    const meta = user.user_metadata || {};
    const responseData = {
      id: userId,
      email: user.email || '',
      full_name: dbProfile?.full_name || meta.full_name || meta.name || 'Trader',
      phone: dbProfile?.phone_number || dbProfile?.phone || meta.phone || meta.phone_number || '',
      business_name: dbProfile?.business_name || meta.business_name || meta.company || '',
      city: dbProfile?.city || meta.city || 'Rajkot',
      role: dbProfile?.role || meta.role || 'user',
      fcm_token: dbProfile?.fcm_token || meta.fcm_token || '',
      preferences: meta.preferences || dbProfile?.preferences || { pushOn: true, highContrast: false },
      created_at: dbProfile?.created_at || user.created_at,
    };

    res.json({ success: true, data: responseData });
  } catch (err) {
    next(err);
  }
});

// PUT /api/profile - Securely coordinate and update user profile & metadata
router.put('/', requireAuth, validateBody(updateProfileSchema), async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      res.status(401).json({ success: false, error: 'Unauthorized' });
      return;
    }

    const { full_name, phone, business_name, city, preferences, fcm_token } = req.body;

    // 1. Fetch current auth user metadata to merge preferences/metadata properly
    const { data: { user }, error: fetchUserErr } = await supabase.auth.admin.getUserById(userId);
    if (fetchUserErr || !user) {
      res.status(404).json({ success: false, error: 'User auth record not found' });
      return;
    }

    const currentMeta = user.user_metadata || {};
    const newPrefs = {
      ...(currentMeta.preferences || {}),
      ...(preferences || {}),
    };

    const updatedMeta = {
      ...currentMeta,
      ...(full_name !== undefined ? { full_name } : {}),
      ...(phone !== undefined ? { phone } : {}),
      ...(business_name !== undefined ? { business_name } : {}),
      ...(city !== undefined ? { city } : {}),
      ...(fcm_token !== undefined ? { fcm_token } : {}),
      preferences: newPrefs,
    };

    // 2. Update user metadata in Supabase Auth (this is our source of truth for fields missing in remote DB table)
    const { error: metaUpdateErr } = await supabase.auth.admin.updateUserById(userId, {
      user_metadata: updatedMeta,
    });

    if (metaUpdateErr) {
      logger.error('Failed to update auth metadata', { error: metaUpdateErr.message });
      res.status(500).json({ success: false, error: 'Failed to update user profile metadata' });
      return;
    }

    // 3. Safely update database profiles table (only columns that we know exist / work)
    const dbUpdatePayload: any = {};
    if (full_name !== undefined) dbUpdatePayload.full_name = full_name;
    if (phone !== undefined) dbUpdatePayload.phone_number = phone;
    if (city !== undefined) dbUpdatePayload.city = city;
    if (fcm_token !== undefined) dbUpdatePayload.fcm_token = fcm_token;

    // Optional columns (wrapped in try-catch dynamically / database filters to prevent PGRST204)
    const { error: dbUpdateErr } = await supabase
      .from('profiles')
      .update(dbUpdatePayload)
      .eq('id', userId);

    if (dbUpdateErr) {
      logger.warn('Failed to update profiles table columns', { error: dbUpdateErr.message });
      
      // Auto-insert row if missing entirely
      if (dbUpdateErr.message.includes('multiple (or no) rows') || dbUpdateErr.code === 'PGRST116') {
        const { error: insErr } = await supabase
          .from('profiles')
          .insert({
            id: userId,
            full_name: full_name || currentMeta.full_name || 'Trader',
            phone_number: phone || currentMeta.phone || '',
            city: city || currentMeta.city || 'Rajkot',
          });
        if (insErr) {
          logger.error('Failed to auto-create profile row on update fail', { error: insErr.message });
        }
      }
    }

    logger.info(`👤 Profile updated for User ID=${userId}`, { userId });
    
    // Return combined profile
    res.json({
      success: true,
      message: 'Profile updated successfully',
      data: {
        id: userId,
        email: user.email || '',
        full_name: full_name || currentMeta.full_name || '',
        phone: phone || currentMeta.phone || '',
        business_name: business_name || currentMeta.business_name || '',
        city: city || currentMeta.city || 'Rajkot',
        role: currentMeta.role || 'user',
        fcm_token: fcm_token || currentMeta.fcm_token || '',
        preferences: newPrefs,
      }
    });
  } catch (err) {
    next(err);
  }
});

export default router;
