import { Router } from 'express';
import { supabase } from '../supabase.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
import { config } from '../config.js';
import { logger } from '../utils/logger.js';
import crypto from 'crypto';

const router: Router = Router();

// Keys whose values must never be returned to any client.
const SECRET_KEYS = new Set(['kite_api_secret', 'kite_api_key', 'kite_access_token']);
// Window during which an admin-initiated Kite login may be completed.
const OAUTH_PENDING_TTL_MS = 10 * 60 * 1000;

// Helper to fetch key from dealer_config
async function getConfigKey(key: string): Promise<any | null> {
  const { data, error } = await supabase
    .from('dealer_config')
    .select('value')
    .eq('key', key)
    .maybeSingle();
  if (error || !data) return null;
  return data.value;
}

// Helper to set key in dealer_config
async function setConfigKey(key: string, value: any, userId?: string): Promise<boolean> {
  const { error } = await supabase
    .from('dealer_config')
    .upsert({
      key,
      value,
      updated_by: userId,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'key' });
  return !error;
}

function buildFrontendRedirect(params: Record<string, string>): string {
  const qs = new URLSearchParams(params).toString();
  return `${config.frontendUrl}/profile?${qs}`;
}

// Get recent admin audit logs
router.get('/audit-logs', requireAuth, requireAdmin, async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('admin_audit_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(30);

    if (error) throw error;
    res.json({ success: true, data });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch audit logs' });
  }
});

// Get all dealer config (admin/dealer only; secret material is masked, never returned).
router.get('/', requireAuth, requireAdmin, async (req, res) => {
  try {
    const { data, error } = await supabase.from('dealer_config').select('key, value');
    if (error) throw error;

    const result: Record<string, any> = {};
    for (const item of data || []) {
      if (SECRET_KEYS.has(item.key)) {
        // Never return secret values; only signal whether they are configured.
        result[item.key] = item.value ? '******' : '';
      } else {
        result[item.key] = item.value;
      }
    }
    res.json({ success: true, data: result });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to fetch configuration' });
  }
});

// Update dealer config
router.post('/', requireAuth, requireAdmin, async (req, res) => {
  try {
    const body = req.body;
    // Basic input validation: body must be a non-null object
    if (!body || typeof body !== 'object' || Array.isArray(body)) {
      return res.status(400).json({ success: false, error: 'Request body must be a JSON object' });
    }
    const adminUser = req.user;
    if (!adminUser) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    for (const [key, value] of Object.entries(body)) {
      // Don't overwrite secrets with their masked placeholder.
      if (SECRET_KEYS.has(key) && value === '******') {
        continue;
      }

      // Validate badla markup values are finite numbers before persisting.
      if (key === 'gold_badla_markup' || key === 'silver_badla_markup') {
        const asNum = Number(value);
        if (!Number.isFinite(asNum)) {
          return res.status(400).json({ success: false, error: `Invalid numeric value for ${key}` });
        }
      }

      // Fetch old value first to compare and write an audit log on change.
      const oldValue = await getConfigKey(key);

      // Structural comparison (JSONB values may be primitives, arrays, or objects).
      const isChanged = JSON.stringify(oldValue ?? null) !== JSON.stringify(value ?? null);

      if (isChanged) {
        await setConfigKey(key, value, adminUser.id);

        if (key === 'gold_badla_markup' || key === 'silver_badla_markup') {
          const oldNum = oldValue !== null && Number.isFinite(Number(oldValue)) ? Number(oldValue) : null;
          const newNum = Number(value);

          const { error: logErr } = await supabase
            .from('admin_audit_logs')
            .insert({
              admin_id: adminUser.id,
              admin_email: adminUser.email,
              setting_key: key,
              old_value: oldNum,
              new_value: newNum,
            });

          if (logErr) {
            logger.error(`Failed to insert audit log for key ${key}`, { error: logErr.message });
          }
        }
      }
    }
    res.json({ success: true, message: 'Configuration updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to update configuration' });
  }
});


// Get Kite Login Redirect URL (admin/dealer only).
// Records a short-lived "pending login" marker so the callback can verify the
// flow was initiated by an authenticated admin (mitigates a stranger planting
// their own access token via the public callback).
router.get('/kite-login-url', requireAuth, requireAdmin, async (req, res) => {
  try {
    const apiKey = await getConfigKey('kite_api_key');
    if (!apiKey) {
      return res.status(400).json({ success: false, error: 'Kite API Key is not configured.' });
    }
    await setConfigKey('kite_oauth_pending', { at: Date.now(), by: req.user?.id }, req.user?.id);
    const loginUrl = `https://kite.zerodha.com/connect/login?api_key=${encodeURIComponent(apiKey)}&v=3`;
    res.json({ success: true, data: { url: loginUrl } });
  } catch (err: any) {
    res.status(500).json({ success: false, error: 'Failed to generate login URL' });
  }
});

// Kite login callback URL (registered with Zerodha).
// Cannot carry our own auth header (it is a browser redirect from Zerodha), so
// it is bound to a recent admin-initiated login via the kite_oauth_pending marker.
router.get('/kite-callback', async (req, res) => {
  const requestToken = req.query.request_token as string;
  const status = req.query.status as string;

  if (status && status !== 'success') {
    return res.redirect(buildFrontendRedirect({ kite_login: 'error', message: 'Zerodha login failed.' }));
  }

  if (!requestToken) {
    return res.redirect(buildFrontendRedirect({ kite_login: 'error', message: 'Request token missing in callback.' }));
  }

  try {
    // Verify a recent admin-initiated login exists, then consume it (single use).
    const pending = await getConfigKey('kite_oauth_pending');
    const pendingAt = pending && typeof pending.at === 'number' ? pending.at : 0;
    if (!pendingAt || Date.now() - pendingAt > OAUTH_PENDING_TTL_MS) {
      logger.warn('Kite callback rejected: no recent admin-initiated login');
      return res.redirect(buildFrontendRedirect({ kite_login: 'error', message: 'No active login request. Please start the connection from the app.' }));
    }
    await setConfigKey('kite_oauth_pending', null);

    const apiKey = await getConfigKey('kite_api_key');
    const apiSecret = await getConfigKey('kite_api_secret');

    if (!apiKey || !apiSecret) {
      return res.redirect(buildFrontendRedirect({ kite_login: 'error', message: 'Kite API key or secret is not configured.' }));
    }

    // Calculate checksum = SHA256(api_key + request_token + api_secret)
    const hashInput = apiKey + requestToken + apiSecret;
    const checksum = crypto.createHash('sha256').update(hashInput).digest('hex');

    logger.info('Exchanging Kite request token for access token');

    const response = await fetch('https://api.kite.trade/session/token', {
      method: 'POST',
      headers: {
        'X-Kite-Version': '3',
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        api_key: apiKey,
        request_token: requestToken,
        checksum: checksum,
      }),
    });

    const responseData = await response.json() as any;

    if (!response.ok || !responseData?.data?.access_token) {
      // Log the full provider error server-side; do not reflect it into the redirect.
      logger.error('Zerodha token exchange failed', { status: response.status, body: responseData });
      return res.redirect(buildFrontendRedirect({ kite_login: 'error', message: 'Token exchange failed.' }));
    }

    const accessToken = responseData.data.access_token;
    await setConfigKey('kite_access_token', accessToken);
    logger.info('Zerodha access token saved');

    return res.redirect(buildFrontendRedirect({ kite_login: 'success' }));
  } catch (err: any) {
    logger.error('Error handling Kite callback', { error: String(err?.message || err) });
    return res.redirect(buildFrontendRedirect({ kite_login: 'error', message: 'Unexpected error during Kite login.' }));
  }
});

// Optional Kite postback endpoint (registered with Zerodha)
router.post('/kite-postback', async (req, res) => {
  try {
    logger.info('Zerodha kite postback received');
    return res.status(200).json({ success: true });
  } catch (err: any) {
    logger.error('Error handling Kite postback', { error: String(err) });
    return res.status(500).json({ success: false, error: 'Failed to process Kite postback' });
  }
});

export default router;
