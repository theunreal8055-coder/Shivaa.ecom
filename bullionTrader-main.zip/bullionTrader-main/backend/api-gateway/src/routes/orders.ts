import { Router, Request, Response, NextFunction } from 'express';
import { supabase } from '../supabase.js';
import { requireAuth } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { z } from 'zod';
import { logger } from '../utils/logger.js';

const router: Router = Router();

const orderSchema = z.object({
  commodity_name: z.string().min(1, 'Commodity name is required'),
  type: z.enum(['buy', 'sell']),
  quantity: z.number().positive('Quantity must be greater than zero'),
  unit: z.string().default('gm'),
  rate_at_booking: z.number().positive('Rate must be positive'),
  customer_name: z.string().optional(),
  customer_phone: z.string().optional(),
  notes: z.string().optional(),
});

// GET /api/orders - Fetch user's orders (or all orders for admin if query parameter all=true is passed)
router.get('/', requireAuth, async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    const role = req.user?.role;
    const fetchAll = req.query.all === 'true' && role === 'admin';

    let query = supabase.from('orders').select('*');

    if (!fetchAll) {
      query = query.eq('user_id', userId);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    if (error) {
      logger.error('Error fetching orders from DB', { error: error.message });
      res.status(500).json({ success: false, error: 'Database query failed' });
      return;
    }

    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
});

// POST /api/orders - Place a booking order
router.post('/', requireAuth, validateBody(orderSchema), async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    const {
      commodity_name,
      type,
      quantity,
      unit,
      rate_at_booking,
      customer_name,
      customer_phone,
      notes,
    } = req.body;

    // 1. Verify the rate is valid (not stale/manipulated)
    const metal = commodity_name.toUpperCase().includes('SILVER') ? 'SILVER' : 'GOLD';
    
    const { data: latestTick, error: rateError } = await supabase
      .from('rate_history')
      .select('bid_price, ask_price')
      .eq('metal', metal)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (rateError) {
      logger.error('Error fetching latest rate for validation', { error: rateError.message });
    }

    if (latestTick) {
      const marketPrice = type === 'buy' ? Number(latestTick.ask_price) : Number(latestTick.bid_price);
      // Allow up to a 5% margin difference to account for minor delays, markup offsets, or different purities
      const differencePercent = Math.abs(rate_at_booking - marketPrice) / marketPrice;
      
      if (differencePercent > 0.05) {
        logger.warn(`Order rate verification failed: booked=${rate_at_booking}, market=${marketPrice}, diff=${(differencePercent * 100).toFixed(2)}%`, {
          booked: rate_at_booking,
          market: marketPrice
        });
        res.status(400).json({ 
          success: false, 
          error: 'Rate expired or is invalid. Please refresh the live rates and try again.' 
        });
        return;
      }
    }

    // 2. Fetch default profile fields if customer info is omitted
    let finalCustomerName = customer_name;
    let finalCustomerPhone = customer_phone;

    if (!finalCustomerName || !finalCustomerPhone) {
      const { data: profile, error: profileErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (profileErr) {
        logger.warn('Error reading profile during order creation', { error: profileErr.message });
      }

      if (profile) {
        if (!finalCustomerName) {
          finalCustomerName = profile.full_name || 'Walk-in Trader';
        }
        if (!finalCustomerPhone) {
          finalCustomerPhone = profile.phone_number || profile.phone || '';
        }
      }
    }

    // 3. Compute total order amount
    const total_amount = Number((quantity * rate_at_booking).toFixed(2));

    // 4. Insert order record
    const { data: order, error: insertError } = await supabase
      .from('orders')
      .insert({
        user_id: userId,
        commodity_name,
        type,
        quantity,
        unit,
        rate_at_booking,
        total_amount,
        customer_name: finalCustomerName || 'Walk-in Trader',
        customer_phone: finalCustomerPhone || '',
        notes: notes || '',
        status: 'pending',
      })
      .select()
      .single();

    if (insertError) {
      logger.error('Error creating order in DB', { error: insertError.message });
      res.status(500).json({ success: false, error: 'Failed to record the order in the database' });
      return;
    }

    logger.info(`🎉 Order created successfully: ID=${order.id}, User=${userId}, Total=${total_amount}`, {
      orderId: order.id,
      userId: userId || ''
    });
    res.status(201).json({ success: true, data: order });
  } catch (err) {
    next(err);
  }
});

export default router;
