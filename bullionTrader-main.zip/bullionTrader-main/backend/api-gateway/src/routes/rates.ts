import { Router } from 'express';
import { supabase } from '../supabase.js';
import { logger } from '../utils/logger.js';

const router: Router = Router();

router.get('/', async (req, res) => {
  try {
    const { data: goldData, error: goldError } = await supabase
      .from('rate_history')
      .select('*')
      .eq('metal', 'GOLD')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    const { data: silverData, error: silverError } = await supabase
      .from('rate_history')
      .select('*')
      .eq('metal', 'SILVER')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (goldError && goldError.code !== 'PGRST116') throw goldError;
    if (silverError && silverError.code !== 'PGRST116') throw silverError;

    res.json({
      success: true,
      data: {
        gold: goldData,
        silver: silverData
      }
    });
  } catch (error: any) {
    logger.error('Failed to fetch latest rates', error);
    res.status(500).json({ success: false, error: 'Failed to fetch rates' });
  }
});

router.get('/history', async (req, res) => {
  const { metal, period = '1d' } = req.query;
  
  if (!metal || (metal !== 'GOLD' && metal !== 'SILVER')) {
    return res.status(400).json({ success: false, error: 'Invalid metal parameter' });
  }

  let timeFilter = new Date();
  switch (period) {
    case '1h': timeFilter.setHours(timeFilter.getHours() - 1); break;
    case '4h': timeFilter.setHours(timeFilter.getHours() - 4); break;
    case '1d': timeFilter.setDate(timeFilter.getDate() - 1); break;
    case '1w': timeFilter.setDate(timeFilter.getDate() - 7); break;
    case '1m': timeFilter.setMonth(timeFilter.getMonth() - 1); break;
    default: timeFilter.setDate(timeFilter.getDate() - 1); break;
  }

  try {
    const { data, error } = await supabase
      .from('rate_history')
      .select('*')
      .eq('metal', metal)
      .gte('created_at', timeFilter.toISOString())
      .order('created_at', { ascending: true });

    if (error) throw error;

    res.json({ success: true, data });
  } catch (error: any) {
    logger.error(`Failed to fetch rate history for ${metal}`, error);
    res.status(500).json({ success: false, error: 'Failed to fetch rate history' });
  }
});

export default router;
