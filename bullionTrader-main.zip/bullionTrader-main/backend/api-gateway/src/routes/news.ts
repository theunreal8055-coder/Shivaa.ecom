import { Router, Request, Response, NextFunction } from 'express';
import { supabase } from '../supabase.js';
import { logger } from '../utils/logger.js';

const router: Router = Router();

interface Article {
  title: string;
  url: string;
  domain: string;
  seendate: string;
  summary?: string;
  is_db?: boolean;
}

// In-memory cache for news proxy
let cachedNews: Article[] = [];
let cacheExpiresAt = 0;
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes cache

function parseGdeltDate(s: string): string {
  // Converts 20240615T103000Z -> ISO string
  if (!/^\d{8}T\d{6}Z$/.test(s)) {
    return new Date(s).toISOString();
  }
  const iso = `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}T${s.slice(9, 11)}:${s.slice(11, 13)}:${s.slice(13, 15)}Z`;
  return new Date(iso).toISOString();
}

async function fetchAndCacheNews(): Promise<Article[]> {
  try {
    let dbArticles: Article[] = [];
    
    // 1. Fetch from Supabase market_news table
    const { data: dbData, error: dbError } = await supabase
      .from('market_news')
      .select('*')
      .eq('is_published', true)
      .order('published_at', { ascending: false });

    if (dbError) {
      logger.error('Error fetching market_news from Supabase', { error: dbError.message });
    } else if (dbData) {
      dbArticles = dbData.map(item => ({
        title: item.title,
        url: item.source || '#',
        domain: item.category || 'Admin Feed',
        seendate: new Date(item.published_at).toISOString(),
        summary: item.summary || '',
        is_db: true
      }));
    }

    // 2. Fetch from GDELT API
    let gdeltArticles: Article[] = [];
    try {
      const gdeltUrl = 'https://api.gdeltproject.org/api/v2/doc/doc?query=(gold%20OR%20bullion%20OR%20silver)%20sourcelang:eng&mode=ArtList&format=json&maxrecords=25&sort=DateDesc';
      
      const response = await fetch(gdeltUrl, { signal: AbortSignal.timeout(5000) });
      if (response.ok) {
        const json = await response.json() as any;
        gdeltArticles = (json.articles ?? []).map((a: any) => ({
          title: a.title,
          url: a.url,
          domain: a.domain || 'GDELT',
          seendate: parseGdeltDate(a.seendate),
          summary: `${a.domain || 'Global News'} · Tap to read full coverage on the publisher’s site.`,
          is_db: false
        }));
      } else {
        logger.warn(`GDELT API responded with status ${response.status}`);
      }
    } catch (gdeltErr: any) {
      logger.error('Failed to retrieve news from GDELT API', { error: gdeltErr.message });
    }

    // Combine: database articles take priority at the top
    const combined = [...dbArticles, ...gdeltArticles];
    
    cachedNews = combined;
    cacheExpiresAt = Date.now() + CACHE_TTL_MS;
    
    return combined;
  } catch (err: any) {
    logger.error('Error refreshing news cache', { error: err.message || String(err) });
    // Return stale cache if available, else empty list
    return cachedNews.length > 0 ? cachedNews : [];
  }
}

// GET /api/news - Proxy combined cached news feed
router.get('/', async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const forceRefresh = req.query.refresh === 'true';
    
    if (forceRefresh || Date.now() > cacheExpiresAt || cachedNews.length === 0) {
      logger.info('Refreshing market news cache from source APIs...');
      await fetchAndCacheNews();
    }
    
    res.json({ success: true, data: cachedNews });
  } catch (err) {
    next(err);
  }
});

export default router;
