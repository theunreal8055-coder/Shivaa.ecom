import { Router, Request, Response, NextFunction } from 'express';
import { supabase } from '../supabase.js';
import { requireAuth } from '../middleware/auth.js';
import { validateBody } from '../middleware/validate.js';
import { z } from 'zod';
import { logger } from '../utils/logger.js';

const router: Router = Router();

const createAlertSchema = z.object({
  metal: z.enum(['GOLD', 'SILVER']),
  commodity_name: z.string().optional().nullable(),
  target_price: z.number().positive('Target price must be positive'),
  direction: z.enum(['above', 'below']),
});

const updateAlertSchema = z
  .object({
    is_active: z.boolean().optional(),
    target_price: z.number().positive().optional(),
    direction: z.enum(['above', 'below']).optional(),
  })
  .refine((obj) => Object.keys(obj).length > 0, {
    message: 'At least one field must be provided to update',
  });

const uuidSchema = z.string().uuid();

// GET /api/alerts - Get user's price alerts
router.get('/', requireAuth, async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;

    const { data, error } = await supabase
      .from('price_alerts')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      logger.error('Error fetching alerts from DB', { error: error.message });
      res.status(500).json({ success: false, error: 'Database query failed' });
      return;
    }

    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
});

// POST /api/alerts - Register a new price alert
router.post('/', requireAuth, validateBody(createAlertSchema), async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    const { metal, commodity_name, target_price, direction } = req.body;

    const { data, error } = await supabase
      .from('price_alerts')
      .insert({
        user_id: userId,
        metal,
        commodity_name: commodity_name || (metal === 'GOLD' ? 'Gold Future' : 'Silver Future'),
        target_price,
        direction,
        is_active: true,
        is_triggered: false,
        notification_sent: false,
      })
      .select()
      .single();

    if (error) {
      logger.error('Error creating price alert', { error: error.message });
      res.status(500).json({ success: false, error: 'Failed to create price alert' });
      return;
    }

    logger.info(`🔔 Alert created: ID=${data.id}, User=${userId}, Target=${metal} @ ${target_price} (${direction})`);
    res.status(201).json({ success: true, data });
  } catch (err) {
    next(err);
  }
});

// PUT /api/alerts/:id - Update alert status or parameters
router.put('/:id', requireAuth, validateBody(updateAlertSchema), async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    const { id } = req.params;

    if (!uuidSchema.safeParse(id).success) {
      res.status(400).json({ success: false, error: 'Invalid alert id' });
      return;
    }

    const { data, error } = await supabase
      .from('price_alerts')
      .update(req.body)
      .eq('id', id)
      .eq('user_id', userId)
      .select()
      .maybeSingle();

    if (error) {
      logger.error(`Error updating price alert ID=${id}`, { error: error.message });
      res.status(500).json({ success: false, error: 'Failed to update price alert' });
      return;
    }

    if (!data) {
      res.status(404).json({ success: false, error: 'Price alert not found or access denied' });
      return;
    }

    res.json({ success: true, data });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/alerts/:id - Delete a price alert
router.delete('/:id', requireAuth, async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  try {
    const userId = req.user?.id;
    const { id } = req.params;

    if (!uuidSchema.safeParse(id).success) {
      res.status(400).json({ success: false, error: 'Invalid alert id' });
      return;
    }

    const { error } = await supabase
      .from('price_alerts')
      .delete()
      .eq('id', id)
      .eq('user_id', userId);

    if (error) {
      logger.error(`Error deleting price alert ID=${id}`, { error: error.message });
      res.status(500).json({ success: false, error: 'Failed to delete price alert' });
      return;
    }

    res.json({ success: true, message: 'Price alert deleted successfully' });
  } catch (err) {
    next(err);
  }
});

export default router;
