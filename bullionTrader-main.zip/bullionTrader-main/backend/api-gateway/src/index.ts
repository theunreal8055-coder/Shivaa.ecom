import express from 'express';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import { config } from './config.js';
import { logger } from './utils/logger.js';
import ratesRouter from './routes/rates.js';
import alertsRouter from './routes/alerts.js';
import newsRouter from './routes/news.js';
import configRouter from './routes/config.js';
import profileRouter from './routes/profile.js';

const app = express();

// Trust the first proxy hop so express-rate-limit and req.ip use the real
// client address (X-Forwarded-For) rather than collapsing all clients onto
// the proxy IP. Adjust the hop count to match your deployment topology.
app.set('trust proxy', 1);

// Global rate limiter
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200, // limit each IP to 200 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests, please try again later.' },
});

// Stricter rate limiter for auth-sensitive endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests, please try again later.' },
});

app.use(globalLimiter);
app.use(cors({
  origin: config.isDev
    ? ['http://localhost:8081', 'http://localhost:8080', 'http://localhost:19006']
    : config.allowedOrigins,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
  maxAge: 86400,
}));
app.use(express.json({ limit: '1mb' }));

// Request logging middleware
app.use((req, res, next) => {
  logger.info(`${req.method} ${req.url}`);
  next();
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Routes
app.use('/api/rates', ratesRouter);
app.use('/api/alerts', authLimiter, alertsRouter);
app.use('/api/news', newsRouter);
app.use('/api/config', authLimiter, configRouter);
app.use('/api/profile', authLimiter, profileRouter);

// Error handler
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  logger.error(`Error processing ${req.method} ${req.url}: ${err.message}`);
  res.status(err.status || 500).json({
    success: false,
    error: config.isDev ? err.message : 'Internal server error',
  });
});

app.listen(config.port, () => {
  logger.info(`API Gateway started on port ${config.port}`);
});
