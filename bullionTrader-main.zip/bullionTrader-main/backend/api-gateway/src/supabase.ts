import { createClient } from '@supabase/supabase-js';
import { config } from './config.js';

/**
 * Admin-level Supabase client using the service role key.
 * Bypasses Row Level Security — use only on the server side.
 */
export const supabase = createClient(config.supabaseUrl, config.supabaseServiceRoleKey, {
  auth: { persistSession: false },
});
