import { Request, Response, NextFunction } from 'express';
import { supabase } from '../supabase.js';
import { logger } from '../utils/logger.js';

/**
 * Authenticated user payload attached to req.user
 */
export interface AuthUser {
  id: string;
  email: string;
  role: 'user' | 'admin' | 'dealer';
}

// Extend Express Request to carry the authenticated user
declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

/**
 * Extracts and verifies the Supabase JWT from the Authorization header.
 * On success, attaches the user (with role from profiles table) to req.user.
 */
export async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      res.status(401).json({ success: false, error: 'Missing or malformed Authorization header' });
      return;
    }

    const token = authHeader.slice(7); // strip "Bearer "

    // Verify the JWT via Supabase Auth
    const { data: { user }, error } = await supabase.auth.getUser(token);

    if (error || !user) {
      logger.warn('Auth verification failed', { error: error?.message });
      res.status(401).json({ success: false, error: 'Invalid or expired token' });
      return;
    }

    // Fetch the user's role from the profiles table
    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    const role = (profile?.role as AuthUser['role']) || 'user';

    req.user = {
      id: user.id,
      email: user.email || '',
      role,
    };

    next();
  } catch (err) {
    logger.error('Auth middleware error', { error: String(err) });
    res.status(500).json({ success: false, error: 'Authentication service error' });
  }
}

/**
 * Requires the authenticated user to have the 'admin' or 'dealer' role.
 * Must be used AFTER requireAuth.
 */
export async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, error: 'Authentication required' });
    return;
  }

  if (req.user.role !== 'admin' && req.user.role !== 'dealer') {
    logger.warn('Admin access denied', { userId: req.user.id, role: req.user.role });
    res.status(403).json({ success: false, error: 'Insufficient permissions. Admin access required.' });
    return;
  }

  next();
}
