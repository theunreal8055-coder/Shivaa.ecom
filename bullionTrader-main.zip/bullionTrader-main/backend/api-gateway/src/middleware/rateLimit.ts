import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger.js';

interface RateLimitEntry {
  count: number;
  resetAt: number;
}

/**
 * Simple in-memory sliding-window rate limiter.
 * For production, swap with Redis-backed solution.
 */
export function rateLimit(options: { windowMs?: number; maxRequests?: number } = {}) {
  const windowMs = options.windowMs || 60_000;   // 1 minute default
  const maxRequests = options.maxRequests || 100;  // 100 req/min default

  const store = new Map<string, RateLimitEntry>();

  // Periodically clean up expired entries to prevent memory leaks
  const cleanupInterval = setInterval(() => {
    const now = Date.now();
    for (const [key, entry] of store) {
      if (now > entry.resetAt) {
        store.delete(key);
      }
    }
  }, windowMs * 2);

  // Allow the timer to not block process shutdown
  cleanupInterval.unref();

  return (req: Request, res: Response, next: NextFunction): void => {
    // Use user ID if authenticated, otherwise fall back to IP
    const key = req.user?.id || req.ip || 'unknown';
    const now = Date.now();

    let entry = store.get(key);

    if (!entry || now > entry.resetAt) {
      entry = { count: 1, resetAt: now + windowMs };
      store.set(key, entry);
    } else {
      entry.count++;
    }

    // Set rate limit headers
    res.setHeader('X-RateLimit-Limit', String(maxRequests));
    res.setHeader('X-RateLimit-Remaining', String(Math.max(0, maxRequests - entry.count)));
    res.setHeader('X-RateLimit-Reset', String(Math.ceil(entry.resetAt / 1000)));

    if (entry.count > maxRequests) {
      logger.warn('Rate limit exceeded', { key, count: entry.count });
      res.status(429).json({
        success: false,
        error: 'Too many requests. Please try again later.',
      });
      return;
    }

    next();
  };
}
