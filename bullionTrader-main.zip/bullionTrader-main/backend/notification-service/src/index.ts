import { supabase } from './supabase.js';
import { logger } from './logger.js';
import { config } from './config.js';
import admin from 'firebase-admin';
import { existsSync, readFileSync } from 'fs';
import { RatePayload } from '@bulliontrader/shared-types';

interface PriceAlert {
  id: string;
  user_id: string;
  metal: 'GOLD' | 'SILVER';
  commodity_name: string;
  target_price: number;
  direction: 'above' | 'below';
  is_active: boolean;
  is_triggered: boolean;
}

let activeAlerts: PriceAlert[] = [];
let firebaseInitialized = false;

/**
 * Initialize Firebase Admin SDK if service account credentials are available.
 * Falls back to simulation mode if no credentials are configured.
 */
function initializeFirebase() {
  const serviceAccountPath = config.firebaseServiceAccountPath;

  if (!serviceAccountPath) {
    logger.info('⚠️ FIREBASE_SERVICE_ACCOUNT_PATH not set. FCM will run in simulation mode.');
    return;
  }

  if (!existsSync(serviceAccountPath)) {
    logger.warn(`⚠️ Firebase service account file not found at "${serviceAccountPath}". FCM will run in simulation mode.`);
    return;
  }

  try {
    const serviceAccount = JSON.parse(readFileSync(serviceAccountPath, 'utf-8'));

    admin.initializeApp({
      credential: admin.credential.cert(serviceAccount),
    });

    firebaseInitialized = true;
    logger.info('✅ Firebase Admin SDK initialized successfully (FCM v1 API ready).');
  } catch (err: any) {
    logger.error('Failed to initialize Firebase Admin SDK. FCM will run in simulation mode.', {
      error: err.message,
    });
  }
}

/**
 * Loads all active, untriggered alerts from the database into local memory cache
 */
async function loadActiveAlerts() {
  try {
    const { data, error } = await supabase
      .from('price_alerts')
      .select('id, user_id, metal, commodity_name, target_price, direction, is_active, is_triggered')
      .eq('is_active', true)
      .eq('is_triggered', false);

    if (error) {
      logger.error('Failed to load active alerts from DB', { error: error.message });
      return;
    }

    // Cast and format numeric fields to avoid type mismatches
    activeAlerts = (data || []).map((item: any) => ({
      id: item.id,
      user_id: item.user_id,
      metal: item.metal as 'GOLD' | 'SILVER',
      commodity_name: item.commodity_name || '',
      target_price: Number(item.target_price),
      direction: item.direction as 'above' | 'below',
      is_active: !!item.is_active,
      is_triggered: !!item.is_triggered,
    }));

    logger.info(`Loaded ${activeAlerts.length} active price alerts into memory cache.`);
  } catch (err: any) {
    logger.error('Error during alerts loading', { error: err.message });
  }
}

/**
 * Dispatches an FCM push notification via Firebase Admin SDK (FCM v1 API).
 * Falls back to simulation logging if Firebase Admin is not initialized.
 */
async function sendPushNotification(token: string, title: string, body: string) {
  logger.info(`📤 Attempting push dispatch to token: "${token.substring(0, 15)}..."`);

  if (!firebaseInitialized) {
    logger.info('📢 [FCM Simulation Mode] Push notification sent successfully', {
      to: token,
      title,
      body,
    });
    return;
  }

  try {
    const messageId = await admin.messaging().send({
      token,
      notification: {
        title,
        body,
      },
      android: {
        notification: {
          sound: 'default',
          clickAction: 'FLUTTER_NOTIFICATION_CLICK',
        },
      },
      apns: {
        payload: {
          aps: {
            sound: 'default',
            badge: 1,
          },
        },
      },
      data: {
        type: 'PRICE_ALERT',
      },
    });

    logger.info('✅ FCM Push Notification dispatched successfully.', { messageId });
  } catch (err: any) {
    logger.error('Failed to dispatch FCM push request', {
      error: err.message,
      code: err.code,
    });
  }
}

/**
 * Main evaluation loop matching ticks to cached alerts
 */
async function evaluateAlerts(payload: RatePayload) {
  if (activeAlerts.length === 0) return;

  const currentPrices = {
    GOLD: {
      bid: payload.gold.bid,
      ask: payload.gold.ask,
      mid: (payload.gold.bid + payload.gold.ask) / 2,
    },
    SILVER: {
      bid: payload.silver.bid,
      ask: payload.silver.ask,
      mid: (payload.silver.bid + payload.silver.ask) / 2,
    },
  };

  const triggeredIds: string[] = [];

  for (const alert of activeAlerts) {
    if (alert.is_triggered) continue;

    const metalRates = currentPrices[alert.metal];
    if (!metalRates) continue;

    // Use ASK price to verify if price is rising above, BID price to verify if price is falling below
    const evalPrice = alert.direction === 'above' ? metalRates.ask : metalRates.bid;
    let didTrigger = false;

    if (alert.direction === 'above' && evalPrice >= alert.target_price) {
      didTrigger = true;
    } else if (alert.direction === 'below' && evalPrice <= alert.target_price) {
      didTrigger = true;
    }

    if (didTrigger) {
      alert.is_triggered = true; // Mark locally to prevent concurrent matches
      triggeredIds.push(alert.id);
      
      logger.info(`🎯 ALERT TRIGGERED! ID=${alert.id}, Metal=${alert.metal}, Target=${alert.target_price}, Current=${evalPrice}`);
      
      // Perform async notification handle
      handleAlertTrigger(alert, evalPrice).catch((err) => {
        logger.error('Failed processing alert trigger actions', { error: err.message, alertId: alert.id });
      });
    }
  }

  // Remove triggered alerts from memory cache
  if (triggeredIds.length > 0) {
    activeAlerts = activeAlerts.filter((alert) => !triggeredIds.includes(alert.id));
  }
}

/**
 * Handle DB state updates and push notification retrieval
 */
async function handleAlertTrigger(alert: PriceAlert, currentPrice: number) {
  const triggerTime = new Date().toISOString();

  // 1. Update DB immediately to mark as triggered
  const { error: dbErr } = await supabase
    .from('price_alerts')
    .update({
      is_triggered: true,
      triggered_at: triggerTime,
      is_active: false,
      notification_sent: true,
    })
    .eq('id', alert.id);

  if (dbErr) {
    logger.error(`Failed to update DB for triggered alert ID=${alert.id}`, { error: dbErr.message });
  }

  // 2. Fetch User Profile to retrieve fcm_token
  const { data: profile, error: profileErr } = await supabase
    .from('profiles')
    .select('fcm_token')
    .eq('id', alert.user_id)
    .maybeSingle();

  if (profileErr) {
    logger.warn(`Failed to read user profile token for ID=${alert.user_id}`, { error: profileErr.message });
  }

  let fcmToken = profile?.fcm_token;

  // Fallback to Auth user_metadata if profiles DB lacks columns/fcm_token
  if (!fcmToken) {
    const { data: { user }, error: userErr } = await supabase.auth.admin.getUserById(alert.user_id);
    if (!userErr && user) {
      fcmToken = user.user_metadata?.fcm_token;
    }
  }

  // 3. Dispatch Notification
  const title = `🚨 Price Alert Triggered!`;
  const body = `${alert.metal} has crossed your target of ₹${alert.target_price.toLocaleString()}! Current Rate: ₹${currentPrice.toLocaleString()}. Tap to trade now.`;

  if (fcmToken) {
    await sendPushNotification(fcmToken, title, body);
  } else {
    logger.warn(`Could not dispatch push notification for alert ID=${alert.id}: User has no FCM token registered.`);
  }
}

/**
 * Start the notification microservice
 */
async function main() {
  logger.info('🚀 Starting BullionTrader Notification Service...');

  // 0. Initialize Firebase Admin SDK for push notifications
  initializeFirebase();

  // 1. Initial alerts cache fetch
  await loadActiveAlerts();

  // Fallback periodic poll to ensure the memory cache remains synchronized in case Realtime postgres_changes is not enabled/configured
  setInterval(() => {
    loadActiveAlerts().catch((err) => {
      logger.error('Error during periodic alerts sync fallback', { error: err.message });
    });
  }, 1500);

  // 2. Subscribe to price_alerts table updates/inserts to sync cache live
  const priceAlertsSyncChannel = supabase.channel('price_alerts_db_sync');
  priceAlertsSyncChannel
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'price_alerts' },
      async (payload) => {
        logger.info('🔄 Change detected in price_alerts table. Re-syncing memory cache...');
        await loadActiveAlerts();
      }
    )
    .subscribe((status) => {
      logger.info(`🔌 Supabase DB synchronization channel status: ${status}`);
    });

  // 3. Subscribe to bullion_rates Realtime broadcast ticks
  const bullionRatesChannel = supabase.channel('bullion_rates', {
    config: { broadcast: { ack: false } },
  });

  bullionRatesChannel
    .on('broadcast', { event: 'rate-update' }, (message) => {
      const payload = message.payload as RatePayload;
      if (!payload) return;

      // Evaluate tick pricing
      evaluateAlerts(payload).catch((err) => {
        logger.error('Error evaluating rates payload against alerts', { error: err.message });
      });
    })
    .subscribe((status) => {
      logger.info(`🔌 Supabase Realtime Rates channel subscription status: ${status}`);
    });
}

main().catch((err) => {
  logger.error('Fatal crash in notification service main thread', { error: err.message || String(err) });
  process.exit(1);
});
