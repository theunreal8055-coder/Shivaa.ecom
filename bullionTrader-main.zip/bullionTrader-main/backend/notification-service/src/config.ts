import dotenv from 'dotenv';

dotenv.config();

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    throw new Error(`❌ Missing required environment variable: ${name}`);
  }
  return value;
}

export const config = {
  nodeEnv: process.env.NODE_ENV || 'development',
  supabaseUrl: requireEnv('SUPABASE_URL'),
  supabaseServiceRoleKey: requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
  // (Deprecated) Legacy FCM server key — kept for reference only
  fcmServerKey: process.env.FCM_SERVER_KEY || '',
  // Path to Firebase service account JSON for Admin SDK (FCM v1 API)
  firebaseServiceAccountPath: process.env.FIREBASE_SERVICE_ACCOUNT_PATH || '',
  isDev: (process.env.NODE_ENV || 'development') === 'development',
} as const;
