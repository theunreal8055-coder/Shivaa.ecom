/**
 * Upstox OAuth2 Auth Helper
 *
 * Run this script ONCE per day to get a fresh access token.
 *
 * Usage:
 *   npx tsx src/upstoxAuth.ts
 *
 * Steps:
 *   1. Script prints an authorization URL
 *   2. Open it in your browser → login with Upstox → allow access
 *   3. Browser redirects to your redirect URI with ?code=XXXX in URL
 *   4. Copy that code and paste it here
 *   5. Script prints your access token → copy it to UPSTOX_ACCESS_TOKEN in .env
 */

import { getAuthUrl, exchangeCodeForToken } from './upstoxClient.js';
import * as readline from 'readline';
import * as dotenv from 'dotenv';

dotenv.config();

const API_KEY     = process.env.UPSTOX_API_KEY     || '';
const API_SECRET  = process.env.UPSTOX_API_SECRET  || '';
const REDIRECT_URI = process.env.UPSTOX_REDIRECT_URI || 'https://127.0.0.1';

if (!API_KEY || !API_SECRET) {
  console.error('❌ Missing UPSTOX_API_KEY or UPSTOX_API_SECRET in .env');
  process.exit(1);
}

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

console.log('\n🔐 Upstox OAuth2 Login\n');
console.log('Step 1: Open this URL in your browser:');
console.log('─'.repeat(80));
console.log(getAuthUrl(API_KEY, REDIRECT_URI));
console.log('─'.repeat(80));
console.log('\nStep 2: Login with your Upstox account and allow access.');
console.log('Step 3: After redirect, copy the "code" value from the URL.');
console.log('        e.g. https://127.0.0.1/?code=AbCdEfGh12345\n');

rl.question('Paste the auth code here: ', async (code) => {
  rl.close();
  try {
    console.log('\n🔄 Exchanging code for access token...');
    const token = await exchangeCodeForToken(API_KEY, API_SECRET, code.trim(), REDIRECT_URI);
    console.log('\n✅ Success! Your access token:\n');
    console.log('─'.repeat(80));
    console.log(token);
    console.log('─'.repeat(80));
    console.log('\n👉 Copy this and set it in your .env file:');
    console.log(`UPSTOX_ACCESS_TOKEN=${token}`);
    console.log('\n⚠️  Note: This token expires at midnight. Run this script again tomorrow.\n');
  } catch (err: any) {
    console.error('❌ Failed to get token:', err.message);
    process.exit(1);
  }
});
