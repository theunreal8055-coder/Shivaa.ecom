/**
 * Upstox API v2 — Live MCX Gold & Silver price client.
 *
 * Free to use with any Upstox demat account.
 * Docs: https://upstox.com/developer/api-documentation/
 *
 * Auth flow (OAuth2 — one-time per day):
 *   1. Run `npm run upstox:auth` → opens browser → copy auth code from redirect URL
 *   2. Run `npm run upstox:token` → exchanges code for access token → saves to .env
 *   3. Worker auto-starts using the saved UPSTOX_ACCESS_TOKEN
 *
 * Instrument key format: "MCX_FO|<instrument_key>"
 *   Gold  near-month future → UPSTOX_GOLD_INSTRUMENT_KEY  (e.g. "MCX_FO|257801")
 *   Silver near-month future → UPSTOX_SILVER_INSTRUMENT_KEY (e.g. "MCX_FO|257861")
 *   Run `npm run upstox:tokens` to auto-resolve current month's keys.
 */

import https from 'https';
import { RatePayload } from '@bulliontrader/shared-types';

type TickCallback = (payload: RatePayload) => void;

// ─── Upstox REST helper ──────────────────────────────────────────────────────

function upstoxRequest<T = any>(
  method: 'GET' | 'POST',
  path: string,
  body: string | null,
  accessToken?: string,
  contentType = 'application/json',
): Promise<T> {
  return new Promise((resolve, reject) => {
    const options: https.RequestOptions = {
      hostname: 'api.upstox.com',
      port: 443,
      path,
      method,
      headers: {
        'Accept': 'application/json',
        ...(contentType ? { 'Content-Type': contentType } : {}),
        ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}),
        ...(body ? { 'Content-Length': Buffer.byteLength(body).toString() } : {}),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          reject(new Error(`Upstox: Invalid JSON: ${data}`));
        }
      });
    });

    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

// ─── Auth helpers (exported for CLI scripts) ─────────────────────────────────

/** Step 1: Get the authorization URL to open in browser */
export function getAuthUrl(apiKey: string, redirectUri: string): string {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: apiKey,
    redirect_uri: redirectUri,
  });
  return `https://api.upstox.com/v2/login/authorization/dialog?${params.toString()}`;
}

/** Step 2: Exchange auth code for access token */
export async function exchangeCodeForToken(
  apiKey: string,
  apiSecret: string,
  authCode: string,
  redirectUri: string,
): Promise<string> {
  const body = new URLSearchParams({
    code: authCode,
    client_id: apiKey,
    client_secret: apiSecret,
    redirect_uri: redirectUri,
    grant_type: 'authorization_code',
  }).toString();

  const resp = await upstoxRequest(
    'POST',
    '/v2/login/authorization/token',
    body,
    undefined,
    'application/x-www-form-urlencoded',
  );

  if (!resp.access_token) {
    throw new Error(`Upstox token exchange failed: ${JSON.stringify(resp)}`);
  }
  return resp.access_token as string;
}

// ─── LTP polling ─────────────────────────────────────────────────────────────

async function fetchLTP(
  accessToken: string,
  goldKey: string,
  silverKey: string,
): Promise<{ goldPrice: number; silverPrice: number }> {
  const instrumentKeys = encodeURIComponent(`${goldKey},${silverKey}`);
  const resp = await upstoxRequest(
    'GET',
    `/v2/market-quote/ltp?instrument_key=${instrumentKeys}`,
    null,
    accessToken,
  );

  if (resp.status !== 'success' || !resp.data) {
    throw new Error(`Upstox LTP failed: ${JSON.stringify(resp)}`);
  }

  // resp.data is a map keyed by instrument_key
  const goldData = resp.data[goldKey];
  const silverData = resp.data[silverKey];

  if (!goldData || !silverData) {
    throw new Error(`Upstox: Missing LTP data for Gold or Silver. Got: ${JSON.stringify(resp.data)}`);
  }

  return {
    goldPrice: goldData.last_price,
    silverPrice: silverData.last_price,
  };
}

// ─── Instrument resolver ─────────────────────────────────────────────────────

export async function resolveUpstoxTokens(accessToken: string): Promise<{
  goldKey: string;
  silverKey: string;
}> {
  console.log('🔍 Upstox: Fetching MCX instrument list...');

  // Upstox provides a downloadable CSV of all instruments
  const resp = await upstoxRequest('GET', '/v2/market/instruments/MCX', null, accessToken);

  if (!resp.data) throw new Error('Upstox: Could not fetch instrument list');

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const goldFutures = (resp.data as any[])
    .filter(i => i.name === 'GOLD' && i.instrument_type === 'FUT' && new Date(i.expiry) >= today)
    .sort((a, b) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime());

  const silverFutures = (resp.data as any[])
    .filter(i => i.name === 'SILVER' && i.instrument_type === 'FUT' && new Date(i.expiry) >= today)
    .sort((a, b) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime());

  if (!goldFutures.length || !silverFutures.length) {
    throw new Error('Upstox: No active GOLD or SILVER futures found');
  }

  const gold = goldFutures[0];
  const silver = silverFutures[0];

  console.log(`📌 Resolved Gold:   ${gold.trading_symbol} | Key: ${gold.instrument_key} | Expiry: ${gold.expiry}`);
  console.log(`📌 Resolved Silver: ${silver.trading_symbol} | Key: ${silver.instrument_key} | Expiry: ${silver.expiry}`);

  return {
    goldKey: gold.instrument_key,
    silverKey: silver.instrument_key,
  };
}

// ─── Main Client Class ───────────────────────────────────────────────────────

export class UpstoxLiveClient {
  private accessToken: string;
  private goldKey: string;
  private silverKey: string;
  private goldBadla: number;
  private silverBadla: number;

  private intervalId: NodeJS.Timeout | null = null;
  private onTickCallback?: TickCallback;

  constructor(
    accessToken: string,
    goldKey: string,
    silverKey: string,
    goldBadla: number,
    silverBadla: number,
  ) {
    this.accessToken = accessToken;
    this.goldKey = goldKey;
    this.silverKey = silverKey;
    this.goldBadla = goldBadla;
    this.silverBadla = silverBadla;
  }

  public updateBadla(goldBadla: number, silverBadla: number) {
    this.goldBadla = goldBadla;
    this.silverBadla = silverBadla;
  }

  public onTick(callback: TickCallback) {
    this.onTickCallback = callback;
  }

  public async connect(tickIntervalMs = 1000) {
    console.log('📡 Upstox: Starting LTP polling...');

    // Validate token works before starting
    try {
      const { goldPrice, silverPrice } = await fetchLTP(
        this.accessToken,
        this.goldKey,
        this.silverKey,
      );
      console.log(`✅ Upstox: Connected. Gold: ₹${goldPrice} | Silver: ₹${silverPrice}`);
    } catch (err: any) {
      throw new Error(`Upstox: Initial connection test failed — ${err.message}`);
    }

    this.intervalId = setInterval(async () => {
      try {
        const { goldPrice, silverPrice } = await fetchLTP(
          this.accessToken,
          this.goldKey,
          this.silverKey,
        );

        const payload: RatePayload = {
          timestamp: new Date().toISOString(),
          gold: {
            bid: Math.round(goldPrice),
            ask: Math.round(goldPrice + this.goldBadla),
            base_mcx: goldPrice,
          },
          silver: {
            bid: Math.round(silverPrice),
            ask: Math.round(silverPrice + this.silverBadla),
            base_mcx: silverPrice,
          },
        };

        console.log(`📈 Upstox Tick → Gold: ₹${payload.gold.bid} | Silver: ₹${payload.silver.bid}`);

        if (this.onTickCallback) {
          this.onTickCallback(payload);
        }
      } catch (err: any) {
        console.error('⚠️ Upstox: Tick error:', err.message);
      }
    }, tickIntervalMs);
  }

  public disconnect() {
    console.log('🔌 Upstox: Disconnecting...');
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }
}
