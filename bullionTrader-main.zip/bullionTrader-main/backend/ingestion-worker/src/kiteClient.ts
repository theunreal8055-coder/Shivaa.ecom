import { KiteTicker } from 'kiteconnect';
import { RatePayload } from '@bulliontrader/shared-types';

type TickCallback = (payload: RatePayload) => void;

export class KiteLiveClient {
  private ticker: any;
  private onTickCallback?: TickCallback;
  
  private apiKey: string;
  private accessToken: string;

  private goldInstrumentToken: number;
  private silverInstrumentToken: number;

  private goldBadla: number;
  private silverBadla: number;

  // Track the last known prices so if one ticks without the other, we can still broadcast both
  private lastGoldMcx: number = 0;
  private lastSilverMcx: number = 0;

  constructor(
    apiKey: string, 
    accessToken: string, 
    goldToken: number, 
    silverToken: number,
    goldBadla: number,
    silverBadla: number
  ) {
    this.apiKey = apiKey;
    this.accessToken = accessToken;
    this.goldInstrumentToken = goldToken;
    this.silverInstrumentToken = silverToken;
    this.goldBadla = goldBadla;
    this.silverBadla = silverBadla;

    this.ticker = new KiteTicker({
      api_key: apiKey,
      access_token: accessToken,
    });

    this.ticker.on('connect', this.subscribe.bind(this));
    this.ticker.on('ticks', this.onTicks.bind(this));
    this.ticker.on('noreconnect', () => {
      console.error('KiteTicker: Max reconnects reached');
    });
    this.ticker.on('error', (err: any) => {
      console.error('KiteTicker Error:', err);
    });
  }

  public updateBadla(goldBadla: number, silverBadla: number) {
    this.goldBadla = goldBadla;
    this.silverBadla = silverBadla;
  }

  public onTick(callback: TickCallback) {
    this.onTickCallback = callback;
  }

  public async connect() {
    console.log('🔗 Connecting to Kite Ticker...');
    if (this.goldInstrumentToken === 0 || this.silverInstrumentToken === 0) {
      console.log('🔍 Instrument tokens not specified. Resolving dynamically...');
      try {
        const tokens = await this.resolveMcxTokens();
        this.goldInstrumentToken = tokens.goldToken;
        this.silverInstrumentToken = tokens.silverToken;
      } catch (err) {
        console.error('❌ Failed to resolve MCX tokens dynamically. Cannot connect.', err);
        return;
      }
    }
    this.ticker.connect();
  }

  public disconnect() {
    this.ticker.disconnect();
  }

  public async resolveMcxTokens(): Promise<{ goldToken: number; silverToken: number }> {
    const { KiteConnect } = await import('kiteconnect');
    const kc = new KiteConnect({ api_key: this.apiKey });
    kc.setAccessToken(this.accessToken);
    
    console.log('🔍 Fetching MCX instruments list...');
    const instruments = await kc.getInstruments('MCX');
    
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Filter for active FUT (Futures) for name 'GOLD' and 'SILVER'
    // Usually the near-month (most liquid) contract is the one with the earliest expiry that is >= today.
    const goldFutures = instruments.filter((inst: any) => 
      inst.name === 'GOLD' && 
      inst.instrument_type === 'FUT' && 
      inst.expiry && 
      new Date(inst.expiry) >= today
    );
    
    const silverFutures = instruments.filter((inst: any) => 
      inst.name === 'SILVER' && 
      inst.instrument_type === 'FUT' && 
      inst.expiry && 
      new Date(inst.expiry) >= today
    );
    
    // Sort by expiry ascending to get the near-month contract
    goldFutures.sort((a: any, b: any) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime());
    silverFutures.sort((a: any, b: any) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime());
    
    if (goldFutures.length === 0 || silverFutures.length === 0) {
      throw new Error('Could not find active MCX GOLD or SILVER futures contracts.');
    }
    
    const activeGold = goldFutures[0];
    const activeSilver = silverFutures[0];
    
    console.log(`📌 Resolved Active Gold: ${activeGold.tradingsymbol} (Token: ${activeGold.instrument_token}, Expiry: ${activeGold.expiry})`);
    console.log(`📌 Resolved Active Silver: ${activeSilver.tradingsymbol} (Token: ${activeSilver.instrument_token}, Expiry: ${activeSilver.expiry})`);
    
    return {
      goldToken: Number(activeGold.instrument_token),
      silverToken: Number(activeSilver.instrument_token)
    };
  }

  private subscribe() {
    console.log('✅ Connected to Kite Ticker. Subscribing to instruments...');
    const tokens = [this.goldInstrumentToken, this.silverInstrumentToken];
    this.ticker.subscribe(tokens);
    this.ticker.setMode(this.ticker.modeFull, tokens);
  }

  private onTicks(ticks: any[]) {
    let updated = false;

    for (const tick of ticks) {
      if (tick.instrument_token === this.goldInstrumentToken) {
        this.lastGoldMcx = tick.last_price;
        updated = true;
      } else if (tick.instrument_token === this.silverInstrumentToken) {
        this.lastSilverMcx = tick.last_price;
        updated = true;
      }
    }

    // Only broadcast if we have prices for both and at least one updated
    if (updated && this.lastGoldMcx > 0 && this.lastSilverMcx > 0 && this.onTickCallback) {
      this.onTickCallback({
        timestamp: new Date().toISOString(),
        gold: {
          bid: Math.round(this.lastGoldMcx), 
          ask: Math.round(this.lastGoldMcx + this.goldBadla),
          base_mcx: this.lastGoldMcx
        },
        silver: {
          bid: Math.round(this.lastSilverMcx),
          ask: Math.round(this.lastSilverMcx + this.silverBadla),
          base_mcx: this.lastSilverMcx
        }
      });
    }
  }
}
