import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import http from 'http';
import { RateSimulator } from './simulator.js';
import { RateBroadcaster } from './broadcaster.js';
import { KiteLiveClient } from './kiteClient.js';
import { AngelOneLiveClient } from './angelOneClient.js';
import { UpstoxLiveClient } from './upstoxClient.js';

dotenv.config();

const supabaseUrl = process.env.SUPABASE_URL || 'YOUR_SUPABASE_URL_HERE';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || 'YOUR_SUPABASE_SERVICE_ROLE_KEY';

const TICK_INTERVAL_MS = parseInt(process.env.TICK_INTERVAL_MS || '1000', 10);
const DB_LOG_INTERVAL = parseInt(process.env.DB_LOG_INTERVAL || '10', 10);
const PORT = process.env.PORT || 3003;

const useMockData = process.env.USE_MOCK_DATA !== 'false';
const kiteApiKey = process.env.KITE_API_KEY || '';
const kiteAccessToken = process.env.KITE_ACCESS_TOKEN || '';
const kiteGoldToken = parseInt(process.env.KITE_GOLD_INSTRUMENT_TOKEN || '0', 10);
const kiteSilverToken = parseInt(process.env.KITE_SILVER_INSTRUMENT_TOKEN || '0', 10);

// Angel One SmartAPI credentials
const angelApiKey = process.env.ANGEL_ONE_API_KEY || '';
const angelClientCode = process.env.ANGEL_ONE_CLIENT_CODE || '';
const angelPassword = process.env.ANGEL_ONE_PASSWORD || '';
const angelMpin = process.env.ANGEL_ONE_MPIN || '';
const angelGoldToken = process.env.ANGEL_ONE_GOLD_TOKEN || '';
const angelSilverToken = process.env.ANGEL_ONE_SILVER_TOKEN || '';
const useAngelOne = process.env.USE_ANGEL_ONE === 'true';

// Upstox API v2 credentials
const upstoxAccessToken = process.env.UPSTOX_ACCESS_TOKEN || '';
const upstoxGoldKey = process.env.UPSTOX_GOLD_INSTRUMENT_KEY || '';
const upstoxSilverKey = process.env.UPSTOX_SILVER_INSTRUMENT_KEY || '';
const useUpstox = process.env.USE_UPSTOX === 'true';

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { persistSession: false }
});

async function fetchDealerConfig() {
  const defaults = {
    goldBadla: 150,
    silverBadla: 250,
    useMockData: process.env.USE_MOCK_DATA !== 'false',
    useAngelOne: process.env.USE_ANGEL_ONE === 'true',
    // Kite
    kiteApiKey: process.env.KITE_API_KEY || '',
    kiteAccessToken: process.env.KITE_ACCESS_TOKEN || '',
    kiteGoldToken: parseInt(process.env.KITE_GOLD_INSTRUMENT_TOKEN || '0', 10),
    kiteSilverToken: parseInt(process.env.KITE_SILVER_INSTRUMENT_TOKEN || '0', 10),
    // Angel One
    angelApiKey: process.env.ANGEL_ONE_API_KEY || '',
    angelClientCode: process.env.ANGEL_ONE_CLIENT_CODE || '',
    angelPassword: process.env.ANGEL_ONE_PASSWORD || '',
    angelMpin: process.env.ANGEL_ONE_MPIN || '',
    angelGoldToken: process.env.ANGEL_ONE_GOLD_TOKEN || '',
    angelSilverToken: process.env.ANGEL_ONE_SILVER_TOKEN || '',
    // Upstox
    useUpstox: process.env.USE_UPSTOX === 'true',
    upstoxAccessToken: process.env.UPSTOX_ACCESS_TOKEN || '',
    upstoxGoldKey: process.env.UPSTOX_GOLD_INSTRUMENT_KEY || '',
    upstoxSilverKey: process.env.UPSTOX_SILVER_INSTRUMENT_KEY || '',
  };

  try {
    const { data, error } = await supabase.from('dealer_config').select('key, value');
    if (error || !data) return defaults;

    const config = { ...defaults };

    for (const item of data) {
      const val = item.value;
      if (item.key === 'gold_badla_markup') config.goldBadla = typeof val === 'number' ? val : parseFloat(val);
      if (item.key === 'silver_badla_markup') config.silverBadla = typeof val === 'number' ? val : parseFloat(val);
      if (item.key === 'use_mock_data') config.useMockData = val === true || val === 'true';
      if (item.key === 'kite_api_key') config.kiteApiKey = typeof val === 'string' ? val : String(val);
      if (item.key === 'kite_access_token') config.kiteAccessToken = typeof val === 'string' ? val : String(val);
      if (item.key === 'kite_gold_instrument_token') config.kiteGoldToken = typeof val === 'number' ? val : parseInt(val, 10);
      if (item.key === 'kite_silver_instrument_token') config.kiteSilverToken = typeof val === 'number' ? val : parseInt(val, 10);
    }
    return config;
  } catch (err) {
    console.error('⚠️ Error fetching dealer_config from DB:', err);
    return defaults;
  }
}

async function main() {
  console.log('🚀 Starting Laxmi Abhushan Ingestion Worker...');
  
  let currentCfg = await fetchDealerConfig();
  console.log(`🔧 Initial Configs -> Gold Badla: ₹${currentCfg.goldBadla}, Silver Badla: ₹${currentCfg.silverBadla}, Use Mock: ${currentCfg.useMockData}`);

  // 1. Get channel singleton and register all listeners BEFORE instantiating RateBroadcaster
  const bullionRatesChannel = supabase.channel('bullion_rates', {
    config: { broadcast: { ack: false } }
  });

  let intervalId: NodeJS.Timeout | null = null;
  let kiteClient: KiteLiveClient | null = null;
  let simulator: RateSimulator | null = null;
  
  let activeProviderType: 'mock' | 'live' | null = null;
  let currentKiteKey = '';
  let currentKiteToken = '';
  let currentGoldToken = 0;
  let currentSilverToken = 0;

  bullionRatesChannel
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'dealer_config' },
      async (payload) => {
        console.log('🔄 dealer_config updated in DB. Checking if reload needed...');
        const newCfg = await fetchDealerConfig();
        
        const providerTypeChanged = (newCfg.useMockData ? 'mock' : 'live') !== activeProviderType;
        const credsChanged = newCfg.kiteApiKey !== currentKiteKey || 
                             newCfg.kiteAccessToken !== currentKiteToken ||
                             newCfg.kiteGoldToken !== currentGoldToken ||
                             newCfg.kiteSilverToken !== currentSilverToken;

        if (providerTypeChanged || (activeProviderType === 'live' && credsChanged)) {
          console.log('🔄 Re-initializing data provider due to configuration changes...');
          currentCfg = newCfg;
          await startProvider(newCfg);
        } else {
          console.log(`🔧 Live Reload -> Updating badla markup. Gold: ₹${newCfg.goldBadla}, Silver: ₹${newCfg.silverBadla}`);
          currentCfg = newCfg;
          if (simulator) {
            simulator.updateBadla(newCfg.goldBadla, newCfg.silverBadla);
          }
          if (kiteClient) {
            kiteClient.updateBadla(newCfg.goldBadla, newCfg.silverBadla);
          }
        }
      }
    )
    .on('broadcast', { event: 'badla-update' }, async (message) => {
      const payload = message.payload;
      if (!payload) return;
      const { goldBadla: newGold, silverBadla: newSilver } = payload;
      console.log(`⚡ Realtime Broadcast Reload -> Gold Badla: ${newGold}, Silver Badla: ${newSilver}`);
      currentCfg.goldBadla = newGold;
      currentCfg.silverBadla = newSilver;
      if (simulator) {
        simulator.updateBadla(newGold, newSilver);
      }
      if (kiteClient) {
        kiteClient.updateBadla(newGold, newSilver);
      }
    });

  // 2. Instantiate RateBroadcaster
  const broadcaster = new RateBroadcaster(supabase, DB_LOG_INTERVAL);

  async function startProvider(cfg: typeof currentCfg) {
    // Clean up existing provider
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    if (kiteClient) {
      console.log('🔌 Disconnecting live Kite client...');
      kiteClient.disconnect();
      kiteClient = null;
    }
    if (simulator) {
      simulator = null;
    }

    // ── Upstox API v2 ────────────────────────────────────────────────────────
    if (cfg.useUpstox && cfg.upstoxAccessToken && cfg.upstoxGoldKey && cfg.upstoxSilverKey) {
      console.log('📡 Running in LIVE mode (Upstox API v2)');
      activeProviderType = 'live';

      const upstoxClient = new UpstoxLiveClient(
        cfg.upstoxAccessToken,
        cfg.upstoxGoldKey,
        cfg.upstoxSilverKey,
        cfg.goldBadla,
        cfg.silverBadla,
      );

      upstoxClient.onTick(async (payload) => {
        await broadcaster.broadcast(payload);
      });

      await upstoxClient.connect(TICK_INTERVAL_MS);
      kiteClient = upstoxClient as any;

    // ── Angel One SmartAPI ───────────────────────────────────────────────────
    } else if (cfg.useAngelOne && cfg.angelApiKey && cfg.angelClientCode && cfg.angelPassword) {
      console.log('📡 Running in LIVE mode (Angel One SmartAPI)');
      activeProviderType = 'live';

      const angelClient = new AngelOneLiveClient(
        cfg.angelApiKey,
        cfg.angelClientCode,
        cfg.angelPassword,
        cfg.angelMpin,
        cfg.angelGoldToken,
        cfg.angelSilverToken,
        cfg.goldBadla,
        cfg.silverBadla,
      );

      angelClient.onTick(async (payload) => {
        await broadcaster.broadcast(payload);
      });

      await angelClient.connect(TICK_INTERVAL_MS);
      // Store reference for badla live-reload
      kiteClient = angelClient as any;

    // ── Zerodha Kite Connect ─────────────────────────────────────────────────
    } else if (!cfg.useMockData && cfg.kiteApiKey && cfg.kiteAccessToken) {
      console.log('📈 Running in LIVE mode (Kite Connect)');
      activeProviderType = 'live';
      currentKiteKey = cfg.kiteApiKey;
      currentKiteToken = cfg.kiteAccessToken;
      currentGoldToken = cfg.kiteGoldToken;
      currentSilverToken = cfg.kiteSilverToken;

      kiteClient = new KiteLiveClient(
        cfg.kiteApiKey,
        cfg.kiteAccessToken,
        cfg.kiteGoldToken,
        cfg.kiteSilverToken,
        cfg.goldBadla,
        cfg.silverBadla
      );

      kiteClient.onTick(async (payload) => {
        console.log(`📈 Live Tick -> Gold Ask: ₹${payload.gold.ask} | Silver Ask: ₹${payload.silver.ask}`);
        await broadcaster.broadcast(payload);
      });

      await kiteClient.connect();

    // ── Simulator (Mock) ─────────────────────────────────────────────────────
    } else {
      console.log('⚠️ Running in MOCK mode (Simulator)');
      activeProviderType = 'mock';
      simulator = new RateSimulator(cfg.goldBadla, cfg.silverBadla);
      intervalId = setInterval(async () => {
        if (simulator) {
          const payload = simulator.generateTick();
          console.log(`🎲 Simulating -> Gold Ask: ₹${payload.gold.ask} | Silver Ask: ₹${payload.silver.ask}`);
          await broadcaster.broadcast(payload);
        }
      }, TICK_INTERVAL_MS);
    }
  }

  // Initial provider startup
  await startProvider(currentCfg);


  // Health check server
  const server = http.createServer((req, res) => {
    if (req.url === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ 
        status: 'ok', 
        timestamp: new Date().toISOString(), 
        mode: activeProviderType 
      }));
    } else {
      res.writeHead(404);
      res.end();
    }
  });

  server.listen(PORT, () => {
    console.log(`💓 Health check server running on port ${PORT}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('\n🛑 Shutting down Ingestion Worker...');
    if (intervalId) clearInterval(intervalId);
    if (kiteClient) {
      console.log('🔌 Disconnecting live Kite client...');
      kiteClient.disconnect();
    }
    await supabase.removeChannel(bullionRatesChannel);
    await broadcaster.shutdown();
    server.close();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

main().catch(console.error);