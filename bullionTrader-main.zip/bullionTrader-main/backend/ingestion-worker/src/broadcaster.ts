import { RealtimeChannel, SupabaseClient } from '@supabase/supabase-js';
import { RatePayload } from '@bulliontrader/shared-types';

export class RateBroadcaster {
  private channel: RealtimeChannel;
  private supabase: SupabaseClient;
  private dbLogInterval: number;
  private tickCounter = 0;

  constructor(supabase: SupabaseClient, dbLogInterval: number = 10) {
    this.supabase = supabase;
    this.dbLogInterval = dbLogInterval;

    this.channel = this.supabase.channel('bullion_rates', {
      config: { broadcast: { self: false, ack: false } }
    });

    this.channel.subscribe((status) => {
      if (status === 'SUBSCRIBED') {
        console.log('📡 RateBroadcaster: Subscribed to channel [bullion_rates]');
      }
    });
  }

  public async broadcast(payload: RatePayload) {
    // Fast track: broadcast
    await this.channel.send({
      type: 'broadcast',
      event: 'rate-update',
      payload
    });

    // Slow track: db log
    this.tickCounter++;
    if (this.tickCounter >= this.dbLogInterval) {
      this.tickCounter = 0;
      await this.logPriceToDatabase(payload);
    }
  }

  private async logPriceToDatabase(payload: RatePayload) {
    try {
      let { error } = await this.supabase.from('rate_history').insert([
        { metal: 'GOLD', bid_price: payload.gold.bid, ask_price: payload.gold.ask, base_mcx: payload.gold.base_mcx, source: 'simulator' },
        { metal: 'SILVER', bid_price: payload.silver.bid, ask_price: payload.silver.ask, base_mcx: payload.silver.base_mcx, source: 'simulator' }
      ]);
      
      // If column 'source' does not exist in schema (postgres error 42703 or PostgREST error PGRST204), fallback and insert without it
      if (error && (error.code === '42703' || error.code === 'PGRST204')) {
        const fallbackResult = await this.supabase.from('rate_history').insert([
          { metal: 'GOLD', bid_price: payload.gold.bid, ask_price: payload.gold.ask, base_mcx: payload.gold.base_mcx },
          { metal: 'SILVER', bid_price: payload.silver.bid, ask_price: payload.silver.ask, base_mcx: payload.silver.base_mcx }
        ]);
        error = fallbackResult.error;
      }

      if (error) {
        // If table doesn't exist yet, we silently ignore
        if (error.code !== '42P01') {
           throw error;
        }
      } else {
        console.log('💾 RateBroadcaster: Logged historical snapshot to DB.');
      }
    } catch (err: any) {
      console.error('⚠️ RateBroadcaster Storage Error:', err.message);
    }
  }

  public async shutdown() {
    console.log('🔌 RateBroadcaster: Unsubscribing from channel...');
    await this.supabase.removeChannel(this.channel);
  }
}
