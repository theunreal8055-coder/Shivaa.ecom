import { RatePayload, MetalRate } from '@bulliontrader/shared-types';

export class RateSimulator {
  private liveGoldPrice = 150000;   // MCX Gold Future ~₹1,50,000 per 10g (Sep 2026)
  private liveSilverPrice = 95000;  // MCX Silver Future ~₹95,000 per kg (Sep 2026)
  
  private goldBadla = 150;
  private silverBadla = 250;

  constructor(goldBadla?: number, silverBadla?: number) {
    if (goldBadla) this.goldBadla = goldBadla;
    if (silverBadla) this.silverBadla = silverBadla;
  }

  public updateBadla(goldBadla: number, silverBadla: number) {
    this.goldBadla = goldBadla;
    this.silverBadla = silverBadla;
  }

  public generateTick(): RatePayload {
    const goldDelta = (Math.random() - 0.5) * 40;
    const silverDelta = (Math.random() - 0.5) * 60;

    this.liveGoldPrice += goldDelta;
    this.liveSilverPrice += silverDelta;

    return {
      timestamp: new Date().toISOString(),
      gold: {
        bid: Math.round(this.liveGoldPrice),
        ask: Math.round(this.liveGoldPrice + this.goldBadla),
        base_mcx: Math.round(this.liveGoldPrice)
      },
      silver: {
        bid: Math.round(this.liveSilverPrice),
        ask: Math.round(this.liveSilverPrice + this.silverBadla),
        base_mcx: Math.round(this.liveSilverPrice)
      }
    };
  }
}
