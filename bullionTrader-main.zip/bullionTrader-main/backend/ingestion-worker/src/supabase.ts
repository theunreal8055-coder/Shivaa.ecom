// ============================================================================
// Ingestion Worker — Supabase client initialisation
// ============================================================================

import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { config } from './config.js';

/** Admin-level Supabase client (uses service role key, no session persistence) */
export const supabase: SupabaseClient = createClient(
  config.supabaseUrl,
  config.supabaseServiceKey,
  { auth: { persistSession: false } },
);
