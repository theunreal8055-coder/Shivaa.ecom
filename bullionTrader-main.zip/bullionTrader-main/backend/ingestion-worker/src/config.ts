// ============================================================================
// Ingestion Worker — Configuration from environment variables
// ============================================================================

import dotenv from 'dotenv';
import type { WorkerConfig } from './types.js';

dotenv.config();

function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    throw new Error(`❌ Missing required environment variable: ${key}`);
  }
  return value;
}

export const config: WorkerConfig = {
  supabaseUrl: requireEnv('SUPABASE_URL'),
  supabaseServiceKey: requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
  goldBadlaMarkup: parseFloat(process.env.GOLD_BADLA_MARKUP || '150'),
  silverBadlaMarkup: parseFloat(process.env.SILVER_BADLA_MARKUP || '250'),
  tickIntervalMs: parseInt(process.env.TICK_INTERVAL_MS || '1000', 10),
  dbLogInterval: parseInt(process.env.DB_LOG_INTERVAL || '10', 10),
  healthPort: parseInt(process.env.HEALTH_PORT || '3003', 10),
};
