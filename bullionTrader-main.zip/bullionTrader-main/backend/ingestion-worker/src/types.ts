// ============================================================================
// Ingestion Worker — TypeScript interfaces for rate payloads
// ============================================================================

/** Price data for a single metal (Gold or Silver) */
export interface MetalRate {
  /** Base price without badla/markup */
  bid: number;
  /** Price with badla/markup added */
  ask: number;
  /** MCX reference price */
  base_mcx: number;
}

/** Top-level payload broadcast via Supabase Realtime */
export interface RatePayload {
  timestamp: string;
  gold: MetalRate;
  silver: MetalRate;
}

/** Worker configuration loaded from environment */
export interface WorkerConfig {
  supabaseUrl: string;
  supabaseServiceKey: string;
  goldBadlaMarkup: number;
  silverBadlaMarkup: number;
  tickIntervalMs: number;
  dbLogInterval: number;
  healthPort: number;
}
