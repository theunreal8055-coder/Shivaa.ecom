/**
 * Angel One SmartAPI — Live MCX Gold & Silver price client.
 *
 * Uses the Angel One SmartAPI REST + WebSocket feed to stream real-time
 * MCX futures prices (same exchange as Zerodha Kite).
 *
 * Free to use with any Angel One demat account.
 * Docs: https://smartapi.angelbroking.com/docs
 *
 * Instrument tokens for MCX:
 *   GOLD  (near-month future) → use ANGEL_ONE_GOLD_TOKEN   (e.g. "11292" for GOLD25OCTFUT)
 *   SILVER(near-month future) → use ANGEL_ONE_SILVER_TOKEN (e.g. "11295" for SILVER25DECFUT)
 */

import https from 'https';
import { RatePayload } from '@bulliontrader/shared-types';

type TickCallback = (payload: RatePayload) => void;

// ─── Angel One REST helper ───────────────────────────────────────────────────

function angelRequest<T = any>(
  method: 'GET' | 'POST',
  path: string,
  body: object | null,
  authToken?: string,
  apiKey?: string,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const bodyStr = body ? JSON.stringify(body) : '';
    const options: https.RequestOptions = {
      hostname: 'apiconnect.angelbroking.com',
      port: 443,
      path,
      method,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-UserType': 'USER',
        'X-SourceID': 'WEB',
        'X-ClientLocalIP': '127.0.0.1',
        'X-ClientPublicIP': '127.0.0.1',
        'X-MACAddress': '00:00:00:00:00:00',
        'X-PrivateKey': apiKey || '',
        ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
        ...(bodyStr ? { 'Content-Length': Buffer.byteLength(bodyStr).toString() } : {}),
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => (data += chunk));
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch {
          reject(new Error(`Angel One: Invalid JSON response: ${data}`));
        }
      });
    });

    req.on('error', reject);
    if (bodyStr) req.write(bodyStr);
    req.end();
  });
}

// ─── Session management ──────────────────────────────────────────────────────

interface AngelSession {
  jwtToken: string;
  refreshToken: string;
  feedToken: string;
}

async function createAngelSession(
  apiKey: string,
  clientCode: string,
  password: string,
  totp: string,
): Promise<AngelSession> {
  console.log('🔐 Angel One: Creating session...');
  const resp = await angelRequest(
    'POST',
    '/rest/auth/angelbroking/user/v1/loginByPassword',
    { clientcode: clientCode, password, totp },
    undefined,
    apiKey,
  );

  if (!resp.status || resp.errorcode) {
    throw new Error(`Angel One login failed: ${resp.message || JSON.stringify(resp)}`);
  }

  const { jwtToken, refreshToken, feedToken } = resp.data;
  console.log('✅ Angel One: Session created successfully.');
  return { jwtToken, refreshToken, feedToken };
}

// ─── LTP (Last Traded Price) polling client ──────────────────────────────────
// Angel One WebSocket feed requires a separate npm package or raw WS implementation.
// For simplicity and reliability, we poll the LTP endpoint every second — 
// this stays well within free-tier rate limits and is identical to what the 
// WebSocket gives for non-HFT use-cases.

async function fetchLTP(
  apiKey: string,
  jwtToken: string,
  goldToken: string,
  silverToken: string,
): Promise<{ goldPrice: number; silverPrice: number }> {
  const resp = await angelRequest(
    'POST',
    '/rest/secure/angelbroking/market/v1/quote/',
    {
      mode: 'LTP',
      exchangeTokens: {
        MCX: [goldToken, silverToken],
      },
    },
    jwtToken,
    apiKey,
  );

  if (!resp.status || !resp.data?.fetched) {
    throw new Error(`Angel One LTP fetch failed: ${resp.message || JSON.stringify(resp)}`);
  }

  const fetched: any[] = resp.data.fetched;
  let goldPrice = 0;
  let silverPrice = 0;

  for (const item of fetched) {
    if (String(item.symbolToken) === String(goldToken)) {
      goldPrice = item.ltp;
    } else if (String(item.symbolToken) === String(silverToken)) {
      silverPrice = item.ltp;
    }
  }

  if (goldPrice === 0 || silverPrice === 0) {
    throw new Error('Angel One: Could not find Gold or Silver LTP in response');
  }

  return { goldPrice, silverPrice };
}

// ─── Main Client Class ───────────────────────────────────────────────────────

export class AngelOneLiveClient {
  private apiKey: string;
  private clientCode: string;
  private password: string;
  private mpin: string;

  private goldToken: string;
  private silverToken: string;

  private goldBadla: number;
  private silverBadla: number;

  private session: AngelSession | null = null;
  private intervalId: NodeJS.Timeout | null = null;
  private onTickCallback?: TickCallback;

  constructor(
    apiKey: string,
    clientCode: string,
    password: string,
    mpin: string,
    goldToken: string,
    silverToken: string,
    goldBadla: number,
    silverBadla: number,
  ) {
    this.apiKey = apiKey;
    this.clientCode = clientCode;
    this.password = password;
    this.mpin = mpin;
    this.goldToken = goldToken;
    this.silverToken = silverToken;
    this.goldBadla = goldBadla;
    this.silverBadla = silverBadla;
  }

  public updateBadla(goldBadla: number, silverBadla: number) {
    this.goldBadla = goldBadla;
    this.silverBadla = silverBadla;
  }

  public onTick(callback: TickCallback) {
    this.onTickCallback = callback;
  }

  public async connect(tickIntervalMs = 1000) {
    console.log('📡 Angel One: Connecting...');

    // NOTE: Angel One TOTP is time-based — generate it using your TOTP app
    // or use the MPIN (4-digit PIN) if TOTP is not set up.
    // We use MPIN as the TOTP field for simplicity here.
    this.session = await createAngelSession(
      this.apiKey,
      this.clientCode,
      this.password,
      this.mpin, // Use TOTP from your authenticator app if enabled
    );

    console.log(`📈 Angel One: Starting LTP polling every ${tickIntervalMs}ms...`);

    this.intervalId = setInterval(async () => {
      try {
        if (!this.session) return;

        const { goldPrice, silverPrice } = await fetchLTP(
          this.apiKey,
          this.session.jwtToken,
          this.goldToken,
          this.silverToken,
        );

        const payload: RatePayload = {
          timestamp: new Date().toISOString(),
          gold: {
            bid: Math.round(goldPrice),
            ask: Math.round(goldPrice + this.goldBadla),
            base_mcx: goldPrice,
          },
          silver: {
            bid: Math.round(silverPrice),
            ask: Math.round(silverPrice + this.silverBadla),
            base_mcx: silverPrice,
          },
        };

        console.log(`📈 Angel One Tick → Gold: ₹${payload.gold.bid} | Silver: ₹${payload.silver.bid}`);

        if (this.onTickCallback) {
          this.onTickCallback(payload);
        }
      } catch (err: any) {
        console.error('⚠️ Angel One: Tick error:', err.message);
        // If session expired (401), try to refresh
        if (err.message?.includes('401') || err.message?.toLowerCase().includes('unauthorized')) {
          console.log('🔄 Angel One: Session may have expired. Re-authenticating...');
          try {
            this.session = await createAngelSession(
              this.apiKey,
              this.clientCode,
              this.password,
              this.mpin,
            );
            console.log('✅ Angel One: Re-authenticated successfully.');
          } catch (reAuthErr: any) {
            console.error('❌ Angel One: Re-authentication failed:', reAuthErr.message);
          }
        }
      }
    }, tickIntervalMs);
  }

  public disconnect() {
    console.log('🔌 Angel One: Disconnecting...');
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.session = null;
  }

  /**
   * Helper: Look up the current near-month MCX Gold & Silver instrument tokens.
   * Run this once to find the correct token IDs to put in your .env file.
   */
  public async resolveTokens(): Promise<{ goldToken: string; silverToken: string }> {
    if (!this.session) {
      this.session = await createAngelSession(
        this.apiKey,
        this.clientCode,
        this.password,
        this.mpin,
      );
    }

    // Fetch MCX instrument master
    const resp = await angelRequest('GET', '/rest/secure/angelbroking/master/v1/getInstrumentList?exchange=MCX', null, this.session.jwtToken, this.apiKey);
    
    if (!resp.data) {
      throw new Error('Angel One: Could not fetch instrument list');
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const goldFutures = resp.data.filter((i: any) =>
      i.name === 'GOLD' && i.instrumenttype === 'FUTCOM' && new Date(i.expiry) >= today
    ).sort((a: any, b: any) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime());

    const silverFutures = resp.data.filter((i: any) =>
      i.name === 'SILVER' && i.instrumenttype === 'FUTCOM' && new Date(i.expiry) >= today
    ).sort((a: any, b: any) => new Date(a.expiry).getTime() - new Date(b.expiry).getTime());

    if (!goldFutures.length || !silverFutures.length) {
      throw new Error('Angel One: No active GOLD or SILVER futures found');
    }

    const gold = goldFutures[0];
    const silver = silverFutures[0];

    console.log(`📌 Resolved Gold: ${gold.tradingsymbol} (Token: ${gold.symboltoken}, Expiry: ${gold.expiry})`);
    console.log(`📌 Resolved Silver: ${silver.tradingsymbol} (Token: ${silver.symboltoken}, Expiry: ${silver.expiry})`);

    return {
      goldToken: String(gold.symboltoken),
      silverToken: String(silver.symboltoken),
    };
  }
}
