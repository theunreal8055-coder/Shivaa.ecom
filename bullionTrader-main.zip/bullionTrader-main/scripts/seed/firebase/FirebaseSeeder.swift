import Foundation
import FirebaseDatabase

/// Seeds Firebase Realtime Database with initial rate data.
/// Call once from admin to populate the RTDB structure.
enum FirebaseSeeder {

    static func seedIfEmpty() {
        let ref = Database.database().reference().child("bullion-rates")
        ref.child("config").observeSingleEvent(of: .value) { snapshot in
            if !snapshot.exists() {
                seed(ref: ref)
            }
        }
    }

    static func seed(ref: DatabaseReference? = nil) {
        let db = ref ?? Database.database().reference().child("bullion-rates")
        let now = Date().timeIntervalSince1970 * 1000 // milliseconds

        let data: [String: Any] = [
            "gold": [
                "fine_995": [
                    "name": "Gold Fine", "purity": "995", "unit": "10 gm",
                    "buyRate": 92_200, "sellRate": 92_350,
                    "highRate": 92_600, "lowRate": 91_800,
                    "previousClose": 91_850, "lastUpdated": now,
                ],
                "24k": [
                    "name": "Gold 24K", "purity": "999", "unit": "10 gm",
                    "buyRate": 92_500, "sellRate": 92_650,
                    "highRate": 92_900, "lowRate": 92_000,
                    "previousClose": 92_100, "lastUpdated": now,
                ],
                "22k": [
                    "name": "Gold 22K", "purity": "916", "unit": "10 gm",
                    "buyRate": 84_800, "sellRate": 84_950,
                    "highRate": 85_100, "lowRate": 84_400,
                    "previousClose": 84_480, "lastUpdated": now,
                ],
                "18k": [
                    "name": "Gold 18K", "purity": "750", "unit": "10 gm",
                    "buyRate": 69_400, "sellRate": 69_500,
                    "highRate": 69_700, "lowRate": 69_100,
                    "previousClose": 69_150, "lastUpdated": now,
                ],
                "guinee": [
                    "name": "Gold Guinee", "purity": "916", "unit": "8 gm",
                    "buyRate": 67_850, "sellRate": 67_960,
                    "highRate": 68_100, "lowRate": 67_500,
                    "previousClose": 67_590, "lastUpdated": now,
                ],
                "petal": [
                    "name": "Gold Petal", "purity": "999", "unit": "1 gm",
                    "buyRate": 9_250, "sellRate": 9_265,
                    "highRate": 9_290, "lowRate": 9_200,
                    "previousClose": 9_210, "lastUpdated": now,
                ],
            ],
            "silver": [
                "fine_999": [
                    "name": "Silver Fine", "purity": "999", "unit": "1 kg",
                    "buyRate": 105_200, "sellRate": 105_500,
                    "highRate": 106_000, "lowRate": 104_800,
                    "previousClose": 106_000, "lastUpdated": now,
                ],
                "925": [
                    "name": "Silver 925", "purity": "925", "unit": "1 kg",
                    "buyRate": 97_300, "sellRate": 97_600,
                    "highRate": 98_000, "lowRate": 96_900,
                    "previousClose": 97_950, "lastUpdated": now,
                ],
                "micro": [
                    "name": "Silver Micro", "purity": "999", "unit": "100 gm",
                    "buyRate": 10_520, "sellRate": 10_550,
                    "highRate": 10_600, "lowRate": 10_480,
                    "previousClose": 10_600, "lastUpdated": now,
                ],
            ],
            "spot": [
                "xau": [
                    "name": "Gold Spot", "symbol": "XAU",
                    "priceUSD": 2_340.50, "change": 12.30, "changePercent": 0.53,
                    "lastUpdated": now,
                ],
                "xag": [
                    "name": "Silver Spot", "symbol": "XAG",
                    "priceUSD": 28.75, "change": -0.45, "changePercent": -1.54,
                    "lastUpdated": now,
                ],
            ],
            "local": [
                "gold": [
                    "commodityName": "Gold", "category": "gold",
                    "unit": "10 gm", "mcxRate": 92_500, "localPremium": 2_000,
                    "lastUpdated": now,
                ],
                "silver": [
                    "commodityName": "Silver", "category": "silver",
                    "unit": "1 kg", "mcxRate": 105_200, "localPremium": 1_500,
                    "lastUpdated": now,
                ],
            ],
            "config": [
                "isMarketOpen": true,
                "lastGlobalUpdate": now,
                "usdToInr": 83.45,
                "importDutyPercent": 15.0,
                "gstPercent": 3.0,
            ],
        ]

        db.setValue(data)
    }
}
