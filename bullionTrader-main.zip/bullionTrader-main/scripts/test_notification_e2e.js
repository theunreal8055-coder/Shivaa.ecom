/**
 * BullionTrader — End-to-End Notification Cycle Test
 *
 * This script simulates the full push notification cycle:
 *   1. Connects to Supabase with the service role key
 *   2. Finds the demo user (demo@laxmibullion.in)
 *   3. Sets a test FCM token on the user's profile
 *   4. Creates a very-low-threshold GOLD price alert (target_price = 100)
 *   5. Broadcasts a simulated rate-update on the bullion_rates Realtime channel
 *   6. Waits, then verifies the alert was marked as triggered in the DB
 *   7. Cleans up test data
 *
 * Run from the project root:
 *   node scripts/test_notification_e2e.js
 */

import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// ─── Configuration ───────────────────────────────────────────────────────────
dotenv.config({ path: './backend/api-gateway/.env' });

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
const DEMO_EMAIL = 'demo@laxmibullion.in';
const TEST_FCM_TOKEN = 'test_fcm_token_e2e';

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error('❌ Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY in backend/api-gateway/.env');
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false },
});

// ─── Helpers ─────────────────────────────────────────────────────────────────
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let passed = 0;
let failed = 0;

function report(step, ok, detail = '') {
  if (ok) {
    passed++;
    console.log(`  ✅ PASS — ${step}${detail ? ': ' + detail : ''}`);
  } else {
    failed++;
    console.log(`  ❌ FAIL — ${step}${detail ? ': ' + detail : ''}`);
  }
}

// ─── State tracked for cleanup ───────────────────────────────────────────────
let demoUserId = null;
let testAlertId = null;

// ─── Main Test Flow ──────────────────────────────────────────────────────────
async function run() {
  console.log('\n══════════════════════════════════════════════════════════════');
  console.log('  BullionTrader — E2E Notification Cycle Test');
  console.log('══════════════════════════════════════════════════════════════\n');

  // ── Step 1: Find demo user ─────────────────────────────────────────────────
  console.log('Step 1: Finding demo user...');
  try {
    const { data: { users }, error } = await supabase.auth.admin.listUsers();
    if (error) throw new Error(error.message);

    const demoUser = users.find((u) => u.email === DEMO_EMAIL);
    if (!demoUser) throw new Error(`User with email "${DEMO_EMAIL}" not found`);

    demoUserId = demoUser.id;
    report('Find demo user', true, `id = ${demoUserId}`);
  } catch (err) {
    report('Find demo user', false, err.message);
    await cleanup();
    process.exit(1);
  }

  // ── Step 2: Set test FCM token on profile ──────────────────────────────────
  console.log('\nStep 2: Setting test FCM token on profile...');
  try {
    const { error } = await supabase
      .from('profiles')
      .upsert({ id: demoUserId, fcm_token: TEST_FCM_TOKEN, full_name: 'Demo User' });

    if (error) throw new Error(error.message);
    report('Set FCM token', true, `fcm_token = "${TEST_FCM_TOKEN}"`);
  } catch (err) {
    report('Set FCM token', false, err.message);
    await cleanup();
    process.exit(1);
  }

  // ── Step 3: Create a test price alert ──────────────────────────────────────
  console.log('\nStep 3: Creating test price alert (GOLD > 100)...');
  try {
    const { data, error } = await supabase
      .from('price_alerts')
      .insert({
        user_id: demoUserId,
        metal: 'GOLD',
        direction: 'above',
        target_price: 100,
        is_active: true,
        is_triggered: false,
      })
      .select('id')
      .single();

    if (error) throw new Error(error.message);
    testAlertId = data.id;
    report('Create price alert', true, `alert id = ${testAlertId}`);
  } catch (err) {
    report('Create price alert', false, err.message);
    await cleanup();
    process.exit(1);
  }

  // ── Step 4: Wait 2 seconds ─────────────────────────────────────────────────
  console.log('\nStep 4: Waiting 2 seconds for alert to propagate...');
  await sleep(2000);
  report('Wait for propagation', true, '2s elapsed');

  // ── Step 5: Broadcast simulated rate-update ────────────────────────────────
  console.log('\nStep 5: Broadcasting simulated rate-update on bullion_rates channel...');
  try {
    const channel = supabase.channel('bullion_rates');

    // We need to subscribe first before we can send
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Channel subscription timed out')), 10000);
      channel.subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          clearTimeout(timeout);
          resolve();
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          clearTimeout(timeout);
          reject(new Error(`Channel subscription failed: ${status}`));
        }
      });
    });

    const sendResult = await channel.send({
      type: 'broadcast',
      event: 'rate-update',
      payload: {
        gold: { bid: 72400, ask: 72500 },
        silver: { bid: 86100, ask: 86200 },
      },
    });

    report('Broadcast rate-update', sendResult === 'ok', `sendResult = "${sendResult}"`);

    // Unsubscribe from the channel after sending
    await supabase.removeChannel(channel);
  } catch (err) {
    report('Broadcast rate-update', false, err.message);
  }

  // ── Step 6: Wait 5 seconds for notification service processing ─────────────
  console.log('\nStep 6: Waiting 5 seconds for processing...');
  await sleep(5000);
  report('Wait for processing', true, '5s elapsed');

  // ── Step 7: Verify alert was triggered ─────────────────────────────────────
  console.log('\nStep 7: Verifying alert trigger state in database...');
  try {
    const { data, error } = await supabase
      .from('price_alerts')
      .select('is_triggered, is_active')
      .eq('id', testAlertId)
      .single();

    if (error) throw new Error(error.message);

    const isTriggered = data.is_triggered === true;
    const isInactive = data.is_active === false;

    if (isTriggered && isInactive) {
      report('Alert triggered (is_triggered=true, is_active=false)', true);
    } else {
      report(
        'Alert triggered',
        false,
        `is_triggered=${data.is_triggered}, is_active=${data.is_active} (expected true / false). ` +
        'NOTE: This is expected if the notification service is not running. ' +
        'The broadcast was sent successfully — the service would process it when active.'
      );
    }
  } catch (err) {
    report('Verify alert trigger', false, err.message);
  }

  // ── Step 8: Cleanup ────────────────────────────────────────────────────────
  console.log('\nStep 8: Cleaning up test data...');
  await cleanup();

  // ── Summary ────────────────────────────────────────────────────────────────
  console.log('\n══════════════════════════════════════════════════════════════');
  console.log(`  Results: ${passed} passed, ${failed} failed`);
  console.log('══════════════════════════════════════════════════════════════\n');

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

// ─── Cleanup ─────────────────────────────────────────────────────────────────
async function cleanup() {
  // Delete the test alert
  if (testAlertId) {
    try {
      const { error } = await supabase
        .from('price_alerts')
        .delete()
        .eq('id', testAlertId);

      if (error) throw new Error(error.message);
      report('Delete test alert', true, `id = ${testAlertId}`);
    } catch (err) {
      report('Delete test alert', false, err.message);
    }
  }

  // Reset FCM token to null
  if (demoUserId) {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ fcm_token: null })
        .eq('id', demoUserId);

      if (error) throw new Error(error.message);
      report('Reset FCM token to null', true);
    } catch (err) {
      report('Reset FCM token', false, err.message);
    }
  }
}

// ─── Entry Point ─────────────────────────────────────────────────────────────
run().catch((err) => {
  console.error('\n💥 Unhandled error:', err.message);
  cleanup().finally(() => process.exit(1));
});
