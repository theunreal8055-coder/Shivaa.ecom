from pathlib import Path
import math

import numpy as np
import pandas as pd
from openpyxl import load_workbook
from openpyxl.chart import BarChart, LineChart, PieChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter


SOURCE = Path("outputs/Google_Trends_Dataset_Stage1_Cleaned.xlsx")
OUTPUT = Path("outputs/Google_Trends_Final_Intelligence_Workbook.xlsx")


BRAND = "Google Trends Market Intelligence"
HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
SUBHEADER_FILL = PatternFill("solid", fgColor="D9EAF7")
KPI_FILL = PatternFill("solid", fgColor="E2F0D9")
WHITE_FONT = Font(color="FFFFFF", bold=True)
BOLD = Font(bold=True)
THIN_BORDER = Border(
    left=Side(style="thin", color="D9D9D9"),
    right=Side(style="thin", color="D9D9D9"),
    top=Side(style="thin", color="D9D9D9"),
    bottom=Side(style="thin", color="D9D9D9"),
)


def norm(series, invert=False):
    series = pd.to_numeric(series, errors="coerce").fillna(0)
    low = series.min()
    high = series.max()
    if math.isclose(float(high), float(low)):
        out = pd.Series(100, index=series.index, dtype=float)
    else:
        out = (series - low) / (high - low) * 100
    if invert:
        out = 100 - out
    return out.clip(0, 100)


def rank_class(rank, total, labels):
    pct = rank / total
    if pct <= 0.20:
        return labels[0]
    if pct <= 0.40:
        return labels[1]
    if pct <= 0.72:
        return labels[2]
    return labels[3]


def clean_percent(value):
    if pd.isna(value):
        return 0.0
    text = str(value).strip()
    if text == "Breakout":
        return 5000.0
    if text == "Stable":
        return 0.0
    return float(text.replace("+", "").replace("%", "") or 0)


def slope_for_group(df):
    ordered = df.sort_values("week_start_date")
    y = ordered["search_interest_index"].astype(float).to_numpy()
    if len(y) < 2:
        return 0.0
    x = np.arange(len(y))
    return float(np.polyfit(x, y, 1)[0])


def classify_portfolio(row):
    leadership = row["Leadership Classification"]
    opportunity = row["Opportunity Classification"]
    if leadership in {"Market Leader", "Strong Performer"} and opportunity in {"Breakout Opportunity", "Emerging Theme"}:
        return "Invest"
    if opportunity in {"Breakout Opportunity", "Emerging Theme"}:
        return "Watch"
    if leadership in {"Market Leader", "Strong Performer"}:
        return "Defend"
    if leadership == "Weak Performer" and opportunity == "Low Potential Theme":
        return "Avoid"
    return "Monitor"


def classify_sustainability(row):
    if row["Growth Indicator"] >= 25 and row["Consistency Score"] >= 65:
        return "Sustainable Growth"
    if row["Peak Interest"] >= 85 and row["Consistency Score"] < 50:
        return "Temporary Spike"
    if row["Growth Indicator"] < -10:
        return "Declining Theme"
    if row["Volatility Score"] >= 35:
        return "Seasonal / Event-Driven"
    return "Stable Performer"


def supporting_theme(row):
    return (
        f"Leadership {row['Leadership Score']:.1f}; opportunity {row['Opportunity Score']:.1f}; "
        f"current interest {row['Current Interest']:.1f}; growth {row['Growth Indicator']:.1f}%."
    )


def write_df(writer, sheet_name, df):
    df.to_excel(writer, sheet_name=sheet_name, index=False)


def style_workbook(path):
    wb = load_workbook(path)
    for ws in wb.worksheets:
        ws.freeze_panes = "A2"
        ws.sheet_view.showGridLines = False
        max_col = ws.max_column
        if ws.max_row >= 1:
            for cell in ws[1]:
                cell.fill = HEADER_FILL
                cell.font = WHITE_FONT
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        for row in ws.iter_rows():
            for cell in row:
                cell.border = THIN_BORDER
                cell.alignment = Alignment(vertical="top", wrap_text=True)
        ws.auto_filter.ref = ws.dimensions
        for col_idx in range(1, max_col + 1):
            letter = get_column_letter(col_idx)
            values = [ws.cell(row=row, column=col_idx).value for row in range(1, min(ws.max_row, 200) + 1)]
            max_len = max(len(str(value)) if value is not None else 0 for value in values)
            ws.column_dimensions[letter].width = min(max(max_len + 2, 12), 42)
        for row in range(2, ws.max_row + 1):
            ws.row_dimensions[row].height = 28
    return wb


def add_title(ws, title, subtitle=None):
    ws.insert_rows(1, 3)
    ws["A1"] = title
    ws["A1"].font = Font(bold=True, size=18, color="1F4E78")
    if subtitle:
        ws["A2"] = subtitle
        ws["A2"].font = Font(italic=True, color="666666")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=min(ws.max_column, 8))
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=min(ws.max_column, 8))


def add_bar_chart(ws, title, data_range, cats_range, anchor):
    chart = BarChart()
    chart.title = title
    chart.style = 10
    chart.y_axis.title = "Score"
    chart.x_axis.title = ""
    chart.add_data(data_range, titles_from_data=True)
    chart.set_categories(cats_range)
    chart.height = 7
    chart.width = 13
    ws.add_chart(chart, anchor)


def add_line_chart(ws, title, data_range, cats_range, anchor):
    chart = LineChart()
    chart.title = title
    chart.style = 13
    chart.y_axis.title = "Interest"
    chart.add_data(data_range, titles_from_data=True)
    chart.set_categories(cats_range)
    chart.height = 7
    chart.width = 13
    ws.add_chart(chart, anchor)


def add_pie_chart(ws, title, data_range, cats_range, anchor):
    chart = PieChart()
    chart.title = title
    chart.add_data(data_range, titles_from_data=True)
    chart.set_categories(cats_range)
    chart.height = 7
    chart.width = 10
    ws.add_chart(chart, anchor)


def add_dashboard_charts(wb):
    ws = wb["Market_Leadership_Dashboard"]
    add_title(ws, "Market Leadership Dashboard", "Current market position, leadership tiers, and performance gaps.")
    add_bar_chart(
        ws,
        "Top 10 Market Leaders",
        Reference(ws, min_col=2, min_row=4, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "J4",
    )
    add_pie_chart(
        ws,
        "Leadership Tier Distribution",
        Reference(ws, min_col=5, min_row=4, max_row=8),
        Reference(ws, min_col=4, min_row=5, max_row=8),
        "J20",
    )
    add_bar_chart(
        ws,
        "Average vs Peak Interest",
        Reference(ws, min_col=6, min_row=4, max_col=7, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "T4",
    )

    ws = wb["Emerging_Opportunity_Dashboard"]
    add_title(ws, "Emerging Opportunity Dashboard", "Future growth momentum and breakout opportunity signals.")
    add_bar_chart(
        ws,
        "Top 10 Opportunity Scores",
        Reference(ws, min_col=2, min_row=4, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "J4",
    )
    add_pie_chart(
        ws,
        "Opportunity Tier Distribution",
        Reference(ws, min_col=5, min_row=4, max_row=8),
        Reference(ws, min_col=4, min_row=5, max_row=8),
        "J20",
    )
    add_bar_chart(
        ws,
        "Growth and Momentum",
        Reference(ws, min_col=6, min_row=4, max_col=7, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "T4",
    )

    ws = wb["Search_Ecosystem_Dashboard"]
    add_title(ws, "Search Ecosystem Dashboard", "Related query depth, rising-query concentration, and ecosystem strength.")
    add_bar_chart(
        ws,
        "Top 10 Ecosystem Scores",
        Reference(ws, min_col=2, min_row=4, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "J4",
    )
    add_pie_chart(
        ws,
        "Ecosystem Tier Distribution",
        Reference(ws, min_col=5, min_row=4, max_row=8),
        Reference(ws, min_col=4, min_row=5, max_row=8),
        "J20",
    )
    add_bar_chart(
        ws,
        "Related vs Rising Query Count",
        Reference(ws, min_col=6, min_row=4, max_col=7, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "T4",
    )

    ws = wb["Regional_Opportunity_Dashboard"]
    add_title(ws, "Regional Opportunity Dashboard", "State ranking, demand concentration, and priority regions.")
    add_bar_chart(
        ws,
        "Top 10 Regional Scores",
        Reference(ws, min_col=2, min_row=4, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "J4",
    )
    add_pie_chart(
        ws,
        "Regional Priority Distribution",
        Reference(ws, min_col=5, min_row=4, max_row=8),
        Reference(ws, min_col=4, min_row=5, max_row=8),
        "J20",
    )
    add_bar_chart(
        ws,
        "Average Interest and Theme Coverage",
        Reference(ws, min_col=6, min_row=4, max_col=7, max_row=14),
        Reference(ws, min_col=1, min_row=5, max_row=14),
        "T4",
    )


def create_dashboard_frame(engine, score_col, class_col, metric_cols):
    top = engine.sort_values(score_col, ascending=False).head(10).copy()
    top_frame = top[[engine.columns[0], score_col] + metric_cols].copy()
    top_frame.columns = ["Name", "Score"] + metric_cols
    dist = engine[class_col].value_counts().reset_index()
    dist.columns = ["Classification", "Count"]
    rows = []
    max_len = max(len(top_frame), len(dist))
    for i in range(max_len):
        base = {}
        if i < len(top_frame):
            base.update(top_frame.iloc[i].to_dict())
        else:
            base.update({col: "" for col in top_frame.columns})
        if i < len(dist):
            base.update(dist.iloc[i].to_dict())
        else:
            base.update({"Classification": "", "Count": ""})
        rows.append(base)
    return pd.DataFrame(rows)


def main():
    cleaned = pd.ExcelFile(SOURCE)
    weekly = pd.read_excel(SOURCE, sheet_name="Weekly_Search_Trends")
    regional = pd.read_excel(SOURCE, sheet_name="Regional_Interest")
    related = pd.read_excel(SOURCE, sheet_name="Related_Queries")
    term_ref = pd.read_excel(SOURCE, sheet_name="Term_Reference")

    weekly["week_start_date"] = pd.to_datetime(weekly["week_start_date"])
    latest_date = weekly["week_start_date"].max()
    current_start = latest_date - pd.Timedelta(weeks=12)
    previous_start = latest_date - pd.Timedelta(weeks=24)
    first_end = weekly["week_start_date"].min() + pd.Timedelta(weeks=12)

    market = weekly.groupby("search_term").agg(
        **{
            "Average Interest": ("search_interest_index", "mean"),
            "Peak Interest": ("search_interest_index", "max"),
            "Volatility Score": ("search_interest_index", "std"),
        }
    ).reset_index()
    market["Volatility Score"] = market["Volatility Score"].fillna(0).round(2)
    market["Consistency Score"] = (100 - norm(market["Volatility Score"])).round(2)
    market["Leadership Score"] = (
        0.40 * norm(market["Average Interest"])
        + 0.25 * norm(market["Peak Interest"])
        + 0.25 * market["Consistency Score"]
        + 0.10 * norm(market["Volatility Score"], invert=True)
    ).round(2)
    market = market.sort_values("Leadership Score", ascending=False).reset_index(drop=True)
    market["Rank"] = market.index + 1
    total_terms = len(market)
    market["Classification"] = market["Rank"].map(
        lambda rank: rank_class(rank, total_terms, ["Market Leader", "Strong Performer", "Average Performer", "Weak Performer"])
    )
    market = market.rename(columns={"search_term": "Search Theme"})
    market = market[
        [
            "Search Theme",
            "Average Interest",
            "Peak Interest",
            "Consistency Score",
            "Volatility Score",
            "Leadership Score",
            "Rank",
            "Classification",
        ]
    ].round(2)

    first = weekly[weekly["week_start_date"] <= first_end].groupby("search_term")["search_interest_index"].mean()
    previous = weekly[(weekly["week_start_date"] > previous_start) & (weekly["week_start_date"] <= current_start)].groupby("search_term")["search_interest_index"].mean()
    current = weekly[weekly["week_start_date"] > current_start].groupby("search_term")["search_interest_index"].mean()
    slopes = weekly.groupby("search_term").apply(slope_for_group, include_groups=False)

    opportunity = pd.DataFrame({"search_term": sorted(weekly["search_term"].unique())})
    opportunity["Current Interest"] = opportunity["search_term"].map(current).fillna(0)
    opportunity["First Period Interest"] = opportunity["search_term"].map(first).fillna(0)
    opportunity["Previous Interest"] = opportunity["search_term"].map(previous).fillna(0)
    opportunity["Growth Indicator"] = np.where(
        opportunity["First Period Interest"] > 0,
        (opportunity["Current Interest"] - opportunity["First Period Interest"]) / opportunity["First Period Interest"] * 100,
        0,
    )
    opportunity["Momentum Indicator"] = opportunity["Current Interest"] - opportunity["Previous Interest"]
    opportunity["Trend Score"] = opportunity["search_term"].map(slopes).fillna(0)
    opportunity["Opportunity Score"] = (
        0.25 * norm(opportunity["Current Interest"])
        + 0.30 * norm(opportunity["Growth Indicator"])
        + 0.25 * norm(opportunity["Momentum Indicator"])
        + 0.20 * norm(opportunity["Trend Score"])
    ).round(2)
    opportunity = opportunity.sort_values("Opportunity Score", ascending=False).reset_index(drop=True)
    opportunity["Rank"] = opportunity.index + 1
    opportunity["Classification"] = opportunity["Rank"].map(
        lambda rank: rank_class(rank, total_terms, ["Breakout Opportunity", "Emerging Theme", "Watchlist Theme", "Low Potential Theme"])
    )
    opportunity = opportunity.rename(columns={"search_term": "Search Theme"})
    opportunity = opportunity[
        [
            "Search Theme",
            "Current Interest",
            "Growth Indicator",
            "Momentum Indicator",
            "Trend Score",
            "Opportunity Score",
            "Rank",
            "Classification",
        ]
    ].round(2)

    related["growth_percent"] = related["growth_indicator"].map(clean_percent)
    ecosystem = related.groupby("search_term").agg(
        **{
            "Related Query Count": ("related_query", "nunique"),
            "Average Relevance Score": ("relevance_score", "mean"),
            "Rising Query Count": ("query_type", lambda s: int((s == "Rising").sum())),
            "Average Rising Growth %": ("growth_percent", "mean"),
        }
    ).reset_index()
    ecosystem["Average Relevance Score"] = ecosystem["Average Relevance Score"].fillna(0)
    ecosystem["Rising Query Percentage"] = ecosystem["Rising Query Count"] / ecosystem["Related Query Count"] * 100
    ecosystem["Ecosystem Score"] = (
        0.25 * norm(ecosystem["Related Query Count"])
        + 0.30 * norm(ecosystem["Average Relevance Score"])
        + 0.25 * norm(ecosystem["Rising Query Percentage"])
        + 0.20 * norm(ecosystem["Average Rising Growth %"])
    ).round(2)
    ecosystem = ecosystem.sort_values("Ecosystem Score", ascending=False).reset_index(drop=True)
    ecosystem["Rank"] = ecosystem.index + 1
    ecosystem["Classification"] = ecosystem["Rank"].map(
        lambda rank: rank_class(rank, len(ecosystem), ["Ecosystem Leader", "Strong Ecosystem", "Moderate Ecosystem", "Weak Ecosystem"])
    )
    ecosystem = ecosystem.rename(columns={"search_term": "Search Theme"})
    ecosystem = ecosystem[
        [
            "Search Theme",
            "Related Query Count",
            "Average Relevance Score",
            "Rising Query Count",
            "Rising Query Percentage",
            "Ecosystem Score",
            "Rank",
            "Classification",
        ]
    ].round(2)

    state_theme = regional.groupby(["state", "search_term"])["regional_interest_index"].mean().reset_index()
    regional_engine = regional.groupby("state").agg(
        **{
            "Average Regional Interest": ("regional_interest_index", "mean"),
            "Theme Coverage": ("search_term", "nunique"),
        }
    ).reset_index()
    high_counts = state_theme[state_theme["regional_interest_index"] >= 60].groupby("state")["search_term"].nunique()
    regional_engine["High Interest Themes"] = regional_engine["state"].map(high_counts).fillna(0).astype(int)
    regional_engine["Regional Score"] = (
        0.50 * norm(regional_engine["Average Regional Interest"])
        + 0.30 * norm(regional_engine["Theme Coverage"])
        + 0.20 * norm(regional_engine["High Interest Themes"])
    ).round(2)
    regional_engine = regional_engine.sort_values("Regional Score", ascending=False).reset_index(drop=True)
    regional_engine["Rank"] = regional_engine.index + 1
    regional_engine["Classification"] = regional_engine["Rank"].map(
        lambda rank: rank_class(rank, len(regional_engine), ["Priority State", "Growth State", "Monitor State", "Low Priority State"])
    )
    regional_engine = regional_engine.rename(columns={"state": "State"})[
        [
            "State",
            "Average Regional Interest",
            "Theme Coverage",
            "High Interest Themes",
            "Regional Score",
            "Rank",
            "Classification",
        ]
    ].round(2)

    portfolio = market.merge(opportunity, on="Search Theme", suffixes=("_Leadership", "_Opportunity"))
    portfolio = portfolio.rename(
        columns={
            "Classification_Leadership": "Leadership Classification",
            "Classification_Opportunity": "Opportunity Classification",
        }
    )
    portfolio["Portfolio Classification"] = portfolio.apply(classify_portfolio, axis=1)
    portfolio["Supporting Evidence"] = portfolio.apply(supporting_theme, axis=1)
    portfolio = portfolio[
        [
            "Search Theme",
            "Portfolio Classification",
            "Leadership Classification",
            "Opportunity Classification",
            "Leadership Score",
            "Opportunity Score",
            "Supporting Evidence",
        ]
    ].sort_values(["Portfolio Classification", "Opportunity Score"], ascending=[True, False])

    top_theme_by_state = (
        state_theme.sort_values(["state", "regional_interest_index"], ascending=[True, False])
        .groupby("state")
        .head(1)
        .rename(columns={"regional_interest_index": "Top Theme Interest", "search_term": "Top Theme"})
    )
    regional_growth = regional_engine.merge(top_theme_by_state[["state", "Top Theme", "Top Theme Interest"]], left_on="State", right_on="state").drop(columns=["state"])
    regional_growth["Priority Level"] = regional_growth["Classification"]
    regional_growth["Supporting Evidence"] = regional_growth.apply(
        lambda r: f"Regional score {r['Regional Score']:.1f}; average interest {r['Average Regional Interest']:.1f}; top theme {r['Top Theme']} ({r['Top Theme Interest']:.1f}).",
        axis=1,
    )
    regional_growth = regional_growth[["State", "Priority Level", "Top Theme", "Regional Score", "Supporting Evidence"]]

    ecosystem_intel = ecosystem.merge(market[["Search Theme", "Leadership Score"]], on="Search Theme")
    ecosystem_intel["Ecosystem Assessment"] = ecosystem_intel.apply(
        lambda r: "Disproportionate Ecosystem Strength"
        if r["Ecosystem Score"] > 70 and r["Leadership Score"] < 60
        else r["Classification"],
        axis=1,
    )
    ecosystem_intel["Supporting Evidence"] = ecosystem_intel.apply(
        lambda r: f"Ecosystem score {r['Ecosystem Score']:.1f}; {int(r['Related Query Count'])} related queries; rising share {r['Rising Query Percentage']:.1f}%.",
        axis=1,
    )
    ecosystem_intel = ecosystem_intel[["Search Theme", "Ecosystem Assessment", "Ecosystem Score", "Supporting Evidence"]]

    sustainability = market.merge(opportunity, on="Search Theme")
    sustainability["Pattern Type"] = sustainability.apply(classify_sustainability, axis=1)
    sustainability["Supporting Evidence"] = sustainability.apply(
        lambda r: f"Growth {r['Growth Indicator']:.1f}%; consistency {r['Consistency Score']:.1f}; volatility {r['Volatility Score']:.1f}; peak {r['Peak Interest']:.1f}.",
        axis=1,
    )
    sustainability = sustainability[["Search Theme", "Pattern Type", "Supporting Evidence"]]

    executive = pd.DataFrame(
        [
            ["Market Leadership", market.iloc[0]["Search Theme"], f"Highest leadership score at {market.iloc[0]['Leadership Score']:.1f}.", "Prioritize sustained visibility and competitive tracking."],
            ["Future Opportunity", opportunity.iloc[0]["Search Theme"], f"Highest opportunity score at {opportunity.iloc[0]['Opportunity Score']:.1f}.", "Evaluate as a near-term growth bet."],
            ["Search Ecosystem", ecosystem.iloc[0]["Search Theme"], f"Highest ecosystem score at {ecosystem.iloc[0]['Ecosystem Score']:.1f}.", "Use related-query behavior to expand content and campaign themes."],
            ["Regional Priority", regional_engine.iloc[0]["State"], f"Highest regional score at {regional_engine.iloc[0]['Regional Score']:.1f}.", "Prioritize state-level activation and deeper regional analysis."],
            ["Portfolio Action", portfolio[portfolio["Portfolio Classification"].isin(["Invest", "Defend"])].iloc[0]["Search Theme"], "Strong combined strategic signal.", "Include in executive recommendation pack."],
        ],
        columns=["Decision Area", "Top Recommendation", "Supporting Evidence", "Recommended Action"],
    )

    recommendation_pack = pd.DataFrame(
        [
            ["Insight", "The market is split between current leaders, emerging growth themes, strong ecosystems, and state-level concentration."],
            ["Supporting Evidence", f"Top leadership theme: {market.iloc[0]['Search Theme']}; top opportunity theme: {opportunity.iloc[0]['Search Theme']}; top state: {regional_engine.iloc[0]['State']}."],
            ["Recommendation", "Invest in themes that combine leadership and opportunity, watch high-growth themes without current scale, and prioritize top regional states."],
            ["Justification", "The recommendation combines current demand, trend momentum, ecosystem behavior, and regional concentration rather than relying on a single score."],
            ["Executive Outcome", "Leadership can allocate attention across invest, watch, defend, monitor, and avoid categories with traceable evidence."],
        ],
        columns=["Executive Summary Element", "Content"],
    )

    market_dash = create_dashboard_frame(market, "Leadership Score", "Classification", ["Average Interest", "Peak Interest"])
    opp_dash = create_dashboard_frame(opportunity, "Opportunity Score", "Classification", ["Growth Indicator", "Momentum Indicator"])
    eco_dash = create_dashboard_frame(ecosystem, "Ecosystem Score", "Classification", ["Related Query Count", "Rising Query Count"])
    reg_dash = create_dashboard_frame(regional_engine, "Regional Score", "Classification", ["Average Regional Interest", "Theme Coverage"])

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(OUTPUT, engine="openpyxl") as writer:
        write_df(writer, "Executive_Summary", executive)
        write_df(writer, "Stage2_Market_Leadership", market)
        write_df(writer, "Stage2_Emerging_Opportunity", opportunity)
        write_df(writer, "Stage2_Ecosystem_Strength", ecosystem)
        write_df(writer, "Stage2_Regional_Opportunity", regional_engine)
        write_df(writer, "Stage3_Investment_Portfolio", portfolio)
        write_df(writer, "Stage3_Regional_Growth", regional_growth)
        write_df(writer, "Stage3_Ecosystem_Intelligence", ecosystem_intel)
        write_df(writer, "Stage3_Trend_Sustainability", sustainability)
        write_df(writer, "Market_Leadership_Dashboard", market_dash)
        write_df(writer, "Emerging_Opportunity_Dashboard", opp_dash)
        write_df(writer, "Search_Ecosystem_Dashboard", eco_dash)
        write_df(writer, "Regional_Opportunity_Dashboard", reg_dash)
        write_df(writer, "Executive_Recommendation_Pack", recommendation_pack)
        write_df(writer, "Cleaned_Weekly_Trends", weekly)
        write_df(writer, "Cleaned_Regional_Interest", regional)
        write_df(writer, "Cleaned_Related_Queries", related.drop(columns=["growth_percent"]))
        write_df(writer, "Term_Reference", term_ref)
        pd.read_excel(SOURCE, sheet_name="Cleaning_Log").to_excel(writer, sheet_name="Stage1_Cleaning_Log", index=False)

    wb = style_workbook(OUTPUT)
    for name in [
        "Executive_Summary",
        "Stage2_Market_Leadership",
        "Stage2_Emerging_Opportunity",
        "Stage2_Ecosystem_Strength",
        "Stage2_Regional_Opportunity",
        "Stage3_Investment_Portfolio",
        "Stage3_Regional_Growth",
        "Stage3_Ecosystem_Intelligence",
        "Stage3_Trend_Sustainability",
        "Executive_Recommendation_Pack",
    ]:
        add_title(wb[name], name.replace("_", " "), BRAND)

    add_dashboard_charts(wb)
    wb.save(OUTPUT)
    print(OUTPUT.resolve())


if __name__ == "__main__":
    main()
