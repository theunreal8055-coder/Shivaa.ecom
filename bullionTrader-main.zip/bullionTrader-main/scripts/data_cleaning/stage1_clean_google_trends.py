from pathlib import Path
import re

import pandas as pd


SOURCE = Path("/Users/tanishqtamarkar/Downloads/datascience /Google_Trends_Dataset.xlsx")
OUTPUT = Path("outputs/Google_Trends_Dataset_Stage1_Cleaned.xlsx")


VALID_STATES = {
    "andhra pradesh": "Andhra Pradesh",
    "arunachal pradesh": "Arunachal Pradesh",
    "assam": "Assam",
    "bihar": "Bihar",
    "chhattisgarh": "Chhattisgarh",
    "delhi": "Delhi",
    "goa": "Goa",
    "gujarat": "Gujarat",
    "haryana": "Haryana",
    "himachal pradesh": "Himachal Pradesh",
    "jharkhand": "Jharkhand",
    "karnataka": "Karnataka",
    "kerala": "Kerala",
    "madhya pradesh": "Madhya Pradesh",
    "maharashtra": "Maharashtra",
    "manipur": "Manipur",
    "meghalaya": "Meghalaya",
    "mizoram": "Mizoram",
    "nagaland": "Nagaland",
    "odisha": "Odisha",
    "punjab": "Punjab",
    "rajasthan": "Rajasthan",
    "sikkim": "Sikkim",
    "tamil nadu": "Tamil Nadu",
    "tamilnadu": "Tamil Nadu",
    "telangana": "Telangana",
    "tripura": "Tripura",
    "uttar pradesh": "Uttar Pradesh",
    "uttarakhand": "Uttarakhand",
    "west bengal": "West Bengal",
    "andaman and nicobar islands": "Andaman and Nicobar Islands",
    "chandigarh": "Chandigarh",
    "dadra and nagar haveli and daman and diu": "Dadra and Nagar Haveli and Daman and Diu",
    "jammu and kashmir": "Jammu and Kashmir",
    "ladakh": "Ladakh",
    "lakshadweep": "Lakshadweep",
    "puducherry": "Puducherry",
}


def key(value):
    text = "" if pd.isna(value) else str(value)
    text = re.sub(r"[^a-z0-9]+", " ", text.casefold())
    return re.sub(r"\s+", " ", text).strip()


def clean_text(value):
    if pd.isna(value):
        return value
    return re.sub(r"\s+", " ", str(value).strip())


def build_lookup(values):
    return {key(value): clean_text(value) for value in values}


def canonicalize(series, lookup, fallback_title=False):
    cleaned = series.map(clean_text)
    result = cleaned.map(lambda value: lookup.get(key(value), value))
    if fallback_title:
        result = result.map(lambda value: value.title() if isinstance(value, str) else value)
    return result


def cap_0_100(series):
    return pd.to_numeric(series, errors="coerce").clip(lower=0, upper=100)


def parse_week_date(row):
    value = row["week_start_date"]
    if pd.isna(value):
        return pd.NaT
    text = str(value).strip()
    candidates = []
    if "-" in text:
        candidates.append(pd.to_datetime(text, dayfirst=True, errors="coerce"))
    else:
        candidates.extend(
            [
                pd.to_datetime(text, format="%Y/%m/%d", errors="coerce"),
                pd.to_datetime(text, format="%m/%d/%Y", errors="coerce"),
                pd.to_datetime(text, format="%d/%m/%Y", errors="coerce"),
            ]
        )

    expected_year = row.get("year")
    expected_month = row.get("month")
    for candidate in candidates:
        if (
            not pd.isna(candidate)
            and candidate.year == expected_year
            and candidate.month == expected_month
        ):
            return candidate
    for candidate in candidates:
        if not pd.isna(candidate):
            return candidate
    return pd.NaT


def impute_weekly_interest(df):
    before_missing = int(df["search_interest_index"].isna().sum())
    term_month_median = df.groupby(["search_term", "month"])["search_interest_index"].transform("median")
    term_median = df.groupby("search_term")["search_interest_index"].transform("median")
    overall_median = df["search_interest_index"].median()
    df["search_interest_index"] = (
        df["search_interest_index"]
        .fillna(term_month_median)
        .fillna(term_median)
        .fillna(overall_median)
        .round(2)
    )
    return before_missing


def validation_summary(sheets):
    rows = []
    for sheet_name, df in sheets.items():
        rows.append(
            {
                "sheet": sheet_name,
                "rows": len(df),
                "columns": len(df.columns),
                "missing_cells": int(df.isna().sum().sum()),
                "exact_duplicate_rows": int(df.duplicated().sum()),
            }
        )

    weekly = sheets["Weekly_Search_Trends"]
    rows.append(
        {
            "sheet": "Weekly_Search_Trends",
            "rows": "check",
            "columns": "search_interest_index",
            "missing_cells": int(weekly["search_interest_index"].isna().sum()),
            "exact_duplicate_rows": int(((weekly["search_interest_index"] < 0) | (weekly["search_interest_index"] > 100)).sum()),
        }
    )

    regional = sheets["Regional_Interest"]
    rows.append(
        {
            "sheet": "Regional_Interest",
            "rows": "check",
            "columns": "regional_interest_index",
            "missing_cells": int(regional["regional_interest_index"].isna().sum()),
            "exact_duplicate_rows": int(((regional["regional_interest_index"] < 0) | (regional["regional_interest_index"] > 100)).sum()),
        }
    )

    related = sheets["Related_Queries"]
    top = related["query_type"].eq("Top")
    rows.append(
        {
            "sheet": "Related_Queries",
            "rows": "check",
            "columns": "Top relevance_score",
            "missing_cells": int(related.loc[top, "relevance_score"].isna().sum()),
            "exact_duplicate_rows": int(((related.loc[top, "relevance_score"] < 0) | (related.loc[top, "relevance_score"] > 100)).sum()),
        }
    )
    return pd.DataFrame(rows)


def main():
    xl = pd.ExcelFile(SOURCE)
    raw = {sheet: pd.read_excel(SOURCE, sheet_name=sheet) for sheet in xl.sheet_names}
    log = []

    term_ref = raw["Term_Reference"].copy()
    term_ref = term_ref.apply(lambda col: col.map(clean_text) if col.dtype == "object" else col)
    term_lookup = build_lookup(term_ref["search_term"])
    category_lookup = build_lookup(term_ref["category"])
    category_lookup["educaton"] = "Education"

    weekly = raw["Weekly_Search_Trends"].copy()
    weekly_rows_before = len(weekly)
    weekly["search_term"] = canonicalize(weekly["search_term"], term_lookup)
    weekly["category"] = canonicalize(weekly["category"], category_lookup)
    weekly["week_start_date"] = weekly.apply(parse_week_date, axis=1)
    invalid_dates = int(weekly["week_start_date"].isna().sum())
    weekly["search_interest_index"] = cap_0_100(weekly["search_interest_index"])
    weekly_missing_imputed = impute_weekly_interest(weekly)
    weekly["year"] = weekly["week_start_date"].dt.year.astype("Int64")
    weekly["month"] = weekly["week_start_date"].dt.month.astype("Int64")
    weekly = weekly.dropna(subset=["week_start_date", "search_term"])
    weekly = (
        weekly.groupby(["week_start_date", "search_term"], as_index=False)
        .agg(
            category=("category", "first"),
            search_interest_index=("search_interest_index", "mean"),
            year=("year", "first"),
            month=("month", "first"),
        )
        .sort_values(["search_term", "week_start_date"])
    )
    weekly["search_interest_index"] = weekly["search_interest_index"].round(2)
    weekly["week_start_date"] = weekly["week_start_date"].dt.strftime("%Y-%m-%d")
    log.append(["Weekly_Search_Trends", "Standardized search terms and categories from Term_Reference."])
    log.append(["Weekly_Search_Trends", f"Parsed week_start_date to YYYY-MM-DD; invalid dates removed: {invalid_dates}."])
    log.append(["Weekly_Search_Trends", f"Imputed missing search_interest_index values: {weekly_missing_imputed}."])
    log.append(["Weekly_Search_Trends", "Capped search_interest_index to the valid 0-100 Google Trends range."])
    log.append(["Weekly_Search_Trends", f"Removed/merged duplicate business keys; rows before: {weekly_rows_before}, rows after: {len(weekly)}."])

    regional = raw["Regional_Interest"].copy()
    regional_rows_before = len(regional)
    regional["search_term"] = canonicalize(regional["search_term"], term_lookup)
    regional["state"] = regional["state"].map(lambda value: VALID_STATES.get(key(value), clean_text(value)))
    regional["regional_interest_index"] = cap_0_100(regional["regional_interest_index"]).round(0).astype("Int64")
    regional = (
        regional.groupby(["search_term", "state", "year", "month"], as_index=False)
        .agg(regional_interest_index=("regional_interest_index", "mean"))
        .sort_values(["search_term", "state", "year", "month"])
    )
    regional["regional_interest_index"] = regional["regional_interest_index"].round(0).astype("Int64")
    log.append(["Regional_Interest", "Standardized search terms from Term_Reference."])
    log.append(["Regional_Interest", "Standardized state casing and Tamil Nadu naming."])
    log.append(["Regional_Interest", "Capped regional_interest_index to the valid 0-100 Google Trends range."])
    log.append(["Regional_Interest", f"Merged duplicate keys after state/name standardization; rows before: {regional_rows_before}, rows after: {len(regional)}."])

    related = raw["Related_Queries"].copy()
    related_rows_before = len(related)
    related["search_term"] = canonicalize(related["search_term"], term_lookup)
    related["related_query"] = related["related_query"].map(clean_text).str.casefold()
    related["query_type"] = related["query_type"].map(lambda value: "Rising" if key(value) == "rising" else "Top")
    related["relevance_score"] = pd.to_numeric(related["relevance_score"], errors="coerce")
    top_mask = related["query_type"].eq("Top")
    related.loc[top_mask, "relevance_score"] = cap_0_100(related.loc[top_mask, "relevance_score"]).round(2)
    related.loc[~top_mask, "relevance_score"] = pd.NA
    related["growth_indicator"] = related["growth_indicator"].map(clean_text)
    related = related.drop_duplicates().sort_values(["search_term", "query_type", "related_query"])
    log.append(["Related_Queries", "Standardized query_type to Top/Rising."])
    log.append(["Related_Queries", "Capped Top relevance_score to 0-100; Rising relevance_score left blank because growth_indicator carries the signal."])
    log.append(["Related_Queries", "Standardized related_query text to lowercase and trimmed whitespace."])
    log.append(["Related_Queries", f"Removed exact duplicates; rows before: {related_rows_before}, rows after: {len(related)}."])

    term_ref = term_ref.sort_values("search_term")
    log.append(["Term_Reference", "Retained as the master reference table after trimming text fields."])

    sheets = {
        "Weekly_Search_Trends": weekly,
        "Regional_Interest": regional,
        "Related_Queries": related,
        "Term_Reference": term_ref,
    }
    cleaning_log = pd.DataFrame(log, columns=["worksheet", "cleaning_action"])
    quality = validation_summary(sheets)

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(OUTPUT, engine="openpyxl") as writer:
        for sheet_name, df in sheets.items():
            df.to_excel(writer, sheet_name=sheet_name, index=False)
        cleaning_log.to_excel(writer, sheet_name="Cleaning_Log", index=False)
        quality.to_excel(writer, sheet_name="Quality_Checks", index=False)

        workbook = writer.book
        for ws in workbook.worksheets:
            ws.freeze_panes = "A2"
            ws.auto_filter.ref = ws.dimensions
            for column_cells in ws.columns:
                max_len = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
                ws.column_dimensions[column_cells[0].column_letter].width = min(max(max_len + 2, 12), 45)

    print(OUTPUT.resolve())


if __name__ == "__main__":
    main()
