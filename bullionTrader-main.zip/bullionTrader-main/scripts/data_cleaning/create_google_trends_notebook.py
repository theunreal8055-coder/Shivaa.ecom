from pathlib import Path
import json
import textwrap

import pandas as pd


FINAL_WORKBOOK = Path("outputs/Google_Trends_Final_Intelligence_Workbook.xlsx")
NOTEBOOK = Path("outputs/Google_Trends_Full_Implementation_Notebook.ipynb")


def md(source):
    return {
        "cell_type": "markdown",
        "metadata": {},
        "source": textwrap.dedent(source).strip().splitlines(True),
    }


def code(source):
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": textwrap.dedent(source).strip().splitlines(True),
    }


def bar_svg(df, label_col, value_col, title, color="#1f77b4", width=880, height=430):
    data = df[[label_col, value_col]].head(10).copy()
    data[value_col] = pd.to_numeric(data[value_col], errors="coerce").fillna(0)
    max_value = max(float(data[value_col].max()), 1)
    margin_left, margin_right, margin_top, margin_bottom = 190, 40, 56, 46
    plot_w = width - margin_left - margin_right
    row_h = (height - margin_top - margin_bottom) / len(data)
    lines = [
        f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        f'<text x="{width/2}" y="28" text-anchor="middle" font-size="20" font-family="Arial" font-weight="700" fill="#1F4E78">{title}</text>',
    ]
    for i, row in data.reset_index(drop=True).iterrows():
        y = margin_top + i * row_h + 5
        bar_w = float(row[value_col]) / max_value * plot_w
        label = str(row[label_col]).replace("&", "&amp;")
        value = float(row[value_col])
        lines.extend(
            [
                f'<text x="{margin_left-10}" y="{y+row_h*0.58:.1f}" text-anchor="end" font-size="13" font-family="Arial" fill="#333">{label}</text>',
                f'<rect x="{margin_left}" y="{y}" width="{bar_w:.1f}" height="{row_h-10:.1f}" rx="3" fill="{color}"/>',
                f'<text x="{margin_left+bar_w+7:.1f}" y="{y+row_h*0.58:.1f}" font-size="12" font-family="Arial" fill="#333">{value:.1f}</text>',
            ]
        )
    lines.append("</svg>")
    return "\n".join(lines)


def pie_svg(df, label_col, value_col, title, width=760, height=430):
    # A compact donut-style proportional bar works more reliably in Markdown
    # renderers than hand-authored pie paths, while still communicating share.
    data = df[[label_col, value_col]].copy()
    total = max(float(pd.to_numeric(data[value_col], errors="coerce").fillna(0).sum()), 1)
    palette = ["#1F4E78", "#70AD47", "#FFC000", "#C00000", "#7030A0", "#5B9BD5"]
    x, y, bar_w, bar_h = 70, 120, width - 140, 42
    cursor = x
    lines = [
        f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">',
        '<rect width="100%" height="100%" fill="#ffffff"/>',
        f'<text x="{width/2}" y="34" text-anchor="middle" font-size="20" font-family="Arial" font-weight="700" fill="#1F4E78">{title}</text>',
    ]
    for i, row in data.reset_index(drop=True).iterrows():
        value = float(row[value_col])
        segment_w = value / total * bar_w
        color = palette[i % len(palette)]
        lines.append(f'<rect x="{cursor:.1f}" y="{y}" width="{segment_w:.1f}" height="{bar_h}" fill="{color}"/>')
        cursor += segment_w
    lines.append(f'<rect x="{x}" y="{y}" width="{bar_w}" height="{bar_h}" fill="none" stroke="#555" stroke-width="1"/>')
    legend_y = y + 80
    for i, row in data.reset_index(drop=True).iterrows():
        lx = x + (i % 2) * 330
        ly = legend_y + (i // 2) * 32
        color = palette[i % len(palette)]
        label = str(row[label_col]).replace("&", "&amp;")
        value = float(row[value_col])
        pct = value / total * 100
        lines.extend(
            [
                f'<rect x="{lx}" y="{ly-13}" width="16" height="16" fill="{color}"/>',
                f'<text x="{lx+24}" y="{ly}" font-size="13" font-family="Arial" fill="#333">{label}: {int(value)} ({pct:.1f}%)</text>',
            ]
        )
    lines.append("</svg>")
    return "\n".join(lines)


def table_md(df, title):
    return f"### {title}\n\n" + df.to_markdown(index=False)


def load_preview_frames():
    market = pd.read_excel(FINAL_WORKBOOK, sheet_name="Stage2_Market_Leadership", skiprows=3)
    opportunity = pd.read_excel(FINAL_WORKBOOK, sheet_name="Stage2_Emerging_Opportunity", skiprows=3)
    ecosystem = pd.read_excel(FINAL_WORKBOOK, sheet_name="Stage2_Ecosystem_Strength", skiprows=3)
    regional = pd.read_excel(FINAL_WORKBOOK, sheet_name="Stage2_Regional_Opportunity", skiprows=3)
    portfolio = pd.read_excel(FINAL_WORKBOOK, sheet_name="Stage3_Investment_Portfolio", skiprows=3)
    executive = pd.read_excel(FINAL_WORKBOOK, sheet_name="Executive_Summary", skiprows=3)
    return market, opportunity, ecosystem, regional, portfolio, executive


def main():
    market, opportunity, ecosystem, regional, portfolio, executive = load_preview_frames()

    cells = [
        md(
            """
            # Google Trends Market Intelligence: Full Python Implementation

            This notebook completes all four stages of the Google Trends Data Intelligence Hackathon:

            1. **Stage 1: Data Cleaning** - standardize raw worksheets and build a trusted dataset.
            2. **Stage 2: Metric Engineering** - create market, opportunity, ecosystem, and regional scoring engines.
            3. **Stage 3: Pivot Intelligence** - convert metric outputs into strategy tables.
            4. **Stage 4: Visual Intelligence** - build charts and executive recommendations.

            The notebook is designed to run from the workspace folder:
            `/Users/tanishqtamarkar/Downloads/bullionTrader`
            """
        ),
        md(
            """
            ## Setup

            The implementation uses only common Python data tools:
            `pandas`, `numpy`, and `openpyxl`.

            Chart sections use simple SVG/HTML rendering so the notebook remains portable even if `matplotlib` or `seaborn` are not installed.
            """
        ),
        code(
            r"""
            from pathlib import Path
            import math
            import re

            import numpy as np
            import pandas as pd
            from openpyxl import load_workbook
            from openpyxl.chart import BarChart, PieChart, Reference
            from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
            from openpyxl.utils import get_column_letter

            try:
                from IPython.display import HTML, display
            except Exception:
                HTML = None
                display = print

            RAW_FILE = Path("/Users/tanishqtamarkar/Downloads/datascience /Google_Trends_Dataset.xlsx")
            CLEANED_FILE = Path("outputs/Google_Trends_Dataset_Stage1_Cleaned_From_Notebook.xlsx")
            FINAL_FILE = Path("outputs/Google_Trends_Final_Intelligence_From_Notebook.xlsx")

            RAW_FILE.exists(), RAW_FILE
            """
        ),
        md("## Helper Functions"),
        code(
            r"""
            def key(value):
                text = "" if pd.isna(value) else str(value)
                text = re.sub(r"[^a-z0-9]+", " ", text.casefold())
                return re.sub(r"\s+", " ", text).strip()

            def clean_text(value):
                if pd.isna(value):
                    return value
                return re.sub(r"\s+", " ", str(value).strip())

            def build_lookup(values):
                return {key(value): clean_text(value) for value in values}

            def canonicalize(series, lookup):
                cleaned = series.map(clean_text)
                return cleaned.map(lambda value: lookup.get(key(value), value))

            def cap_0_100(series):
                return pd.to_numeric(series, errors="coerce").clip(lower=0, upper=100)

            def norm(series, invert=False):
                series = pd.to_numeric(series, errors="coerce").fillna(0)
                low, high = series.min(), series.max()
                out = pd.Series(100, index=series.index, dtype=float) if math.isclose(float(high), float(low)) else (series - low) / (high - low) * 100
                return (100 - out if invert else out).clip(0, 100)

            def rank_class(rank, total, labels):
                pct = rank / total
                if pct <= 0.20:
                    return labels[0]
                if pct <= 0.40:
                    return labels[1]
                if pct <= 0.72:
                    return labels[2]
                return labels[3]

            def parse_week_date(row):
                value = row["week_start_date"]
                if pd.isna(value):
                    return pd.NaT
                text = str(value).strip()
                candidates = []
                if "-" in text:
                    candidates.append(pd.to_datetime(text, dayfirst=True, errors="coerce"))
                else:
                    candidates.extend([
                        pd.to_datetime(text, format="%Y/%m/%d", errors="coerce"),
                        pd.to_datetime(text, format="%m/%d/%Y", errors="coerce"),
                        pd.to_datetime(text, format="%d/%m/%Y", errors="coerce"),
                    ])
                for candidate in candidates:
                    if not pd.isna(candidate) and candidate.year == row["year"] and candidate.month == row["month"]:
                        return candidate
                return next((candidate for candidate in candidates if not pd.isna(candidate)), pd.NaT)

            def clean_percent(value):
                if pd.isna(value):
                    return 0.0
                text = str(value).strip()
                if text == "Breakout":
                    return 5000.0
                if text == "Stable":
                    return 0.0
                return float(text.replace("+", "").replace("%", "") or 0)
            """
        ),
        md("## Stage 1: Data Cleaning"),
        code(
            r"""
            raw = {sheet: pd.read_excel(RAW_FILE, sheet_name=sheet) for sheet in pd.ExcelFile(RAW_FILE).sheet_names}
            weekly = raw["Weekly_Search_Trends"].copy()
            regional = raw["Regional_Interest"].copy()
            related = raw["Related_Queries"].copy()
            term_ref = raw["Term_Reference"].copy()

            term_ref = term_ref.apply(lambda col: col.map(clean_text) if col.dtype == "object" else col)
            term_lookup = build_lookup(term_ref["search_term"])
            category_lookup = build_lookup(term_ref["category"])
            category_lookup["educaton"] = "Education"

            valid_states = {
                "bihar": "Bihar", "delhi": "Delhi", "karnataka": "Karnataka", "maharashtra": "Maharashtra",
                "tamilnadu": "Tamil Nadu", "tamil nadu": "Tamil Nadu", "telangana": "Telangana",
            }

            weekly["search_term"] = canonicalize(weekly["search_term"], term_lookup)
            weekly["category"] = canonicalize(weekly["category"], category_lookup)
            weekly["week_start_date"] = weekly.apply(parse_week_date, axis=1)
            weekly["search_interest_index"] = cap_0_100(weekly["search_interest_index"])
            term_month_median = weekly.groupby(["search_term", "month"])["search_interest_index"].transform("median")
            term_median = weekly.groupby("search_term")["search_interest_index"].transform("median")
            weekly["search_interest_index"] = weekly["search_interest_index"].fillna(term_month_median).fillna(term_median).fillna(weekly["search_interest_index"].median()).round(2)
            weekly["year"] = weekly["week_start_date"].dt.year.astype("Int64")
            weekly["month"] = weekly["week_start_date"].dt.month.astype("Int64")
            weekly = weekly.dropna(subset=["week_start_date", "search_term"])
            weekly = weekly.groupby(["week_start_date", "search_term"], as_index=False).agg(
                category=("category", "first"),
                search_interest_index=("search_interest_index", "mean"),
                year=("year", "first"),
                month=("month", "first"),
            ).sort_values(["search_term", "week_start_date"])
            weekly["search_interest_index"] = weekly["search_interest_index"].round(2)

            regional["search_term"] = canonicalize(regional["search_term"], term_lookup)
            regional["state"] = regional["state"].map(lambda value: valid_states.get(key(value), clean_text(value).title()))
            regional["regional_interest_index"] = cap_0_100(regional["regional_interest_index"]).round(0).astype("Int64")
            regional = regional.groupby(["search_term", "state", "year", "month"], as_index=False).agg(
                regional_interest_index=("regional_interest_index", "mean")
            )
            regional["regional_interest_index"] = regional["regional_interest_index"].round(0).astype("Int64")

            related["search_term"] = canonicalize(related["search_term"], term_lookup)
            related["related_query"] = related["related_query"].map(clean_text).str.casefold()
            related["query_type"] = related["query_type"].map(lambda value: "Rising" if key(value) == "rising" else "Top")
            related["relevance_score"] = pd.to_numeric(related["relevance_score"], errors="coerce")
            top_mask = related["query_type"].eq("Top")
            related.loc[top_mask, "relevance_score"] = cap_0_100(related.loc[top_mask, "relevance_score"]).round(2)
            related.loc[~top_mask, "relevance_score"] = pd.NA
            related["growth_indicator"] = related["growth_indicator"].map(clean_text)
            related = related.drop_duplicates()

            cleaning_summary = pd.DataFrame([
                ["Weekly_Search_Trends", len(weekly), weekly.duplicated().sum(), weekly.isna().sum().sum()],
                ["Regional_Interest", len(regional), regional.duplicated().sum(), regional.isna().sum().sum()],
                ["Related_Queries", len(related), related.duplicated().sum(), related.isna().sum().sum()],
                ["Term_Reference", len(term_ref), term_ref.duplicated().sum(), term_ref.isna().sum().sum()],
            ], columns=["Worksheet", "Rows", "Duplicate Rows", "Missing Cells"])

            cleaning_summary
            """
        ),
        md("## Stage 2: Metric Engineering"),
        code(
            r"""
            weekly["week_start_date"] = pd.to_datetime(weekly["week_start_date"])
            latest_date = weekly["week_start_date"].max()
            current_start = latest_date - pd.Timedelta(weeks=12)
            previous_start = latest_date - pd.Timedelta(weeks=24)
            first_end = weekly["week_start_date"].min() + pd.Timedelta(weeks=12)

            def slope_for_group(df):
                ordered = df.sort_values("week_start_date")
                y = ordered["search_interest_index"].astype(float).to_numpy()
                if len(y) < 2:
                    return 0.0
                return float(np.polyfit(np.arange(len(y)), y, 1)[0])

            market = weekly.groupby("search_term").agg(
                **{
                    "Average Interest": ("search_interest_index", "mean"),
                    "Peak Interest": ("search_interest_index", "max"),
                    "Volatility Score": ("search_interest_index", "std"),
                }
            ).reset_index()
            market["Volatility Score"] = market["Volatility Score"].fillna(0).round(2)
            market["Consistency Score"] = (100 - norm(market["Volatility Score"])).round(2)
            market["Leadership Score"] = (0.40*norm(market["Average Interest"]) + 0.25*norm(market["Peak Interest"]) + 0.25*market["Consistency Score"] + 0.10*norm(market["Volatility Score"], invert=True)).round(2)
            market = market.sort_values("Leadership Score", ascending=False).reset_index(drop=True)
            market["Rank"] = market.index + 1
            market["Classification"] = market["Rank"].map(lambda r: rank_class(r, len(market), ["Market Leader", "Strong Performer", "Average Performer", "Weak Performer"]))
            market = market.rename(columns={"search_term": "Search Theme"})

            first = weekly[weekly["week_start_date"] <= first_end].groupby("search_term")["search_interest_index"].mean()
            previous = weekly[(weekly["week_start_date"] > previous_start) & (weekly["week_start_date"] <= current_start)].groupby("search_term")["search_interest_index"].mean()
            current = weekly[weekly["week_start_date"] > current_start].groupby("search_term")["search_interest_index"].mean()
            slopes = weekly.groupby("search_term").apply(slope_for_group, include_groups=False)

            opportunity = pd.DataFrame({"search_term": sorted(weekly["search_term"].unique())})
            opportunity["Current Interest"] = opportunity["search_term"].map(current).fillna(0)
            opportunity["First Period Interest"] = opportunity["search_term"].map(first).fillna(0)
            opportunity["Previous Interest"] = opportunity["search_term"].map(previous).fillna(0)
            opportunity["Growth Indicator"] = np.where(opportunity["First Period Interest"] > 0, (opportunity["Current Interest"] - opportunity["First Period Interest"]) / opportunity["First Period Interest"] * 100, 0)
            opportunity["Momentum Indicator"] = opportunity["Current Interest"] - opportunity["Previous Interest"]
            opportunity["Trend Score"] = opportunity["search_term"].map(slopes).fillna(0)
            opportunity["Opportunity Score"] = (0.25*norm(opportunity["Current Interest"]) + 0.30*norm(opportunity["Growth Indicator"]) + 0.25*norm(opportunity["Momentum Indicator"]) + 0.20*norm(opportunity["Trend Score"])).round(2)
            opportunity = opportunity.sort_values("Opportunity Score", ascending=False).reset_index(drop=True)
            opportunity["Rank"] = opportunity.index + 1
            opportunity["Classification"] = opportunity["Rank"].map(lambda r: rank_class(r, len(opportunity), ["Breakout Opportunity", "Emerging Theme", "Watchlist Theme", "Low Potential Theme"]))
            opportunity = opportunity.rename(columns={"search_term": "Search Theme"})

            related["growth_percent"] = related["growth_indicator"].map(clean_percent)
            ecosystem = related.groupby("search_term").agg(
                **{
                    "Related Query Count": ("related_query", "nunique"),
                    "Average Relevance Score": ("relevance_score", "mean"),
                    "Rising Query Count": ("query_type", lambda s: int((s == "Rising").sum())),
                    "Average Rising Growth %": ("growth_percent", "mean"),
                }
            ).reset_index()
            ecosystem["Average Relevance Score"] = ecosystem["Average Relevance Score"].fillna(0)
            ecosystem["Rising Query Percentage"] = ecosystem["Rising Query Count"] / ecosystem["Related Query Count"] * 100
            ecosystem["Ecosystem Score"] = (0.25*norm(ecosystem["Related Query Count"]) + 0.30*norm(ecosystem["Average Relevance Score"]) + 0.25*norm(ecosystem["Rising Query Percentage"]) + 0.20*norm(ecosystem["Average Rising Growth %"])).round(2)
            ecosystem = ecosystem.sort_values("Ecosystem Score", ascending=False).reset_index(drop=True)
            ecosystem["Rank"] = ecosystem.index + 1
            ecosystem["Classification"] = ecosystem["Rank"].map(lambda r: rank_class(r, len(ecosystem), ["Ecosystem Leader", "Strong Ecosystem", "Moderate Ecosystem", "Weak Ecosystem"]))
            ecosystem = ecosystem.rename(columns={"search_term": "Search Theme"})

            state_theme = regional.groupby(["state", "search_term"])["regional_interest_index"].mean().reset_index()
            regional_engine = regional.groupby("state").agg(
                **{"Average Regional Interest": ("regional_interest_index", "mean"), "Theme Coverage": ("search_term", "nunique")}
            ).reset_index()
            high_counts = state_theme[state_theme["regional_interest_index"] >= 60].groupby("state")["search_term"].nunique()
            regional_engine["High Interest Themes"] = regional_engine["state"].map(high_counts).fillna(0).astype(int)
            regional_engine["Regional Score"] = (0.50*norm(regional_engine["Average Regional Interest"]) + 0.30*norm(regional_engine["Theme Coverage"]) + 0.20*norm(regional_engine["High Interest Themes"])).round(2)
            regional_engine = regional_engine.sort_values("Regional Score", ascending=False).reset_index(drop=True)
            regional_engine["Rank"] = regional_engine.index + 1
            regional_engine["Classification"] = regional_engine["Rank"].map(lambda r: rank_class(r, len(regional_engine), ["Priority State", "Growth State", "Monitor State", "Low Priority State"]))
            regional_engine = regional_engine.rename(columns={"state": "State"})

            market.head(), opportunity.head(), ecosystem.head(), regional_engine.head()
            """
        ),
        md(table_md(market.head(8), "Preview: Market Leadership Engine")),
        md(bar_svg(market, "Search Theme", "Leadership Score", "Top Market Leadership Scores", "#1F4E78")),
        md(table_md(opportunity.head(8), "Preview: Emerging Opportunity Engine")),
        md(bar_svg(opportunity, "Search Theme", "Opportunity Score", "Top Emerging Opportunity Scores", "#70AD47")),
        md(table_md(ecosystem.head(8), "Preview: Ecosystem Strength Engine")),
        md(bar_svg(ecosystem, "Search Theme", "Ecosystem Score", "Top Search Ecosystem Scores", "#7030A0")),
        md(table_md(regional.head(8), "Preview: Regional Opportunity Engine")),
        md(bar_svg(regional, "State", "Regional Score", "Top Regional Opportunity Scores", "#C00000")),
        md("## Stage 3: Pivot Intelligence / Strategy Tables"),
        code(
            r"""
            def classify_portfolio(row):
                leadership = row["Leadership Classification"]
                opportunity_class = row["Opportunity Classification"]
                if leadership in {"Market Leader", "Strong Performer"} and opportunity_class in {"Breakout Opportunity", "Emerging Theme"}:
                    return "Invest"
                if opportunity_class in {"Breakout Opportunity", "Emerging Theme"}:
                    return "Watch"
                if leadership in {"Market Leader", "Strong Performer"}:
                    return "Defend"
                if leadership == "Weak Performer" and opportunity_class == "Low Potential Theme":
                    return "Avoid"
                return "Monitor"

            portfolio = market.merge(opportunity, on="Search Theme", suffixes=("_Leadership", "_Opportunity"))
            portfolio = portfolio.rename(columns={"Classification_Leadership": "Leadership Classification", "Classification_Opportunity": "Opportunity Classification"})
            portfolio["Portfolio Classification"] = portfolio.apply(classify_portfolio, axis=1)
            portfolio["Supporting Evidence"] = portfolio.apply(
                lambda r: f"Leadership {r['Leadership Score']:.1f}; opportunity {r['Opportunity Score']:.1f}; current interest {r['Current Interest']:.1f}; growth {r['Growth Indicator']:.1f}%.",
                axis=1,
            )

            regional_growth = regional_engine.copy()
            top_theme_by_state = state_theme.sort_values(["state", "regional_interest_index"], ascending=[True, False]).groupby("state").head(1)
            regional_growth = regional_growth.merge(top_theme_by_state[["state", "search_term", "regional_interest_index"]], left_on="State", right_on="state")
            regional_growth["Supporting Evidence"] = regional_growth.apply(
                lambda r: f"Regional score {r['Regional Score']:.1f}; average interest {r['Average Regional Interest']:.1f}; top theme {r['search_term']} ({r['regional_interest_index']:.1f}).",
                axis=1,
            )

            portfolio[["Search Theme", "Portfolio Classification", "Leadership Classification", "Opportunity Classification", "Supporting Evidence"]].head(10)
            """
        ),
        md(table_md(portfolio.head(10), "Preview: Investment Portfolio Strategy")),
        md(pie_svg(portfolio["Portfolio Classification"].value_counts().reset_index().rename(columns={"Portfolio Classification": "Classification", "count": "Count"}), "Classification", "Count", "Portfolio Classification Distribution")),
        md("## Stage 4: Visual Intelligence and Final Export"),
        code(
            r"""
            def write_outputs():
                with pd.ExcelWriter(FINAL_FILE, engine="openpyxl") as writer:
                    market.to_excel(writer, sheet_name="Stage2_Market_Leadership", index=False)
                    opportunity.to_excel(writer, sheet_name="Stage2_Emerging_Opportunity", index=False)
                    ecosystem.to_excel(writer, sheet_name="Stage2_Ecosystem_Strength", index=False)
                    regional_engine.to_excel(writer, sheet_name="Stage2_Regional_Opportunity", index=False)
                    portfolio.to_excel(writer, sheet_name="Stage3_Investment_Portfolio", index=False)
                    regional_growth.to_excel(writer, sheet_name="Stage3_Regional_Growth", index=False)
                    weekly.to_excel(writer, sheet_name="Cleaned_Weekly_Trends", index=False)
                    regional.to_excel(writer, sheet_name="Cleaned_Regional_Interest", index=False)
                    related.drop(columns=["growth_percent"]).to_excel(writer, sheet_name="Cleaned_Related_Queries", index=False)
                    term_ref.to_excel(writer, sheet_name="Term_Reference", index=False)
                    cleaning_summary.to_excel(writer, sheet_name="Cleaning_Summary", index=False)

                wb = load_workbook(FINAL_FILE)
                header_fill = PatternFill("solid", fgColor="1F4E78")
                white_font = Font(color="FFFFFF", bold=True)
                thin = Side(style="thin", color="D9D9D9")
                border = Border(left=thin, right=thin, top=thin, bottom=thin)
                for ws in wb.worksheets:
                    ws.freeze_panes = "A2"
                    ws.sheet_view.showGridLines = False
                    ws.auto_filter.ref = ws.dimensions
                    for cell in ws[1]:
                        cell.fill = header_fill
                        cell.font = white_font
                    for row in ws.iter_rows():
                        for cell in row:
                            cell.border = border
                            cell.alignment = Alignment(wrap_text=True, vertical="top")
                    for col_idx in range(1, ws.max_column + 1):
                        letter = get_column_letter(col_idx)
                        max_len = max(len(str(ws.cell(row=row, column=col_idx).value or "")) for row in range(1, min(ws.max_row, 120) + 1))
                        ws.column_dimensions[letter].width = min(max(max_len + 2, 12), 42)
                wb.save(FINAL_FILE)
                return FINAL_FILE

            write_outputs()
            """
        ),
        md(
            f"""
            ## Final Results

            - **Market Leader:** `{market.iloc[0]["Search Theme"]}` with leadership score `{market.iloc[0]["Leadership Score"]:.2f}`
            - **Top Emerging Opportunity:** `{opportunity.iloc[0]["Search Theme"]}` with opportunity score `{opportunity.iloc[0]["Opportunity Score"]:.2f}`
            - **Strongest Search Ecosystem:** `{ecosystem.iloc[0]["Search Theme"]}` with ecosystem score `{ecosystem.iloc[0]["Ecosystem Score"]:.2f}`
            - **Top Regional Opportunity:** `{regional.iloc[0]["State"]}` with regional score `{regional.iloc[0]["Regional Score"]:.2f}`

            When you run this notebook, it will create:

            `outputs/Google_Trends_Final_Intelligence_From_Notebook.xlsx`
            """
        ),
    ]

    notebook = {
        "cells": cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            },
            "language_info": {
                "name": "python",
                "version": "3.11",
                "mimetype": "text/x-python",
                "codemirror_mode": {"name": "ipython", "version": 3},
                "pygments_lexer": "ipython3",
                "nbconvert_exporter": "python",
                "file_extension": ".py",
            },
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }

    NOTEBOOK.parent.mkdir(parents=True, exist_ok=True)
    NOTEBOOK.write_text(json.dumps(notebook, indent=2), encoding="utf-8")
    print(NOTEBOOK.resolve())


if __name__ == "__main__":
    main()
