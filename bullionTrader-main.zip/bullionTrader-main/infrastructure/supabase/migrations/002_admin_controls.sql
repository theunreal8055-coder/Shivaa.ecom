-- 002_admin_controls.sql

-- 1. Create admin_audit_logs table
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    admin_email VARCHAR(255) NOT NULL,
    setting_key VARCHAR(50) NOT NULL,
    old_value NUMERIC(10,2),
    new_value NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable Row Level Security (RLS) on admin_audit_logs
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Add policies for admin_audit_logs
DROP POLICY IF EXISTS "Admins can view all audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can view all audit logs" ON public.admin_audit_logs 
    FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Admins can insert audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can insert audit logs" ON public.admin_audit_logs 
    FOR INSERT WITH CHECK (auth.uid() = admin_id);

-- 2. Seed default values in dealer_config if they do not exist
INSERT INTO public.dealer_config (key, value)
VALUES 
    ('gold_badla_markup', '150'::jsonb),
    ('silver_badla_markup', '250'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- 3. Enable realtime replication for dealer_config
-- PostgreSQL allows adding tables to publications to enable realtime change streams
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime'
    ) THEN
        -- Add dealer_config to realtime if not already added
        IF NOT EXISTS (
            SELECT 1 FROM pg_publication_tables 
            WHERE pubname = 'supabase_realtime' AND tablename = 'dealer_config'
        ) THEN
            ALTER PUBLICATION supabase_realtime ADD TABLE public.dealer_config;
        END IF;
    END IF;
END $$;
