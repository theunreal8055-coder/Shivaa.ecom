-- 003_schema_repair_and_sync.sql

-- 1. Repair profiles table to ensure 'role' exists
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'dealer'));

-- 2. Repair rate_history table to ensure 'base_mcx' exists
ALTER TABLE public.rate_history ADD COLUMN IF NOT EXISTS base_mcx DECIMAL(12,2);

-- 3. Ensure dealer_config exists
CREATE TABLE IF NOT EXISTS public.dealer_config (
  id SERIAL PRIMARY KEY,
  key TEXT UNIQUE NOT NULL,
  value JSONB NOT NULL,
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on dealer_config if not already enabled
ALTER TABLE public.dealer_config ENABLE ROW LEVEL SECURITY;

-- Add policies for dealer_config if not exists
DROP POLICY IF EXISTS "Dealer config is public" ON public.dealer_config;
CREATE POLICY "Dealer config is public" ON public.dealer_config FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can update dealer config" ON public.dealer_config;
CREATE POLICY "Admins can update dealer config" ON public.dealer_config FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- 4. Ensure admin_audit_logs exists
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    admin_email VARCHAR(255) NOT NULL,
    setting_key VARCHAR(50) NOT NULL,
    old_value NUMERIC(10,2),
    new_value NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS on admin_audit_logs
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Add policies for admin_audit_logs
DROP POLICY IF EXISTS "Admins can view all audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can view all audit logs" ON public.admin_audit_logs 
    FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Admins can insert audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can insert audit logs" ON public.admin_audit_logs 
    FOR INSERT WITH CHECK (auth.uid() = admin_id);

-- 5. Seed default markup values if missing
INSERT INTO public.dealer_config (key, value)
VALUES 
    ('gold_badla_markup', '150'::jsonb),
    ('silver_badla_markup', '250'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- 6. Enable realtime replication for tables
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime'
    ) THEN
        IF NOT EXISTS (
            SELECT 1 FROM pg_publication_tables 
            WHERE pubname = 'supabase_realtime' AND tablename = 'dealer_config'
        ) THEN
            ALTER PUBLICATION supabase_realtime ADD TABLE public.dealer_config;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM pg_publication_tables 
            WHERE pubname = 'supabase_realtime' AND tablename = 'admin_audit_logs'
        ) THEN
            ALTER PUBLICATION supabase_realtime ADD TABLE public.admin_audit_logs;
        END IF;
    END IF;
END $$;

-- 7. Force PostgREST schema cache reload
NOTIFY pgrst, 'reload schema';
