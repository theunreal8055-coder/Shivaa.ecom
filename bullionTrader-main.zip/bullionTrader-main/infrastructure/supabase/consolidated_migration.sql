-- ==========================================
-- CONSOLIDATED IDEMPOTENT DATABASE MIGRATION
-- BullionTrader (Laxmi Abhushan)
-- Run this in your Supabase SQL Editor
-- ==========================================

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Repair and ensure columns on profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID REFERENCES auth.users(id) ON DELETE CASCADE PRIMARY KEY,
  full_name TEXT,
  phone TEXT,
  phone_number TEXT,
  business_name TEXT,
  city TEXT DEFAULT 'Rajkot',
  role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'dealer')),
  fcm_token TEXT,
  preferences JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure all profiles columns exist
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS phone_number TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS business_name TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS city TEXT DEFAULT 'Rajkot';
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS role TEXT DEFAULT 'user' CHECK (role IN ('user', 'admin', 'dealer'));
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS fcm_token TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS preferences JSONB DEFAULT '{}'::jsonb;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 2. Repair and ensure columns on rate_history table
CREATE TABLE IF NOT EXISTS public.rate_history (
  id BIGSERIAL PRIMARY KEY,
  metal TEXT NOT NULL CHECK (metal IN ('GOLD', 'SILVER')),
  bid_price DECIMAL(12,2) NOT NULL,
  ask_price DECIMAL(12,2) NOT NULL,
  base_mcx DECIMAL(12,2),
  source TEXT DEFAULT 'simulator',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.rate_history ADD COLUMN IF NOT EXISTS base_mcx DECIMAL(12,2);
CREATE INDEX IF NOT EXISTS idx_rate_history_metal_created_at ON rate_history (metal, created_at DESC);


-- 4. Create Price Alerts Table
CREATE TABLE IF NOT EXISTS public.price_alerts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  metal TEXT NOT NULL CHECK (metal IN ('GOLD', 'SILVER')),
  commodity_name TEXT,
  target_price DECIMAL(12,2) NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('above', 'below')),
  is_active BOOLEAN DEFAULT true,
  is_triggered BOOLEAN DEFAULT false,
  triggered_at TIMESTAMPTZ,
  notification_sent BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_price_alerts_user_active ON price_alerts (user_id, is_active);
CREATE INDEX IF NOT EXISTS idx_price_alerts_evaluation ON price_alerts (metal, is_active, is_triggered);

-- 5. Create Market News Table
CREATE TABLE IF NOT EXISTS public.market_news (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  summary TEXT,
  content TEXT,
  source TEXT,
  category TEXT DEFAULT 'market',
  image_url TEXT,
  is_published BOOLEAN DEFAULT true,
  published_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 6. Create Dealer Config Table
CREATE TABLE IF NOT EXISTS public.dealer_config (
  id SERIAL PRIMARY KEY,
  key TEXT UNIQUE NOT NULL,
  value JSONB NOT NULL,
  updated_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_dealer_config_key ON dealer_config (key);

-- 7. Create Admin Audit Logs Table
CREATE TABLE IF NOT EXISTS public.admin_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    admin_email VARCHAR(255) NOT NULL,
    setting_key VARCHAR(50) NOT NULL,
    old_value NUMERIC(10,2),
    new_value NUMERIC(10,2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES SETUP
-- ==========================================

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rate_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.price_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.market_news ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dealer_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_logs ENABLE ROW LEVEL SECURITY;

-- Profiles Policies
DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
CREATE POLICY "Users can read own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Admins can read all profiles" ON public.profiles;
CREATE POLICY "Admins can read all profiles" ON public.profiles FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Rate History Policies
DROP POLICY IF EXISTS "Rate history is public" ON public.rate_history;
CREATE POLICY "Rate history is public" ON public.rate_history FOR SELECT USING (true);

DROP POLICY IF EXISTS "Service role can insert rate history" ON public.rate_history;
CREATE POLICY "Service role can insert rate history" ON public.rate_history FOR INSERT WITH CHECK (true);


-- Price Alerts Policies
DROP POLICY IF EXISTS "Users can manage own alerts" ON public.price_alerts;
CREATE POLICY "Users can manage own alerts" ON public.price_alerts FOR ALL USING (auth.uid() = user_id);

-- Market News Policies
DROP POLICY IF EXISTS "News is public" ON public.market_news;
CREATE POLICY "News is public" ON public.market_news FOR SELECT USING (is_published = true);

DROP POLICY IF EXISTS "Admins can manage news" ON public.market_news;
CREATE POLICY "Admins can manage news" ON public.market_news FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Dealer Config Policies
DROP POLICY IF EXISTS "Dealer config is public" ON public.dealer_config;
CREATE POLICY "Dealer config is public" ON public.dealer_config FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins can update dealer config" ON public.dealer_config;
CREATE POLICY "Admins can update dealer config" ON public.dealer_config FOR ALL USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

-- Admin Audit Logs Policies
DROP POLICY IF EXISTS "Admins can view all audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can view all audit logs" ON public.admin_audit_logs FOR SELECT USING (EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "Admins can insert audit logs" ON public.admin_audit_logs;
CREATE POLICY "Admins can insert audit logs" ON public.admin_audit_logs FOR INSERT WITH CHECK (auth.uid() = admin_id);

-- ==========================================
-- TRIGGERS SETUP
-- ==========================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_profiles_modtime ON public.profiles;
CREATE TRIGGER update_profiles_modtime BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();


DROP TRIGGER IF EXISTS update_dealer_config_modtime ON public.dealer_config;
CREATE TRIGGER update_dealer_config_modtime BEFORE UPDATE ON public.dealer_config FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Profile auto-creation on auth signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, phone_number)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();

-- ==========================================
-- SEED DEFAULT DATA
-- ==========================================

INSERT INTO public.dealer_config (key, value)
VALUES 
    ('gold_badla_markup', '150'::jsonb),
    ('silver_badla_markup', '250'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- ==========================================
-- REALTIME REPLICATION SETUP
-- ==========================================

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_publication WHERE pubname = 'supabase_realtime'
    ) THEN
        IF NOT EXISTS (
            SELECT 1 FROM pg_publication_tables 
            WHERE pubname = 'supabase_realtime' AND tablename = 'dealer_config'
        ) THEN
            ALTER PUBLICATION supabase_realtime ADD TABLE public.dealer_config;
        END IF;
        IF NOT EXISTS (
            SELECT 1 FROM pg_publication_tables 
            WHERE pubname = 'supabase_realtime' AND tablename = 'admin_audit_logs'
        ) THEN
            ALTER PUBLICATION supabase_realtime ADD TABLE public.admin_audit_logs;
        END IF;
    END IF;
END $$;

-- Force PostgREST schema cache reload
NOTIFY pgrst, 'reload schema';
