# 🪙 Laxmi Bullion — Live MCX Gold & Silver Trading App

> Real-time MCX commodity price tracking app for bullion traders — built with React Native, Expo, Node.js, and Supabase.

[![Platform](https://img.shields.io/badge/platform-Android%20%7C%20iOS-blue)](https://github.com/Tanishq74/bullionTrader)
[![Built With](https://img.shields.io/badge/built%20with-Expo%20%7C%20React%20Native-blueviolet)](https://expo.dev)
[![Backend](https://img.shields.io/badge/backend-Node.js%20%7C%20Supabase-green)](https://supabase.com)

---

## ✨ Features

- 📊 **Live MCX Prices** — Real-time Gold & Silver futures Bid/Ask via Upstox, Angel One, or Zerodha Kite Connect
- 🔔 **Price Alerts** — Push notifications when Gold/Silver crosses user-defined targets
- 💰 **Karat Rates** — Auto-calculated 22K, 20K, 18K gold rates from MCX futures price
- 🌍 **International Rates** — Live USD Gold/Silver spot price and USD/INR conversion
- 📈 **High/Low Tracking** — Intraday high and low tracked per session
- ⚡ **Realtime Updates** — WebSocket-based price broadcasting via Supabase Realtime
- 📞 **One-tap Booking** — Call or WhatsApp to book commodity instantly
- 🔄 **Automatic Fallback** — Simulator kicks in if live feed is unavailable

---

## 🏗️ Architecture

```
MCX Exchange
     │
     ▼
┌─────────────────────────────────┐
│     Ingestion Worker (Node.js)  │
│  Upstox / Angel One / Kite /    │
│  Simulator (fallback)           │
└────────────┬────────────────────┘
             │ Supabase Realtime Broadcast
             ▼
┌─────────────────────────────────┐
│       Supabase (PostgreSQL)     │
│  Auth · RLS · Realtime · DB     │
└────────────┬────────────────────┘
             │
     ┌───────┴────────┐
     ▼                ▼
┌─────────┐     ┌──────────┐
│ Mobile  │     │   Web    │
│ App     │     │   App    │
│(Expo RN)│     │ (React)  │
└─────────┘     └──────────┘
```

---

## 🛠️ Tech Stack

### Mobile App (`apps/mobile`)
| Technology | Purpose |
|---|---|
| React Native + Expo SDK 54 | Cross-platform mobile (Android + iOS) |
| TypeScript | Type safety |
| Supabase JS | Auth, database, realtime |
| Expo Notifications | Push notification alerts |
| React Navigation | Tab-based navigation |
| EAS Build | Cloud builds for Play Store / App Store |

### Backend (`backend/ingestion-worker`)
| Technology | Purpose |
|---|---|
| Node.js + TypeScript | Price ingestion service |
| Upstox API v2 | Free MCX live price feed |
| Angel One SmartAPI | Alternative free MCX feed |
| Zerodha Kite Connect | Premium MCX WebSocket feed |
| Supabase Realtime | Broadcast price ticks to all clients |

---

## 🚀 Getting Started

### Prerequisites
- Node.js >= 18
- pnpm >= 8
- Expo CLI (`npm install -g expo-cli`)
- EAS CLI (`npm install -g eas-cli`)
- Supabase account
- Upstox / Angel One demat account (for live prices)

### 1. Clone & Install

```bash
git clone https://github.com/Tanishq74/bullionTrader.git
cd bullionTrader
pnpm install
```

### 2. Set up environment variables

```bash
cp apps/mobile/.env.example apps/mobile/.env
cp backend/ingestion-worker/.env.example backend/ingestion-worker/.env
```

Fill in your Supabase URL, anon key, and your chosen price feed credentials.

### 3. Run the mobile app

```bash
cd apps/mobile
npx expo start
```

Scan the QR code with **Expo Go** on your phone.

### 4. Run the backend ingestion worker

```bash
cd backend/ingestion-worker
npm run upstox:auth   # One-time: generate Upstox access token
npm run dev           # Start the worker
```

---

## 📡 Live Price Feed Setup

| Provider | Cost | Setup |
|---|---|---|
| **Upstox API v2** | 🆓 Free | [developer.upstox.com](https://developer.upstox.com) |
| **Angel One SmartAPI** | 🆓 Free | [smartapi.angelbroking.com](https://smartapi.angelbroking.com) |
| **Zerodha Kite Connect** | 💰 ₹2000/mo | [kite.trade](https://kite.trade) |

Set your preferred provider in `backend/ingestion-worker/.env`:

```env
USE_UPSTOX=true        # Recommended for testing
USE_ANGEL_ONE=false
USE_MOCK_DATA=false    # Set true for simulator mode
```

---

## 📦 Build for Play Store

```bash
cd apps/mobile
eas build --platform android --profile production   # AAB for Play Store
eas build --platform android --profile preview      # APK for device testing
```

---

## 📁 Project Structure

```
bullionTrader/
├── apps/
│   ├── mobile/                  # React Native Expo app
│   │   ├── src/
│   │   │   ├── screens/         # Dashboard, Alerts, Profile, News
│   │   │   └── services/        # Supabase, API, notifications
│   │   ├── app.json             # Expo config
│   │   └── eas.json             # EAS build profiles
│   ├── ios/                     # Native Swift iOS app
│   └── web/                     # React web app
├── backend/
│   ├── ingestion-worker/        # MCX price feed service
│   │   └── src/
│   │       ├── upstoxClient.ts  # Upstox API v2 client
│   │       ├── angelOneClient.ts# Angel One SmartAPI client
│   │       ├── kiteClient.ts    # Zerodha Kite Connect client
│   │       ├── simulator.ts     # Fallback price simulator
│   │       └── broadcaster.ts   # Supabase Realtime broadcaster
│   ├── api-gateway/             # REST API gateway
│   └── notification-service/   # Push notification service
├── infrastructure/
│   └── supabase/migrations/     # PostgreSQL schema migrations
└── docker-compose.yml
```

---

## 🔒 Security

- All `.env` files are gitignored — never committed
- Supabase Row Level Security (RLS) enforced on all tables
- API keys managed via environment variables only

---

## 🤝 Associated With

**Laxmi Abhushan Jewellers** — Indore, MP
📞 +91 98272 33090 | 💬 [WhatsApp](https://wa.me/919827233090)

---

## 👨‍💻 Developer

**Tanishq Tamarkar** — [github.com/Tanishq74](https://github.com/Tanishq74)

---

*Built with ❤️ for the bullion trading community*
