# Laxmi Abhushan - Bullion Trading App
## Complete Implementation Plan & Technical Blueprint

**Project:** bullionTrader (iOS)
**Type:** Real-time bullion trading platform
**Comparable:** Pritam Spot, Kedia Bullion, Augmont Gold
**Created:** 2026-03-26
**Author:** Tanishq Tamarkar

---

## Table of Contents

1. [Current State Assessment](#1-current-state-assessment)
2. [Target Vision](#2-target-vision)
3. [System Architecture](#3-system-architecture)
4. [Phase 1 - Project Foundation](#phase-1---project-foundation)
5. [Phase 2 - Firebase Setup](#phase-2---firebase-setup)
6. [Phase 3 - Authentication System](#phase-3---authentication-system)
7. [Phase 4 - Market Data & Rate Engine](#phase-4---market-data--rate-engine)
8. [Phase 5 - Real-Time Rate Display](#phase-5---real-time-rate-display)
9. [Phase 6 - Order & Booking System](#phase-6---order--booking-system)
10. [Phase 7 - Price Alerts & Notifications](#phase-7---price-alerts--notifications)
11. [Phase 8 - Admin Panel](#phase-8---admin-panel)
12. [Phase 9 - Offline & Caching](#phase-9---offline--caching)
13. [Phase 10 - Testing](#phase-10---testing)
14. [Phase 11 - Polish & Deployment](#phase-11---polish--deployment)
15. [Phase 12 - V2 Features](#phase-12---v2-features)
16. [Rate Calculation Reference](#rate-calculation-reference)
17. [Database Schema Reference](#database-schema-reference)
18. [API Contract Reference](#api-contract-reference)

---

## 1. Current State Assessment

### What Exists (Completed)

| Component | Status | Details |
|---|---|---|
| Project structure | Done | SwiftUI, MVVM skeleton |
| Theme system | Done | Dark mode, gold accent (#D4A843), Color hex init |
| Models | Done | CommodityRate, LocalRate, SpotRate, PriceAlert, MarketNews, BookingEnquiry, UserProfile |
| Mock data | Done | Gold (6 variants), Silver (3 variants), Local rates, Spot rates, Alerts, News |
| Dashboard | Done | Marquee ticker, spot rate bar, rate cards (buy/sell/high/low), international rates (USD), local delivery rates, quick actions, market status |
| Login/OTP | Done | Phone input, OTP sheet, skip option (all mocked) |
| Booking | Done | Commodity picker, quantity, customer info, submit form |
| Alerts | Done | List view, create alert sheet, toggle active/inactive |
| News | Done | Market news feed, read/unread state, relative timestamps |
| Profile | Done | User header, preferences, contact info, sign out |
| Price formatters | Done | INR (Indian locale), USD, change, percent |

### What's Missing (To Build)

| Component | Priority | Complexity |
|---|---|---|
| Firebase project & SDK setup | P0 | Low |
| Phone OTP authentication (real) | P0 | Medium |
| Live rate data source | P0 | High |
| Rate calculation engine | P0 | Medium |
| Networking / service layer | P0 | Medium |
| Real-time data sync (Firebase RTDB) | P0 | High |
| Order execution backend | P1 | High |
| Push notifications (FCM) | P1 | Medium |
| Admin rate management | P1 | High |
| Offline caching | P2 | Medium |
| Charts & price history | P2 | Medium |
| Portfolio tracking | P3 | High |

---

## 2. Target Vision

### User Roles

| Role | Capabilities |
|---|---|
| **Guest** | View live rates only (limited access) |
| **Registered User** | View rates, place buy/sell requests, set alerts, view history |
| **Admin / Dealer** | All user capabilities + update rates, manage orders, send notifications, set margins |

### User Journey

```
App Launch
  |
  v
Splash Screen (2s, check auth token)
  |
  +-- Token valid --> Dashboard (live rates)
  |
  +-- No token --> Login Screen
                      |
                      v
                   Phone + OTP
                      |
                      v
                   Dashboard (live rates)
                      |
                      +-- View gold/silver rates (real-time)
                      +-- Place buy/sell request
                      +-- Set price alert
                      +-- View order history
                      +-- Read market news
                      +-- Profile & settings
```

### MVP Feature Set (V1)

1. Phone OTP login (Firebase Auth)
2. Live gold & silver rate dashboard (Firebase RTDB)
3. Rate calculation (spot + conversion + duty + GST + margin)
4. Buy/sell request placement (Firestore)
5. Order history
6. Price alerts with push notifications
7. Market news feed
8. Profile management

---

## 3. System Architecture

### 3-Tier Overview

```
+--------------------------------------------+
|            FRONTEND (iOS App)              |
|                                            |
|  SwiftUI + MVVM + Observation framework    |
|  Firebase iOS SDK                          |
+--------------------------------------------+
          |              |              |
     Firebase Auth   Firebase RTDB   Firestore
          |              |              |
+--------------------------------------------+
|           FIREBASE BACKEND LAYER           |
|                                            |
|  Authentication    Realtime Database       |
|  Cloud Firestore   Cloud Functions         |
|  Cloud Messaging   Storage                 |
+--------------------------------------------+
          |
+--------------------------------------------+
|          EXTERNAL DATA SOURCES             |
|                                            |
|  Gold/Silver spot price APIs               |
|  Currency exchange rates (USD/INR)         |
|  MCX reference data                        |
+--------------------------------------------+
```

### Why Firebase (Not Custom Backend)

For an MVP bullion app targeting Indian bullion dealers:

- **Speed to market:** No server provisioning, no DevOps
- **Real-time native:** Firebase RTDB gives sub-second rate updates out of the box
- **Phone auth built-in:** Indian OTP flow works immediately
- **Cloud Functions:** Server-side logic (rate calculation, order validation) without a full backend
- **Cost:** Free tier covers early users; pay-as-you-grow after
- **Admin SDK:** Build a simple admin panel or use Firebase Console directly

### iOS App Architecture (MVVM + Services)

```
bullionTrader/
|
+-- App/
|   +-- bullionTraderApp.swift          (entry point, environment setup)
|   +-- ContentView.swift               (auth routing + tab view)
|
+-- Models/
|   +-- Models.swift                    (data models)
|   +-- MockData.swift                  (development mock data)
|
+-- Services/
|   +-- AuthService.swift               (Firebase Auth wrapper)
|   +-- RateService.swift               (Firebase RTDB listener for live rates)
|   +-- OrderService.swift              (Firestore CRUD for orders)
|   +-- AlertService.swift              (Firestore CRUD for price alerts)
|   +-- NewsService.swift               (Firestore CRUD for news)
|   +-- NotificationService.swift       (FCM registration + handling)
|   +-- RateCalculator.swift            (spot -> final price logic)
|
+-- ViewModels/
|   +-- AuthViewModel.swift             (login state, OTP flow)
|   +-- DashboardViewModel.swift        (live rates, connection status)
|   +-- BookingViewModel.swift          (order placement flow)
|   +-- AlertsViewModel.swift           (alert management)
|   +-- NewsViewModel.swift             (news feed)
|   +-- ProfileViewModel.swift          (user profile)
|
+-- Views/
|   +-- Auth/                           (LoginView, OTPVerificationView)
|   +-- Dashboard/                      (all dashboard components)
|   +-- Booking/                        (BookingView, OrderHistoryView)
|   +-- Alerts/                         (AlertsView, CreateAlertView)
|   +-- News/                           (NewsView, NewsDetailView)
|   +-- Profile/                        (ProfileView, EditProfileView)
|
+-- Theme/
|   +-- AppTheme.swift                  (colors, formatters)
|
+-- Utilities/
    +-- KeychainHelper.swift            (secure token storage)
    +-- NetworkMonitor.swift            (connectivity tracking)
    +-- HapticManager.swift             (tactile feedback on price changes)
```

### Data Flow Pattern

```
Firebase RTDB (rates update)
       |
       v
  RateService (listener receives new data)
       |
       v
  RateCalculator (applies conversion, duty, GST, margin)
       |
       v
  DashboardViewModel (@Observable, publishes updated rates)
       |
       v
  SwiftUI Views (automatic re-render via Observation framework)
```

---

## Phase 1 - Project Foundation

**Goal:** Set up dependency management, project structure, and configuration for multi-environment builds.

### Step 1.1 - Swift Package Manager Dependencies

Add the following packages to the Xcode project via File > Add Package Dependencies:

| Package | Purpose | URL |
|---|---|---|
| firebase-ios-sdk | Auth, Firestore, RTDB, FCM, Functions | `https://github.com/firebase/firebase-ios-sdk` |

Select these Firebase products:
- FirebaseAuth
- FirebaseFirestore
- FirebaseDatabase (Realtime Database)
- FirebaseMessaging
- FirebaseFunctions

No other third-party dependencies needed for MVP. SwiftUI + Observation framework handles UI and state.

### Step 1.2 - Project Configuration

- **Minimum deployment target:** iOS 17.0 (for Observation framework, modern SwiftUI)
- **Bundle ID:** `com.laxmiabhushan.bulliontrader` (or as registered)
- **Capabilities to enable:**
  - Push Notifications
  - Background Modes > Remote notifications
  - Keychain Sharing (if needed across extensions)

### Step 1.3 - Environment Configuration

Create two Firebase projects (or use one with care):
- **Development:** Points to dev Firestore/RTDB (mock rates, test data)
- **Production:** Points to live data

Use Xcode build configurations:
- `Debug` scheme -> `GoogleService-Info-Dev.plist`
- `Release` scheme -> `GoogleService-Info.plist`

Load the correct plist at app startup based on the active configuration.

### Step 1.4 - Create Service Layer Skeleton

Create empty service files with protocol definitions:

- `AuthService` - Protocol with: `sendOTP(phone:)`, `verifyOTP(code:)`, `signOut()`, `currentUser`
- `RateService` - Protocol with: `startListening()`, `stopListening()`, `onRatesUpdate` callback
- `OrderService` - Protocol with: `placeOrder(_:)`, `fetchOrders()`, `cancelOrder(_:)`
- `AlertService` - Protocol with: `createAlert(_:)`, `fetchAlerts()`, `toggleAlert(_:)`
- `NewsService` - Protocol with: `fetchNews()`, `markAsRead(_:)`

This allows ViewModels to be built against protocols while Firebase implementation is wired up.

### Step 1.5 - Network Monitor

Create a `NetworkMonitor` utility using `NWPathMonitor` from the Network framework:
- Track connected/disconnected state
- Expose as an `@Observable` class
- Inject into environment so any view can show offline banner
- Dashboard should show "Offline - showing cached rates" when disconnected

---

## Phase 2 - Firebase Setup

**Goal:** Create Firebase project, configure iOS app, and verify SDK integration.

### Step 2.1 - Firebase Console Setup

1. Go to console.firebase.google.com
2. Create project: "Laxmi Abhushan" (or "BullionTrader")
3. Enable Google Analytics (optional but recommended for tracking)
4. Register iOS app with bundle ID
5. Download `GoogleService-Info.plist`
6. Place in Xcode project root (ensure it's in the target)

### Step 2.2 - Enable Firebase Services

In Firebase Console, enable:

| Service | Location | Configuration |
|---|---|---|
| Authentication | Authentication > Sign-in method | Enable "Phone" provider |
| Realtime Database | Realtime Database > Create Database | Start in **locked mode**, add rules later |
| Cloud Firestore | Firestore Database > Create Database | Start in **production mode** |
| Cloud Messaging | Cloud Messaging | Generate APNs key, upload to Firebase |
| Cloud Functions | Functions | Will deploy rate-fetch and order-validation functions |

### Step 2.3 - Realtime Database Structure (for Live Rates)

Design the RTDB structure for maximum read efficiency:

```
bullion-rates/
  |
  +-- gold/
  |   +-- fine_995/
  |   |   +-- buyRate: 92200
  |   |   +-- sellRate: 92350
  |   |   +-- highRate: 92600
  |   |   +-- lowRate: 91800
  |   |   +-- previousClose: 91850
  |   |   +-- lastUpdated: 1711411200000
  |   |
  |   +-- 24k/
  |   +-- 22k/
  |   +-- 18k/
  |   +-- guinee/
  |   +-- petal/
  |
  +-- silver/
  |   +-- fine_999/
  |   +-- 925/
  |   +-- micro/
  |
  +-- spot/
  |   +-- xau/
  |   |   +-- priceUSD: 2340.50
  |   |   +-- change: 12.30
  |   |   +-- changePercent: 0.53
  |   |   +-- lastUpdated: 1711411200000
  |   |
  |   +-- xag/
  |
  +-- local/
  |   +-- gold/
  |   |   +-- mcxRate: 92500
  |   |   +-- localPremium: 2000
  |   |   +-- lastUpdated: 1711411200000
  |   |
  |   +-- silver/
  |
  +-- config/
      +-- isMarketOpen: true
      +-- lastGlobalUpdate: 1711411200000
      +-- usdToInr: 83.45
      +-- importDutyPercent: 15.0
      +-- gstPercent: 3.0
```

**Why RTDB over Firestore for rates:** RTDB is optimized for frequent small writes and real-time listeners. Rates update every few seconds. Firestore charges per read and is better for structured queries (orders, users). Use both: RTDB for rates, Firestore for everything else.

### Step 2.4 - Firestore Collections (for Business Data)

```
users/
  {userId}/
    name: "..."
    phone: "+91..."
    city: "Rajkot"
    businessName: "..."
    createdAt: timestamp
    fcmToken: "..."

orders/
  {orderId}/
    userId: "..."
    commodityName: "Gold Fine 995"
    type: "buy" | "sell"
    quantity: "100"
    unit: "gm"
    rateAtBooking: 92200
    totalAmount: 922000
    status: "pending" | "confirmed" | "delivered" | "cancelled"
    customerName: "..."
    customerPhone: "..."
    notes: "..."
    createdAt: timestamp
    updatedAt: timestamp

alerts/
  {alertId}/
    userId: "..."
    commodityName: "Gold 24K"
    targetPrice: 93000
    direction: "above" | "below"
    isActive: true
    triggered: false
    createdAt: timestamp

news/
  {newsId}/
    title: "..."
    body: "..."
    publishedAt: timestamp

rate-history/
  {date}/
    gold_fine_995/
      open: 91850
      close: 92200
      high: 92600
      low: 91800
```

### Step 2.5 - Security Rules

**Realtime Database rules** (rates are read-only for users, writable only by admin/Cloud Functions):

```
{
  "rules": {
    "bullion-rates": {
      ".read": "auth != null",
      ".write": "auth.token.admin === true"
    }
  }
}
```

**Firestore rules** (users can only access their own data):

- `/users/{userId}` - Read/write only if `request.auth.uid == userId`
- `/orders/{orderId}` - Read if `resource.data.userId == request.auth.uid`; Create if authenticated; Update only by admin
- `/alerts/{alertId}` - Read/write if `resource.data.userId == request.auth.uid`
- `/news/{newsId}` - Read if authenticated; Write only by admin

### Step 2.6 - Firebase App Initialization

In `bullionTraderApp.swift`:
- Call `FirebaseApp.configure()` in an init block or using the app delegate adaptor
- Register for remote notifications
- Set up FCM delegate

---

## Phase 3 - Authentication System

**Goal:** Replace mocked login with real Firebase Phone Auth (Indian OTP).

### Step 3.1 - Auth Flow

```
LoginView
  |
  User enters phone number (+91 XXXXXXXXXX)
  |
  v
AuthService.sendOTP(phone)
  |
  Firebase sends SMS to the number
  |
  v
OTPVerificationView appears
  |
  User enters 6-digit code
  |
  v
AuthService.verifyOTP(code)
  |
  Firebase verifies -> returns FirebaseAuth.User
  |
  v
Check Firestore: does /users/{uid} exist?
  |
  +-- YES --> Load profile, go to Dashboard
  +-- NO  --> Create user document, then go to Dashboard
```

### Step 3.2 - AuthService Implementation Details

- `sendOTP(phone:)` calls `PhoneAuthProvider.provider().verifyPhoneNumber(phone, uiDelegate: nil)`
- Store the returned `verificationID` in memory (needed for OTP verification)
- `verifyOTP(code:)` creates `PhoneAuthCredential` with verificationID + code, then calls `Auth.auth().signIn(with: credential)`
- On success, store auth state. Firebase SDK persists the session automatically.
- `signOut()` calls `Auth.auth().signOut()`
- `currentUser` returns `Auth.auth().currentUser`

### Step 3.3 - AuthViewModel

- Holds state: `phoneNumber`, `isLoading`, `error`, `authState` (enum: `.loggedOut`, `.otpSent`, `.loggedIn`)
- Exposes methods: `sendOTP()`, `verifyOTP(code:)`, `signOut()`
- On successful login, checks/creates Firestore user profile
- Publishes `isAuthenticated` for ContentView routing

### Step 3.4 - Session Persistence

- Firebase Auth SDK handles token refresh automatically
- On app launch, check `Auth.auth().currentUser`:
  - Non-nil -> user is logged in, go to dashboard
  - Nil -> show login screen
- Add an auth state listener: `Auth.auth().addStateDidChangeListener` to react to sign-in/sign-out globally

### Step 3.5 - Secure Storage

- Store any sensitive local data (user preferences, cached tokens) in iOS Keychain using a simple KeychainHelper wrapper
- Never store auth tokens in UserDefaults
- Firebase handles its own token storage securely

---

## Phase 4 - Market Data & Rate Engine

**Goal:** Fetch real gold/silver prices and calculate final INR rates with all applicable charges.

### Step 4.1 - Data Source Options

| Source | Type | Cost | Notes |
|---|---|---|---|
| **Admin manual entry** | Firebase RTDB write | Free | Admin updates rates from their own MCX terminal. Simplest approach for a dealer app. |
| **GoldAPI.io** | REST API | Free tier: 300 req/month | International spot prices (XAU, XAG) |
| **MetalpriceAPI** | REST API | Free tier: 100 req/month | Multi-metal, multi-currency |
| **MCX data feed** | Commercial | Paid | Official Indian commodity exchange data |
| **Custom scraping** | Cloud Function | Free (compute cost) | Scrape publicly available MCX rates from financial sites |

**Recommended approach for MVP:**

The most common approach for Indian bullion dealer apps (like Pritam Spot) is **admin-controlled rates**. The dealer (Laxmi Abhushan) watches their MCX terminal and updates rates in Firebase. The app reflects those rates instantly.

For international spot prices (XAU/XAG shown in the spot bar), use a free API like GoldAPI.io called from a Cloud Function on a schedule.

### Step 4.2 - Rate Update Architecture

```
Option A: Admin-Controlled (Primary)
==========================================
Admin opens admin panel (web or app)
  |
  v
Enters/adjusts gold & silver rates
  |
  v
Writes to Firebase RTDB: /bullion-rates/gold/fine_995/buyRate = 92200
  |
  v
All connected iOS apps receive update instantly via RTDB listener
  |
  v
UI updates in real-time


Option B: Automated via Cloud Function (International Spot)
==========================================
Cloud Function runs on schedule (every 60 seconds via Cloud Scheduler)
  |
  v
Calls GoldAPI.io or MetalpriceAPI
  |
  v
Gets XAU/XAG prices in USD
  |
  v
Writes to RTDB: /bullion-rates/spot/xau/priceUSD = 2340.50
  |
  v
iOS apps receive update
```

### Step 4.3 - Rate Calculation Engine

The `RateCalculator` service converts international spot prices to Indian retail prices:

**Gold Price Calculation:**

```
1. International Spot Price (per troy ounce in USD)
   Example: $2,340.50

2. Convert to per gram
   = $2,340.50 / 31.1035 (troy ounce to grams)
   = $75.24 per gram

3. Convert to INR
   = $75.24 x 83.45 (USD/INR rate)
   = Rs 6,278.78 per gram

4. Apply Import Duty (15%)
   = Rs 6,278.78 x 1.15
   = Rs 7,220.60 per gram

5. Apply GST (3%)
   = Rs 7,220.60 x 1.03
   = Rs 7,437.22 per gram

6. Convert to per 10 grams (standard Indian unit)
   = Rs 74,372.20 per 10 gm

7. Apply Dealer Margin / Local Premium
   = Rs 74,372.20 + Rs 2,000 (dealer premium)
   = Rs 76,372.20 per 10 gm (BUY price)

8. Sell Price = Buy Price - Spread
   = Rs 76,372.20 - Rs 150 (dealer spread)
   = Rs 76,222.20 per 10 gm (SELL price)
```

**In practice for a dealer app:** The admin typically sets the final buy/sell rates directly (they do the calculation mentally based on their MCX terminal). The rate calculation engine is useful for:
- Auto-calculating when integrated with a spot price API
- Showing the breakdown to users (transparency)
- Calculating rates for different purities (22K = 24K x 0.9166, 18K = 24K x 0.75)

### Step 4.4 - Purity Multipliers

| Purity | Multiplier | Use Case |
|---|---|---|
| 999 (24K) | 1.000 | Pure gold, investment bars |
| 995 (Fine) | 0.996 | Standard bullion |
| 916 (22K) | 0.916 | Jewellery standard |
| 750 (18K) | 0.750 | Lightweight jewellery |

Silver follows a similar pattern with 999 and 925 purities.

### Step 4.5 - Config Parameters (Stored in RTDB)

These values live at `/bullion-rates/config/` and can be changed by admin without app update:

| Parameter | Example | Purpose |
|---|---|---|
| usdToInr | 83.45 | Currency conversion rate |
| importDutyPercent | 15.0 | Indian import duty on gold |
| gstPercent | 3.0 | GST on gold/silver |
| dealerMarginGold | 2000 | Premium per 10gm gold |
| dealerMarginSilver | 1500 | Premium per kg silver |
| spreadGold | 150 | Buy-sell difference for gold |
| spreadSilver | 300 | Buy-sell difference for silver |
| isMarketOpen | true | Controls market status indicator |

---

## Phase 5 - Real-Time Rate Display

**Goal:** Wire Firebase RTDB listeners to the dashboard so rates update live.

### Step 5.1 - RateService Implementation

The `RateService` does the following:

1. **Start listening:** Attach Firebase RTDB observers at `/bullion-rates/`
2. **Receive updates:** When any rate value changes, Firebase pushes the new data instantly
3. **Parse data:** Convert Firebase snapshots to `CommodityRate`, `SpotRate`, `LocalRate` model objects
4. **Notify ViewModel:** Call the update callback / publish new values
5. **Stop listening:** Remove observers when the service is deallocated or app goes to background

Key RTDB observer types:
- `.observe(.value)` on `/bullion-rates/gold/` for all gold rates
- `.observe(.value)` on `/bullion-rates/silver/` for all silver rates
- `.observe(.value)` on `/bullion-rates/spot/` for international spot
- `.observe(.value)` on `/bullion-rates/local/` for local delivery rates
- `.observe(.value)` on `/bullion-rates/config/` for market status & config

### Step 5.2 - DashboardViewModel Updates

Replace current mock data loading with RateService:

1. On `init`, create RateService and start listening
2. When RateService delivers new data, update published properties (`goldRates`, `silverRates`, `spotRates`, `localRates`)
3. Update `lastUpdated` timestamp
4. Update `isConnected` based on RTDB connection state (Firebase provides `.info/connected`)
5. Update `isMarketOpen` from config

### Step 5.3 - UI Update Strategy

To prevent flickering when rates update frequently:

- Use SwiftUI's built-in diffing (Observation framework handles this well)
- Apply `.animation(.easeInOut(duration: 0.3))` to price text for smooth transitions
- Flash green/red briefly when a price changes (use a `priceJustChanged` flag with a 0.5s reset timer)
- The marquee ticker should update its data but not restart the scroll position

### Step 5.4 - Connection State Handling

Firebase RTDB provides a special path `.info/connected` that indicates whether the client is connected to Firebase servers.

States to show in UI:
- **Connected + Market Open:** Green dot + "Market Open" (as currently designed)
- **Connected + Market Closed:** Red dot + "Market Closed"
- **Disconnected:** Yellow dot + "Reconnecting..." or "Offline - Cached Rates"
- **No internet:** Show offline banner at top of dashboard

### Step 5.5 - Background/Foreground Handling

- When app enters background: Detach RTDB listeners (save battery and quota)
- When app returns to foreground: Re-attach listeners, fetch latest data
- Use `scenePhase` environment value in SwiftUI to detect transitions
- On re-attach, data arrives immediately since RTDB re-syncs

---

## Phase 6 - Order & Booking System

**Goal:** Allow users to place buy/sell requests with rate locking, stored in Firestore.

### Step 6.1 - Order Flow (Step by Step)

```
1. USER ACTION
   User taps "Book" tab, selects commodity (e.g., Gold Fine 995)

2. RATE DISPLAY
   App shows current live buy rate (from DashboardViewModel)
   Rate continues updating in real-time on this screen

3. USER INPUT
   User enters: quantity (gm), name, phone, notes

4. RATE LOCK
   User taps "Submit Booking Enquiry"
   App captures the EXACT rate at the moment of tap
   This becomes rateAtBooking (e.g., 92,200)

5. CONFIRMATION DIALOG
   App shows: "Book 100gm Gold Fine 995 at Rs 92,200/10gm?"
   "Total: Rs 9,22,000"
   User confirms

6. ORDER SUBMISSION
   App creates order document in Firestore:
   - All order details + rateAtBooking + timestamp
   - Status: "pending"

7. BACKEND VALIDATION (Cloud Function trigger)
   Cloud Function triggers on Firestore write (orders collection)
   - Validates the rate is within acceptable range (not stale)
   - Checks if market is open
   - If valid: keeps status "pending"
   - If invalid: sets status "rejected" with reason

8. ADMIN NOTIFICATION
   Cloud Function sends push notification to admin device
   "New order: 100gm Gold Fine 995 at Rs 92,200 from [Customer Name]"

9. ADMIN CONFIRMATION
   Admin reviews order in admin panel
   Changes status to "confirmed" or "cancelled" with note

10. USER NOTIFICATION
    Cloud Function triggers on status change
    Sends push to user: "Your order for 100gm Gold Fine 995 has been confirmed"

11. ORDER COMPLETION
    Admin marks as "delivered" when physical delivery happens
```

### Step 6.2 - Rate Lock Strategy

In bullion trading, rates change every second. The "rate lock" works as follows:

- The rate displayed is always live
- The rate is "locked" only at the moment the user confirms the order
- The locked rate is stored in the order document
- A tolerance window (e.g., rate must not have changed more than 0.5% from when the user opened the booking screen) can be enforced
- If the rate moved too much during the confirmation dialog, show a "Rate has changed" alert and ask the user to re-confirm at the new rate

### Step 6.3 - Order Statuses

```
pending --> confirmed --> delivered
   |            |
   v            v
cancelled    cancelled
```

- `pending` - Order placed by user, awaiting admin review
- `confirmed` - Admin has accepted the order
- `delivered` - Physical delivery completed
- `cancelled` - Cancelled by admin or user (with reason)

### Step 6.4 - BookingViewModel

- Holds form state: selectedCommodity, quantity, customerName, customerPhone, notes
- Fetches current rate from DashboardViewModel (shared via Environment)
- On submit: creates `BookingEnquiry` object, calls `OrderService.placeOrder()`
- Handles loading state, success, and error
- Also provides `fetchOrderHistory()` for the order list screen

### Step 6.5 - Order History View

Add a new view accessible from the Booking tab:
- Segmented control: "New Order" | "My Orders"
- Order list shows: commodity, quantity, rate, status, date
- Tap an order to see full details
- Status shown with color-coded badges (pending=gold, confirmed=green, cancelled=red)

---

## Phase 7 - Price Alerts & Notifications

**Goal:** Users set target prices; app notifies them when the target is hit.

### Step 7.1 - Alert Creation Flow

```
User creates alert:
  - Commodity: Gold 24K
  - Target: Rs 93,000
  - Direction: Above (notify when price goes ABOVE 93,000)
  |
  v
Alert saved to Firestore: /alerts/{alertId}
  - userId, commodityName, targetPrice, direction, isActive: true, triggered: false
```

### Step 7.2 - Alert Evaluation (Cloud Function)

```
Cloud Function triggers when rates update in RTDB
  |
  v
Function reads all active alerts from Firestore
  |
  v
For each alert:
  - Get current price for the alert's commodity
  - Check: if direction is "above" and currentPrice >= targetPrice -> TRIGGER
  - Check: if direction is "below" and currentPrice <= targetPrice -> TRIGGER
  |
  v
If triggered:
  - Send push notification to user's FCM token
  - Set alert.triggered = true (to prevent re-triggering)
  - Optionally set alert.isActive = false
```

### Step 7.3 - Push Notification Setup (FCM)

1. **APNs Key:** Generate an APNs authentication key in Apple Developer Console
2. **Upload to Firebase:** In Firebase Console > Cloud Messaging > Upload APNs key
3. **iOS Setup:**
   - Request notification permission on first launch (or after login)
   - Register for remote notifications
   - Implement `UNUserNotificationCenterDelegate` for foreground handling
   - On token refresh, save FCM token to Firestore user document
4. **Notification payload structure:**
   ```
   {
     "title": "Price Alert: Gold 24K",
     "body": "Gold 24K has crossed Rs 93,000! Current: Rs 93,150",
     "data": {
       "type": "price_alert",
       "alertId": "...",
       "commodityName": "Gold 24K",
       "currentPrice": "93150"
     }
   }
   ```

### Step 7.4 - Notification Types

| Type | Trigger | Message |
|---|---|---|
| Price alert | Rate crosses target | "Gold 24K crossed Rs 93,000!" |
| Order confirmed | Admin confirms order | "Your order #123 has been confirmed" |
| Order update | Status change | "Your order #123 is out for delivery" |
| Market open/close | Market hours | "Market is now open" |
| News/announcement | Admin publishes | "New: RBI policy impact on gold" |

---

## Phase 8 - Admin Panel

**Goal:** Allow the dealer (Laxmi Abhushan) to manage rates, orders, and users.

### Step 8.1 - Admin Options

Two approaches:

**Option A: Web Admin Panel (Recommended for V1)**
- Simple web page hosted on Firebase Hosting
- Built with HTML/JS + Firebase SDK
- Admin logs in with email/password (separate from phone auth)
- Pages: Rate Management, Orders, Users, Push Notifications

**Option B: In-App Admin (V2)**
- Add admin role check in the iOS app
- Show admin-only tabs when logged in as admin
- More convenient but more development effort

**Option C: Firebase Console (Quick Start)**
- For the very first version, admin can edit RTDB values directly in Firebase Console
- Not user-friendly but works as a stopgap

### Step 8.2 - Admin Capabilities

| Feature | Details |
|---|---|
| **Update rates** | Change buy/sell/high/low for any commodity in RTDB |
| **Set margins** | Adjust dealer premium and spread per commodity |
| **Toggle market** | Open/close market status |
| **Manage orders** | View all pending orders, confirm/cancel them |
| **Send notifications** | Broadcast messages to all users or specific segments |
| **Manage users** | View registered users, block/unblock |
| **Set config** | Update USD/INR rate, duty %, GST %, margins |

### Step 8.3 - Admin Authentication

- Create a custom claim `admin: true` on the Firebase user account
- Cloud Function `setAdminRole(uid)` can be called to promote a user
- Firestore and RTDB rules check `auth.token.admin === true` for write access
- In the iOS app, check custom claims to show/hide admin features

---

## Phase 9 - Offline & Caching

**Goal:** App remains usable even with poor connectivity (common in parts of India).

### Step 9.1 - Firebase Offline Support

Firebase RTDB has built-in offline persistence:
- Enable disk persistence: `Database.database().isPersistenceEnabled = true`
- Last known rates are cached locally
- When offline, app shows cached rates with an "Offline" indicator
- When connection resumes, RTDB auto-syncs

Firestore also has offline support:
- Enabled by default on iOS
- Orders, alerts, user data available offline
- Writes queue locally and sync when online

### Step 9.2 - User Experience When Offline

| Screen | Offline Behavior |
|---|---|
| Dashboard | Show last cached rates + "Offline" banner + stale timestamp |
| Booking | Allow filling form; disable submit button with "Requires connection" |
| Alerts | Show cached alerts; disable create (needs server validation) |
| News | Show cached news articles |
| Profile | Show cached profile; disable edit |

### Step 9.3 - Rate Staleness Indicator

If cached rates are older than a threshold (e.g., 5 minutes):
- Show a warning: "Rates may be outdated"
- Change the timestamp color to red/yellow
- Disable booking (stale rates should not be used for orders)

---

## Phase 10 - Testing

**Goal:** Ensure reliability of core business logic and user flows.

### Step 10.1 - Unit Tests

| Test Area | What to Test |
|---|---|
| RateCalculator | Spot to INR conversion, purity multipliers, duty/GST application, margin calculation |
| Models | Encoding/decoding, computed properties (change, changePercent, isUp, localPrice) |
| AuthViewModel | State transitions (loggedOut -> otpSent -> loggedIn), error handling |
| BookingViewModel | Form validation, rate lock capture, order creation |

### Step 10.2 - Integration Tests

| Test Area | What to Test |
|---|---|
| Firebase Auth | OTP send/verify flow (use Firebase Auth emulator) |
| Firestore | Order CRUD operations (use Firestore emulator) |
| RTDB | Rate listener setup/teardown, data parsing |

### Step 10.3 - UI Tests

| Flow | Steps to Automate |
|---|---|
| Login | Enter phone -> Send OTP -> Enter code -> Verify -> Dashboard appears |
| View rates | Dashboard loads -> Gold/silver rates visible -> Marquee scrolls |
| Place order | Tap Book tab -> Fill form -> Submit -> Confirmation alert |
| Create alert | Tap Alerts tab -> Tap + -> Fill form -> Create -> Alert in list |

### Step 10.4 - Edge Cases to Test

- Network disconnects mid-order submission
- Rate changes between user viewing and confirming order
- OTP timeout and resend
- Very large/small quantities in booking
- Concurrent rate updates (rapid fire)
- App backgrounding and foregrounding with active listeners
- Fresh install (no cached data)

### Step 10.5 - Firebase Emulators

Use Firebase Local Emulator Suite during development:
- Auth emulator (no real SMS sent)
- Firestore emulator (no cloud charges)
- RTDB emulator
- Functions emulator

Configure iOS app to connect to emulators in Debug builds.

---

## Phase 11 - Polish & Deployment

**Goal:** Production-ready app with App Store submission.

### Step 11.1 - UI Polish

- App icon: Gold/black themed with Laxmi Abhushan branding
- Launch screen: Branded splash with logo (use storyboard launch screen)
- Haptic feedback: Light tap on price change, medium on order submit
- Animations: Smooth number transitions when prices update
- Pull-to-refresh on dashboard (calls `viewModel.refreshRates()`)
- Skeleton loading states when data is first loading

### Step 11.2 - App Store Preparation

| Asset | Specification |
|---|---|
| App icon | 1024x1024 PNG, no alpha |
| Screenshots | 6.7" (iPhone 15 Pro Max), 6.1" (iPhone 15 Pro), 5.5" (iPhone 8 Plus) - at least 3 per size |
| App name | "Laxmi Abhushan - Live Gold Rate" |
| Subtitle | "Real-time bullion prices & booking" |
| Category | Finance |
| Keywords | gold rate, silver rate, bullion, live gold price, MCX gold, jewellery, gold booking |
| Privacy policy URL | Required - host on Firebase Hosting |
| Description | Detailed description of features |
| Age rating | 4+ (no restricted content) |

### Step 11.3 - TestFlight Beta

1. Archive the app in Xcode (Product > Archive)
2. Upload to App Store Connect
3. Create TestFlight group, add internal testers
4. Test all flows on real devices
5. Fix issues from beta feedback
6. Add external testers (up to 10,000) for broader testing

### Step 11.4 - Production Deployment

1. **Firebase:** Switch from development to production project
2. **Security rules:** Ensure Firestore and RTDB rules are locked down
3. **Cloud Functions:** Deploy all functions to production
4. **App Store Connect:** Submit for review
5. **Review notes:** Provide test phone number for Apple review team (Firebase Auth test numbers)
6. **Post-launch:** Monitor Firebase Crashlytics for crashes

### Step 11.5 - Post-Launch Monitoring

- Firebase Crashlytics for crash reports
- Firebase Analytics for user behavior
- Firebase Performance Monitoring for network latency
- Monitor RTDB bandwidth usage (watch for quota limits)
- Monitor Cloud Function invocations

---

## Phase 12 - V2 Features

**Goal:** Future enhancements after successful V1 launch.

### 12.1 - Price Charts & History

- Store daily OHLC (Open/High/Low/Close) in Firestore `/rate-history/`
- Use Swift Charts framework (iOS 16+) to display:
  - 1 Day, 1 Week, 1 Month, 3 Month, 1 Year views
  - Candlestick or line chart
  - Interactive: tap to see price at any point
- Cloud Function runs daily at market close to record OHLC

### 12.2 - Portfolio Tracker

- User enters their gold/silver holdings (quantity, purchase price, date)
- App calculates current value, profit/loss, percentage return
- Dashboard widget showing total portfolio value

### 12.3 - Multi-Dealer System

- Multiple dealers can register and set their own rates/margins
- Users can compare rates across dealers
- Each dealer gets their own admin panel
- Requires multi-tenancy in the database design

### 12.4 - AI/ML Predictions

- Collect historical price data
- Use Create ML or a backend ML service to predict short-term trends
- Show "Predicted trend: Bullish/Bearish" on dashboard
- This is a premium/engagement feature, not financial advice

### 12.5 - WhatsApp Integration

- Send rate updates via WhatsApp Business API
- Users can opt-in to daily rate summaries
- Order confirmations sent via WhatsApp

### 12.6 - Widget & Live Activities

- iOS Home Screen widget showing current gold/silver rate
- Live Activity on lock screen during market hours showing real-time price ticker
- Uses WidgetKit and ActivityKit

### 12.7 - Apple Watch Companion

- Glanceable gold rate on wrist
- Complication showing current price and change
- Alert notifications on watch

---

## Rate Calculation Reference

### Gold Rate Formula

```
Base Price (per gram) = Spot Price (USD/oz) / 31.1035 * USD_INR_Rate
With Duty              = Base Price * (1 + ImportDuty%)
With GST               = With Duty * (1 + GST%)
Per 10 grams           = With GST * 10
Buy Price              = Per 10 grams + Dealer Premium
Sell Price             = Buy Price - Spread
```

### Silver Rate Formula

```
Base Price (per gram) = Spot Price (USD/oz) / 31.1035 * USD_INR_Rate
With Duty              = Base Price * (1 + ImportDuty%)
With GST               = With Duty * (1 + GST%)
Per kg                 = With GST * 1000
Buy Price              = Per kg + Dealer Premium
Sell Price             = Buy Price - Spread
```

### Purity Adjustment

```
Price for Purity X = 24K Price * (X / 24)

22K = 24K * (22/24) = 24K * 0.9167
18K = 24K * (18/24) = 24K * 0.75
```

### Current Indian Duty Structure (as of 2026)

| Component | Rate | Notes |
|---|---|---|
| Basic Custom Duty | 10% | On gold/silver imports |
| Agriculture Infrastructure Cess | 5% | Additional import levy |
| **Total Import Duty** | **15%** | Applied on CIF value |
| GST | 3% | On (CIF + Import Duty) |

These percentages should be stored in Firebase config so they can be updated when government policy changes.

---

## Database Schema Reference

### Firebase Realtime Database (Live Rates)

```
/bullion-rates
  /gold
    /fine_995     { buyRate, sellRate, highRate, lowRate, previousClose, lastUpdated }
    /24k          { ... }
    /22k          { ... }
    /18k          { ... }
    /guinee       { ... }
    /petal        { ... }
  /silver
    /fine_999     { ... }
    /925          { ... }
    /micro        { ... }
  /spot
    /xau          { priceUSD, change, changePercent, lastUpdated }
    /xag          { ... }
  /local
    /gold         { mcxRate, localPremium, lastUpdated }
    /silver       { ... }
  /config
    { isMarketOpen, usdToInr, importDutyPercent, gstPercent, dealerMarginGold,
      dealerMarginSilver, spreadGold, spreadSilver, lastGlobalUpdate }
```

### Cloud Firestore (Business Data)

```
/users/{uid}
  { name, phone, city, businessName, role, fcmToken, createdAt }

/orders/{orderId}
  { userId, commodityName, type, quantity, unit, rateAtBooking,
    totalAmount, status, customerName, customerPhone, notes,
    createdAt, updatedAt, adminNote }

/alerts/{alertId}
  { userId, commodityName, targetPrice, direction, isActive,
    triggered, createdAt }

/news/{newsId}
  { title, body, publishedAt, category }

/rate-history/{YYYY-MM-DD}/{commodityId}
  { open, close, high, low }
```

---

## API Contract Reference

### Cloud Functions Endpoints

| Function | Trigger | Purpose |
|---|---|---|
| `onOrderCreated` | Firestore onCreate on `/orders` | Validate order, notify admin |
| `onOrderStatusChanged` | Firestore onUpdate on `/orders` | Notify user of status change |
| `evaluateAlerts` | RTDB onUpdate on `/bullion-rates` | Check all active alerts, send notifications |
| `fetchSpotPrices` | Cloud Scheduler (every 60s) | Fetch XAU/XAG from external API, write to RTDB |
| `recordDailyOHLC` | Cloud Scheduler (daily at market close) | Save daily price data to Firestore |
| `setAdminRole` | HTTPS callable | Promote user to admin (restricted) |
| `broadcastNotification` | HTTPS callable (admin only) | Send push to all users or segments |

---

## Implementation Priority & Order

Execute phases in this order for optimal development flow:

```
Week 1-2:   Phase 1 (Foundation) + Phase 2 (Firebase Setup)
Week 3:     Phase 3 (Authentication)
Week 4-5:   Phase 4 (Rate Engine) + Phase 5 (Real-Time Display)
Week 6:     Phase 6 (Order System)
Week 7:     Phase 7 (Notifications) + Phase 8 (Admin Panel)
Week 8:     Phase 9 (Offline) + Phase 10 (Testing)
Week 9:     Phase 11 (Polish + Deploy)
Post-launch: Phase 12 (V2 Features)
```

This is a 9-week timeline for a solo developer working full-time. Adjust based on team size and availability.

---

## Key Technical Decisions Summary

| Decision | Choice | Reasoning |
|---|---|---|
| UI Framework | SwiftUI | Modern, declarative, less boilerplate |
| Architecture | MVVM + Services | Clean separation, testable |
| State Management | Observation framework | Native iOS 17+, no Combine overhead |
| Backend | Firebase | Real-time native, no server management, fast MVP |
| Live Rates | Firebase RTDB | Sub-second updates, built-in offline, automatic sync |
| Business Data | Cloud Firestore | Structured queries, security rules, offline support |
| Auth | Firebase Phone Auth | Indian OTP out of the box |
| Server Logic | Cloud Functions | Triggered by data changes, no server to manage |
| Push | FCM | Integrated with Firebase ecosystem |
| Min iOS | 17.0 | Observation framework, modern SwiftUI APIs |

---

*This document serves as the single source of truth for the Laxmi Abhushan bullionTrader app development. Update it as decisions evolve.*
