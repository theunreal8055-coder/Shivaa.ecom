import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import path from 'path';

// Load gateway env variables for credentials
dotenv.config({ path: path.resolve('backend/api-gateway/.env') });

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

async function seedZerodha() {
  // ─── ENTER YOUR ZERODHA CREDENTIALS HERE ─────────────────────────────────
  const configValues = {
    use_mock_data: false, // Set to false to switch to live MCX data
    kite_api_key: 'YOUR_KITE_API_KEY_HERE',
    kite_api_secret: 'YOUR_KITE_API_SECRET_HERE',
    kite_gold_instrument_token: 223532,  // Update with current MCX Gold contract token
    kite_silver_instrument_token: 224345 // Update with current MCX Silver contract token
  };
  // ─────────────────────────────────────────────────────────────────────────

  console.log('🌱 Seeding Zerodha configurations to dealer_config table...');

  for (const [key, value] of Object.entries(configValues)) {
    const { error } = await supabase
      .from('dealer_config')
      .upsert({
        key,
        value,
        updated_at: new Date().toISOString()
      }, { onConflict: 'key' });

    if (error) {
      console.error(`❌ Failed to set ${key}:`, error.message);
    } else {
      console.log(`✅ Config set: ${key} = ${value}`);
    }
  }

  console.log('\n🎉 Finished seeding configurations! The ingestion worker and gateway will automatically hot-reload.');
}

seedZerodha();
