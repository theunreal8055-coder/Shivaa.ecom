import SwiftUI
import FirebaseCore
import FirebaseDatabase

class AppDelegate: NSObject, UIApplicationDelegate {

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {

        FirebaseApp.configure()
        Database.database().isPersistenceEnabled = true

        return true
    }
}

@main
struct bullionTraderApp: App {

    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate

    @State private var authService = AuthService()

    var body: some Scene {

        WindowGroup {

            ContentView()
                .preferredColorScheme(.dark)
                .environment(authService)
        }
    }
}
