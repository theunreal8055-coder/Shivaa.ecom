import SwiftUI

struct LoginView: View {
    @Environment(AuthService.self) private var authService

    @State private var email = ""
    @State private var showOTPSheet = false
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            AppTheme.background
                .ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                // MARK: - Branding
                VStack(spacing: 12) {
                    ZStack {
                        AppTheme.goldRadialGlow
                            .frame(width: 200, height: 200)
                            .blur(radius: 30)

                        Image(systemName: "building.columns.fill")
                            .font(.system(size: 48))
                            .foregroundStyle(AppTheme.goldGradient)
                    }

                    Text("LAXMI ABHUSHAN")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundStyle(AppTheme.goldGradient)
                        .tracking(2)

                    Text("Live Gold & Silver Rates")
                        .font(.subheadline)
                        .foregroundColor(AppTheme.textSecondary)
                }

                Spacer()

                Rectangle()
                    .fill(AppTheme.goldGradient)
                    .frame(width: 40, height: 1)
                    .padding(.bottom, 24)

                // MARK: - Login Card
                VStack(spacing: 20) {
                    Text("Login with Email")
                        .font(.title3.bold())
                        .foregroundColor(AppTheme.textPrimary)
                        .frame(maxWidth: .infinity, alignment: .leading)

                    TextField("Email address", text: $email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .foregroundColor(AppTheme.textPrimary)
                        .padding(14)
                        .background(AppTheme.surface)
                        .cornerRadius(10)

                    if let errorMessage {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundColor(AppTheme.priceDown)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }

                    Button {
                        sendOTP()
                    } label: {
                        HStack(spacing: 8) {
                            if authService.isLoading {
                                ProgressView()
                                    .tint(.black)
                            }
                            Text("Send OTP")
                                .fontWeight(.semibold)
                        }
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            !email.contains("@")
                                ? AnyShapeStyle(AppTheme.gold.opacity(0.4))
                                : AnyShapeStyle(AppTheme.goldGradient)
                        )
                        .cornerRadius(12)
                    }
                    .disabled(!email.contains("@") || authService.isLoading)
                }
                .padding(24)
                .background(AppTheme.cardBackground)
                .cornerRadius(16)
                .overlay(
                    RoundedRectangle(cornerRadius: 16)
                        .stroke(AppTheme.gold.opacity(0.2), lineWidth: 0.5)
                )
                .padding(.horizontal, 16)
                .padding(.bottom, 32)
            }
        }
        .sheet(isPresented: $showOTPSheet) {
            OTPVerificationView(email: email)
                .presentationDetents([.medium])
        }
    }

    private func sendOTP() {
        errorMessage = nil
        Task {
            do {
                try await authService.sendOTP(to: email)
                showOTPSheet = true
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
