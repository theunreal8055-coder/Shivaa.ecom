import SwiftUI
import Combine

struct OTPVerificationView: View {
    let email: String

    @Environment(AuthService.self) private var authService
    @Environment(\.dismiss) private var dismiss

    @State private var otp = ""
    @State private var errorMessage: String?
    @State private var resendCountdown = 30
    @State private var canResend = false
    @State private var timer: AnyCancellable?

    var body: some View {
        VStack(spacing: 20) {
            // MARK: - Header
            Text("Verify OTP")
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(.white)

            Text("Enter the 6-digit code sent to \(email)")
                .font(.subheadline)
                .foregroundColor(AppTheme.textSecondary)
                .multilineTextAlignment(.center)

            // MARK: - OTP Field
            TextField("000000", text: $otp)
                .keyboardType(.numberPad)
                .font(.system(size: 24, weight: .bold, design: .monospaced))
                .multilineTextAlignment(.center)
                .foregroundColor(AppTheme.textPrimary)
                .padding(16)
                .background(AppTheme.surface)
                .cornerRadius(12)
                .onChange(of: otp) { _, newValue in
                    if newValue.count > 6 {
                        otp = String(newValue.prefix(6))
                    }
                    errorMessage = nil
                }

            // MARK: - Error Message
            if let errorMessage {
                Text(errorMessage)
                    .font(.caption)
                    .foregroundColor(AppTheme.priceDown)
            }

            // MARK: - Verify Button
            Button {
                verifyOTP()
            } label: {
                HStack(spacing: 8) {
                    if authService.isLoading {
                        ProgressView()
                            .tint(.black)
                    }
                    Text("Verify")
                        .fontWeight(.semibold)
                }
                .foregroundColor(.black)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 16)
                .background(otp.count != 6 ? AppTheme.gold.opacity(0.4) : AppTheme.gold)
                .cornerRadius(12)
            }
            .disabled(otp.count != 6 || authService.isLoading)

            // MARK: - Resend
            if canResend {
                Button {
                    resendOTP()
                } label: {
                    Text("Resend OTP")
                        .font(.subheadline.bold())
                        .foregroundColor(AppTheme.gold)
                }
            } else {
                Text("Resend in \(resendCountdown)s")
                    .font(.subheadline)
                    .foregroundColor(AppTheme.textTertiary)
            }

            Spacer()
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppTheme.cardBackground)
        .onAppear {
            startResendTimer()
        }
        .onDisappear {
            timer?.cancel()
        }
    }

    // MARK: - Methods

    private func verifyOTP() {
        errorMessage = nil
        Task {
            do {
                try await authService.verifyOTP(email: email, code: otp)
                dismiss()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func resendOTP() {
        canResend = false
        resendCountdown = 30
        startResendTimer()
        Task {
            try? await authService.sendOTP(to: email)
        }
    }

    private func startResendTimer() {
        timer?.cancel()
        timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { _ in
                if resendCountdown > 1 {
                    resendCountdown -= 1
                } else {
                    canResend = true
                    timer?.cancel()
                }
            }
    }
}
