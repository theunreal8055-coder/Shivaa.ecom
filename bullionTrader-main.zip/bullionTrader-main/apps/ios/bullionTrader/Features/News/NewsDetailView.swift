import SwiftUI

struct NewsDetailView: View {
    @Binding var newsItem: MarketNews

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                HStack {
                    Text("MARKET NEWS")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(AppTheme.gold)
                        .tracking(0.5)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(AppTheme.gold.opacity(0.1))
                        .clipShape(Capsule())

                    Spacer()

                    Text(newsItem.publishedAt, style: .relative)
                        .font(.system(size: 12))
                        .foregroundColor(AppTheme.textTertiary)
                }

                Text(newsItem.title)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(AppTheme.textPrimary)

                Rectangle()
                    .fill(AppTheme.goldGradient)
                    .frame(height: 1)
                    .padding(.vertical, 4)

                Text(newsItem.body)
                    .font(.system(size: 16))
                    .foregroundColor(AppTheme.textSecondary)
                    .lineSpacing(6)
            }
            .padding(20)
        }
        .background(AppTheme.background.ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(AppTheme.cardBackground, for: .navigationBar)
        .toolbarBackground(.visible, for: .navigationBar)
        .onAppear {
            newsItem.isRead = true
        }
    }
}
