import SwiftUI

struct NewsView: View {
    @State private var news = MockData.news

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.background
                    .ignoresSafeArea()

                if news.isEmpty {
                    emptyState
                } else {
                    newsList
                }
            }
            .navigationTitle("Market Updates")
            .toolbarBackground(AppTheme.cardBackground, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            Image(systemName: "newspaper")
                .font(.system(size: 48))
                .foregroundColor(AppTheme.textTertiary)

            Text("No Market Updates")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)

            Text("Market news and updates will appear here. Check back later for the latest bullion market insights.")
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
    }

    private var newsList: some View {
        ScrollView {
            VStack(spacing: 10) {
                ForEach(news.indices, id: \.self) { index in
                    NavigationLink {
                        NewsDetailView(newsItem: $news[index])
                    } label: {
                        newsCard(index: index)
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
        }
    }

    private func newsCard(index: Int) -> some View {
        let item = news[index]
        return VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 8) {
                if !item.isRead {
                    Circle()
                        .fill(AppTheme.gold)
                        .frame(width: 8, height: 8)
                        .padding(.top, 5)
                }

                Text(item.title)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(AppTheme.textPrimary)
                    .lineLimit(2)

                Spacer()

                Text(relativeTime(from: item.publishedAt))
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(AppTheme.textTertiary)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(AppTheme.surface)
                    .clipShape(Capsule())
            }

            Text("MARKET NEWS")
                .font(.system(size: 9, weight: .bold))
                .foregroundColor(AppTheme.gold)
                .tracking(0.5)

            Text(item.body)
                .font(.system(size: 13))
                .foregroundColor(AppTheme.textSecondary)
                .lineLimit(3)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14)
        .background(AppTheme.cardBackground)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(item.isRead ? Color.clear : AppTheme.gold.opacity(0.2), lineWidth: 1)
        )
    }

    private func relativeTime(from date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .abbreviated
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}
