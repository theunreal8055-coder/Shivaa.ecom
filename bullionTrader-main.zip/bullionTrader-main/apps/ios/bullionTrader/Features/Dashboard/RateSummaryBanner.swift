import SwiftUI

/// Top-of-dashboard banner showing Gold 22K and Silver 999 buy rates at a glance.
struct RateSummaryBanner: View {
    let goldRates: [CommodityRate]
    let silverRates: [CommodityRate]

    private var gold22K: CommodityRate? {
        goldRates.first { $0.id == "gold_22k" } ?? goldRates.first { $0.category == .gold }
    }
    private var silver999: CommodityRate? {
        silverRates.first { $0.id == "silver_999" } ?? silverRates.first { $0.category == .silver }
    }

    var body: some View {
        HStack(spacing: 1) {
            if let gold = gold22K {
                summaryCell(rate: gold, isGold: true)
            }
            if let silver = silver999 {
                summaryCell(rate: silver, isGold: false)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(AppTheme.gold.opacity(0.2), lineWidth: 0.5)
        )
        .shadow(color: AppTheme.gold.opacity(0.08), radius: 10, x: 0, y: 4)
    }

    private func summaryCell(rate: CommodityRate, isGold: Bool) -> some View {
        let accent: Color = isGold ? AppTheme.gold : Color(hex: "C0C0C0")

        return VStack(alignment: .leading, spacing: 6) {
            // Name + unit
            HStack {
                Circle()
                    .fill(accent)
                    .frame(width: 6, height: 6)
                Text(rate.name.uppercased())
                    .font(.system(size: 10, weight: .bold))
                    .foregroundColor(accent)
                    .tracking(0.8)
                Spacer()
                Text("per \(rate.unit)")
                    .font(.system(size: 9))
                    .foregroundColor(AppTheme.textTertiary)
            }

            // BUY rate — hero number
            Text(formatINR(rate.buyRate))
                .font(.system(size: 22, weight: .bold, design: .monospaced))
                .foregroundColor(isGold ? AppTheme.goldLight : .white)
                .contentTransition(.numericText())

            // Sell + change
            HStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("SELL")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(AppTheme.textTertiary)
                        .tracking(0.5)
                    Text(formatINR(rate.sellRate))
                        .font(.system(size: 13, weight: .semibold, design: .monospaced))
                        .foregroundColor(AppTheme.textSecondary)
                        .contentTransition(.numericText())
                }

                Spacer()

                HStack(spacing: 3) {
                    Image(systemName: rate.isUp ? "arrowtriangle.up.fill" : "arrowtriangle.down.fill")
                        .font(.system(size: 7))
                    Text(formatPercent(rate.changePercent))
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                        .contentTransition(.numericText())
                }
                .foregroundColor(rate.isUp ? AppTheme.priceUp : AppTheme.priceDown)
                .padding(.horizontal, 7)
                .padding(.vertical, 4)
                .background(
                    Capsule()
                        .fill((rate.isUp ? AppTheme.priceUp : AppTheme.priceDown).opacity(0.12))
                )
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            ZStack {
                AppTheme.cardBackground
                // subtle gradient tint
                LinearGradient(
                    colors: [accent.opacity(0.06), Color.clear],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            }
        )
    }
}
