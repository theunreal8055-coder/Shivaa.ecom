import SwiftUI

struct SpotRateBarView: View {
    let spotRates: [SpotRate]

    var body: some View {
        HStack(spacing: 0) {
            ForEach(Array(spotRates.enumerated()), id: \.element.id) { index, spot in
                if index > 0 {
                    Rectangle()
                        .fill(AppTheme.divider)
                        .frame(width: 1, height: 22)
                }
                spotItem(spot)
                    .frame(maxWidth: .infinity)
            }
        }
        .frame(height: 40)
        .background(AppTheme.cardBackground)
        .overlay(alignment: .top)    { Rectangle().fill(AppTheme.divider).frame(height: 0.5) }
        .overlay(alignment: .bottom) { Rectangle().fill(AppTheme.divider).frame(height: 0.5) }
    }

    private func spotItem(_ spot: SpotRate) -> some View {
        HStack(spacing: 6) {
            Text(spot.symbol)
                .font(.system(size: 11, weight: .bold))
                .foregroundColor(AppTheme.gold)

            Text(formatUSD(spot.priceUSD))
                .font(.system(size: 12, weight: .semibold, design: .monospaced))
                .foregroundColor(AppTheme.textPrimary)
                .contentTransition(.numericText())

            Rectangle()
                .fill(AppTheme.divider)
                .frame(width: 1, height: 12)

            Text("₹\(formatINR(spot.priceUSD / 31.1035, showSymbol: false))/g")
                .font(.system(size: 10, weight: .medium, design: .monospaced))
                .foregroundColor(AppTheme.textSecondary)
                .contentTransition(.numericText())

            Text(formatPercent(spot.changePercent))
                .font(.system(size: 10, weight: .semibold, design: .monospaced))
                .foregroundColor(spot.isUp ? AppTheme.priceUp : AppTheme.priceDown)
                .contentTransition(.numericText())
                .padding(.horizontal, 5)
                .padding(.vertical, 2)
                .background(
                    RoundedRectangle(cornerRadius: 4)
                        .fill(spot.isUp ? AppTheme.priceUp.opacity(0.13) : AppTheme.priceDown.opacity(0.13))
                )
        }
    }
}
