import SwiftUI

struct RateRowView: View {
    let rate: CommodityRate

    @State private var flashOpacity: Double = 0
    @State private var flashUp: Bool = true

    var body: some View {
        VStack(spacing: 10) {
            // Top row: name + purity | change pill
            HStack {
                HStack(spacing: 8) {
                    Circle()
                        .fill(rate.category == .gold ? AppTheme.gold : AppTheme.textSecondary)
                        .frame(width: 7, height: 7)

                    Text(rate.name)
                        .font(.subheadline)
                        .fontWeight(.semibold)
                        .foregroundColor(AppTheme.textPrimary)

                    Text(rate.purity)
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(AppTheme.textSecondary)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(RoundedRectangle(cornerRadius: 4).fill(AppTheme.surface))
                }

                Spacer()

                changePill
            }

            // Price row: BUY | SELL | HIGH | LOW
            HStack(spacing: 0) {
                priceColumn(label: "BUY",  value: rate.buyRate,  isPrimary: true,  align: .leading)
                priceColumn(label: "SELL", value: rate.sellRate, isPrimary: true,  align: .center)
                priceColumn(label: "HIGH", value: rate.highRate, isPrimary: false, align: .center)
                priceColumn(label: "LOW",  value: rate.lowRate,  isPrimary: false, align: .trailing)
            }

            // Unit label
            Text("per \(rate.unit)")
                .font(.system(size: 10))
                .foregroundColor(AppTheme.textTertiary)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding(12)
        .background(
            ZStack {
                RoundedRectangle(cornerRadius: 10).fill(AppTheme.cardBackground)
                RoundedRectangle(cornerRadius: 10)
                    .fill(flashUp ? AppTheme.priceUp : AppTheme.priceDown)
                    .opacity(flashOpacity)
            }
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(AppTheme.border, lineWidth: 0.5)
        )
        .accentBar(color: rate.category == .gold ? AppTheme.gold : AppTheme.textSecondary)
        .shadow(color: Color.black.opacity(0.15), radius: 4, x: 0, y: 2)
        .onChange(of: rate.buyRate) { old, new in
            guard old != 0 else { return }
            flashUp = new >= old
            withAnimation(.easeIn(duration: 0.06)) { flashOpacity = 0.14 }
            withAnimation(.easeOut(duration: 0.55).delay(0.1)) { flashOpacity = 0 }
        }
    }

    // MARK: - Subviews

    private var changePill: some View {
        HStack(spacing: 4) {
            Image(systemName: rate.isUp ? "arrowtriangle.up.fill" : "arrowtriangle.down.fill")
                .font(.system(size: 8))
            Text(formatChange(rate.change))
                .font(.system(size: 11, weight: .semibold, design: .monospaced))
                .contentTransition(.numericText())
            Text(formatPercent(rate.changePercent))
                .font(.system(size: 10, weight: .medium, design: .monospaced))
                .opacity(0.8)
                .contentTransition(.numericText())
        }
        .foregroundColor(rate.isUp ? AppTheme.priceUp : AppTheme.priceDown)
        .padding(.horizontal, 8)
        .padding(.vertical, 5)
        .background(
            RoundedRectangle(cornerRadius: 6)
                .fill(rate.isUp ? AppTheme.priceUp.opacity(0.13) : AppTheme.priceDown.opacity(0.13))
        )
    }

    private func priceColumn(label: String, value: Double, isPrimary: Bool, align: HorizontalAlignment) -> some View {
        VStack(alignment: align, spacing: 4) {
            Text(label)
                .font(.system(size: isPrimary ? 10 : 9, weight: .semibold))
                .foregroundColor(isPrimary ? AppTheme.textSecondary : AppTheme.textTertiary)
                .tracking(0.5)

            Text(formatINR(value, showSymbol: false))
                .font(.system(size: isPrimary ? 17 : 13, weight: isPrimary ? .bold : .regular, design: .monospaced))
                .foregroundColor(isPrimary
                    ? (label == "BUY" ? AppTheme.goldLight : AppTheme.textPrimary)
                    : AppTheme.textSecondary)
                .contentTransition(.numericText())
        }
        .frame(maxWidth: .infinity, alignment: Alignment(horizontal: align, vertical: .center))
    }
}
