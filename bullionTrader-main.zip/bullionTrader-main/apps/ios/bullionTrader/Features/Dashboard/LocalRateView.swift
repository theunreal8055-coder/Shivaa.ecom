import SwiftUI

struct LocalRateView: View {
    let localRates: [LocalRate]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Section header
            HStack {
                HStack(spacing: 6) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.system(size: 14))
                        .foregroundColor(AppTheme.gold)

                    Text("LOCAL DELIVERY RATES")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundColor(AppTheme.gold)
                        .tracking(0.5)
                }

                Spacer()

                Text("Rajkot")
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(AppTheme.textSecondary)
            }
            .padding(.horizontal, 14)
            .padding(.top, 14)

            // Rate cards
            ForEach(localRates) { rate in
                localRateCard(rate)
            }
            .padding(.horizontal, 14)
            .padding(.bottom, 14)
        }
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(AppTheme.cardBackground)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(AppTheme.gold.opacity(0.25), lineWidth: 0.5)
        )
    }

    private func localRateCard(_ rate: LocalRate) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            // Commodity name header
            HStack(spacing: 6) {
                Circle()
                    .fill(rate.category == .gold ? AppTheme.gold : AppTheme.textSecondary)
                    .frame(width: 6, height: 6)

                Text(rate.commodityName)
                    .font(.caption)
                    .fontWeight(.semibold)
                    .foregroundColor(AppTheme.textPrimary)
            }

            // Card with MCX, Premium, Delivery Price
            VStack(spacing: 10) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("MCX Rate")
                            .font(.system(size: 10))
                            .foregroundColor(AppTheme.textTertiary)
                        Text(formatINR(rate.mcxRate))
                            .font(.system(size: 13, weight: .medium, design: .monospaced))
                            .foregroundColor(AppTheme.textSecondary)
                    }

                    Spacer()

                    VStack(alignment: .trailing, spacing: 2) {
                        Text("Local Premium")
                            .font(.system(size: 10))
                            .foregroundColor(AppTheme.textTertiary)
                        Text("+\(formatINR(rate.localPremium))")
                            .font(.system(size: 13, weight: .semibold, design: .monospaced))
                            .foregroundColor(AppTheme.gold)
                    }
                }

                Rectangle()
                    .fill(AppTheme.divider)
                    .frame(height: 0.5)

                HStack {
                    Text("Delivery Price")
                        .font(.system(size: 10))
                        .foregroundColor(AppTheme.textTertiary)

                    Spacer()

                    Text(formatINR(rate.localPrice))
                        .font(.system(size: 18, weight: .bold, design: .monospaced))
                        .foregroundColor(AppTheme.goldLight)
                }

                Text("per \(rate.unit)")
                    .font(.system(size: 9))
                    .foregroundColor(AppTheme.textTertiary)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            .padding(10)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(AppTheme.surface)
            )
        }
    }
}
