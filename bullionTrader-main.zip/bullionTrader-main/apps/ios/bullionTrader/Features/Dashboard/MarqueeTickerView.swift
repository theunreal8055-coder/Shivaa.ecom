import SwiftUI
import Combine

struct MarqueeTickerView: View {
    let rates: [CommodityRate]

    @State private var offset: CGFloat = 0
    @State private var contentWidth: CGFloat = 0

    private let timer = Timer.publish(every: 0.03, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geometry in
            HStack(spacing: 0) {
                tickerContent
                    .background(
                        GeometryReader { contentGeometry in
                            Color.clear
                                .preference(
                                    key: ContentWidthPreferenceKey.self,
                                    value: contentGeometry.size.width
                                )
                            }
                    )
                tickerContent
            }
            .offset(x: offset)
            .onPreferenceChange(ContentWidthPreferenceKey.self) { width in
                contentWidth = width
            }
            .onReceive(timer) { _ in
                guard contentWidth > 0 else { return }
                offset -= 0.8
                if -offset >= contentWidth {
                    offset = 0
                }
            }
        }
        .frame(height: 36)
        .background(AppTheme.surface)
        .clipped()
        .overlay(alignment: .leading) {
            LinearGradient(
                colors: [AppTheme.surface, AppTheme.surface.opacity(0)],
                startPoint: .leading,
                endPoint: .trailing
            )
            .frame(width: 24)
        }
        .overlay(alignment: .trailing) {
            LinearGradient(
                colors: [AppTheme.surface.opacity(0), AppTheme.surface],
                startPoint: .leading,
                endPoint: .trailing
            )
            .frame(width: 24)
        }
    }

    private var tickerContent: some View {
        HStack(spacing: 24) {
            ForEach(rates) { rate in
                HStack(spacing: 8) {
                    Circle()
                        .fill(rate.category == .gold ? AppTheme.gold : AppTheme.textSecondary)
                        .frame(width: 6, height: 6)

                    Text(rate.name)
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundColor(AppTheme.textPrimary)

                    Text(formatINR(rate.buyRate))
                        .font(.system(.caption, design: .monospaced))
                        .fontWeight(.semibold)
                        .foregroundColor(AppTheme.textPrimary)

                    HStack(spacing: 2) {
                        Image(systemName: rate.isUp ? "arrowtriangle.up.fill" : "arrowtriangle.down.fill")
                            .font(.system(size: 8))
                        Text(formatChange(rate.change))
                            .font(.system(.caption2, design: .monospaced))
                    }
                    .foregroundColor(rate.isUp ? AppTheme.priceUp : AppTheme.priceDown)
                }
            }
        }
        .padding(.horizontal, 16)
    }
}

private struct ContentWidthPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}
