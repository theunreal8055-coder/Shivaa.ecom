import SwiftUI

struct InternationalRatesView: View {
    let spotRates: [SpotRate]

    var body: some View {
        VStack(spacing: 12) {
            // Section Header
            HStack(spacing: 6) {
                Image(systemName: "globe.americas.fill")
                    .font(.system(size: 12))
                    .foregroundStyle(AppTheme.gold)
                Text("INTERNATIONAL RATES (USD)")
                    .font(.system(size: 12, weight: .bold))
                    .foregroundStyle(AppTheme.gold)
                    .tracking(0.5)
                Rectangle()
                    .fill(AppTheme.gold.opacity(0.3))
                    .frame(height: 0.5)
            }

            ForEach(spotRates) { rate in
                dollarRateCard(rate)
            }
        }
    }

    private func dollarRateCard(_ rate: SpotRate) -> some View {
        VStack(spacing: 10) {
            // Top: Name + Change pill
            HStack {
                HStack(spacing: 8) {
                    Circle()
                        .fill(rate.symbol == "XAU" ? AppTheme.gold : Color.gray.opacity(0.7))
                        .frame(width: 8, height: 8)
                    Text(rate.name)
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.white)
                    Text(rate.symbol)
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(AppTheme.textTertiary)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(AppTheme.surface)
                        .clipShape(RoundedRectangle(cornerRadius: 4))
                }

                Spacer()

                HStack(spacing: 3) {
                    Image(systemName: rate.isUp ? "arrowtriangle.up.fill" : "arrowtriangle.down.fill")
                        .font(.system(size: 8))
                    Text(formatPercent(rate.changePercent))
                        .font(.system(size: 11, weight: .bold, design: .monospaced))
                }
                .foregroundStyle(rate.isUp ? AppTheme.priceUp : AppTheme.priceDown)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background((rate.isUp ? AppTheme.priceUp : AppTheme.priceDown).opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 6))
            }

            // Price row
            HStack(alignment: .bottom) {
                // Per Ounce
                VStack(alignment: .leading, spacing: 2) {
                    Text("PER OUNCE")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(AppTheme.textTertiary)
                    Text(formatUSD(rate.priceUSD))
                        .font(.system(size: 20, weight: .bold, design: .monospaced))
                        .foregroundStyle(.white)
                }

                Spacer()

                // Per Gram
                VStack(alignment: .center, spacing: 2) {
                    Text("PER GRAM")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(AppTheme.textTertiary)
                    Text(formatUSD(rate.priceUSD / 31.1035))
                        .font(.system(size: 14, weight: .semibold, design: .monospaced))
                        .foregroundStyle(AppTheme.textSecondary)
                }

                Spacer()

                // Change
                VStack(alignment: .trailing, spacing: 2) {
                    Text("CHANGE")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundStyle(AppTheme.textTertiary)
                    Text("\(rate.change >= 0 ? "+" : "")\(formatUSD(rate.change))")
                        .font(.system(size: 14, weight: .semibold, design: .monospaced))
                        .foregroundStyle(rate.isUp ? AppTheme.priceUp : AppTheme.priceDown)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(AppTheme.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 10))
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(AppTheme.border, lineWidth: 0.5)
        )
    }
}
