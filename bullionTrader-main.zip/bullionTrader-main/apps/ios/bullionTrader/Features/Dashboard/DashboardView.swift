import SwiftUI

struct DashboardView: View {
    @State private var viewModel = DashboardViewModel()
    @State private var livePulse = false

    var body: some View {
        NavigationStack {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 0) {
                    // 1. Marquee ticker
                    MarqueeTickerView(rates: viewModel.allRates)

                    // 2. Spot rate bar (XAU/XAG in USD + INR/g)
                    SpotRateBarView(spotRates: viewModel.spotRates)
                        .padding(.top, 1)

                    VStack(spacing: 16) {
                        // 3. Hero summary banner — Gold 22K + Silver 999
                        if !viewModel.goldRates.isEmpty || !viewModel.silverRates.isEmpty {
                            RateSummaryBanner(
                                goldRates: viewModel.goldRates,
                                silverRates: viewModel.silverRates
                            )
                        }

                        // 4. Gold rates section
                        sectionHeader(title: "GOLD RATES", color: AppTheme.gold)

                        ForEach(viewModel.goldRates) { rate in
                            RateRowView(rate: rate)
                                .animation(.easeInOut(duration: 0.3), value: rate)
                        }

                        // 5. Silver rates section
                        sectionHeader(title: "SILVER RATES", color: AppTheme.textSecondary)

                        ForEach(viewModel.silverRates) { rate in
                            RateRowView(rate: rate)
                                .animation(.easeInOut(duration: 0.3), value: rate)
                        }

                        // 6. International rates (USD)
                        InternationalRatesView(spotRates: viewModel.spotRates)
                            .padding(.top, 4)

                        // 7. Local delivery rates
                        LocalRateView(localRates: viewModel.localRates)

                        // 8. Quick action buttons
                        HStack(spacing: 12) {
                            Button {
                                if let url = URL(string: "tel://") {
                                    UIApplication.shared.open(url)
                                }
                            } label: {
                                Label("Call to Book", systemImage: "phone.fill")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundColor(.white)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 46)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(LinearGradient(
                                                colors: [AppTheme.priceUp, AppTheme.priceUp.opacity(0.75)],
                                                startPoint: .top, endPoint: .bottom
                                            ))
                                    )
                                    .shadow(color: AppTheme.priceUp.opacity(0.3), radius: 8, y: 3)
                            }

                            Button {} label: {
                                Label("Enquire", systemImage: "bubble.left.fill")
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundColor(.black)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 46)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(AppTheme.goldGradient)
                                    )
                                    .shadow(color: AppTheme.gold.opacity(0.3), radius: 8, y: 3)
                            }
                        }

                        // 9. Footer: last updated + market status
                        HStack {
                            Text("Updated \(viewModel.lastUpdated, style: .time)")
                                .font(.system(size: 10))
                                .foregroundColor(AppTheme.textTertiary)

                            Spacer()

                            marketStatusBadge
                        }
                        .padding(.bottom, 24)
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 14)
                }
            }
            .background(AppTheme.background.ignoresSafeArea())
            .refreshable { viewModel.refreshRates() }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    HStack(spacing: 8) {
                        liveDot
                        Text("LAXMI ABHUSHAN")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(AppTheme.gold)
                            .tracking(1)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { viewModel.refreshRates() } label: {
                        Image(systemName: "arrow.clockwise")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(AppTheme.textSecondary)
                    }
                }
            }
            .toolbarBackground(AppTheme.cardBackground, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }

    // MARK: - Subviews

    private var liveDot: some View {
        ZStack {
            Circle()
                .fill(AppTheme.priceUp.opacity(0.3))
                .frame(width: livePulse ? 16 : 10, height: livePulse ? 16 : 10)
            Circle()
                .fill(AppTheme.priceUp)
                .frame(width: 8, height: 8)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 1.1).repeatForever(autoreverses: true)) {
                livePulse = true
            }
        }
    }

    private var marketStatusBadge: some View {
        HStack(spacing: 5) {
            Circle()
                .fill(viewModel.isMarketOpen ? AppTheme.priceUp : AppTheme.priceDown)
                .frame(width: 6, height: 6)
            Text(viewModel.isMarketOpen ? "Market Open" : "Market Closed")
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(viewModel.isMarketOpen ? AppTheme.priceUp : AppTheme.priceDown)
        }
        .padding(.horizontal, 9)
        .padding(.vertical, 4)
        .background(
            Capsule()
                .fill((viewModel.isMarketOpen ? AppTheme.priceUp : AppTheme.priceDown).opacity(0.1))
        )
    }

    private func sectionHeader(title: String, color: Color) -> some View {
        HStack(spacing: 10) {
            Circle()
                .fill(color)
                .frame(width: 7, height: 7)
                .overlay(Circle().fill(color.opacity(0.3)).frame(width: 13, height: 13))

            Text(title)
                .font(.system(size: 12, weight: .heavy))
                .foregroundColor(color)
                .tracking(2)

            Rectangle()
                .fill(LinearGradient(
                    colors: [color.opacity(0.4), color.opacity(0.0)],
                    startPoint: .leading, endPoint: .trailing
                ))
                .frame(height: 0.5)
        }
        .padding(.top, 6)
    }
}
