import SwiftUI

struct AlertsView: View {
    @State private var alerts = MockData.alerts
    @State private var showCreateAlert = false

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.background
                    .ignoresSafeArea()

                if alerts.isEmpty {
                    emptyState
                } else {
                    alertsList
                }
            }
            .navigationTitle("Price Alerts")
            .toolbarBackground(AppTheme.cardBackground, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showCreateAlert = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .foregroundColor(AppTheme.gold)
                    }
                }
            }
            .sheet(isPresented: $showCreateAlert) {
                CreateAlertView { newAlert in
                    alerts.append(newAlert)
                }
                .presentationDetents([.medium])
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill(AppTheme.gold.opacity(0.1))
                    .frame(width: 100, height: 100)
                Image(systemName: "bell.badge")
                    .font(.system(size: 44))
                    .foregroundStyle(AppTheme.goldGradient)
            }

            Text("No Price Alerts")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)

            Text("Set up alerts to get notified when prices reach your target.")
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)

            Button {
                showCreateAlert = true
            } label: {
                Text("Create Alert")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.black)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                    .background(AppTheme.gold)
                    .cornerRadius(10)
            }
            .padding(.top, 8)
        }
    }

    private var alertsList: some View {
        ScrollView {
            VStack(spacing: 10) {
                ForEach($alerts) { $alert in
                    alertRow(alert: $alert)
                }
            }
            .padding(.horizontal, 16)
            .padding(.top, 8)
        }
    }

    private func alertRow(alert: Binding<PriceAlert>) -> some View {
        HStack(spacing: 12) {
            Image(systemName: alert.wrappedValue.direction == .above ? "arrow.up.circle.fill" : "arrow.down.circle.fill")
                .font(.system(size: 28))
                .foregroundColor(alert.wrappedValue.direction == .above ? AppTheme.priceUp : AppTheme.priceDown)

            VStack(alignment: .leading, spacing: 4) {
                Text(alert.wrappedValue.commodityName)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(AppTheme.textPrimary)

                Text("When price goes \(alert.wrappedValue.direction.rawValue.lowercased()) \(formatINR(alert.wrappedValue.targetPrice))")
                    .font(.system(size: 12))
                    .foregroundColor(AppTheme.textSecondary)
            }

            Spacer()

            Toggle("", isOn: alert.isActive)
                .labelsHidden()
                .tint(AppTheme.gold)
        }
        .padding(14)
        .background(AppTheme.cardBackground)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(AppTheme.border, lineWidth: 0.5)
        )
        .accentBar(color: alert.wrappedValue.direction == .above ? AppTheme.priceUp : AppTheme.priceDown)
    }
}

struct CreateAlertView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var selectedCommodity = "Gold Fine 995"
    @State private var targetPriceText = ""
    @State private var direction: PriceAlert.AlertDirection = .above

    let commodities = ["Gold Fine 995", "Gold 24K", "Gold 22K", "Silver Fine 999", "Silver 925"]
    var onCreate: (PriceAlert) -> Void

    var body: some View {
        VStack(spacing: 20) {
            Text("Create Price Alert")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)
                .padding(.top, 8)

            VStack(alignment: .leading, spacing: 8) {
                Text("Commodity")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(AppTheme.textSecondary)

                Picker("Commodity", selection: $selectedCommodity) {
                    ForEach(commodities, id: \.self) { commodity in
                        Text(commodity).tag(commodity)
                    }
                }
                .pickerStyle(.menu)
                .tint(AppTheme.gold)
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Target Price")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(AppTheme.textSecondary)

                TextField("Enter target price", text: $targetPriceText)
                    .keyboardType(.numberPad)
                    .font(.system(size: 16, design: .monospaced))
                    .foregroundColor(AppTheme.textPrimary)
                    .padding(12)
                    .background(AppTheme.surface)
                    .cornerRadius(8)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Direction")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(AppTheme.textSecondary)

                Picker("Direction", selection: $direction) {
                    Text("Above").tag(PriceAlert.AlertDirection.above)
                    Text("Below").tag(PriceAlert.AlertDirection.below)
                }
                .pickerStyle(.segmented)
            }

            Spacer()

            Button {
                let price = Double(targetPriceText) ?? 0
                let newAlert = PriceAlert(
                    id: UUID().uuidString,
                    commodityName: selectedCommodity,
                    targetPrice: price,
                    direction: direction,
                    isActive: true,
                    createdAt: Date()
                )
                onCreate(newAlert)
                dismiss()
            } label: {
                Text("Create Alert")
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
                    .background(AppTheme.gold)
                    .cornerRadius(10)
            }
        }
        .padding(24)
        .background(AppTheme.cardBackground.ignoresSafeArea())
    }
}
