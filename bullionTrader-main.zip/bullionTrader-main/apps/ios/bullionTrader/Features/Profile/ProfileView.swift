import SwiftUI
import Auth

struct ProfileView: View {
    @Environment(AuthService.self) private var authService
    @State private var notificationsEnabled = true
    @State private var darkModeEnabled = true

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.background
                    .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 20) {
                        userHeader
                        preferencesSection
                        contactSection
                        aboutSection
                        signOutButton
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 8)
                    .padding(.bottom, 24)
                }
            }
            .navigationTitle("Profile")
            .toolbarBackground(AppTheme.cardBackground, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
        }
    }

    // MARK: - User Header

    private var userHeader: some View {
        VStack(spacing: 8) {
            Image(systemName: "person.circle.fill")
                .font(.system(size: 56))
                .foregroundColor(AppTheme.textSecondary)
                .background(
                    Circle()
                        .strokeBorder(AppTheme.goldGradient, lineWidth: 2.5)
                        .frame(width: 72, height: 72)
                )

            Text("Guest User")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(AppTheme.textPrimary)

            Text(authService.currentUser?.phone ?? "+91 — —")
                .font(.system(size: 14))
                .foregroundColor(AppTheme.textSecondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 20)
    }

    // MARK: - Preferences

    private var preferencesSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionHeader("PREFERENCES")

            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    iconBadge(systemName: "bell.fill", color: AppTheme.gold)

                    Text("Notifications")
                        .font(.system(size: 15))
                        .foregroundColor(AppTheme.textPrimary)

                    Spacer()

                    Toggle("", isOn: $notificationsEnabled)
                        .labelsHidden()
                        .tint(AppTheme.gold)
                }
                .padding(.vertical, 4)

                Divider()
                    .background(AppTheme.border)

                HStack(spacing: 12) {
                    iconBadge(systemName: "moon.fill", color: .purple)

                    Text("Dark Mode")
                        .font(.system(size: 15))
                        .foregroundColor(AppTheme.textPrimary)

                    Spacer()

                    Toggle("", isOn: $darkModeEnabled)
                        .labelsHidden()
                        .tint(AppTheme.gold)
                }
                .padding(.vertical, 4)
            }
            .padding(14)
            .background(AppTheme.cardBackground)
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(AppTheme.border, lineWidth: 0.5)
            )
        }
    }

    // MARK: - Contact

    private var contactSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionHeader("CONTACT LAXMI ABHUSHAN")

            VStack(spacing: 0) {
                Button {
                    if let url = URL(string: "tel://919876543210") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    contactRow(icon: "phone.fill", color: AppTheme.priceUp, title: "Call Us")
                }

                Divider()
                    .background(AppTheme.border)

                Button {
                    if let url = URL(string: "https://wa.me/919876543210") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    contactRow(icon: "message.fill", color: Color(hex: "25D366"), title: "WhatsApp")
                }

                Divider()
                    .background(AppTheme.border)

                Button {
                    // Visit Us action
                } label: {
                    contactRow(icon: "mappin.circle.fill", color: AppTheme.priceDown, title: "Visit Us")
                }
            }
            .padding(14)
            .background(AppTheme.cardBackground)
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(AppTheme.border, lineWidth: 0.5)
            )
        }
    }

    // MARK: - About

    private var aboutSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            sectionHeader("ABOUT")

            VStack(spacing: 0) {
                HStack {
                    Text("App Version")
                        .font(.system(size: 15))
                        .foregroundColor(AppTheme.textPrimary)

                    Spacer()

                    Text("1.0.0")
                        .font(.system(size: 15))
                        .foregroundColor(AppTheme.textSecondary)
                }
                .padding(.vertical, 4)

                Divider()
                    .background(AppTheme.border)

                Button {
                    // Privacy Policy action
                } label: {
                    HStack {
                        Text("Privacy Policy")
                            .font(.system(size: 15))
                            .foregroundColor(AppTheme.textPrimary)

                        Spacer()

                        Image(systemName: "chevron.right")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(AppTheme.textTertiary)
                    }
                    .padding(.vertical, 4)
                }
            }
            .padding(14)
            .background(AppTheme.cardBackground)
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(AppTheme.border, lineWidth: 0.5)
            )
        }
    }

    // MARK: - Sign Out

    private var signOutButton: some View {
        Button {
            Task { await authService.signOut() }
        } label: {
            Text("Sign Out")
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(AppTheme.priceDown)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(AppTheme.priceDown.opacity(0.1))
                .cornerRadius(10)
        }
        .padding(.top, 8)
    }

    // MARK: - Helpers

    private func sectionHeader(_ title: String) -> some View {
        Text(title)
            .font(.system(size: 11, weight: .bold))
            .foregroundColor(AppTheme.textTertiary)
            .padding(.leading, 4)
    }

    private func iconBadge(systemName: String, color: Color) -> some View {
        Image(systemName: systemName)
            .font(.system(size: 14))
            .foregroundColor(color)
            .frame(width: 32, height: 32)
            .background(color.opacity(0.12))
            .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    private func contactRow(icon: String, color: Color, title: String) -> some View {
        HStack(spacing: 12) {
            iconBadge(systemName: icon, color: color)

            Text(title)
                .font(.system(size: 15))
                .foregroundColor(AppTheme.textPrimary)

            Spacer()

            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(AppTheme.textTertiary)
        }
        .padding(.vertical, 4)
    }
}
