import SwiftUI

struct BookingView: View {
    @State private var selectedCommodity = "Gold Fine 995"
    @State private var quantity = ""
    @State private var customerName = ""
    @State private var customerPhone = ""
    @State private var notes = ""
    @State private var showConfirmationAlert = false
    @State private var selectedSegment = 0
    @State private var viewModel = DashboardViewModel()

    private var currentRate: CommodityRate? {
        viewModel.allRates.first { "\($0.name) \($0.purity)" == selectedCommodity }
    }

    private let commodities = [
        "Gold Fine 995",
        "Gold 24K",
        "Gold 22K",
        "Gold 18K",
        "Silver Fine 999",
        "Silver 925"
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // MARK: - Segment Picker
                    Picker("", selection: $selectedSegment) {
                        Text("New Booking").tag(0)
                        Text("My Orders").tag(1)
                    }
                    .pickerStyle(.segmented)

                    if selectedSegment == 1 {
                        VStack(spacing: 16) {
                            Spacer().frame(height: 40)
                            ZStack {
                                Circle()
                                    .fill(AppTheme.gold.opacity(0.1))
                                    .frame(width: 100, height: 100)
                                Image(systemName: "shippingbox")
                                    .font(.system(size: 44))
                                    .foregroundStyle(AppTheme.goldGradient)
                            }
                            Text("No Orders Yet")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundColor(AppTheme.textPrimary)
                            Text("Your booking orders will appear here.")
                                .font(.system(size: 14))
                                .foregroundColor(AppTheme.textSecondary)
                            Spacer().frame(height: 40)
                        }
                        .frame(maxWidth: .infinity)
                    }

                    if selectedSegment == 0 {
                    // MARK: - Current Rate Card
                    VStack(spacing: 8) {
                        HStack {
                            Text(selectedCommodity)
                                .font(.headline)
                                .foregroundColor(AppTheme.textPrimary)

                            Spacer()

                            HStack(spacing: 4) {
                                Circle()
                                    .fill(AppTheme.priceUp)
                                    .frame(width: 8, height: 8)
                                Text("LIVE")
                                    .font(.caption.bold())
                                    .foregroundColor(AppTheme.priceUp)
                            }
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(AppTheme.priceUp.opacity(0.15))
                            .clipShape(Capsule())
                        }

                        HStack(alignment: .firstTextBaseline) {
                            Text(formatINR(currentRate?.buyRate ?? 0))
                                .font(.system(size: 36, weight: .bold, design: .monospaced))
                                .foregroundColor(AppTheme.goldLight)

                            Spacer()

                            Text("per \(currentRate?.unit ?? "10 gm")")
                                .font(.subheadline)
                                .foregroundColor(AppTheme.textSecondary)
                        }
                    }
                    .padding(16)
                    .background(AppTheme.cardBackground)
                    .cornerRadius(12)

                    // MARK: - Booking Form
                    VStack(spacing: 16) {
                        // Commodity Picker
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Commodity")
                                .font(.subheadline)
                                .foregroundColor(AppTheme.textSecondary)

                            Picker("Commodity", selection: $selectedCommodity) {
                                ForEach(commodities, id: \.self) { commodity in
                                    Text(commodity).tag(commodity)
                                }
                            }
                            .pickerStyle(.menu)
                            .tint(AppTheme.gold)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(12)
                            .background(AppTheme.surface)
                            .cornerRadius(10)
                        }

                        // Quantity
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Quantity")
                                .font(.subheadline)
                                .foregroundColor(AppTheme.textSecondary)

                            HStack {
                                TextField("Enter quantity", text: $quantity)
                                    .keyboardType(.decimalPad)
                                    .foregroundColor(AppTheme.textPrimary)

                                Text("gm")
                                    .foregroundColor(AppTheme.textSecondary)
                            }
                            .padding(12)
                            .background(AppTheme.surface)
                            .cornerRadius(10)
                        }

                        // Customer Name
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Customer Name")
                                .font(.subheadline)
                                .foregroundColor(AppTheme.textSecondary)

                            TextField("Enter your full name", text: $customerName)
                                .foregroundColor(AppTheme.textPrimary)
                                .padding(12)
                                .background(AppTheme.surface)
                                .cornerRadius(10)
                        }

                        // Phone
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Phone Number")
                                .font(.subheadline)
                                .foregroundColor(AppTheme.textSecondary)

                            TextField("Enter phone number", text: $customerPhone)
                                .keyboardType(.phonePad)
                                .foregroundColor(AppTheme.textPrimary)
                                .padding(12)
                                .background(AppTheme.surface)
                                .cornerRadius(10)
                        }

                        // Notes
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Notes")
                                .font(.subheadline)
                                .foregroundColor(AppTheme.textSecondary)

                            TextField("Any special instructions...", text: $notes, axis: .vertical)
                                .lineLimit(3...5)
                                .foregroundColor(AppTheme.textPrimary)
                                .padding(12)
                                .background(AppTheme.surface)
                                .cornerRadius(10)
                        }
                    }
                    .padding(16)
                    .background(AppTheme.cardBackground)
                    .cornerRadius(12)

                    // MARK: - Action Buttons
                    VStack(spacing: 12) {
                        Button {
                            showConfirmationAlert = true
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "paperplane.fill")
                                Text("Submit Booking Enquiry")
                                    .fontWeight(.semibold)
                            }
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(AppTheme.gold)
                            .cornerRadius(12)
                        }

                        Button {
                            if let url = URL(string: "tel://+911234567890") {
                                UIApplication.shared.open(url)
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Image(systemName: "phone.fill")
                                Text("Call to Book Now")
                                    .fontWeight(.semibold)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(AppTheme.priceUp)
                            .cornerRadius(12)
                        }
                    }

                    // MARK: - Info Text
                    Text("Rates are subject to change. Final rate will be confirmed at the time of booking confirmation.")
                        .font(.caption)
                        .foregroundColor(AppTheme.textTertiary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 8)
                        .padding(.bottom, 16)
                    } // end if selectedSegment == 0
                }
                .padding(16)
            }
            .background(AppTheme.background)
            .navigationTitle("Book Gold & Silver")
            .navigationBarTitleDisplayMode(.large)
            .toolbarBackground(AppTheme.cardBackground, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
            .alert("Booking Submitted", isPresented: $showConfirmationAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Your booking enquiry has been submitted. We will call you shortly.")
            }
        }
    }
}
