import Foundation
import Observation

@Observable
class DashboardViewModel {
    var goldRates: [CommodityRate] = []
    var silverRates: [CommodityRate] = []
    var localRates: [LocalRate] = []
    var spotRates: [SpotRate] = []
    var isConnected: Bool = true
    var lastUpdated: Date = Date()
    var isMarketOpen: Bool = true

    var allRates: [CommodityRate] {
        goldRates + silverRates
    }

    private var rateService: RateServiceProtocol

    /// Auto-selects service in priority order:
    ///  1. Angel One SmartAPI credentials present → AngelOneMCXService (live MCX, 1s updates)
    ///  2. GoldAPI key present                   → LiveMetalsService (live international spot)
    ///  3. Nothing                               → SimulatedRateService (realistic fake data)
    init(rateService: RateServiceProtocol? = nil) {
        let service: RateServiceProtocol
        if let rateService {
            service = rateService
        } else if !Secrets.angelAPIKey.isEmpty && !Secrets.angelClientCode.isEmpty {
            service = AngelOneMCXService(
                apiKey:     Secrets.angelAPIKey,
                secretKey:  Secrets.angelSecretKey,
                clientCode: Secrets.angelClientCode,
                password:   Secrets.angelPassword,
                totpSecret: Secrets.angelTOTPSecret
            )
        } else if !Secrets.goldAPIKey.isEmpty {
            service = LiveMetalsService(apiKey: Secrets.goldAPIKey)
        } else {
            service = SimulatedRateService()
        }
        self.rateService = service
        self.rateService.onRatesUpdate = { [weak self] update in
            self?.applyUpdate(update)
        }
        self.rateService.startListening()
    }

    func refreshRates() {
        rateService.forceRefresh()
    }

    func pause() {
        rateService.stopListening()
    }

    func resume() {
        rateService.startListening()
    }

    private func applyUpdate(_ update: RateUpdate) {
        goldRates = update.goldRates
        silverRates = update.silverRates
        spotRates = update.spotRates
        localRates = update.localRates
        isMarketOpen = update.isMarketOpen
        lastUpdated = update.lastUpdated
        isConnected = true
    }
}
