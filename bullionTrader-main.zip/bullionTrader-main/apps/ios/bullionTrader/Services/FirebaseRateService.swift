import Foundation
import FirebaseDatabase

/// Listens to Firebase Realtime Database for live bullion rates.
/// The admin updates rates in RTDB; this service delivers them to the app instantly.
///
/// RTDB structure expected:
///   bullion-rates/
///     gold/   { fine_995: {buyRate, sellRate, ...}, 24k: {...}, ... }
///     silver/ { fine_999: {...}, 925: {...}, ... }
///     spot/   { xau: {priceUSD, change, ...}, xag: {...} }
///     local/  { gold: {mcxRate, localPremium, ...}, silver: {...} }
///     config/ { isMarketOpen, lastGlobalUpdate }
final class FirebaseRateService: RateServiceProtocol {
    var onRatesUpdate: ((RateUpdate) -> Void)?

    private let dbRef = Database.database().reference().child("bullion-rates")
    private var handles: [DatabaseHandle] = []

    private var goldRates: [CommodityRate] = []
    private var silverRates: [CommodityRate] = []
    private var spotRates: [SpotRate] = []
    private var localRates: [LocalRate] = []
    private var isMarketOpen: Bool = true

    func startListening() {
        listenToGold()
        listenToSilver()
        listenToSpot()
        listenToLocal()
        listenToConfig()
    }

    func stopListening() {
        for handle in handles {
            dbRef.removeObserver(withHandle: handle)
        }
        handles.removeAll()
    }

    func forceRefresh() {
        dbRef.getData { [weak self] error, snapshot in
            guard error == nil, let data = snapshot else { return }
            self?.parseFullSnapshot(data)
        }
    }

    deinit {
        stopListening()
    }

    // MARK: - Listeners

    private func listenToGold() {
        let handle = dbRef.child("gold").observe(.value) { [weak self] snapshot in
            guard let self, let dict = snapshot.value as? [String: [String: Any]] else { return }
            self.goldRates = dict.compactMap { key, value in
                self.parseCommodityRate(id: "gold_\(key)", data: value, category: .gold)
            }.sorted { $0.buyRate > $1.buyRate }
            self.fireUpdate()
        }
        handles.append(handle)
    }

    private func listenToSilver() {
        let handle = dbRef.child("silver").observe(.value) { [weak self] snapshot in
            guard let self, let dict = snapshot.value as? [String: [String: Any]] else { return }
            self.silverRates = dict.compactMap { key, value in
                self.parseCommodityRate(id: "silver_\(key)", data: value, category: .silver)
            }.sorted { $0.buyRate > $1.buyRate }
            self.fireUpdate()
        }
        handles.append(handle)
    }

    private func listenToSpot() {
        let handle = dbRef.child("spot").observe(.value) { [weak self] snapshot in
            guard let self, let dict = snapshot.value as? [String: [String: Any]] else { return }
            self.spotRates = dict.compactMap { key, value in
                self.parseSpotRate(id: key, data: value)
            }
            self.fireUpdate()
        }
        handles.append(handle)
    }

    private func listenToLocal() {
        let handle = dbRef.child("local").observe(.value) { [weak self] snapshot in
            guard let self, let dict = snapshot.value as? [String: [String: Any]] else { return }
            self.localRates = dict.compactMap { key, value in
                self.parseLocalRate(id: "local_\(key)", data: value)
            }
            self.fireUpdate()
        }
        handles.append(handle)
    }

    private func listenToConfig() {
        let handle = dbRef.child("config").observe(.value) { [weak self] snapshot in
            guard let self, let dict = snapshot.value as? [String: Any] else { return }
            self.isMarketOpen = dict["isMarketOpen"] as? Bool ?? true
            self.fireUpdate()
        }
        handles.append(handle)
    }

    // MARK: - Parsers

    private func parseCommodityRate(id: String, data: [String: Any], category: CommodityCategory) -> CommodityRate? {
        guard let buyRate = data["buyRate"] as? Double,
              let sellRate = data["sellRate"] as? Double else { return nil }

        return CommodityRate(
            id: id,
            name: data["name"] as? String ?? id,
            category: category,
            purity: data["purity"] as? String ?? "",
            unit: data["unit"] as? String ?? (category == .gold ? "10 gm" : "1 kg"),
            buyRate: buyRate,
            sellRate: sellRate,
            highRate: data["highRate"] as? Double ?? buyRate,
            lowRate: data["lowRate"] as? Double ?? buyRate,
            previousClose: data["previousClose"] as? Double ?? buyRate,
            lastUpdated: parseTimestamp(data["lastUpdated"])
        )
    }

    private func parseSpotRate(id: String, data: [String: Any]) -> SpotRate? {
        guard let priceUSD = data["priceUSD"] as? Double else { return nil }

        return SpotRate(
            id: id,
            name: data["name"] as? String ?? id,
            symbol: data["symbol"] as? String ?? id.uppercased(),
            priceUSD: priceUSD,
            change: data["change"] as? Double ?? 0,
            changePercent: data["changePercent"] as? Double ?? 0,
            lastUpdated: parseTimestamp(data["lastUpdated"])
        )
    }

    private func parseLocalRate(id: String, data: [String: Any]) -> LocalRate? {
        guard let mcxRate = data["mcxRate"] as? Double else { return nil }

        let categoryStr = data["category"] as? String ?? ""
        let category: CommodityCategory = categoryStr.lowercased() == "silver" ? .silver : .gold

        return LocalRate(
            id: id,
            commodityName: data["commodityName"] as? String ?? (category == .gold ? "Gold" : "Silver"),
            category: category,
            unit: data["unit"] as? String ?? (category == .gold ? "10 gm" : "1 kg"),
            mcxRate: mcxRate,
            localPremium: data["localPremium"] as? Double ?? 0,
            lastUpdated: parseTimestamp(data["lastUpdated"])
        )
    }

    private func parseTimestamp(_ value: Any?) -> Date {
        if let ms = value as? Double {
            return Date(timeIntervalSince1970: ms / 1000)
        }
        return Date()
    }

    private func parseFullSnapshot(_ snapshot: DataSnapshot) {
        guard let dict = snapshot.value as? [String: Any] else { return }

        if let goldDict = dict["gold"] as? [String: [String: Any]] {
            goldRates = goldDict.compactMap { parseCommodityRate(id: "gold_\($0.key)", data: $0.value, category: .gold) }
                .sorted { $0.buyRate > $1.buyRate }
        }
        if let silverDict = dict["silver"] as? [String: [String: Any]] {
            silverRates = silverDict.compactMap { parseCommodityRate(id: "silver_\($0.key)", data: $0.value, category: .silver) }
                .sorted { $0.buyRate > $1.buyRate }
        }
        if let spotDict = dict["spot"] as? [String: [String: Any]] {
            spotRates = spotDict.compactMap { parseSpotRate(id: $0.key, data: $0.value) }
        }
        if let localDict = dict["local"] as? [String: [String: Any]] {
            localRates = localDict.compactMap { parseLocalRate(id: "local_\($0.key)", data: $0.value) }
        }
        if let config = dict["config"] as? [String: Any] {
            isMarketOpen = config["isMarketOpen"] as? Bool ?? true
        }
        fireUpdate()
    }

    private func fireUpdate() {
        let update = RateUpdate(
            goldRates: goldRates,
            silverRates: silverRates,
            spotRates: spotRates,
            localRates: localRates,
            isMarketOpen: isMarketOpen,
            lastUpdated: Date()
        )
        onRatesUpdate?(update)
    }
}
