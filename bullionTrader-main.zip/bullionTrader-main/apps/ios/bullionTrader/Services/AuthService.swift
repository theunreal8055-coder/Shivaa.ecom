import Foundation
import Supabase

@Observable
class AuthService {
    var currentUser: User?
    var isAuthenticated: Bool { currentUser != nil }
    var isLoading = false
    var error: String?

    init() {
        Task {
            await restoreSession()
            await listenToAuthChanges()
        }
    }

    private func restoreSession() async {
        currentUser = try? await supabase.auth.session.user
    }

    private func listenToAuthChanges() async {
        for await (event, session) in supabase.auth.authStateChanges {
            await MainActor.run {
                switch event {
                case .signedIn, .tokenRefreshed, .userUpdated:
                    currentUser = session?.user
                case .signedOut:
                    currentUser = nil
                default:
                    break
                }
            }
        }
    }

    // MARK: - Email OTP

    func sendOTP(to email: String) async throws {
        isLoading = true
        error = nil
        defer { isLoading = false }

        do {
            try await supabase.auth.signInWithOTP(email: email)
        } catch let err {
            error = err.localizedDescription
            throw err
        }
    }

    func verifyOTP(email: String, code: String) async throws {
        isLoading = true
        error = nil
        defer { isLoading = false }

        do {
            let session = try await supabase.auth.verifyOTP(
                email: email,
                token: code,
                type: EmailOTPType.email
            )
            currentUser = session.user
        } catch let err {
            error = err.localizedDescription
            throw err
        }
    }

    func signOut() async {
        do {
            try await supabase.auth.signOut()
            currentUser = nil
        } catch {
            self.error = error.localizedDescription
        }
    }
}
