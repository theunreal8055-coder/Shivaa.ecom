import Foundation
import Supabase

let supabase = SupabaseClient(
    supabaseURL: URL(string: "https://sjytxyhmgffopmslcuux.supabase.co")!,
    supabaseKey: "sb_publishable_TusWlaGuwQwil-aeoRCwWw_iNNcN7pJ"
)
