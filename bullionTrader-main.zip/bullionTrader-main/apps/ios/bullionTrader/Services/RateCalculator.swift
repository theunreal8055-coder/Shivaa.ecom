import Foundation

struct RateConfig {
    var usdToInr: Double = 83.45
    var importDutyPercent: Double = 15.0
    var gstPercent: Double = 3.0
    var dealerMarginGoldPer10gm: Double = 2_000
    var dealerMarginSilverPerKg: Double = 1_500
    var spreadGold: Double = 150
    var spreadSilver: Double = 300
}

enum RateCalculator {

    static let purityMultipliers: [String: Double] = [
        "999": 1.0,
        "995": 0.996,
        "916": 22.0 / 24.0,
        "750": 18.0 / 24.0,
    ]

    /// Convert international spot price (USD per troy ounce) to INR per gram
    static func spotToINRPerGram(spotUSD: Double, config: RateConfig) -> Double {
        let perGramUSD = spotUSD / 31.1035
        let perGramINR = perGramUSD * config.usdToInr
        let withDuty = perGramINR * (1 + config.importDutyPercent / 100)
        let withGST = withDuty * (1 + config.gstPercent / 100)
        return withGST
    }

    /// Get price per 10 grams for a given purity
    static func goldPricePer10gm(spotUSD: Double, purity: String, config: RateConfig) -> Double {
        let basePerGram = spotToINRPerGram(spotUSD: spotUSD, config: config)
        let multiplier = purityMultipliers[purity] ?? 1.0
        return basePerGram * multiplier * 10 + config.dealerMarginGoldPer10gm
    }

    /// Get silver price per kg
    static func silverPricePerKg(spotUSD: Double, purity: String, config: RateConfig) -> Double {
        let basePerGram = spotToINRPerGram(spotUSD: spotUSD, config: config)
        let multiplier = purityMultipliers[purity] ?? 1.0
        return basePerGram * multiplier * 1000 + config.dealerMarginSilverPerKg
    }

    /// Apply a random fluctuation to a price
    static func fluctuate(
        _ price: Double,
        normalRange: ClosedRange<Double> = 0.0002...0.0008,
        spikeRange: ClosedRange<Double> = 0.002...0.005,
        spikeChance: Double = 0.10
    ) -> Double {
        let isSpike = Double.random(in: 0...1) < spikeChance
        let range = isSpike ? spikeRange : normalRange
        let percent = Double.random(in: range)
        let direction: Double = Bool.random() ? 1 : -1
        return price + (price * percent * direction)
    }
}
