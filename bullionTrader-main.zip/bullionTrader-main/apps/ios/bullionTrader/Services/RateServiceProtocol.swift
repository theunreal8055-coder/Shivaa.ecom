import Foundation

struct RateUpdate {
    let goldRates: [CommodityRate]
    let silverRates: [CommodityRate]
    let spotRates: [SpotRate]
    let localRates: [LocalRate]
    let isMarketOpen: Bool
    let lastUpdated: Date
}

protocol RateServiceProtocol {
    var onRatesUpdate: ((RateUpdate) -> Void)? { get set }
    func startListening()
    func stopListening()
    func forceRefresh()
}
