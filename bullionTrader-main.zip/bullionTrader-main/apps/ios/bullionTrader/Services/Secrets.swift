// MARK: - API Keys

enum Secrets {

    // MARK: Angel One SmartAPI (live MCX data — priority source)
    // Get credentials at: https://smartapi.angelbroking.com → Create App
    static let angelAPIKey      = "WfMUkgNs"   // ← API key from SmartAPI portal
    static let angelSecretKey   = "8463854a-6462-46f9-8efc-49363750ecb1"   // ← Secret key from SmartAPI portal
    static let angelClientCode  = "AACG273919"   // ← Your Angel One login ID (e.g. A123456)
    static let angelPassword    = "1074"   // ← Your Angel One trading password
    static let angelTOTPSecret  = "WCTALCUFIHTC2IO276NPK7MUTI"   // ← TOTP secret shown when you enable 2FA (base32 string)

    // MARK: GoldAPI.io (fallback — international spot via REST)
    // Get free key at: https://www.goldapi.io
    static let goldAPIKey = ""
}
