import Foundation

final class SimulatedRateService: RateServiceProtocol {
    var onRatesUpdate: ((RateUpdate) -> Void)?

    private var timer: Timer?

    // Base prices that get fluctuated — all purities derive from these
    private var baseGold24KPer10gm: Double = 92_500   // Gold 999 (24K) per 10 gm
    private var baseSilver999PerKg: Double = 1_05_200  // Silver 999 per 1 kg
    private var baseXAU: Double = 2_340.50             // Gold spot USD/oz
    private var baseXAG: Double = 28.75                // Silver spot USD/oz

    // Fixed references (don't change during session)
    private let previousCloseGold24K: Double = 92_100
    private let previousCloseSilver999: Double = 1_06_000
    private let previousCloseXAU: Double = 2_328.20
    private let previousCloseXAG: Double = 29.20

    // Session high/low tracking
    private var sessionHighGold: Double = 92_900
    private var sessionLowGold: Double = 92_000
    private var sessionHighSilver: Double = 1_06_000
    private var sessionLowSilver: Double = 1_04_800

    // Purity multipliers relative to 24K (999)
    private let goldPurities: [(id: String, name: String, purity: String, unit: String, multiplier: Double, spread: Double)] = [
        ("gold_fine_995", "Gold Fine",  "995", "10 gm", 0.996,           150),
        ("gold_24k",      "Gold 24K",   "999", "10 gm", 1.0,             150),
        ("gold_22k",      "Gold 22K",   "916", "10 gm", 22.0 / 24.0,    150),
        ("gold_18k",      "Gold 18K",   "750", "10 gm", 18.0 / 24.0,    100),
        ("gold_guinee",   "Gold Guinee", "916", "8 gm", 22.0 / 24.0 * 0.8, 110),
        ("gold_petal",    "Gold Petal", "999", "1 gm",  0.1,             15),
    ]

    private let silverPurities: [(id: String, name: String, purity: String, unit: String, multiplier: Double, spread: Double)] = [
        ("silver_999",  "Silver Fine",  "999", "1 kg",   1.0,   300),
        ("silver_925",  "Silver 925",   "925", "1 kg",   0.925, 300),
        ("silver_micro", "Silver Micro", "999", "100 gm", 0.1,   30),
    ]

    init() {}

    func startListening() {
        fireUpdate()
        timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            self?.tick()
        }
    }

    func stopListening() {
        timer?.invalidate()
        timer = nil
    }

    func forceRefresh() {
        tick()
    }

    deinit {
        stopListening()
    }

    // MARK: - Tick

    private func tick() {
        // 1. Fluctuate the TWO base rates (gold + silver)
        baseGold24KPer10gm = RateCalculator.fluctuate(
            baseGold24KPer10gm,
            normalRange: 0.0002...0.0006,
            spikeRange: 0.001...0.003,
            spikeChance: 0.08
        )
        baseSilver999PerKg = RateCalculator.fluctuate(
            baseSilver999PerKg,
            normalRange: 0.0003...0.0010,
            spikeRange: 0.002...0.005,
            spikeChance: 0.08
        )

        // 2. Fluctuate spot prices proportionally
        baseXAU = RateCalculator.fluctuate(
            baseXAU,
            normalRange: 0.0002...0.0006,
            spikeRange: 0.001...0.003,
            spikeChance: 0.08
        )
        baseXAG = RateCalculator.fluctuate(
            baseXAG,
            normalRange: 0.0003...0.0010,
            spikeRange: 0.002...0.005,
            spikeChance: 0.08
        )

        // 3. Update session high/low
        sessionHighGold = max(sessionHighGold, baseGold24KPer10gm)
        sessionLowGold = min(sessionLowGold, baseGold24KPer10gm)
        sessionHighSilver = max(sessionHighSilver, baseSilver999PerKg)
        sessionLowSilver = min(sessionLowSilver, baseSilver999PerKg)

        fireUpdate()
    }

    // MARK: - Build Rate Arrays

    private func buildGoldRates() -> [CommodityRate] {
        goldPurities.map { item in
            let buyRate = baseGold24KPer10gm * item.multiplier
            let prevClose = previousCloseGold24K * item.multiplier
            return CommodityRate(
                id: item.id,
                name: item.name,
                category: .gold,
                purity: item.purity,
                unit: item.unit,
                buyRate: buyRate,
                sellRate: buyRate + item.spread,
                highRate: sessionHighGold * item.multiplier,
                lowRate: sessionLowGold * item.multiplier,
                previousClose: prevClose,
                lastUpdated: Date()
            )
        }
    }

    private func buildSilverRates() -> [CommodityRate] {
        silverPurities.map { item in
            let buyRate = baseSilver999PerKg * item.multiplier
            let prevClose = previousCloseSilver999 * item.multiplier
            return CommodityRate(
                id: item.id,
                name: item.name,
                category: .silver,
                purity: item.purity,
                unit: item.unit,
                buyRate: buyRate,
                sellRate: buyRate + item.spread,
                highRate: sessionHighSilver * item.multiplier,
                lowRate: sessionLowSilver * item.multiplier,
                previousClose: prevClose,
                lastUpdated: Date()
            )
        }
    }

    private func buildSpotRates() -> [SpotRate] {
        [
            SpotRate(
                id: "xau", name: "Gold Spot", symbol: "XAU",
                priceUSD: baseXAU,
                change: baseXAU - previousCloseXAU,
                changePercent: ((baseXAU - previousCloseXAU) / previousCloseXAU) * 100,
                lastUpdated: Date()
            ),
            SpotRate(
                id: "xag", name: "Silver Spot", symbol: "XAG",
                priceUSD: baseXAG,
                change: baseXAG - previousCloseXAG,
                changePercent: ((baseXAG - previousCloseXAG) / previousCloseXAG) * 100,
                lastUpdated: Date()
            ),
        ]
    }

    private func buildLocalRates() -> [LocalRate] {
        let goldMCX = baseGold24KPer10gm
        let silverMCX = baseSilver999PerKg
        return [
            LocalRate(
                id: "local_gold", commodityName: "Gold", category: .gold,
                unit: "10 gm", mcxRate: goldMCX, localPremium: 2_000,
                lastUpdated: Date()
            ),
            LocalRate(
                id: "local_silver", commodityName: "Silver", category: .silver,
                unit: "1 kg", mcxRate: silverMCX, localPremium: 1_500,
                lastUpdated: Date()
            ),
        ]
    }

    private var isMarketOpen: Bool {
        let calendar = Calendar.current
        let ist = TimeZone(identifier: "Asia/Kolkata")!
        let components = calendar.dateComponents(in: ist, from: Date())
        let hour = components.hour ?? 12
        let minute = components.minute ?? 0
        let totalMinutes = hour * 60 + minute
        return totalMinutes >= 540 && totalMinutes <= 1410
    }

    private func fireUpdate() {
        let update = RateUpdate(
            goldRates: buildGoldRates(),
            silverRates: buildSilverRates(),
            spotRates: buildSpotRates(),
            localRates: buildLocalRates(),
            isMarketOpen: isMarketOpen,
            lastUpdated: Date()
        )
        onRatesUpdate?(update)
    }
}
