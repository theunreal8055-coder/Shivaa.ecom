import Foundation
import CryptoKit
import OSLog

private let logger = Logger(subsystem: "com.bullionTrader", category: "AngelOne")

// MARK: - Angel One Response Models

private struct LoginResponse: Decodable {
    let status: Bool
    let message: String
    let data: LoginData?

    struct LoginData: Decodable {
        let jwtToken: String
        let feedToken: String
        let refreshToken: String
    }
}

private struct SearchResponse: Decodable {
    let status: Bool
    let data: [SearchResult]?

    struct SearchResult: Decodable {
        let tradingSymbol: String
        let symbolToken: String
        let exchange: String
    }
}

private struct MarketDataResponse: Decodable {
    let status: Bool
    let data: MarketDataPayload?

    struct MarketDataPayload: Decodable {
        let fetched: [Quote]
    }

    struct Quote: Decodable {
        let tradingSymbol: String
        let symbolToken: String
        let open: Double
        let high: Double
        let low: Double
        let close: Double       // previous close
        let ltp: Double         // last traded price
        let netChange: Double
        let percentChange: Double
    }
}

// MARK: - AngelOneMCXService

/// Fetches live MCX Gold & Silver tick data from Angel One SmartAPI.
/// Polls every 1 second while the timer is running.
/// MCX prices are already in INR — all purity rates are derived from base MCX price.
final class AngelOneMCXService: RateServiceProtocol {
    var onRatesUpdate: ((RateUpdate) -> Void)?

    private let apiKey: String
    private let secretKey: String
    private let clientCode: String
    private let password: String
    private let totpSecret: String

    private var jwtToken: String?
    private var goldToken: String?
    private var silverToken: String?

    private var timer: Timer?
    private var lastAuthAttempt: Date = .distantPast
    private let authRetryInterval: TimeInterval = 300 // only retry auth every 5 min
    private var sessionHighGold: Double = 0
    private var sessionLowGold: Double = .greatestFiniteMagnitude
    private var sessionHighSilver: Double = 0
    private var sessionLowSilver: Double = .greatestFiniteMagnitude

    private let config = RateConfig()

    private let goldPurities: [(id: String, name: String, purity: Double, purityLabel: String, grams: Double, spread: Double)] = [
        ("gold_fine_995", "Gold Fine",   0.995,       "995", 10,  150),
        ("gold_24k",      "Gold 24K",    1.0,         "999", 10,  150),
        ("gold_22k",      "Gold 22K",    22.0 / 24.0, "916", 10,  150),
        ("gold_18k",      "Gold 18K",    18.0 / 24.0, "750", 10,  100),
        ("gold_guinee",   "Gold Guinee", 22.0 / 24.0, "916",  8,  110),
        ("gold_petal",    "Gold Petal",  1.0,         "999",  1,   15),
    ]

    private let silverPurities: [(id: String, name: String, purity: Double, purityLabel: String, grams: Double, spread: Double)] = [
        ("silver_999",   "Silver Fine",  1.0,   "999", 1000, 300),
        ("silver_925",   "Silver 925",   0.925, "925", 1000, 300),
        ("silver_micro", "Silver Micro", 1.0,   "999",  100,  30),
    ]

    init(apiKey: String, secretKey: String, clientCode: String, password: String, totpSecret: String) {
        self.apiKey     = apiKey
        self.secretKey  = secretKey
        self.clientCode = clientCode
        self.password   = password
        self.totpSecret = totpSecret
    }

    func startListening() {
        Task {
            await authenticate()
            if jwtToken != nil {
                await discoverTokens()
            }
            startPolling()
        }
    }

    func stopListening() {
        timer?.invalidate()
        timer = nil
    }

    func forceRefresh() {
        Task { await fetchAndPublish() }
    }

    deinit { stopListening() }

    // MARK: - Authentication

    private func authenticate() async {
        lastAuthAttempt = Date()
        guard let url = URL(string: "https://apiconnect.angelone.in/rest/auth/angelbroking/user/v1/loginByPassword") else { return }

        let totp = generateTOTP(secret: totpSecret)
        let body: [String: String] = [
            "clientcode": clientCode,
            "password":   password,
            "totp":       totp
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        addCommonHeaders(&request)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        guard let (data, _) = try? await URLSession.shared.data(for: request) else {
            logger.error("Network request failed")
            return
        }
        let loginStr = String(data: data, encoding: .utf8) ?? "nil"
        print("🔐 LOGIN RESPONSE: \(loginStr)")
        logger.info("Login response: \(loginStr)")
        guard let response = try? JSONDecoder().decode(LoginResponse.self, from: data),
              let loginData = response.data else { return }

        jwtToken = loginData.jwtToken
    }

    // MARK: - Token Discovery (finds current front-month MCX contracts)

    private func discoverTokens() async {
        goldToken   = await searchToken(query: "GOLDM")
        silverToken = await searchToken(query: "SILVERM")
    }

    private func searchToken(query: String) async -> String? {
        guard let jwt = jwtToken,
              let url = URL(string: "https://apiconnect.angelone.in/rest/secure/angelbroking/order/v1/searchScrip") else { return nil }

        let body = ["exchange": "MCX", "searchscrip": query]
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        addCommonHeaders(&request)
        request.setValue("application/json",           forHTTPHeaderField: "Content-Type")
        request.setValue(jwt,                          forHTTPHeaderField: "Authorization")

        guard let (data, _) = try? await URLSession.shared.data(for: request) else { return nil }
        print("🔍 SEARCH [\(query)]: \(String(data: data, encoding: .utf8) ?? "nil")")
        guard let response  = try? JSONDecoder().decode(SearchResponse.self, from: data),
              let results   = response.data, !results.isEmpty else { return nil }

        return results.first?.symbolToken
    }

    // MARK: - Polling

    private func startPolling() {
        Task { await fetchAndPublish() }
        DispatchQueue.main.async { [weak self] in
            self?.timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
                Task { await self?.fetchAndPublish() }
            }
        }
    }

    private func fetchAndPublish() async {
        guard let jwt = jwtToken,
              let goldTok = goldToken, let silverTok = silverToken else {
            guard Date().timeIntervalSince(lastAuthAttempt) > authRetryInterval else { return }
            lastAuthAttempt = Date()
            await authenticate()
            await discoverTokens()
            return
        }

        guard let url = URL(string: "https://apiconnect.angelone.in/rest/secure/angelbroking/market/v1/quote/") else { return }

        let body: [String: Any] = [
            "mode": "FULL",
            "exchangeTokens": ["MCX": [goldTok, silverTok]]
        ]

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        addCommonHeaders(&request)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue(jwt,                forHTTPHeaderField: "Authorization")

        guard let (data, _) = try? await URLSession.shared.data(for: request) else {
            logger.error("Market data network failed")
            return
        }
        print("📊 MARKET DATA: \(String(data: data, encoding: .utf8) ?? "nil")")
        guard let response  = try? JSONDecoder().decode(MarketDataResponse.self, from: data),
              let fetched   = response.data?.fetched, fetched.count >= 2 else {
            if Date().timeIntervalSince(lastAuthAttempt) > authRetryInterval {
                lastAuthAttempt = Date()
                jwtToken = nil
                goldToken = nil
                silverToken = nil
                await authenticate()
                await discoverTokens()
            }
            return
        }

        let goldQuote   = fetched.first { $0.symbolToken == goldTok }
        let silverQuote = fetched.first { $0.symbolToken == silverTok }

        guard let gold = goldQuote, let silver = silverQuote else { return }

        // Update session high/low
        sessionHighGold   = max(sessionHighGold,   gold.high)
        sessionLowGold    = min(sessionLowGold,     gold.low)
        sessionHighSilver = max(sessionHighSilver,  silver.high)
        sessionLowSilver  = min(sessionLowSilver,   silver.low)

        let update = buildUpdate(gold: gold, silver: silver)
        await MainActor.run { onRatesUpdate?(update) }
    }

    // MARK: - Rate Building
    // MCX prices are already INR — GOLDM LTP = ₹ per 10gm, SILVERM LTP = ₹ per kg

    private func buildUpdate(gold: MarketDataResponse.Quote, silver: MarketDataResponse.Quote) -> RateUpdate {
        RateUpdate(
            goldRates:    buildGoldRates(quote: gold),
            silverRates:  buildSilverRates(quote: silver),
            spotRates:    buildSpotRates(gold: gold, silver: silver),
            localRates:   buildLocalRates(gold: gold, silver: silver),
            isMarketOpen: isMarketOpen,
            lastUpdated:  Date()
        )
    }

    private func buildGoldRates(quote: MarketDataResponse.Quote) -> [CommodityRate] {
        // quote.ltp is ₹ per 10gm for Gold 999 (24K)
        goldPurities.map { item in
            let base      = quote.ltp        * item.purity * (item.grams / 10)
            let prevClose = quote.close      * item.purity * (item.grams / 10)
            let high      = sessionHighGold  * item.purity * (item.grams / 10)
            let low       = sessionLowGold   * item.purity * (item.grams / 10)

            return CommodityRate(
                id: item.id, name: item.name, category: .gold,
                purity: item.purityLabel, unit: goldUnit(item.grams),
                buyRate: base, sellRate: base + item.spread,
                highRate: high, lowRate: low,
                previousClose: prevClose, lastUpdated: Date()
            )
        }
    }

    private func buildSilverRates(quote: MarketDataResponse.Quote) -> [CommodityRate] {
        // quote.ltp is ₹ per kg for Silver 999
        silverPurities.map { item in
            let base      = quote.ltp          * item.purity * (item.grams / 1000)
            let prevClose = quote.close        * item.purity * (item.grams / 1000)
            let high      = sessionHighSilver  * item.purity * (item.grams / 1000)
            let low       = sessionLowSilver   * item.purity * (item.grams / 1000)

            return CommodityRate(
                id: item.id, name: item.name, category: .silver,
                purity: item.purityLabel, unit: silverUnit(item.grams),
                buyRate: base, sellRate: base + item.spread,
                highRate: high, lowRate: low,
                previousClose: prevClose, lastUpdated: Date()
            )
        }
    }

    private func buildSpotRates(gold: MarketDataResponse.Quote, silver: MarketDataResponse.Quote) -> [SpotRate] {
        let usdInr = config.usdToInr
        return [
            SpotRate(id: "xau", name: "Gold Spot",   symbol: "XAU",
                     priceUSD: gold.ltp   / (usdInr / 31.1035 * 10),
                     change: gold.netChange   / (usdInr / 31.1035 * 10),
                     changePercent: gold.percentChange,   lastUpdated: Date()),
            SpotRate(id: "xag", name: "Silver Spot", symbol: "XAG",
                     priceUSD: silver.ltp / (usdInr / 31.1035 * 1000),
                     change: silver.netChange / (usdInr / 31.1035 * 1000),
                     changePercent: silver.percentChange, lastUpdated: Date()),
        ]
    }

    private func buildLocalRates(gold: MarketDataResponse.Quote, silver: MarketDataResponse.Quote) -> [LocalRate] {
        [
            LocalRate(id: "local_gold",   commodityName: "Gold",   category: .gold,
                      unit: "10 gm", mcxRate: gold.ltp,   localPremium: config.dealerMarginGoldPer10gm,   lastUpdated: Date()),
            LocalRate(id: "local_silver", commodityName: "Silver", category: .silver,
                      unit: "1 kg",  mcxRate: silver.ltp, localPremium: config.dealerMarginSilverPerKg, lastUpdated: Date()),
        ]
    }

    // MARK: - Helpers

    private func addCommonHeaders(_ request: inout URLRequest) {
        request.setValue("USER",              forHTTPHeaderField: "X-UserType")
        request.setValue("WEB",               forHTTPHeaderField: "X-SourceID")
        request.setValue("127.0.0.1",         forHTTPHeaderField: "X-ClientLocalIP")
        request.setValue("127.0.0.1",         forHTTPHeaderField: "X-ClientPublicIP")
        request.setValue("00:00:00:00:00:00", forHTTPHeaderField: "X-MACAddress")
        request.setValue(apiKey,              forHTTPHeaderField: "X-PrivateKey")
        request.setValue(secretKey,           forHTTPHeaderField: "X-SecretKey")
        request.setValue("application/json",  forHTTPHeaderField: "Accept")
    }

    private func goldUnit(_ grams: Double) -> String {
        grams >= 10 ? "\(Int(grams)) gm" : "\(Int(grams)) gm"
    }

    private func silverUnit(_ grams: Double) -> String {
        grams >= 1000 ? "\(Int(grams / 1000)) kg" : "\(Int(grams)) gm"
    }

    private var isMarketOpen: Bool {
        let ist = TimeZone(identifier: "Asia/Kolkata")!
        let c = Calendar.current.dateComponents(in: ist, from: Date())
        let total = (c.hour ?? 12) * 60 + (c.minute ?? 0)
        return total >= 540 && total <= 1410
    }

    // MARK: - TOTP (RFC 6238)

    private func generateTOTP(secret: String, digits: Int = 6, period: Int = 30) -> String {
        let key = base32Decode(secret.uppercased().replacingOccurrences(of: " ", with: ""))
        guard !key.isEmpty else { return "000000" }

        let counter = UInt64(Date().timeIntervalSince1970) / UInt64(period)
        let counterData = withUnsafeBytes(of: counter.bigEndian) { Data($0) }

        let hmac = HMAC<Insecure.SHA1>.authenticationCode(
            for: counterData,
            using: SymmetricKey(data: key)
        )
        let bytes = Array(hmac)

        let offset = Int(bytes[bytes.count - 1] & 0x0F)
        let code = (Int(bytes[offset]     & 0x7F) << 24)
                 | (Int(bytes[offset + 1] & 0xFF) << 16)
                 | (Int(bytes[offset + 2] & 0xFF) << 8)
                 |  Int(bytes[offset + 3] & 0xFF)

        let otp = code % Int(pow(10.0, Double(digits)))
        return String(format: "%0\(digits)d", otp)
    }

    private func base32Decode(_ input: String) -> Data {
        let alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        var result = Data()
        var buffer = 0
        var bitsLeft = 0

        for char in input {
            guard let idx = alphabet.firstIndex(of: char) else { continue }
            let value = alphabet.distance(from: alphabet.startIndex, to: idx)
            buffer = (buffer << 5) | value
            bitsLeft += 5
            if bitsLeft >= 8 {
                bitsLeft -= 8
                result.append(UInt8((buffer >> bitsLeft) & 0xFF))
                buffer &= (1 << bitsLeft) - 1
            }
        }
        return result
    }
}
