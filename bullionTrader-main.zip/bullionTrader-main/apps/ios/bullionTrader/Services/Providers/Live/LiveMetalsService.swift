import Foundation

// MARK: - API Response Models

private struct GoldAPIResponse: Decodable {
    let price: Double
    let prevClosePrice: Double
    let highPrice: Double
    let lowPrice: Double
    let ch: Double   // change USD
    let chp: Double  // change percent

    enum CodingKeys: String, CodingKey {
        case price
        case prevClosePrice = "prev_close_price"
        case highPrice = "high_price"
        case lowPrice = "low_price"
        case ch, chp
    }
}

private struct ForexResponse: Decodable {
    let rates: [String: Double]
}

// MARK: - LiveMetalsService

/// Fetches live XAU/USD and XAG/USD from GoldAPI.io.
/// USD/INR from open.er-api.com (free, no key required).
/// Derives all purity rates using RateCalculator (import duty + GST included).
final class LiveMetalsService: RateServiceProtocol {
    var onRatesUpdate: ((RateUpdate) -> Void)?

    private let apiKey: String
    private var config: RateConfig
    private var timer: Timer?

    // Session high/low tracking
    private var sessionHighGold: Double = 0
    private var sessionLowGold: Double = .greatestFiniteMagnitude
    private var sessionHighSilver: Double = 0
    private var sessionLowSilver: Double = .greatestFiniteMagnitude

    private let goldPurities: [(id: String, name: String, purity: Double, purityLabel: String, grams: Double, spread: Double)] = [
        ("gold_fine_995", "Gold Fine",   0.995,        "995", 10, 150),
        ("gold_24k",      "Gold 24K",    1.0,          "999", 10, 150),
        ("gold_22k",      "Gold 22K",    22.0 / 24.0,  "916", 10, 150),
        ("gold_18k",      "Gold 18K",    18.0 / 24.0,  "750", 10, 100),
        ("gold_guinee",   "Gold Guinee", 22.0 / 24.0,  "916",  8, 110),
        ("gold_petal",    "Gold Petal",  1.0,          "999",  1,  15),
    ]

    private let silverPurities: [(id: String, name: String, purity: Double, purityLabel: String, grams: Double, spread: Double)] = [
        ("silver_999",   "Silver Fine",  1.0,   "999", 1000, 300),
        ("silver_925",   "Silver 925",   0.925, "925", 1000, 300),
        ("silver_micro", "Silver Micro", 1.0,   "999",  100,  30),
    ]

    init(apiKey: String, config: RateConfig = RateConfig()) {
        self.apiKey = apiKey
        self.config = config
    }

    func startListening() {
        Task { await refresh() }
        timer = Timer.scheduledTimer(withTimeInterval: 300, repeats: true) { [weak self] _ in
            Task { await self?.refresh() }
        }
    }

    func stopListening() {
        timer?.invalidate()
        timer = nil
    }

    func forceRefresh() {
        Task { await refresh() }
    }

    deinit { stopListening() }

    // MARK: - Fetch

    private func refresh() async {
        async let goldFetch   = fetchMetal("XAU")
        async let silverFetch = fetchMetal("XAG")
        async let forexFetch  = fetchUSDINR()

        let (gold, silver, inrRate) = await (goldFetch, silverFetch, forexFetch)
        guard let gold, let silver else { return }

        if let inrRate { config.usdToInr = inrRate }

        sessionHighGold   = max(sessionHighGold,   gold.highPrice)
        sessionLowGold    = min(sessionLowGold,     gold.lowPrice)
        sessionHighSilver = max(sessionHighSilver,  silver.highPrice)
        sessionLowSilver  = min(sessionLowSilver,   silver.lowPrice)

        let update = buildUpdate(gold: gold, silver: silver)
        await MainActor.run { onRatesUpdate?(update) }
    }

    private func fetchMetal(_ symbol: String) async -> GoldAPIResponse? {
        guard let url = URL(string: "https://www.goldapi.io/api/\(symbol)/USD") else { return nil }
        var request = URLRequest(url: url)
        request.setValue(apiKey, forHTTPHeaderField: "x-access-token")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        guard let (data, _) = try? await URLSession.shared.data(for: request) else { return nil }
        return try? JSONDecoder().decode(GoldAPIResponse.self, from: data)
    }

    private func fetchUSDINR() async -> Double? {
        guard let url = URL(string: "https://open.er-api.com/v6/latest/USD") else { return nil }
        guard let (data, _) = try? await URLSession.shared.data(from: url) else { return nil }
        return (try? JSONDecoder().decode(ForexResponse.self, from: data))?.rates["INR"]
    }

    // MARK: - Build RateUpdate

    private func buildUpdate(gold: GoldAPIResponse, silver: GoldAPIResponse) -> RateUpdate {
        RateUpdate(
            goldRates:   buildGoldRates(spot: gold),
            silverRates: buildSilverRates(spot: silver),
            spotRates:   buildSpotRates(gold: gold, silver: silver),
            localRates:  buildLocalRates(gold: gold, silver: silver),
            isMarketOpen: isMarketOpen,
            lastUpdated: Date()
        )
    }

    private func buildGoldRates(spot: GoldAPIResponse) -> [CommodityRate] {
        goldPurities.map { item in
            let base     = RateCalculator.spotToINRPerGram(spotUSD: spot.price,          config: config)
            let prevBase = RateCalculator.spotToINRPerGram(spotUSD: spot.prevClosePrice, config: config)
            let highBase = RateCalculator.spotToINRPerGram(spotUSD: sessionHighGold,     config: config)
            let lowBase  = RateCalculator.spotToINRPerGram(spotUSD: sessionLowGold,      config: config)

            let marginPerUnit = config.dealerMarginGoldPer10gm * (item.grams / 10)
            let buyRate    = base     * item.purity * item.grams + marginPerUnit
            let prevClose  = prevBase * item.purity * item.grams + marginPerUnit
            let high       = highBase * item.purity * item.grams + marginPerUnit
            let low        = lowBase  * item.purity * item.grams + marginPerUnit

            return CommodityRate(
                id: item.id, name: item.name, category: .gold,
                purity: item.purityLabel, unit: unitLabel(grams: item.grams, isSilver: false),
                buyRate: buyRate, sellRate: buyRate + item.spread,
                highRate: high, lowRate: low, previousClose: prevClose,
                lastUpdated: Date()
            )
        }
    }

    private func buildSilverRates(spot: GoldAPIResponse) -> [CommodityRate] {
        silverPurities.map { item in
            let base     = RateCalculator.spotToINRPerGram(spotUSD: spot.price,          config: config)
            let prevBase = RateCalculator.spotToINRPerGram(spotUSD: spot.prevClosePrice, config: config)
            let highBase = RateCalculator.spotToINRPerGram(spotUSD: sessionHighSilver,   config: config)
            let lowBase  = RateCalculator.spotToINRPerGram(spotUSD: sessionLowSilver,    config: config)

            let marginPerUnit = config.dealerMarginSilverPerKg * (item.grams / 1000)
            let buyRate   = base     * item.purity * item.grams + marginPerUnit
            let prevClose = prevBase * item.purity * item.grams + marginPerUnit
            let high      = highBase * item.purity * item.grams + marginPerUnit
            let low       = lowBase  * item.purity * item.grams + marginPerUnit

            return CommodityRate(
                id: item.id, name: item.name, category: .silver,
                purity: item.purityLabel, unit: unitLabel(grams: item.grams, isSilver: true),
                buyRate: buyRate, sellRate: buyRate + item.spread,
                highRate: high, lowRate: low, previousClose: prevClose,
                lastUpdated: Date()
            )
        }
    }

    private func buildSpotRates(gold: GoldAPIResponse, silver: GoldAPIResponse) -> [SpotRate] {
        [
            SpotRate(id: "xau", name: "Gold Spot",   symbol: "XAU",
                     priceUSD: gold.price,   change: gold.ch,   changePercent: gold.chp,   lastUpdated: Date()),
            SpotRate(id: "xag", name: "Silver Spot", symbol: "XAG",
                     priceUSD: silver.price, change: silver.ch, changePercent: silver.chp, lastUpdated: Date()),
        ]
    }

    private func buildLocalRates(gold: GoldAPIResponse, silver: GoldAPIResponse) -> [LocalRate] {
        let goldBase   = RateCalculator.spotToINRPerGram(spotUSD: gold.price,   config: config)
        let silverBase = RateCalculator.spotToINRPerGram(spotUSD: silver.price, config: config)
        return [
            LocalRate(id: "local_gold",   commodityName: "Gold",   category: .gold,
                      unit: "10 gm", mcxRate: goldBase * 10,
                      localPremium: config.dealerMarginGoldPer10gm,   lastUpdated: Date()),
            LocalRate(id: "local_silver", commodityName: "Silver", category: .silver,
                      unit: "1 kg",  mcxRate: silverBase * 1000,
                      localPremium: config.dealerMarginSilverPerKg, lastUpdated: Date()),
        ]
    }

    // MARK: - Helpers

    private func unitLabel(grams: Double, isSilver: Bool) -> String {
        if isSilver {
            return grams >= 1000 ? "\(Int(grams / 1000)) kg" : "\(Int(grams)) gm"
        } else {
            return "\(Int(grams)) gm"
        }
    }

    private var isMarketOpen: Bool {
        let ist = TimeZone(identifier: "Asia/Kolkata")!
        let components = Calendar.current.dateComponents(in: ist, from: Date())
        let total = (components.hour ?? 12) * 60 + (components.minute ?? 0)
        return total >= 540 && total <= 1410
    }
}
