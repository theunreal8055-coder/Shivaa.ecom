import Foundation

// MARK: - Commodity Category

enum CommodityCategory: String, Codable, CaseIterable {
    case gold = "Gold"
    case silver = "Silver"
}

// MARK: - Commodity Rate

struct CommodityRate: Identifiable, Codable, Equatable {
    let id: String
    let name: String
    let category: CommodityCategory
    let purity: String
    let unit: String
    var buyRate: Double
    var sellRate: Double
    var highRate: Double
    var lowRate: Double
    var previousClose: Double
    var lastUpdated: Date

    var change: Double { buyRate - previousClose }

    var changePercent: Double {
        guard previousClose > 0 else { return 0 }
        return (change / previousClose) * 100
    }

    var isUp: Bool { change >= 0 }
}

// MARK: - Local Rate

struct LocalRate: Identifiable, Codable, Equatable {
    let id: String
    let commodityName: String
    let category: CommodityCategory
    let unit: String
    var mcxRate: Double
    var localPremium: Double
    var lastUpdated: Date

    var localPrice: Double { mcxRate + localPremium }
}

// MARK: - Spot Rate (International)

struct SpotRate: Identifiable, Codable, Equatable {
    let id: String
    let name: String
    let symbol: String
    var priceUSD: Double
    var change: Double
    var changePercent: Double
    var lastUpdated: Date

    var isUp: Bool { change >= 0 }
}

// MARK: - Price Alert

struct PriceAlert: Identifiable, Codable {
    let id: String
    let commodityName: String
    let targetPrice: Double
    let direction: AlertDirection
    var isActive: Bool
    let createdAt: Date

    enum AlertDirection: String, Codable {
        case above = "Above"
        case below = "Below"
    }
}

// MARK: - Market News

struct MarketNews: Identifiable, Codable {
    let id: String
    let title: String
    let body: String
    let publishedAt: Date
    var isRead: Bool
}

// MARK: - Booking Enquiry

struct BookingEnquiry: Identifiable, Codable {
    let id: String
    let commodityName: String
    let quantity: String
    let unit: String
    let rateAtBooking: Double
    let customerName: String
    let customerPhone: String
    let notes: String
    let status: BookingStatus
    let createdAt: Date

    enum BookingStatus: String, Codable {
        case pending = "Pending"
        case confirmed = "Confirmed"
        case delivered = "Delivered"
        case cancelled = "Cancelled"
    }
}

// MARK: - User Profile

struct UserProfile: Identifiable, Codable {
    let id: String
    var name: String
    var phone: String
    var city: String
    var businessName: String?
}
