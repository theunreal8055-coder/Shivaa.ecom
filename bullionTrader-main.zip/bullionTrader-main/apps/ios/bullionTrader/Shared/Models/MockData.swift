import Foundation

enum MockData {

    // MARK: - Gold Rates

    static let goldRates: [CommodityRate] = [
        CommodityRate(
            id: "gold_fine_995", name: "Gold Fine", category: .gold,
            purity: "995", unit: "10 gm",
            buyRate: 92_200, sellRate: 92_350,
            highRate: 92_600, lowRate: 91_800,
            previousClose: 91_850, lastUpdated: Date()
        ),
        CommodityRate(
            id: "gold_24k", name: "Gold 24K", category: .gold,
            purity: "999", unit: "10 gm",
            buyRate: 92_500, sellRate: 92_650,
            highRate: 92_900, lowRate: 92_000,
            previousClose: 92_100, lastUpdated: Date()
        ),
        CommodityRate(
            id: "gold_22k", name: "Gold 22K", category: .gold,
            purity: "916", unit: "10 gm",
            buyRate: 84_800, sellRate: 84_950,
            highRate: 85_100, lowRate: 84_400,
            previousClose: 84_480, lastUpdated: Date()
        ),
        CommodityRate(
            id: "gold_18k", name: "Gold 18K", category: .gold,
            purity: "750", unit: "10 gm",
            buyRate: 69_400, sellRate: 69_500,
            highRate: 69_700, lowRate: 69_100,
            previousClose: 69_150, lastUpdated: Date()
        ),
        CommodityRate(
            id: "gold_guinee", name: "Gold Guinee", category: .gold,
            purity: "916", unit: "8 gm",
            buyRate: 67_850, sellRate: 67_960,
            highRate: 68_100, lowRate: 67_500,
            previousClose: 67_590, lastUpdated: Date()
        ),
        CommodityRate(
            id: "gold_petal", name: "Gold Petal", category: .gold,
            purity: "999", unit: "1 gm",
            buyRate: 9_250, sellRate: 9_265,
            highRate: 9_290, lowRate: 9_200,
            previousClose: 9_210, lastUpdated: Date()
        ),
    ]

    // MARK: - Silver Rates

    static let silverRates: [CommodityRate] = [
        CommodityRate(
            id: "silver_999", name: "Silver Fine", category: .silver,
            purity: "999", unit: "1 kg",
            buyRate: 1_05_200, sellRate: 1_05_500,
            highRate: 1_06_000, lowRate: 1_04_800,
            previousClose: 1_06_000, lastUpdated: Date()
        ),
        CommodityRate(
            id: "silver_925", name: "Silver 925", category: .silver,
            purity: "925", unit: "1 kg",
            buyRate: 97_300, sellRate: 97_600,
            highRate: 98_000, lowRate: 96_900,
            previousClose: 97_950, lastUpdated: Date()
        ),
        CommodityRate(
            id: "silver_micro", name: "Silver Micro", category: .silver,
            purity: "999", unit: "100 gm",
            buyRate: 10_520, sellRate: 10_550,
            highRate: 10_600, lowRate: 10_480,
            previousClose: 10_600, lastUpdated: Date()
        ),
    ]

    // MARK: - Local Delivery Rates

    static let localRates: [LocalRate] = [
        LocalRate(
            id: "local_gold", commodityName: "Gold", category: .gold,
            unit: "10 gm", mcxRate: 92_500, localPremium: 2_000,
            lastUpdated: Date()
        ),
        LocalRate(
            id: "local_silver", commodityName: "Silver", category: .silver,
            unit: "1 kg", mcxRate: 1_05_200, localPremium: 1_500,
            lastUpdated: Date()
        ),
    ]

    // MARK: - International Spot Rates

    static let spotRates: [SpotRate] = [
        SpotRate(
            id: "xau", name: "Gold Spot", symbol: "XAU",
            priceUSD: 2_340.50, change: 12.30, changePercent: 0.53,
            lastUpdated: Date()
        ),
        SpotRate(
            id: "xag", name: "Silver Spot", symbol: "XAG",
            priceUSD: 28.75, change: -0.45, changePercent: -1.54,
            lastUpdated: Date()
        ),
    ]

    // MARK: - Price Alerts

    static let alerts: [PriceAlert] = [
        PriceAlert(
            id: "alert1", commodityName: "Gold 24K",
            targetPrice: 93_000, direction: .above,
            isActive: true, createdAt: Date().addingTimeInterval(-86400)
        ),
        PriceAlert(
            id: "alert2", commodityName: "Silver Fine",
            targetPrice: 1_04_000, direction: .below,
            isActive: true, createdAt: Date().addingTimeInterval(-43200)
        ),
    ]

    // MARK: - Market News

    static let news: [MarketNews] = [
        MarketNews(
            id: "news1",
            title: "Gold prices rally on weak US dollar",
            body: "Gold prices surged today as the US dollar weakened against major currencies. Analysts expect the uptrend to continue amid growing concerns over inflation and geopolitical tensions. MCX Gold futures closed higher, marking a gain from the previous session.",
            publishedAt: Date().addingTimeInterval(-3600),
            isRead: false
        ),
        MarketNews(
            id: "news2",
            title: "Silver demand up 15% in Q1 2026",
            body: "Industrial demand for silver has increased significantly in the first quarter of 2026, driven by growing solar panel manufacturing and electronics sectors. The Silver Institute reports a 15% year-over-year increase in demand.",
            publishedAt: Date().addingTimeInterval(-7200),
            isRead: true
        ),
        MarketNews(
            id: "news3",
            title: "RBI policy meeting: Impact on gold",
            body: "The Reserve Bank of India's upcoming monetary policy meeting is expected to have significant implications for gold prices. Market participants are closely watching for any changes in interest rates and inflation outlook.",
            publishedAt: Date().addingTimeInterval(-86400),
            isRead: false
        ),
    ]
}
