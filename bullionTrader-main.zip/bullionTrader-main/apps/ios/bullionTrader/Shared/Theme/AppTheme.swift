import SwiftUI

enum AppTheme {
    // Background
    static let background = Color(hex: "0C0C14")
    static let cardBackground = Color(hex: "161622")
    static let surface = Color(hex: "101020")

    // Brand
    static let gold = Color(hex: "D4A843")
    static let goldLight = Color(hex: "F0D078")
    static let goldDark = Color(hex: "8B6914")

    // Semantic
    static let priceUp = Color(hex: "00C853")
    static let priceDown = Color(hex: "FF3B30")

    // Text
    static let textPrimary = Color.white
    static let textSecondary = Color(hex: "8E8E93")
    static let textTertiary = Color(hex: "636366")

    // Borders
    static let divider = Color(hex: "1E1E2E")
    static let border = Color(hex: "2A2A3C")

    // Gradients
    static let goldGradient = LinearGradient(
        colors: [Color(hex: "D4A843"), Color(hex: "F0D078")],
        startPoint: .leading,
        endPoint: .trailing
    )

    static let goldRadialGlow = RadialGradient(
        colors: [Color(hex: "D4A843").opacity(0.3), Color.clear],
        center: .center,
        startRadius: 0,
        endRadius: 120
    )
}

// MARK: - Color Hex Init

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// MARK: - Price Formatting

func formatINR(_ value: Double, showSymbol: Bool = true) -> String {
    let formatter = NumberFormatter()
    formatter.locale = Locale(identifier: "en_IN")
    formatter.numberStyle = .decimal
    formatter.maximumFractionDigits = 0
    formatter.minimumFractionDigits = 0
    let formatted = formatter.string(from: NSNumber(value: value)) ?? "\(Int(value))"
    return showSymbol ? "\u{20B9}\(formatted)" : formatted
}

func formatChange(_ value: Double) -> String {
    let sign = value >= 0 ? "+" : ""
    return "\(sign)\(Int(value))"
}

func formatPercent(_ value: Double) -> String {
    let sign = value >= 0 ? "+" : ""
    return String(format: "\(sign)%.2f%%", value)
}

func formatUSD(_ value: Double) -> String {
    return String(format: "$%.2f", value)
}

// MARK: - View Modifiers

extension View {
    func cardShadow() -> some View {
        self.shadow(color: Color.black.opacity(0.3), radius: 8, x: 0, y: 4)
    }

    func goldGlowShadow() -> some View {
        self.shadow(color: AppTheme.gold.opacity(0.15), radius: 12, x: 0, y: 4)
    }

    func accentBar(color: Color, width: CGFloat = 3) -> some View {
        self.overlay(alignment: .leading) {
            UnevenRoundedRectangle(
                topLeadingRadius: 10,
                bottomLeadingRadius: 10
            )
            .fill(color)
            .frame(width: width)
        }
    }
}

// MARK: - Shimmer Modifier

struct ShimmerModifier: ViewModifier {
    @State private var phase: CGFloat = -200

    func body(content: Content) -> some View {
        content
            .overlay(
                LinearGradient(
                    colors: [.clear, Color.white.opacity(0.12), .clear],
                    startPoint: .leading,
                    endPoint: .trailing
                )
                .rotationEffect(.degrees(20))
                .offset(x: phase)
            )
            .clipped()
            .onAppear {
                withAnimation(.linear(duration: 1.5).repeatForever(autoreverses: false)) {
                    phase = 350
                }
            }
    }
}

extension View {
    func shimmer() -> some View {
        modifier(ShimmerModifier())
    }
}
