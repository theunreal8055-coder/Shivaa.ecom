// ============================================================================
// BullionTrader Web — Type Definitions
// ============================================================================

export interface RateMetrics {
  bid: number;
  ask: number;
  base_mcx: number;
}

export interface RateUpdate {
  timestamp: string;
  gold: RateMetrics;
  silver: RateMetrics;
}

export interface PriceTick {
  timestamp: number;
  price: number;
}

export interface PurityOption {
  id: string;
  label: string;
  shortLabel: string;
  multiplier: number;
  unit: string;
}

export interface Alert {
  id: string;
  metal: 'gold' | 'silver';
  targetPrice: number;
  direction: 'above' | 'below';
  isActive: boolean;
  createdAt: string;
  triggeredAt?: string;
  purity: string;
}

export interface MarketStatus {
  isOpen: boolean;
  nextEvent: string;
  nextEventTime: string;
}

export interface DealerConfig {
  badlaGold: number;
  badlaSilver: number;
  dutyRate: number;
  gstRate: number;
  marketOpenTime: string;
  marketCloseTime: string;
}
