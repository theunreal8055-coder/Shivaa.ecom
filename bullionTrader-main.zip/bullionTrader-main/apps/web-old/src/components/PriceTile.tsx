'use client';
import { useEffect, useState } from 'react';

interface PriceTileProps {
  metal: 'Gold' | 'Silver';
  bid: number | null;
  ask: number | null;
}

export function PriceTile({ metal, bid, ask }: PriceTileProps) {
  const [flash, setFlash] = useState<'up' | 'down' | null>(null);
  const [prevAsk, setPrevAsk] = useState<number | null>(null);

  useEffect(() => {
    if (ask && prevAsk && ask !== prevAsk) {
      setFlash(ask > prevAsk ? 'up' : 'down');
      const timer = setTimeout(() => setFlash(null), 1000);
      return () => clearTimeout(timer);
    }
    setPrevAsk(ask);
  }, [ask, prevAsk]);

  const flashClass = flash === 'up' ? 'flash-up' : flash === 'down' ? 'flash-down' : '';

  return (
    <div className={`price-tile ${flashClass}`} style={{
      background: 'var(--bg-card)', 
      padding: '2rem', 
      borderRadius: '12px',
      position: 'relative',
      overflow: 'hidden',
      border: '1px solid var(--border)',
      transition: 'box-shadow 0.3s ease'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ margin: 0, color: metal === 'Gold' ? 'var(--accent-gold)' : '#E0E0E0' }}>
          {metal}
        </h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginTop: '1.5rem' }}>
        <div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', margin: '0 0 0.5rem 0' }}>BID</p>
          <p style={{ fontSize: '2rem', margin: 0, fontWeight: 'bold' }}>
            {bid ? `₹${bid.toLocaleString('en-IN')}` : '---'}
          </p>
        </div>
        <div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', margin: '0 0 0.5rem 0' }}>ASK</p>
          <p style={{ fontSize: '2rem', margin: 0, fontWeight: 'bold', color: 'var(--text-primary)' }}>
            {ask ? `₹${ask.toLocaleString('en-IN')}` : '---'}
          </p>
        </div>
      </div>
    </div>
  );
}
