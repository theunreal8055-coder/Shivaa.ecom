import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { RateUpdate, PriceTick } from '../lib/types';

export function useRealtimeRates() {
  const [liveRates, setLiveRates] = useState<RateUpdate | null>(null);
  const [goldHistory, setGoldHistory] = useState<PriceTick[]>([]);
  const [silverHistory, setSilverHistory] = useState<PriceTick[]>([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Connect to the 'bullion_rates' channel
    const channel = supabase.channel('bullion_rates');

    channel
      .on('broadcast', { event: 'rate-update' }, (payload) => {
        const update = payload.payload as RateUpdate;
        setLiveRates(update);
        setIsConnected(true);

        const timestamp = new Date(update.timestamp).getTime();

        setGoldHistory((prev) => {
          const newHistory = [...prev, { timestamp, price: update.gold.ask }];
          // Keep last 100 ticks for the sparkline
          if (newHistory.length > 100) newHistory.shift();
          return newHistory;
        });

        setSilverHistory((prev) => {
          const newHistory = [...prev, { timestamp, price: update.silver.ask }];
          if (newHistory.length > 100) newHistory.shift();
          return newHistory;
        });
      })
      .subscribe((status) => {
        if (status === 'SUBSCRIBED') {
          setIsConnected(true);
        } else if (status === 'CLOSED' || status === 'CHANNEL_ERROR') {
          setIsConnected(false);
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return { liveRates, goldHistory, silverHistory, isConnected };
}
