import Link from 'next/link';

export default function Home() {
  return (
    <main style={{ padding: '4rem', textAlign: 'center' }}>
      <h1 style={{ color: 'var(--accent-gold)' }}>Laxmi Abhushan</h1>
      <h2>Premium Bullion Trading Since 1994</h2>
      <p style={{ color: 'var(--text-secondary)', marginBottom: '2rem' }}>
        Real-time Rates • Price Alerts • Secure Trading
      </p>
      <Link 
        href="/dashboard" 
        style={{ 
          background: 'var(--accent-gold)', 
          color: '#000', 
          padding: '12px 24px', 
          textDecoration: 'none', 
          borderRadius: '8px',
          fontWeight: 'bold'
        }}
      >
        View Live Rates
      </Link>
    </main>
  );
}
