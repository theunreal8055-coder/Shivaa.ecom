import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Laxmi Abhushan - Bullion Trading',
  description: 'Premium Bullion Trading Since 1994',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
