'use client';
import { useRealtimeRates } from '@/hooks/useRealtimeRates';
import { PriceTile } from '@/components/PriceTile';

export default function Dashboard() {
  const { liveRates, isConnected } = useRealtimeRates();

  return (
    <div style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <h1 style={{ color: 'var(--accent-gold)' }}>Live Dashboard</h1>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <div style={{
            width: '10px', height: '10px', borderRadius: '50%',
            background: isConnected ? 'var(--green)' : 'var(--red)',
            boxShadow: `0 0 8px ${isConnected ? 'var(--green)' : 'var(--red)'}`
          }} />
          <span style={{ color: 'var(--text-secondary)', fontSize: '0.9rem' }}>
            {isConnected ? 'LIVE' : 'OFFLINE'}
          </span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
        <PriceTile 
          metal="Gold" 
          bid={liveRates?.gold.bid || null} 
          ask={liveRates?.gold.ask || null} 
        />
        <PriceTile 
          metal="Silver" 
          bid={liveRates?.silver.bid || null} 
          ask={liveRates?.silver.ask || null} 
        />
      </div>
    </div>
  );
}
