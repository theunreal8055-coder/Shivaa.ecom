import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { signUp } from "@/lib/auth";
import { toast } from "sonner";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create account — Laxmi Abhushan" },
      { name: "description", content: "Register your bullion trading account with Laxmi Abhushan." },
    ],
  }),
  component: SignupScreen,
});

function SignupScreen() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "",
    code: "+91",
    phone: "",
    company: "",
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);

  function update<K extends keyof typeof form>(k: K, v: string) {
    setForm((s) => ({ ...s, [k]: v }));
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name || !form.phone || !form.email || !form.password) {
      toast.error("Please fill in Name, Phone, Email, and Password.");
      return;
    }
    setLoading(true);
    const res = await signUp({
      name: form.name,
      phone: `${form.code} ${form.phone}`.trim(),
      company: form.company,
      email: form.email,
      password: form.password,
    });
    setLoading(false);
    if (res.success) {
      toast.success("Account created successfully!");
      navigate({ to: "/rates" });
    } else {
      toast.error(res.error || "Failed to create account");
    }
  }

  return (
    <div className="relative min-h-screen overflow-y-auto px-6 pb-10 pt-12">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-60"
        style={{
          backgroundImage:
            "radial-gradient(circle at 50% 0%, color-mix(in oklab, var(--color-gold) 20%, transparent), transparent 60%)",
        }}
      />
      <div className="relative">
        <h1 className="font-display text-xl font-bold tracking-[0.36em]">LAXMI</h1>
        <p className="font-display text-[0.7rem] font-medium tracking-[0.42em] text-gold">ABHUSHAN</p>
      </div>

      <div className="relative mt-8">
        <h2 className="font-display text-2xl font-bold leading-tight">Open your trader account.</h2>
        <p className="mt-1 text-sm text-muted-foreground">Takes under a minute.</p>
      </div>

      <form onSubmit={onSubmit} className="relative mt-6 space-y-4 rounded-2xl border border-white/10 bg-card/80 p-5 backdrop-blur">
        <Field label="Trader Name">
          <Input value={form.name} onChange={(e) => update("name", e.target.value)} disabled={loading} placeholder="Rohan Mehta" className="h-11 bg-surface" />
        </Field>
        <Field label="Contact Number">
          <div className="flex gap-2">
            <select
              value={form.code}
              onChange={(e) => update("code", e.target.value)}
              disabled={loading}
              className="h-11 w-20 rounded-md border border-input bg-surface px-2 text-sm"
            >
              <option>+91</option>
              <option>+971</option>
              <option>+1</option>
              <option>+44</option>
            </select>
            <Input value={form.phone} onChange={(e) => update("phone", e.target.value)} disabled={loading} placeholder="98200 12345" className="h-11 flex-1 bg-surface" />
          </div>
        </Field>
        <Field label="Company Name">
          <Input value={form.company} onChange={(e) => update("company", e.target.value)} disabled={loading} placeholder="Mehta Jewellers" className="h-11 bg-surface" />
        </Field>
        <Field label="Email">
          <Input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} disabled={loading} placeholder="you@company.com" className="h-11 bg-surface" />
        </Field>
        <Field label="Password">
          <Input type="password" value={form.password} onChange={(e) => update("password", e.target.value)} disabled={loading} placeholder="Create a strong password" className="h-11 bg-surface" />
        </Field>
        <Button type="submit" disabled={loading} className="h-12 w-full bg-gold font-display font-semibold tracking-wide gold-glow hover:opacity-90">
          {loading ? "Registering..." : "Sign Up"}
        </Button>
      </form>

      <p className="relative mt-6 text-center text-sm text-muted-foreground">
        Already have an account?{" "}
        <Link to="/login" className="font-semibold text-gold hover:underline">Sign in</Link>
      </p>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[0.7rem] font-medium uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}