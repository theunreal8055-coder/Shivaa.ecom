import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { signIn } from "@/lib/auth";

import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Sign in — Laxmi Abhushan" },
      { name: "description", content: "Sign in to your Laxmi Abhushan trader account." },
    ],
  }),
  component: LoginScreen,
});

function LoginScreen() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) {
      toast.error("Please fill in all fields.");
      return;
    }
    setLoading(true);
    const res = await signIn(email, password);
    setLoading(false);
    if (res.success) {
      toast.success("Signed in successfully!");
      navigate({ to: "/rates" });
    } else {
      toast.error(res.error || "Failed to sign in");
    }
  }

  return (
    <div className="relative flex min-h-screen flex-col px-6 pb-10 pt-14">
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-72"
        style={{
          backgroundImage:
            "radial-gradient(circle at 50% 0%, color-mix(in oklab, var(--color-gold) 22%, transparent), transparent 60%)",
        }}
      />
      <div className="relative">
        <h1 className="font-display text-xl font-bold tracking-[0.36em] text-foreground">LAXMI</h1>
        <p className="font-display text-[0.7rem] font-medium tracking-[0.42em] text-gold">ABHUSHAN</p>
      </div>

      <div className="relative mt-12">
        <h2 className="font-display text-3xl font-bold leading-tight text-foreground">Welcome back.</h2>
        <p className="mt-2 text-sm text-muted-foreground">Sign in to access today’s live bullion desk.</p>
      </div>

      <form onSubmit={onSubmit} className="relative mt-8 space-y-5 rounded-2xl border border-white/10 bg-card/80 p-6 backdrop-blur">
        <FormField id="email" label="Email">
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} disabled={loading} placeholder="email@example.com" className="h-12 bg-surface" />
        </FormField>
        <FormField id="password" label="Password">
          <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} disabled={loading} placeholder="••••••••" className="h-12 bg-surface" />
        </FormField>
        <div className="flex justify-end">
          <button type="button" className="text-xs font-medium text-gold hover:underline">Forgot password?</button>
        </div>
        <Button type="submit" disabled={loading} className="h-12 w-full bg-gold font-display text-base font-semibold tracking-wide gold-glow hover:opacity-90">
          {loading ? "Signing In..." : "Sign In"}
        </Button>
      </form>

      <p className="relative mt-8 text-center text-sm text-muted-foreground">
        Don’t have an account?{" "}
        <Link to="/signup" className="font-semibold text-gold hover:underline">Sign up</Link>
      </p>
    </div>
  );
}

function FormField({ id, label, children }: { id: string; label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
        {label}
      </Label>
      {children}
    </div>
  );
}