import { createFileRoute, Outlet, Link, useRouterState, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { isSignedIn } from "@/lib/auth";
import { LineChart, BellRing, Newspaper, User } from "lucide-react";

export const Route = createFileRoute("/_app")({
  component: AppLayout,
});

function AppLayout() {
  const navigate = useNavigate();
  useEffect(() => {
    if (!isSignedIn()) navigate({ to: "/login" });
  }, [navigate]);

  return (
    <div className="relative flex h-full min-h-screen flex-col bg-background">
      <main className="flex-1 overflow-y-auto pb-24">
        <Outlet />
      </main>
      <BottomTabs />
    </div>
  );
}

const TABS = [
  { to: "/rates", label: "Rates", Icon: LineChart },
  { to: "/alerts", label: "Alerts", Icon: BellRing },
  { to: "/news", label: "News", Icon: Newspaper },
  { to: "/profile", label: "Profile", Icon: User },
] as const;

function BottomTabs() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="absolute inset-x-0 bottom-0 z-30 border-t border-white/10 bg-surface/95 backdrop-blur">
      <ul className="grid grid-cols-4 px-2 pb-3 pt-2">
        {TABS.map(({ to, label, Icon }) => {
          const active = pathname === to || pathname.startsWith(to + "/");
          return (
            <li key={to}>
              <Link
                to={to}
                className="flex flex-col items-center gap-1 rounded-xl py-2 text-[0.65rem] font-medium uppercase tracking-wider transition-colors"
              >
                <span
                  className={`grid h-9 w-9 place-items-center rounded-xl transition-colors ${
                    active ? "bg-gold text-primary-foreground gold-glow" : "text-muted-foreground"
                  }`}
                >
                  <Icon className="h-5 w-5" strokeWidth={2.2} />
                </span>
                <span className={active ? "text-foreground" : "text-muted-foreground"}>{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}