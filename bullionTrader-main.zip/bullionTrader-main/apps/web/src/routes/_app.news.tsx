import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { AlertTriangle } from "lucide-react";
import { fetchWithAuth } from "@/lib/api";

export const Route = createFileRoute("/_app/news")({
  head: () => ({
    meta: [
      { title: "Bullion News — Laxmi Abhushan" },
      { name: "description", content: "Latest gold, silver and global reserves news for bullion traders." },
    ],
  }),
  component: NewsScreen,
});

type Article = {
  title: string;
  url: string;
  domain: string;
  seendate: Date;
  summary?: string;
};

function parseDate(s: string): Date {
  // 20240615T103000Z -> 2024-06-15T10:30:00Z
  if (!/^\d{8}T\d{6}Z$/.test(s)) return new Date(s);
  const iso = `${s.slice(0, 4)}-${s.slice(4, 6)}-${s.slice(6, 8)}T${s.slice(9, 11)}:${s.slice(11, 13)}:${s.slice(13, 15)}Z`;
  return new Date(iso);
}

function categoryFor(title: string): string {
  const t = title.toLowerCase();
  if (t.includes("reserve") || t.includes("central bank")) return "Global Reserves";
  if (t.includes("silver")) return "Silver";
  if (t.includes("mcx") || t.includes("comex") || t.includes("futures")) return "Markets";
  if (t.includes("rate") || t.includes("price")) return "Price Action";
  return "Bullion";
}

async function fetchNews(): Promise<Article[]> {
  try {
    const res = await fetchWithAuth("/news");
    if (res.success && res.data) {
      return res.data.map((item: any) => ({
        title: item.title,
        url: item.url,
        domain: item.domain,
        seendate: new Date(item.seendate),
        summary: item.summary
      }));
    }
  } catch (err: any) {
    console.error("Error fetching news from API Gateway:", err.message);
  }
  return [];
}


function NewsScreen() {
  const { data, isLoading, isError } = useQuery({
    queryKey: ["news"],
    queryFn: fetchNews,
    staleTime: 60_000,
  });

  return (
    <div className="px-5 pt-6">
      <header className="mb-5">
        <p className="text-[0.65rem] font-semibold uppercase tracking-widest text-gold">Bullion desk</p>
        <h1 className="mt-1 font-display text-2xl font-bold">News & Market Pulse</h1>
      </header>

      {isLoading && (
        <ul className="space-y-3">
          {Array.from({ length: 5 }).map((_, i) => (
            <li key={i} className="h-28 animate-pulse rounded-2xl border border-white/10 bg-card" />
          ))}
        </ul>
      )}

      {isError && (
        <div className="flex items-start gap-3 rounded-2xl border border-white/10 bg-card p-4">
          <AlertTriangle className="h-5 w-5 shrink-0 text-gold" />
          <div className="text-sm text-muted-foreground">
            Couldn’t load news right now. Check your connection and pull down to retry.
          </div>
        </div>
      )}

      {data && (
        <ul className="space-y-3">
          {data.slice(0, 20).map((a, i) => (
            <li key={`${a.url}-${i}`}>
              <a
                href={a.url}
                target="_blank"
                rel="noopener noreferrer"
                className="block rounded-2xl border border-white/10 bg-card p-4 transition-colors hover:border-gold/40"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[0.6rem] font-bold uppercase tracking-[0.22em] text-gold">
                    {categoryFor(a.title)}
                  </span>
                  <span className="text-[0.65rem] text-muted-foreground">
                    {formatDistanceToNow(a.seendate, { addSuffix: true })}
                  </span>
                </div>
                <h3 className="mt-2 font-display text-[0.95rem] font-bold leading-snug text-foreground text-wrap break-words">
                  {a.title}
                </h3>
                <p className="mt-2 text-xs text-muted-foreground line-clamp-2">
                  {a.summary || `${a.domain} · Tap to read full coverage on the publisher’s site.`}
                </p>
                <div className="mt-3 flex items-center justify-between text-[0.7rem]">
                  <span className="font-semibold text-foreground/80">{a.domain}</span>
                  <span className="text-gold">Read →</span>
                </div>
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}