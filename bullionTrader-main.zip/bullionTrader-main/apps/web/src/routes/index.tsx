import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { isSignedIn } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Laxmi Abhushan" },
      { name: "description", content: "Premium bullion trading workspace — live gold & silver rates, alerts and news." },
    ],
  }),
  component: SplashScreen,
});

function SplashScreen() {
  const navigate = useNavigate();
  useEffect(() => {
    const t = setTimeout(() => {
      navigate({ to: isSignedIn() ? "/rates" : "/login" });
    }, 1600);
    return () => clearTimeout(t);
  }, [navigate]);

  return (
    <div className="relative flex h-full min-h-screen w-full flex-col items-center justify-center overflow-hidden bg-background px-8">
      {/* ambient glow */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(circle at 50% 40%, color-mix(in oklab, var(--color-gold) 18%, transparent), transparent 60%)",
        }}
      />
      <div className="relative flex flex-col items-center gap-6">
        <DiamondGlyph />
        <div className="text-center">
          <h1 className="font-display text-2xl font-bold tracking-[0.32em] text-foreground">
            LAXMI
          </h1>
          <p className="mt-1 font-display text-sm font-medium tracking-[0.42em] text-gold">
            ABHUSHAN
          </p>
        </div>
        <p className="mt-2 text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Bullion · Trading · Trust
        </p>
      </div>
      <div className="absolute bottom-12 flex items-center gap-1.5">
        <Dot delay="0ms" />
        <Dot delay="180ms" />
        <Dot delay="360ms" />
      </div>
    </div>
  );
}

function Dot({ delay }: { delay: string }) {
  return (
    <span
      className="inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-gold"
      style={{ animationDelay: delay, animationDuration: "1.2s" }}
    />
  );
}

function DiamondGlyph() {
  return (
    <div className="relative">
      <div className="absolute inset-0 blur-2xl" style={{ background: "radial-gradient(circle, color-mix(in oklab, var(--color-gold) 60%, transparent), transparent 65%)" }} />
      <svg width="84" height="84" viewBox="0 0 84 84" className="relative">
        <defs>
          <linearGradient id="gold-g" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="oklch(0.92 0.13 88)" />
            <stop offset="50%" stopColor="oklch(0.82 0.14 85)" />
            <stop offset="100%" stopColor="oklch(0.62 0.12 70)" />
          </linearGradient>
        </defs>
        <path d="M42 4 L78 32 L42 80 L6 32 Z" fill="url(#gold-g)" stroke="oklch(0.95 0.08 88)" strokeWidth="0.8" />
        <path d="M42 4 L42 80 M6 32 L78 32 M22 18 L62 18 L78 32 M22 18 L6 32 M62 18 L78 32 M22 18 L42 80 M62 18 L42 80" stroke="oklch(0.20 0.02 260)" strokeWidth="0.6" fill="none" opacity="0.6" />
      </svg>
    </div>
  );
}
