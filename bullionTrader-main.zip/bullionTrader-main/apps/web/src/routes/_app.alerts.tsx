import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Trash2, TrendingDown, TrendingUp } from "lucide-react";
import { fetchWithAuth } from "@/lib/api";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/alerts")({
  head: () => ({
    meta: [
      { title: "Price Alerts — Laxmi Abhushan" },
      { name: "description", content: "Create custom price alerts for gold and silver bullion." },
    ],
  }),
  component: AlertsScreen,
});

type Alert = {
  id: string;
  metal: "GOLD" | "SILVER";
  condition: "BELOW" | "ABOVE";
  target: number;
  enabled: boolean;
};

function AlertsScreen() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [metal, setMetal] = useState<"GOLD" | "SILVER">("GOLD");
  const [condition, setCondition] = useState<"BELOW" | "ABOVE">("ABOVE");
  const [target, setTarget] = useState("");
  const [loading, setLoading] = useState(true);

  // Fetch alerts from API Gateway on mount
  useEffect(() => {
    async function loadAlerts() {
      try {
        const res = await fetchWithAuth("/alerts");

        if (res.success && res.data) {
          setAlerts(
            res.data.map((item: any) => ({
              id: item.id,
              metal: item.metal as "GOLD" | "SILVER",
              condition: item.direction.toUpperCase() as "ABOVE" | "BELOW",
              target: parseFloat(item.target_price),
              enabled: item.is_active,
            }))
          );
        }
      } catch (err: any) {
        console.error("Error loading alerts:", err.message);
        toast.error("Failed to load price alerts.");
      } finally {
        setLoading(false);
      }
    }
    loadAlerts();
  }, []);

  async function add() {
    const t = parseFloat(target);
    if (!t || Number.isNaN(t)) {
      toast.error("Please enter a valid target price.");
      return;
    }
    try {
      const res = await fetchWithAuth("/alerts", {
        method: "POST",
        body: JSON.stringify({
          metal: metal,
          target_price: t,
          direction: condition.toLowerCase(),
        }),
      });

      if (res.success && res.data) {
        setAlerts((a) => [
          {
            id: res.data.id,
            metal: res.data.metal as "GOLD" | "SILVER",
            condition: res.data.direction.toUpperCase() as "ABOVE" | "BELOW",
            target: parseFloat(res.data.target_price),
            enabled: res.data.is_active,
          },
          ...a,
        ]);
        setTarget("");
        toast.success("Alert activated successfully!");
      }
    } catch (err: any) {
      console.error("Error creating alert:", err.message);
      toast.error("Failed to create alert.");
    }
  }

  async function toggle(id: string) {
    const targetAlert = alerts.find((x) => x.id === id);
    if (!targetAlert) return;
    const nextVal = !targetAlert.enabled;

    // Optimistic UI update
    setAlerts((a) => a.map((x) => (x.id === id ? { ...x, enabled: nextVal } : x)));

    try {
      const res = await fetchWithAuth(`/alerts/${id}`, {
        method: "PUT",
        body: JSON.stringify({ is_active: nextVal }),
      });

      if (!res.success) throw new Error("API responded with failure");
    } catch (err: any) {
      console.error("Error updating alert:", err.message);
      toast.error("Failed to toggle alert status.");
      // Revert UI state
      setAlerts((a) => a.map((x) => (x.id === id ? { ...x, enabled: !nextVal } : x)));
    }
  }

  async function remove(id: string) {
    const targetAlert = alerts.find((x) => x.id === id);
    if (!targetAlert) return;

    // Optimistic UI update
    setAlerts((a) => a.filter((x) => x.id !== id));

    try {
      const res = await fetchWithAuth(`/alerts/${id}`, {
        method: "DELETE",
      });

      if (!res.success) throw new Error("API responded with failure");
      toast.success("Alert deleted.");
    } catch (err: any) {
      console.error("Error deleting alert:", err.message);
      toast.error("Failed to delete alert.");
      // Revert UI state
      if (targetAlert) setAlerts((a) => [targetAlert, ...a]);
    }
  }

  return (
    <div className="px-5 pt-6">
      <header className="mb-5">
        <p className="text-[0.65rem] font-semibold uppercase tracking-widest text-gold">Notify me when</p>
        <h1 className="mt-1 font-display text-2xl font-bold">Price Alerts</h1>
      </header>

      {/* Create form */}
      <section className="rounded-2xl border border-white/10 bg-card p-4">
        <Segmented
          options={["GOLD", "SILVER"] as const}
          value={metal}
          onChange={setMetal}
        />

        <div className="mt-4 grid grid-cols-2 gap-2">
          <ConditionPill
            label="Drops Below"
            Icon={TrendingDown}
            active={condition === "BELOW"}
            tint="ask"
            onClick={() => setCondition("BELOW")}
          />
          <ConditionPill
            label="Rises Above"
            Icon={TrendingUp}
            active={condition === "ABOVE"}
            tint="bid"
            onClick={() => setCondition("ABOVE")}
          />
        </div>

        <div className="mt-4 space-y-2">
          <label className="text-[0.65rem] font-semibold uppercase tracking-wider text-muted-foreground">
            Target price (₹)
          </label>
          <Input
            inputMode="decimal"
            placeholder={metal === "GOLD" ? "e.g. 74000" : "e.g. 92000"}
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            className="h-12 bg-surface text-lg font-semibold"
          />
        </div>

        <Button onClick={add} className="mt-4 h-12 w-full bg-gold font-display text-sm font-bold tracking-[0.18em] gold-glow hover:opacity-90">
          ACTIVATE ALERT
        </Button>
      </section>

      {/* Active list */}
      <section className="mt-6">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-base font-bold">Active alerts</h2>
          <span className="text-[0.65rem] uppercase tracking-widest text-muted-foreground">
            {loading ? "..." : `${alerts.length} set`}
          </span>
        </div>
        <ul className="space-y-2.5">
          {loading ? (
            <li className="h-20 animate-pulse rounded-2xl border border-white/10 bg-card" />
          ) : alerts.length === 0 ? (
            <li className="rounded-2xl border border-dashed border-white/10 p-6 text-center text-sm text-muted-foreground">
              No alerts yet — create one above.
            </li>
          ) : (
            alerts.map((a) => (
              <li key={a.id} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-card p-3.5">
                <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${a.condition === "ABOVE" ? "bg-bid/15 text-bid" : "bg-ask/15 text-ask"}`}>
                  {a.condition === "ABOVE" ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-display text-sm font-bold">
                    {a.metal} {a.condition === "ABOVE" ? "rises above" : "drops below"}
                  </p>
                  <p className="text-[0.7rem] text-muted-foreground">
                    ₹ {a.target.toLocaleString("en-IN")}
                  </p>
                </div>
                <Switch checked={a.enabled} onCheckedChange={() => toggle(a.id)} />
                <button onClick={() => remove(a.id)} className="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground hover:text-destructive">
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))
          )}
        </ul>
      </section>
    </div>
  );
}

function Segmented<T extends string>({ options, value, onChange }: { options: readonly T[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="grid grid-cols-2 gap-1 rounded-xl bg-surface-2 p-1">
      {options.map((o) => {
        const active = o === value;
        return (
          <button
            key={o}
            onClick={() => onChange(o)}
            className={`rounded-lg py-2.5 text-xs font-bold tracking-[0.18em] transition-all ${
              active ? "bg-gold text-primary-foreground gold-glow" : "text-muted-foreground"
            }`}
          >
            {o}
          </button>
        );
      })}
    </div>
  );
}

function ConditionPill({
  label, Icon, active, tint, onClick,
}: {
  label: string;
  Icon: typeof TrendingUp;
  active: boolean;
  tint: "bid" | "ask";
  onClick: () => void;
}) {
  const accent = tint === "bid" ? "text-bid border-bid/60 bg-bid/10" : "text-ask border-ask/60 bg-ask/10";
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-center gap-2 rounded-xl border px-3 py-3 text-xs font-semibold transition-all ${
        active ? accent : "border-white/10 bg-surface text-muted-foreground"
      }`}
    >
      <Icon className="h-4 w-4" />
      {label}
    </button>
  );
}