import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getProfile, signOut } from "@/lib/auth";
import { LogOut, MapPin, MessageCircle } from "lucide-react";
import { fetchWithAuth } from "@/lib/api";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Laxmi Abhushan" },
      { name: "description", content: "Trader profile, preferences and support for Laxmi Abhushan bullion trading." },
    ],
  }),
  component: ProfileScreen,
});

function ProfileScreen() {
  const navigate = useNavigate();
  const [profile, setProfile] = useState(() => ({ name: "—", email: "—", contact: "—", company: "—" }));
  const [pushOn, setPushOn] = useState(true);
  const [highContrast, setHighContrast] = useState(false);
  const [role, setRole] = useState("user");
  const [config, setConfig] = useState({
    gold_badla_markup: 150,
    silver_badla_markup: 250,
    use_mock_data: true,
    kite_api_key: "",
    kite_api_secret: "",
    kite_access_token: ""
  });
  const [loadingConfig, setLoadingConfig] = useState(false);
const [savingConfig, setSavingConfig] = useState(false);

  const kiteCallbackUrl = "http://localhost:3000/api/config/kite-callback";
  const kitePostbackUrl = "http://localhost:3000/api/config/kite-postback";

  async function loadDealerConfig() {
    setLoadingConfig(true);
    try {
      const response = await fetch("http://localhost:3000/api/config");
      const resData = await response.json();
      if (resData.success && resData.data) {
        setConfig((prev) => ({
          ...prev,
          ...resData.data,
          gold_badla_markup: resData.data.gold_badla_markup ?? 150,
          silver_badla_markup: resData.data.silver_badla_markup ?? 250,
          use_mock_data: resData.data.use_mock_data ?? true,
          kite_api_key: resData.data.kite_api_key ?? "",
          kite_api_secret: resData.data.kite_api_secret ?? "",
          kite_access_token: resData.data.kite_access_token ?? ""
        }));
      }
    } catch (err) {
      console.error("Failed to load dealer config:", err);
    } finally {
      setLoadingConfig(false);
    }
  }

  useEffect(() => {
    setProfile(getProfile());

    async function loadPreferencesAndRole() {
      try {
        const res = await fetchWithAuth("/profile");
        if (res.success && res.data) {
          const data = res.data;
          setRole(data.role || "user");
          if (data.preferences) {
            if (data.preferences.pushOn !== undefined) setPushOn(data.preferences.pushOn);
            if (data.preferences.highContrast !== undefined) setHighContrast(data.preferences.highContrast);
          }
          setProfile({
            name: data.full_name || "New Trader",
            email: data.email || "—",
            contact: data.phone || "—",
            company: data.business_name || "—",
          });
          if (data.role === "admin" || data.role === "dealer") {
            loadDealerConfig();
          }
        }
      } catch (err: any) {
        console.error("Failed to load profile via API Gateway:", err.message);
      }
    }
    loadPreferencesAndRole();

    // Check if redirect query parameters exist
    const urlParams = new URLSearchParams(window.location.search);
    const kiteLoginStatus = urlParams.get("kite_login");
    const kiteLoginMessage = urlParams.get("message");

    if (kiteLoginStatus === "success") {
      toast.success("Zerodha Kite connected successfully! Live feed started.");
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (kiteLoginStatus === "error") {
      toast.error(decodeURIComponent(kiteLoginMessage || "Zerodha Kite connection failed."));
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  async function updatePreference(key: "pushOn" | "highContrast", val: boolean) {
    const nextPush = key === "pushOn" ? val : pushOn;
    const nextContrast = key === "highContrast" ? val : highContrast;

    if (key === "pushOn") setPushOn(val);
    else setHighContrast(val);

    try {
      await fetchWithAuth("/profile", {
        method: "PUT",
        body: JSON.stringify({
          preferences: {
            pushOn: nextPush,
            highContrast: nextContrast,
          }
        })
      });
    } catch (err: any) {
      console.error("Failed to save preference via API Gateway:", err.message);
      toast.error("Failed to save settings.");
    }
  }

  async function saveDealerConfig(e: React.FormEvent) {
    e.preventDefault();
    setSavingConfig(true);
    try {
      const response = await fetch("http://localhost:3000/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          gold_badla_markup: Number(config.gold_badla_markup),
          silver_badla_markup: Number(config.silver_badla_markup),
          use_mock_data: config.use_mock_data,
          kite_api_key: config.kite_api_key,
          kite_api_secret: config.kite_api_secret
        })
      });
      const resData = await response.json();
      if (resData.success) {
        toast.success("Dealer configuration updated successfully.");
        // Refresh local state config
        loadDealerConfig();
      } else {
        toast.error(resData.error || "Failed to save configuration.");
      }
    } catch (err) {
      console.error("Error saving dealer config:", err);
      toast.error("Error saving configuration.");
    } finally {
      setSavingConfig(false);
    }
  }

  async function handleKiteLogin() {
    try {
      // First save current config state (specifically keys if edited)
      await fetch("http://localhost:3000/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          gold_badla_markup: Number(config.gold_badla_markup),
          silver_badla_markup: Number(config.silver_badla_markup),
          use_mock_data: config.use_mock_data,
          kite_api_key: config.kite_api_key,
          kite_api_secret: config.kite_api_secret
        })
      });

      const response = await fetch("http://localhost:3000/api/config/kite-login-url");
      const resData = await response.json();
      if (resData.success && resData.data?.url) {
        window.location.href = resData.data.url;
      } else {
        toast.error(resData.error || "Failed to fetch login URL. Check API Key configuration.");
      }
    } catch (err) {
      console.error("Error getting Kite URL:", err);
      toast.error("Error redirecting to Zerodha.");
    }
  }

  async function onSignOut() {
    await signOut();
    navigate({ to: "/login" });
  }

  return (
    <div className="px-5 pt-6 pb-24 max-w-md mx-auto">
      <header className="mb-5 flex items-center gap-4">
        <div className="grid h-14 w-14 place-items-center rounded-2xl bg-gold font-display text-xl font-bold text-primary-foreground gold-glow">
          {(profile.name || "T").slice(0, 1).toUpperCase()}
        </div>
        <div className="min-w-0">
          <h1 className="truncate font-display text-xl font-bold">{profile.name}</h1>
          <p className="truncate text-xs text-muted-foreground">{profile.company}</p>
        </div>
      </header>

      <SectionTitle>Trader identification</SectionTitle>
      <ul className="divide-y divide-white/5 rounded-2xl border border-white/10 bg-card">
        <Row label="Name" value={profile.name} />
        <Row label="Contact" value={profile.contact} />
        <Row label="Email" value={profile.email} muted />
        <Row label="Company" value={profile.company} />
        <Row label="Role" value={role.toUpperCase()} muted />
      </ul>

      <SectionTitle className="mt-6">Preferences</SectionTitle>
      <ul className="divide-y divide-white/5 rounded-2xl border border-white/10 bg-card">
        <ToggleRow
          label="Rate Push Notifications"
          description="Send a tick alert when targets are hit."
          checked={pushOn}
          onChange={(val) => updatePreference("pushOn", val)}
        />
        <ToggleRow
          label="High Contrast Ticks"
          description="Brighten BID / ASK colors for daylight reading."
          checked={highContrast}
          onChange={(val) => updatePreference("highContrast", val)}
        />
      </ul>

      {(role === "admin" || role === "dealer") && (
        <div className="mt-6 space-y-2">
          <SectionTitle>Dealer Controls</SectionTitle>
          <form onSubmit={saveDealerConfig} className="space-y-4 rounded-2xl border border-white/10 bg-card p-4">
            <div className="rounded-2xl border border-gold/20 bg-gold/5 p-4">
              <h3 className="text-[0.7rem] font-extrabold uppercase tracking-[0.1em] text-gold">Kite Setup Guide</h3>
              <ol className="mt-2 space-y-2 text-xs leading-relaxed text-muted-foreground">
                <li>1. Sign up or log in to the official Kite Developer Console.</li>
                <li>2. Add billing credits, then create a new app under My Apps.</li>
                <li>3. Use the exact callback URL below when registering the app.</li>
                <li>4. Copy the API Key and API Secret into the fields in this panel, then connect Kite.</li>
              </ol>
              <div className="mt-3 space-y-2 rounded-xl border border-white/10 bg-surface p-3">
                <div>
                  <p className="text-[0.62rem] font-bold uppercase tracking-wider text-muted-foreground">Redirect URL</p>
                  <p className="mt-1 break-all text-[0.72rem] font-medium text-foreground">{kiteCallbackUrl}</p>
                </div>
                <div>
                  <p className="text-[0.62rem] font-bold uppercase tracking-wider text-muted-foreground">Postback URL</p>
                  <p className="mt-1 break-all text-[0.72rem] font-medium text-foreground">{kitePostbackUrl}</p>
                  <p className="mt-1 text-[0.62rem] leading-snug text-muted-foreground">Optional. Leaving this blank is also fine.</p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="min-w-0 pr-2">
                <p className="text-sm font-semibold text-foreground">Mock Data Mode</p>
                <p className="text-[0.65rem] leading-snug text-muted-foreground">Run local simulator instead of live MCX rates.</p>
              </div>
              <Switch 
                checked={config.use_mock_data} 
                onCheckedChange={(val) => setConfig(prev => ({ ...prev, use_mock_data: val }))} 
              />
            </div>
            
            <hr className="border-white/5" />

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label htmlFor="gold_badla" className="text-[0.65rem] font-bold uppercase tracking-wider text-muted-foreground">Gold Badla (₹)</Label>
                <Input 
                  id="gold_badla"
                  type="number"
                  value={config.gold_badla_markup}
                  onChange={(e) => setConfig(prev => ({ ...prev, gold_badla_markup: Number(e.target.value) }))}
                  className="bg-surface border-white/10 rounded-xl h-10 text-sm font-medium"
                  required
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="silver_badla" className="text-[0.65rem] font-bold uppercase tracking-wider text-muted-foreground">Silver Badla (₹)</Label>
                <Input 
                  id="silver_badla"
                  type="number"
                  value={config.silver_badla_markup}
                  onChange={(e) => setConfig(prev => ({ ...prev, silver_badla_markup: Number(e.target.value) }))}
                  className="bg-surface border-white/10 rounded-xl h-10 text-sm font-medium"
                  required
                />
              </div>
            </div>

            {!config.use_mock_data && (
              <>
                <hr className="border-white/5" />
                <div className="space-y-3">
                  <h3 className="text-[0.7rem] font-extrabold uppercase tracking-[0.1em] text-gold">Zerodha Kite Connect Live API</h3>
                  <div className="space-y-1">
                    <Label htmlFor="kite_api_key" className="text-[0.65rem] font-bold uppercase tracking-wider text-muted-foreground">API Key</Label>
                    <Input 
                      id="kite_api_key"
                      type="text"
                      value={config.kite_api_key}
                      onChange={(e) => setConfig(prev => ({ ...prev, kite_api_key: e.target.value }))}
                      className="bg-surface border-white/10 rounded-xl h-10 text-sm font-medium"
                      placeholder="Enter Kite API Key"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <Label htmlFor="kite_api_secret" className="text-[0.65rem] font-bold uppercase tracking-wider text-muted-foreground">API Secret</Label>
                    <Input 
                      id="kite_api_secret"
                      type="password"
                      value={config.kite_api_secret}
                      onChange={(e) => setConfig(prev => ({ ...prev, kite_api_secret: e.target.value }))}
                      className="bg-surface border-white/10 rounded-xl h-10 text-sm font-medium"
                      placeholder={config.kite_api_secret ? "••••••" : "Enter Kite API Secret"}
                      required={!config.kite_api_secret}
                    />
                  </div>

                  {config.kite_access_token ? (
                    <div className="rounded-xl bg-up/10 border border-up/20 p-3 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-up">Connected to Zerodha</p>
                        <p className="text-[0.6rem] text-muted-foreground truncate max-w-[150px]">{config.kite_access_token}</p>
                      </div>
                      <Button
                        type="button"
                        onClick={handleKiteLogin}
                        variant="outline"
                        size="sm"
                        className="text-[0.65rem] border-white/10 rounded-lg h-7 px-2.5 font-bold"
                      >
                        RE-CONNECT
                      </Button>
                    </div>
                  ) : (
                    <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 p-3 flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-amber-500">Kite Disconnected</p>
                        <p className="text-[0.6rem] text-muted-foreground">Session token required for live rates.</p>
                      </div>
                      <Button
                        type="button"
                        onClick={handleKiteLogin}
                        variant="secondary"
                        size="sm"
                        className="bg-amber-500 hover:bg-amber-600 text-white text-[0.65rem] rounded-lg h-7 px-2.5 font-bold"
                        disabled={!config.kite_api_key}
                      >
                        CONNECT KITE
                      </Button>
                    </div>
                  )}
                </div>
              </>
            )}

            <Button
              type="submit"
              disabled={savingConfig || loadingConfig}
              className="w-full bg-gold hover:bg-gold/80 text-primary-foreground font-display font-bold text-xs tracking-widest rounded-xl h-10 mt-1"
            >
              {savingConfig ? "SAVING CONFIG..." : "SAVE DEALER CONFIGURATION"}
            </Button>
          </form>
        </div>
      )}

      <SectionTitle className="mt-6">Support</SectionTitle>
      <div className="grid grid-cols-2 gap-3">
        <a
          href="https://wa.me/919820012345"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-card py-4 font-display text-sm font-bold tracking-wider"
        >
          <MessageCircle className="h-4 w-4 text-up" />
          WHATSAPP
        </a>
        <a
          href="https://maps.google.com/?q=Zaveri+Bazaar+Mumbai"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-card py-4 font-display text-sm font-bold tracking-wider"
        >
          <MapPin className="h-4 w-4 text-gold" />
          VISIT US
        </a>
      </div>

      <Button
        onClick={onSignOut}
        variant="ghost"
        className="mt-8 h-12 w-full rounded-2xl border border-white/10 bg-surface font-display text-sm font-bold tracking-[0.18em] text-destructive hover:bg-destructive/10"
      >
        <LogOut className="mr-2 h-4 w-4" />
        SIGN OUT
      </Button>

      <p className="mt-6 text-center text-[0.65rem] uppercase tracking-widest text-muted-foreground">
        Laxmi Abhushan · v1.0
      </p>
    </div>
  );
}

function SectionTitle({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <h2 className={`mb-2 text-[0.65rem] font-bold uppercase tracking-[0.22em] text-muted-foreground ${className}`}>
      {children}
    </h2>
  );
}

function Row({ label, value, muted = false }: { label: string; value: string; muted?: boolean }) {
  return (
    <li className="grid grid-cols-[110px_minmax(0,1fr)] items-center gap-3 px-4 py-3.5">
      <span className="text-[0.7rem] font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <span className={`truncate text-sm font-medium ${muted ? "text-muted-foreground" : "text-foreground"}`}>{value}</span>
    </li>
  );
}

function ToggleRow({
  label, description, checked, onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <li className="flex items-center gap-3 px-4 py-3.5">
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-foreground">{label}</p>
        <p className="text-[0.7rem] text-muted-foreground">{description}</p>
      </div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </li>
  );
}
