import { createFileRoute } from "@tanstack/react-router";
import { COMMODITIES, TICKER_INDICES } from "@/lib/mock-data";
import { useLiveRates, direction, formatPrice } from "@/lib/use-live-rates";
import { ArrowDownRight, ArrowUpRight, MessageSquare, PhoneCall } from "lucide-react";
import { useMemo } from "react";

export const Route = createFileRoute("/_app/rates")({
  head: () => ({
    meta: [
      { title: "Live Rates — Laxmi Abhushan" },
      { name: "description", content: "Live gold and silver bullion BID / ASK rates with daily highs and lows." },
    ],
  }),
  component: RatesScreen,
});

function RatesScreen() {
  const seed = useMemo(() => {
    const out: Record<string, number> = {};
    for (const t of TICKER_INDICES) out[`idx:${t.id}`] = t.base;
    for (const c of COMMODITIES) out[c.id] = c.base;
    return out;
  }, []);
  const rates = useLiveRates(seed, 0.0009, 1400);

  return (
    <div className="flex h-full flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 border-b border-white/10 bg-background/90 px-5 pb-3 pt-5 backdrop-blur">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display text-xl font-bold tracking-[0.32em]">LAXMI</h1>
            <p className="font-display text-[0.6rem] font-medium tracking-[0.4em] text-gold">ABHUSHAN</p>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-white/10 bg-surface px-3 py-1.5">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-up opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-up" />
            </span>
            <span className="text-[0.65rem] font-semibold uppercase tracking-widest text-foreground">Live</span>
          </div>
        </div>
      </header>

      {/* Ticker row */}
      <div className="no-scrollbar flex gap-3 overflow-x-auto py-4">
        <div className="w-5 shrink-0" />
        {TICKER_INDICES.map((t) => {
          const r = rates[`idx:${t.id}`];
          if (!r) return null;
          const mid = (r.bid + r.ask) / 2;
          const prevMid = (r.prevBid + r.prevAsk) / 2;
          const dir = direction(mid, prevMid);
          const delta = ((mid - t.base) / t.base) * 100;
          return (
            <div key={t.id} className="min-w-[148px] shrink-0 rounded-2xl border border-white/10 bg-card p-4">
              <p className="text-[0.65rem] font-semibold uppercase tracking-widest text-muted-foreground">{t.label}</p>
              <p className="mt-2 font-display text-xl font-bold text-foreground">{formatPrice(mid)}</p>
              <div className="mt-1 flex items-center justify-between text-[0.7rem]">
                <span className="text-muted-foreground">{t.unit}</span>
                <span className={`flex items-center gap-0.5 font-semibold ${dir === "down" ? "text-down" : "text-up"}`}>
                  {dir === "down" ? <ArrowDownRight className="h-3 w-3" /> : <ArrowUpRight className="h-3 w-3" />}
                  {Math.abs(delta).toFixed(2)}%
                </span>
              </div>
              <Sparkline seed={mid} dir={dir} />
            </div>
          );
        })}
        <div className="w-5 shrink-0" />
      </div>

      {/* Commodities list */}
      <div className="px-5 pb-32">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-base font-bold">Live Commodities</h2>
          <p className="text-[0.65rem] uppercase tracking-widest text-muted-foreground">BID / ASK · INR</p>
        </div>
        <div className="space-y-3">
          {COMMODITIES.map((c) => {
            const r = rates[c.id];
            if (!r) return null;
            const bidDir = direction(r.bid, r.prevBid);
            const askDir = direction(r.ask, r.prevAsk);
            return (
              <article key={c.id} className="rounded-2xl border border-white/10 bg-card p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-display text-[0.95rem] font-bold leading-tight">{c.name}</h3>
                    <span className="mt-1 inline-flex items-center rounded-md bg-surface-2 px-1.5 py-0.5 text-[0.6rem] font-semibold uppercase tracking-wider text-gold">
                      {c.purity}
                    </span>
                  </div>
                  <div className="text-right text-[0.65rem] text-muted-foreground">
                    <p>High <span className="font-semibold text-up">{formatPrice(c.high)}</span></p>
                    <p>Low <span className="font-semibold text-down">{formatPrice(c.low)}</span></p>
                  </div>
                </div>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <RateButton kind="bid" value={r.bid} dir={bidDir} />
                  <RateButton kind="ask" value={r.ask} dir={askDir} />
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Quick actions */}
      <div className="sticky bottom-20 mx-5 mb-4 grid grid-cols-2 gap-3 rounded-2xl border border-white/10 bg-card/95 p-3 backdrop-blur">
        <button className="flex items-center justify-center gap-2 rounded-xl bg-gold py-3 font-display text-sm font-bold tracking-wider text-primary-foreground gold-glow">
          <PhoneCall className="h-4 w-4" /> ENQUIRY
        </button>
        <button className="flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-surface py-3 font-display text-sm font-bold tracking-wider text-foreground">
          <MessageSquare className="h-4 w-4 text-gold" /> CHAT
        </button>
      </div>
    </div>
  );
}

function RateButton({ kind, value, dir }: { kind: "bid" | "ask"; value: number; dir: "up" | "down" | "flat" }) {
  const bg = kind === "bid" ? "bg-bid text-bid-foreground" : "bg-ask text-ask-foreground";
  const flash = dir === "up" ? "tick-flash-up" : dir === "down" ? "tick-flash-down" : "";
  return (
    <button
      key={value.toFixed(2)}
      className={`relative flex flex-col items-center rounded-xl px-3 py-2.5 transition-transform active:scale-[0.98] ${bg} ${flash}`}
    >
      <span className="text-[0.6rem] font-bold uppercase tracking-[0.2em] opacity-80">
        {kind === "bid" ? "BID · BUY" : "ASK · SELL"}
      </span>
      <span className="font-display text-lg font-bold leading-tight">{formatPrice(value)}</span>
    </button>
  );
}

function Sparkline({ seed, dir }: { seed: number; dir: "up" | "down" | "flat" }) {
  // deterministic-ish micro-sparkline derived from seed digits
  const points = Array.from({ length: 16 }, (_, i) => {
    const s = Math.sin(seed * 0.0007 + i * 0.9) + Math.sin(seed * 0.0003 + i * 0.4);
    return 12 - s * 4;
  });
  const path = points.map((y, i) => `${i === 0 ? "M" : "L"}${i * 8},${y.toFixed(1)}`).join(" ");
  const stroke = dir === "down" ? "var(--color-down)" : "var(--color-up)";
  return (
    <svg viewBox="0 0 120 24" className="mt-2 h-6 w-full">
      <path d={path} fill="none" stroke={stroke} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}