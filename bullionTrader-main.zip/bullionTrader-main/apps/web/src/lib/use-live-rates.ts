import { useEffect, useRef, useState } from "react";
import { supabase } from "./supabase";

type Tick = { bid: number; ask: number; prevBid: number; prevAsk: number };

function jitter(base: number, magnitude: number) {
  return base + (Math.random() - 0.5) * magnitude;
}

export function useLiveRates(seed: Record<string, number>, magnitudeFactor = 0.0008, intervalMs = 1500) {
  const [rates, setRates] = useState<Record<string, Tick>>(() => {
    const out: Record<string, Tick> = {};
    for (const [k, v] of Object.entries(seed)) {
      const spread = v * 0.0006;
      out[k] = { bid: v - spread, ask: v + spread, prevBid: v - spread, prevAsk: v + spread };
    }
    return out;
  });

  const lastLiveUpdateRef = useRef<number>(0);
  const seedRef = useRef(seed);
  seedRef.current = seed;

  useEffect(() => {
    // 1. Subscribe to Supabase Realtime Channel
    const channel = supabase.channel("bullion_rates_client", {
      config: { broadcast: { ack: false } }
    });

    channel
      .on("broadcast", { event: "rate-update" }, (message) => {
        const payload = message.payload;
        if (!payload) return;

        lastLiveUpdateRef.current = Date.now();

        setRates((curr) => {
          const next = { ...curr };

          // Extract values
          const gBid = payload.gold.bid;
          const gAsk = payload.gold.ask;
          const gMcx = payload.gold.base_mcx;

          const sBid = payload.silver.bid;
          const sAsk = payload.silver.ask;
          const sMcx = payload.silver.base_mcx;

          // Map to tickers & commodities
          // Gold
          if (curr["idx:gold"]) {
            next["idx:gold"] = { bid: gBid, ask: gAsk, prevBid: curr["idx:gold"].bid, prevAsk: curr["idx:gold"].ask };
          }
          if (curr["gold-rtgs"]) {
            next["gold-rtgs"] = { bid: gBid, ask: gAsk, prevBid: curr["gold-rtgs"].bid, prevAsk: curr["gold-rtgs"].ask };
          }
          if (curr["gold-995-mcx"]) {
            next["gold-995-mcx"] = { bid: gMcx - 300, ask: gMcx + 300, prevBid: curr["gold-995-mcx"].bid, prevAsk: curr["gold-995-mcx"].ask };
          }

          // Silver
          if (curr["idx:silver"]) {
            next["idx:silver"] = { bid: sBid, ask: sAsk, prevBid: curr["idx:silver"].bid, prevAsk: curr["idx:silver"].ask };
          }
          if (curr["silver-rtgs"]) {
            next["silver-rtgs"] = { bid: sBid, ask: sAsk, prevBid: curr["silver-rtgs"].bid, prevAsk: curr["silver-rtgs"].ask };
          }
          if (curr["silver-999-mcx"]) {
            next["silver-999-mcx"] = { bid: sMcx - 400, ask: sMcx + 400, prevBid: curr["silver-999-mcx"].bid, prevAsk: curr["silver-999-mcx"].ask };
          }

          // USD/INR ticker (simulate slowly if not in payload, or keep current)
          const prevUsd = curr["idx:usdinr"] || { bid: 83.42, ask: 83.45, prevBid: 83.42, prevAsk: 83.45 };
          const newUsdVal = jitter((prevUsd.bid + prevUsd.ask) / 2, 0.02);
          next["idx:usdinr"] = { bid: newUsdVal - 0.02, ask: newUsdVal + 0.02, prevBid: prevUsd.bid, prevAsk: prevUsd.ask };

          // Badla (keep simulated or static)
          if (curr["badla-gold"]) {
            const prevBadla = curr["badla-gold"];
            const newBadlaVal = jitter((prevBadla.bid + prevBadla.ask) / 2, 0.5);
            next["badla-gold"] = { bid: newBadlaVal - 1, ask: newBadlaVal + 1, prevBid: prevBadla.bid, prevAsk: prevBadla.ask };
          }

          return next;
        });
      })
      .subscribe((status) => {
        if (status === "SUBSCRIBED") {
          console.log("📡 Connected to Supabase Realtime channel for live rates.");
        }
      });

    // 2. Fallback Jitter Simulator (ticks client-side if no Supabase updates are received)
    const id = setInterval(() => {
      const timeSinceLastLive = Date.now() - lastLiveUpdateRef.current;
      
      // If we haven't received a live update in the last 4 seconds, fallback to local jitter
      if (timeSinceLastLive > 4000) {
        setRates((curr) => {
          const next: Record<string, Tick> = {};
          for (const [k, v] of Object.entries(seedRef.current)) {
            const prev = curr[k] ?? { bid: v, ask: v, prevBid: v, prevAsk: v };
            const mag = v * magnitudeFactor;
            const spread = v * 0.0006;
            const mid = jitter((prev.bid + prev.ask) / 2, mag * 2);
            const reverted = mid + (v - mid) * 0.1;
            next[k] = {
              bid: reverted - spread,
              ask: reverted + spread,
              prevBid: prev.bid,
              prevAsk: prev.ask,
            };
          }
          return next;
        });
      }
    }, intervalMs);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(id);
    };
  }, [magnitudeFactor, intervalMs]);

  return rates;
}

export function direction(curr: number, prev: number): "up" | "down" | "flat" {
  if (curr > prev) return "up";
  if (curr < prev) return "down";
  return "flat";
}

export function formatPrice(n: number): string {
  if (n >= 1000) return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
  return n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}