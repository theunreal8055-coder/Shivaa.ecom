export type Commodity = {
  id: string;
  name: string;
  purity: string;
  base: number;
  high: number;
  low: number;
};

export const COMMODITIES: Commodity[] = [
  { id: "gold-995-mcx", name: "Gold 995 MCX", purity: "995", base: 73540, high: 73820, low: 73280 },
  { id: "silver-999-mcx", name: "Silver 999 MCX", purity: "999", base: 92080, high: 92750, low: 91420 },
  { id: "gold-rtgs", name: "Gold RTGS", purity: "999", base: 73420, high: 73680, low: 73120 },
  { id: "silver-rtgs", name: "Silver RTGS", purity: "999", base: 92150, high: 92840, low: 91560 },
  { id: "badla-gold", name: "Badla Rate Gold", purity: "Per 10g / Month", base: 245, high: 265, low: 220 },
];

export const TICKER_INDICES = [
  { id: "gold", label: "GOLD 995 MCX", unit: "₹/10g", base: 73540 },
  { id: "silver", label: "SILVER 999 MCX", unit: "₹/kg", base: 92080 },
  { id: "usdinr", label: "USD/INR", unit: "₹", base: 83.42 },
];