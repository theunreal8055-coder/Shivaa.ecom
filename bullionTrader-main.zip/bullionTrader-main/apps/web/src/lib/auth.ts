import { supabase } from "./supabase";

const KEY = "laxmi_auth";

export interface ProfileData {
  name: string;
  email: string;
  company: string;
  contact: string;
}

const defaultProfile: ProfileData = {
  name: "Rohan Mehta",
  email: "rohan@laxmibullion.in",
  company: "Mehta Jewellers",
  contact: "+91 98200 12345",
};

export async function signIn(email: string, password: string): Promise<{ success: boolean; error?: string }> {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      return { success: false, error: error.message };
    }

    if (data.user) {
      // Fetch user profile from the profiles table safely
      let profileData = null;
      try {
        const { data: pData } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", data.user.id)
          .maybeSingle();
        profileData = pData;
      } catch (e: any) {
        console.warn("Failed to fetch profile row on login (likely schema mismatch):", e.message);
      }

      const profile = {
        name: profileData?.full_name || data.user.user_metadata?.full_name || "New Trader",
        email: data.user.email || email,
        company: profileData?.business_name || data.user.user_metadata?.business_name || "—",
        contact: profileData?.phone_number || profileData?.phone || data.user.user_metadata?.phone || "",
      };

      localStorage.setItem(KEY, JSON.stringify({ signedIn: true, profile }));
      return { success: true };
    }
    return { success: false, error: "Authentication failed" };
  } catch (err: any) {
    return { success: false, error: err.message || "An unexpected error occurred" };
  }
}

export async function signUp(form: {
  name: string;
  phone: string;
  company: string;
  email: string;
  password: string;
}): Promise<{ success: boolean; error?: string }> {
  try {
    const { data, error } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: {
        emailRedirectTo: typeof window !== "undefined" ? window.location.origin : undefined,
        data: {
          full_name: form.name,
          phone: form.phone,
          business_name: form.company,
        },
      },
    });

    if (error) {
      return { success: false, error: error.message };
    }

    if (data.user) {
      const profile = {
        name: form.name,
        email: form.email,
        company: form.company,
        contact: form.phone,
      };

      localStorage.setItem(KEY, JSON.stringify({ signedIn: true, profile }));
      return { success: true };
    }
    return { success: false, error: "Registration failed" };
  } catch (err: any) {
    return { success: false, error: err.message || "An unexpected error occurred" };
  }
}

export async function signOut() {
  await supabase.auth.signOut();
  if (typeof window !== "undefined") {
    localStorage.removeItem(KEY);
  }
}

export function isSignedIn(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return false;
    return JSON.parse(raw)?.signedIn === true;
  } catch {
    return false;
  }
}

export function getProfile(): ProfileData {
  if (typeof window === "undefined") return defaultProfile;
  try {
    const raw = localStorage.getItem(KEY);
    const data = raw ? JSON.parse(raw) : null;
    return { ...defaultProfile, ...(data?.profile ?? {}) };
  } catch {
    return defaultProfile;
  }
}