import { supabase } from "./supabase";

const API_BASE = "http://localhost:3000/api";

/**
 * Custom fetch wrapper that automatically appends the Supabase JWT token in the Authorization header.
 * Requests route to our Express API Gateway.
 */
export async function fetchWithAuth(path: string, options: RequestInit = {}): Promise<any> {
  const { data: { session } } = await supabase.auth.getSession();
  const token = session?.access_token;

  const headers = new Headers(options.headers);
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  
  if (!headers.has("Content-Type") && !(options.body instanceof FormData)) {
    headers.set("Content-Type", "application/json");
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  const responseJson = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(responseJson.error || `HTTP error ${response.status}`);
  }

  return responseJson;
}
