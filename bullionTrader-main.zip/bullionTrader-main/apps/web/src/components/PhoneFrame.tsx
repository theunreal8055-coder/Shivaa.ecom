import type { ReactNode } from "react";

/**
 * Centers the app inside a phone-shaped bezel on wider viewports so the
 * mobile design reads as a mockup on desktop. On phone widths the frame
 * disappears and the app fills the screen edge-to-edge.
 */
export function PhoneFrame({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen w-full bg-background">
      {/* Mobile: full-bleed */}
      <div className="md:hidden min-h-screen w-full">{children}</div>
      {/* Desktop: phone bezel */}
      <div className="hidden md:flex min-h-screen w-full items-center justify-center p-8" style={{
        backgroundImage:
          "radial-gradient(circle at 30% 20%, color-mix(in oklab, var(--color-gold) 6%, transparent), transparent 50%), radial-gradient(circle at 80% 80%, color-mix(in oklab, var(--color-bid) 8%, transparent), transparent 50%)",
      }}>
        <div className="relative rounded-[3rem] border border-white/10 bg-black p-3 shadow-[0_50px_120px_-30px_rgba(0,0,0,0.8)]">
          <div className="pointer-events-none absolute left-1/2 top-3 z-20 h-6 w-32 -translate-x-1/2 rounded-b-2xl bg-black" />
          <div className="relative h-[860px] w-[400px] overflow-hidden rounded-[2.4rem] bg-background">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}