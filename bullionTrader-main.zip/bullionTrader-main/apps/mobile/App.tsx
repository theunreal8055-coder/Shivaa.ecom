import React, { useEffect, useState, useRef, useCallback } from 'react';
import { StyleSheet, Text, View, StatusBar, Alert } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { supabase } from './src/services/supabase';
import { Session } from '@supabase/supabase-js';
import { COLORS } from './src/theme';
import {
  initializePushNotifications,
  addNotificationReceivedListener,
  addNotificationResponseListener,
  clearBadgeCount,
} from './src/services/notifications';
import type { Notification, NotificationResponse, EventSubscription } from 'expo-notifications';

// Screen Component Imports
import DashboardScreen from './src/screens/dashboard/DashboardScreen';
import AlertsScreen from './src/screens/alerts/AlertsScreen';
import NewsScreen from './src/screens/news/NewsScreen';
import ProfileScreen from './src/screens/profile/ProfileScreen';
import LoginScreen from './src/screens/auth/LoginScreen';
import LoadingScreen from './src/screens/loading/LoadingScreen';
import AdminScreen from './src/screens/admin/AdminScreen';

const Tab = createBottomTabNavigator();

// ─── Simple text-based tab icons (no emoji) ─────────────────────────
const TAB_ICONS: Record<string, string> = {
  'Live Rates': '◉',
  'Alerts':     '◎',
  'News':       '▤',
  'Admin':      '⚙',
  'Profile':    '⬟',
};

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [appReady, setAppReady] = useState<boolean>(false);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [currentRoute, setCurrentRoute] = useState<string>('Live Rates');
  const [pushToken, setPushToken] = useState<string | null>(null);
  const navigationRef = useRef<any>(null);
  const notificationReceivedSub = useRef<EventSubscription | null>(null);
  const notificationResponseSub = useRef<EventSubscription | null>(null);

  const checkAdminRole = async (userId: string) => {
    // The Admin tab is a convenience surface only; all privileged writes are
    // enforced server-side by Supabase Row-Level Security on the user's role.
    try {
      const { data } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', userId)
        .single();
      setIsAdmin(data?.role === 'admin');
    } catch (err) {
      setIsAdmin(false);
    }
  };

  useEffect(() => {
    if (session?.user?.id) {
      checkAdminRole(session.user.id);
    } else {
      setIsAdmin(false);
    }
  }, [session]);

  useEffect(() => {
    // Check session on start with a timeout safety fallback
    let isTransitioned = false;
    const transitionToApp = (sessionVal: Session | null) => {
      if (isTransitioned) return;
      isTransitioned = true;
      setSession(sessionVal);
      setAppReady(true);
    };

    // Race the session check against a safety timeout of 3.5 seconds
    const safetyTimeout = setTimeout(() => {
      console.warn("⚠️ Supabase getSession timed out/took too long. Proceeding to app with fallback/offline state.");
      transitionToApp(null);
    }, 3500);

    supabase.auth.getSession()
      .then(({ data: { session } }) => {
        clearTimeout(safetyTimeout);
        // Add a slight delay for aesthetic transition
        setTimeout(() => {
          transitionToApp(session);
        }, 1000);
      })
      .catch((error) => {
        console.error("Error fetching session on start:", error);
        clearTimeout(safetyTimeout);
        transitionToApp(null);
      });

    // Listen for sign-in / sign-out events
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  // ── Push Notification Registration & Listeners ────────────────────
  useEffect(() => {
    if (!session) {
      // Clean up notification listeners when logged out
      notificationReceivedSub.current?.remove();
      notificationResponseSub.current?.remove();
      return;
    }

    // Initialize push notifications (request permission → get token → sync to backend)
    initializePushNotifications()
      .then((token) => {
        if (token) {
          setPushToken(token);
          console.log('🔔 Push notifications initialized. Token:', token.substring(0, 20) + '...');
        }
      })
      .catch((err) => {
        console.warn('⚠️ Push notification initialization failed:', err);
      });

    // Listen for notifications while the app is in the foreground
    notificationReceivedSub.current = addNotificationReceivedListener(
      (notification: Notification) => {
        const { title, body } = notification.request.content;
        console.log('📬 Notification received in foreground:', title);
        Alert.alert(
          title || 'Laxmi Abhushan',
          body || '',
          [{ text: 'OK', style: 'cancel' }]
        );
      }
    );

    // Listen for when user taps on a notification
    notificationResponseSub.current = addNotificationResponseListener(
      (response: NotificationResponse) => {
        const data = response.notification.request.content.data;
        console.log('👆 User tapped notification:', data);

        // Navigate to Alerts tab if the notification is a price alert
        if (data?.type === 'PRICE_ALERT' && navigationRef.current) {
          navigationRef.current.navigate('Alerts');
        }
      }
    );

    // Clear badge count when the app opens
    clearBadgeCount();

    return () => {
      notificationReceivedSub.current?.remove();
      notificationResponseSub.current?.remove();
    };
  }, [session?.user?.id]);

  // Monitor Realtime Connection Link only when authenticated to prevent unauthenticated connection failures
  useEffect(() => {
    if (!session) {
      setIsConnected(false);
      return;
    }

    console.log('🔌 Subscribing to connection status channel for user:', session.user.email);
    const channel = supabase.channel('bullion_connection_status');
    channel.subscribe((status) => {
      console.log('🔌 App connection status channel event:', status);
      setIsConnected(status === 'SUBSCRIBED');
    });

    return () => {
      console.log('🔌 Unsubscribing from connection status channel');
      supabase.removeChannel(channel);
    };
  }, [session?.user?.id]);

  if (!appReady) {
    return <LoadingScreen />;
  }

  return (
    <SafeAreaProvider>
      <SafeAreaView
        style={styles.container}
        edges={session ? ['top', 'left', 'right'] : ['top', 'bottom', 'left', 'right']}
      >
        <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />

        {session ? (
          <NavigationContainer ref={navigationRef}>
          {/* ── Header ────────────────────────────────────────────── */}
          <View style={styles.header}>
            <View>
              <Text style={styles.brandName}>LAXMI ABHUSHAN</Text>
              <Text style={styles.brandTag}>BULLION TRADING</Text>
            </View>

            {/* Live / Offline pill */}
            <View
              style={[
                styles.statusPill,
                {
                  backgroundColor: isConnected
                    ? 'rgba(91, 202, 122, 0.10)'
                    : 'rgba(239, 91, 91, 0.10)',
                },
              ]}
            >
              <View
                style={[
                  styles.statusDot,
                  {
                    backgroundColor: isConnected
                      ? COLORS.success
                      : COLORS.danger,
                  },
                ]}
              />
              <Text
                style={[
                  styles.statusLabel,
                  {
                    color: isConnected ? COLORS.success : COLORS.danger,
                  },
                ]}
              >
                {isConnected ? 'LIVE' : 'OFFLINE'}
              </Text>
            </View>
          </View>

          {/* ── Tab Navigator ─────────────────────────────────────── */}
          <Tab.Navigator
            screenOptions={({ route }) => ({
              headerShown: false,
              tabBarIcon: ({ color }) => (
                <Text style={{ color, fontSize: 18, marginBottom: -2 }}>
                  {TAB_ICONS[route.name] ?? '·'}
                </Text>
              ),
              tabBarStyle: {
                backgroundColor: COLORS.surface,
                borderTopWidth: 1,
                borderTopColor: COLORS.border,
              },
              tabBarActiveTintColor: COLORS.accent,
              tabBarInactiveTintColor: COLORS.textSecondary,
              tabBarLabelStyle: {
                fontSize: 10,
                fontWeight: '600' as const,
                letterSpacing: 0.8,
              },
            })}
          >
            <Tab.Screen
              name="Live Rates"
              listeners={{
                focus: () => setCurrentRoute('Live Rates'),
              }}
            >
              {() => <DashboardScreen isConnected={isConnected} />}
            </Tab.Screen>

            <Tab.Screen
              name="Alerts"
              component={AlertsScreen}
              listeners={{
                focus: () => setCurrentRoute('Alerts'),
              }}
            />

            <Tab.Screen
              name="News"
              component={NewsScreen}
              listeners={{
                focus: () => setCurrentRoute('News'),
              }}
            />

            {isAdmin && (
              <Tab.Screen
                name="Admin"
                component={AdminScreen}
                listeners={{
                  focus: () => setCurrentRoute('Admin'),
                }}
              />
            )}

            <Tab.Screen
              name="Profile"
              listeners={{
                focus: () => setCurrentRoute('Profile'),
              }}
            >
              {() => <ProfileScreen userEmail={session.user.email} />}
            </Tab.Screen>
          </Tab.Navigator>
        </NavigationContainer>
      ) : (
        <LoginScreen />
      )}
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

// ─── Styles ──────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },

  // ── Header ─────────────────────────────────────────────────────────
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 14,
    backgroundColor: COLORS.background,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  brandName: {
    color: COLORS.textPrimary,
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 2.5,
  },
  brandTag: {
    color: COLORS.accent,
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 2,
    marginTop: 2,
  },

  // ── Status Pill ────────────────────────────────────────────────────
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 14,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
  },
  statusLabel: {
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.2,
  },
});