// ─── Laxmi Abhushan — Design Tokens ─────────────────────────────────
// Dark palette with warm-gold accent for bullion/commodity context.
// All screens should import COLORS from this single source of truth.

export const COLORS = {
  // ── Core surfaces ──────────────────────────────────────────────────
  background:       '#111318',                    // near-black, cool blue undertone
  surface:          '#1C1F26',                    // elevated card / panel
  surfaceLight:     '#252830',                    // nested elements inside cards
  border:           '#2E3139',                    // subtle dividers & outlines

  // ── Typography ─────────────────────────────────────────────────────
  textPrimary:      '#F0F0F3',                    // headings & primary values
  textSecondary:    '#8A8D95',                    // labels, meta, captions

  // ── Brand accent (gold) ────────────────────────────────────────────
  accent:           '#C9A96E',                    // warm gold — primary CTA / active
  accentLight:      'rgba(201, 169, 110, 0.12)',  // tinted background for pills / tags

  // ── Semantic ───────────────────────────────────────────────────────
  bidBlue:          '#5B8DEF',                    // bid price highlight
  askRose:          '#EF6B6B',                    // ask price highlight
  success:          '#5BCA7A',                    // live / connected / positive
  danger:           '#EF5B5B',                    // alerts / errors / disconnected

  // ── Legacy aliases (keeps other screens compiling) ─────────────────
  deepCanvas:       '#111318',
  lightCore:        '#F0F0F3',
  luxuryAccent:     '#C9A96E',
  structuralGlass:  '#2E3139',
  mutedStone:       '#8A8D95',
  darkWell:         '#1C1F26',
  glassBackground:      'rgba(201, 169, 110, 0.06)',
  glassBackgroundHeavy: 'rgba(201, 169, 110, 0.12)',

  // ── Extra aliases used by other screens ────────────────────────────
  textMuted:        '#8A8D95',
  borderSubtle:     '#2E3139',
  surfaceElevated:  '#252830',
  white:            '#F0F0F3',
};

// ─── Typography presets ──────────────────────────────────────────────
export const TYPOGRAPHY = {
  editorialHeader: {
    fontFamily: 'System',
    fontSize: 24,
    fontWeight: '700' as const,
    letterSpacing: 2,
    color: COLORS.textPrimary,
  },
  editorialSubheader: {
    fontFamily: 'System',
    fontSize: 12,
    fontWeight: '600' as const,
    letterSpacing: 1.5,
    color: COLORS.textSecondary,
  },
  primaryNumber: {
    fontFamily: 'System',
    fontSize: 28,
    fontWeight: '700' as const,
    color: COLORS.textPrimary,
  },
  secondaryLabel: {
    fontFamily: 'System',
    fontSize: 11,
    fontWeight: '600' as const,
    letterSpacing: 1,
    color: COLORS.textSecondary,
  },
  buttonText: {
    fontFamily: 'System',
    fontSize: 14,
    fontWeight: '700' as const,
    letterSpacing: 1.5,
  },
};
