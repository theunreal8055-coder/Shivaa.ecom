/**
 * Push Notification Service for BullionTrader Mobile
 *
 * Handles:
 *  1. Requesting push notification permissions (iOS + Android)
 *  2. Retrieving the Expo push token (which wraps the native FCM/APNs token)
 *  3. Syncing the token to the user profile via PUT /api/profile
 *  4. Setting up foreground + background notification handlers
 */

import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform, Alert } from 'react-native';
import { fetchWithAuth } from './api';

// ─── Configure foreground notification presentation ─────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

/**
 * Request permission and retrieve the Expo Push Token (wraps FCM on Android, APNs on iOS).
 * Returns the token string or null if permissions were denied or device is a simulator.
 */
export async function registerForPushNotifications(): Promise<string | null> {
  // Push notifications only work on physical devices
  if (!Device.isDevice) {
    console.warn('⚠️ Push notifications require a physical device. Skipping registration on simulator/emulator.');
    return null;
  }

  // ── Android: create a high-priority notification channel ──────────
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('price-alerts', {
      name: 'Price Alerts',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#C9A96E',
      sound: 'default',
      description: 'Real-time gold & silver price alert notifications',
      enableVibrate: true,
      enableLights: true,
    });

    await Notifications.setNotificationChannelAsync('general', {
      name: 'General',
      importance: Notifications.AndroidImportance.DEFAULT,
      description: 'News updates and general notifications',
    });
  }

  // ── Check existing permissions ────────────────────────────────────
  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  // ── Request permissions if not already granted ────────────────────
  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync({
      ios: {
        allowAlert: true,
        allowBadge: true,
        allowSound: true,
      },
    });
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    console.warn('⚠️ User denied push notification permissions.');
    return null;
  }

  // ── Retrieve the native FCM/APNs device push token ────────────────
  try {
    const tokenData = await Notifications.getDevicePushTokenAsync();
    console.log('🔔 Native Device Push Token retrieved:', tokenData.data);
    return tokenData.data;
  } catch (error: any) {
    console.error('❌ Failed to retrieve native push token:', error.message);
    return null;
  }
}

/**
 * Sync the push token to the backend user profile.
 * Performs a PUT /api/profile with the fcm_token field.
 */
export async function syncPushTokenToBackend(token: string): Promise<boolean> {
  try {
    await fetchWithAuth('/profile', {
      method: 'PUT',
      body: JSON.stringify({ fcm_token: token }),
    });
    
    console.log('✅ FCM token synced to backend profile successfully.');
    return true;
  } catch (error: any) {
    console.error('❌ Failed to sync FCM token to backend:', error.message);
    return false;
  }
}

/**
 * Full registration flow: request permissions → get token → sync to backend.
 * Call this once when the user logs in or the app initializes with an active session.
 */
export async function initializePushNotifications(): Promise<string | null> {
  const token = await registerForPushNotifications();
  
  if (token) {
    const synced = await syncPushTokenToBackend(token);
    if (!synced) {
      // Retry once after a short delay
      setTimeout(async () => {
        const retryResult = await syncPushTokenToBackend(token);
        if (!retryResult) {
          console.warn('⚠️ Push token sync retry also failed. Token will be synced on next app launch.');
        }
      }, 5000);
    }
  }
  
  return token;
}

/**
 * Add a listener for notifications received while the app is in the foreground.
 * Returns a subscription that should be cleaned up on unmount.
 */
export function addNotificationReceivedListener(
  handler: (notification: Notifications.Notification) => void
): Notifications.EventSubscription {
  return Notifications.addNotificationReceivedListener(handler);
}

/**
 * Add a listener for when the user taps on a notification (foreground or background).
 * Returns a subscription that should be cleaned up on unmount.
 */
export function addNotificationResponseListener(
  handler: (response: Notifications.NotificationResponse) => void
): Notifications.EventSubscription {
  return Notifications.addNotificationResponseReceivedListener(handler);
}

/**
 * Get the last notification response if the app was opened via a notification tap.
 */
export async function getLastNotificationResponse(): Promise<Notifications.NotificationResponse | null> {
  return await Notifications.getLastNotificationResponseAsync();
}

/**
 * Reset the app badge count (iOS).
 */
export async function clearBadgeCount(): Promise<void> {
  await Notifications.setBadgeCountAsync(0);
}
