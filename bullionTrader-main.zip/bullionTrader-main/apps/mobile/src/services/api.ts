import { supabase } from './supabase';
import { Platform } from 'react-native';

const getApiBase = () => {
  const customUrl = process.env.EXPO_PUBLIC_API_URL;
  if (customUrl) return customUrl;
  // Fallback depending on host OS and simulator context (Android emulator maps dev machine loopback to 10.0.2.2)
  return Platform.OS === 'android' ? 'http://10.0.2.2:3000/api' : 'http://localhost:3000/api';
};

const API_BASE = getApiBase();

/**
 * Custom fetch wrapper for React Native Expo to call our API Gateway with automatic Supabase JWT headers.
 */
export async function fetchWithAuth(path: string, options: RequestInit = {}): Promise<any> {
  const { data: { session } } = await supabase.auth.getSession();
  const token = session?.access_token;

  const headers = new Headers(options.headers);
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  const responseJson = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(responseJson.error || `HTTP error ${response.status}`);
  }

  return responseJson;
}
