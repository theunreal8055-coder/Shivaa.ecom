/**
 * Supabase-direct data layer.
 *
 * The app talks to Supabase directly (Row-Level Security restricts every row to
 * the authenticated user), so it runs standalone with no API-gateway server.
 * These helpers replace the previous `fetchWithAuth('/alerts' | '/profile')`
 * calls and return plain data (throwing on error) for the screens to consume.
 */
import { supabase } from './supabase';

export type Metal = 'GOLD' | 'SILVER';
export type Direction = 'above' | 'below';

export interface AlertRow {
  id: string;
  metal: Metal;
  commodity_name: string | null;
  target_price: number;
  direction: Direction;
  is_active: boolean;
  is_triggered: boolean;
  created_at?: string;
}

async function currentUserId(): Promise<string> {
  const { data: { user }, error } = await supabase.auth.getUser();
  if (error || !user) throw new Error('Not authenticated');
  return user.id;
}

/** List the signed-in user's price alerts (newest first). */
export async function listAlerts(): Promise<AlertRow[]> {
  const { data, error } = await supabase
    .from('price_alerts')
    .select('*')
    .order('created_at', { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as AlertRow[];
}

/** Create a new price alert for the signed-in user. */
export async function createAlert(input: {
  metal: Metal;
  direction: Direction;
  target_price: number;
}): Promise<AlertRow> {
  const userId = await currentUserId();
  const commodity_name = input.metal === 'GOLD' ? 'Gold Future' : 'Silver Future';
  const { data, error } = await supabase
    .from('price_alerts')
    .insert({
      user_id: userId,
      metal: input.metal,
      direction: input.direction,
      target_price: input.target_price,
      commodity_name,
      is_active: true,
      is_triggered: false,
      notification_sent: false,
    })
    .select()
    .single();
  if (error) throw new Error(error.message);
  return data as AlertRow;
}

/** Patch an existing alert (RLS ensures the user can only touch their own). */
export async function updateAlert(
  id: string,
  patch: Partial<Pick<AlertRow, 'is_active' | 'target_price' | 'direction'>>,
): Promise<AlertRow | null> {
  const { data, error } = await supabase
    .from('price_alerts')
    .update(patch)
    .eq('id', id)
    .select()
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data as AlertRow) ?? null;
}

/** Delete one of the user's alerts. */
export async function deleteAlert(id: string): Promise<void> {
  const { error } = await supabase.from('price_alerts').delete().eq('id', id);
  if (error) throw new Error(error.message);
}

/** Clear the stored push token so the user stops receiving notifications. */
export async function clearPushToken(): Promise<void> {
  const userId = await currentUserId();
  const { error } = await supabase
    .from('profiles')
    .update({ fcm_token: null })
    .eq('id', userId);
  // A missing column shouldn't crash the toggle; surface other errors.
  if (error && !/column .* does not exist/i.test(error.message)) {
    throw new Error(error.message);
  }
}
