import React, { useRef, useCallback, useState, useEffect } from 'react';
import { StyleSheet, View, Text, ScrollView, Pressable, Animated, Linking, Alert } from 'react-native';
import { supabase } from '../../services/supabase';
import { COLORS } from '../../theme';

export default function DashboardScreen({ isConnected }: { isConnected?: boolean }) {
  const [goldBid, setGoldBid] = useState(150000);
  const [goldAsk, setGoldAsk] = useState(150150);
  const [goldHigh, setGoldHigh] = useState(150400);
  const [goldLow, setGoldLow] = useState(149700);

  const [silverBid, setSilverBid] = useState(95000);
  const [silverAsk, setSilverAsk] = useState(95250);
  const [silverHigh, setSilverHigh] = useState(95600);
  const [silverLow, setSilverLow] = useState(94700);

  const [usdInr, setUsdInr] = useState(95.56);
  const lastUpdate = useRef<number>(0);

  // Direction states for ticks
  const [goldBidDir, setGoldBidDir] = useState<'up' | 'down' | 'flat'>('flat');
  const [goldAskDir, setGoldAskDir] = useState<'up' | 'down' | 'flat'>('flat');
  const [silverBidDir, setSilverBidDir] = useState<'up' | 'down' | 'flat'>('flat');
  const [silverAskDir, setSilverAskDir] = useState<'up' | 'down' | 'flat'>('flat');
  const [usdDir, setUsdDir] = useState<'up' | 'down' | 'flat'>('flat');

  // Refs for tracking timeouts and latest values to prevent race conditions & stale closures
  const goldBidTimeout = useRef<NodeJS.Timeout | null>(null);
  const goldAskTimeout = useRef<NodeJS.Timeout | null>(null);
  const silverBidTimeout = useRef<NodeJS.Timeout | null>(null);
  const silverAskTimeout = useRef<NodeJS.Timeout | null>(null);
  const usdTimeout = useRef<NodeJS.Timeout | null>(null);

  const goldBidRef = useRef(150000);
  const goldAskRef = useRef(150150);
  const silverBidRef = useRef(95000);
  const silverAskRef = useRef(95250);
  const usdRef = useRef(95.56);

  // Dynamic badla offsets used for real-time calculations
  const goldBadlaRef = useRef(150);
  const silverBadlaRef = useRef(250);

  // Sync initial state values to refs on mount
  useEffect(() => {
    goldBidRef.current = goldBid;
    goldAskRef.current = goldAsk;
    silverBidRef.current = silverBid;
    silverAskRef.current = silverAsk;
    usdRef.current = usdInr;
  }, []);

  // Helper functions to update rates, track direction, and trigger/reset color ticks safely
  const updateGoldBid = useCallback((newVal: number) => {
    const prevVal = goldBidRef.current;
    if (newVal === prevVal) return;
    goldBidRef.current = newVal;
    setGoldBid(newVal);
    setGoldHigh((h) => Math.max(h, newVal));
    setGoldLow((l) => Math.min(l, newVal));

    if (newVal > prevVal) {
      setGoldBidDir('up');
      if (goldBidTimeout.current) clearTimeout(goldBidTimeout.current);
      goldBidTimeout.current = setTimeout(() => setGoldBidDir('flat'), 1000);
    } else {
      setGoldBidDir('down');
      if (goldBidTimeout.current) clearTimeout(goldBidTimeout.current);
      goldBidTimeout.current = setTimeout(() => setGoldBidDir('flat'), 1000);
    }
  }, []);

  const updateGoldAsk = useCallback((newVal: number) => {
    const prevVal = goldAskRef.current;
    if (newVal === prevVal) return;
    goldAskRef.current = newVal;
    setGoldAsk(newVal);

    if (newVal > prevVal) {
      setGoldAskDir('up');
      if (goldAskTimeout.current) clearTimeout(goldAskTimeout.current);
      goldAskTimeout.current = setTimeout(() => setGoldAskDir('flat'), 1000);
    } else {
      setGoldAskDir('down');
      if (goldAskTimeout.current) clearTimeout(goldAskTimeout.current);
      goldAskTimeout.current = setTimeout(() => setGoldAskDir('flat'), 1000);
    }
  }, []);

  const updateSilverBid = useCallback((newVal: number) => {
    const prevVal = silverBidRef.current;
    if (newVal === prevVal) return;
    silverBidRef.current = newVal;
    setSilverBid(newVal);
    setSilverHigh((h) => Math.max(h, newVal));
    setSilverLow((l) => Math.min(l, newVal));

    if (newVal > prevVal) {
      setSilverBidDir('up');
      if (silverBidTimeout.current) clearTimeout(silverBidTimeout.current);
      silverBidTimeout.current = setTimeout(() => setSilverBidDir('flat'), 1000);
    } else {
      setSilverBidDir('down');
      if (silverBidTimeout.current) clearTimeout(silverBidTimeout.current);
      silverBidTimeout.current = setTimeout(() => setSilverBidDir('flat'), 1000);
    }
  }, []);

  const updateSilverAsk = useCallback((newVal: number) => {
    const prevVal = silverAskRef.current;
    if (newVal === prevVal) return;
    silverAskRef.current = newVal;
    setSilverAsk(newVal);

    if (newVal > prevVal) {
      setSilverAskDir('up');
      if (silverAskTimeout.current) clearTimeout(silverAskTimeout.current);
      silverAskTimeout.current = setTimeout(() => setSilverAskDir('flat'), 1000);
    } else {
      setSilverAskDir('down');
      if (silverAskTimeout.current) clearTimeout(silverAskTimeout.current);
      silverAskTimeout.current = setTimeout(() => setSilverAskDir('flat'), 1000);
    }
  }, []);

  const updateUsdInr = useCallback((newVal: number) => {
    const prevVal = usdRef.current;
    if (newVal === prevVal) return;
    usdRef.current = newVal;
    setUsdInr(newVal);

    if (newVal > prevVal) {
      setUsdDir('up');
      if (usdTimeout.current) clearTimeout(usdTimeout.current);
      usdTimeout.current = setTimeout(() => setUsdDir('flat'), 1000);
    } else {
      setUsdDir('down');
      if (usdTimeout.current) clearTimeout(usdTimeout.current);
      usdTimeout.current = setTimeout(() => setUsdDir('flat'), 1000);
    }
  }, []);

  useEffect(() => {
    // 1. Subscribe to Supabase Realtime channel (must match backend broadcaster channel name)
    const channel = supabase.channel('bullion_rates', {
      config: { broadcast: { ack: false } }
    });

    channel
      .on('broadcast', { event: 'rate-update' }, (message) => {
        const payload = message.payload;
        if (!payload) return;

        lastUpdate.current = Date.now();
        console.log('📡 Realtime Rate Update received:', payload);

        // Update gold rates
        if (payload.gold) {
          updateGoldBid(payload.gold.bid);
          updateGoldAsk(payload.gold.ask);
        }

        // Update silver rates
        if (payload.silver) {
          updateSilverBid(payload.silver.bid);
          updateSilverAsk(payload.silver.ask);
        }

        // Mock USD rate changes (since not provided in payload)
        const nextUsd = 95.56 + (Math.random() - 0.5) * 0.04;
        updateUsdInr(nextUsd);
      })
      .on('broadcast', { event: 'badla-update' }, (message) => {
        const payload = message.payload;
        if (!payload) return;
        console.log('⚡ Received dynamic badla-update broadcast:', payload);
        goldBadlaRef.current = payload.goldBadla;
        silverBadlaRef.current = payload.silverBadla;

        // Apply immediately to current displayed ask prices
        updateGoldAsk(goldBidRef.current + payload.goldBadla);
        updateSilverAsk(silverBidRef.current + payload.silverBadla);
      })
      .subscribe((status) => {
        console.log('🔌 Supabase Realtime subscription status:', status);
      });

    // 2. Client-side fallback simulator (simulates market ticking if server feed is idle)
    const interval = setInterval(() => {
      const timeSinceLastUpdate = Date.now() - lastUpdate.current;
      if (timeSinceLastUpdate > 4000) {
        // Gold simulation
        const goldDelta = Math.round((Math.random() - 0.5) * 16);
        const nextGoldBid = goldBidRef.current + goldDelta;
        console.log('🎲 Simulating fallback Gold Bid:', nextGoldBid);
        updateGoldBid(nextGoldBid);
        updateGoldAsk(nextGoldBid + goldBadlaRef.current);

        // Silver simulation
        const silverDelta = Math.round((Math.random() - 0.5) * 24);
        const nextSilverBid = silverBidRef.current + silverDelta;
        console.log('🎲 Simulating fallback Silver Bid:', nextSilverBid);
        updateSilverBid(nextSilverBid);
        updateSilverAsk(nextSilverBid + silverBadlaRef.current);

        // USD simulation
        const usdDelta = (Math.random() - 0.5) * 0.02;
        updateUsdInr(usdRef.current + usdDelta);
      }
    }, 1500);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(interval);
      if (goldBidTimeout.current) clearTimeout(goldBidTimeout.current);
      if (goldAskTimeout.current) clearTimeout(goldAskTimeout.current);
      if (silverBidTimeout.current) clearTimeout(silverBidTimeout.current);
      if (silverAskTimeout.current) clearTimeout(silverAskTimeout.current);
      if (usdTimeout.current) clearTimeout(usdTimeout.current);
    };
  }, [updateGoldBid, updateGoldAsk, updateSilverBid, updateSilverAsk, updateUsdInr]);

  // Format Helper
  const formatVal = (val: number) => val.toLocaleString('en-IN', { maximumFractionDigits: 0 });

  const goldRateUsd = ((goldBid / usdInr) * 5.932).toFixed(2);
  const silverRateUsd = ((silverBid / usdInr) * 0.0825).toFixed(2);

  const handleBookItem = (title: string, bid: string, ask: string) => {
    Alert.alert(
      'Book Commodity',
      `Would you like to place a call to book ${title}?\n\nBid: ₹${bid} | Ask: ₹${ask}`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Call to Book',
          onPress: () => {
            Linking.openURL('tel:+919827233090').catch(() => {
              Alert.alert('Error', 'Could not open phone dialer.');
            });
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      {/* Domestic & Karat Rates Ticker Bar (Placed right under the header, sticky) */}
      <View style={styles.tickerContainer}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.tickerScroll}
          contentContainerStyle={styles.ratesRowContent}
        >
          <RateBox title="GOLD 22K (916)" value={formatVal(Math.round(goldBid * (22 / 24)))} direction={goldBidDir} />
          <RateBox title="GOLD 20K (833)" value={formatVal(Math.round(goldBid * (20 / 24)))} direction={goldBidDir} />
          <RateBox title="GOLD 18K (750)" value={formatVal(Math.round(goldBid * (18 / 24)))} direction={goldBidDir} />
        </ScrollView>
      </View>

      {/* Scrollable Commodities and other info */}
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* International Rates Row */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={[styles.ratesRowScroll, { marginTop: 0, marginBottom: 20 }]}
          contentContainerStyle={styles.ratesRowContent}
        >
          <RateBox title="GOLD RATE $" value={goldRateUsd} direction={goldBidDir} />
          <RateBox title="SILVER RATE $" value={silverRateUsd} direction={silverBidDir} />
          <RateBox title="USD / INR" value={usdInr.toFixed(2)} direction={usdDir} />
        </ScrollView>

        {/* Divider */}
        <View style={styles.divider} />

        {/* Commodity Rows */}
        <CommodityRow
          title="GOLD FUTURE 995"
          bid={formatVal(goldBid)}
          ask={formatVal(goldAsk)}
          bidHigh={formatVal(goldHigh)}
          askLow={formatVal(goldLow)}
          bidDir={goldBidDir}
          askDir={goldAskDir}
          onPress={() => handleBookItem('GOLD FUTURE 995', formatVal(goldBid), formatVal(goldAsk))}
        />
        <CommodityRow
          title="SILVER FUTURE 999"
          bid={formatVal(silverBid)}
          ask={formatVal(silverAsk)}
          bidHigh={formatVal(silverHigh)}
          askLow={formatVal(silverLow)}
          bidDir={silverBidDir}
          askDir={silverAskDir}
          onPress={() => handleBookItem('SILVER FUTURE 999', formatVal(silverBid), formatVal(silverAsk))}
        />
        <CommodityRow
          title="GOLD PREMIUM (HAWALA)"
          bid={formatVal(goldBid + 350)}
          ask={formatVal(goldAsk + 350)}
          bidHigh={formatVal(goldHigh + 350)}
          askLow={formatVal(goldLow + 350)}
          bidDir={goldBidDir}
          askDir={goldAskDir}
          onPress={() => handleBookItem('GOLD PREMIUM (HAWALA)', formatVal(goldBid + 350), formatVal(goldAsk + 350))}
        />
        <CommodityRow
          title="SILVER FUTURE (HAWALA)"
          bid={formatVal(silverBid + 500)}
          ask={formatVal(silverAsk + 500)}
          bidHigh={formatVal(silverHigh + 500)}
          askLow={formatVal(silverLow + 500)}
          bidDir={silverBidDir}
          askDir={silverAskDir}
          onPress={() => handleBookItem('SILVER FUTURE (HAWALA)', formatVal(silverBid + 500), formatVal(silverAsk + 500))}
        />
        <CommodityRow
          title="GOLD RTGS"
          bid={formatVal(goldBid - 150)}
          ask={formatVal(goldAsk - 150)}
          bidHigh={formatVal(goldHigh - 150)}
          askLow={formatVal(goldLow - 150)}
          badge="24K"
          bidDir={goldBidDir}
          askDir={goldAskDir}
          onPress={() => handleBookItem('GOLD RTGS', formatVal(goldBid - 150), formatVal(goldAsk - 150))}
        />

        {/* Action Buttons */}
        <View style={styles.actionRow}>
          <ActionButton
            title="CALL TO BOOK"
            onPress={() => {
              Linking.openURL('tel:+919827233090').catch(() => {
                Alert.alert('Error', 'Could not open phone dialer.');
              });
            }}
          />
          <ActionButton
            title="WHATSAPP CHAT"
            onPress={() => {
              const url = 'whatsapp://send?phone=919827233090&text=Hello Laxmi Abhushan Support, I would like to inquire about live rates.';
              Linking.openURL(url).catch(() => {
                Linking.openURL('https://wa.me/919827233090?text=Hello%20Laxmi%20Abhushan%20Support%2C%20I%20would%20like%20to%20inquire%20about%20live%20rates.');
              });
            }}
          />
        </View>
      </ScrollView>
    </View>
  );
}

/* ─── Rate Box ─────────────────────────────────────── */

const RateBox = ({
  title,
  value,
  direction = 'flat',
}: {
  title: string;
  value: string;
  direction?: 'up' | 'down' | 'flat';
}) => {
  const bgColor = direction === 'up'
    ? COLORS.bidBlue
    : direction === 'down'
    ? COLORS.askRose
    : COLORS.surfaceLight;

  return (
    <View style={styles.rateBox}>
      <Text style={styles.rateBoxTitle}>{title}</Text>
      <View style={[styles.rateValuePill, { backgroundColor: bgColor }]}>
        <Text style={styles.rateValueText}>{value}</Text>
      </View>
    </View>
  );
};

/* ─── Action Button ────────────────────────────────── */

const ActionButton = ({ title, onPress }: { title: string; onPress?: () => void }) => {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const onIn = useCallback(() => {
    Animated.spring(scaleAnim, {
      toValue: 0.95,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  }, [scaleAnim]);

  const onOut = useCallback(() => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
      speed: 20,
      bounciness: 6,
    }).start();
  }, [scaleAnim]);

  return (
    <Pressable onPress={onPress} onPressIn={onIn} onPressOut={onOut} style={styles.actionPressable}>
      <Animated.View style={[styles.actionBtn, { transform: [{ scale: scaleAnim }] }]}>
        <Text style={styles.actionBtnText}>{title}</Text>
      </Animated.View>
    </Pressable>
  );
};

/* ─── Commodity Row ────────────────────────────────── */

const CommodityRow = ({
  title,
  bid,
  ask,
  bidHigh,
  askLow,
  badge,
  bidDir = 'flat',
  askDir = 'flat',
  onPress,
}: {
  title: string;
  bid: string;
  ask: string;
  bidHigh: string;
  askLow: string;
  badge?: string;
  bidDir?: 'up' | 'down' | 'flat';
  askDir?: 'up' | 'down' | 'flat';
  onPress?: () => void;
}) => {
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const onIn = useCallback(() => {
    Animated.spring(scaleAnim, {
      toValue: 0.98,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  }, [scaleAnim]);

  const onOut = useCallback(() => {
    Animated.spring(scaleAnim, {
      toValue: 1,
      useNativeDriver: true,
      speed: 20,
      bounciness: 6,
    }).start();
  }, [scaleAnim]);

  const bidBg = bidDir === 'up' ? COLORS.bidBlue : bidDir === 'down' ? COLORS.askRose : COLORS.surfaceLight;
  const askBg = askDir === 'up' ? COLORS.bidBlue : askDir === 'down' ? COLORS.askRose : COLORS.surfaceLight;

  return (
    <Pressable onPress={onPress} onPressIn={onIn} onPressOut={onOut}>
      <Animated.View style={[styles.commodityCard, { transform: [{ scale: scaleAnim }] }]}>
        {badge && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>{badge}</Text>
          </View>
        )}

        {/* Left: Title */}
        <View style={styles.commodityTitleWrap}>
          <Text style={styles.commodityTitle} numberOfLines={2}>
            {title}
          </Text>
        </View>

        {/* Right: Prices */}
        <View style={styles.pricesWrap}>
          <View style={styles.priceLabelsRow}>
            <Text style={styles.priceLabel}>BID</Text>
            <Text style={styles.priceLabel}>ASK</Text>
          </View>
          <View style={styles.priceBoxesRow}>
            <View style={[styles.priceBox, { backgroundColor: bidBg }]}>
              <Text style={styles.priceValue}>{bid}</Text>
              <Text style={styles.priceHiLo}>H: {bidHigh}</Text>
            </View>
            <View style={[styles.priceBox, { backgroundColor: askBg }]}>
              <Text style={styles.priceValue}>{ask}</Text>
              <Text style={styles.priceHiLo}>L: {askLow}</Text>
            </View>
          </View>
        </View>
      </Animated.View>
    </Pressable>
  );
};



/* ─── Styles ───────────────────────────────────────── */

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 24,
  },

  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  tickerContainer: {
    backgroundColor: COLORS.background,
    paddingTop: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  tickerScroll: {
    marginHorizontal: 0,
  },

  /* Rate Boxes */
  ratesRowScroll: {
    marginBottom: 20,
    marginHorizontal: -20,
  },
  ratesRowContent: {
    paddingHorizontal: 20,
    gap: 10,
    flexDirection: 'row',
    flexGrow: 1,
    justifyContent: 'space-between',
  },

  rateBox: {
    backgroundColor: COLORS.surface,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 12,
    width: 105,
    alignItems: 'center',
  },
  rateBoxTitle: {
    fontSize: 9,
    fontWeight: '700',
    color: COLORS.accent,
    letterSpacing: 0.5,
    marginBottom: 8,
    textAlign: 'center',
    textTransform: 'uppercase',
  },
  rateValuePill: {
    borderRadius: 6,
    width: '100%',
    alignItems: 'center',
    paddingVertical: 5,
  },
  rateValueText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },

  /* Divider */
  divider: {
    height: 1,
    backgroundColor: COLORS.border,
    marginBottom: 20,
  },

  /* Commodity Card */
  commodityCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 14,
    padding: 16,
    marginBottom: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  commodityTitleWrap: {
    flex: 1,
    paddingRight: 12,
  },
  commodityTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: COLORS.textPrimary,
    letterSpacing: 0.3,
    lineHeight: 19,
  },

  /* Badge */
  badge: {
    position: 'absolute',
    top: -8,
    left: 18,
    backgroundColor: COLORS.accent,
    borderRadius: 6,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  badgeText: {
    fontSize: 9,
    fontWeight: '800',
    color: COLORS.background,
    letterSpacing: 0.8,
  },

  /* Prices */
  pricesWrap: {
    alignItems: 'flex-end',
  },
  priceLabelsRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 5,
    paddingHorizontal: 4,
  },
  priceLabel: {
    fontSize: 9,
    fontWeight: '700',
    color: COLORS.textSecondary,
    letterSpacing: 1,
    width: 72,
    textAlign: 'center',
  },
  priceBoxesRow: {
    flexDirection: 'row',
    gap: 10,
  },
  priceBox: {
    width: 72,
    height: 52,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bidBox: {
    backgroundColor: COLORS.bidBlue,
  },
  askBox: {
    backgroundColor: COLORS.askRose,
  },
  priceValue: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '800',
  },
  priceHiLo: {
    color: 'rgba(255, 255, 255, 0.75)',
    fontSize: 8,
    fontWeight: '600',
    marginTop: 3,
    letterSpacing: 0.3,
  },

  /* Action Buttons */
  actionRow: {
    flexDirection: 'row',
    gap: 14,
    marginTop: 8,
  },
  actionPressable: {
    flex: 1,
  },
  actionBtn: {
    backgroundColor: COLORS.accent,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionBtnText: {
    color: COLORS.background,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1,
  },
});