import React, { useEffect, useRef } from 'react';
import { StyleSheet, Text, View, Animated, Easing } from 'react-native';
import { COLORS } from '../../theme';

export default function LoadingScreen() {
  const glowAnim = useRef(new Animated.Value(0.25)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 0.65,
          duration: 3500,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(glowAnim, {
          toValue: 0.25,
          duration: 3500,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]),
    ).start();
  }, [glowAnim]);

  return (
    <View style={styles.container}>
      {/* Breathing gold halo */}
      <Animated.View
        style={[
          styles.glowHalo,
          {
            opacity: glowAnim,
            transform: [
              {
                scale: glowAnim.interpolate({
                  inputRange: [0.25, 0.65],
                  outputRange: [0.9, 1.2],
                }),
              },
            ],
          },
        ]}
      />

      {/* Brand lockup */}
      <View style={styles.brandContainer}>
        <Text style={styles.glyph}>◆</Text>
        <Text style={styles.brandName}>LAXMI ABHUSHAN</Text>
        <View style={styles.divider} />
        <Text style={styles.tagline}>ESTD 1994</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // ── Glow ───────────────────────────────────────────────────────────
  glowHalo: {
    position: 'absolute',
    width: 260,
    height: 260,
    borderRadius: 130,
    backgroundColor: 'rgba(201, 169, 110, 0.03)',
    shadowColor: COLORS.accent,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.85,
    shadowRadius: 90,
    elevation: 20,
  },

  // ── Brand ──────────────────────────────────────────────────────────
  brandContainer: {
    alignItems: 'center',
    zIndex: 1,
  },
  glyph: {
    fontSize: 36,
    color: COLORS.accent,
    marginBottom: 16,
  },
  brandName: {
    fontSize: 20,
    fontWeight: '700',
    color: COLORS.textPrimary,
    letterSpacing: 5,
    textAlign: 'center',
  },
  divider: {
    width: 32,
    height: 1,
    backgroundColor: COLORS.accent,
    marginVertical: 12,
    borderRadius: 1,
    opacity: 0.5,
  },
  tagline: {
    fontSize: 10,
    fontWeight: '600',
    color: COLORS.textSecondary,
    letterSpacing: 4,
    textAlign: 'center',
  },
});
