import React, { useState, useEffect, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
  ScrollView,
  FlatList,
  Alert,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { supabase } from '../../services/supabase';
import { fetchWithAuth } from '../../services/api';
import { COLORS } from '../../theme';

interface AuditLog {
  id: string;
  admin_email: string;
  setting_key: string;
  old_value: number;
  new_value: number;
  created_at: string;
}

export default function AdminScreen() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // Markups
  const [goldBadla, setGoldBadla] = useState('150');
  const [silverBadla, setSilverBadla] = useState('250');

  // Zerodha Kite API Configs
  const [kiteApiKey, setKiteApiKey] = useState('');
  const [kiteApiSecret, setKiteApiSecret] = useState('');
  const [useMockData, setUseMockData] = useState(true);
  const [kiteGoldToken, setKiteGoldToken] = useState('0');
  const [kiteSilverToken, setKiteSilverToken] = useState('0');
  
  // Previous values (for audit log comparison)
  const originalGold = useRef<number>(150);
  const originalSilver = useRef<number>(250);

  // Live prices (for reference context)
  const [goldBid, setGoldBid] = useState(72400);
  const [silverBid, setSilverBid] = useState(86100);

  // Refs for fallback simulator
  const goldBidRef = useRef(72400);
  const silverBidRef = useRef(86100);
  const lastUpdate = useRef<number>(0);

  // Audit Logs
  const [logs, setLogs] = useState<AuditLog[]>([]);

  // Load configuration, live rates reference, and recent logs
  const loadAdminData = async () => {
    try {
      setLoading(true);
      
      // 1. Fetch current badla markups via API Gateway
      try {
        const configRes = await fetchWithAuth('/config');
        if (configRes.success && configRes.data) {
          const d = configRes.data;
          if (d.gold_badla_markup !== undefined) {
            const val = parseFloat(String(d.gold_badla_markup)).toString();
            setGoldBadla(val);
            originalGold.current = parseFloat(String(d.gold_badla_markup));
          }
          if (d.silver_badla_markup !== undefined) {
            const val = parseFloat(String(d.silver_badla_markup)).toString();
            setSilverBadla(val);
            originalSilver.current = parseFloat(String(d.silver_badla_markup));
          }
          if (d.kite_api_key !== undefined) {
            setKiteApiKey(String(d.kite_api_key));
          }
          if (d.kite_api_secret !== undefined) {
            setKiteApiSecret(String(d.kite_api_secret));
          }
          if (d.use_mock_data !== undefined) {
            setUseMockData(d.use_mock_data === true || d.use_mock_data === 'true');
          }
          if (d.kite_gold_instrument_token !== undefined) {
            setKiteGoldToken(String(d.kite_gold_instrument_token));
          }
          if (d.kite_silver_instrument_token !== undefined) {
            setKiteSilverToken(String(d.kite_silver_instrument_token));
          }
        }
      } catch (configErr: any) {
        console.warn('Failed to fetch config via API. Using default markups.', configErr.message);
      }

      // 2. Fetch recent audit logs via API Gateway
      try {
        const logsRes = await fetchWithAuth('/config/audit-logs');
        if (logsRes.success && logsRes.data) {
          setLogs(logsRes.data);
        }
      } catch (logErr: any) {
        console.warn('Failed to fetch audit logs via API.', logErr.message);
      }
    } catch (err: any) {
      console.error('Error loading admin configurations:', err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();

    // Subscribe to rate ticks for live reference on bullion_rates channel
    const channel = supabase.channel('bullion_rates', {
      config: { broadcast: { ack: false } }
    });

    channel
      .on('broadcast', { event: 'rate-update' }, (message) => {
        const payload = message.payload;
        if (!payload) return;
        
        lastUpdate.current = Date.now();
        if (payload.gold?.bid) {
          setGoldBid(payload.gold.bid);
          goldBidRef.current = payload.gold.bid;
        }
        if (payload.silver?.bid) {
          setSilverBid(payload.silver.bid);
          silverBidRef.current = payload.silver.bid;
        }
      })
      .subscribe();

    // Client-side fallback simulator to keep reference data ticking when worker is idle
    const interval = setInterval(() => {
      const timeSinceLastUpdate = Date.now() - lastUpdate.current;
      if (timeSinceLastUpdate > 4000) {
        const goldDelta = Math.round((Math.random() - 0.5) * 16);
        const nextGoldBid = goldBidRef.current + goldDelta;
        setGoldBid(nextGoldBid);
        goldBidRef.current = nextGoldBid;

        const silverDelta = Math.round((Math.random() - 0.5) * 24);
        const nextSilverBid = silverBidRef.current + silverDelta;
        setSilverBid(nextSilverBid);
        silverBidRef.current = nextSilverBid;
      }
    }, 1500);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(interval);
    };
  }, []);

  const handleSaveConfig = async () => {
    const newGold = parseFloat(goldBadla);
    const newSilver = parseFloat(silverBadla);

    if (isNaN(newGold) || isNaN(newSilver)) {
      Alert.alert('Validation Error', 'Please enter valid numbers for the badla premium values.');
      return;
    }

    try {
      setSaving(true);

      // 1. Save config via API Gateway (backend handles audit log insertion automatically)
      try {
        await fetchWithAuth('/config', {
          method: 'POST',
          body: JSON.stringify({
            gold_badla_markup: newGold,
            silver_badla_markup: newSilver,
          }),
        });
      } catch (apiErr: any) {
        console.warn('API config save failed:', apiErr.message);
      }

      // 2. Broadcast the update in real-time over the 'bullion_rates' channel
      // We must subscribe to the channel and wait for 'SUBSCRIBED' state before broadcasting
      const channel = supabase.channel('bullion_rates');
      channel.subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          const sendStatus = await channel.send({
            type: 'broadcast',
            event: 'badla-update',
            payload: {
              goldBadla: newGold,
              silverBadla: newSilver,
            }
          });
          console.log('⚡ Admin successfully broadcasted badla-update. Status:', sendStatus);
          
          // Wait a short moment then clean up subscription
          setTimeout(() => {
            supabase.removeChannel(channel);
          }, 1000);
        }
      });

      Alert.alert('Success', 'Premium markups updated and broadcasted successfully.');
      loadAdminData(); // Refresh values and audit list
    } catch (err: any) {
      console.error('Save Error:', err.message);
      Alert.alert('Save Failed', err.message || 'An error occurred while writing configuration.');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveZerodha = async () => {
    try {
      setSaving(true);
      await fetchWithAuth('/config', {
        method: 'POST',
        body: JSON.stringify({
          kite_api_key: kiteApiKey,
          kite_api_secret: kiteApiSecret,
          use_mock_data: useMockData,
          kite_gold_instrument_token: parseInt(kiteGoldToken) || 0,
          kite_silver_instrument_token: parseInt(kiteSilverToken) || 0,
        }),
      });
      Alert.alert('Success', 'Zerodha configurations saved and hot-reloaded.');
      loadAdminData();
    } catch (err: any) {
      console.error('Save Zerodha Error:', err.message);
      Alert.alert('Save Failed', err.message || 'An error occurred.');
    } finally {
      setSaving(false);
    }
  };

  // Adjustments helper
  const adjustGold = (amount: number) => {
    setGoldBadla((prev) => {
      const parsed = parseFloat(prev);
      return (isNaN(parsed) ? amount : parsed + amount).toString();
    });
  };

  const adjustSilver = (amount: number) => {
    setSilverBadla((prev) => {
      const parsed = parseFloat(prev);
      return (isNaN(parsed) ? amount : parsed + amount).toString();
    });
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={COLORS.accent} />
        <Text style={styles.loadingText}>Loading Admin Configuration...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled">
        {/* Live Rates Overview */}
        <View style={styles.liveOverview}>
          <Text style={styles.sectionTitle}>LIVE RATES REFERENCE</Text>
          <View style={styles.priceRow}>
            <View style={styles.priceItem}>
              <Text style={styles.metalLabel}>GOLD BID (MCX)</Text>
              <Text style={styles.metalPrice}>₹{goldBid.toLocaleString('en-IN')}</Text>
            </View>
            <View style={styles.priceItem}>
              <Text style={styles.metalLabel}>SILVER BID (MCX)</Text>
              <Text style={styles.metalPrice}>₹{silverBid.toLocaleString('en-IN')}</Text>
            </View>
          </View>
        </View>

        {/* Configurations Form */}
        <View style={styles.formCard}>
          <Text style={styles.sectionTitle}>EDIT BADLA / PREMIUM OFFSETS</Text>
          <Text style={styles.helperText}>
            Values specify the add-on charge applied to the base rate. Positive values increase ask rates, negative values decrease them.
          </Text>

          {/* Gold Input */}
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Gold Badla Offset (₹/gm)</Text>
            <View style={styles.inputWrapper}>
              <Text style={styles.currencySymbol}>₹</Text>
              <TextInput
                style={styles.textInput}
                value={goldBadla}
                onChangeText={setGoldBadla}
                keyboardType="numeric"
                placeholder="0.00"
                placeholderTextColor={COLORS.mutedStone}
              />
            </View>
            <View style={styles.quickActions}>
              <Pressable style={styles.adjustPill} onPress={() => adjustGold(-100)}>
                <Text style={styles.adjustPillText}>-100</Text>
              </Pressable>
              <Pressable style={styles.adjustPill} onPress={() => adjustGold(-50)}>
                <Text style={styles.adjustPillText}>-50</Text>
              </Pressable>
              <Pressable style={styles.adjustPill} onPress={() => adjustGold(50)}>
                <Text style={styles.adjustPillText}>+50</Text>
              </Pressable>
              <Pressable style={styles.adjustPill} onPress={() => adjustGold(100)}>
                <Text style={styles.adjustPillText}>+100</Text>
              </Pressable>
            </View>
          </View>

          {/* Silver Input */}
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Silver Badla Offset (₹/kg)</Text>
            <View style={styles.inputWrapper}>
              <Text style={styles.currencySymbol}>₹</Text>
              <TextInput
                style={styles.textInput}
                value={silverBadla}
                onChangeText={setSilverBadla}
                keyboardType="numeric"
                placeholder="0.00"
                placeholderTextColor={COLORS.mutedStone}
              />
            </View>
            <View style={styles.quickActions}>
              <Pressable style={styles.adjustPill} onPress={() => adjustSilver(-250)}>
                <Text style={styles.adjustPillText}>-250</Text>
              </Pressable>
              <Pressable style={styles.adjustPill} onPress={() => adjustSilver(-100)}>
                <Text style={styles.adjustPillText}>-100</Text>
              </Pressable>
              <Pressable style={styles.adjustPill} onPress={() => adjustSilver(100)}>
                <Text style={styles.adjustPillText}>+100</Text>
              </Pressable>
              <Pressable style={styles.adjustPill} onPress={() => adjustSilver(250)}>
                <Text style={styles.adjustPillText}>+250</Text>
              </Pressable>
            </View>
          </View>

          <Pressable 
            style={[styles.saveBtn, saving && styles.saveBtnDisabled]} 
            onPress={handleSaveConfig}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator color={COLORS.background} size="small" />
            ) : (
              <Text style={styles.saveBtnText}>PUBLISH NEW MARKUPS</Text>
            )}
          </Pressable>
        </View>

        {/* Zerodha Config Form */}
        <View style={styles.formCard}>
          <Text style={styles.sectionTitle}>ZERODHA KITE CONNECT SETTINGS</Text>
          <Text style={styles.helperText}>
            Configure your Zerodha developer API credentials to fetch live MCX gold and silver rates.
          </Text>

          {/* Mode Switcher */}
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Data Provider Mode</Text>
            <View style={styles.modeToggleContainer}>
              <Pressable
                style={[styles.modeToggleBtn, useMockData && styles.modeToggleActive]}
                onPress={() => setUseMockData(true)}
              >
                <Text style={[styles.modeToggleBtnText, useMockData && styles.modeToggleActiveText]}>
                  MOCK SIMULATOR
                </Text>
              </Pressable>
              <Pressable
                style={[styles.modeToggleBtn, !useMockData && styles.modeToggleActiveLive]}
                onPress={() => setUseMockData(false)}
              >
                <Text style={[styles.modeToggleBtnText, !useMockData && styles.modeToggleActiveText]}>
                  LIVE KITE MCX
                </Text>
              </Pressable>
            </View>
          </View>

          {/* API Key */}
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Kite API Key</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.textInput}
                value={kiteApiKey}
                onChangeText={setKiteApiKey}
                placeholder="Enter API Key"
                placeholderTextColor={COLORS.mutedStone}
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
          </View>

          {/* API Secret */}
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Kite API Secret</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.textInput}
                value={kiteApiSecret}
                onChangeText={setKiteApiSecret}
                placeholder={kiteApiSecret === '******' ? 'Saved (******)' : 'Enter API Secret'}
                placeholderTextColor={COLORS.mutedStone}
                secureTextEntry={true}
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
          </View>

          {/* Gold Token */}
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Gold Instrument Token</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.textInput}
                value={kiteGoldToken}
                onChangeText={setKiteGoldToken}
                placeholder="e.g. 223532"
                placeholderTextColor={COLORS.mutedStone}
                keyboardType="numeric"
              />
            </View>
          </View>

          {/* Silver Token */}
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Silver Instrument Token</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.textInput}
                value={kiteSilverToken}
                onChangeText={setKiteSilverToken}
                placeholder="e.g. 224345"
                placeholderTextColor={COLORS.mutedStone}
                keyboardType="numeric"
              />
            </View>
          </View>

          <Pressable 
            style={[styles.saveBtn, saving && styles.saveBtnDisabled]} 
            onPress={handleSaveZerodha}
            disabled={saving}
          >
            {saving ? (
              <ActivityIndicator color={COLORS.background} size="small" />
            ) : (
              <Text style={styles.saveBtnText}>SAVE ZERODHA CONFIGURATION</Text>
            )}
          </Pressable>
        </View>

        {/* Recent Audit Logs */}
        <View style={styles.auditContainer}>
          <Text style={styles.sectionTitle}>RECENT AUDIT HISTORY</Text>
          {logs.length === 0 ? (
            <Text style={styles.emptyLogsText}>No recent configuration changes logged.</Text>
          ) : (
            logs.map((item) => (
              <View key={item.id} style={styles.auditCard}>
                <View style={styles.auditHeader}>
                  <Text style={styles.auditAdmin} numberOfLines={1}>{item.admin_email}</Text>
                  <Text style={styles.auditTime}>
                    {new Date(item.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </View>
                <Text style={styles.auditContent}>
                  Changed <Text style={styles.boldText}>{item.setting_key === 'gold_badla_markup' ? 'Gold Badla' : 'Silver Badla'}</Text> from{' '}
                  <Text style={styles.boldText}>₹{item.old_value}</Text> to{' '}
                  <Text style={styles.boldText}>₹{item.new_value}</Text>
                </Text>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: COLORS.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: COLORS.textSecondary,
    marginTop: 14,
    fontSize: 13,
    letterSpacing: 0.5,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 40,
  },
  liveOverview: {
    backgroundColor: COLORS.surface,
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.accent,
    letterSpacing: 2,
    marginBottom: 14,
    textTransform: 'uppercase',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  priceItem: {
    flex: 1,
  },
  metalLabel: {
    fontSize: 9,
    fontWeight: '600',
    color: COLORS.textSecondary,
    marginBottom: 4,
    letterSpacing: 0.5,
  },
  metalPrice: {
    fontSize: 18,
    fontWeight: '800',
    color: COLORS.textPrimary,
  },
  formCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginBottom: 24,
  },
  helperText: {
    fontSize: 11,
    color: COLORS.textSecondary,
    lineHeight: 16,
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 22,
  },
  inputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textPrimary,
    marginBottom: 8,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surfaceLight,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 12,
  },
  currencySymbol: {
    color: COLORS.accent,
    fontSize: 16,
    fontWeight: '600',
    marginRight: 6,
  },
  textInput: {
    flex: 1,
    color: COLORS.textPrimary,
    fontSize: 16,
    fontWeight: '700',
    paddingVertical: Platform.OS === 'ios' ? 12 : 8,
  },
  quickActions: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 8,
  },
  adjustPill: {
    backgroundColor: COLORS.surfaceLight,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 6,
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
  adjustPillText: {
    color: COLORS.accent,
    fontSize: 10,
    fontWeight: '700',
  },
  saveBtn: {
    backgroundColor: COLORS.accent,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 10,
  },
  saveBtnDisabled: {
    opacity: 0.6,
  },
  saveBtnText: {
    color: COLORS.background,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1,
  },
  auditContainer: {
    marginTop: 8,
  },
  emptyLogsText: {
    color: COLORS.textSecondary,
    fontSize: 12,
    fontStyle: 'italic',
    marginTop: 4,
  },
  auditCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 10,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  auditHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  auditAdmin: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.textSecondary,
    flex: 1,
    marginRight: 10,
  },
  auditTime: {
    fontSize: 10,
    color: COLORS.textSecondary,
  },
  auditContent: {
    fontSize: 12,
    color: COLORS.textPrimary,
    lineHeight: 18,
  },
  boldText: {
    fontWeight: '700',
    color: COLORS.accent,
  },
  modeToggleContainer: {
    flexDirection: 'row',
    backgroundColor: COLORS.surfaceLight,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: COLORS.border,
    padding: 4,
    gap: 4,
  },
  modeToggleBtn: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: 8,
  },
  modeToggleActive: {
    backgroundColor: COLORS.border,
  },
  modeToggleActiveLive: {
    backgroundColor: COLORS.accent,
  },
  modeToggleBtnText: {
    color: COLORS.textSecondary,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  modeToggleActiveText: {
    color: COLORS.background,
  },
});
