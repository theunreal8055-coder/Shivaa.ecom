import React, { useState, useRef, useCallback } from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Pressable,
  Animated,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { supabase } from '../../services/supabase';
import { COLORS } from '../../theme';

export default function LoginScreen() {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [company, setCompany] = useState('');

  const [loading, setLoading] = useState(false);

  // Focus states
  const [emailFocused, setEmailFocused] = useState(false);
  const [passwordFocused, setPasswordFocused] = useState(false);
  const [nameFocused, setNameFocused] = useState(false);
  const [phoneFocused, setPhoneFocused] = useState(false);
  const [companyFocused, setCompanyFocused] = useState(false);

  const btnScale = useRef(new Animated.Value(1)).current;

  const handlePressIn = useCallback(() => {
    Animated.spring(btnScale, {
      toValue: 0.96,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  }, [btnScale]);

  const handlePressOut = useCallback(() => {
    Animated.spring(btnScale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 20,
      bounciness: 6,
    }).start();
  }, [btnScale]);

  async function handleSubmit() {
    if (isSignUp) {
      if (!email || !password || !name || !phone || !company) {
        Alert.alert('Missing Fields', 'Please fill in all registration fields.');
        return;
      }
      setLoading(true);
      try {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            data: {
              full_name: name,
              phone: phone,
              business_name: company, // Pass business_name in metadata so it is stored in auth.users
            },
          },
        });

        if (error) {
          Alert.alert('Sign Up Failed', error.message);
          setLoading(false);
          return;
        }

        if (data?.user) {
          // Update profiles table with safe columns (full_name and phone_number)
          try {
            const { error: profileError } = await supabase
              .from('profiles')
              .update({ 
                full_name: name,
                phone_number: phone 
              })
              .eq('id', data.user.id);

            if (profileError) {
              console.warn('Profiles table sync warning on signup:', profileError.message);
            }
          } catch (e: any) {
            console.warn('Profiles table sync failed on signup:', e.message);
          }

          setLoading(false);
          Alert.alert(
            'Verification Sent',
            'Registration successful! Please check your email inbox to verify your account.',
            [{ text: 'OK', onPress: () => setIsSignUp(false) }]
          );
        }
      } catch (err) {
        console.error(err);
        Alert.alert('Error', 'An unexpected error occurred during registration.');
        setLoading(false);
      }
    } else {
      if (!email || !password) {
        Alert.alert('Missing Fields', 'Please fill in both email and password.');
        return;
      }
      setLoading(true);
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) {
        Alert.alert('Sign In Failed', error.message);
      }
    }
  }

  return (
    <View style={styles.screen}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.centered}
      >
        {/* Brand Header outside the card/box */}
        <View style={styles.brandContainer}>
          <Text style={styles.brandName}>LAXMI ABHUSHAN</Text>
          <Text style={styles.brandTag}>BULLION TRADING</Text>
        </View>

        <View style={styles.card}>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
            {/* Header */}
            <View style={styles.headerBlock}>
              <Text style={styles.title}>{isSignUp ? 'Create Account' : 'Welcome Back'}</Text>
              <Text style={styles.subtitle}>
                {isSignUp ? 'Sign up to start trading' : 'Sign in to continue trading'}
              </Text>
            </View>

            {/* Registration Fields (Only visible on Sign Up) */}
            {isSignUp && (
              <>
                {/* Full Name */}
                <View style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>Trader Name</Text>
                  <View style={[styles.inputContainer, nameFocused && styles.inputContainerFocused]}>
                    <TextInput
                      style={styles.input}
                      placeholder="Enter full name"
                      placeholderTextColor={COLORS.textSecondary}
                      value={name}
                      onChangeText={setName}
                      onFocus={() => setNameFocused(true)}
                      onBlur={() => setNameFocused(false)}
                      autoCorrect={false}
                    />
                  </View>
                </View>

                {/* Organization */}
                <View style={[styles.fieldGroup, { marginTop: 16 }]}>
                  <Text style={styles.fieldLabel}>Organization</Text>
                  <View style={[styles.inputContainer, companyFocused && styles.inputContainerFocused]}>
                    <TextInput
                      style={styles.input}
                      placeholder="Company / Jeweller Name"
                      placeholderTextColor={COLORS.textSecondary}
                      value={company}
                      onChangeText={setCompany}
                      onFocus={() => setCompanyFocused(true)}
                      onBlur={() => setCompanyFocused(false)}
                      autoCorrect={false}
                    />
                  </View>
                </View>

                {/* Contact (Phone) */}
                <View style={[styles.fieldGroup, { marginTop: 16 }]}>
                  <Text style={styles.fieldLabel}>Mobile Number</Text>
                  <View style={[styles.inputContainer, phoneFocused && styles.inputContainerFocused]}>
                    <TextInput
                      style={styles.input}
                      placeholder="+91 99999 99999"
                      placeholderTextColor={COLORS.textSecondary}
                      value={phone}
                      onChangeText={setPhone}
                      onFocus={() => setPhoneFocused(true)}
                      onBlur={() => setPhoneFocused(false)}
                      keyboardType="phone-pad"
                      autoCorrect={false}
                    />
                  </View>
                </View>
              </>
            )}

            {/* Email Input */}
            <View style={[styles.fieldGroup, isSignUp && { marginTop: 16 }]}>
              <Text style={styles.fieldLabel}>Email</Text>
              <View style={[styles.inputContainer, emailFocused && styles.inputContainerFocused]}>
                <TextInput
                  style={styles.input}
                  placeholder="you@example.com"
                  placeholderTextColor={COLORS.textSecondary}
                  value={email}
                  onChangeText={setEmail}
                  onFocus={() => setEmailFocused(true)}
                  onBlur={() => setEmailFocused(false)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>
            </View>

            {/* Password Input */}
            <View style={[styles.fieldGroup, { marginTop: 16 }]}>
              <Text style={styles.fieldLabel}>Password</Text>
              <View style={[styles.inputContainer, passwordFocused && styles.inputContainerFocused]}>
                <TextInput
                  style={styles.input}
                  placeholder="Enter password"
                  placeholderTextColor={COLORS.textSecondary}
                  value={password}
                  onChangeText={setPassword}
                  onFocus={() => setPasswordFocused(true)}
                  onBlur={() => setPasswordFocused(false)}
                  secureTextEntry
                  autoCapitalize="none"
                />
              </View>
            </View>

            {/* Forgot Password (Only on Sign In) */}
            {!isSignUp && (
              <Pressable
                onPress={() => Alert.alert('Forgot Password', 'Feature coming soon!')}
                hitSlop={8}
                style={styles.forgotWrapper}
              >
                <Text style={styles.forgotText}>Forgot password?</Text>
              </Pressable>
            )}

            {/* Submit Button */}
            <Pressable
              onPressIn={handlePressIn}
              onPressOut={handlePressOut}
              onPress={handleSubmit}
              disabled={loading}
              style={isSignUp && { marginTop: 24 }}
            >
              <Animated.View
                style={[
                  styles.submitButton,
                  { transform: [{ scale: btnScale }] },
                  loading && { opacity: 0.7 },
                ]}
              >
                {loading ? (
                  <ActivityIndicator color={COLORS.background} size="small" />
                ) : (
                  <Text style={styles.submitText}>{isSignUp ? 'Sign Up' : 'Sign In'}</Text>
                )}
              </Animated.View>
            </Pressable>

            {/* Toggle Sign In / Sign Up Option */}
            <Pressable
              style={styles.toggleOptionWrapper}
              onPress={() => {
                setIsSignUp(!isSignUp);
                // Clear state values when switching modes
                setEmail('');
                setPassword('');
                setName('');
                setPhone('');
                setCompany('');
              }}
            >
              <Text style={styles.toggleOptionText}>
                {isSignUp ? 'Already have an account? ' : "Don't have an account? "}
                <Text style={styles.toggleOptionTextHighlight}>
                  {isSignUp ? 'Sign In' : 'Sign Up'}
                </Text>
              </Text>
            </Pressable>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  card: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: COLORS.surface,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 10,
    maxHeight: '90%', // Ensures card handles small devices without overflowing screen bounds
  },
  scrollContent: {
    padding: 24,
  },
  headerBlock: {
    marginBottom: 24,
  },
  brandContainer: {
    alignItems: 'center',
    marginBottom: 28,
  },
  brandName: {
    color: COLORS.textPrimary,
    fontSize: 22,
    fontWeight: '700',
    letterSpacing: 2.8,
    textAlign: 'center',
  },
  brandTag: {
    color: COLORS.accent,
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 2.2,
    marginTop: 4,
    textAlign: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.textPrimary,
    letterSpacing: 0.2,
    marginBottom: 6,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textSecondary,
    fontWeight: '400',
  },
  fieldGroup: {},
  fieldLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: COLORS.textSecondary,
    letterSpacing: 0.8,
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  inputContainer: {
    backgroundColor: COLORS.surfaceLight,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 16,
    height: 48,
    justifyContent: 'center',
  },
  inputContainerFocused: {
    borderColor: COLORS.accent,
  },
  input: {
    color: COLORS.textPrimary,
    fontSize: 14,
    fontWeight: '500',
    padding: 0,
  },
  forgotWrapper: {
    alignSelf: 'flex-end',
    marginTop: 12,
    marginBottom: 4,
  },
  forgotText: {
    color: COLORS.accent,
    fontSize: 12,
    fontWeight: '500',
  },
  submitButton: {
    marginTop: 18,
    backgroundColor: COLORS.accent,
    borderRadius: 12,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.accent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  submitText: {
    color: COLORS.background,
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  toggleOptionWrapper: {
    marginTop: 20,
    alignItems: 'center',
    paddingVertical: 4,
  },
  toggleOptionText: {
    color: COLORS.textSecondary,
    fontSize: 13,
    fontWeight: '400',
  },
  toggleOptionTextHighlight: {
    color: COLORS.accent,
    fontWeight: '700',
  },
});