import React, { useState, useRef, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Pressable,
  TextInput,
  Switch,
  ScrollView,
  Linking,
  Alert,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { supabase } from '../../services/supabase';
import { clearPushToken } from '../../services/data';
import { initializePushNotifications } from '../../services/notifications';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import { COLORS } from '../../theme';

interface ProfileScreenProps {
  userEmail?: string;
}

function AccentButton({
  onPress,
  label,
  icon,
  style,
}: {
  onPress: () => void;
  label: string;
  icon?: React.ReactNode;
  style?: any;
}) {
  const scale = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Animated.spring(scale, {
      toValue: 0.96,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 30,
      bounciness: 6,
    }).start();
  };

  return (
    <Pressable onPress={onPress} onPressIn={handlePressIn} onPressOut={handlePressOut}>
      <Animated.View style={[styles.accentBtn, style, { transform: [{ scale }] }]}>
        <View style={styles.btnContent}>
          {icon}
          <Text style={styles.accentBtnText}>{label}</Text>
        </View>
      </Animated.View>
    </Pressable>
  );
}

export default function ProfileScreen({ userEmail }: ProfileScreenProps) {
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [company, setCompany] = useState('');

  const [isEmailVerified, setIsEmailVerified] = useState(false);
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);

  // Track original values to reset on cancel
  const [originalData, setOriginalData] = useState({ name: '', phone: '', company: '', email: '' });

  const [notifySync, setNotifySync] = useState(true);
  const [highContrast, setHighContrast] = useState(false);

  // OTP Verification state
  const [otpToken, setOtpToken] = useState('');
  const [isOtpSent, setIsOtpSent] = useState(false);
  const [verificationType, setVerificationType] = useState<'email' | 'phone'>('phone');

  const fetchProfile = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const emailVal = user.email || userEmail || '';
      const isEmailConf = !!user.email_confirmed_at;
      const isPhoneConf = !!user.phone_confirmed_at;

      setEmail(emailVal);
      setIsEmailVerified(isEmailConf);
      setIsPhoneVerified(isPhoneConf);

      // Fallback values from user metadata so fields are never empty
      const fallbackName = user.user_metadata?.full_name || '';
      const fallbackPhone = user.user_metadata?.phone || user.user_metadata?.phone_number || '';
      const fallbackCompany = user.user_metadata?.business_name || '';

      setName(fallbackName);
      setPhone(fallbackPhone);
      setCompany(fallbackCompany);
      setOriginalData({
        name: fallbackName,
        phone: fallbackPhone,
        company: fallbackCompany,
        email: emailVal,
      });

      // Query profiles table safely using select('*') to handle dynamic columns
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (error) {
        console.warn('Error fetching profile table (likely schema mismatch):', error.message);
      } else if (data) {
        const profileName = data.full_name || fallbackName;
        const profilePhone = data.phone_number || data.phone || fallbackPhone;
        const profileCompany = data.business_name || fallbackCompany;

        setName(profileName);
        setPhone(profilePhone);
        setCompany(profileCompany);
        setOriginalData({
          name: profileName,
          phone: profilePhone,
          company: profileCompany,
          email: emailVal,
        });
      } else {
        // Auto-create row in profiles table if it doesn't exist yet
        const { error: insErr } = await supabase
          .from('profiles')
          .insert({ id: user.id, full_name: fallbackName || 'New Trader' });
        if (insErr) console.warn('Failed to auto-create profile row:', insErr.message);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const handleSave = async () => {
    try {
      setLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // 1. Update Auth user metadata first (reliable source of truth)
      const { error: metaError } = await supabase.auth.updateUser({
        data: {
          full_name: name,
          phone: phone,
          business_name: company,
        }
      });

      if (metaError) {
        Alert.alert('Metadata Update Failed', metaError.message);
        return;
      }

      // 2. Update profiles table using only safe, existing schema columns
      try {
        const { error: profileError } = await supabase
          .from('profiles')
          .update({
            full_name: name,
            phone_number: phone,
          })
          .eq('id', user.id);

        if (profileError) {
          console.warn('Profiles table update warning (likely phone_number column mismatch):', profileError.message);
          
          // Retry with only full_name if phone_number doesn't exist
          await supabase
            .from('profiles')
            .update({ full_name: name })
            .eq('id', user.id);
        }
      } catch (e: any) {
        console.warn('Profiles table update error (likely schema mismatch):', e.message);
      }

      const verificationUpdates = [];

      // 3. If email changed, trigger email change verification
      if (email.trim().toLowerCase() !== originalData.email.trim().toLowerCase()) {
        const { error: emailError } = await supabase.auth.updateUser({ email });
        if (emailError) {
          Alert.alert('Email Update Error', emailError.message);
        } else {
          verificationUpdates.push(`Verification code sent to your new email: ${email}`);
          setIsEmailVerified(false);
          setIsOtpSent(true);
          setVerificationType('email');
        }
      }

      // 4. If phone changed, trigger phone change verification
      if (phone.trim() !== originalData.phone.trim()) {
        const { error: phoneError } = await supabase.auth.updateUser({ phone });
        if (phoneError) {
          console.warn('Phone update warning:', phoneError.message);
          verificationUpdates.push(`Mobile verification initialized for: ${phone}. Enter OTP below.`);
          setIsOtpSent(true);
          setVerificationType('phone');
        } else {
          verificationUpdates.push(`Verification SMS OTP sent to your mobile: ${phone}`);
          setIsPhoneVerified(false);
          setIsOtpSent(true);
          setVerificationType('phone');
        }
      }

      setOriginalData({ name, phone, company, email });
      setIsEditing(false);

      if (verificationUpdates.length > 0) {
        Alert.alert(
          'Verification Triggered',
          'Profile metadata saved.\n\n' + verificationUpdates.join('\n\n')
        );
      } else {
        Alert.alert('Success', 'Profile updated successfully.');
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'An unexpected error occurred.');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setName(originalData.name);
    setPhone(originalData.phone);
    setCompany(originalData.company);
    setEmail(originalData.email);
    setIsEditing(false);
    setIsOtpSent(false);
    setOtpToken('');
  };

  const handleVerifyEmail = async () => {
    try {
      const { error } = await supabase.auth.updateUser({ email });
      if (error) {
        Alert.alert('Verification Error', error.message);
      } else {
        setIsOtpSent(true);
        setVerificationType('email');
        Alert.alert('Verification Sent', `An email OTP has been sent to ${email}. Please enter the code below.`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleVerifyPhone = async () => {
    try {
      const { error } = await supabase.auth.updateUser({ phone });
      if (error) {
        Alert.alert('Verification Error', error.message);
      } else {
        setIsOtpSent(true);
        setVerificationType('phone');
        Alert.alert('SMS Sent', `A verification code has been sent to: ${phone}. Please enter the OTP below.`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleConfirmOtp = async () => {
    if (!otpToken) {
      Alert.alert('Input Required', 'Please enter the 6-digit verification code.');
      return;
    }

    try {
      setLoading(true);
      const verifyParams: any = {
        token: otpToken,
        type: verificationType === 'phone' ? 'phone_change' : 'email_change',
      };
      if (verificationType === 'phone') {
        verifyParams.phone = phone;
      } else {
        verifyParams.email = email;
      }

      const { data, error } = await supabase.auth.verifyOtp(verifyParams);

      if (error) {
        Alert.alert('Verification Failed', error.message);
      } else {
        Alert.alert('Success', `${verificationType === 'phone' ? 'Mobile' : 'Email'} verified successfully!`);
        setIsOtpSent(false);
        setOtpToken('');
        if (verificationType === 'phone') setIsPhoneVerified(true);
        if (verificationType === 'email') setIsEmailVerified(true);
        fetchProfile();
      }
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'An unexpected error occurred during OTP verification.');
    } finally {
      setLoading(false);
    }
  };

  const openWhatsApp = () => {
    const url = 'whatsapp://send?phone=919827233090&text=Hello Laxmi Abhushan Support, I would like to inquire about live rates.';
    Linking.canOpenURL(url).then((supported) => {
      if (supported) {
        Linking.openURL(url);
      } else {
        Alert.alert('Support Contact', 'WhatsApp is not installed. Reach us at support@laxmiabhushan.com');
      }
    });
  };

  const openMap = () => {
    const url = 'https://www.google.com/maps/search/?api=1&query=Laxmi+Abhushan+Jewellers+Mumbai';
    Linking.openURL(url);
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={COLORS.luxuryAccent} />
        <Text style={styles.loadingText}>Syncing Profile details...</Text>
      </View>
    );
  }

  return (
    <ScrollView
      style={styles.scrollView}
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
    >
      {/* ── Identification ── */}
      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionHeading}>IDENTIFICATION</Text>
        {!isEditing && (
          <Pressable style={styles.editToggleBtn} onPress={() => setIsEditing(true)}>
            <Ionicons name="create-outline" size={14} color={COLORS.luxuryAccent} style={styles.editIcon} />
            <Text style={styles.editToggleText}>EDIT PROFILE</Text>
          </Pressable>
        )}
      </View>

      <View style={styles.fieldCard}>
        <FieldRow label="TRADER NAME" value={name} onChangeText={setName} editable={isEditing} />
        <View style={styles.fieldDivider} />

        <FieldRow
          label="CONTACT (MOBILE)"
          value={phone}
          onChangeText={setPhone}
          keyboardType="phone-pad"
          editable={isEditing}
          showVerifyBadge={!isEditing && !!phone}
          verified={isPhoneVerified}
          onVerifyPress={handleVerifyPhone}
        />
        <View style={styles.fieldDivider} />

        <FieldRow
          label="EMAIL ADDRESS"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          editable={isEditing}
          showVerifyBadge={!isEditing && !!email}
          verified={isEmailVerified}
          onVerifyPress={handleVerifyEmail}
        />
        <View style={styles.fieldDivider} />

        <FieldRow label="ORGANIZATION" value={company} onChangeText={setCompany} editable={isEditing} />

        {isOtpSent && (
          <>
            <View style={styles.fieldDivider} />
            <View style={styles.fieldRowContainer}>
              <View style={styles.fieldRowTextWrap}>
                <Text style={styles.fieldLabel}>ENTER {verificationType.toUpperCase()} OTP</Text>
                <TextInput
                  style={styles.fieldInput}
                  value={otpToken}
                  onChangeText={setOtpToken}
                  placeholder="Enter 6-digit code"
                  placeholderTextColor={COLORS.mutedStone}
                  keyboardType="numeric"
                />
              </View>
              <Pressable style={styles.verifyBtn} onPress={handleConfirmOtp}>
                <Text style={styles.verifyBtnText}>VERIFY</Text>
              </Pressable>
            </View>
          </>
        )}

        {/* Editing Footer Actions */}
        {isEditing && (
          <View style={styles.editActionsContainer}>
            <Pressable style={[styles.editActionBtn, styles.cancelBtn]} onPress={handleCancel}>
              <Text style={styles.cancelBtnText}>CANCEL</Text>
            </Pressable>
            <Pressable style={[styles.editActionBtn, styles.saveBtn]} onPress={handleSave}>
              <Text style={styles.saveBtnText}>SAVE CHANGES</Text>
            </Pressable>
          </View>
        )}
      </View>

      {/* ── Preferences ── */}
      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionHeading}>PREFERENCES</Text>
      </View>

      <View style={styles.preferencesCard}>
        <View style={styles.preferenceRow}>
          <View style={styles.prefLabelWrap}>
            <Text style={styles.preferenceLabel}>Rate Push Notifications</Text>
            <Text style={styles.preferenceCaption}>Realtime price movement alerts</Text>
          </View>
           <Switch
            value={notifySync}
            onValueChange={async (value) => {
              setNotifySync(value);
              try {
                if (value) {
                  // Re-register for push notifications and sync token
                  const token = await initializePushNotifications();
                  if (token) {
                    Alert.alert('Notifications Enabled', 'You will now receive real-time price alerts.');
                  }
                } else {
                  // Clear the stored push token so the user stops receiving notifications
                  await clearPushToken();
                  Alert.alert('Notifications Disabled', 'Push notifications have been turned off.');
                }
              } catch (err: any) {
                console.warn('Failed to toggle notification preference:', err.message);
              }
            }}
            trackColor={{ false: COLORS.mutedStone, true: COLORS.luxuryAccent }}
            thumbColor={notifySync ? COLORS.deepCanvas : COLORS.lightCore}
            ios_backgroundColor={COLORS.mutedStone}
          />
        </View>
        <View style={styles.prefDivider} />
        <View style={styles.preferenceRow}>
          <View style={styles.prefLabelWrap}>
            <Text style={styles.preferenceLabel}>High Contrast Ticks</Text>
            <Text style={styles.preferenceCaption}>Enhanced visibility for price changes</Text>
          </View>
          <Switch
            value={highContrast}
            onValueChange={setHighContrast}
            trackColor={{ false: COLORS.mutedStone, true: COLORS.luxuryAccent }}
            thumbColor={highContrast ? COLORS.deepCanvas : COLORS.lightCore}
            ios_backgroundColor={COLORS.mutedStone}
          />
        </View>
      </View>

      {/* ── Support Actions ── */}
      <View style={styles.sectionHeaderRow}>
        <Text style={styles.sectionHeading}>SUPPORT</Text>
      </View>

      <View style={styles.actionRow}>
        <AccentButton
          onPress={openWhatsApp}
          label="WHATSAPP"
          icon={<FontAwesome name="whatsapp" size={16} color={COLORS.deepCanvas} style={styles.btnIcon} />}
          style={styles.actionBtnHalf}
        />
        <AccentButton
          onPress={openMap}
          label="VISIT US"
          icon={<Ionicons name="location-sharp" size={15} color={COLORS.deepCanvas} style={styles.btnIcon} />}
          style={styles.actionBtnHalf}
        />
      </View>

      {/* ── Sign Out ── */}
      <Pressable
        style={({ pressed }) => [
          styles.signOutBtn,
          pressed && styles.signOutBtnPressed,
        ]}
        onPress={() => supabase.auth.signOut()}
      >
        <Text style={styles.signOutText}>SIGN OUT</Text>
      </Pressable>
    </ScrollView>
  );
}

/* ── Reusable Field Row with Verification Action support ── */
function FieldRow({
  label,
  value,
  onChangeText,
  editable = true,
  keyboardType = 'default',
  showVerifyBadge = false,
  verified = false,
  onVerifyPress,
}: {
  label: string;
  value: string;
  onChangeText?: (text: string) => void;
  editable?: boolean;
  keyboardType?: 'default' | 'phone-pad' | 'email-address' | 'numeric';
  showVerifyBadge?: boolean;
  verified?: boolean;
  onVerifyPress?: () => void;
}) {
  return (
    <View style={styles.fieldRowContainer}>
      <View style={styles.fieldRowTextWrap}>
        <Text style={styles.fieldLabel}>{label}</Text>
        <TextInput
          style={[styles.fieldInput, !editable && styles.fieldInputDisabled]}
          value={value}
          onChangeText={onChangeText}
          editable={editable}
          placeholderTextColor={COLORS.mutedStone}
          keyboardType={keyboardType}
        />
      </View>

      {showVerifyBadge && (
        <View style={styles.badgeCol}>
          {verified ? (
            <View style={styles.verifiedContainer}>
              <Ionicons name="checkmark-circle" size={13} color={COLORS.success} />
              <Text style={styles.verifiedText}>Verified</Text>
            </View>
          ) : (
            <Pressable style={styles.verifyBtn} onPress={onVerifyPress}>
              <Text style={styles.verifyBtnText}>Verify</Text>
            </Pressable>
          )}
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: COLORS.deepCanvas,
  },
  container: {
    paddingHorizontal: 18,
    paddingTop: 8,
    paddingBottom: 50,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.deepCanvas,
    gap: 14,
  },
  loadingText: {
    color: COLORS.mutedStone,
    fontSize: 13,
    fontWeight: '600',
  },

  /* ── Section Headings ── */
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'baseline',
    marginTop: 24,
    marginBottom: 12,
  },
  sectionHeading: {
    color: COLORS.mutedStone,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2.5,
    textTransform: 'uppercase',
    paddingLeft: 2,
  },
  editToggleBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 4,
    paddingHorizontal: 8,
  },
  editIcon: {
    marginRight: 4,
  },
  editToggleText: {
    color: COLORS.luxuryAccent,
    fontSize: 9.5,
    fontWeight: '800',
    letterSpacing: 1,
  },

  /* ── Field Card ── */
  fieldCard: {
    backgroundColor: COLORS.darkWell,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(188, 184, 177, 0.08)',
    overflow: 'hidden',
  },
  fieldRowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 18,
    paddingVertical: 14,
  },
  fieldRowTextWrap: {
    flex: 1,
  },
  fieldDivider: {
    height: 1,
    backgroundColor: 'rgba(188, 184, 177, 0.06)',
    marginHorizontal: 18,
  },
  fieldLabel: {
    color: COLORS.mutedStone,
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.5,
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  fieldInput: {
    color: COLORS.lightCore,
    fontSize: 15,
    fontWeight: '600',
    padding: 0,
    width: '100%',
    marginTop: 2,
  },
  fieldInputDisabled: {
    opacity: 0.7,
  },

  /* Verification badge / buttons */
  badgeCol: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingLeft: 12,
  },
  verifiedContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(91, 202, 122, 0.08)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  verifiedText: {
    color: COLORS.success,
    fontSize: 10,
    fontWeight: '700',
  },
  verifyBtn: {
    backgroundColor: 'rgba(201, 169, 110, 0.12)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 6,
  },
  verifyBtnText: {
    color: COLORS.luxuryAccent,
    fontSize: 10,
    fontWeight: '700',
  },

  /* Editing actions footer */
  editActionsContainer: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: 'rgba(188, 184, 177, 0.08)',
  },
  editActionBtn: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelBtn: {
    borderRightWidth: 1,
    borderRightColor: 'rgba(188, 184, 177, 0.08)',
    backgroundColor: 'rgba(239, 91, 91, 0.04)',
  },
  saveBtn: {
    backgroundColor: 'rgba(91, 202, 122, 0.04)',
  },
  cancelBtnText: {
    color: COLORS.askRose,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  saveBtnText: {
    color: COLORS.success,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1.5,
  },

  /* ── Preferences Card ── */
  preferencesCard: {
    backgroundColor: COLORS.darkWell,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(188, 184, 177, 0.08)',
    overflow: 'hidden',
  },
  preferenceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 16,
  },
  prefLabelWrap: {
    flex: 1,
    marginRight: 16,
  },
  preferenceLabel: {
    color: COLORS.lightCore,
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  preferenceCaption: {
    color: COLORS.mutedStone,
    fontSize: 11,
    fontWeight: '400',
  },
  prefDivider: {
    height: 1,
    backgroundColor: 'rgba(188, 184, 177, 0.06)',
    marginHorizontal: 18,
  },

  /* ── Action Buttons ── */
  actionRow: {
    flexDirection: 'row',
    gap: 12,
  },
  accentBtn: {
    backgroundColor: COLORS.luxuryAccent,
    borderRadius: 26,
    paddingVertical: 13,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: COLORS.luxuryAccent,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 3,
  },
  accentBtnText: {
    color: COLORS.deepCanvas,
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  actionBtnHalf: {
    flex: 1,
  },
  btnContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnIcon: {
    marginRight: 6,
  },

  /* ── Sign Out ── */
  signOutBtn: {
    borderWidth: 1,
    borderColor: 'rgba(188, 184, 177, 0.2)',
    borderRadius: 14,
    paddingVertical: 15,
    alignItems: 'center',
    marginTop: 32,
  },
  signOutBtnPressed: {
    backgroundColor: 'rgba(188, 184, 177, 0.04)',
  },
  signOutText: {
    color: COLORS.mutedStone,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 2,
  },
});