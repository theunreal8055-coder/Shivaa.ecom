import React, { useRef, useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Pressable,
  Alert,
  Animated,
  Image,
  ActivityIndicator,
  Linking,
  RefreshControl,
} from 'react-native';
import { COLORS } from '../../theme';

interface NewsArticle {
  id: string;
  title: string;
  source: string;
  timeElapsed: string;
  category: string;
  summary: string;
  imageUrl: string;
  url: string;
}

// ─── Diverse, curated high-res Unsplash image pools ────────────────
const GOLD_IMAGES = [
  'https://images.unsplash.com/photo-1610374792793-f016b77ca51a?q=80&w=500',
  'https://images.unsplash.com/photo-1589758438368-0ad531db3366?q=80&w=500',
  'https://images.unsplash.com/photo-1535320903710-d993d3d77d29?q=80&w=500',
];

const SILVER_IMAGES = [
  'https://images.unsplash.com/photo-1618401471353-b98aedd07871?q=80&w=500',
  'https://images.unsplash.com/photo-1605792657660-596af9009e82?q=80&w=500',
];

const STOCK_IMAGES = [
  'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=500',
  'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?q=80&w=500',
  'https://images.unsplash.com/photo-1642390090886-070104f6af05?q=80&w=500',
];

const POLITICS_IMAGES = [
  'https://images.unsplash.com/photo-1541872703-74c5e44368f9?q=80&w=500',
  'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?q=80&w=500',
  'https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=500',
];

const MACRO_IMAGES = [
  'https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?q=80&w=500',
  'https://images.unsplash.com/photo-1601597111158-2fceff292cdc?q=80&w=500',
  'https://images.unsplash.com/photo-1502920514313-52581002a659?q=80&w=500',
];

const GENERAL_IMAGES = [
  'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=500',
  'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=500',
  'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=500',
];

// Consistent string hashing to assign a stable, unique image index per title
const getHashIndex = (str: string, length: number): number => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  return Math.abs(hash) % length;
};

// Simple helper to unescape XML entities
const decodeXmlEntities = (str: string): string => {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#39;/g, "'")
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, ' ');
};

// Format elapsed time relative to current time
const formatTimeElapsed = (dateStr: string): string => {
  try {
    const pubDate = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - pubDate.getTime();
    if (isNaN(diffMs)) return 'Recently';

    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 60) {
      return diffMins <= 1 ? 'Just now' : `${diffMins}m ago`;
    }

    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) {
      return diffHours === 1 ? '1h ago' : `${diffHours}h ago`;
    }

    const diffDays = Math.floor(diffHours / 24);
    return diffDays === 1 ? '1d ago' : `${diffDays}d ago`;
  } catch (err) {
    return 'Recently';
  }
};

const parseGoogleNewsRss = (xmlString: string): NewsArticle[] => {
  const articles: NewsArticle[] = [];
  const items = xmlString.split('<item>');

  for (let i = 1; i < items.length && i <= 20; i++) {
    const item = items[i];

    // Extract title
    const titleMatch = item.match(/<title>([\s\S]*?)<\/title>/);
    let fullTitle = titleMatch ? titleMatch[1].trim() : '';
    fullTitle = decodeXmlEntities(fullTitle);

    // Split title and source (Google News format: "Title - Source")
    let title = fullTitle;
    let source = 'Markets';
    const lastDashIndex = fullTitle.lastIndexOf(' - ');
    if (lastDashIndex !== -1) {
      title = fullTitle.substring(0, lastDashIndex).trim();
      source = fullTitle.substring(lastDashIndex + 3).trim();
    }

    // Extract link
    const linkMatch = item.match(/<link>([\s\S]*?)<\/link>/);
    const url = linkMatch ? linkMatch[1].trim() : '';

    // Extract pubDate
    const pubDateMatch = item.match(/<pubDate>([\s\S]*?)<\/pubDate>/);
    const pubDateStr = pubDateMatch ? pubDateMatch[1].trim() : '';
    const timeElapsed = formatTimeElapsed(pubDateStr);

    // Determine category based on title keywords
    const tLower = title.toLowerCase();
    let category = 'MARKETS';

    if (
      tLower.includes('politic') ||
      tLower.includes('election') ||
      tLower.includes('govt') ||
      tLower.includes('government') ||
      tLower.includes('tariff') ||
      tLower.includes('trade') ||
      tLower.includes('sanction') ||
      tLower.includes('geopolitic') ||
      tLower.includes('war') ||
      tLower.includes('biden') ||
      tLower.includes('trump') ||
      tLower.includes('policy')
    ) {
      category = 'POLITICS & RISK';
    } else if (
      tLower.includes('fed') ||
      tLower.includes('rate') ||
      tLower.includes('inflation') ||
      tLower.includes('central bank') ||
      tLower.includes('interest')
    ) {
      category = 'MACRO HEDGE';
    } else if (
      tLower.includes('stock') ||
      tLower.includes('nasdaq') ||
      tLower.includes('dow') ||
      tLower.includes('s&p') ||
      tLower.includes('wall street') ||
      tLower.includes('equity') ||
      tLower.includes('shares') ||
      tLower.includes('index')
    ) {
      category = 'STOCK MARKET';
    } else if (tLower.includes('silver')) {
      category = 'SILVER INDEX';
    } else if (tLower.includes('gold') || tLower.includes('bullion')) {
      category = 'GOLD RATES';
    } else if (tLower.includes('shipwreck') || tLower.includes('coin') || tLower.includes('mine')) {
      category = 'MINING / SUPPLY';
    }

    // Pick a stable unique image from the matching pool using title hash
    let imageUrl = '';
    if (category === 'SILVER INDEX') {
      imageUrl = SILVER_IMAGES[getHashIndex(title, SILVER_IMAGES.length)];
    } else if (category === 'GOLD RATES') {
      imageUrl = GOLD_IMAGES[getHashIndex(title, GOLD_IMAGES.length)];
    } else if (category === 'POLITICS & RISK') {
      imageUrl = POLITICS_IMAGES[getHashIndex(title, POLITICS_IMAGES.length)];
    } else if (category === 'MACRO HEDGE') {
      imageUrl = MACRO_IMAGES[getHashIndex(title, MACRO_IMAGES.length)];
    } else if (category === 'STOCK MARKET') {
      imageUrl = STOCK_IMAGES[getHashIndex(title, STOCK_IMAGES.length)];
    } else {
      imageUrl = GENERAL_IMAGES[getHashIndex(title, GENERAL_IMAGES.length)];
    }

    articles.push({
      id: String(i),
      title,
      source,
      timeElapsed,
      category,
      summary: `Read full coverage from ${source} on the latest commodity changes.`,
      imageUrl,
      url,
    });
  }

  return articles;
};

function ArticleCard({
  item,
  onPress,
}: {
  item: NewsArticle;
  onPress: () => void;
}) {
  const scale = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Animated.spring(scale, {
      toValue: 0.98,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 30,
      bounciness: 6,
    }).start();
  };

  return (
    <Pressable onPress={onPress} onPressIn={handlePressIn} onPressOut={handlePressOut}>
      <Animated.View style={[styles.articleCard, { transform: [{ scale }] }]}>
        {/* Cover Image at the top (Discover style) */}
        {item.imageUrl ? (
          <Image source={{ uri: item.imageUrl }} style={styles.articleImage} />
        ) : null}

        {/* Info Area */}
        <View style={styles.cardInfoContainer}>
          <View style={styles.categoryRow}>
            <View style={styles.categoryPill}>
              <Text style={styles.categoryText}>{item.category}</Text>
            </View>
            <Text style={styles.timeText}>{item.timeElapsed}</Text>
          </View>

          {/* Headline */}
          <Text style={styles.articleTitle} numberOfLines={3}>
            {item.title}
          </Text>

          {/* Footer Metadata */}
          <View style={styles.metadataRow}>
            <Text style={styles.sourceText} numberOfLines={1}>
              {item.source}
            </Text>
            <Text style={styles.readMoreText}>Read Story →</Text>
          </View>
        </View>
      </Animated.View>
    </Pressable>
  );
}

export default function NewsScreen() {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<string>('');

  const fetchNewsFeed = async () => {
    try {
      // Append cache-busting timestamp to bypass HTTP cache on mobile refresh
      const feedUrl = `https://news.google.com/rss/search?q=gold+OR+silver+OR+%22stock+market%22+OR+geopolitics+OR+inflation+OR+%22interest+rates%22+OR+commodities&hl=en-US&gl=US&ceid=US:en&_t=${Date.now()}`;
      const response = await fetch(feedUrl);
      const xmlText = await response.text();
      const parsed = parseGoogleNewsRss(xmlText);
      setArticles(parsed);

      const date = new Date();
      const hrs = String(date.getHours()).padStart(2, '0');
      const mins = String(date.getMinutes()).padStart(2, '0');
      const secs = String(date.getSeconds()).padStart(2, '0');
      setLastUpdated(`${hrs}:${mins}:${secs}`);
    } catch (error) {
      console.error('Error fetching news:', error);
      Alert.alert('Error', 'Could not load latest news articles.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchNewsFeed();
  }, []);

  const handleArticlePress = (item: NewsArticle) => {
    if (item.url) {
      Linking.openURL(item.url).catch(() => {
        Alert.alert('Error', 'Could not open article link.');
      });
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchNewsFeed();
  };

  return (
    <View style={styles.container}>
      {articles.length === 0 && !loading ? (
        <View style={styles.centerContainer}>
          <Text style={styles.emptyText}>No news articles found right now.</Text>
        </View>
      ) : (
        <FlatList
          data={articles}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          ListHeaderComponent={
            loading && !refreshing ? (
              <View style={{ paddingVertical: 20, alignItems: 'center', justifyContent: 'center' }}>
                <ActivityIndicator size="small" color={COLORS.accent} />
              </View>
            ) : null
          }
          renderItem={({ item }) => (
            <ArticleCard item={item} onPress={() => handleArticlePress(item)} />
          )}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor={COLORS.accent}
              colors={[COLORS.accent]}
            />
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    paddingHorizontal: 18,
    paddingTop: 16,
  },
  headerLabel: {
    color: COLORS.textSecondary,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2.5,
    textTransform: 'uppercase',
    marginTop: 10,
    marginBottom: 20,
    paddingLeft: 2,
  },
  listContainer: {
    paddingBottom: 30,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: COLORS.background,
    gap: 12,
  },
  loadingText: {
    color: COLORS.textSecondary,
    fontSize: 13,
    fontWeight: '600',
  },
  emptyText: {
    color: COLORS.textSecondary,
    fontSize: 14,
    textAlign: 'center',
  },

  /* ── Discover Style Card ── */
  articleCard: {
    backgroundColor: COLORS.surface,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
    overflow: 'hidden',
    marginBottom: 16,
  },
  articleImage: {
    width: '100%',
    height: 170,
    backgroundColor: COLORS.surfaceLight,
  },
  cardInfoContainer: {
    padding: 16,
  },
  categoryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  categoryPill: {
    backgroundColor: COLORS.accentLight,
    paddingHorizontal: 8,
    paddingVertical: 3.5,
    borderRadius: 6,
  },
  categoryText: {
    color: COLORS.accent,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.8,
  },
  articleTitle: {
    color: COLORS.textPrimary,
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 22,
    marginBottom: 14,
  },
  metadataRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    paddingTop: 12,
  },
  sourceText: {
    color: COLORS.accent,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.2,
    maxWidth: '70%',
  },
  timeText: {
    color: COLORS.textSecondary,
    fontSize: 10.5,
    fontWeight: '600',
  },
  readMoreText: {
    color: COLORS.textSecondary,
    fontSize: 10.5,
    fontWeight: '700',
  },
});
