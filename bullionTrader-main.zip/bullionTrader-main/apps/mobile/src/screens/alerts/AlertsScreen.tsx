import React, { useState, useRef, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  Pressable,
  FlatList,
  Switch,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Animated,
} from 'react-native';
import { supabase } from '../../services/supabase';
import { listAlerts, createAlert, updateAlert, deleteAlert } from '../../services/data';
import { COLORS } from '../../theme';

interface PriceAlert {
  id: string;
  metal: 'GOLD' | 'SILVER';
  condition: 'Drops Below' | 'Rises Above';
  targetValue: number;
  isActive: boolean;
}

function ScaleButton({
  onPress,
  style,
  children,
  activeOpacity = 0.92,
}: {
  onPress: () => void;
  style?: any;
  children: React.ReactNode;
  activeOpacity?: number;
}) {
  const scale = useRef(new Animated.Value(1)).current;

  const handlePressIn = () => {
    Animated.spring(scale, {
      toValue: 0.96,
      useNativeDriver: true,
      speed: 50,
      bounciness: 4,
    }).start();
  };

  const handlePressOut = () => {
    Animated.spring(scale, {
      toValue: 1,
      useNativeDriver: true,
      speed: 30,
      bounciness: 6,
    }).start();
  };

  return (
    <Pressable onPress={onPress} onPressIn={handlePressIn} onPressOut={handlePressOut}>
      <Animated.View style={[style, { transform: [{ scale }] }]}>
        {children}
      </Animated.View>
    </Pressable>
  );
}

export default function AlertsScreen() {
  const [selectedMetal, setSelectedMetal] = useState<'GOLD' | 'SILVER'>('GOLD');
  const [selectedCondition, setSelectedCondition] = useState<'Drops Below' | 'Rises Above'>('Drops Below');
  const [targetPrice, setTargetPrice] = useState('');
  const [isInputFocused, setIsInputFocused] = useState(false);

  const [alerts, setAlerts] = useState<PriceAlert[]>([]);

  // Realtime subscription & mock fallback simulation states
  const lastUpdate = useRef<number>(0);
  const goldPriceRef = useRef<number>(72400);
  const silverPriceRef = useRef<number>(86100);

  // Keep a ref to alerts so the Realtime subscription and setInterval callback always have the latest list
  const alertsRef = useRef<PriceAlert[]>(alerts);
  useEffect(() => {
    alertsRef.current = alerts;
  }, [alerts]);

  // Helper function to check and trigger alerts (for local foreground user alerts feedback)
  const checkAlerts = (currentGold: number, currentSilver: number) => {
    goldPriceRef.current = currentGold;
    silverPriceRef.current = currentSilver;

    let triggeredAny = false;
    const updatedAlerts = alertsRef.current.map((alert) => {
      if (!alert.isActive) return alert;

      const currentPrice = alert.metal === 'GOLD' ? currentGold : currentSilver;
      const isHit =
        alert.condition === 'Drops Below'
          ? currentPrice < alert.targetValue
          : currentPrice > alert.targetValue;

      if (isHit) {
        triggeredAny = true;
        // Trigger native alert notification
        Alert.alert(
          '🚨 Price Alert Triggered!',
          `${alert.metal} has ${alert.condition === 'Drops Below' ? 'dropped below' : 'risen above'} ₹${alert.targetValue.toLocaleString('en-IN')}.\n\nActual price: ₹${currentPrice.toLocaleString('en-IN')}.`,
          [{ text: 'OK' }]
        );
        return { ...alert, isActive: false }; // deactivate
      }
      return alert;
    });

    if (triggeredAny) {
      setAlerts(updatedAlerts);
    }
  };

  useEffect(() => {
    // 1. Fetch alerts directly from Supabase (RLS scopes them to this user)
    async function loadAlerts() {
      try {
        const rows = await listAlerts();
        setAlerts(rows.map((item) => ({
          id: item.id,
          metal: item.metal,
          condition: item.direction === 'above' ? 'Rises Above' : 'Drops Below',
          targetValue: Number(item.target_price),
          isActive: !!item.is_active,
        })));
      } catch (err: any) {
        console.error('Error fetching alerts:', err.message);
      }
    }
    loadAlerts();

    // 2. Subscribe to Supabase Realtime channel for live ticks comparison
    const channel = supabase.channel('bullion_alerts', {
      config: { broadcast: { ack: false } }
    });

    channel
      .on('broadcast', { event: 'rate-update' }, (message) => {
        const payload = message.payload;
        if (!payload) return;

        lastUpdate.current = Date.now();
        const currentGold = payload.gold?.bid;
        const currentSilver = payload.silver?.bid;

        if (currentGold && currentSilver) {
          checkAlerts(currentGold, currentSilver);
        }
      })
      .subscribe();

    // 3. Client-side fallback simulator (in case server broadcaster is offline/idle)
    const interval = setInterval(() => {
      const timeSinceLastUpdate = Date.now() - lastUpdate.current;
      if (timeSinceLastUpdate > 4000) {
        // Gold simulation
        const goldDelta = Math.round((Math.random() - 0.5) * 16);
        const nextGold = goldPriceRef.current + goldDelta;

        // Silver simulation
        const silverDelta = Math.round((Math.random() - 0.5) * 24);
        const nextSilver = silverPriceRef.current + silverDelta;

        checkAlerts(nextGold, nextSilver);
      }
    }, 1500);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(interval);
    };
  }, []);

  const handleAddAlert = async () => {
    const value = parseFloat(targetPrice);
    if (isNaN(value) || value <= 0) {
      Alert.alert('Invalid Price', 'Please enter a valid positive numeric target price.');
      return;
    }

    try {
      const item = await createAlert({
        metal: selectedMetal,
        direction: selectedCondition === 'Rises Above' ? 'above' : 'below',
        target_price: value,
      });

      const newAlert: PriceAlert = {
        id: item.id,
        metal: item.metal,
        condition: item.direction === 'above' ? 'Rises Above' : 'Drops Below',
        targetValue: Number(item.target_price),
        isActive: !!item.is_active,
      };

      setAlerts([newAlert, ...alerts]);
      setTargetPrice('');
      Alert.alert('Alert Set', `We will notify you when ${selectedMetal} ${selectedCondition.toLowerCase()} ₹${value.toLocaleString('en-IN')}.`);
    } catch (err: any) {
      console.error('Error creating alert:', err.message);
      Alert.alert('Error', 'Failed to save alert. Please try again.');
    }
  };

  const toggleAlertStatus = async (id: string) => {
    const targetAlert = alerts.find(x => x.id === id);
    if (!targetAlert) return;
    const nextVal = !targetAlert.isActive;

    // Optimistic UI update
    setAlerts(prevAlerts =>
      prevAlerts.map(alert =>
        alert.id === id ? { ...alert, isActive: nextVal } : alert
      )
    );

    try {
      await updateAlert(id, { is_active: nextVal });
    } catch (err: any) {
      console.error('Error toggling alert status:', err.message);
      // Revert UI state
      setAlerts(prevAlerts =>
        prevAlerts.map(alert =>
          alert.id === id ? { ...alert, isActive: !nextVal } : alert
        )
      );
    }
  };

  const deleteAlert = async (id: string) => {
    const targetAlert = alerts.find(x => x.id === id);
    if (!targetAlert) return;

    // Optimistic UI update
    setAlerts(prevAlerts => prevAlerts.filter(alert => alert.id !== id));

    try {
      await deleteAlert(id);
    } catch (err: any) {
      console.error('Error deleting alert:', err.message);
      // Revert UI state
      if (targetAlert) {
        setAlerts(prevAlerts => [targetAlert, ...prevAlerts]);
      }
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <View style={styles.content}>
        {/* ── Form Card ── */}
        <View style={styles.formCard}>
          <Text style={styles.sectionTitle}>CREATE ALERT</Text>

          {/* Metal Selector — rounded pill toggle */}
          <View style={styles.metalToggleTrack}>
            {(['GOLD', 'SILVER'] as const).map((metal) => {
              const isActive = selectedMetal === metal;
              return (
                <Pressable
                  key={metal}
                  style={[styles.metalPill, isActive && styles.metalPillActive]}
                  onPress={() => setSelectedMetal(metal)}
                >
                  <Text
                    style={[
                      styles.metalPillText,
                      isActive && styles.metalPillTextActive,
                    ]}
                  >
                    {metal}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {/* Condition Pills — outlined with accent border when active */}
          <View style={styles.conditionRow}>
            {(['Drops Below', 'Rises Above'] as const).map((cond) => {
              const isActive = selectedCondition === cond;
              return (
                <Pressable
                  key={cond}
                  style={[styles.conditionPill, isActive && styles.conditionPillActive]}
                  onPress={() => setSelectedCondition(cond)}
                >
                  <Text
                    style={[
                      styles.conditionPillText,
                      isActive && styles.conditionPillTextActive,
                    ]}
                  >
                    {cond}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          {/* Target Price Input */}
          <View
            style={[
              styles.inputWell,
              isInputFocused && styles.inputWellFocused,
            ]}
          >
            <Text style={styles.currencySymbol}>₹</Text>
            <TextInput
              style={styles.numericInput}
              placeholder="Target Rate"
              placeholderTextColor={COLORS.mutedStone}
              value={targetPrice}
              onChangeText={setTargetPrice}
              keyboardType="numeric"
              onFocus={() => setIsInputFocused(true)}
              onBlur={() => setIsInputFocused(false)}
            />
          </View>

          {/* Add Button — gold accent background */}
          <ScaleButton onPress={handleAddAlert} style={styles.addButton}>
            <Text style={styles.addButtonText}>ACTIVATE ALERT</Text>
          </ScaleButton>
        </View>

        {/* ── Active Alerts Header ── */}
        <Text style={styles.listHeading}>ACTIVE ALERTS</Text>

        {/* ── Alert List ── */}
        <FlatList
          data={alerts}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={[styles.alertCard, !item.isActive && styles.alertCardInactive]}>
              <View style={styles.alertTopRow}>
                <View style={styles.alertMeta}>
                  <View
                    style={[
                      styles.metalBadge,
                      item.metal === 'GOLD' ? styles.metalBadgeGold : styles.metalBadgeSilver,
                    ]}
                  >
                    <Text style={styles.metalBadgeText}>{item.metal}</Text>
                  </View>
                  <Text style={styles.conditionLabel}>
                    {item.condition}
                  </Text>
                </View>
                <View style={styles.alertActions}>
                  <Switch
                    value={item.isActive}
                    onValueChange={() => toggleAlertStatus(item.id)}
                    trackColor={{ false: COLORS.mutedStone, true: COLORS.luxuryAccent }}
                    thumbColor={item.isActive ? COLORS.deepCanvas : COLORS.lightCore}
                    ios_backgroundColor={COLORS.mutedStone}
                  />
                  <Pressable
                    style={styles.deleteBtn}
                    onPress={() => deleteAlert(item.id)}
                    hitSlop={8}
                  >
                    <Text style={styles.deleteBtnText}>✕</Text>
                  </Pressable>
                </View>
              </View>
              <Text style={styles.targetValue}>
                ₹{item.targetValue.toLocaleString('en-IN')}
              </Text>
            </View>
          )}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>
                No active alerts. Set your first target above.
              </Text>
            </View>
          }
        />
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.deepCanvas,
  },
  content: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 8,
  },

  /* ── Form Card ── */
  formCard: {
    backgroundColor: COLORS.darkWell,
    borderRadius: 16,
    padding: 20,
    marginBottom: 28,
    borderWidth: 1,
    borderColor: 'rgba(188, 184, 177, 0.08)',
  },
  sectionTitle: {
    color: COLORS.mutedStone,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2.5,
    textTransform: 'uppercase',
    marginBottom: 18,
  },

  /* ── Metal Pill Toggle ── */
  metalToggleTrack: {
    flexDirection: 'row',
    backgroundColor: 'rgba(188, 184, 177, 0.06)',
    borderRadius: 24,
    padding: 3,
    marginBottom: 16,
  },
  metalPill: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  metalPillActive: {
    backgroundColor: COLORS.luxuryAccent,
    shadowColor: COLORS.luxuryAccent,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 3,
  },
  metalPillText: {
    color: COLORS.mutedStone,
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 1.5,
  },
  metalPillTextActive: {
    color: COLORS.deepCanvas,
  },

  /* ── Condition Pills ── */
  conditionRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  conditionPill: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(188, 184, 177, 0.15)',
    alignItems: 'center',
  },
  conditionPillActive: {
    borderColor: COLORS.luxuryAccent,
    backgroundColor: 'rgba(224, 175, 160, 0.06)',
  },
  conditionPillText: {
    color: COLORS.mutedStone,
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  conditionPillTextActive: {
    color: COLORS.luxuryAccent,
    fontWeight: '700',
  },

  /* ── Input Well ── */
  inputWell: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(188, 184, 177, 0.04)',
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 4,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(188, 184, 177, 0.1)',
  },
  inputWellFocused: {
    borderColor: COLORS.luxuryAccent,
    backgroundColor: 'rgba(224, 175, 160, 0.04)',
  },
  currencySymbol: {
    color: COLORS.luxuryAccent,
    fontSize: 20,
    fontWeight: '600',
    marginRight: 8,
  },
  numericInput: {
    flex: 1,
    color: COLORS.lightCore,
    fontSize: 18,
    fontWeight: '700',
    paddingVertical: Platform.OS === 'ios' ? 12 : 8,
  },

  /* ── Add Button ── */
  addButton: {
    backgroundColor: COLORS.luxuryAccent,
    paddingVertical: 15,
    borderRadius: 14,
    alignItems: 'center',
    shadowColor: COLORS.luxuryAccent,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  addButtonText: {
    color: COLORS.deepCanvas,
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 1.5,
  },

  /* ── List Header ── */
  listHeading: {
    color: COLORS.mutedStone,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2.5,
    textTransform: 'uppercase',
    marginBottom: 14,
    paddingLeft: 2,
  },
  listContainer: {
    paddingBottom: 30,
  },

  /* ── Alert Card ── */
  alertCard: {
    backgroundColor: COLORS.darkWell,
    borderRadius: 14,
    padding: 16,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'rgba(188, 184, 177, 0.08)',
  },
  alertCardInactive: {
    opacity: 0.5,
  },
  alertTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  alertMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  metalBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
  },
  metalBadgeGold: {
    backgroundColor: 'rgba(224, 175, 160, 0.15)',
  },
  metalBadgeSilver: {
    backgroundColor: 'rgba(188, 184, 177, 0.12)',
  },
  metalBadgeText: {
    color: COLORS.lightCore,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 1.2,
  },
  conditionLabel: {
    color: COLORS.luxuryAccent,
    fontSize: 13,
    fontWeight: '600',
  },
  alertActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  targetValue: {
    color: COLORS.lightCore,
    fontSize: 22,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  deleteBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(188, 184, 177, 0.06)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteBtnText: {
    color: COLORS.mutedStone,
    fontSize: 12,
    fontWeight: '600',
  },

  /* ── Empty State ── */
  emptyContainer: {
    paddingVertical: 40,
    alignItems: 'center',
  },
  emptyText: {
    color: COLORS.mutedStone,
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 20,
  },
});
