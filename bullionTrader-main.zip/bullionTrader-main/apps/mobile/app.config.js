module.exports = ({ config }) => {
  return {
    ...config,
    plugins: [
      ...(config.plugins || []),
      "expo-font"
    ],
    android: {
      ...config.android,
      googleServicesFile: process.env.GOOGLE_SERVICES_JSON || "./google-services.json"
    }
  };
};
