import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Read api-gateway env
dotenv.config({ path: './backend/api-gateway/.env' });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.log("Missing Supabase credentials in env file.");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { persistSession: false }
});

async function run() {
  const email = 'admin@laxmibullion.in';
  const password = 'password123';
  
  console.log("Creating or resetting admin user:", email);
  
  // List current users to clean up if it already exists
  const { data: { users }, error: listError } = await supabase.auth.admin.listUsers();
  if (listError) throw listError;

  const existing = users.find(u => u.email === email);
  if (existing) {
    const { error: delError } = await supabase.auth.admin.deleteUser(existing.id);
    if (delError) console.log("Note: Could not delete existing user:", delError.message);
    else console.log("Removed previous instance of admin user.");
  }
  
  // Create user
  const { data, error } = await supabase.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: {
      full_name: 'Admin User',
      phone: '+91 99999 88888',
      business_name: 'Laxmi Abhushan Administration'
    }
  });
  
  if (error) {
    console.error("Error creating admin user:", error.message);
    return;
  }

  const userId = data.user.id;
  
  // Wait a moment for trigger to create the profile
  await new Promise((resolve) => setTimeout(resolve, 1000));

  // Update role to 'admin' in profiles table
  const { error: profileError } = await supabase
    .from('profiles')
    .update({ role: 'admin' })
    .eq('id', userId);

  if (profileError) {
    console.error("Error updating admin role in profiles table:", profileError.message);
  } else {
    console.log("----------------------------------------");
    console.log("🎉 Admin Account Created Successfully!");
    console.log("Email:    admin@laxmibullion.in");
    console.log("Password: password123");
    console.log("Role set to 'admin' in database profiles.");
    console.log("----------------------------------------");
  }
}

run().catch(console.error);
