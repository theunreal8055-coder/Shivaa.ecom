import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Read api-gateway env
dotenv.config({ path: './backend/api-gateway/.env' });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.log("Missing Supabase credentials in env file.");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { persistSession: false }
});

async function run() {
  console.log("Connecting to Supabase at:", supabaseUrl);
  
  // List auth users
  const { data: { users }, error } = await supabase.auth.admin.listUsers();
  
  if (error) {
    console.error("Error listing users:", error.message);
    process.exit(1);
  }
  
  if (!users || users.length === 0) {
    console.log("No registered users found in the database. You can register a new account on the Signup screen!");
  } else {
    console.log(`Found ${users.length} users:`);
    users.forEach(user => {
      console.log(`- Email: ${user.email}`);
    });
  }

  if (!users || users.length === 0) {
    console.log("No registered users found in the database. You can register a new account on the Signup screen!");
  } else {
    console.log(`Found ${users.length} users:`);
    users.forEach(user => {
      console.log(`- Email: ${user.email}`);
    });
  }
}

run().catch(console.error);





