import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Read api-gateway env
dotenv.config({ path: './backend/api-gateway/.env' });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.log("Missing Supabase credentials in env file.");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { persistSession: false }
});

async function run() {
  const email = 'demo@laxmibullion.in';
  const password = 'password123';
  
  console.log("Creating or resetting demo user:", email);
  
  // List current users to clean up if it already exists
  const { data: { users }, error: listError } = await supabase.auth.admin.listUsers();
  if (listError) throw listError;

  const existing = users.find(u => u.email === email);
  if (existing) {
    const { error: delError } = await supabase.auth.admin.deleteUser(existing.id);
    if (delError) console.log("Note: Could not delete existing user:", delError.message);
    else console.log("Removed previous instance of demo user.");
  }
  
  // Create user
  const { data, error } = await supabase.auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: {
      full_name: 'Demo Trader',
      phone: '+91 98765 43210',
      business_name: 'Laxmi Abhushan Demo'
    }
  });
  
  if (error) {
    console.error("Error creating demo user:", error.message);
  } else {
    console.log("----------------------------------------");
    console.log("🎉 Demo Account Created Successfully!");
    console.log("Email / ID:  demo@laxmibullion.in");
    console.log("Password:    password123");
    console.log("----------------------------------------");
  }
}

run().catch(console.error);
