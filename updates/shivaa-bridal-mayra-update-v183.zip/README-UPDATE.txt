Shivaa Bridal & Mayra Booking Update — v183

This archive contains the production CMS files changed for the booking update.
Paths are relative to the repository root. Review before applying; this archive
has not been deployed. Preview-only server code and smoke-test files are omitted.

GitHub PR: https://github.com/theunreal8055-coder/Shivaa.ecom/pull/102
Commit: 56cb510 feat: add bridal and mayra booking journey
