/* =====================================================================
   Shivaa Jewels — SHIVAA'S SHOWROOM 2027 (vision board) · v30
   The owner's dream showroom photo + target date (Dhanteras, 27 October 2027):
   • Targets tab   — big banner: photo, countdown, time progress, the "safar" milestones, line of the day
   • Dashboard     — compact card with countdown
   • Login screen  — the dream showroom as the background
   • Setup         — change photo / title / date, or hide
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const role = () => (window.SJ_USER || { role: 'owner' }).role || 'owner';
  const isOwner = () => !SITE || role() === 'owner';
  const q$ = (s, r) => (r || document).querySelector(s);
  const DEF = { on: true, title: "Shivaa's Showroom", sub: 'Wholesale & Retail · Wedding Gold Planner · Gold · Silver', date: '2027-10-27', label: 'Dhanteras', start: '2026-11-13', dash: true, login: true };
  const V = () => { const v = { ...DEF, ...((settings().pro || {}).vision || {}) }; if (!v.title || /naya showroom/i.test(v.title)) v.title = DEF.title; return v; };
  const img = (small) => { const v = V(); return v.img || (small ? 'vision-shop-sm.jpg' : 'vision-shop.jpg'); };
  const LINES = ['Har bill is showroom ki ek eent hai. 🧱', 'Aaj ki mehnat, kal ka showroom. ✨', 'Chhote kadam, badi manzil — roz aage. 🚶', 'Grahak ka bharosa hi asli sona hai. 🙏', 'Jo likha hai, wo banega. 27-10-2027. 🎯', 'Roshni wahi jo andar se ho — aur board par bhi! 💡', 'Shivaa — wholesale se wedding planner tak. 💍', 'Aaj ka ek naya grahak, kal ka parivaar. 👨‍👩‍👧'];
  function count(v) {
    const t = todayStr(); const left = daysBetween(t, v.date); const total = Math.max(1, daysBetween(v.start || t, v.date)); const done = Math.min(1, Math.max(0, (total - Math.max(0, left)) / total));
    const d0 = parseD(t), d1 = parseD(v.date); let m = (d1.getFullYear() - d0.getFullYear()) * 12 + (d1.getMonth() - d0.getMonth()); let dd = d1.getDate() - d0.getDate(); if (dd < 0) { m--; dd += new Date(d1.getFullYear(), d1.getMonth(), 0).getDate(); }
    return { left, total, done, months: Math.max(0, m), days: Math.max(0, dd), weeks: Math.floor(Math.max(0, left) / 7) };
  }
  const dateTxt = d => parseD(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' });
  const line = () => LINES[(parseInt(todayStr().replace(/-/g, ''), 10) || 0) % LINES.length];
  // milestones: owner's own list, else 4 sensible stops between start and the big day
  function steps(v) {
    if (Array.isArray(v.miles) && v.miles.length) return v.miles.filter(m => m && m.d).slice(0, 6).sort((a, b) => String(a.d).localeCompare(String(b.d)));
    const s = parseD(v.start || todayStr()), e = parseD(v.date), span = (e - s) / 86400000; const N = ['Plan & naksha pakka', 'Interior & board', 'Stock & staff taiyaar'];
    return [...N.map((n, k) => ({ d: new Date(s.getTime() + span * (k + 1) / 4 * 86400000).toISOString().slice(0, 10), n })), { d: v.date, n: 'Udghatan — ' + (v.label || 'Showroom') }];
  }
  function salesSince(from) { return sum(S.invoices.filter(x => !x.deleted && (x.type === 'sale' || x.type === 'estimate') && x.date >= from), x => invPayable(x)); }
  function pulse(v) {
    const t = todayStr(), c = count(v), sold = salesSince(v.start || t), gone = Math.max(1, daysBetween(v.start || t, t) + 1), perDay = sold / gone, proj = sold + perDay * Math.max(0, c.left);
    const goal = num(v.goal); const need = goal ? Math.max(0, goal - sold) / Math.max(1, c.left) : 0; const gp = goal ? Math.min(1, sold / goal) : 0;
    return { sold, perDay, proj, goal, need, gp, ahead: goal ? gp >= c.done : null };
  }
  const short = n => { n = num(n); return n >= 1e7 ? '₹' + (n / 1e7).toFixed(n >= 1e8 ? 0 : 2) + ' Cr' : n >= 1e5 ? '₹' + (n / 1e5).toFixed(n >= 1e6 ? 1 : 2) + ' L' : inr(n); };
  const targetMs = v => parseD(v.date).getTime() + 10 * 3600 * 1000;   // the big day, 10 AM

  function banner() {
    const v = V(); if (!v.on || !v.date) return ''; const c = count(v), p = pulse(v), t = todayStr(), st = steps(v), done = c.left < 0 || (c.left === 0 && Date.now() >= targetMs(v));
    const R = 54, L = 2 * Math.PI * R, off = L * (1 - c.done);
    const tStart = parseD(v.start || t).getTime(), tEnd = parseD(v.date).getTime(), pos = d => Math.min(100, Math.max(0, (parseD(d).getTime() - tStart) / Math.max(1, tEnd - tStart) * 100));
    const now = Math.min(100, Math.max(0, (Date.now() - tStart) / Math.max(1, tEnd - tStart) * 100));
    return `<div class="vz-big"><div class="vz-img" style="background-image:url('${esc(img(false))}')"></div><div class="vz-shade"></div><div class="vz-rays" aria-hidden="true"></div><canvas class="vz-fx" aria-hidden="true"></canvas>
      <div class="vz-grid">
        <div class="vz-a">
          <div class="vz-tag vz-shine">✦ COMING SOON ✦</div>
          <div class="vz-hl"><span class="vz-this">This is</span><h2 data-t="${esc(v.title)}">${esc(v.title)}</h2><div class="vz-in">in <b class="vz-shine">${esc(dateTxt(v.date))}</b></div></div>
          <div class="vz-date">🪔 ${v.label ? `${esc(v.label)} ke shubh din udghatan` : 'Shubh udghatan'}${v.sub ? ` <span>·</span> <em>${esc(v.sub)}</em>` : ''}</div>
          ${done ? `<div class="vz-done">🎉 ${c.left === 0 ? 'Aaj udghatan ka din hai — shubh udghatan!' : 'Showroom khul gaya — badhai ho!'}</div>` : `<div class="vz-live" data-vz-live="${targetMs(v)}">${['DIN', 'GHANTE', 'MINUTE', 'SECOND'].map((l, k) => `<div><b data-k="${k}">--</b><span>${l}</span></div>`).join('')}</div>
          <div class="vz-cal">Calendar se: ${c.months} mahine ${c.days} din · ${c.weeks} hafte</div>`}
          <div class="vz-quote">“${esc(line())}”</div>
          <div class="vz-act">${isOwner() ? '<button class="btn sm" data-act="vz-edit">✎ Badlo</button>' : ''}<button class="btn sm" data-act="vz-full">⤢ Poori photo</button></div>
        </div>
        <div class="vz-b">
          <div class="vz-ringrow"><div class="vz-ring" style="--L:${L.toFixed(1)};--o:${off.toFixed(1)}"><svg viewBox="0 0 128 128" aria-hidden="true"><defs><linearGradient id="vzg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff2c4"/><stop offset=".5" stop-color="#e2b04a"/><stop offset="1" stop-color="#a8741d"/></linearGradient></defs><circle cx="64" cy="64" r="60" class="orb"/><circle cx="64" cy="64" r="${R}" class="bg"/><circle cx="64" cy="64" r="${R}" class="fg" stroke-dasharray="${L.toFixed(1)}" stroke-dashoffset="${off.toFixed(1)}"/></svg><div><b data-vz-count="${Math.round(c.done * 100)}">0%</b><span>safar poora</span></div></div>
            <div class="vz-kp"><div><span>Safar shuru hone se bikri</span><b>${short(p.sold)}</b></div><div><span>Roz ki average</span><b>${short(p.perDay)}</b></div><div><span>Is raftaar se ${esc(v.label || 'udghatan')} tak</span><b class="gold">${short(p.proj)}</b></div></div></div>
          ${p.goal ? `<div class="vz-goal"><div class="vz-gh"><span>Bikri ka lakshya ${short(p.goal)}</span><b class="${p.ahead ? 'up' : 'dn'}">${p.ahead ? '▲ Samay se aage' : '▼ Thoda peeche'}</b></div><div class="vz-bar"><i style="width:${(p.gp * 100).toFixed(1)}%"></i><em style="left:${(c.done * 100).toFixed(1)}%"></em></div><div class="vz-gf"><span>${Math.round(p.gp * 100)}% poora</span><span>Roz chahiye: <b>${short(p.need)}</b></span></div></div>` : (isOwner() ? '<button class="vz-setgoal" data-act="vz-edit">＋ Bikri ka lakshya jodiye — roz kitna chahiye, software batayega</button>' : '')}
          <div class="vz-tl"><div class="vz-line"><i style="width:${now.toFixed(1)}%"></i><u style="left:${now.toFixed(1)}%" title="Aaj"></u></div>${st.map((m, k) => `<div class="vz-ms ${m.d <= t ? 'on' : ''} ${k === st.length - 1 ? 'last' : ''}" style="left:${pos(m.d).toFixed(1)}%"><i></i></div>`).join('')}</div>
          <div class="vz-mlist">${st.map((m, k) => `<div class="${m.d <= t ? 'on' : ''}"><i>${m.d <= t ? '✓' : k === st.length - 1 ? '🏬' : k + 1}</i><span>${esc(m.n)}</span><small>${esc(parseD(m.d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: '2-digit' }))}</small></div>`).join('')}</div>
        </div>
        <button type="button" class="vz-photo" data-act="vz-full" aria-label="Poori photo"><i class="vz-pf"><img src="${esc(img(false))}" alt="${esc(v.title)} — ${esc(dateTxt(v.date))}"><u class="vz-glare"></u></i><span>${esc(v.title)} · ${parseD(v.date).getFullYear()}</span></button>
      </div></div>`;
  }
  /* ---- motion: gold dust canvas + count-up (pauses when hidden, off for reduced-motion) ---- */
  const RM = (() => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } })();
  const FX = new WeakMap();
  function fxFrame(t) {
    requestAnimationFrame(fxFrame);
    if (RM || document.hidden || document.documentElement.classList.contains('tv-on')) return;
    document.querySelectorAll('canvas.vz-fx').forEach(cv => {
      const box = cv.parentElement; if (!box) return; const w = box.clientWidth, h = box.clientHeight; if (!w || !h) return;
      let S2 = FX.get(cv); const dpr = Math.min(2, window.devicePixelRatio || 1);
      if (!S2 || S2.w !== w || S2.h !== h) {
        cv.width = w * dpr; cv.height = h * dpr; cv.style.width = w + 'px'; cv.style.height = h + 'px';
        const n = Math.round(Math.min(90, w * h / 9000));
        S2 = { w, h, last: t, p: Array.from({ length: n }, () => mk(w, h, true)), sp: [] }; FX.set(cv, S2);
      }
      const dt = Math.min(50, t - S2.last) / 16.7; S2.last = t;
      const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h); g.globalCompositeOperation = 'lighter';
      for (const q of S2.p) {
        q.y -= q.v * dt; q.x += Math.sin((t / 1000) * q.f + q.ph) * .25 * dt; q.life += dt;
        if (q.y < -10) Object.assign(q, mk(w, h, false));
        const a = q.a * (0.55 + 0.45 * Math.sin(t / 380 * q.f + q.ph));
        const gr = g.createRadialGradient(q.x, q.y, 0, q.x, q.y, q.r * 3); gr.addColorStop(0, `rgba(255,236,170,${a})`); gr.addColorStop(1, 'rgba(242,190,90,0)');
        g.fillStyle = gr; g.beginPath(); g.arc(q.x, q.y, q.r * 3, 0, 6.283); g.fill();
      }
      if (Math.random() < .035 * dt) S2.sp.push({ x: Math.random() * w, y: Math.random() * h * .9, life: 0, max: 40 + Math.random() * 30, s: 5 + Math.random() * 9 });
      S2.sp = S2.sp.filter(z => (z.life += dt) < z.max);
      for (const z of S2.sp) {
        const k = Math.sin(Math.PI * z.life / z.max), L2 = z.s * k; g.strokeStyle = `rgba(255,246,210,${.9 * k})`; g.lineWidth = 1.2;
        g.beginPath(); g.moveTo(z.x - L2, z.y); g.lineTo(z.x + L2, z.y); g.moveTo(z.x, z.y - L2); g.lineTo(z.x, z.y + L2); g.stroke();
        g.fillStyle = `rgba(255,250,230,${k})`; g.beginPath(); g.arc(z.x, z.y, 1.6 * k, 0, 6.283); g.fill();
      }
    });
    document.querySelectorAll('[data-vz-count]:not([data-vz-go])').forEach(b => {
      b.dataset.vzGo = '1'; const to = +b.dataset.vzCount || 0;
      if (RM) { b.textContent = to + '%'; return; }
      const t0 = performance.now(); const step = n => { const k = Math.min(1, (n - t0) / 1600), e = 1 - Math.pow(1 - k, 3); b.textContent = Math.round(to * e) + '%'; if (k < 1) requestAnimationFrame(step); }; requestAnimationFrame(step);
    });
  }
  function mk(w, h, any) { return { x: Math.random() * w, y: any ? Math.random() * h : h + 10, r: .6 + Math.random() * 1.8, v: .15 + Math.random() * .55, f: .5 + Math.random() * 1.5, ph: Math.random() * 6.283, a: .25 + Math.random() * .5, life: 0 }; }
  requestAnimationFrame(fxFrame);
  // live countdown — one ticker for every banner on screen
  setInterval(() => { document.querySelectorAll('[data-vz-live]').forEach(el => { const ms = Math.max(0, +el.dataset.vzLive - Date.now()); const d = Math.floor(ms / 864e5), h = Math.floor(ms / 36e5) % 24, m = Math.floor(ms / 6e4) % 60, s2 = Math.floor(ms / 1e3) % 60; [d, h, m, s2].forEach((n, k) => { const b = el.querySelector(`b[data-k="${k}"]`); const txt = k ? String(n).padStart(2, '0') : String(n); if (b && b.textContent !== txt) { b.textContent = txt; if (!RM) { b.classList.remove('vz-flip'); void b.offsetWidth; b.classList.add('vz-flip'); } } }); }); }, 1000);
  function dashCard() {
    const v = V(); if (!v.on || !v.dash || !v.date) return ''; const c = count(v);
    return `<div class="card vz-mini" data-act="vz-go" role="button" tabindex="0"><div class="vz-mimg" style="background-image:url('${esc(img(true))}')"></div><div class="vz-mtx"><div class="vz-tag">✦ COMING SOON</div><b><i>This is</i> ${esc(v.title)}</b><div class="small">${esc(v.label ? v.label + ' · ' : '')}${esc(dateTxt(v.date))}</div><div class="vz-mc">${c.left > 0 ? `<b>${c.left}</b> din baaki` : '<b>🎉</b> Aaj / poora!'}</div><div class="vz-bar sm"><i style="width:${(c.done * 100).toFixed(1)}%"></i></div><div class="small">${Math.round(c.done * 100)}% safar · is raftaar se <b>${short(pulse(v).proj)}</b></div><div class="small vz-q">${esc(line())}</div></div></div>`;
  }

  /* ---- hooks ---- */
  // Target 🎯 page (retailers + customers mission): the showroom as the "manzil" inside the hero
  function manzil() {
    const v = V(); if (!v.on || !v.date) return ''; const c = count(v);
    return `<div class="tg-vz"><button type="button" class="tg-vzp" data-act="vz-full" aria-label="Showroom ki poori photo"><img src="${esc(img(false))}" alt="${esc(v.title)} — ${esc(dateTxt(v.date))}" loading="lazy"><u></u><em>MANZIL</em></button>
      <div class="tg-vzt"><span class="tg-vzk">✦ Har party = ek eent</span><b><i>This is</i> ${esc(v.title)}</b><small>in ${esc(dateTxt(v.date))}${c.left > 0 ? ` · <strong>${c.left}</strong> din` : ''}</small><button type="button" class="link" data-act="vz-go">Showroom dekho →</button></div></div>`;
  }
  const withManzil = h => { try { const m = manzil(); if (!m || typeof h !== 'string' || h.indexOf('<div class="tg-hr">') < 0) return h; return h.replace('<div class="tg-hero">', '<div class="tg-hero has-vz">').replace('<div class="tg-hr">', m + '<div class="tg-hr">'); } catch (e) { console.error(e); return h; } };
  if (typeof VIEWDEF !== 'undefined' && VIEWDEF.target && typeof VIEWDEF.target.body === 'function') { const B0 = VIEWDEF.target.body; VIEWDEF.target.body = function () { return withManzil(B0.apply(this, arguments)); }; }
  if (typeof repGrowth === 'function') { const G0 = repGrowth; repGrowth = function () { return withManzil(G0.apply(this, arguments)); }; }
  if (typeof repTargets === 'function') { const R0 = repTargets; repTargets = function () { let b = ''; try { b = banner(); } catch (e) { console.error(e); } return b + R0.apply(this, arguments); }; }
  { const D = VIEWDEF.dashboard; if (D && D.body) VIEWDEF.dashboard = { ...D, body() { let x = ''; try { x = dashCard(); } catch (e) { console.error(e); } return x + D.body.apply(D, arguments); } }; }
  { const SU = VIEWDEF.setup; if (SU && SU.body) VIEWDEF.setup = { ...SU, body() { let x = ''; try { if (isOwner()) { const v = V(); x = `<div class="card"><div class="card-h"><h3>🏛️ ${esc(v.title)} · ${parseD(v.date).getFullYear()}</h3><button class="btn sm" data-act="vz-edit">Badlo</button></div><p class="small muted" style="margin:0">${v.on ? `${esc(v.title)} · ${esc(dateTxt(v.date))} — Targets tab${v.dash ? ', Dashboard' : ''}${v.login ? ' aur login screen' : ''} par dikhta hai.` : 'Abhi chhupa hua hai.'}</p></div>`; } } catch (e) { console.error(e); } return x + SU.body.apply(SU, arguments); } }; }
  const ACT = {
    'vz-go': () => goTo('reports', { rTab: 'targets' }),
    'vz-full': () => openModal(`${mHead('🎯 ' + esc(V().title), esc(dateTxt(V().date)))}<div class="m-body" style="padding:0"><img src="${esc(img(false))}" alt="${esc(V().title)}" style="display:block;width:100%;border-radius:0 0 16px 16px"></div>`, { wide: true }),
    'vz-edit': () => {
      const v = V();
      openModal(`<form data-vz="1" novalidate>${mHead('🏛️ ' + esc(DEF.title) + ' banner', 'Photo, naam aur tareekh — Targets, Dashboard aur login par')}<div class="m-body">
        <div class="vz-prev" style="background-image:url('${esc(img(true))}')"></div>
        <div class="fg"><label class="f"><span>Showroom ka naam</span><input name="title" value="${esc(v.title)}"></label><label class="f"><span>Chhoti line</span><input name="sub" value="${esc(v.sub)}"></label><label class="f"><span>Mauka</span><input name="label" value="${esc(v.label)}" placeholder="Dhanteras"></label><label class="f"><span>Udghatan ki tareekh</span><input type="date" name="date" value="${esc(v.date)}"></label><label class="f"><span>Safar shuru</span><input type="date" name="start" value="${esc(v.start)}"></label><label class="f"><span>Bikri ka lakshya ₹ (tab tak, chahein to)</span><input type="number" name="goal" min="0" step="100000" value="${esc(v.goal || '')}" placeholder="jaise 50000000"></label><label class="f"><span>Nayi photo (chahein to)</span><input type="file" name="photo" accept="image/*"></label></div>
        <label class="f"><span>Padaav — har line: tareekh | kaam (khaali = apne-aap)</span><textarea name="miles" rows="4" placeholder="2027-02-15 | Plan & naksha pakka">${esc((v.miles || []).map(m => m.d + ' | ' + m.n).join('\n'))}</textarea></label>
        <label class="chk"><input type="checkbox" name="on" ${v.on ? 'checked' : ''}> Showroom banner dikhao</label><label class="chk"><input type="checkbox" name="dash" ${v.dash ? 'checked' : ''}> Dashboard par bhi</label><label class="chk"><input type="checkbox" name="login" ${v.login ? 'checked' : ''}> Login screen ke peeche</label>
        ${v.img ? '<label class="chk"><input type="checkbox" name="reset"> Wapas asli (showroom wali) photo</label>' : ''}</div>
        <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { small: true });
    }
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="vz-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);
  // keep the picked photo before the app's global file handler empties the input
  document.addEventListener('change', e => { const i = e.target; if (!i.matches || !i.matches('form[data-vz] input[name="photo"]')) return; e.stopPropagation(); i.closest('form')._file = i.files && i.files[0]; }, true);
  document.addEventListener('submit', async e => {
    const f = e.target; if (!f.matches || !f.matches('form[data-vz]')) return; e.preventDefault(); e.stopPropagation();
    const g = n => f.elements[n]; const v = V(); const nv = { ...((settings().pro || {}).vision || {}), title: g('title').value.trim() || DEF.title, sub: g('sub').value.trim(), label: g('label').value.trim(), date: g('date').value || DEF.date, start: g('start').value || v.start, on: g('on').checked, dash: g('dash').checked, login: g('login').checked };
    if (nv.start >= nv.date) return toast('Safar shuru udghatan ki tareekh se pehle hona chahiye', 'err');
    nv.goal = num(g('goal').value) || 0; const ml = String(g('miles').value || '').split('\n').map(l => l.trim()).filter(Boolean); const miles = [];
    for (const l of ml) { const m = l.match(/^(\d{4}-\d{2}-\d{2})\s*[|,-]\s*(.+)$/); if (!m) return toast('Padaav aise likhiye: 2027-02-15 | Plan pakka', 'err'); miles.push({ d: m[1], n: m[2].slice(0, 60) }); } nv.miles = miles;
    if (g('reset') && g('reset').checked) delete nv.img;
    if (f._file) { try { nv.img = await shrinkImage(f._file, 900, 'image/jpeg', 0.8); } catch (er) { return toast('Photo nahi padhi', 'err'); } }
    if (await saveSettings({ ...S.settings, pro: { ...((S.settings || {}).pro || {}), vision: nv } })) { try { localStorage.setItem('sjv_login', nv.on && nv.login && !nv.img ? '1' : '0'); } catch (er) { /* */ } closeModal(f.closest('.overlay')); toast('✓ Showroom save'); renderView(true); }
  }, true);
  try { const v = V(); localStorage.setItem('sjv_login', v.on && v.login && !v.img ? '1' : '0'); } catch (e) { /* */ }

  /* ---- login screen background (before login there is no data, so a local flag decides) ---- */
  { let on = true; try { on = localStorage.getItem('sjv_login') !== '0'; } catch (e) { /* */ }
    const st = document.createElement('style');
    st.textContent = `.vz-big{position:relative;border-radius:24px;overflow:hidden;margin-bottom:16px;border:1px solid rgba(242,214,138,.45);box-shadow:0 18px 44px rgba(0,0,0,.4);color:#fff6dc;isolation:isolate}
      .vz-img{position:absolute;inset:-40px;background-size:cover;background-position:center;filter:blur(26px) brightness(.5) saturate(1.25);z-index:-2}
      .vz-shade{position:absolute;inset:0;background:radial-gradient(120% 90% at 0% 0%,rgba(8,6,3,.92),rgba(8,6,3,.6) 60%,rgba(8,6,3,.35));z-index:-1}
      .vz-grid{display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,1.15fr) auto;gap:22px;padding:24px;align-items:stretch}
      .vz-a,.vz-b{display:flex;flex-direction:column;gap:10px;min-width:0}
      .vz-tag{display:inline-block;align-self:flex-start;font:700 11px/1 inherit;letter-spacing:2.5px;color:#1b1206;background:linear-gradient(90deg,#b98a2d,#f6dc8c,#c9a046);padding:6px 10px;border-radius:20px}
      .vz-hl{margin:2px 0 2px}.vz-this{display:block;font:italic 500 19px/1.1 'Playfair Display',Georgia,serif;color:#fff2c4;opacity:.9;letter-spacing:.5px}.vz-big h2{margin:2px 0 4px;font:800 42px/1.05 'Playfair Display',Georgia,serif;letter-spacing:.3px;background:linear-gradient(180deg,#fff4cc 0%,#f2d68a 45%,#c08a2c 100%);-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 3px 10px rgba(0,0,0,.55))}.vz-in{display:flex;align-items:center;gap:10px;font:italic 500 19px/1.2 'Playfair Display',Georgia,serif;color:#fff2c4}.vz-in b{font-style:normal;font-weight:700;color:#1b1206;background:linear-gradient(90deg,#b98a2d,#f6dc8c,#c9a046);padding:5px 14px;border-radius:10px;letter-spacing:.4px;box-shadow:0 4px 14px rgba(242,214,138,.25)}.vz-in:before{content:'';width:28px;height:1px;background:#f2d68a;opacity:.7}.vz-date{font-weight:600;font-size:13px;letter-spacing:.3px;color:#ffe9a8}.vz-date span{opacity:.5}.vz-date em{font-style:normal;opacity:.75;font-weight:500}
      .vz-live{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:4px}.vz-live div{position:relative;text-align:center;padding:10px 4px 8px;border-radius:14px;background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(0,0,0,.35));border:1px solid rgba(242,214,138,.35);box-shadow:inset 0 1px 0 rgba(255,255,255,.08)}
      .vz-live div:after{content:'';position:absolute;left:8px;right:8px;top:50%;height:1px;background:rgba(0,0,0,.35)}
      .vz-live b{display:block;font:700 34px/1.05 'Playfair Display',Georgia,serif;font-variant-numeric:tabular-nums;background:linear-gradient(180deg,#fff2c4,#e2b04a 60%,#a8741d);-webkit-background-clip:text;background-clip:text;color:transparent}.vz-live span{font-size:10px;letter-spacing:2px;opacity:.75}
      .vz-live div:first-child b{font-size:40px}.vz-cal{font-size:12px;opacity:.8}.vz-done{font:700 22px 'Playfair Display',Georgia,serif;color:#f6dc8c}
      .vz-quote{margin-top:auto;font:italic 600 15px/1.4 'Playfair Display',Georgia,serif;color:#fff2c4;border-left:3px solid #c9a046;padding:4px 0 4px 10px}
      .vz-act{display:flex;gap:8px;flex-wrap:wrap}.vz-act .btn{background:rgba(0,0,0,.45);color:#f6dc8c;border-color:rgba(242,214,138,.45)}
      .vz-ringrow{display:flex;gap:16px;align-items:center}.vz-ring{position:relative;flex:none;width:132px;height:132px}.vz-ring svg{width:100%;height:100%;transform:rotate(-90deg)}.vz-ring circle{fill:none;stroke-width:11}.vz-ring .bg{stroke:rgba(255,255,255,.12)}.vz-ring .fg{stroke:url(#vzg);stroke-linecap:round;filter:drop-shadow(0 0 6px rgba(242,214,138,.5))}
      .vz-ring div{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center}.vz-ring b{font:700 30px/1 'Playfair Display',Georgia,serif;color:#f6dc8c}.vz-ring span{font-size:11px;opacity:.75}
      .vz-kp{display:grid;gap:8px;flex:1;min-width:0}.vz-kp div{background:rgba(0,0,0,.35);border:1px solid rgba(242,214,138,.22);border-radius:12px;padding:7px 10px}.vz-kp span{display:block;font-size:11px;opacity:.72}.vz-kp b{font-size:17px}.vz-kp b.gold{color:#f6dc8c}
      .vz-goal{background:rgba(0,0,0,.35);border:1px solid rgba(242,214,138,.22);border-radius:12px;padding:9px 12px}.vz-gh,.vz-gf{display:flex;justify-content:space-between;gap:8px;font-size:12px}.vz-gh b.up{color:#5be39a}.vz-gh b.dn{color:#ffb070}.vz-gf{opacity:.85;margin-top:2px}
      .vz-bar{position:relative;height:10px;border-radius:8px;background:rgba(255,255,255,.14);overflow:visible;margin-top:6px}.vz-bar.sm{height:7px;margin:6px 0 4px;overflow:hidden}.vz-bar i{display:block;height:100%;border-radius:8px;background:linear-gradient(90deg,#b98a2d,#f6dc8c)}.vz-bar em{position:absolute;top:-4px;width:2px;height:18px;background:#fff;opacity:.8;border-radius:2px}
      .vz-setgoal{background:rgba(0,0,0,.3);border:1px dashed rgba(242,214,138,.5);color:#f6dc8c;border-radius:12px;padding:10px;font:600 12.5px inherit;cursor:pointer;text-align:left}
      .vz-tl{position:relative;height:26px;margin:10px 8px 0}.vz-line{position:absolute;left:0;right:0;top:11px;height:4px;border-radius:4px;background:rgba(255,255,255,.15)}.vz-line i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,#b98a2d,#f6dc8c)}.vz-line u{position:absolute;top:-7px;width:18px;height:18px;margin-left:-9px;border-radius:50%;background:#fff2c4;box-shadow:0 0 0 4px rgba(242,214,138,.3),0 0 14px #f2d68a;text-decoration:none;animation:vzp 2s ease-in-out infinite}
      @keyframes vzp{50%{box-shadow:0 0 0 8px rgba(242,214,138,.12),0 0 18px #f2d68a}}
      .vz-ms{position:absolute;top:5px;margin-left:-8px}.vz-ms i{display:block;width:16px;height:16px;border-radius:50%;border:2px solid #f2d68a;background:#1a1309}.vz-ms.on i{background:#f2d68a}.vz-ms.last i{width:20px;height:20px;margin:-2px;background:linear-gradient(135deg,#fff2c4,#c9a046);box-shadow:0 0 12px #f2d68a}
      .vz-mlist{display:grid;grid-template-columns:1fr;gap:7px}.vz-mlist div{display:flex;gap:8px;align-items:center;font-size:12.5px;min-width:0}.vz-mlist i{flex:none;display:grid;place-items:center;width:22px;height:22px;border-radius:50%;border:1.5px solid rgba(242,214,138,.6);font:700 11px inherit;font-style:normal;color:#f6dc8c}.vz-mlist div.on i{background:#f2d68a;color:#1b1206}.vz-mlist span{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.vz-mlist small{opacity:.65;flex:none}
      .vz-photo{position:relative;display:block;padding:0;border:0;background:none;cursor:zoom-in;align-self:center}.vz-photo img{display:block;height:470px;width:auto;max-width:none;border-radius:18px;border:2px solid rgba(242,214,138,.75);box-shadow:0 16px 36px rgba(0,0,0,.6),0 0 34px rgba(242,214,138,.2)}
      .vz-photo span{position:absolute;left:50%;bottom:-11px;transform:translateX(-50%);white-space:nowrap;font:700 11px inherit;letter-spacing:1.5px;color:#1b1206;background:linear-gradient(90deg,#b98a2d,#f6dc8c,#c9a046);padding:5px 12px;border-radius:20px;box-shadow:0 4px 12px rgba(0,0,0,.4)}
      @media(max-width:1180px){.vz-grid{grid-template-columns:minmax(0,1fr) auto}.vz-b{grid-column:1/-1;grid-row:2}.vz-photo img{height:420px}}
      @media(max-width:640px){.vz-grid{grid-template-columns:minmax(0,1fr);padding:16px;gap:16px}.vz-photo{grid-row:1;justify-self:center}.vz-photo img{height:auto;max-height:min(64vh,520px);width:auto;max-width:100%}.vz-a{grid-row:2}.vz-b{grid-row:3}.vz-big h2{font-size:32px}.vz-this,.vz-in{font-size:16px}.vz-live b{font-size:28px}.vz-live div:first-child b{font-size:32px}.vz-ring{width:112px;height:112px}.vz-ring b{font-size:24px}.vz-mlist{grid-template-columns:1fr}}
      .vz-fx{position:absolute;inset:0;z-index:0;pointer-events:none}.vz-grid{position:relative;z-index:1}
      .vz-rays{position:absolute;right:-8%;top:50%;width:780px;height:780px;margin-top:-390px;z-index:-1;pointer-events:none;background:repeating-conic-gradient(from 0deg,rgba(255,220,140,.10) 0deg 6deg,transparent 6deg 18deg);-webkit-mask:radial-gradient(circle,#000 0,rgba(0,0,0,.6) 30%,transparent 68%);mask:radial-gradient(circle,#000 0,rgba(0,0,0,.6) 30%,transparent 68%);animation:vzspin 60s linear infinite}
      @keyframes vzspin{to{transform:rotate(360deg)}}
      .vz-big h2{background:linear-gradient(110deg,#b07a22 0%,#f2d68a 30%,#fffbea 46%,#f2d68a 60%,#b07a22 100%);background-size:260% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:vzsh 5s ease-in-out infinite}
      @keyframes vzsh{0%{background-position:100% 0}60%,100%{background-position:0 0}}
      .vz-shine{position:relative;overflow:hidden}.vz-shine:after{content:'';position:absolute;top:0;bottom:0;left:-60%;width:40%;background:linear-gradient(100deg,transparent,rgba(255,255,255,.75),transparent);transform:skewX(-20deg);animation:vzswp 4.5s ease-in-out infinite}
      .vz-in b.vz-shine:after{animation-delay:1.2s}@keyframes vzswp{0%,55%{left:-60%}85%,100%{left:130%}}
      .vz-a>*,.vz-b>*{animation:vzup .8s cubic-bezier(.2,.8,.2,1) both}
      .vz-a>:nth-child(1){animation-delay:.05s}.vz-a>:nth-child(2){animation-delay:.18s}.vz-a>:nth-child(3){animation-delay:.32s}.vz-a>:nth-child(4){animation-delay:.45s}.vz-a>:nth-child(5){animation-delay:.58s}.vz-a>:nth-child(6){animation-delay:.7s}.vz-a>:nth-child(7){animation-delay:.82s}
      .vz-b>:nth-child(1){animation-delay:.35s}.vz-b>:nth-child(2){animation-delay:.5s}.vz-b>:nth-child(3){animation-delay:.65s}.vz-b>:nth-child(4){animation-delay:.8s}
      @keyframes vzup{from{opacity:0;transform:translateY(18px);filter:blur(4px)}to{opacity:1;transform:none;filter:none}}
      .vz-this{animation:vzfade 1s .2s both}.vz-in{animation:vzslide .9s .55s both}@keyframes vzfade{from{opacity:0;letter-spacing:6px}}@keyframes vzslide{from{opacity:0;transform:translateX(-24px)}}
      .vz-live div{overflow:hidden}.vz-live b.vz-flip{animation:vzflip .45s cubic-bezier(.3,1.4,.5,1)}@keyframes vzflip{from{transform:translateY(-60%) rotateX(70deg);opacity:0}to{transform:none;opacity:1}}
      .vz-live div{animation:vzglow 3s ease-in-out infinite}.vz-live div:nth-child(4){animation-duration:1s}@keyframes vzglow{50%{border-color:rgba(242,214,138,.7);box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 0 18px rgba(242,214,138,.18)}}
      .vz-ring .fg{stroke-dasharray:var(--L);animation:vzring 1.8s cubic-bezier(.2,.8,.2,1) .3s both}@keyframes vzring{from{stroke-dashoffset:var(--L)}to{stroke-dashoffset:var(--o)}}
      .vz-ring .orb{fill:none;stroke:rgba(242,214,138,.45);stroke-width:1.2;stroke-dasharray:2 7;transform-origin:64px 64px;animation:vzspin 24s linear infinite}
      .vz-ring:before{content:'';position:absolute;inset:14px;border-radius:50%;background:radial-gradient(circle,rgba(242,214,138,.22),transparent 70%);animation:vzbreath 3s ease-in-out infinite}@keyframes vzbreath{50%{transform:scale(1.12);opacity:.6}}
      .vz-line i{animation:vzgrow 1.6s cubic-bezier(.2,.8,.2,1) .7s both;transform-origin:left}@keyframes vzgrow{from{transform:scaleX(0)}}
      .vz-ms i{animation:vzpop .5s cubic-bezier(.3,1.6,.5,1) both}.vz-ms:nth-of-type(2) i{animation-delay:.9s}.vz-ms:nth-of-type(3) i{animation-delay:1.05s}.vz-ms:nth-of-type(4) i{animation-delay:1.2s}.vz-ms:nth-of-type(5) i{animation-delay:1.35s}.vz-ms:nth-of-type(6) i{animation-delay:1.5s}@keyframes vzpop{from{transform:scale(0)}}
      .vz-ms.last i{animation:vzpop .5s 1.5s both,vzbeat 1.6s 2s ease-in-out infinite}@keyframes vzbeat{50%{box-shadow:0 0 0 7px rgba(242,214,138,.15),0 0 22px #f2d68a}}
      .vz-photo{animation:vzin 1.1s cubic-bezier(.2,.8,.2,1) .15s both}@keyframes vzin{from{opacity:0;transform:translateY(30px) scale(.94)}}
      .vz-pf{position:relative;display:block;overflow:hidden;border-radius:18px;animation:vzfloat 6s ease-in-out 1.3s infinite}@keyframes vzfloat{50%{transform:translateY(-7px)}}
      .vz-pf img{animation:vzkb 16s ease-in-out infinite alternate;transform-origin:50% 30%}@keyframes vzkb{to{transform:scale(1.07)}}
      .vz-glare{position:absolute;inset:0;pointer-events:none;background:linear-gradient(115deg,transparent 35%,rgba(255,250,225,.38) 48%,transparent 60%);background-size:300% 100%;animation:vzgl 6s ease-in-out infinite;text-decoration:none}@keyframes vzgl{0%,50%{background-position:120% 0}90%,100%{background-position:-60% 0}}
      .vz-photo:before{content:'';position:absolute;inset:-14px;border-radius:26px;background:conic-gradient(from 0deg,transparent,rgba(242,214,138,.55),transparent 30%,transparent 50%,rgba(242,214,138,.55),transparent 80%);filter:blur(10px);z-index:-1;animation:vzspin 9s linear infinite;opacity:.8}
      .vz-photo{isolation:isolate}.vz-photo span{z-index:2}
      .vz-mini .vz-mtx b{background:linear-gradient(110deg,#b07a22,#f2d68a 35%,#fffbea 48%,#f2d68a 62%,#b07a22);background-size:260% 100%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:vzsh 5s ease-in-out infinite}
      .vz-mimg{position:relative;overflow:hidden}.vz-mimg:after{content:'';position:absolute;inset:0;background:linear-gradient(115deg,transparent 35%,rgba(255,250,225,.4) 48%,transparent 60%);background-size:300% 100%;animation:vzgl 6s ease-in-out infinite}
      @media(max-width:640px){.vz-rays{right:auto;left:50%;top:0;margin:-200px 0 0 -390px}}
      @media(prefers-reduced-motion:reduce){.vz-big *,.vz-big *:before,.vz-big *:after,.vz-mini *,.vz-mini *:after,.vz-rays{animation:none!important}.vz-fx{display:none}}.tg-hero.has-vz{grid-template-columns:minmax(0,1.5fr) auto minmax(0,1fr)}
      .tg-vz{display:flex;flex-direction:column;align-items:center;gap:10px;align-self:stretch;justify-content:center}
      .tg-vzp{position:relative;display:block;padding:0;border:0;background:none;cursor:zoom-in;border-radius:16px;overflow:hidden;box-shadow:0 0 0 1.5px rgba(242,214,138,.7),0 14px 30px rgba(0,0,0,.45),0 0 26px rgba(242,214,138,.18);animation:vzfloat 6s ease-in-out infinite}
      .tg-vzp img{display:block;height:230px;width:auto;animation:vzkb 16s ease-in-out infinite alternate;transform-origin:50% 30%}
      .tg-vzp u{position:absolute;inset:0;background:linear-gradient(115deg,transparent 35%,rgba(255,250,225,.4) 48%,transparent 60%);background-size:300% 100%;animation:vzgl 6s ease-in-out infinite}
      .tg-vzp em{position:absolute;left:50%;bottom:8px;transform:translateX(-50%);font:700 10px/1 inherit;font-style:normal;letter-spacing:2.5px;color:#1b1206;background:linear-gradient(90deg,#b98a2d,#f6dc8c,#c9a046);padding:5px 10px;border-radius:20px;box-shadow:0 3px 10px rgba(0,0,0,.4)}
      .tg-vzt{display:flex;flex-direction:column;align-items:center;text-align:center;gap:2px;max-width:240px}.tg-vzk{font-size:10.5px;letter-spacing:1.5px;color:var(--gold,#d8b45a);font-weight:700;text-transform:uppercase}
      .tg-vzt b{font:700 15px/1.25 'Playfair Display',Georgia,serif;color:var(--head)}.tg-vzt b i{font-weight:500;opacity:.8}.tg-vzt small{font-size:12px;color:var(--muted)}.tg-vzt small strong{color:var(--gold,#d8b45a)}.tg-vzt .link{font-size:12px;font-weight:700;margin-top:2px}
      @media(max-width:1180px){.tg-hero.has-vz{grid-template-columns:minmax(0,1fr) auto}.tg-hero.has-vz .tg-vz{grid-column:2;grid-row:1}.tg-hero.has-vz .tg-hr{grid-column:1/-1;grid-row:2}}
      @media(max-width:760px){.tg-hero.has-vz{grid-template-columns:1fr}.tg-hero.has-vz .tg-vz{grid-column:auto;grid-row:auto;order:3;flex-direction:row;justify-content:flex-start;gap:14px;padding:10px;border:1px solid var(--gold-line,var(--line));border-radius:18px;background:rgba(242,214,138,.05)}.tg-hero.has-vz .tg-hr{grid-column:auto;grid-row:auto}.tg-vzp img{height:150px}.tg-vzt{align-items:flex-start;text-align:left;max-width:none;flex:1;min-width:0}}
      @media(prefers-reduced-motion:reduce){.tg-vzp,.tg-vzp img,.tg-vzp u{animation:none!important}}.vz-mtx b i{font-weight:500;font-family:'Playfair Display',Georgia,serif;opacity:.85}.vz-mini{display:flex;gap:0;padding:0;overflow:hidden;cursor:pointer;border-color:rgba(242,214,138,.45)}.vz-mimg{flex:none;width:96px;background-color:#0d0b07;background-size:contain;background-repeat:no-repeat;background-position:center;border-right:1px solid rgba(242,214,138,.3)}.vz-mini{min-height:228px}.vz-mtx{padding:12px 14px;min-width:0;flex:1}.vz-mtx .vz-tag{font-size:9.5px;padding:4px 8px}.vz-mtx b{display:block;margin-top:6px;font:700 16px 'Playfair Display',Georgia,serif;color:var(--gold,#c9a046)}.vz-mc b{display:inline;font:700 26px 'Playfair Display',Georgia,serif;margin:0;color:var(--gold,#c9a046)}
      .vz-prev{height:220px;border-radius:12px;background-color:#0d0b07;background-size:contain;background-repeat:no-repeat;background-position:center;margin-bottom:10px}
      ${on ? `html .sjw-ov:not(.dim),html[data-theme] .sjw-ov:not(.dim){background:linear-gradient(180deg,rgba(6,5,3,.55),rgba(6,5,3,.88)),url('vision-shop.jpg') center top/cover no-repeat,#070605!important}@media(min-aspect-ratio:3/4){html .sjw-ov:not(.dim),html[data-theme] .sjw-ov:not(.dim){background:linear-gradient(180deg,rgba(6,5,3,.45),rgba(6,5,3,.8)),url('vision-shop.jpg') center/contain no-repeat,#070605!important}}.sjw-ov:not(.dim) .sjw-box{background:rgba(19,15,8,.82);backdrop-filter:blur(6px)}` : ''}`;
    document.head.appendChild(st);
  }

  /* ---- AI knows the dream ---- */
  if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { let x = ''; try { const v = V(), c = count(v); if (v.on) x = `\nSHIVAA'S SHOWROOM (owner's confirmed plan — call it a reality/plan, never a 'dream'/'sapna'): "${v.title}" by ${v.label ? v.label + ' ' : ''}${v.date} — ${c.left} days left (${c.months} months ${c.days} days). Sales since ${v.start}: ₹${Math.round(salesSince(v.start))}. When the owner asks about the dream / target date / motivation, use this and stay encouraging; it is shown in Reports → Targets.`; } catch (e) { /* */ } return R0.apply(this, arguments) + x; }; }
  window.SJ_VISION = { V, count };
})();
