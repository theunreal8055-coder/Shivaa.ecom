/* =====================================================================
   Shivaa Jewels — v28 pack
   11 Gift voucher        — sell, gift card PDF, redeem on any bill, balance, expiry
   12 Google review       — ask after every retail bill, dashboard list of who is left
   13 Refer & reward      — customer code, new-customer chhoot, referrer gets a voucher
   16 Gehne ka QR page    — public page per piece, display-card PDF, QR cards sheet
   18 AI KYC              — Aadhaar / PAN photo fills the customer form
   19 Stock insurance     — policies vs stock value, expiry alerts
   24 Shaadi package      — full wedding list, budget, advance, estimate, delivery
   27 Staff target        — monthly / daily sales target per staff with progress
   44 Size record         — ring / bangle / chain sizes per customer
   (41 Mera Locker is on the customer portal — sj-api.php)
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { name: 'Owner', role: 'owner' };
  const role = () => me().role || 'owner';
  const isOwner = () => !SITE || role() === 'owner';
  const canAdmin = () => !SITE || ['owner', 'manager'].includes(role());
  const canEdit = () => role() !== 'viewer';
  const q$ = (s, r) => (r || document).querySelector(s);
  const F = (label, inner, cls) => `<label class="f${cls ? ' ' + cls : ''}"><span>${label}</span>${inner}</label>`;
  const inp = (name, v, o = {}) => `<input name="${name}"${o.type ? ` type="${o.type}"` : ''}${o.step ? ` step="${o.step}"` : ''}${o.min != null ? ` min="${o.min}"` : ''}${o.max != null ? ` max="${o.max}"` : ''}${o.ph ? ` placeholder="${esc(o.ph)}"` : ''}${o.im ? ` inputmode="${o.im}"` : ''}${o.list ? ` list="${o.list}"` : ''}${o.req ? ' required' : ''}${o.ro ? ' readonly' : ''} value="${esc(v == null ? '' : v)}">`;
  const sel = (name, list, v) => `<select name="${name}">${opts(list, v)}</select>`;
  const tabs = (k, arr) => `<div class="rep-tabs">${arr.map(([v, l]) => `<button type="button" data-act="seg" data-k="${k}" data-v="${v}" class="${(ui[k] || arr[0][0]) === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  const kpis = arr => `<div class="kpis">${arr.map(([l, v, s]) => kpi(esc(l), v, s || '')).join('')}</div>`;
  const formVals = f => { const o = {}; [...f.elements].forEach(e => { if (e.name) o[e.name] = e.type === 'checkbox' ? e.checked : e.value; }); return o; };
  const ph10 = p => String(p || '').replace(/\D/g, '').slice(-10);
  const waUrl = (ph, msg) => { const d = ph10(ph); return d.length === 10 ? `https://wa.me/91${d}${msg ? '?text=' + encodeURIComponent(msg) : ''}` : ''; };
  const nextNo = (col, pre) => { let mx = 0; (S[col] || []).forEach(x => { if (x.no && x.no.startsWith(pre)) mx = Math.max(mx, parseInt(x.no.slice(pre.length)) || 0); }); return pre + String(mx + 1).padStart(4, '0'); };
  const firm = () => settings().firm || 'Shivaa Jewels';
  const css = document.createElement('style'); document.head.appendChild(css); const addCss = t => { css.textContent += t; };
  ['vouchers', 'weddings'].forEach(c => { if (typeof COLS !== 'undefined' && !COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  try { NON_MONEY.add('Gift voucher'); } catch (e) { /* */ }
  const ACT = {};
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act]'); if (!t) return; const h = ACT[t.dataset.act]; if (!h) return;
    e.preventDefault(); e.stopPropagation(); if (t.disabled) return;
    try { await h(t, e); } catch (err) { console.error(err); toast(err && err.message ? err.message : 'Kuch galat hua — dobara try kijiye', 'err'); }
  }, true);
  const SUBMIT = {};
  document.addEventListener('submit', async e => { const f = e.target; const k = f && f.dataset && f.dataset.sjy; if (!k || !SUBMIT[k]) return; e.preventDefault(); e.stopPropagation(); const b = f.querySelector('button.primary'); if (b) b.disabled = true; try { await SUBMIT[k](f); } catch (err) { console.error(err); toast(err.message || 'Save nahi hua', 'err'); } finally { if (b) b.disabled = false; } }, true);
  const pro = () => (settings().pro || {});
  const savePro = async patch => saveSettings({ ...S.settings, pro: { ...((S.settings || {}).pro || {}), ...patch } });
  const tunchOf = p => { const s = String(p || '').toUpperCase(); const m = { '24K': 99.9, '23K': 95.8, '22K': 91.6, '20K': 83.3, '18K': 75, '14K': 58.5, '9K': 37.5 }; if (m[s]) return m[s]; const n = parseFloat(s); return n > 0 && n <= 100 ? n : 91.6; };
  const isSilver = (purity, metal) => /silver|chandi/i.test(String(metal || '')) || /silver|^92\.?5$|^925$|^80$|^70$|^999 ?s/i.test(String(purity || '').trim());
  const rateFine = silver => silver ? num(settings().silver999) / 1000 : num(settings().gold24) / 10;   // ₹ per fine gram
  const custList = () => S.customers.slice().sort((a, b) => String(a.name).localeCompare(String(b.name))).map(c => [c.id, c.name + (c.phone ? ' · ' + c.phone : '')]);
  const randCode = (n) => { const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; const b = new Uint8Array(n); crypto.getRandomValues(b); return [...b].map(x => A[x % A.length]).join(''); };
  async function moneyIn(date, amount, mode, party, notes, ref) {   // a receipt in Bank & cash, so the day book and cash book see it
    if (!(num(amount) > 0)) return '';
    const cash = !mode || mode === 'Cash'; const bank = cash ? '' : ((banksList().find(b => b.primary) || banksList()[0]) || {}).id;
    if (!cash && !bank) throw new Error('UPI / bank se paisa — pehle Setup mein bank account jodiye (ya Cash chuniye)');
    const x = { id: uid('bt'), kind: cash ? 'cashin' : 'receipt', date, amount: r2(num(amount)), bankId: bank || '', toBankId: '', source: 'Advance from customer', purpose: '', party: party || '', ref: ref || '', notes: notes || '', createdAt: Date.now(), updatedAt: Date.now() };
    if (!await save('banktx', x, { quiet: true })) throw new Error('Paisa ki entry save nahi hui');
    return x.id;
  }

  /* =====================================================================
     44. SIZE RECORD
     ===================================================================== */
  const SIZE_F = [['ring', 'Anguthi (Indian size)', '14'], ['ring2', 'Doosri ungli', ''], ['bangle', 'Kangan / chudi', '2.6'], ['bracelet', 'Bracelet (inch)', '7'], ['chain', 'Chain lambai (inch)', '18'], ['waist', 'Kamarbandh (inch)', ''], ['toe', 'Bichhiya', ''], ['note', 'Note', 'jaise: dahine haath mein pehnti hain']];
  const sizeTxt = c => { const z = (c && c.sizes) || {}; return [['ring', 'Anguthi'], ['ring2', 'Doosri'], ['bangle', 'Kangan'], ['bracelet', 'Bracelet'], ['chain', 'Chain'], ['waist', 'Kamar'], ['toe', 'Bichhiya']].filter(([k]) => z[k]).map(([k, l]) => `${l} ${z[k]}`).join(' · '); };
  function sizeCard(c) {
    const z = c.sizes || {}; const t = sizeTxt(c);
    return `<div class="card sjy-size"><div class="card-h"><h3>📏 Size</h3>${canEdit() ? `<button class="btn sm" data-act="sjy-size-edit" data-id="${esc(c.id)}">${t ? 'Badlo' : '+ Size likho'}</button>` : ''}</div>${t ? `<div class="sjy-chips">${t.split(' · ').map(x => `<span class="pill">${esc(x)}</span>`).join('')}</div>${z.note ? `<div class="small muted" style="margin-top:6px">${esc(z.note)}</div>` : ''}${z.updatedAt ? `<div class="small muted">Aakhri badlav ${fmtD(new Date(z.updatedAt).toISOString().slice(0, 10))}</div>` : ''}` : '<p class="small muted" style="margin:0">Anguthi, kangan, chain ka size likh lijiye — agli baar ya gift dene wale ko turant pata rahega.</p>'}</div>`;
  }
  ACT['sjy-size-edit'] = t => {
    const c = S.customers.find(x => x.id === t.dataset.id); if (!c) return; const z = c.sizes || {};
    openModal(`<form data-sjy="size" data-id="${esc(c.id)}" novalidate>${mHead('📏 Size — ' + esc(c.name), 'Indian ring size 1–30 · kangan 2.2 / 2.4 / 2.6 / 2.8')}<div class="m-body"><div class="fg">${SIZE_F.map(([k, l, ph]) => F(l, inp(k, z[k] || '', { ph }))).join('')}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { small: true });
  };
  SUBMIT.size = async f => { const c = S.customers.find(x => x.id === f.dataset.id); const v = formVals(f); const z = {}; SIZE_F.forEach(([k]) => { const s = String(v[k] || '').trim().slice(0, 60); if (s) z[k] = s; }); z.updatedAt = Date.now(); if (await save('customers', { ...c, sizes: z, updatedAt: Date.now() })) { closeModal(f.closest('.overlay')); toast('✓ Size save'); renderView(); } };

  /* =====================================================================
     13. REFERRAL — code, chhoot for the new customer, voucher for the referrer
     ===================================================================== */
  const refCfg = () => ({ reward: 500, newPct: 5, months: 12, on: true, ...(pro().referral || {}) });
  function refCodeFor(c) { const p = ph10(c.phone).slice(-4) || '0000'; let h = 7; String(c.id).split('').forEach(ch => { h = (h * 33 + ch.charCodeAt(0)) >>> 0; }); return 'SJR' + p + h.toString(36).toUpperCase().slice(-2).padStart(2, 'X'); }
  async function ensureRefCode(c) { if (!c || c.refCode) return c; const c2 = { ...c, refCode: refCodeFor(c), updatedAt: Date.now() }; return (await save('customers', c2, { quiet: true })) ? c2 : c; }
  const retailBills = (cid, except) => S.invoices.filter(v => v.partyId === cid && v.id !== except && !v.deleted && (v.type === 'sale' || v.type === 'estimate'));
  const refMsg = c => `Namaste 🙏 Main ${firm()} se gehne leta/leti hoon — bahut achha kaam hai. Aap bhi wahan jaiye aur billing par mera code *${c.refCode}* bataiye${refCfg().newPct ? ` — pehli kharid par making mein ${refCfg().newPct}% extra chhoot milegi` : ''}. 💛`;
  function referralCard(c) {
    if (!refCfg().on) return '';
    const by = c.referredBy ? S.customers.find(x => x.id === c.referredBy) : null; const n = S.customers.filter(x => x.referredBy === c.id).length; const vs = (S.vouchers || []).filter(v => v.customerId === c.id && v.source === 'referral');
    return `<div class="card sjy-ref"><div class="card-h"><h3>🤝 Referral</h3></div>${c.refCode ? `<div>Code: <b class="mono" style="font-size:17px;letter-spacing:1px">${esc(c.refCode)}</b> <button class="btn sm" data-act="sjy-ref-share" data-id="${esc(c.id)}">WhatsApp par bhejo</button></div>` : `<button class="btn sm gold" data-act="sjy-ref-make" data-id="${esc(c.id)}">Referral code banao</button>`}<div class="small muted" style="margin-top:6px">${n ? `${n} naye grahak laaye · inaam ${inr(sum(vs, v => v.amount))}` : 'Abhi kisi ko nahi laaye'}${by ? ` · inhe ${esc(by.name)} laaye` : ''}</div></div>`;
  }
  ACT['sjy-ref-make'] = async t => { const c = S.customers.find(x => x.id === t.dataset.id); await ensureRefCode(c); toast('✓ Code ban gaya'); renderView(); };
  ACT['sjy-ref-share'] = t => { const c = S.customers.find(x => x.id === t.dataset.id); const u = waUrl(c.phone, refMsg(c)); if (u) window.open(u, '_blank', 'noopener'); else toast('Customer ka phone nahi hai', 'err'); };
  // ---- bill builder banner ----
  function invRetail() { if (!INV || (INV.type !== 'sale' && INV.type !== 'estimate')) return false; const p = invParty(); return INV.channel ? INV.channel === 'retail' : (p ? chanOfParty(p) === 'retail' : false); }
  function makingOf(items, type) { return window.SJX_2051 ? SJX_2051.makingOf(items, type) : 0; }
  function refBanner() {
    if (!INV || !INV.el) return; const box = q$('#inv-party', INV.el); let b = q$('#sjy-ref', INV.el); const p = invParty();
    const ok = p && refCfg().on && invRetail() && !p.referredBy && !retailBills(p.id, INV.orig && INV.orig.id).length && !(INV.orig && INV.orig.referral);
    if (!ok) { if (b) b.remove(); if (INV.referral && !INV.referral.locked) INV.referral = null; return; }
    if (!b) { b = document.createElement('div'); b.id = 'sjy-ref'; (q$('#sjx-priv', INV.el) || box).insertAdjacentElement('afterend', b); }
    const r = INV.referral; const by = r ? S.customers.find(x => x.id === r.by) : null; const amt = r ? Math.round(makingOf(INV.items, INV.type) * refCfg().newPct / 100) : 0;
    b.className = 'sjy-refb' + (r ? ' on' : '');
    b.innerHTML = r ? `<div><b>🤝 ${esc(by ? by.name : '')} ke referral se</b> <span class="mono small">${esc(r.code)}</span><div class="small muted">Naye grahak ko making par ${refCfg().newPct}% chhoot · ${esc(by ? by.name : '')} ko ${inr(refCfg().reward)} ka gift voucher milega</div></div><div class="right">${refCfg().newPct ? `<b class="green">− ${inr(amt)}</b>` : ''}<div><button type="button" class="btn sm" data-act="sjy-ref-clear">Hatao</button></div></div>`
      : `<div><b>🤝 Naya grahak — kisi ne bheja?</b><div class="small muted">Referral code daaliye (jaise SJR1234AB) ya bhejne wale ka phone</div></div><div class="right sjy-refin"><input id="sjy-ref-code" placeholder="Code / phone" autocomplete="off"><button type="button" class="btn sm gold" data-act="sjy-ref-apply">Lagao</button></div>`;
  }
  function refApplyDisc() { if (!INV || !INV.referral || !refCfg().newPct || !invRetail()) return; if (INV.privilege && INV.privilege.on) return; const amt = Math.round(makingOf(INV.items, INV.type) * refCfg().newPct / 100); INV.discMode = 'flat'; INV.discValue = amt || ''; const a = q$('[data-inv="discValue"]', INV.el), m = q$('[data-inv="discMode"]', INV.el); if (a) a.value = amt || ''; if (m) m.value = 'flat'; }
  ACT['sjy-ref-apply'] = () => {
    const v = String((q$('#sjy-ref-code') || {}).value || '').trim().toUpperCase(); if (!v) return toast('Code ya phone daaliye', 'err'); const p = invParty();
    const by = S.customers.find(c => (c.refCode && c.refCode === v) || (v.replace(/\D/g, '').length === 10 && ph10(c.phone) === ph10(v)));
    if (!by) return toast('Ye code / phone kisi customer ka nahi mila', 'err'); if (p && by.id === p.id) return toast('Grahak khud ko refer nahi kar sakta', 'err');
    if (!retailBills(by.id).length) return toast(by.name + ' ka abhi koi bill nahi — referral sirf purane grahak de sakte hain', 'err');
    INV.referral = { by: by.id, code: by.refCode || refCodeFor(by) }; refBanner(); refreshTotals();
  };
  ACT['sjy-ref-clear'] = () => { if (!INV) return; INV.referral = null; INV.discValue = ''; const a = q$('[data-inv="discValue"]', INV.el); if (a) a.value = ''; refBanner(); refreshTotals(); };

  /* ---- size line in the bill ---- */
  function sizeLine() { if (!INV || !INV.el) return; let b = q$('#sjy-szl', INV.el); const p = invParty(); const t = p && invRetail() ? sizeTxt(p) : ''; if (!t) { if (b) b.remove(); return; } if (!b) { b = document.createElement('div'); b.id = 'sjy-szl'; b.className = 'small muted'; q$('#inv-party', INV.el).insertAdjacentElement('afterend', b); } b.innerHTML = '📏 ' + esc(t); }
  if (typeof renderInvParty === 'function') { const R0 = renderInvParty; renderInvParty = function () { const r = R0.apply(this, arguments); try { sizeLine(); refBanner(); if (INV && INV.referral) refApplyDisc(); } catch (e) { console.error(e); } return r; }; }
  if (typeof refreshTotals === 'function') { const T0 = refreshTotals; let busy = false; refreshTotals = function () { if (!busy && INV && INV.el && INV.referral) { busy = true; try { refApplyDisc(); refBanner(); } catch (e) { console.error(e); } busy = false; } return T0.apply(this, arguments); }; }
  addCss(`.sjy-refb{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-top:10px;padding:10px 12px;border:1px dashed var(--gold,#c9a046);border-radius:12px}.sjy-refb.on{border-style:solid;background:rgba(60,207,122,.08)}.sjy-refb .right{text-align:right}.sjy-refin{display:flex;gap:6px;align-items:center}.sjy-refin input{max-width:150px}#sjy-szl{margin-top:6px}.sjy-chips{display:flex;flex-wrap:wrap;gap:6px}`);

  /* =====================================================================
     11. GIFT VOUCHER
     ===================================================================== */
  const vStatus = v => v.status === 'cancelled' ? 'cancelled' : num(v.balance) <= 0.5 ? 'used' : (v.expiry && v.expiry < todayStr()) ? 'expired' : 'active';
  async function newCode() { let c; do { c = 'GV-' + randCode(4) + '-' + randCode(4); } while ((S.vouchers || []).some(v => v.code === c)); return c; }
  async function issueVoucher(o) {
    const amt = r2(num(o.amount)); const c = o.customerId ? custById(o.customerId) : null;
    const v = { id: uid('gv'), code: await newCode(), amount: amt, balance: amt, customerId: c ? c.id : '', holderName: c ? c.name : (o.holderName || ''), holderPhone: c ? c.phone : (o.holderPhone || ''), buyerName: o.buyerName || '', buyerPhone: o.buyerPhone || '', issueDate: o.date || todayStr(), expiry: addDays(o.date || todayStr(), Math.round(30.4 * (num(o.months) || 12))), source: o.source || 'sold', mode: o.mode || '', note: o.note || '', redemptions: [], status: 'active', by: me().name || '', createdAt: Date.now(), updatedAt: Date.now() };
    if (v.source === 'sold') v.btxId = await moneyIn(v.issueDate, amt, o.mode, v.buyerName || v.holderName, 'Gift voucher ' + v.code + ' becha', v.code);
    if (!await save('vouchers', v)) throw new Error('Voucher save nahi hua'); return v;
  }
  async function giftCardPdf(v) {
    const K = window.SJ_BILLX && SJ_BILLX.kit; if (!K) throw new Error('Bill kit nahi mila');
    await SJ_BILLX.loadFonts(); const { SERIF, HIN, font, grad, rr, T, sheen, goldLogo, qrDraw, jpeg, DPI_K } = K;
    const W = 2008, H = 1240, k = DPI_K(); const cv = document.createElement('canvas'); cv.width = Math.round(W * k); cv.height = Math.round(H * k); const x = cv.getContext('2d'); x.scale(k, k);
    const g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#07060a'); g.addColorStop(0.5, '#1c140a'); g.addColorStop(1, '#2d1f0b'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.save(); x.globalAlpha = 0.07; x.strokeStyle = '#f2d68a'; x.lineWidth = 1.4; for (let q = -H; q < W; q += 24) { x.beginPath(); x.moveTo(q, H); x.lineTo(q + H * 0.6, 0); x.stroke(); } x.restore();
    x.lineWidth = 6; x.strokeStyle = grad(x, 0, 0, W, H); rr(x, 40, 40, W - 80, H - 80, 40); x.stroke(); x.lineWidth = 2; x.strokeStyle = 'rgba(242,214,138,.45)'; rr(x, 64, 64, W - 128, H - 128, 30); x.stroke();
    const logo = typeof SJ_LOGO !== 'undefined' ? await goldLogo(SJ_LOGO, 700) : null; if (logo) { const lh = 230, lw = lh * logo.width / logo.height; x.drawImage(logo, 130, 110, Math.min(lw, 560), lh); }
    T(x, 'GIFT VOUCHER', W - 130, 200, { align: 'right', size: 92, w: 700, fam: SERIF, color: '#f2d68a' }); T(x, 'उपहार वाउचर  ·  ' + firm(), W - 130, 262, { align: 'right', size: 32, fam: HIN, color: '#d8ccb0' });
    font(x, 700, 260, SERIF); x.textAlign = 'left'; x.save(); x.shadowColor = 'rgba(0,0,0,.7)'; x.shadowBlur = 20; x.shadowOffsetY = 8; x.fillStyle = sheen(x, 130, 420, 1100, 700); x.fillText('₹' + fmtAmt(v.amount), 130, 650); x.restore();
    T(x, v.source === 'referral' ? 'REFERRAL REWARD · DHANYAVAAD' : 'ANY JEWELLERY · KISI BHI GEHNE PAR', 140, 730, { size: 30, w: 700, color: '#d9b45a', ls: 4 });
    if (v.holderName) { T(x, 'FOR', 140, 850, { size: 26, w: 700, color: '#bfb08c', ls: 4 }); T(x, v.holderName, 140, 925, { size: 64, w: 700, fam: SERIF, color: '#fff4d6', maxW: 1150 }); }
    if (v.buyerName && v.buyerName !== v.holderName) T(x, 'With love from ' + v.buyerName, 140, 990, { size: 32, color: '#e9d7a5', maxW: 1150 });
    const qs = 330, qx = W - 130 - qs, qy = 380; rr(x, qx - 18, qy - 18, qs + 36, qs + 36, 24); x.fillStyle = '#fff'; x.fill(); const shop = ph10(settings().phone);
    qrDraw(x, shop.length === 10 ? `https://wa.me/91${shop}?text=${encodeURIComponent('Namaste! Mera gift voucher ' + v.code + ' hai — balance aur design batayein.')}` : v.code, qx, qy, qs, '#1a1206');
    T(x, 'Scan · WhatsApp', qx + qs / 2, qy + qs + 56, { align: 'center', size: 24, color: '#cdbb8f' });
    font(x, 700, 46); const cw = x.measureText(v.code).width + 110, cx0 = W - 130 - cw; rr(x, cx0, 880, cw, 92, 46); x.fillStyle = 'rgba(242,214,138,.12)'; x.fill(); x.lineWidth = 3; x.strokeStyle = '#d9b45a'; x.stroke(); T(x, v.code, cx0 + cw / 2, 942, { align: 'center', size: 46, w: 700, color: '#f6dc8c', ls: 3 });
    T(x, 'Valid till ' + fmtD(v.expiry) + '  ·  Issued ' + fmtD(v.issueDate), W - 130, 1030, { align: 'right', size: 26, color: '#cdbb8f' });
    T(x, 'Billing par code bataiye · bachi rakam agli baar · cash mein wapas nahi · kho jaye to dukaan ko turant bataiye', W / 2, H - 100, { align: 'center', size: 24, color: '#a89a78', maxW: W - 260 });
    const pdf = new Pdf(170, 105); pdf.pages.length = 0; pdf.addPage(); pdf.image(jpeg(cv, 0.96), 0, 0, 170, 105); return pdf.blob();
  }
  async function voucherForm(preset) {
    const c = refCfg();
    openModal(`<form data-sjy="gv" novalidate>${mHead('🎁 Gift voucher becho', 'Rakam lekar voucher banta hai — kisi bhi bill par chalega')}<div class="m-body"><div class="fg">
      ${F('Rakam ₹ *', inp('amount', (preset && preset.amount) || '', { type: 'number', step: '1', min: 1, im: 'numeric', req: 1 }))}${F('Kaise mila paisa', sel('mode', PAY_MODES, 'Cash'))}
      ${F('Kiske naam (customer list)', `<select name="customerId">${opts(custList(), '', '— naya / bina list —')}</select>`)}${F('Naam (list mein nahi to)', inp('holderName', ''))}${F('Phone', inp('holderPhone', '', { im: 'tel' }))}
      ${F('Kisne kharida (agar alag)', inp('buyerName', ''))}${F('Kharidne wale ka phone', inp('buyerPhone', '', { im: 'tel' }))}${F('Valid (mahine)', inp('months', c.months || 12, { type: 'number', min: 1, max: 36 }))}${F('Note', inp('note', ''))}</div>
      <p class="small muted" style="margin:10px 0 0">Ye paisa "Advance from customer" ke roop mein cash / bank book mein judega. Bill mein voucher lagane par wo bill ka jama ban jayega.</p></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Voucher banao</button></div></form>`, { small: true });
  }
  SUBMIT.gv = async f => {
    const v = formVals(f); if (!(num(v.amount) > 0)) return toast('Rakam daaliye', 'err'); if (!v.customerId && !String(v.holderName).trim()) return toast('Kiske naam ka voucher hai?', 'err');
    const g = await issueVoucher({ amount: v.amount, mode: v.mode, customerId: v.customerId, holderName: String(v.holderName).trim(), holderPhone: String(v.holderPhone).trim(), buyerName: String(v.buyerName).trim(), buyerPhone: String(v.buyerPhone).trim(), months: v.months, note: v.note, source: 'sold' });
    closeModal(f.closest('.overlay')); toast('✓ Voucher ' + g.code + ' ban gaya'); await offerDownload('gift_voucher_' + g.code + '.pdf', await giftCardPdf(g)); renderView();
  };
  ACT['sjy-gv-new'] = () => voucherForm();
  ACT['sjy-gv-pdf'] = async t => { const v = S.vouchers.find(x => x.id === t.dataset.id); await offerDownload('gift_voucher_' + v.code + '.pdf', await giftCardPdf(v)); };
  ACT['sjy-gv-wa'] = t => { const v = S.vouchers.find(x => x.id === t.dataset.id); const ph = v.holderPhone || (custById(v.customerId) || {}).phone || v.buyerPhone; const u = waUrl(ph, `Namaste ${v.holderName || ''} ji 🎁\n${firm()} ka gift voucher aapke liye:\nCode: *${v.code}*\nBalance: ${inr(v.balance)}\nValid: ${fmtD(v.expiry)} tak\nBilling par ye code bataiye. 💛`); if (u) window.open(u, '_blank', 'noopener'); else toast('Phone number nahi hai', 'err'); };
  ACT['sjy-gv-cancel'] = t => { const v = S.vouchers.find(x => x.id === t.dataset.id); confirmBox(`Voucher ${v.code} (balance ${inr(v.balance)}) cancel karein? Cancel ke baad ye kisi bill par nahi chalega. Paisa wapas dena ho to Bank & cash mein alag se entry kijiye.`, async () => { if (await save('vouchers', { ...v, status: 'cancelled', cancelledBy: me().name || '', updatedAt: Date.now() })) { toast('Cancel'); renderView(); } }, 'Cancel voucher'); };
  // ---- redeem on a bill ----
  async function redeemVoucher(inv, code) {
    code = String(code || '').trim().toUpperCase().replace(/\s/g, ''); if (/^GV[A-Z0-9]{8}$/.test(code)) code = 'GV-' + code.slice(2, 6) + '-' + code.slice(6);
    const g = (S.vouchers || []).find(v => v.code === code); if (!g) throw new Error('Ye voucher code nahi mila');
    const st = vStatus(g); if (st !== 'active') throw new Error({ used: 'Is voucher ka balance khatam ho chuka', expired: 'Voucher ki tareekh nikal gayi (' + fmtD(g.expiry) + ')', cancelled: 'Ye voucher cancel ho chuka hai' }[st]);
    const due = invDue(inv); if (!(due > 0.5)) throw new Error('Is bill mein kuch baaki nahi'); const use = r2(Math.min(num(g.balance), due));
    const pay = { id: uid('pay'), date: todayStr(), amount: use, fine: 0, mode: 'Gift voucher', note: g.code };
    if (!await save('invoices', { ...inv, payments: [...invPayments(inv), pay], updatedAt: Date.now() })) throw new Error('Bill save nahi hua');
    const bal = r2(num(g.balance) - use); await save('vouchers', { ...g, balance: bal, status: bal <= 0.5 ? 'used' : 'active', redemptions: [...(g.redemptions || []), { date: todayStr(), invId: inv.id, invNo: inv.no, amount: use, payId: pay.id, by: me().name || '' }], updatedAt: Date.now() });
    return { use, bal, g };
  }
  ACT['sjy-gv-redeem'] = t => {
    const inv = S.invoices.find(x => x.id === t.dataset.id); if (!inv) return;
    const el = openModal(`<form data-sjy="gvr" data-id="${esc(inv.id)}" novalidate>${mHead('🎁 Gift voucher se jama', esc(inv.no) + ' · baaki ' + inr(invDue(inv)))}<div class="m-body"><div class="fg">${F('Voucher code', '<input name="code" placeholder="GV-XXXX-XXXX" autocomplete="off" style="text-transform:uppercase" required>')}</div><div class="sjy-gvr small muted" style="margin-top:8px"></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Lagao</button></div></form>`, { small: true });
    setTimeout(() => { const i = q$('input[name="code"]', el); if (i) i.focus(); }, 50);
  };
  document.addEventListener('input', e => { const i = e.target; if (!i.closest || !i.closest('form[data-sjy="gvr"]')) return; const code = i.value.trim().toUpperCase(); const g = (S.vouchers || []).find(v => v.code === code || v.code.replace(/-/g, '') === code.replace(/-/g, '')); const out = q$('.sjy-gvr', i.closest('form')); out.innerHTML = g ? `${esc(g.holderName || '')} · balance <b>${inr(g.balance)}</b> · ${({ active: '<span class="green">chalu</span>', used: '<span class="red">khatam</span>', expired: '<span class="red">tareekh nikal gayi</span>', cancelled: '<span class="red">cancel</span>' })[vStatus(g)]}` : code.length >= 10 ? '<span class="red">Code nahi mila</span>' : ''; });
  SUBMIT.gvr = async f => { const inv = S.invoices.find(x => x.id === f.dataset.id); const r = await redeemVoucher(inv, formVals(f).code); closeModal(f.closest('.overlay')); toast(`✓ ${inr(r.use)} voucher se jama · voucher mein bacha ${inr(r.bal)}`); document.querySelectorAll('#modal-root .overlay').forEach(o => { if (o.querySelector('.inv-doc')) closeModal(o); }); openInvoiceView(inv.id); };

  /* 24. SHAADI PACKAGE → sj-shaadi.js (v29). Only the menu entries stay here. */
  Object.assign(ICON, { shaadi: '<path d="M12 21s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 11c0 5.5-7 10-7 10z"/>', gift: '<rect x="3" y="8" width="18" height="13" rx="2"/><path d="M12 8v13M3 12h18M12 8c-2-4-6-4-6-1s6 1 6 1zm0 0c2-4 6-4 6-1s-6 1-6 1z"/>' });
  if (typeof VIEWS !== 'undefined') {
    const after = (k, row) => { if (VIEWS.some(v => v[0] === row[0])) return; const i = VIEWS.findIndex(v => v[0] === k); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, row); };
    after('girvi', ['shaadi', 'Shaadi', 'shaadi', 'Shaadi package']); after('shaadi', ['gifts', 'Gift', 'gift', 'Gift, referral & review']);
  }
  /* ---- buttons on the bill view: voucher / wedding advance / review ---- */
  if (typeof openInvoiceView === 'function') {
    const OV = openInvoiceView;
    openInvoiceView = function (id) {
      const r = OV.apply(this, arguments);
      try {
        const v = S.invoices.find(x => x.id === id); const el = q$('#modal-root').lastElementChild; const pb = el && q$('.m-foot [data-act="inv-pdf"]', el);
        if (v && pb && (v.type === 'sale' || v.type === 'estimate') && canEdit()) {
          const due = invDue(v); let h = '';
          if (due > 0.5 && (S.vouchers || []).some(g => vStatus(g) === 'active')) h += `<button type="button" class="btn" data-act="sjy-gv-redeem" data-id="${esc(v.id)}">🎁 Voucher</button>`;
          if (reviewOk(v)) h += `<button type="button" class="btn" data-act="sjy-rv-ask" data-id="${esc(v.id)}">⭐ Review</button>`;
          if (h) pb.insertAdjacentHTML('beforebegin', h);
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }

  /* =====================================================================
     12. GOOGLE REVIEW
     ===================================================================== */
  const reviewUrl = () => String(pro().reviewUrl || '').trim();
  const reviewOk = v => !!reviewUrl() && (v.type === 'sale' || v.type === 'estimate') && chanOf(v) === 'retail' && !!ph10((custById(v.partyId) || {}).phone || v.partyPhone) && !v.deleted;
  const reviewMsg = v => `Namaste ${v.partyName} ji 🙏\n${firm()} se kharid ke liye dil se dhanyavaad! 💛\nAapka anubhav kaisa raha? Bas 1 minute — Google par 5⭐ review dekar humein bataiye:\n${reviewUrl()}\nAapki ek line se doosre grahakon ko bharosa milta hai. 🙏`;
  async function askReview(v) { const u = waUrl((custById(v.partyId) || {}).phone || v.partyPhone, reviewMsg(v)); if (!u) throw new Error('Customer ka phone nahi hai'); window.open(u, '_blank', 'noopener'); await save('invoices', { ...v, reviewAsked: Date.now(), updatedAt: Date.now() }, { quiet: true }); }
  ACT['sjy-rv-ask'] = async t => { const v = S.invoices.find(x => x.id === t.dataset.id); await askReview(v); t.textContent = '✓ Review maanga'; renderView(); };
  function reviewCard() {
    if (!reviewUrl() || !canEdit()) return ''; const from = addDays(todayStr(), -7);
    const L = S.invoices.filter(v => v.date >= from && !v.reviewAsked && reviewOk(v)).sort((a, b) => String(b.date).localeCompare(String(a.date)));
    const seen = new Set(); const U = L.filter(v => { if (seen.has(v.partyId)) return false; seen.add(v.partyId); return !S.invoices.some(x => x.partyId === v.partyId && x.reviewAsked && x.reviewAsked > Date.now() - 180 * 86400000); });
    if (!U.length) return '';
    return `<div class="card"><div class="card-h"><h3>⭐ Google review maango (${U.length})</h3></div><p class="small muted" style="margin-top:-4px">Pichhle 7 din ke grahak — ek WhatsApp, aur dukaan Google par upar.</p>${U.slice(0, 6).map(v => `<div class="row static"><div><b>${esc(v.partyName)}</b><div class="small muted">${esc(v.no)} · ${fmtD(v.date)} · ${inr(invPayable(v))}</div></div><button class="btn sm green" data-act="sjy-rv-ask" data-id="${esc(v.id)}">⭐ WhatsApp</button></div>`).join('')}</div>`;
  }
  // a small prompt right after a retail bill is saved
  if (typeof persistInvoice === 'function') {
    const P0 = persistInvoice;
    persistInvoice = async function (st) {
      const isNew = !(st && st.orig); const ref = st && st.referral ? { ...st.referral } : null;
      const r = await P0.apply(this, arguments);
      try {
        if (r && r.inv && (r.inv.type === 'sale' || r.inv.type === 'estimate') && chanOf(r.inv) === 'retail') {
          let c = custById(r.inv.partyId); if (c && !c.refCode && refCfg().on) c = await ensureRefCode(c);
          if (ref && c && !c.referredBy && isNew) await finishReferral(r, c, ref, st);
          if (isNew && reviewOk(r.inv)) setTimeout(() => flashReview(r.inv), 900);
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }
  async function finishReferral(r, c, ref, st) {
    const by = S.customers.find(x => x.id === ref.by); if (!by || by.id === c.id) return; const cfg = refCfg();
    const disc = cfg.newPct && !(st.privilege && st.privilege.on) ? r2(num(st.discValue)) : 0;
    const inv2 = { ...r.inv, referral: { by: by.id, code: ref.code, discount: disc } }; if (await save('invoices', inv2, { quiet: true })) r.inv = inv2;
    await save('customers', { ...c, referredBy: by.id, referredAt: Date.now(), updatedAt: Date.now() }, { quiet: true });
    let g = null; if (num(cfg.reward) > 0) g = await issueVoucher({ amount: cfg.reward, customerId: by.id, months: cfg.months, source: 'referral', note: 'Referral: ' + c.name + ' (' + r.inv.no + ')' });
    toast(`🤝 ${by.name} ko ${g ? inr(g.amount) + ' ka voucher ' + g.code : 'referral'} mila`);
    if (g) setTimeout(() => { const u = waUrl(by.phone, `Namaste ${by.name} ji 🙏\nAapke bheje ${c.name} ji ne ${firm()} se kharid ki — dhanyavaad! 💛\nAapke liye ${inr(g.amount)} ka gift voucher: *${g.code}* (${fmtD(g.expiry)} tak).\nAgli kharid par ye code bataiye. 🎁`); const el = openModal(`${mHead('🤝 Referral inaam', esc(by.name) + ' ko ' + inr(g.amount) + ' ka voucher')}<div class="m-body"><p>Voucher <b class="mono">${esc(g.code)}</b> ${esc(by.name)} ke naam ban gaya.</p></div><div class="m-foot"><button class="btn" data-act="close">Baad mein</button>${u ? `<a class="btn primary green" href="${esc(u)}" target="_blank" rel="noopener">WhatsApp par bataiye</a>` : ''}</div>`, { small: true }); }, 1800);
  }
  function flashReview(v) { if (q$('#sjy-rv-flash')) return; const d = document.createElement('div'); d.id = 'sjy-rv-flash'; d.className = 'sjy-flash'; d.innerHTML = `<div><b>⭐ ${esc(v.partyName)} se Google review maangein?</b><div class="small muted">Bill ke turant baad maangne par sabse zyada review milte hain.</div></div><div class="btns"><button class="btn sm green" data-act="sjy-rv-ask" data-id="${esc(v.id)}">WhatsApp</button><button class="btn sm" data-act="sjy-flash-x">Nahi</button></div>`; document.body.appendChild(d); setTimeout(() => d.remove(), 20000); }
  ACT['sjy-flash-x'] = t => { const d = t.closest('.sjy-flash'); if (d) d.remove(); };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('#sjy-rv-flash [data-act="sjy-rv-ask"]'); if (t) setTimeout(() => { const d = q$('#sjy-rv-flash'); if (d) d.remove(); }, 300); }, true);
  addCss(`.sjy-flash{position:fixed;left:50%;bottom:86px;transform:translateX(-50%);z-index:90;display:flex;gap:12px;align-items:center;max-width:min(560px,calc(100vw - 32px));background:var(--card,#17130c);border:1px solid var(--gold,#c9a046);border-radius:14px;padding:12px 14px;box-shadow:0 10px 30px rgba(0,0,0,.4)}`);

  /* =====================================================================
     GIFT VIEW — vouchers · referral · review settings
     ===================================================================== */
  if (!ui.gfTab) ui.gfTab = 'vouchers';
  VIEWDEF.gifts = {
    shell: () => tabs('gfTab', [['vouchers', '🎁 Gift voucher'], ['referral', '🤝 Referral'], ['review', '⭐ Google review']]) + `<div class="toolbar">${canEdit() && (ui.gfTab || 'vouchers') === 'vouchers' ? `<button class="btn primary" data-act="sjy-gv-new">${ic('plus', 16)} Voucher becho</button>` : ''}</div><div id="vbody"></div>`,
    body() { const t = ui.gfTab || 'vouchers'; return t === 'referral' ? refView() : t === 'review' ? reviewView() : voucherView(); }
  };
  function voucherView() {
    const V = (S.vouchers || []).slice().sort((a, b) => num(b.createdAt) - num(a.createdAt)); const ym = todayStr().slice(0, 7);
    const act = V.filter(v => vStatus(v) === 'active'); const soldM = V.filter(v => v.source === 'sold' && String(v.issueDate).startsWith(ym)); const redM = sum(V, v => sum((v.redemptions || []).filter(x => String(x.date).startsWith(ym)), x => x.amount));
    const head = kpis([['Chalu voucher', act.length], ['Bacha balance (dena hai)', inr(sum(act, v => v.balance))], ['Is mahine bike', inr(sum(soldM, v => v.amount))], ['Is mahine lage', inr(redM)]]);
    if (!V.length) return head + emptyBox('Abhi koi gift voucher nahi. Shaadi, janamdin, Diwali par ₹2,100 / ₹5,100 / ₹11,000 ke voucher bechiye — paisa aaj, grahak dukaan par baad mein.');
    const pill = s => ({ active: '<span class="pill green">Chalu</span>', used: '<span class="pill">Khatam</span>', expired: '<span class="pill red">Tareekh nikli</span>', cancelled: '<span class="pill red">Cancel</span>' })[s];
    return head + btable([['Code'], ['Kiske naam'], ['Rakam', 'r'], ['Balance', 'r'], ['Valid'], ['Status'], ['']], V.slice(0, 300).map(v => `<tr>${td(`<b class="mono">${esc(v.code)}</b>${v.source === 'referral' ? '<div class="small muted">referral inaam</div>' : ''}`)}${td(esc(v.holderName || '') + (v.buyerName && v.buyerName !== v.holderName ? `<div class="small muted">from ${esc(v.buyerName)}</div>` : ''))}${td(inr(v.amount), 1)}${td('<b>' + inr(v.balance) + '</b>', 1)}${td('<span style="white-space:nowrap">' + fmtD(v.expiry) + '</span>')}${td(pill(vStatus(v)))}${td(`<div class="btns" style="flex-wrap:nowrap"><button class="btn sm" data-act="sjy-gv-pdf" data-id="${v.id}" title="Gift card PDF">${ic('dl', 14)}</button><button class="btn sm green" data-act="sjy-gv-wa" data-id="${v.id}" title="WhatsApp">WA</button>${isOwner() && vStatus(v) === 'active' ? `<button class="btn sm danger" data-act="sjy-gv-cancel" data-id="${v.id}" title="Cancel">✕</button>` : ''}</div>`)}</tr>`));
  }
  function refView() {
    const c = refCfg(); const refd = S.customers.filter(x => x.referredBy); const by = new Map(); refd.forEach(x => by.set(x.referredBy, (by.get(x.referredBy) || 0) + 1));
    const top = [...by].sort((a, b) => b[1] - a[1]).slice(0, 20); const rew = (S.vouchers || []).filter(v => v.source === 'referral');
    return kpis([['Referral se aaye grahak', refd.length], ['Diye gaye inaam', inr(sum(rew, v => v.amount))], ['Inaam jo lag gaye', inr(sum(rew, v => v.amount - v.balance))]]) +
      `<div class="card"><h3>Niyam</h3><form data-sjy="refcfg" novalidate><div class="fg">${F('Bhejne wale ko voucher ₹', inp('reward', c.reward, { type: 'number', min: 0, step: '50' }))}${F('Naye grahak ko making par extra chhoot %', inp('newPct', c.newPct, { type: 'number', min: 0, max: 50, step: '0.5' }))}${F('Voucher valid (mahine)', inp('months', c.months, { type: 'number', min: 1, max: 36 }))}</div><label class="chk" style="margin-top:8px"><input type="checkbox" name="on" ${c.on ? 'checked' : ''}> Referral chalu</label><div class="btns" style="margin-top:10px">${canAdmin() ? '<button class="btn primary">Save</button>' : ''}</div></form>
      <p class="small muted" style="margin:10px 0 0">Kaise chalta hai: har retail grahak ka code (jaise SJR1234AB) apne-aap banta hai — Party 360 aur unke portal par dikhta hai. Naya grahak pehle bill par code (ya bhejne wale ka phone) bataye → use making par ${c.newPct}% chhoot, aur bhejne wale ko ${inr(c.reward)} ka gift voucher apne-aap. Ek naye grahak par inaam ek hi baar.</p></div>` +
      (top.length ? `<div class="card"><h3>Sabse zyada grahak laane wale</h3>${btable([['Grahak'], ['Laaye', 'r'], ['Inaam', 'r']], top.map(([id, n]) => { const x = custById(id) || {}; return `<tr>${td(esc(x.name || '—'))}${td(n, 1)}${td(inr(sum(rew.filter(v => v.customerId === id), v => v.amount)), 1)}</tr>`; }))}</div>` : '');
  }
  SUBMIT.refcfg = async f => { const v = formVals(f); const r = { reward: Math.max(0, num(v.reward)), newPct: Math.max(0, Math.min(50, num(v.newPct))), months: Math.max(1, Math.min(36, Math.round(num(v.months)) || 12)), on: !!v.on }; await savePro({ referral: r }); if (SITE) { try { await window.SJ_API_CALL('referral_cfg', r); } catch (e) { /* portal text only */ } } toast('✓ Referral niyam save'); };
  function reviewView() {
    const ym = todayStr().slice(0, 7); const asked = S.invoices.filter(v => v.reviewAsked && new Date(v.reviewAsked).toISOString().slice(0, 7) === ym).length;
    return kpis([['Is mahine review maange', asked]]) + `<div class="card"><h3>Google review link</h3><form data-sjy="rvcfg" novalidate><div class="fg">${F('Review link', inp('reviewUrl', reviewUrl(), { ph: 'https://g.page/r/XXXX/review' }))}</div><div class="btns" style="margin-top:10px">${canAdmin() ? '<button class="btn primary">Save</button>' : ''}${reviewUrl() ? `<a class="btn" href="${esc(reviewUrl())}" target="_blank" rel="noopener">Link kholo</a>` : ''}</div></form>
      <ol class="small" style="margin:12px 0 0;padding-left:18px"><li>Google par apni dukaan ka <b>Business Profile</b> kholiye (Google Maps / "My business").</li><li><b>"Ask for reviews"</b> / "Read reviews → Get more reviews" dabaiye → link copy kijiye.</li><li>Yahan paste karke Save. Ab har retail bill ke baad "⭐ Review" button aur dashboard par list aayegi.</li></ol>
      <p class="small muted">Google ke niyam: review ke badle chhoot ya inaam dena mana hai — sirf request kijiye.</p></div>`;
  }
  SUBMIT.rvcfg = async f => { const u = String(formVals(f).reviewUrl || '').trim(); if (u && !/^https:\/\/\S+$/.test(u)) return toast('Link https:// se shuru hona chahiye', 'err'); await savePro({ reviewUrl: u }); toast('✓ Review link save'); renderView(); };

  /* =====================================================================
     16. GEHNE KA QR PAGE
     ===================================================================== */
  const IT = new Map();
  async function itemTokens(ids) { const need = ids.filter(i => !IT.has(i)); for (let k = 0; k < need.length; k += 400) { const r = await window.SJ_API_CALL('item_tok', { ids: need.slice(k, k + 400) }); Object.entries(r.tokens || {}).forEach(([i, t]) => IT.set(i, t)); } }
  const itemUrl = id => IT.has(id) ? location.origin + location.pathname.replace(/[^/]*$/, '') + 'item.php?i=' + encodeURIComponent(id) + '&k=' + IT.get(id) : '';
  if (typeof openProductForm === 'function') {
    const OP = openProductForm;
    openProductForm = function (id) { const r = OP.apply(this, arguments); try { if (id && SITE) { const el = q$('#modal-root').lastElementChild; const ft = el && q$('.m-foot', el); if (ft && !q$('[data-act="sjy-qr"]', ft)) ft.insertAdjacentHTML('afterbegin', `<button type="button" class="btn" data-act="sjy-qr" data-id="${esc(id)}">🔗 QR page</button>`); } } catch (e) { console.error(e); } return r; };
  }
  ACT['sjy-qr'] = async t => {
    const p = S.products.find(x => x.id === t.dataset.id); await itemTokens([p.id]); const u = itemUrl(p.id); if (!u) throw new Error('Link nahi bana — internet dekhiye');
    openModal(`${mHead('🔗 Gehne ka QR page', '#' + esc(p.sku) + ' · ' + esc(p.category || '') + ' ' + esc(p.purity || ''))}<div class="m-body"><div class="sjy-qr">${qrSVG(u)}</div><p class="small muted" style="text-align:center;word-break:break-all">${esc(u)}</p><p class="small">Customer QR scan kare to us gehne ki photo, wazan, purity, HUID aur "WhatsApp par poochhiye" button dikhta hai. Keemat nahi dikhti.</p></div><div class="m-foot"><button class="btn" data-act="sjy-qr-copy" data-u="${esc(u)}">Copy link</button><button class="btn green" data-act="sjy-qr-wa" data-u="${esc(u)}" data-n="${esc((p.category || '') + ' ' + (p.purity || ''))}">WhatsApp</button><button class="btn primary" data-act="sjy-qr-card" data-id="${esc(p.id)}">🖨 Display card</button></div>`, { small: true });
  };
  ACT['sjy-qr-copy'] = async t => { await navigator.clipboard.writeText(t.dataset.u); toast('Link copy'); };
  ACT['sjy-qr-wa'] = t => window.open('https://wa.me/?text=' + encodeURIComponent(`${firm()} — ${t.dataset.n}\n${t.dataset.u}`), '_blank', 'noopener');
  ACT['sjy-qr-card'] = async t => { await qrCardsPdf([t.dataset.id]); };
  ACT['sjy-qr-sheet'] = async () => {
    const L = S.products.filter(p => p.status === 'In Stock').sort((a, b) => num(b.createdAt) - num(a.createdAt)); if (!L.length) return toast('In Stock mein koi piece nahi', 'err');
    const withPh = L.filter(p => p.photo); const pick = withPh.length ? withPh : L;
    confirmBox(`${pick.length} piece${withPh.length ? ' (photo wale)' : ''} ke QR display card banayein? (A4 par 8 card, kaat kar tray / showcase mein lagaiye)`, async () => { toast('Cards ban rahe hain…'); await qrCardsPdf(pick.slice(0, 400).map(p => p.id)); }, 'Banao');
  };
  async function qrCardsPdf(ids) {
    const K = SJ_BILLX.kit; await SJ_BILLX.loadFonts(); await itemTokens(ids); const { SERIF, C, font, grad, rr, T, qrDraw, loadImg, jpeg } = K;
    const PX = 2480, PY = 3508, cols = 2, rows = 4, cw = 1120, ch = 790, gx = (PX - cols * cw) / 3, gy = (PY - rows * ch) / 5;
    const pdf = new Pdf(210, 297); pdf.pages.length = 0;
    for (let s0 = 0; s0 < ids.length; s0 += cols * rows) {
      const cv = document.createElement('canvas'); cv.width = PX; cv.height = PY; const x = cv.getContext('2d'); x.fillStyle = '#ffffff'; x.fillRect(0, 0, PX, PY);
      const part = ids.slice(s0, s0 + cols * rows);
      for (let k = 0; k < part.length; k++) {
        const p = S.products.find(z => z.id === part[k]); if (!p) continue; const X = gx + (k % cols) * (cw + gx), Y = gy + Math.floor(k / cols) * (ch + gy);
        x.save(); x.setLineDash([12, 10]); x.strokeStyle = '#bbbbbb'; x.lineWidth = 2; x.strokeRect(X - 20, Y - 20, cw + 40, ch + 40); x.restore();
        rr(x, X, Y, cw, ch, 30); const g = x.createLinearGradient(X, Y, X + cw, Y + ch); g.addColorStop(0, '#0d0b07'); g.addColorStop(1, '#2a1d0c'); x.fillStyle = g; x.fill(); x.lineWidth = 5; x.strokeStyle = grad(x, X, Y, X + cw, Y + ch); x.stroke();
        const im = p.photo ? await loadImg(p.photo) : null; const ps = 430;
        if (im) { x.save(); rr(x, X + 40, Y + 40, ps, ps, 22); x.clip(); const kk = Math.max(ps / im.naturalWidth, ps / im.naturalHeight); x.drawImage(im, X + 40 + (ps - im.naturalWidth * kk) / 2, Y + 40 + (ps - im.naturalHeight * kk) / 2, im.naturalWidth * kk, im.naturalHeight * kk); x.restore(); rr(x, X + 40, Y + 40, ps, ps, 22); x.lineWidth = 3; x.strokeStyle = '#d4b062'; x.stroke(); }
        const qs = 400, qx = X + cw - 40 - qs, qy = Y + 40; rr(x, qx - 12, qy - 12, qs + 24, qs + 24, 18); x.fillStyle = '#fff'; x.fill(); const u = itemUrl(p.id); if (u) qrDraw(x, u, qx, qy, qs, '#1a1206');
        if (!im) { T(x, firm(), X + 50, Y + 130, { size: 52, w: 700, fam: SERIF, color: '#f2d68a', maxW: cw - qs - 140 }); T(x, 'Scan karke dekhiye', X + 50, Y + 200, { size: 32, color: '#d8ccb0' }); }
        T(x, `${p.category || 'Gehna'} ${p.purity || ''}`.trim(), X + 40, Y + 560, { size: 54, w: 700, fam: SERIF, color: '#fff4d6', maxW: cw - 80 });
        T(x, [num(p.net || p.gross) ? num(p.net || p.gross).toFixed(3) + ' g' : '', p.huid ? 'HUID ' + String(p.huid).toUpperCase() : ''].filter(Boolean).join('   ·   '), X + 40, Y + 630, { size: 34, color: '#e9d7a5', maxW: cw - 80 });
        T(x, '#' + (p.sku || ''), X + 40, Y + 700, { size: 30, w: 700, color: '#bfa970' }); T(x, 'Scan · photo, wazan, HUID', X + cw - 40, Y + 700, { align: 'right', size: 26, color: '#a89a78' });
      }
      pdf.addPage(); pdf.image(jpeg(cv, 0.92), 0, 0, 210, 297);
    }
    await offerDownload('shivaa_qr_cards.pdf', pdf.blob());
  }
  { const V = VIEWDEF.vault; if (V && V.shell && SITE) VIEWDEF.vault = { ...V, shell() { return V.shell.apply(V, arguments).replace('</button></div>', '</button><button type="button" class="btn sm" data-act="sjy-qr-sheet">🔗 QR display cards</button></div>'); } }; }
  addCss(`.sjy-qr{display:flex;justify-content:center;margin:6px 0 10px}.sjy-qr svg{width:220px;height:220px;background:#fff;padding:10px;border-radius:12px}`);

  /* =====================================================================
     18. AI KYC — Aadhaar / PAN photo → customer form
     ===================================================================== */
  const KYC_PROMPT = `KYC_JSON. Read this Indian ID card photo (Aadhaar, PAN, voter ID or driving licence). Reply ONLY with JSON, no other text:
{"docType":"aadhaar|pan|voter|dl|other","name":"","fatherName":"","dob":"YYYY-MM-DD or empty","gender":"","aadhaar":"12 digits or empty","pan":"ABCDE1234F or empty","address":"full address in one line or empty","pin":"6 digits or empty","city":"town / district or empty","confidence":"high|medium|low"}
Copy numbers exactly as printed. Do not guess a value you cannot read — leave it empty.`;
  function shrinkImg(file, max) { return new Promise((res, rej) => { const fr = new FileReader(); fr.onerror = rej; fr.onload = () => { const im = new Image(); im.onerror = () => rej(new Error('Photo nahi khuli')); im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)); const c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', 0.88).split(',')[1]); }; im.src = fr.result; }; fr.readAsDataURL(file); }); }
  function mountKyc() {
    const f = q$('form[data-form="customer"]'); if (!f || f.dataset.sjyKyc || !SITE) return; f.dataset.sjyKyc = '1';
    const body = q$('.m-body', f); if (!body) return;
    body.insertAdjacentHTML('afterbegin', `<div class="sjy-kyc"><div><b>📷 Aadhaar / PAN ki photo se bharo</b><div class="small muted">AI card padh kar naam, number, pata bhar dega — aap check karke Save karein. Photo software mein save nahi hoti.</div></div><label class="btn sm gold" style="cursor:pointer">Photo lo<input type="file" accept="image/*" capture="environment" class="sjy-kyc-in" hidden></label></div><div class="sjy-kyc-out small"></div>`);
  }
  setInterval(mountKyc, 700);
  document.addEventListener('change', async e => {
    const i = e.target; if (!i.classList || !i.classList.contains('sjy-kyc-in') || !i.files || !i.files[0]) return; e.stopPropagation(); const f = i.closest('form'); const out = q$('.sjy-kyc-out', f);
    out.innerHTML = '⏳ AI card padh raha hai…';
    try {
      const data = await shrinkImg(i.files[0], 1600); i.value = '';
      const r = await window.SJ_API_CALL('ai', { messages: [{ role: 'user', content: KYC_PROMPT, images: [{ data, mime: 'image/jpeg' }] }], quick: true }, 120000);
      if (r.notSet) throw new Error('AI key nahi hai — Setup → AI Assistant'); const m = String(r.text || '').match(/\{[\s\S]*\}/); if (!m) throw new Error('Card padha nahi gaya — saaf, seedhi photo lijiye');
      const j = JSON.parse(m[0]); const filled = []; const setF = (name, val, force) => { const el = f.elements[name]; if (!el || !val) return; if (el.value && !force) return; el.value = val; el.dispatchEvent(new Event('input', { bubbles: true })); filled.push(name); };
      const aad = String(j.aadhaar || '').replace(/\D/g, ''); const pan = String(j.pan || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      setF('name', String(j.name || '').trim()); if (aad.length === 12) setF('aadhar', aad, true); if (/^[A-Z]{5}\d{4}[A-Z]$/.test(pan)) setF('pan', pan, true);
      setF('address', String(j.address || '').trim()); const pin = String(j.pin || '').replace(/\D/g, ''); if (pin.length === 6) setF('pin', pin); setF('city', String(j.city || '').trim());
      if (/^\d{4}-\d{2}-\d{2}$/.test(j.dob || '')) { setF('dob', j.dob); const age = Math.floor((Date.now() - new Date(j.dob).getTime()) / 31557600000); if (age > 0 && age < 120) setF('age', String(age)); }
      const lbl = { name: 'Naam', aadhar: 'Aadhaar', pan: 'PAN', address: 'Pata', pin: 'PIN', city: 'Shahar', dob: 'Janam tithi', age: 'Umar' };
      out.innerHTML = filled.length ? `<span class="green">✓ Bhara: ${filled.map(k => lbl[k] || k).join(', ')}</span>${j.confidence === 'low' ? ' <span class="red">· photo dhundhli — dhyan se check kijiye</span>' : ''}<div class="muted">Card: ${esc(j.docType || '')}${j.name ? ' · ' + esc(j.name) : ''}. Pehle se bhare khaane nahi badle (Aadhaar / PAN chhod kar).</div>` : '<span class="red">Card se kuch nahi padha gaya — saaf photo lijiye</span>';
    } catch (err) { out.innerHTML = '<span class="red">' + esc(err.message || 'Nahi hua') + '</span>'; }
  }, true);
  addCss(`.sjy-kyc{display:flex;justify-content:space-between;gap:12px;align-items:center;border:1px dashed var(--gold,#c9a046);border-radius:12px;padding:10px 12px;margin-bottom:8px}.sjy-kyc-out{margin:0 0 10px}`);

  /* =====================================================================
     19. STOCK INSURANCE
     ===================================================================== */
  function stockWorth() {
    let gold = 0, silver = 0, v = 0, n = 0;
    S.products.filter(p => p.status === 'In Stock').forEach(p => { const ag = isSilver(p.purity, p.metal); const net = num(p.net) || num(p.gross); const fine = net * (num(p.tunch) || tunchOf(p.purity)) / 100 * (num(p.pcs) > 1 && p.stockType !== 'Individual' ? 1 : 1); if (ag) silver += fine; else gold += fine; v += fine * rateFine(ag) + num(p.stoneValue || 0); n++; });
    let gv = 0; (S.girvi || []).filter(g => g.status !== 'closed').forEach(g => (g.items || []).forEach(it => { const ag = it.metal === 'silver'; gv += num(it.net || it.gross) * num(it.tunch) / 100 * rateFine(ag); }));
    return { pieces: n, gold: r3(gold), silver: r3(silver), stock: r2(v), girvi: r2(gv), total: r2(v + gv) };
  }
  const policies = () => (pro().insurance || []).slice();
  function insStatus() { const t = todayStr(); const P = policies(); const live = P.filter(p => (!p.from || p.from <= t) && (!p.to || p.to >= t)); const cover = sum(live.filter(p => !p.type || p.type === 'block' || p.type === 'stock'), p => p.sumInsured); const w = stockWorth(); const soon = live.filter(p => p.to && daysBetween(t, p.to) <= 30); const gone = P.filter(p => p.to && p.to < t); return { P, live, cover, w, pct: w.total ? cover / w.total * 100 : 0, soon, gone }; }
  function insCard(full) {
    const s = insStatus(); if (!full && !s.P.length) return ''; const bad = s.live.length && s.pct < 100, warn = bad || s.soon.length || (!s.live.length && s.P.length);
    if (!full && !warn) return '';
    return `<div class="card sjy-ins"><div class="card-h"><h3>🛡 Stock insurance</h3>${isOwner() ? `<button class="btn sm" data-act="sjy-ins-edit">${s.P.length ? 'Policy' : '+ Policy jodo'}</button>` : ''}</div>
      ${kpis([['Stock + girvi ki keemat', inr(s.w.total), `${s.w.pieces} piece · sona ${g3(s.w.gold)} fine · chandi ${g3(s.w.silver)} fine`], ['Chalu bima', inr(s.cover), s.live.length + ' policy'], ['Cover', `<span class="${s.pct >= 100 ? 'green' : 'red'}">${s.w.total ? Math.round(s.pct) + '%' : '—'}</span>`, s.pct < 100 && s.w.total ? 'kam: ' + inr(s.w.total - s.cover) : 'theek']])}
      ${!s.P.length ? '<p class="small muted" style="margin:0">Jeweller\'s Block policy ki rakam, insurance company aur tareekh daaliye — software roz stock ki keemat se milayega aur khatam hone se 30 din pehle batayega.</p>' : ''}
      ${s.live.length && s.pct < 100 ? `<div class="note red small">Stock ki keemat bima se ${inr(s.w.total - s.cover)} zyada hai. Nuksaan par company sirf hisse mein bharpai kar sakti hai (under-insurance) — agent se rakam badhwaiye.</div>` : ''}
      ${s.soon.map(p => `<div class="note small" style="margin-top:6px">⏰ ${esc(p.insurer)} ${esc(p.policyNo || '')} — ${fmtD(p.to)} ko khatam (${daysBetween(todayStr(), p.to)} din). Renew karwaiye.</div>`).join('')}
      ${!s.live.length && s.P.length ? '<div class="note red small">Koi chalu policy nahi — sab khatam ho chuki hain.</div>' : ''}
      <p class="small muted" style="margin:8px 0 0">Keemat = fine wazan × aaj ka bhav (stone, making shamil nahi). Bullion / cash alag se jodiye.</p></div>`;
  }
  ACT['sjy-ins-edit'] = () => {
    const P = policies(); while (P.length < 4) P.push({});
    openModal(`<form data-sjy="ins" novalidate>${mHead('🛡 Insurance policy', 'Jeweller\'s Block / stock / cash-in-safe / transit')}<div class="m-body">${P.slice(0, 4).map((p, k) => `<div class="sjy-ins-row"><input name="i${k}" placeholder="Company (jaise New India)" value="${esc(p.insurer || '')}"><input name="n${k}" placeholder="Policy no." value="${esc(p.policyNo || '')}"><select name="t${k}">${opts([['block', 'Jeweller\'s Block'], ['stock', 'Stock / fire'], ['cash', 'Cash in safe'], ['transit', 'Transit']], p.type || 'block')}</select><input name="s${k}" type="number" min="0" step="10000" placeholder="Bima rakam ₹" value="${esc(p.sumInsured || '')}"><input name="f${k}" type="date" value="${esc(p.from || '')}" title="Shuru"><input name="e${k}" type="date" value="${esc(p.to || '')}" title="Khatam"></div>`).join('')}<p class="small muted">Khaali line chhod dein. Stock ki keemat ke saath sirf "Jeweller's Block" aur "Stock" milaye jaate hain.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { wide: true });
  };
  SUBMIT.ins = async f => { const v = formVals(f); const P = []; for (let k = 0; k < 4; k++) { if (!String(v['i' + k] || '').trim() && !num(v['s' + k])) continue; if (!(num(v['s' + k]) > 0)) return toast('Line ' + (k + 1) + ': bima rakam daaliye', 'err'); if (v['f' + k] && v['e' + k] && v['e' + k] < v['f' + k]) return toast('Line ' + (k + 1) + ': khatam tareekh shuru se pehle hai', 'err'); P.push({ insurer: String(v['i' + k]).trim(), policyNo: String(v['n' + k] || '').trim(), type: v['t' + k], sumInsured: num(v['s' + k]), from: v['f' + k] || '', to: v['e' + k] || '' }); } await savePro({ insurance: P }); closeModal(f.closest('.overlay')); toast('✓ Policy save'); renderView(); };
  addCss(`.sjy-ins-row{display:grid;grid-template-columns:1.4fr 1fr 1fr 1fr 1fr 1fr;gap:6px;margin-bottom:8px}@media(max-width:620px){.sjy-ins-row{grid-template-columns:1fr 1fr}}`);

  /* =====================================================================
     27. STAFF TARGET
     ===================================================================== */
  const staffTargets = () => (pro().staffTargets || []).filter(x => x && x.name && num(x.monthly) > 0);
  const createdBy = (() => { let key = '', map = new Map(); return id => { const A = S.audit || []; const k = A.length + ':' + ((A[A.length - 1] || {}).id || ''); if (k !== key) { key = k; map = new Map(); A.forEach(e => { if (e.col === 'invoices' && e.action === 'create' && e.docId) map.set(e.docId, e.by || e.user || ''); }); } return map.get(id) || ''; }; })();
  function staffSales(from, to) { const m = new Map(); S.invoices.forEach(v => { if (v.deleted || !(v.type === 'sale' || v.type === 'estimate') || v.date < from || v.date > to) return; const k = createdBy(v.id) || ''; if (!k) return; m.set(k, (m.get(k) || 0) + invPayable(v)); }); return m; }
  function staffCard() {
    const T = staffTargets(); if (!T.length) return ''; const t = todayStr(), ym = t.slice(0, 7), first = ym + '-01', dim = new Date(+ym.slice(0, 4), +ym.slice(5, 7), 0).getDate(), day = +t.slice(8, 10);
    const M = staffSales(first, t), D = staffSales(t, t); const mine = SITE && !canAdmin() ? T.filter(x => x.name === me().name) : T; if (!mine.length) return '';
    const bar = (p, cls) => `<div class="sjy-bar"><i class="${cls || ''}" style="width:${Math.min(100, Math.max(0, p)).toFixed(1)}%"></i></div>`;
    return `<div class="card sjy-st"><div class="card-h"><h3>🎯 Staff target — ${monthLabel ? monthLabel(ym) : ym}</h3>${canAdmin() ? '<button class="btn sm" data-act="sjy-st-edit">Badlo</button>' : ''}</div>${mine.map(x => { const m = M.get(x.name) || 0, d = D.get(x.name) || 0, mp = m / x.monthly * 100, daily = x.monthly / dim, dp = d / daily * 100, pace = day / dim * 100;
      return `<div class="sjy-st-row"><div class="sjy-st-h"><b>${esc(x.name)}</b><span class="small">${inr(m)} / ${inr(x.monthly)} · <b class="${mp >= pace ? 'green' : 'red'}">${Math.round(mp)}%</b></span></div>${bar(mp, mp >= pace ? 'ok' : 'low')}<div class="small muted">Aaj ${inr(d)} / ${inr(daily)} (${Math.round(dp)}%) · ${mp >= 100 ? '🏆 Target poora!' : 'baaki ' + inr(Math.max(0, x.monthly - m)) + ' · roz ' + inr(Math.max(0, x.monthly - m) / Math.max(1, dim - day + 1)) + ' chahiye'}</div></div>`; }).join('')}<p class="small muted" style="margin:6px 0 0">Bikri = jis staff ne bill banaya (GST + estimate). Line ka nishaan = mahine ke din ke hisaab se kahaan hona chahiye (${Math.round(day / dim * 100)}%).</p></div>`;
  }
  ACT['sjy-st-edit'] = () => {
    const names = new Set(); (S.audit || []).forEach(e => { if (e.by) names.add(e.by); }); if (me().name) names.add(me().name); const T = (pro().staffTargets || []).slice(); while (T.length < 8) T.push({});
    openModal(`<form data-sjy="st" novalidate>${mHead('🎯 Staff target', 'Har mahine ki bikri — roz ka target apne-aap')}<div class="m-body"><datalist id="sjy-st-names">${[...names].map(n => `<option value="${esc(n)}">`).join('')}</datalist>${T.slice(0, 8).map((x, k) => `<div class="sjy-st-in"><input name="n${k}" list="sjy-st-names" placeholder="Staff ka naam (login wala)" value="${esc(x.name || '')}"><input name="m${k}" type="number" min="0" step="10000" placeholder="Mahine ka target ₹" value="${esc(x.monthly || '')}"></div>`).join('')}<p class="small muted">Naam wahi likhiye jo staff ke login mein hai — bill usi naam se gine jaate hain. Dukaan ka kul target "Targets" mein pehle jaisa hai.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { small: true });
  };
  SUBMIT.st = async f => { const v = formVals(f); const T = []; for (let k = 0; k < 8; k++) { const n = String(v['n' + k] || '').trim(); if (n && num(v['m' + k]) > 0) T.push({ name: n.slice(0, 60), monthly: num(v['m' + k]) }); } await savePro({ staffTargets: T }); closeModal(f.closest('.overlay')); toast('✓ Target save'); renderView(); };
  addCss(`.sjy-st-row{padding:8px 0;border-bottom:1px solid var(--line,#3a2f1a)}.sjy-st-h{display:flex;justify-content:space-between;gap:8px}.sjy-bar{height:8px;border-radius:6px;background:rgba(127,127,127,.18);margin:6px 0 4px;overflow:hidden}.sjy-bar i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,#b98a2d,#f2d68a)}.sjy-bar i.low{background:linear-gradient(90deg,#b7791f,#e0a23a)}.sjy-st-in{display:grid;grid-template-columns:1.4fr 1fr;gap:6px;margin-bottom:6px}`);

  /* =====================================================================
     dashboard, Party 360, setup
     ===================================================================== */
  ACT['sjy-go'] = t => goTo(t.dataset.v);
  { const V = VIEWDEF.dashboard; if (V && V.body) VIEWDEF.dashboard = { ...V, body() { let x = ''; try { x = staffCard() + reviewCard() + insCard(false); } catch (e) { console.error(e); } return x + V.body.apply(V, arguments); } }; }
  { const V = VIEWDEF.khata; if (V && V.body) VIEWDEF.khata = { ...V, body() { const h = V.body.apply(V, arguments); const k = String(ui.k3 || ''); if (!k.startsWith('c:')) return h; const c = S.customers.find(x => x.id === k.slice(2)); if (!c) return h; let x = ''; try { x = `<div class="sjy-p360">${sizeCard(c)}${referralCard(c)}</div>`; } catch (e) { console.error(e); } return x + h; } }; }
  { const V = VIEWDEF.setup; if (V && V.body) VIEWDEF.setup = { ...V, body() { let x = ''; try { x = isOwner() ? insCard(true) : ''; } catch (e) { console.error(e); } return x + V.body.apply(V, arguments); } }; }
  addCss(`.sjy-p360{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-bottom:12px}.sjy-p360 .card{margin:0}`);

  /* =====================================================================
     AI tools
     ===================================================================== */
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    const tool = (name, description, props, fn, label) => ({ name, description, inputSchema: { type: 'object', properties: props, required: [] }, execute: async input => { if (typeof setChatStatus === 'function') setChatStatus(label); return fn(input || {}); } });
    agentTools = function () {
      const L = T0.apply(this, arguments); const add = t => { if (!L.some(x => x.name === t.name)) L.push(t); };
      add(tool('customer_sizes', 'Ring / bangle / chain / bracelet / waist / toe-ring sizes saved for a customer (Party 360 → Size).', { name: { type: 'string' } }, a => { const q = String(a.name || '').toLowerCase(); return S.customers.filter(c => !q || String(c.name).toLowerCase().includes(q) || ph10(c.phone) === ph10(q)).slice(0, 10).map(c => ({ name: c.name, phone: c.phone, sizes: c.sizes || null })); }, 'Size dekh raha hoon…'));
      add(tool('gift_vouchers', 'Gift vouchers: code, holder, amount, balance, expiry, status. Filter by code or holder name; status active / used / expired / cancelled / all.', { q: { type: 'string' }, status: { type: 'string' } }, a => { const q = String(a.q || '').toLowerCase(); const st = a.status || 'all'; return (S.vouchers || []).filter(v => (!q || String(v.code).toLowerCase().includes(q) || String(v.holderName).toLowerCase().includes(q)) && (st === 'all' || vStatus(v) === st)).slice(0, 50).map(v => ({ code: v.code, holder: v.holderName, amount: v.amount, balance: v.balance, expiry: v.expiry, status: vStatus(v), source: v.source, redeemed: (v.redemptions || []).map(r => r.invNo + ' ' + r.amount) })); }, 'Voucher dekh raha hoon…'));
      add(tool('staff_targets', 'Monthly sales target per staff and how much each has sold this month and today.', {}, () => { const t = todayStr(), M = staffSales(t.slice(0, 8) + '01', t), D = staffSales(t, t); return staffTargets().map(x => ({ staff: x.name, monthlyTarget: x.monthly, soldThisMonth: r2(M.get(x.name) || 0), soldToday: r2(D.get(x.name) || 0), pct: Math.round((M.get(x.name) || 0) / x.monthly * 100) })); }, 'Target dekh raha hoon…'));
      add(tool('insurance_status', 'Stock insurance: value of stock + pledged (girvi) jewellery at today\'s rate vs active policies, cover %, policies expiring soon.', {}, () => { const s = insStatus(); return { stockValue: s.w, sumInsured: s.cover, coverPct: Math.round(s.pct), policies: s.P, expiringIn30Days: s.soon.map(p => p.insurer + ' ' + p.to) }; }, 'Insurance dekh raha hoon…'));
      add(tool('referral_info', 'Referral programme: rules, a customer\'s referral code, whom they referred, rewards given.', { name: { type: 'string' } }, a => { const q = String(a.name || '').toLowerCase(); return { rules: refCfg(), customers: S.customers.filter(c => q && String(c.name).toLowerCase().includes(q)).slice(0, 5).map(c => ({ name: c.name, code: c.refCode || null, referred: S.customers.filter(x => x.referredBy === c.id).map(x => x.name), referredBy: c.referredBy ? (custById(c.referredBy) || {}).name : null })) }; }, 'Referral dekh raha hoon…'));
      return L;
    };
    if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { return R0.apply(this, arguments) + `
v28: customer_sizes ("Sunita ki anguthi ka size"), gift_vouchers ("voucher GV-… ka balance"), staff_targets ("staff ka target"), insurance_status ("bima kitna hai / kam to nahi"), referral_info. Screens: "shaadi", "gifts". Gift voucher redeem: open the bill → 🎁 Voucher.`; }; }
  }
  window.SJY = { stockWorth, insStatus, vStatus, redeemVoucher, issueVoucher, refCodeFor, giftCardPdf, qrCardsPdf, staffSales };
})();
