/* =====================================================================
   Shivaa Jewels — "2050" pack, part 2
   1. Bill lock            — after N hours only the Owner changes / deletes a bill (server-enforced)
   2. Galti pakadne wala AI — extra checks before a bill is saved (party habits, typos, purity, rate)
   3. Roz ka cash milaan   — note counter in Close-the-day, who closed, history report, server alert
   4. Karigar ka hisaab    — score-card: gold out / in, real ghatt, labour, on-time, balance
   5. Mahine ka CA report  — one report (PDF / Excel) of the month + AI advice
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { name: 'Owner', role: 'owner' };
  const isOwner = () => !SITE || me().role === 'owner';
  const q$ = (s, r) => (r || document).querySelector(s);
  const F = (label, inner) => `<label class="f"><span>${label}</span>${inner}</label>`;
  const nrm = v => String(v == null ? '' : v).toLowerCase().trim();
  const strip = h => String(h || '').replace(/<[^>]+>/g, '');
  ['caNotes'].forEach(c => { if (typeof COLS !== 'undefined' && !COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const css = document.createElement('style'); document.head.appendChild(css); const addCss = t => { css.textContent += t; };
  const median = a => { const b = a.filter(x => isFinite(x)).sort((x, y) => x - y); if (!b.length) return null; const m = Math.floor(b.length / 2); return b.length % 2 ? b[m] : (b[m - 1] + b[m]) / 2; };

  /* ---------------------------------------------------------------
     1. Bill lock (the server is the real guard; this gives a friendly message first)
     --------------------------------------------------------------- */
  const LOCK = { hours: 24, cashMin: 100 };
  async function loadLock() { if (!SITE || !window.SJ_API_CALL) return; try { const r = await window.SJ_API_CALL('lock_status', {}); LOCK.hours = num(r.hours); LOCK.cashMin = num(r.cashMin) || 100; } catch (e) { /* not logged in yet */ } }
  (function wait() { if (!SITE) return; if (window.SJ_USER) loadLock(); else setTimeout(wait, 2500); })(); setInterval(() => { if (window.SJ_USER) loadLock(); }, 10 * 60 * 1000);
  function isLocked(v) { if (!v || !LOCK.hours) return false; const made = num(v.createdAt) || Date.parse(String(v.date || '') + 'T23:59:59+05:30') || Date.now(); return Date.now() - made >= LOCK.hours * 3600 * 1000; }
  window.SJX_LOCK = { isLocked, info: () => ({ ...LOCK }) };
  document.addEventListener('change', e => { if (e.target && e.target.matches && e.target.matches('[data-inv="quality"]') && typeof INV !== 'undefined' && INV) INV._qualityTouched = true; }, true);
  if (typeof openInvoice === 'function') {
    const OI = openInvoice;
    openInvoice = function (type, o) { const r = OI.apply(this, arguments); try { const preset = o && o.preset; if (INV && !INV.orig && (INV.type === 'estimate' || INV.type === 'estpurchase') && !(preset && preset.quality)) { INV.quality = 'kacha'; const sel = document.querySelector('[data-inv="quality"]'); if (sel) sel.value = 'kacha'; } } catch (e) { /* */ } return r; };
  }
  if (typeof persistInvoice === 'function') {
    const P0 = persistInvoice;
    persistInvoice = async function (st) {
      // an Estimate (kacha bill) goes to the Kacha book unless the person deliberately picked "Pakka"
      if (st && !st.orig && (st.type === 'estimate' || st.type === 'estpurchase') && st.quality !== 'kacha' && !st._qualityTouched) st.quality = 'kacha';
      if (SITE && !isOwner() && st && st.orig && isLocked(st.orig)) { const m = `🔒 Bill ${st.orig.no || ''} lock hai (${LOCK.hours} ghante se purana) — ise sirf Owner badal sakta hai. Payment jodna chalta hai.`; toast(m, 'err'); return { error: m }; }
      return P0.apply(this, arguments);
    };
  }
  function lockCard() {
    if (!SITE || !isOwner()) return '';
    const hrs = [[0, 'Band (koi lock nahi)'], [6, '6 ghante'], [12, '12 ghante'], [24, '24 ghante (recommended)'], [48, '2 din'], [72, '3 din'], [168, '7 din']];
    return `<div class="card" id="sjx-lock-card"><div class="card-h"><h3>🔒 Bill lock & cash milaan</h3></div><p class="small muted" style="margin-top:0">Bill banne ke itne ghante baad staff / manager use badal ya mita nahi sakte — sirf aap (Owner). Naya payment jodna chalta rehta hai. Lock todne ki koshish ka alert aapko aata hai. Ye niyam server par chalta hai, browser se bypass nahi hota.</p>
      <div class="two">${F('Bill lock kitne ghante baad', `<select class="sjx-lk-h">${opts(hrs.map(h => [String(h[0]), h[1]]), String(LOCK.hours))}</select>`)}${F('Cash milaan mein kitne ₹ ke farq par alert', `<input type="number" min="1" class="sjx-lk-c" value="${LOCK.cashMin}">`)}</div><div class="btns"><button type="button" class="btn primary" data-act="sjx-lk-save">Save</button></div></div>`;
  }
  { const V = VIEWDEF.setup; if (V && V.body) VIEWDEF.setup = { ...V, body() { return lockCard() + V.body.apply(V, arguments); } }; }
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act="sjx-lk-save"]'); if (!t) return; e.preventDefault(); const el = q$('#sjx-lock-card');
    try { t.disabled = true; const r = await window.SJ_API_CALL('lock_cfg', { hours: num(q$('.sjx-lk-h', el).value), cashMin: num(q$('.sjx-lk-c', el).value) || 100 }); LOCK.hours = r.hours; LOCK.cashMin = r.cashMin; toast(r.hours ? `🔒 Bill lock: ${r.hours} ghante` : 'Bill lock band'); } catch (er) { toast(er.message || 'Nahi hua', 'err'); } finally { t.disabled = false; }
  });

  /* ---------------------------------------------------------------
     2. Galti pakadne wala AI — more checks before saving a bill
     --------------------------------------------------------------- */
  function partyHistory(type, partyId, excludeId) {
    const sale = isSaleT(type) || type === 'metal', buy = isBuy(type);
    return S.invoices.filter(v => v.partyId === partyId && v.id !== excludeId && (sale ? !isBuy(v.type) : buy ? isBuy(v.type) : true)).sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 60);
  }
  function extraChecks(st) {
    const W = []; const type = st.type; const party = typeof partyFor === 'function' ? partyFor(type, st.partyId) : null; if (!party) return W;
    const hist = partyHistory(type, party.id, st.orig && st.orig.id); const items = (st.items || []).filter(it => num(it.gross) > 0);
    const nm = it => `Item ${(st.items || []).indexOf(it) + 1} (${it.category || '?'} ${it.purity || ''})`;
    const AI = '🤖 ';
    items.forEach(it => {
      const same = hist.flatMap(v => (v.items || []).filter(x => nrm(x.category) === nrm(it.category) && nrm(x.purity) === nrm(it.purity)));
      // usual wastage / labour for this party + item
      if (same.length >= 3 && it.wastage !== '' && it.wastage != null) { const mw = median(same.map(x => num(x.wastage))); if (mw != null && Math.abs(num(it.wastage) - mw) >= 2) W.push(['warn', `${AI}${nm(it)}: <b>${esc(party.name)}</b> ko aam taur par <b>${r2(mw)}%</b> wastage lagta hai (pichhle ${same.length} bill), is bill mein <b>${r2(num(it.wastage))}%</b>.`]); }
      if (same.length >= 3 && num(it.labour) > 0) { const ml = median(same.map(x => num(x.labour)).filter(x => x > 0)); if (ml && Math.abs(num(it.labour) - ml) / ml >= 0.3) W.push(['warn', `${AI}${nm(it)}: majoori aam taur par <b>₹${r2(ml)}/g</b>, is bill mein <b>₹${r2(num(it.labour))}/g</b>.`]); }
      // matrix rule
      if (typeof findRule === 'function' && it.wastage !== '' && it.wastage != null) { try { const rule = findRule(party, it.category, it.purity, it.making); if (rule && rule.wastage !== '' && rule.wastage != null && Math.abs(num(rule.wastage) - num(it.wastage)) >= 0.5) W.push(['warn', `${AI}${nm(it)}: party ki rate-list mein wastage <b>${num(rule.wastage)}%</b> likha hai, bill mein <b>${num(it.wastage)}%</b>.`]); } catch (e) { /* */ } }
      // weight typo
      const g = num(it.gross); const usualG = median(same.map(x => num(x.gross)).filter(x => x > 0));
      if (usualG && same.length >= 3 && g >= usualG * 8 && !/coin|biscuit|bar|bullion/i.test(it.category || '')) W.push(['warn', `${AI}${nm(it)}: wazan <b>${g3(g)}</b> — is party ka aam ${esc(it.category || '')} lagbhag <b>${g3(usualG)}</b> hota hai. Kahin ${g3(g / 10)} to nahi likhna tha?`]);
      else if (g >= 1000 && !/coin|biscuit|bar|bullion|silver/i.test((it.category || '') + ' ' + (it.purity || ''))) W.push(['warn', `${AI}${nm(it)}: wazan <b>${g3(g)}</b> bahut zyada lag raha hai — ek baar dekh lijiye.`]);
      // purity vs tunch
      const pt = (typeof PUR !== 'undefined' && PUR[it.purity] || {}).t; if (pt && num(it.tunch) > 0 && Math.abs(num(it.tunch) - pt) >= 3) W.push(['warn', `${AI}${nm(it)}: purity <b>${esc(it.purity)}</b> ka tunch ~${pt}% hota hai, bill mein tunch <b>${num(it.tunch)}%</b> — sahi hai?`]);
      if (num(it.less) > 0 && num(it.less) >= g * 0.5 && num(it.less) < g) W.push(['warn', `${AI}${nm(it)}: less / stone <b>${g3(num(it.less))}</b> — gross ka aadha ya zyada. Sahi hai?`]);
    });
    // price per gram vs last 30 days for the same category
    if (isSaleT(type)) { const ref = S.invoices.filter(v => isSaleT(v.type) && v.date >= addDays(todayStr(), -30));
      items.forEach(it => { const c = calcItem(it, type); if (!(c.net > 0) || !(c.amount > 0)) return; const peers = ref.flatMap(v => (v.items || []).filter(x => nrm(x.category) === nrm(it.category) && nrm(x.purity) === nrm(it.purity)).map(x => { const k = calcItem(x, v.type); return k.net > 0 ? k.amount / k.net : 0; })).filter(x => x > 0);
        if (peers.length >= 5) { const m = median(peers), mine = c.amount / c.net; if (m && Math.abs(mine - m) / m >= 0.15) W.push(['warn', `${AI}${nm(it)}: <b>${inr(mine)}/g</b> pad raha hai — pichhle 30 din mein isi maal ka aam daam <b>${inr(m)}/g</b> (${mine > m ? '+' : ''}${Math.round((mine - m) / m * 100)}%).`]); } });
      }
    // rates not updated today
    const s = settings(); if (isSaleT(type) && s.ratesUpdated && s.ratesUpdated !== todayStr()) W.push(['warn', `${AI}Aaj ka sone-chandi ka rate abhi update nahi hua — bill <b>${fmtD(s.ratesUpdated)}</b> ke rate par ban raha hai.`]);
    // locked bill edit by staff
    if (SITE && !isOwner() && st.orig && isLocked(st.orig)) W.push(['stop', `🔒 Ye bill ${LOCK.hours} ghante se purana hai — sirf Owner badal sakta hai.`]);
    return W;
  }
  if (typeof advGuard === 'function') {
    const G0 = advGuard;
    advGuard = function (st) { let W = []; try { W = G0.apply(this, arguments) || []; } catch (e) { console.error(e); } try { extraChecks(st).forEach(w => { if (!W.some(x => x[1] === w[1])) W.push(w); }); } catch (e) { console.error(e); } return W; };
  }
  window.SJX_BILL_CHECK = st => { try { return (typeof advGuard === 'function' ? advGuard(st) : extraChecks(st)).map(w => (w[0] === 'stop' ? '⛔ ' : '') + strip(w[1])); } catch (e) { return []; } };

  /* ---------------------------------------------------------------
     3. Roz ka cash milaan — note counter, who closed, history
     --------------------------------------------------------------- */
  const DENOMS = [500, 200, 100, 50, 20, 10, 5, 2, 1];
  const PENDING_DEN = {};
  function mountCounter() {
    const f = q$('form[data-form="closing"]'); if (!f || q$('.sjx-den-btn', f)) return;
    const inp = f.querySelector('[name="counted"]'); if (!inp) return;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'btn sm sjx-den-btn'; b.dataset.act = 'sjx-den'; b.textContent = '🧮 Note gino';
    (inp.closest('label') || inp.parentNode).appendChild(b);
    const cl = S.closings.find(c => c.date === f.dataset.date); if (cl && cl.by) { const p = document.createElement('div'); p.className = 'small muted'; p.style.marginTop = '8px'; p.textContent = `Band kiya: ${cl.by}${cl.closedAt ? ' · ' + new Date(cl.closedAt).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : ''}${cl.denoms ? ' · note gine gaye' : ''}`; f.appendChild(p); }
  }
  setInterval(mountCounter, 1000);
  document.addEventListener('click', e => {
    const t = e.target.closest && e.target.closest('[data-act="sjx-den"]'); if (!t) return; e.preventDefault();
    const f = t.closest('form'); const d = f.dataset.date; const prev = PENDING_DEN[d] || (S.closings.find(c => c.date === d) || {}).denoms || {};
    const el = openModal(`${mHead('🧮 Galle ke note gino', fmtD(d))}<form class="m-body sjx-den" novalidate>${DENOMS.map(n => `<label class="sjx-den-r"><span>₹${n}${n <= 10 ? ' ' + (n < 10 ? 'sikka' : 'note/sikka') : ''}</span><span>×</span><input type="number" min="0" step="1" inputmode="numeric" name="d${n}" value="${num(prev[n]) || ''}"><b class="sjx-den-v">₹0</b></label>`).join('')}<label class="sjx-den-r"><span>Khule / baaki</span><span></span><input type="number" min="0" step="1" name="dx" value="${num(prev.x) || ''}"><b class="sjx-den-v"></b></label><div class="sjx-den-tot">Kul: <b>₹0</b></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Ye rakam bharo</button></div></form>`, { small: true });
    const form = q$('form', el);
    const calc = () => { let tot = 0; DENOMS.forEach(n => { const v = Math.max(0, Math.round(num(form['d' + n].value))) * n; tot += v; form['d' + n].closest('label').querySelector('.sjx-den-v').textContent = inr(v); }); tot += num(form.dx.value); q$('.sjx-den-tot b', form).textContent = inr(tot); return tot; };
    form.addEventListener('input', calc); calc();
    form.addEventListener('submit', ev => { ev.preventDefault(); const tot = calc(); const den = {}; DENOMS.forEach(n => { const v = Math.round(num(form['d' + n].value)); if (v) den[n] = v; }); if (num(form.dx.value)) den.x = num(form.dx.value); PENDING_DEN[d] = den;
      const inp = f.querySelector('[name="counted"]'); inp.value = r2(tot); inp.dispatchEvent(new Event('input', { bubbles: true })); inp.dispatchEvent(new Event('change', { bubbles: true })); closeModal(el); toast('Gina hua cash: ' + inr(tot)); });
  });
  addCss('.sjx-kcard .tw{overflow-x:auto;max-width:100%}.sjx-kcard table{min-width:560px}');
  addCss(`.sjx-den-btn{margin-top:6px}.sjx-den-r{display:grid;grid-template-columns:1fr 18px 90px 90px;gap:8px;align-items:center;margin:6px 0}.sjx-den-r input{text-align:right}.sjx-den-v{text-align:right;font-variant-numeric:tabular-nums}.sjx-den-tot{text-align:right;font-size:16px;margin:10px 0 4px}`);
  if (typeof save === 'function') {
    const SV0 = save;
    save = async function (col, obj, o) {
      if (col === 'closings' && obj && typeof obj === 'object' && obj.date) { obj = { ...obj, by: me().name, byRole: me().role }; if (PENDING_DEN[obj.date]) { obj.denoms = PENDING_DEN[obj.date]; delete PENDING_DEN[obj.date]; } }
      return SV0.call(this, col, obj, o);
    };
  }
  function cashMilaan(a, b) {
    const L = S.closings.filter(c => (!a || c.date >= a) && (!b || c.date <= b)).sort((x, y) => String(y.date).localeCompare(String(x.date)));
    const active = new Set(); S.invoices.forEach(v => { if ((!a || v.date >= a) && (!b || v.date <= b) && v.date < todayStr()) active.add(v.date); }); S.expenses.forEach(x => { if ((!a || x.date >= a) && (!b || x.date <= b) && x.date < todayStr()) active.add(x.date); });
    const closed = new Set(L.map(c => c.date)); const missing = [...active].filter(d => !closed.has(d)).sort().reverse();
    return { L, missing, short: r2(sum(L.filter(c => num(c.diff) < 0), c => -num(c.diff))), excess: r2(sum(L.filter(c => num(c.diff) > 0), c => num(c.diff))) };
  }

  /* ---------------------------------------------------------------
     4. Karigar ka hisaab & score
     --------------------------------------------------------------- */
  function karigarStats(a, b) {
    const t = todayStr(); const K = {};
    S.jobs.filter(j => j.status !== 'Cancelled' && (!a || String(j.issueDate || '') >= a || j.status === 'Issued') && (!b || String(j.issueDate || '') <= b)).forEach(j => {
      const k = K[j.karigarId || j.karigarName] || (K[j.karigarId || j.karigarName] = { name: j.karigarName || '—', doneFine: 0, jobs: 0, open: 0, late: 0, issuedG: 0, issuedFine: 0, recvG: 0, scrapG: 0, credited: 0, realLoss: 0, allowed: 0, labour: 0, onTime: 0, done: 0, days: [], list: [] });
      const c = jobCalc(j); k.jobs++; k.issuedG = r3(k.issuedG + num(j.issuedWt)); k.issuedFine = r3(k.issuedFine + c.issuedFine);
      if (j.status === 'Issued') { k.open++; if (j.dueDate && j.dueDate < t) k.late++; }
      if (c.received) { k.done++; k.doneFine = r3(k.doneFine + c.issuedFine); k.recvG = r3(k.recvG + num(j.receivedWt)); k.scrapG = r3(k.scrapG + num(j.scrapWt)); k.credited = r3(k.credited + c.credited); k.labour = r2(k.labour + c.labourAmt);
        const back = r3((num(j.receivedWt) + num(j.scrapWt)) * c.t / 100); k.realLoss = r3(k.realLoss + (c.issuedFine - back)); k.allowed = r3(k.allowed + num(j.receivedWt) * num(j.wastage) / 100);
        if (j.receivedDate && j.dueDate) { if (j.receivedDate <= j.dueDate) k.onTime++; } else k.onTime++;
        if (j.receivedDate && j.issueDate) k.days.push(Math.max(0, (Date.parse(j.receivedDate) - Date.parse(j.issueDate)) / 864e5)); }
      k.list.push({ no: j.no, issued: j.issueDate, due: j.dueDate, recv: j.receivedDate || '', status: j.status, item: [j.category, j.purity].filter(Boolean).join(' '), out: num(j.issuedWt), back: num(j.receivedWt) + num(j.scrapWt), bal: c.balance, labour: c.labourAmt });
    });
    return Object.values(K).map(k => {
      const doneFine = k.doneFine;
      const realPct = doneFine > 0 ? r2(k.realLoss / doneFine * 100) : 0; const allowPct = doneFine > 0 ? r2(k.allowed / doneFine * 100) : 0;
      const onTimePct = k.done ? Math.round(k.onTime / k.done * 100) : null; const balance = r3(sum(k.list, x => x.bal > 0 ? x.bal : 0));
      let score = 100; if (onTimePct != null) score -= (100 - onTimePct) * 0.4; score -= Math.max(0, realPct - allowPct) * 12; score -= k.late * 6; if (k.issuedFine > 0) score -= Math.min(20, balance / Math.max(1, k.issuedFine) * 40);
      score = Math.max(0, Math.min(100, Math.round(score)));
      return { name: k.name, jobs: k.jobs, open: k.open, late: k.late, issued_g: k.issuedG, issuedFine_g: k.issuedFine, received_g: k.recvG, scrap_g: k.scrapG, fineBalanceWithKarigar_g: balance, realGhatt_g: k.realLoss, realGhattPct: realPct, allowedWastagePct: allowPct, labourPaid: k.labour, onTimePct, avgDays: k.days.length ? Math.round(k.days.reduce((x, y) => x + y, 0) / k.days.length) : null, score, jobsList: k.list };
    }).sort((x, y) => y.score - x.score);
  }
  function scoreTag(s) { return s >= 85 ? '🟢 Bharosemand' : s >= 65 ? '🟡 Theek' : '🔴 Dhyan dein'; }
  function karigarCard() {
    const R = karigarStats(); if (!R.length) return '';
    return `<div class="card sjx-kcard"><div class="card-h"><h3>🧾 Karigar score-card</h3>${window.SJ_REPORTS ? '<button type="button" class="btn sm" data-act="sjx-k-rep">Poora hisaab</button>' : ''}</div><div class="tw"><table class="fit"><tr><th>Karigar</th><th class="r">Score</th><th class="r">Fine baaki</th><th class="r">Asli ghatt</th><th class="r">Time par</th><th class="r">Khule / late</th><th class="r">Majoori</th></tr>${R.map(k => `<tr><td><b>${esc(k.name)}</b><div class="small muted">${scoreTag(k.score)}</div></td><td class="r"><b>${k.score}</b></td><td class="r ${k.fineBalanceWithKarigar_g > 0.0005 ? 'red' : ''}">${g3(k.fineBalanceWithKarigar_g)}</td><td class="r">${g3(k.realGhatt_g)} <span class="small muted">(${k.realGhattPct}% / chhoot ${k.allowedWastagePct}%)</span></td><td class="r">${k.onTimePct == null ? '—' : k.onTimePct + '%'}</td><td class="r">${k.open} / <span class="${k.late ? 'red' : ''}">${k.late}</span></td><td class="r">${inr(k.labourPaid)}</td></tr>`).join('')}</table></div><p class="small muted" style="margin:6px 0 0">Asli ghatt = diya fine − (wapas maal + scrap ka fine). Chhoot = jo wastage aapne di. Score: time par kaam, ghatt chhoot se zyada, late jobs aur pada hua sona dekh kar.</p></div>`;
  }
  { const V = VIEWDEF.karigar; if (V && V.body) VIEWDEF.karigar = { ...V, body() { const h = V.body.apply(V, arguments); return (ui.kTab === 'hallmark' ? '' : karigarCard()) + h; } }; }
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act="sjx-k-rep"],[data-act="sjx-ca-open"]'); if (!t) return; e.preventDefault(); if (t.dataset.act === 'sjx-k-rep') window.SJ_REPORTS.open('karigar_score', 'all'); else window.SJ_REPORTS.open('ca_month', 'lastmonth'); });

  /* ---------------------------------------------------------------
     5. Mahine ka CA report (composite) + AI advice
     --------------------------------------------------------------- */
  const CA_PARTS = [['pnl', '1. Profit & Loss'], ['gstr3b', '2. GST (3B) — tax payable'], ['itc', '3. Purchase GST (ITC)'], ['cashbank', '4. Cash & bank'], ['outstanding', '5. Udhaari — party outstanding'], ['payables', '6. Supplier payable'], ['stockval', '7. Stock & valuation'], ['expense', '8. Kharche'], ['cash2l', '9. Cash ₹2 lakh + PAN'], ['cash40a3', '10. Cash payment > ₹10,000 (40A(3))']];
  function caBuild(r) {
    const H = window.SJ_REPORTS.h; const sections = []; const summary = []; const facts = {};
    const note = S.caNotes.find(n => n.id === 'ca_' + r.a + '_' + r.b);
    if (note && note.text) sections.push(H.sec('🤖 AI ki salah (' + new Date(note.at).toLocaleDateString('en-IN') + ')', [H.C('Salah', 's')], String(note.text).split('\n').filter(x => x.trim()).map(x => [x.replace(/^[-•*]\s*/, '• ')])));
    CA_PARTS.forEach(([id, title]) => {
      let x = null; try { x = window.SJ_REPORTS.build(id, r.a, r.b); } catch (e) { x = null; }
      if (!x) return;
      (x.summary || []).slice(0, 4).forEach(s => { facts[title + ' · ' + strip(s[0])] = strip(s[1]); });
      if (['pnl', 'gstr3b', 'cashbank', 'outstanding', 'stockval'].includes(id)) (x.summary || []).slice(0, 2).forEach(s => summary.push([title.replace(/^\d+\.\s*/, '').split(' — ')[0] + ': ' + strip(s[0]), s[1]]));
      const secs = (x.sections || []).filter(s => (s.rows || []).length);
      if (!secs.length) { sections.push(H.sec(title, [H.C('Note', 's')], [['Is period mein koi entry nahi']])); return; }
      secs.slice(0, 3).forEach((s, k) => sections.push({ ...s, title: title + (s.title ? ' — ' + s.title : k ? ' (' + (k + 1) + ')' : ''), rows: (s.rows || []).slice(0, 150) }));
    });
    const cm = cashMilaan(r.a, r.b);
    sections.push(H.sec('11. Roz ka cash milaan', [H.C('Date', 'd'), H.C('Hisaab', 'inr'), H.C('Gina', 'inr'), H.C('Farq', 'inr'), H.C('Kisne', 's'), H.C('Note', 's')], cm.L.map(c => [c.date, num(c.expected), c.counted === '' ? '' : num(c.counted), c.diff === '' ? '' : num(c.diff), c.by || '', c.note || '']), { note: cm.missing.length ? `${cm.missing.length} din band nahi kiye gaye: ${cm.missing.slice(0, 10).map(fmtD).join(', ')}` : 'Saare din band kiye gaye.' }));
    facts['Cash milaan · kam'] = inr(cm.short); facts['Cash milaan · band nahi kiye din'] = cm.missing.length;
    const al = (S.alerts || []).filter(x => { const d = new Date(x.at + 19800000).toISOString().slice(0, 10); return d >= r.a && d <= r.b; });
    if (isOwner() && al.length) sections.push(H.sec('12. Shaq wali activity', [H.C('Kab', 's'), H.C('Kisne', 's'), H.C('Kya', 's')], al.map(x => [new Date(x.at).toLocaleString('en-IN'), x.by || '', x.text])));
    const s = settings();
    return { summary: summary.slice(0, 8), sections, facts, note: `${s.legal || s.firm || ''}${s.gstin ? ' · GSTIN ' + s.gstin : ''} · Ye report software ke records se bani hai — CA se milaan zaroor karwaiye.`,
      tools: SITE ? `<button type="button" class="btn sm" data-act="sjx-ca-ai" data-a="${esc(r.a)}" data-b="${esc(r.b)}">🤖 ${note ? 'AI salah dobara banao' : 'AI ki salah jodo'}</button><span class="small muted">PDF / Excel ke button se CA ko bhejiye</span>` : '' };
  }
  if (window.SJ_REPORTS) {
    const H = window.SJ_REPORTS.h;
    window.SJ_REPORTS.add('ca_month', 'ca', '📁 Mahine ka CA report (sab ek jagah)', 'P&L, GST, ITC, cash-bank, udhaari, payable, stock, kharche, cash niyam, cash milaan, alerts + AI ki salah — ek PDF / Excel', { period: 'range', defRp: 'lastmonth', build: r => { const x = caBuild(r); delete x.facts; return x; } });
    window.SJ_REPORTS.addCa('00 Mahine ka CA report', 'ca_month');
    window.SJ_REPORTS.add('karigar_score', 'metal', 'Karigar ka hisaab & score-card', 'Har karigar: diya / wapas sona, asli ghatt vs chhoot, majoori, time par %, khule kaam, pada hua fine, score', { period: 'range', defRp: 'all', build(r) {
      const R = karigarStats(r.a, r.b);
      return { summary: [['Karigar', R.length], ['Karigar ke paas fine', g3(sum(R, k => k.fineBalanceWithKarigar_g))], ['Asli ghatt', g3(sum(R, k => k.realGhatt_g))], ['Majoori', inr(sum(R, k => k.labourPaid))]],
        sections: [H.sec('Score-card', [H.C('Karigar', 's'), H.C('Score', 'n'), H.C('Status', 's'), H.C('Jobs', 'n'), H.C('Khule', 'n'), H.C('Late', 'n'), H.C('Diya g', 'g'), H.C('Diya fine', 'g'), H.C('Wapas g', 'g'), H.C('Fine baaki', 'g'), H.C('Asli ghatt g', 'g'), H.C('Ghatt %', 'pct'), H.C('Chhoot %', 'pct'), H.C('Time par %', 's'), H.C('Avg din', 's'), H.C('Majoori', 'inr')],
          R.map(k => [k.name, k.score, scoreTag(k.score), k.jobs, k.open, k.late, k.issued_g, k.issuedFine_g, k.received_g, k.fineBalanceWithKarigar_g, k.realGhatt_g, k.realGhattPct, k.allowedWastagePct, k.onTimePct == null ? '—' : k.onTimePct, k.avgDays == null ? '—' : k.avgDays, k.labourPaid]))]
          .concat(R.map(k => H.sec(k.name + ' — jobs', [H.C('Job', 's'), H.C('Item', 's'), H.C('Diya', 'd'), H.C('Due', 'd'), H.C('Wapas', 'd'), H.C('Status', 's'), H.C('Diya g', 'g'), H.C('Wapas g', 'g'), H.C('Fine baaki', 'g'), H.C('Majoori', 'inr')], k.jobsList.map(j => [j.no, j.item, j.issued, j.due, j.recv, j.status, j.out, j.back, j.bal, j.labour])))),
        note: 'Asli ghatt = diya fine − (wapas maal + scrap) ka fine. Chhoot = aapki di hui wastage. Score 100 mein se.' }; } });
    window.SJ_REPORTS.add('cash_milaan', 'cash', 'Roz ka cash milaan (galla)', 'Har din: hisaab se cash, gina hua, farq, kisne band kiya, note gine — aur kaun se din band nahi hue', { period: 'range', defRp: 'month', build(r) {
      const c = cashMilaan(r.a, r.b);
      return { summary: [['Din band kiye', c.L.length], ['Band nahi kiye', c.missing.length], ['Kul kam', inr(c.short)], ['Kul zyada', inr(c.excess)]],
        warn: c.missing.length ? [`${c.missing.length} din band nahi kiye: ${c.missing.slice(0, 12).map(fmtD).join(', ')}`] : [],
        sections: [H.sec('', [H.C('Date', 'd'), H.C('Opening', 'inr'), H.C('Cash in', 'inr'), H.C('Cash out', 'inr'), H.C('Hisaab', 'inr'), H.C('Gina', 'inr'), H.C('Farq', 'inr'), H.C('Kisne', 's'), H.C('Note gine', 's'), H.C('Note', 's')],
          c.L.map(x => [x.date, num(x.opening), num(x.cashIn), num(x.cashOut), num(x.expected), x.counted === '' ? '' : num(x.counted), x.diff === '' ? '' : num(x.diff), x.by || '', x.denoms ? Object.entries(x.denoms).map(([k, v]) => (k === 'x' ? 'khule ' + v : k + '×' + v)).join(' ') : '', x.note || '']))] }; } });
  }
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act="sjx-ca-ai"]'); if (!t) return; e.preventDefault();
    const a = t.dataset.a, b = t.dataset.b; t.disabled = true; const old = t.textContent; t.textContent = '🤖 AI soch raha hai…';
    try {
      const x = caBuild({ a, b, label: '' }); const s = settings();
      const prompt = `You are an experienced Indian chartered accountant and jewellery-business advisor. Firm: ${s.legal || s.firm} (gold & silver jewellery wholesale + retail, Rajasthan). Period ${a} to ${b}. Key figures from the books (JSON): ${JSON.stringify(x.facts).slice(0, 9000)}
Write 5 to 8 short, specific action points in simple Hinglish for the owner and his CA: profit & margin, GST payable / ITC, cash-handling compliance (40A(3), 269ST, 2-lakh PAN), receivables to chase, stock, cash-drawer differences, anything unusual. Use the numbers. No generic advice. Reply ONLY JSON: {"reply":"- point\\n- point ..."}`;
      const r = await window.SJ_AI.ask({ messages: [{ role: 'user', content: prompt }], tools: [] });
      if (r.notSet) throw new Error('AI key nahi hai — Setup mein daaliye');
      let txt = String(r.text || ''); try { const i = txt.indexOf('{'), j = txt.lastIndexOf('}'); if (i >= 0) txt = JSON.parse(txt.slice(i, j + 1)).reply || txt; } catch (er) { /* plain text */ }
      if (!txt.trim()) throw new Error('AI ne jawab nahi diya');
      await save('caNotes', { id: 'ca_' + a + '_' + b, from: a, to: b, text: txt.trim(), at: Date.now(), by: me().name });
      toast('✓ AI ki salah report mein jud gayi'); renderView(true);
    } catch (er) { toast(er.message || 'AI se nahi hua', 'err'); t.disabled = false; t.textContent = old; }
  });
  function caDashCard() {
    if (!isOwner() || !window.SJ_REPORTS) return ''; const d = +todayStr().slice(8, 10); if (d > 10) return '';
    const lm = rangeFor('lastmonth'); const done = S.caNotes.some(n => n.id === 'ca_' + lm.a + '_' + lm.b);
    return `<div class="card sjx-cad"><div class="card-h"><h3>📁 ${esc(lm.label || 'Pichhle mahine')} ka CA report taiyaar</h3><button type="button" class="btn sm primary" data-act="sjx-ca-open">Kholo</button></div><p class="small muted" style="margin:0">P&L, GST, udhaari, stock, cash milaan — ek PDF / Excel mein.${done ? ' AI ki salah judi hui hai.' : ' "AI ki salah jodo" dabakar CA ke liye points bhi jodiye.'}</p></div>`;
  }
  { const V = VIEWDEF.dashboard; if (V && V.body) VIEWDEF.dashboard = { ...V, body() { return caDashCard() + V.body.apply(V, arguments); } }; }

  /* ---------------------------------------------------------------
     AI tools + rules for these
     --------------------------------------------------------------- */
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    const tool = (name, description, props, req, fn, label) => ({ name, description, inputSchema: { type: 'object', properties: props, required: req }, execute: async input => { if (typeof setChatStatus === 'function') setChatStatus(label); return fn(input || {}); } });
    agentTools = function () {
      const L = T0.apply(this, arguments); const add = t => { if (!L.some(x => x.name === t.name)) L.push(t); };
      add(tool('karigar_hisaab', 'Karigar score-card and ledger: per karigar gold issued / received, fine still with the karigar, real ghatt vs allowed wastage, labour, on-time %, open & late jobs, score. Optional from/to (YYYY-MM-DD) and name.', { name: { type: 'string' }, from: { type: 'string' }, to: { type: 'string' } }, [], i => { let R = karigarStats(i.from || '', i.to || ''); if (i.name) R = R.filter(k => nrm(k.name).includes(nrm(i.name))); return R.map(k => ({ ...k, jobsList: k.jobsList.slice(0, 25) })); }, 'Karigar ka hisaab dekh raha hoon…'));
      add(tool('cash_milaan', 'Cash drawer: today\'s expected cash (opening + cash in − cash out) and the recent day-closings with counted cash, difference, who closed, and days not closed. Optional from/to.', { from: { type: 'string' }, to: { type: 'string' } }, [], i => { const t = todayStr(); let today = null; try { const c = dayClosing(t); today = { opening: c.opening, cashIn: c.cashIn, cashOut: c.cashOut, expected: c.expected, closed: !!c.closed }; } catch (e) { /* */ } const m = cashMilaan(i.from || addDays(t, -30), i.to || t); return { today, short: m.short, excess: m.excess, notClosedDays: m.missing.slice(0, 20), closings: m.L.slice(0, 20).map(c => ({ date: c.date, expected: c.expected, counted: c.counted, diff: c.diff, by: c.by || '', note: c.note || '' })) }; }, 'Galla dekh raha hoon…'));
      add(tool('bill_lock_info', 'Bill lock setting: after how many hours a bill is locked (only the Owner can change / delete it; payments can still be added).', {}, [], () => ({ hours: LOCK.hours, cashAlertMin: LOCK.cashMin }), 'Lock dekh raha hoon…'));
      add(tool('ca_month_report', 'Month-end CA report facts for a period (default last month): P&L, GST, ITC, cash & bank, receivables, payables, stock, expenses, cash-rule registers, cash milaan. Use to brief the owner / CA; open it with open_screen reportId "ca_month".', { from: { type: 'string' }, to: { type: 'string' } }, [], i => { const r = i.from && i.to ? { a: i.from, b: i.to } : rangeFor('lastmonth'); return { from: r.a, to: r.b, facts: caBuild({ a: r.a, b: r.b, label: '' }).facts }; }, 'CA report bana raha hoon…'));
      return L;
    };
    const R0 = agentRules;
    agentRules = function (o) { return R0.apply(this, arguments) + `
MISTAKE-CATCHING: when you prepare a bill, check_entry also returns the app's bill checks (party's usual wastage / labour, rate-list mismatch, weight typos, purity vs tunch, price per gram vs last 30 days, rates not updated, duplicates, cash limits, credit limit). Tell the owner about each warning in one short line before they save.
MORE TOOLS: karigar_hisaab ("karigar ka hisaab", "kiske paas kitna sona", "kaun sa karigar achha"), cash_milaan ("galla", "aaj kitna cash hona chahiye", "cash kam kyun"), bill_lock_info, ca_month_report ("CA ko kya bhejun", "mahine ka report").`; };
  }
  /* PDFs use a built-in font without emoji — drop emoji so no "??" appears in any PDF */
  try {
    if (typeof Pdf === 'function' && !Pdf.prototype.__sjxEmoji) {
      const EMO = /[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}\u{20E3}]/gu;
      const cl = s => { if (typeof s !== 'string' || !EMO.test(s)) { EMO.lastIndex = 0; return s; } EMO.lastIndex = 0; return s.replace(EMO, '').replace(/^\s+/, '').replace(/ {2,}/g, ' '); };
      ['text', 'width', 'wrap'].forEach(m => { const o = Pdf.prototype[m]; if (typeof o === 'function') Pdf.prototype[m] = function (s, ...r) { return o.call(this, cl(s), ...r); }; });
      Pdf.prototype.__sjxEmoji = true;
    }
  } catch (e) { console.error(e); }
  /* bill checks also reach the AI's check_entry */
  window.SJX_EXTRA_CHECKS = st => window.SJX_BILL_CHECK(st);
})();
