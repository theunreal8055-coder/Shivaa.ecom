<?php
/* Shivaa Jewels — customer khata page. Opened by the secret link the shop shares (portal.php?t=…).
   The "Mujhe ye chahiye" buttons post back here (each form carries a signed, same-day nonce). */
$_GET['a'] = 'portal';
if (!isset($_SERVER['REQUEST_METHOD']) || ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'GET')) $_SERVER['REQUEST_METHOD'] = 'GET';
require __DIR__ . '/sj-api.php';
