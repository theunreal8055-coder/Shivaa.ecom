<?php
/* =====================================================================
   Shivaa Jewels — website settings
   ---------------------------------------------------------------------
   Is file ko sirf tabhi badliye jab zaroorat ho.
   ===================================================================== */
if (!defined('SJ')) { http_response_code(404); exit; }

return [
    // Pehli baar website kholne par password banane ke liye ye code chahiye.
    'setup_code' => 'B3TP-FS9G',

    // Data kahan save ho:
    //   'sqlite' = koi setup nahi chahiye (default, zyada tar hosting par chalta hai)
    //   'mysql'  = agar hosting SQLite support nahi karti, to cPanel/hPanel mein
    //              ek MySQL database banakar neeche ki details bhariye.
    'driver' => 'sqlite',

    // SQLite file (naam jaan-boojh kar random rakha gaya hai — ise mat badliye).
    'sqlite_file' => __DIR__ . '/sj-data/sj-1f0dacd89946a1283a0139cd.sqlite',

    // MySQL details (sirf 'driver' => 'mysql' hone par use hongi)
    'mysql_host' => 'localhost',
    'mysql_db'   => '',
    'mysql_user' => '',
    'mysql_pass' => '',

    // Login kitne din tak yaad rahe (har device par)
    'login_days' => 90,

    // Suraksha: login sirf https:// par hota hai. SSL lagne se pehle sirf
    // testing ke liye true kar sakte hain — phir wapas false kar dijiye.
    'allow_http' => false,

    // AI Assistant (website): key Setup → "AI Assistant" mein daaliye. Yahan sirf model badal sakte hain.
    'ai_model'       => 'claude-sonnet-5-5',
    'ai_model_quick' => 'claude-haiku-5-5',
];
