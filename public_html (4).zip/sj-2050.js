/* =====================================================================
   Shivaa Jewels — "2050" pack
   1. Photo se bill        — photo of a bill / parcha → AI reads it → draft bill (owner checks & saves)
   2. Photo se stock khoj  — photo of a piece → visual match against Vault photos (+ AI category)
   3. Awaaz se bill        — voice + check_entry: AI asks for anything missing before a draft
   4. AI controls the app  — new actions: receive / pay money, order status, bullion buy, dates
   5. Customer portal      — secret link per customer: khata, bills, payments, orders, scheme
   6. Shaq wali activity   — server-made alerts (bill delete / edit, rate change, night entries)
   7. Janamdin / saalgirah — today's wishes with offer + scheme line, sent log
   8. Order tracking       — status timeline + one-tap WhatsApp update to the customer
   9. Stock ki salah       — dead / slow / fast / reorder advice (report + AI tool)
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { name: 'Owner', role: 'owner' };
  const isOwner = () => !SITE || me().role === 'owner';
  const q$ = (s, r) => (r || document).querySelector(s);
  const F = (label, inner, cls) => `<label class="f${cls ? ' ' + cls : ''}"><span>${label}</span>${inner}</label>`;
  const nrm = v => String(v == null ? '' : v).toLowerCase().trim();
  const NEWC = ['alerts', 'wishLog'];
  NEWC.forEach(c => { if (typeof COLS !== 'undefined' && !COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const css = document.createElement('style'); document.head.appendChild(css);
  const addCss = t => { css.textContent += t; };

  /* ---------------------------------------------------------------
     Photo helpers
     --------------------------------------------------------------- */
  function loadImg(src) { return new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('Photo khul nahi payi')); im.src = src; }); }
  function fileToDataUrl(file) { return new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(new Error('Photo padh nahi paye')); r.readAsDataURL(file); }); }
  async function compress(file, max, q) {
    if (!file || !/^image\//.test(file.type || 'image/')) throw new Error('Sirf photo (JPG / PNG) chuniye');
    const im = await loadImg(await fileToDataUrl(file)); const k = Math.min(1, (max || 1600) / Math.max(im.naturalWidth, im.naturalHeight));
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(im.naturalWidth * k)); c.height = Math.max(1, Math.round(im.naturalHeight * k));
    const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height);
    const url = c.toDataURL('image/jpeg', q || 0.82); return { url, mime: 'image/jpeg', b64: url.split(',')[1], w: c.width, h: c.height };
  }
  function pickPhoto(capture) {
    return new Promise(res => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; if (capture) i.setAttribute('capture', 'environment'); i.style.display = 'none';
      i.addEventListener('change', () => { res(i.files && i.files[0] ? i.files[0] : null); i.remove(); }, { once: true }); document.body.appendChild(i); i.click(); });
  }

  /* ---------------------------------------------------------------
     1 + 3. Chat: attach a photo (bill / parcha / jewellery) — sent with the next question only
     --------------------------------------------------------------- */
  let PIMG = null, TURN_IMG = null;
  window.SJX_TAKE_IMG = () => { const x = PIMG; if (x) { TURN_IMG = x; PIMG = null; paintChip(); } return x; };
  const DEFAULT_PHOTO_Q = 'Is photo ko dekho: agar ye bill / parcha / receipt hai to poori entry bana do (jo detail na dikhe woh mujhse poochho); agar jewellery ka piece hai to stock mein milta-julta dhoondo.';
  if (typeof chatSend === 'function') {
    const C0 = chatSend;
    chatSend = function (text, o) {
      let t = String(text == null ? '' : text).trim();
      if (PIMG) { if (!t) t = DEFAULT_PHOTO_Q; if (!/^📷/.test(t)) t = '📷 ' + t; const box = q$('#chat-q'); if (box && box.value.trim() === String(text || '').trim()) box.value = ''; }
      return C0.call(this, t, o);
    };
  }
  function paintChip() {
    const wrap = q$('.chat-in'); if (!wrap) return; let chip = q$('#sjx-chip');
    if (!PIMG) { if (chip) chip.remove(); return; }
    if (!chip) { chip = document.createElement('div'); chip.id = 'sjx-chip'; wrap.parentNode.insertBefore(chip, wrap); }
    chip.innerHTML = `<img src="${PIMG.url}" alt=""><span>Photo lagi hai — sawal likhiye ya seedha bhejiye</span><button type="button" class="icon-btn" data-act="sjx-unpic" aria-label="Photo hatao">✕</button>`;
  }
  function mountCam() {
    const wrap = q$('.chat-in'); if (!wrap || q$('#sjx-cam', wrap)) return;
    const b = document.createElement('button'); b.type = 'button'; b.className = 'btn'; b.id = 'sjx-cam'; b.title = 'Photo lagao — bill / parcha / jewellery'; b.setAttribute('aria-label', 'Photo'); b.dataset.act = 'sjx-pic'; b.textContent = '📷';
    wrap.insertBefore(b, q$('#chat-send', wrap)); paintChip();
  }
  setInterval(mountCam, 1200);
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act="sjx-pic"],[data-act="sjx-unpic"]'); if (!t) return;
    e.preventDefault(); e.stopPropagation();
    if (t.dataset.act === 'sjx-unpic') { PIMG = null; paintChip(); return; }
    const f = await pickPhoto(false); if (!f) return;
    try { PIMG = await compress(f, 1600, 0.82); paintChip(); const box = q$('#chat-q'); if (box) box.focus(); } catch (err) { toast(err.message, 'err'); }
  }, true);
  addCss(`#sjx-chip{display:flex;align-items:center;gap:10px;padding:6px 8px;margin:0 0 8px;border:1px dashed var(--line,#3a2f1a);border-radius:12px;font-size:12.5px}
    #sjx-chip img{width:46px;height:46px;object-fit:cover;border-radius:8px}#sjx-chip span{flex:1;opacity:.85}#sjx-cam{font-size:17px;padding-inline:12px}`);

  /* ---------------------------------------------------------------
     2. Visual stock search (works in the browser, on Vault photos)
     --------------------------------------------------------------- */
  const FEAT = new Map();
  async function featOf(src) {
    const im = await loadImg(src); const c = document.createElement('canvas'); const g = c.getContext('2d', { willReadFrequently: true });
    // centre crop (pieces are usually in the middle) → 9x8 grey for dHash, 24x24 colour for histogram
    const s = Math.min(im.naturalWidth, im.naturalHeight) * 0.86, sx = (im.naturalWidth - s) / 2, sy = (im.naturalHeight - s) / 2;
    c.width = 9; c.height = 8; g.drawImage(im, sx, sy, s, s, 0, 0, 9, 8); let d = g.getImageData(0, 0, 9, 8).data; const grey = []; for (let k = 0; k < d.length; k += 4) grey.push(d[k] * 0.299 + d[k + 1] * 0.587 + d[k + 2] * 0.114);
    const bits = []; for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) bits.push(grey[y * 9 + x] > grey[y * 9 + x + 1] ? 1 : 0);
    c.width = 24; c.height = 24; g.drawImage(im, sx, sy, s, s, 0, 0, 24, 24); d = g.getImageData(0, 0, 24, 24).data; const h = new Float32Array(64); let n = 0;
    for (let k = 0; k < d.length; k += 4) { const r = d[k], gg = d[k + 1], b = d[k + 2]; if (r > 238 && gg > 238 && b > 238) continue; h[(r >> 6) * 16 + (gg >> 6) * 4 + (b >> 6)]++; n++; }
    if (n) for (let k = 0; k < 64; k++) h[k] /= n;
    return { bits, h };
  }
  function simOf(a, b) { let ham = 0; for (let k = 0; k < 64; k++) if (a.bits[k] !== b.bits[k]) ham++; let hi = 0; for (let k = 0; k < 64; k++) hi += Math.min(a.h[k], b.h[k]); return 0.5 * (1 - ham / 64) + 0.5 * hi; }
  async function productFeat(p) { const key = p.id + ':' + (p.updatedAt || 0); if (FEAT.has(key)) return FEAT.get(key); try { const f = await featOf(p.photo); FEAT.set(key, f); return f; } catch (e) { return null; } }
  async function visualMatch(imgUrl, o) {
    o = o || {}; const q = await featOf(imgUrl);
    const L = S.products.filter(p => p.photo && String(p.photo).startsWith('data:') && (o.all || p.status === 'In Stock') && (!o.category || nrm(p.category) === nrm(o.category)));
    const out = []; for (const p of L) { const f = await productFeat(p); if (f) out.push({ p, score: simOf(q, f) }); }
    return { withPhoto: L.length, total: S.products.filter(p => o.all || p.status === 'In Stock').length, hits: out.sort((a, b) => b.score - a.score).slice(0, o.limit || 12) };
  }
  function hitRow(h) { const p = h.p; return { sku: p.sku, id: p.id, category: p.category, purity: p.purity, gross: num(p.gross), net: num(p.net), status: p.status, tray: p.tray || '', huid: p.huid || '', matchPct: Math.round(h.score * 100) }; }
  async function openPhotoSearch() {
    const el = openModal(`${mHead('📷 Photo se stock khojo', 'Piece ki photo lijiye — Vault ki photos se milaan karke sabse milte-julte piece dikhenge')}<div class="m-body"><div class="btns"><button type="button" class="btn primary" data-act="sjx-ps-cam">📸 Camera</button><button type="button" class="btn" data-act="sjx-ps-file">🖼 Gallery se</button><label class="small" style="display:flex;gap:6px;align-items:center"><input type="checkbox" class="sjx-ps-all"> Bika hua maal bhi</label></div><div class="sjx-ps-out small muted" style="margin-top:12px">Photo saaf roshni mein, piece beech mein, saada background par lijiye — sabse achha milaan hota hai.</div></div>`, { wide: true });
    const run = async capture => {
      const f = await pickPhoto(capture); if (!f) return; const out = q$('.sjx-ps-out', el); out.innerHTML = 'Milaan ho raha hai…';
      try {
        const img = await compress(f, 900, 0.85); const r = await visualMatch(img.url, { all: q$('.sjx-ps-all', el).checked });
        if (!r.withPhoto) { out.innerHTML = `<div class="note">Vault ke kisi piece ki photo nahi hai (${r.total} piece). Stock mein photo daaliye — tab photo se khoj chalegi.${SITE ? ' Abhi ke liye AI se pehchaan karwa sakte hain:' : ''}</div>${SITE ? '<button type="button" class="btn sm" data-act="sjx-ps-ai">🤖 AI se poochho</button>' : ''}`; el._img = img; return; }
        el._img = img;
        out.innerHTML = `<div class="small muted" style="margin-bottom:8px">${r.withPhoto} photo wale piece mein se sabse milte-julte:</div><div class="sjx-grid">${r.hits.map(h => `<button type="button" class="sjx-tile" data-act="sjx-ps-open" data-id="${esc(h.p.id)}"><img src="${esc(h.p.photo)}" alt=""><b>#${esc(h.p.sku)}</b><span>${esc(h.p.category)} ${esc(h.p.purity)} · ${g3(h.p.gross)}</span><span class="${h.score > 0.8 ? 'green' : ''}">${Math.round(h.score * 100)}% milta${h.p.status !== 'In Stock' ? ' · ' + esc(h.p.status) : ''}</span></button>`).join('')}</div>${SITE ? '<div class="btns" style="margin-top:10px"><button type="button" class="btn sm" data-act="sjx-ps-ai">🤖 AI se bhi poochho</button></div>' : ''}`;
      } catch (err) { out.innerHTML = '<span class="red">' + esc(err.message) + '</span>'; }
    };
    el.addEventListener('click', e => { const t = e.target.closest('[data-act]'); if (!t) return;
      if (t.dataset.act === 'sjx-ps-cam') run(true); else if (t.dataset.act === 'sjx-ps-file') run(false);
      else if (t.dataset.act === 'sjx-ps-open') { closeModal(el); if (typeof openProductForm === 'function') openProductForm(t.dataset.id); }
      else if (t.dataset.act === 'sjx-ps-ai' && el._img) { PIMG = el._img; closeModal(el); goTo('assistant'); setTimeout(() => chatSend('Ye jewellery piece kaunsa hai (category, sona/chandi, design)? Stock mein iske jaisa maal dhoondo.'), 700); } });
  }
  addCss(`.sjx-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px}.sjx-tile{display:flex;flex-direction:column;gap:2px;text-align:left;background:transparent;border:1px solid var(--line,#3a2f1a);border-radius:12px;padding:8px;cursor:pointer;color:inherit;font-size:12px}
    .sjx-tile img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;margin-bottom:4px}.sjx-tile:hover{border-color:var(--gold,#e6c25e)}`);
  { const V = VIEWDEF.vault; if (V && V.shell) VIEWDEF.vault = { ...V, shell() { return `<div class="sjx-bar"><button type="button" class="btn sm" data-act="sjx-photo-search">📷 Photo se khojo</button><button type="button" class="btn sm" data-act="sjx-stock-advice">💡 Stock ki salah</button></div>` + V.shell.call(V); } }; }
  addCss('.sjx-bar{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 10px}');

  /* ---------------------------------------------------------------
     9. Stock advice
     --------------------------------------------------------------- */
  function stockAdvice(days) {
    days = days || 90; const t = todayStr(), from = addDays(t, -days); const G = {};
    const key = (c, p) => (c || 'Others') + ' · ' + (p || '');
    S.products.filter(p => p.status === 'In Stock').forEach(p => { const k = key(p.category, p.purity); const a = G[k] || (G[k] = { group: k, stockPcs: 0, stockNet: 0, soldPcs: 0, soldNet: 0, oldest: '', pieces: [] }); a.stockPcs += Math.max(1, num(p.pcs) || 1); a.stockNet = r3(a.stockNet + num(p.net || p.gross)); const d = String(p.purchaseDate || (p.createdAt ? new Date(p.createdAt).toISOString().slice(0, 10) : '')); if (d && (!a.oldest || d < a.oldest)) a.oldest = d; a.pieces.push({ sku: p.sku, d, net: num(p.net || p.gross) }); });
    S.invoices.filter(v => isSaleT(v.type) && v.date >= from && v.date <= t).forEach(v => (v.items || []).forEach(it => { const k = key(it.category, it.purity); const a = G[k] || (G[k] = { group: k, stockPcs: 0, stockNet: 0, soldPcs: 0, soldNet: 0, oldest: '', pieces: [] }); a.soldPcs += Math.max(1, num(it.pcs) || 1); a.soldNet = r3(a.soldNet + num(it.net || (num(it.gross) - num(it.less)))); }));
    const rows = Object.values(G).map(a => { const perDay = a.soldNet / days; const cover = perDay > 0 ? Math.round(a.stockNet / perDay) : (a.stockNet > 0 ? 9999 : 0); const age = a.oldest ? Math.floor((Date.parse(t) - Date.parse(a.oldest)) / 864e5) : 0;
      const dead = a.pieces.filter(x => x.d && (Date.parse(t) - Date.parse(x.d)) / 864e5 > 180);
      let advice, tag; if (a.stockNet <= 0 && a.soldNet > 0) { advice = 'Stock khatam — bikta hai, turant banwaiye / mangwaiye'; tag = 'reorder'; }
      else if (perDay > 0 && cover < 20) { advice = `Sirf ~${cover} din ka maal — aur mangwaiye`; tag = 'reorder'; }
      else if (a.soldNet === 0 && a.stockNet > 0) { advice = `${days} din mein ek bhi nahi bika — discount / exchange offer / karigar ko wapas tudwa kar naya design`; tag = 'dead'; }
      else if (cover > 180) { advice = `~${cover > 999 ? '999+' : cover} din ka maal pada hai — naya mat banwaiye, pehle ye nikaaliye`; tag = 'slow'; }
      else { advice = 'Theek chal raha hai'; tag = 'ok'; }
      return { group: a.group, stockPcs: a.stockPcs, stockNet_g: a.stockNet, soldPcs: a.soldPcs, soldNet_g: a.soldNet, soldPerMonth_g: r3(perDay * 30), coverDays: cover >= 9999 ? null : cover, oldestDays: age, deadPieces: dead.length, deadSkus: dead.slice(0, 8).map(x => x.sku), tag, advice };
    });
    const ord = { reorder: 0, dead: 1, slow: 2, ok: 3 };
    return rows.sort((a, b) => ord[a.tag] - ord[b.tag] || b.soldNet_g - a.soldNet_g);
  }
  if (window.SJ_REPORTS) {
    const H = window.SJ_REPORTS.h;
    window.SJ_REPORTS.add('stock_advice', 'stock', 'Stock ki salah (reorder / dead / slow)', 'Har category-purity ka bikri ki raftaar vs pada maal — kya mangwana, kya nikaalna', { period: 'none', build() {
      const R = stockAdvice(90); const tagL = { reorder: '🔴 Mangwaiye', dead: '⚫ Dead stock', slow: '🟠 Dheema', ok: '🟢 Theek' };
      return { summary: [['Mangwaiye', R.filter(x => x.tag === 'reorder').length], ['Dead stock groups', R.filter(x => x.tag === 'dead').length], ['Dheema', R.filter(x => x.tag === 'slow').length], ['180+ din purane piece', sum(R, x => x.deadPieces)]],
        sections: [H.sec('', [H.C('Group', 's'), H.C('Salah', 's'), H.C('Stock pcs', 'n'), H.C('Stock net g', 'g'), H.C('Bika 90 din g', 'g'), H.C('Bikri / mahina g', 'g'), H.C('Kitne din ka maal', 's'), H.C('Purana (din)', 'n'), H.C('180+ din pcs', 'n'), H.C('Note', 's')],
          R.map(x => [x.group, tagL[x.tag], x.stockPcs, x.stockNet_g, x.soldNet_g, x.soldPerMonth_g, x.coverDays == null ? '—' : x.coverDays, x.oldestDays, x.deadPieces, x.advice]), { note: 'Bikri pichhle 90 din ke sale / estimate bills se. "Kitne din ka maal" = pada net wazan ÷ roz ki bikri.' })] }; } });
  }
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act="sjx-photo-search"],[data-act="sjx-stock-advice"]'); if (!t) return; e.preventDefault();
    if (t.dataset.act === 'sjx-photo-search') openPhotoSearch(); else if (window.SJ_REPORTS) window.SJ_REPORTS.open('stock_advice'); });

  /* ---------------------------------------------------------------
     8. Order tracking: every status change is stamped; offer a WhatsApp update
     --------------------------------------------------------------- */
  const OST_HI = { Draft: 'draft mein hai', New: 'humein mil gaya hai', Pending: 'jald shuru hoga', 'In Progress': 'ban raha hai', Ready: 'TAIYAAR hai — aap le ja sakte hain', Completed: 'aapko de diya gaya hai', Cancelled: 'cancel ho gaya hai' };
  function orderMsg(o) { const s = settings(); return `Namaste ${o.partyName || ''} ji 🙏\nAapka order *${o.no || ''}* (${[o.category, o.purity, o.gross ? o.gross + ' g' : ''].filter(Boolean).join(' ')}) ${OST_HI[o.status] || o.status}.${o.dueDate && o.status !== 'Ready' && o.status !== 'Completed' ? '\nTaiyaar hone ki tareekh: ' + fmtD(o.dueDate) : ''}\n— ${s.firm || 'Shivaa Jewels'}${s.phone ? ' · ' + s.phone : ''}`; }
  function flashCard(html, ms) { let el = q$('#sjx-flash'); if (el) el.remove(); el = document.createElement('div'); el.id = 'sjx-flash'; el.innerHTML = html + '<button type="button" class="icon-btn" data-act="sjx-flash-x" aria-label="Band">✕</button>'; document.body.appendChild(el); clearTimeout(flashCard.t); flashCard.t = setTimeout(() => el.remove(), ms || 15000); }
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('[data-act="sjx-flash-x"]')) { const el = q$('#sjx-flash'); if (el) el.remove(); } });
  addCss(`#sjx-flash{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(92px + env(safe-area-inset-bottom));z-index:80;display:flex;gap:10px;align-items:center;max-width:min(560px,calc(100vw - 32px));background:var(--card,#17130c);color:var(--ink,#f3e6c4);border:1px solid var(--gold,#e6c25e);border-radius:14px;padding:10px 12px;box-shadow:0 10px 30px rgba(0,0,0,.4);font-size:13px}
    #sjx-flash .grow{flex:1}@media(min-width:901px){#sjx-flash{bottom:70px}}`);
  if (typeof save === 'function') {
    const SV0 = save;
    save = async function (col, obj, o) {
      let changed = null;
      if (col === 'orders' && obj && typeof obj === 'object') {
        const old = S.orders.find(x => x.id === obj.id); const st = obj.status || 'New';
        if (!old || old.status !== st) { obj = { ...obj, track: [...((old && old.track) || obj.track || []), { s: st, at: Date.now(), by: me().name }] }; changed = old ? st : null; }
      }
      const r = await SV0.call(this, col, obj, o);
      if (r && changed && obj.type !== 'purchase') { const c = S.customers.find(x => x.id === obj.partyId); const url = c ? waUrl(c.phone, orderMsg(obj)) : '';
        if (url) flashCard(`<span class="grow">Order <b>${esc(obj.no || '')}</b> ab <b>${esc(changed)}</b>. ${esc(c.name)} ko batayein?</span><a class="btn sm green" href="${esc(url)}" target="_blank" rel="noopener">WhatsApp update ↗</a>`); }
      return r;
    };
  }

  /* ---------------------------------------------------------------
     7. Birthdays & anniversaries — today's wishes with an offer
     --------------------------------------------------------------- */
  const DEF_OFFER = 'Is khushi ke mauke par aapke liye making charge par 10% ki khaas chhoot (7 din tak).';
  function wishText(o) { const s = settings(); const offer = s.wishOffer === undefined ? DEF_OFFER : s.wishOffer; const sch = s.wishScheme === false ? '' : '\nHamari Swarn Bachat Yojana se har mahine thoda jama karke sona ghar laaiye — puchhiye!';
    return occText(o).replace(/\n— /, (offer ? '\n' + offer : '') + sch + '\n— '); }
  function wishSent(o) { const k = o.p.id + ':' + o.kind + ':' + o.date; return S.wishLog.some(w => w.key === k); }
  function occCard() {
    if (typeof occasions !== 'function') return '';
    const O = occasions(1).filter(o => o.who === 'customer' || o.p.phone); if (!O.length) return '';
    return `<div class="card sjx-occ"><div class="card-h"><h3>🎂 Aaj-kal ke shubh din (${O.length})</h3><button type="button" class="btn sm" data-act="sjx-offer">Offer badlo</button></div>${O.map(o => { const done = wishSent(o); const url = waUrl(o.p.phone, wishText(o));
      return `<div class="sp-row"><div><b>${esc(o.p.name)}</b> <span class="pill ${o.kind === 'Birthday' ? 'gold' : 'blue'}">${o.kind === 'Birthday' ? 'Janamdin' : 'Saalgirah'}</span><div class="small muted">${o.inDays ? 'Kal' : '<b>Aaj</b>'}${o.years > 0 && o.years < 120 ? ' · ' + o.years + (o.kind === 'Birthday' ? ' saal' : ' saal saath') : ''}${done ? ' · <span class="green">✓ wish bheji</span>' : ''}</div></div>${url ? `<a class="btn sm ${done ? '' : 'green'}" href="${esc(url)}" target="_blank" rel="noopener" data-act="sjx-wish" data-k="${esc(o.p.id + ':' + o.kind + ':' + o.date)}" data-n="${esc(o.p.name)}">${done ? 'Dobara' : 'Wish bhejo'} ↗</a>` : '<span class="small muted">No. nahi</span>'}</div>`; }).join('')}</div>`;
  }
  document.addEventListener('click', async e => {
    const w = e.target.closest && e.target.closest('[data-act="sjx-wish"]');
    if (w) { const k = w.dataset.k; if (!S.wishLog.some(x => x.key === k)) save('wishLog', { id: uid('wl'), key: k, name: w.dataset.n, at: Date.now(), by: me().name }).then(() => { if (typeof renderView === 'function') setTimeout(() => renderView(true), 400); }); return; }
    const t = e.target.closest && e.target.closest('[data-act="sjx-offer"]'); if (!t) return; e.preventDefault();
    const s = settings(); const el = openModal(`${mHead('🎂 Wish ke saath offer', 'Janamdin / saalgirah ke WhatsApp message mein judega')}<form class="m-body" data-sjx="offer">${F('Offer line (khaali chhodein to koi offer nahi)', `<textarea name="offer" rows="3">${esc(s.wishOffer === undefined ? DEF_OFFER : s.wishOffer)}</textarea>`)}<label class="small" style="display:flex;gap:8px;align-items:center;margin-top:8px"><input type="checkbox" name="scheme" ${s.wishScheme === false ? '' : 'checked'}> Gold scheme (Swarn Bachat Yojana) ki line bhi jodein</label><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { small: true });
    q$('form', el).addEventListener('submit', async ev => { ev.preventDefault(); const f = ev.target; if (await saveSettings({ ...S.settings, wishOffer: f.offer.value.trim(), wishScheme: f.scheme.checked })) { closeModal(el); toast('Offer save'); renderView(true); } });
  });

  /* ---------------------------------------------------------------
     6. Suspicious-activity alerts (owner only)
     --------------------------------------------------------------- */
  const seenAlerts = new Set(); let alertsPrimed = false; const T_LOAD = Date.now();
  function unseen() { return (S.alerts || []).filter(a => !a.seen).sort((a, b) => b.at - a.at); }
  function alertCard() {
    if (!isOwner()) return ''; const U = unseen(); if (!U.length) return '';
    return `<div class="card sjx-alerts"><div class="card-h"><h3>🚨 Shaq wali activity (${U.length} nayi)</h3><div class="btns"><button type="button" class="btn sm" data-act="sjx-al-all">Saari dekhi ✓</button>${window.SJ_REPORTS ? '<button type="button" class="btn sm" data-act="sjx-al-rep">Poori list</button>' : ''}</div></div>${U.slice(0, 8).map(a => `<div class="sp-row"><div><b class="${a.level === 'high' ? 'red' : ''}">${a.night ? '🌙 ' : ''}${esc(a.text)}</b><div class="small muted">${esc(a.by || '')} · ${new Date(a.at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</div></div><button type="button" class="btn sm" data-act="sjx-al-seen" data-id="${esc(a.id)}">Dekh liya</button></div>`).join('')}${U.length > 8 ? `<p class="small muted">+${U.length - 8} aur…</p>` : ''}</div>`;
  }
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act="sjx-al-seen"],[data-act="sjx-al-all"],[data-act="sjx-al-rep"]'); if (!t) return; e.preventDefault();
    if (t.dataset.act === 'sjx-al-rep') return window.SJ_REPORTS.open('alerts_log', 'all');
    const L = t.dataset.act === 'sjx-al-all' ? unseen() : unseen().filter(a => a.id === t.dataset.id);
    for (const a of L) await save('alerts', { ...a, seen: true, seenAt: Date.now() });
    renderView(true);
  });
  function notify(a) {
    toast('🚨 ' + a.text, 'err');
    try { if ('Notification' in window && Notification.permission === 'granted') { const n = new Notification('🚨 Shivaa Jewels', { body: a.text + ' — ' + (a.by || ''), tag: a.id, icon: 'icon-192.png' }); n.onclick = () => { window.focus(); goTo('dashboard'); }; } } catch (e) { /* */ }
  }
  setInterval(() => { if (!isOwner()) return; const L = S.alerts || []; if (!alertsPrimed) { if (!L.length && Date.now() - T_LOAD < 15000) return; L.forEach(a => seenAlerts.add(a.id)); alertsPrimed = true; return; }
    L.forEach(a => { if (seenAlerts.has(a.id)) return; seenAlerts.add(a.id); if (!a.seen) notify(a); }); }, 4000);
  if (window.SJ_REPORTS) {
    const H = window.SJ_REPORTS.h;
    window.SJ_REPORTS.add('alerts_log', 'ca', 'Shaq wali activity — alerts log', 'Staff / manager ne bill delete / badla, rate badla, raat ki entries — server ne khud likha', { period: 'range', defRp: 'all', build(r) {
      const L = (S.alerts || []).filter(a => { const d = new Date(a.at + 19800000).toISOString().slice(0, 10); return (!r.a || d >= r.a) && (!r.b || d <= r.b); }).sort((a, b) => b.at - a.at);
      return { summary: [['Alerts', L.length], ['Raat ke', L.filter(a => a.night).length], ['Bill delete', L.filter(a => a.kind === 'bill_delete').length], ['Rate badla', L.filter(a => a.kind === 'rate_change').length]],
        sections: [H.sec('', [H.C('Kab', 's'), H.C('Kisne', 's'), H.C('Kya hua', 's'), H.C('Level', 's'), H.C('Dekha', 's')], L.map(a => [new Date(a.at).toLocaleString('en-IN'), a.by || '', a.text, (a.night ? 'RAAT · ' : '') + (a.level || ''), a.seen ? '✓' : '—']))] }; } });
  }

  /* dashboard: alerts + wishes on top */
  { const V = VIEWDEF.dashboard; if (V && V.body) VIEWDEF.dashboard = { ...V, body() { return alertCard() + occCard() + V.body.apply(V, arguments); } }; }

  /* ---------------------------------------------------------------
     5. Customer portal link (Party 360)
     --------------------------------------------------------------- */
  const newToken = () => { const a = new Uint8Array(18); crypto.getRandomValues(a); return Array.from(a, b => 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'[b % 57]).join('') + Date.now().toString(36).slice(-4); };
  const portalUrl = c => new URL('portal.php?t=' + encodeURIComponent(c.portalToken), location.href.split('#')[0]).href;
  async function portalLink(c, o) {
    o = o || {}; if (!c) throw new Error('Customer nahi mila');
    let cur = S.customers.find(x => x.id === c.id) || c;
    if (!cur.portalToken || cur.portalOff || o.renew) { cur = { ...cur, portalToken: newToken(), portalOff: false, portalAt: Date.now(), updatedAt: Date.now() }; if (!await save('customers', cur)) throw new Error('Save nahi hua'); }
    return cur;
  }
  function portalMsg(c) { const s = settings(); return `Namaste ${c.name} ji 🙏\nAapka khata, bills, payments aur orders ab online dekhiye — kabhi bhi:\n${portalUrl(c)}\n(Ye link sirf aapke liye hai, kisi aur ko na bhejein.)\n— ${s.firm || 'Shivaa Jewels'}`; }
  function portalBar(c) {
    if (!SITE) return '';
    const on = c.portalToken && !c.portalOff;
    return `<div class="card sjx-portal"><div class="card-h"><h3>🔗 Customer portal</h3></div><p class="small muted" style="margin-top:0">Customer apna khata, bills, jama paise, orders aur scheme khud dekh sake — ek secret link se. Kacha (estimate) bill ${c.portalKacha ? '<b>dikhte hain</b>' : 'nahi dikhte'}.</p>
      ${on ? `<div class="sjx-url mono small">${esc(portalUrl(c))}</div>` : ''}<div class="btns">${on ? `<a class="btn sm green" href="${esc(waUrl(c.phone, portalMsg(c)) || '#')}" target="_blank" rel="noopener">WhatsApp par bhejo ↗</a><button type="button" class="btn sm" data-act="sjx-pt-copy" data-id="${esc(c.id)}">Copy</button><a class="btn sm" href="${esc(portalUrl(c))}" target="_blank" rel="noopener">Kholkar dekho</a><button type="button" class="btn sm" data-act="sjx-pt-kacha" data-id="${esc(c.id)}">${c.portalKacha ? 'Kacha chhupao' : 'Kacha bhi dikhao'}</button><button type="button" class="btn sm" data-act="sjx-pt-new" data-id="${esc(c.id)}">Naya link (purana band)</button><button type="button" class="btn sm danger" data-act="sjx-pt-off" data-id="${esc(c.id)}">Band karo</button>` : `<button type="button" class="btn sm primary" data-act="sjx-pt-make" data-id="${esc(c.id)}">Link banao</button>`}</div></div>`;
  }
  { const V = VIEWDEF.khata; if (V && V.body) VIEWDEF.khata = { ...V, body() { const h = V.body.apply(V, arguments); const k = String(ui.k3 || ''); if (!k.startsWith('c:') || !isOwner() && me().role !== 'manager') return h; const c = S.customers.find(x => x.id === k.slice(2)); return c ? portalBar(c) + h : h; } }; }
  addCss('.sjx-url{word-break:break-all;padding:8px 10px;border:1px dashed var(--line,#3a2f1a);border-radius:10px;margin-bottom:8px}');
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act^="sjx-pt-"]'); if (!t) return; e.preventDefault();
    const c = S.customers.find(x => x.id === t.dataset.id); if (!c) return;
    try {
      if (t.dataset.act === 'sjx-pt-make') { await portalLink(c); toast('✓ Portal link ban gaya'); }
      else if (t.dataset.act === 'sjx-pt-new') { await portalLink(c, { renew: true }); toast('Naya link — purana band ho gaya'); }
      else if (t.dataset.act === 'sjx-pt-off') { await save('customers', { ...c, portalOff: true, updatedAt: Date.now() }); toast('Portal band'); }
      else if (t.dataset.act === 'sjx-pt-kacha') { await save('customers', { ...c, portalKacha: !c.portalKacha, updatedAt: Date.now() }); }
      else if (t.dataset.act === 'sjx-pt-copy') { await navigator.clipboard.writeText(portalUrl(c)); toast('Link copy ho gaya'); return; }
      renderView(true);
    } catch (err) { toast(err.message || 'Nahi hua', 'err'); }
  });

  /* ---------------------------------------------------------------
     4. AI controls more of the app — new actions + check_entry
     --------------------------------------------------------------- */
  try { ['dob', 'anniversary', 'email', 'notes', 'ptype', 'shop'].forEach(k => { if (RECORD_COLS.customers && !RECORD_COLS.customers.includes(k)) RECORD_COLS.customers.push(k); }); if (RECORD_COLS.orders === undefined) RECORD_COLS.orders = ['status', 'dueDate', 'priority', 'notes', 'gross', 'pcs']; } catch (e) { /* */ }
  const PAY_OK = typeof PAY_MODES !== 'undefined' ? PAY_MODES : ['Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Card'];
  function findPartyAny(d, prefer) {
    const all = (prefer === 'supplier' ? [] : S.customers.map(c => ['customer', c])).concat(prefer === 'customer' ? [] : S.suppliers.map(c => ['supplier', c]));
    if (d.partyId) { const h = all.find(x => x[1].id === d.partyId); if (h) return [h]; }
    const n = nrm(d.partyName || d.party || ''); if (!n) return [];
    let L = all.filter(x => nrm(x[1].name) === n); if (!L.length) L = all.filter(x => nrm(x[1].name).includes(n) || n.split(/\s+/).filter(w => w.length > 2).every(w => nrm(x[1].name + ' ' + (x[1].city || '')).includes(w)));
    return L;
  }
  function planPayment(d) {
    const amt = r2(num(d.amount)); if (!(amt > 0)) return { err: 'Kitne rupaye? (amount)' };
    let inv = null; if (d.invoiceNo) { inv = S.invoices.find(v => nrm(v.no) === nrm(d.invoiceNo)); if (!inv) return { err: 'Bill ' + d.invoiceNo + ' nahi mila' }; }
    let party, kind;
    if (inv) { kind = isBuy(inv.type) ? 'supplier' : 'customer'; party = (kind === 'supplier' ? S.suppliers : S.customers).find(x => x.id === inv.partyId) || { id: inv.partyId, name: inv.partyName }; }
    else { const L = findPartyAny(d, d.direction === 'out' ? 'supplier' : d.direction === 'in' ? 'customer' : ''); if (!L.length) return { err: 'Party nahi mili: ' + (d.partyName || d.partyId || '') }; if (L.length > 1 && !L.some(x => nrm(x[1].name) === nrm(d.partyName))) return { err: 'Kaun si party? ' + L.slice(0, 4).map(x => x[1].name).join(' / ') }; const h = L.find(x => nrm(x[1].name) === nrm(d.partyName)) || L[0]; kind = h[0]; party = h[1]; }
    const bills = inv ? [inv] : S.invoices.filter(v => v.partyId === party.id && (kind === 'supplier' ? isBuy(v.type) : !isBuy(v.type)) && v.type !== 'metal' && invDue(v) > 0.5).sort((a, b) => String(a.date).localeCompare(String(b.date)));
    if (!bills.length) return { err: party.name + ' ka koi baaki bill nahi hai' };
    let left = amt; const alloc = []; for (const v of bills) { if (left <= 0) break; const due = Math.max(0, invDue(v)); const use = inv ? Math.min(left, Math.max(due, left)) : Math.min(left, due); if (use <= 0) continue; alloc.push({ id: v.id, no: v.no, date: v.date, due: r2(due), use: r2(use) }); left = r2(left - use); }
    const mode = PAY_OK.includes(d.mode) ? d.mode : 'Cash'; const bank = (typeof banksList === 'function' ? banksList() : []).find(b => b.id === d.bankId || (d.bank && nrm((b.bank || '') + ' ' + (b.accNo || '')).includes(nrm(d.bank))));
    const date = /^\d{4}-\d{2}-\d{2}$/.test(d.date || '') ? d.date : todayStr();
    return { party, kind, alloc, extra: left, amt, mode, bankId: bank ? bank.id : '', bankLabel: bank ? (bank.bank || '') + ' ' + String(bank.accNo || '').slice(-4) : '', date, note: String(d.note || '') };
  }
  function checkEntry(type, d) {
    d = d || {}; const errors = [], warns = [];
    try {
      if (type === 'create_invoice') { const r = specToState(d); r.errors.forEach(x => errors.push(x)); r.warns.forEach(x => warns.push(x)); if (!r.errors.length) { if (typeof window.SJX_EXTRA_CHECKS === 'function') window.SJX_EXTRA_CHECKS(r.st).forEach(w => { if (/^⛔/.test(w)) errors.push(w); else warns.push(w); }); if (errors.length) return { ok: false, errors, warns }; const t = invTotals(r.st, r.party); return { ok: true, errors, warns, preview: { party: r.party ? r.party.name : r.newParty ? r.newParty.name + ' (new)' : null, items: r.st.items.length, payable: Math.round(t.payable || t.grand || 0), fineBalance: t.fineBalance } }; } }
      else if (type === 'add_customer') { const r = buildCustomer(d); if (r.err) errors.push(r.err); }
      else if (type === 'add_supplier') { const r = buildSupplier({ ...d, type: 'Manufacturer' }); if (r.err) errors.push(r.err); }
      else if (type === 'add_expense') { const r = buildExpense({ date: d.date || todayStr(), category: d.category || 'Other', amount: d.amount, mode: d.mode || 'Cash', notes: d.notes || '' }); if (r.err) errors.push(r.err); }
      else if (type === 'add_stock') { const r = buildStock(d); if (r.err) errors.push(r.err); }
      else if (type === 'update_record') { const r = buildRecordUpdate(d); if (r.err) errors.push(r.err); }
      else if (type === 'receive_payment') { const r = planPayment(d); if (r.err) errors.push(r.err); else { if (r.extra > 0) warns.push('₹' + r.extra + ' baaki bills se zyada hai — advance ki tarah aakhri bill par lagega'); if (r.mode !== 'Cash' && !r.bankId && (typeof banksList === 'function' && banksList().length)) warns.push('Kis bank account mein aaya? (bank batayein)'); return { ok: true, errors, warns, preview: { party: r.party.name, allocation: r.alloc, mode: r.mode, bank: r.bankLabel } }; } }
      else if (type === 'update_order_status') { const o = S.orders.find(x => nrm(x.no) === nrm(d.orderNo)); if (!o) errors.push('Order ' + (d.orderNo || '') + ' nahi mila'); if (!ORDER_STATUS.includes(d.status)) errors.push('Status in mein se: ' + ORDER_STATUS.join(', ')); }
      else if (type === 'add_bullion') { if (!(num(d.weight) > 0)) errors.push('Wazan (grams) kitna?'); if (!(num(d.rate) > 0)) errors.push('Rate kya laga? (sona ₹/10g, chandi ₹/kg)'); if (!d.supplierName && !d.supplierId) errors.push('Kisse kharida? (supplier / bullion merchant)'); if (!d.gst) warns.push('Pakka (GST) ya kacha? — na batayein to pakka maana jayega'); if (!d.payments || !d.payments.length) warns.push('Payment abhi kiya ya baad mein? Kis account se?'); }
      else if (type === 'set_target' || type === 'create_order' || type === 'update_rates') { /* the app checks these on Save */ }
      else errors.push('Unknown action type ' + type);
    } catch (e) { errors.push(String(e.message || e)); }
    return { ok: !errors.length, errors, warns };
  }
  try { ['receive_payment', 'update_order_status', 'add_bullion'].forEach(t => { if (typeof ACTIONS !== 'undefined' && !ACTIONS.includes(t)) ACTIONS.push(t); }); } catch (e) { /* */ }
  /* action cards for the new types */
  const AC0 = actionCardHTML;
  actionCardHTML = function (a, mi) {
    if (!a || !['receive_payment', 'update_order_status', 'add_bullion'].includes(a.type)) return AC0.apply(this, arguments);
    const d = a.data || {}; if (a.status === 'discarded') return '<div class="act-card small muted">Discarded.</div>';
    if (a.status === 'saved') return `<div class="act-card"><h4>✅ ${esc(a.done || 'Ho gaya')}</h4></div>`;
    let body = '', err = '';
    if (a.type === 'receive_payment') { const p = planPayment(d); if (p.err) err = p.err; else body = `<div class="small"><b>${esc(p.party.name)}</b> · ${p.kind === 'supplier' ? 'humne diye' : 'humein mile'} <b>${inr(p.amt)}</b> · ${esc(p.mode)}${p.bankLabel ? ' · ' + esc(p.bankLabel) : ''} · ${fmtD(p.date)}</div><table style="margin-top:6px"><tr><th>Bill</th><th>Date</th><th class="n">Baaki</th><th class="n">Lagega</th></tr>${p.alloc.map(x => `<tr><td>${esc(x.no)}</td><td>${fmtD(x.date)}</td><td class="n">${inr(x.due)}</td><td class="n">${inr(x.use)}</td></tr>`).join('')}</table>${p.extra > 0 ? `<div class="note small">${inr(p.extra)} baaki se zyada — aakhri bill par advance</div>` : ''}`; }
    else if (a.type === 'update_order_status') { const o = S.orders.find(x => nrm(x.no) === nrm(d.orderNo)); if (!o) err = 'Order nahi mila'; else body = `<div class="small"><b>${esc(o.no)}</b> · ${esc(o.partyName || '')} · ${esc(o.status)} → <b>${esc(d.status)}</b></div>`; }
    else { body = `<table>${[['Kisse', d.supplierName || ((S.suppliers.find(s => s.id === d.supplierId) || {}).name) || '—'], ['Metal', d.metal === 'silver' ? 'Chandi' : 'Sona'], ['Wazan', g3(num(d.weight))], ['Tunch', (num(d.tunch) || (d.metal === 'silver' ? 99.9 : 99.5)) + '%'], ['Rate', inr(num(d.rate)) + (d.metal === 'silver' ? ' /kg' : ' /10g') + (d.rateOn === 'fine' ? ' (fine par)' : '')], ['Bill', d.gst === 'kacha' ? 'Kacha' : 'Pakka (GST)'], ['Payment', (d.payments || []).map(p => inr(num(p.amount)) + ' ' + (p.mode || '')).join(', ') || 'baad mein']].map(r => `<tr><td class="muted">${r[0]}</td><td>${esc(r[1])}</td></tr>`).join('')}</table><div class="small muted">Save dabane par bullion form bhara hua khulega — check karke wahan Save kijiye.</div>`; }
    const title = { receive_payment: '💰 Payment entry', update_order_status: '📦 Order status', add_bullion: '🪙 Bullion kharid' }[a.type];
    return `<div class="act-card"><h4>${title}</h4>${body}${err ? `<div class="errs">${esc(err)}</div>` : ''}<div class="btns"><button class="btn sm primary" data-act="ai-save" data-i="${mi}" ${err ? 'disabled' : ''}>${a.type === 'add_bullion' ? 'Form kholo' : 'Save'}</button><button class="btn sm" data-act="ai-discard" data-i="${mi}">Discard</button></div></div>`;
  };
  const AS0 = aiSave;
  aiSave = async function (i) {
    const m = CHAT.turns[i]; if (!m || !m.action || m.action.status !== 'pending' || !['receive_payment', 'update_order_status', 'add_bullion'].includes(m.action.type)) return AS0.apply(this, arguments);
    const a = m.action, d = a.data || {};
    try {
      if (a.type === 'receive_payment') {
        const p = planPayment(d); if (p.err) return toast(p.err, 'err');
        for (let k = 0; k < p.alloc.length; k++) { const x = p.alloc[k]; const v = S.invoices.find(z => z.id === x.id); const use = k === p.alloc.length - 1 ? r2(x.use + p.extra) : x.use;
          const pay = { id: uid('pay'), date: p.date, amount: use, fine: 0, mode: p.mode, note: (p.note || 'AI se entry') + (p.alloc.length > 1 ? ' · ' + inr(p.amt) + ' mein se' : '') }; if (p.bankId) pay.bankId = p.bankId;
          if (!await save('invoices', { ...v, payments: [...invPayments(v).filter(z => z.id !== 'legacy'), ...(invPayments(v).some(z => z.id === 'legacy') ? [{ ...invPayments(v)[0], id: uid('pay') }] : []), pay], updatedAt: Date.now() })) return; }
        a.done = `${inr(p.amt)} ${p.kind === 'supplier' ? 'diye' : 'mile'} — ${p.party.name} (${p.alloc.map(x => x.no).join(', ')})`;
      } else if (a.type === 'update_order_status') {
        const o = S.orders.find(x => nrm(x.no) === nrm(d.orderNo)); if (!o) return toast('Order nahi mila', 'err');
        if (!await save('orders', { ...o, status: d.status, notes: d.note ? ((o.notes ? o.notes + '\n' : '') + d.note) : o.notes, updatedAt: Date.now() })) return;
        a.done = `Order ${o.no} → ${d.status}`;
      } else {
        goTo('bullion', { bnTab: 'buy' }); await new Promise(r => setTimeout(r, 500));
        const nb = q$('[data-act="bl-new"]'); if (nb) nb.click(); await new Promise(r => setTimeout(r, 400));
        const f = q$('form[data-bz="bullion"]'); if (!f) return toast('Bullion form nahi khula', 'err');
        const setv = (n, v) => { const el = f.elements[n]; if (!el || v == null || v === '') return; if (el.type === 'checkbox') el.checked = !!v; else el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); };
        const sup = d.supplierId ? S.suppliers.find(s => s.id === d.supplierId) : S.suppliers.find(s => nrm(s.name) === nrm(d.supplierName)) || S.suppliers.find(s => d.supplierName && nrm(s.name).includes(nrm(d.supplierName)));
        if (sup) setv('supplierId', sup.id); else setv('newName', d.supplierName);
        setv('metal', d.metal === 'silver' ? 'silver' : 'gold'); if (d.at) setv('at', String(d.at).slice(0, 16)); if (d.form) { const el = f.elements.form; const o = el && [...el.options].find(x => nrm(x.value).includes(nrm(d.form))); if (o) setv('form', o.value); }
        setv('weight', num(d.weight)); setv('tunch', num(d.tunch) || ''); setv('rate', num(d.rate)); setv('rateOn', d.rateOn === 'fine' ? 'fine' : 'weight'); setv('gst', d.gst === 'kacha' ? 'kacha' : 'pakka'); setv('billNo', d.billNo || ''); setv('notes', d.notes || '');
        const P = Array.isArray(d.payments) ? d.payments : [];
        for (let k = 0; k < P.length; k++) { let rows = f.querySelectorAll('[data-bp="amount"]'); if (k >= rows.length) { const add = q$('[data-act="bl-addpay"]', f); if (add) add.click(); await new Promise(r => setTimeout(r, 120)); rows = f.querySelectorAll('[data-bp="amount"]'); }
          const pick = (sel, n) => f.querySelectorAll('[data-bp="' + sel + '"]')[n];
          const am = pick('amount', k); if (am) { am.value = num(P[k].amount); am.dispatchEvent(new Event('input', { bubbles: true })); }
          const md = pick('mode', k); if (md && PAY_OK.includes(P[k].mode)) { md.value = P[k].mode; md.dispatchEvent(new Event('change', { bubbles: true })); }
          const bk = pick('bankId', k); if (bk && P[k].bank) { const o = [...bk.options].find(x => nrm(x.textContent).includes(nrm(P[k].bank))); if (o) { bk.value = o.value; bk.dispatchEvent(new Event('change', { bubbles: true })); } }
          const dt = pick('date', k); if (dt && /^\d{4}-\d{2}-\d{2}$/.test(P[k].date || '')) dt.value = P[k].date;
          const nt = pick('note', k); if (nt && P[k].note) nt.value = P[k].note; }
        a.done = 'Bullion form bhar diya — form mein Save dabaiye';
      }
      a.status = 'saved'; saveChat(); renderChat(); toast('✓ ' + a.done);
    } catch (err) { toast(err.message || 'Nahi hua', 'err'); }
  };

  /* AI tools + rules (website AI) */
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    const tool = (name, description, props, req, fn, label) => ({ name, description, inputSchema: { type: 'object', properties: props, required: req }, execute: async input => { if (typeof setChatStatus === 'function') setChatStatus(label); return fn(input || {}); } });
    agentTools = function () {
      const L = T0.apply(this, arguments);
      const add = t => { if (!L.some(x => x.name === t.name)) L.push(t); };
      add(tool('check_entry', 'ALWAYS call before returning ANY action. Runs the app\'s own validation on the draft (action_type + data as JSON text) and returns errors (must be fixed by asking the owner), warnings (mention or ask) and a preview (party, totals, payment allocation).',
        { action_type: { type: 'string' }, data: { type: 'string', description: 'the action data as JSON text' } }, ['action_type', 'data'], i => { let d = i.data; if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) { return { ok: false, errors: ['data must be JSON text'] }; } } return checkEntry(i.action_type, d); }, 'Entry jaanch raha hoon…'));
      add(tool('photo_stock_match', 'When the owner attached a PHOTO of a jewellery piece: compares it with Vault photos and returns the closest pieces (sku, category, purity, weight, match %). Optional category filter.',
        { category: { type: 'string' }, includeSold: { type: 'boolean' } }, [], async i => { if (!TURN_IMG) return { error: 'No photo attached in this question.' }; const r = await visualMatch(TURN_IMG.url, { category: i.category || '', all: !!i.includeSold, limit: 8 }); return { piecesWithPhotos: r.withPhoto, inStock: r.total, matches: r.hits.map(hitRow), note: r.withPhoto ? 'matchPct above ~80 is a strong match.' : 'No Vault pieces have photos — use stock_lookup by category instead and tell the owner to add photos.' }; }, 'Photo milaa raha hoon…'));
      add(tool('stock_advice', 'Stock advice per category+purity: what to re-order (selling, little stock), dead stock (not sold in 90 days), slow stock (180+ days cover), with sold grams per month and dead SKUs.', {}, [], () => stockAdvice(90).slice(0, 40), 'Stock ki salah bana raha hoon…'));
      add(tool('customer_portal_link', 'Create (or reuse) the secret online khata link for a customer and put a WhatsApp send button under your reply. renew=true makes a new link and stops the old one.',
        { party: { type: 'string' }, renew: { type: 'boolean' } }, ['party'], async i => { if (SITE && !['owner', 'manager'].includes(me().role)) return { error: 'Portal link sirf Owner / Manager bana sakte hain.' }; const L = findPartyAny({ partyName: i.party, partyId: i.party }, 'customer'); if (!L.length) return { error: 'Customer nahi mila' }; if (L.length > 1 && !L.some(x => nrm(x[1].name) === nrm(i.party))) return { needChoice: L.slice(0, 6).map(x => x[1].name) }; const c = await portalLink((L.find(x => nrm(x[1].name) === nrm(i.party)) || L[0])[1], { renew: !!i.renew }); const url = waUrl(c.phone, portalMsg(c)); if (url && window.SJX_EXTRA) window.SJX_EXTRA('[[wa|' + cleanPhone(c.phone) + '|' + encodeURIComponent(portalMsg(c)).replace(/\|/g, '%7C').replace(/\]/g, '%5D') + '|' + encodeURIComponent(c.name) + ']]'); return { ok: true, customer: c.name, note: url ? 'WhatsApp button with the link will appear under your reply.' : 'Customer has no phone — link created; tell owner to copy it from Party 360.' }; }, 'Portal link bana raha hoon…'));
      add(tool('todays_occasions', 'Birthdays and anniversaries of customers today and tomorrow, whether a wish was already sent. To send a wish use whatsapp_draft with a warm message plus the offer line from settings.', {}, [], () => ({ offer: settings().wishOffer === undefined ? DEF_OFFER : settings().wishOffer, list: (typeof occasions === 'function' ? occasions(1) : []).map(o => ({ name: o.p.name, kind: o.kind, when: o.inDays ? 'tomorrow' : 'today', years: o.years, wishSent: wishSent(o) })) }), 'Shubh din dekh raha hoon…'));
      add(tool('recent_alerts', 'Suspicious-activity alerts made by the server (bill deleted/edited, rate changed, night entries) — owner only.', { onlyUnseen: { type: 'boolean' } }, [], i => isOwner() ? (S.alerts || []).filter(a => !i.onlyUnseen || !a.seen).sort((a, b) => b.at - a.at).slice(0, 30).map(a => ({ when: new Date(a.at).toLocaleString('en-IN'), by: a.by, text: a.text, night: !!a.night, seen: !!a.seen })) : { error: 'Owner only' }, 'Alerts dekh raha hoon…'));
      return L;
    };
    const R0 = agentRules;
    agentRules = function (o) {
      return R0.apply(this, arguments) + `

FULL CONTROL OF THE APP (always: you prepare, the owner taps Save):
- New actions: receive_payment, update_order_status, add_bullion (besides create_invoice, add_customer, add_supplier, add_expense, set_target, create_order, add_stock, update_record, update_rates).
  receive_payment data: {"direction":"in (customer paid us) | out (we paid supplier)","partyName" or "partyId","invoiceNo":"optional — else oldest dues first","amount","mode":"Cash|UPI|Bank Transfer|Cheque|Card","bank":"bank name if not cash","date":"YYYY-MM-DD","note":"UTR / cheque no"}
  update_order_status data: {"orderNo","status":"${(typeof ORDER_STATUS !== 'undefined' ? ORDER_STATUS : []).join('|')}","note"}
  add_bullion data: {"supplierName","metal":"gold|silver","form":"Bar / biscuit|Coin|Kachi|Silver bar|Silver granules","weight":"g","tunch":"99.5 default gold, 99.9 silver","rate":"₹ per 10 g gold / per kg silver","rateOn":"weight|fine","gst":"pakka|kacha","billNo","at":"YYYY-MM-DDTHH:MM","payments":[{"amount","mode","bank","date","note"}],"notes"}
  update_record can now also set customers.dob / anniversary (YYYY-MM-DD), email, notes; and orders.status / dueDate / priority / notes.
- NEVER MISS AN ENTRY: before returning ANY action call check_entry(action_type, data as JSON text). If it returns errors, do NOT return the action — ask the owner exactly for the missing things (numbered, max 3; in voice ONE at a time) and remember what they already told you across turns. If only warnings, mention them in one line. Only when check_entry is ok, return the action.
- After the owner's Save, related things are linked automatically (payments reduce dues, books, reports, party khata, portal).
- When the owner describes several things in one message ("Rahul ko 10g ring di, 20 hazaar cash mila"), do them one by one: first the bill (create_invoice with received + payMode), then tell them what's next.
PHOTOS: a message starting with 📷 has a photo attached (you can see it).
- Bill / parcha / receipt / kacchi parchi photo → read EVERYTHING: party name, bill no, date, GSTIN, each line (item, purity / tunch, gross, less, net, wastage %, labour, rate, amount), totals, old gold, payments. Supplier's bill to us → create_invoice type "purchase" (GST) or "estpurchase" (no GST); our bill to a customer → "sale" / "estimate". Bullion merchant bill → add_bullion. Match the party with supplier_profile / customer_profile. If something is unreadable, ask for it — never guess a number. Show what you read as a short table, then check_entry, then the action.
- Jewellery piece photo → describe it (category, gold/silver, colour, design, approx size), call photo_stock_match (with category if sure), and list the closest SKUs. If nothing matches, say so and suggest stock_lookup by category.
OTHER NEW POWERS: stock_advice ("kya mangwaun / kya pada hai"), customer_portal_link ("Rahul ko uska khata online bhejo"), todays_occasions (birthdays → whatsapp_draft wishes), recent_alerts ("staff ne kuch gadbad to nahi ki?"), order status updates with WhatsApp message to the customer (whatsapp_draft).`;
    };
  }

  /* ---------------------------------------------------------------
     Setup: alert email + browser notification permission (owner)
     --------------------------------------------------------------- */
  function alertSetupCard() {
    if (!SITE || !isOwner()) return '';
    setTimeout(async () => { const el = q$('#sjx-al-card'); if (!el) return; try { const r = await window.SJ_API_CALL('alert_status', {}); q$('.sjx-al-email', el).value = r.email || ''; q$('.sjx-al-st', el).innerHTML = (r.email ? '✓ Alert email: <b>' + esc(r.email) + '</b>' : 'Email abhi nahi daala') + (r.mail ? '' : ' · <span class="red">hosting par mail() band hai</span>'); } catch (e) { /* */ } }, 0);
    const perm = 'Notification' in window ? Notification.permission : 'unsupported';
    return `<div class="card" id="sjx-al-card"><div class="card-h"><h3>🚨 Shaq wali activity ke alert</h3></div><p class="small muted" style="margin-top:0">Staff / manager bill delete kare ya badle, rate badle, ya raat 10 se subah 7 ke beech entry kare — server khud alert banata hai (staff ise rok nahi sakta). Alert Dashboard par dikhte hain, is device par notification aata hai, aur email bhi ja sakta hai.</p><div class="sjx-al-st small">…</div>
      <div class="two" style="margin-top:8px">${F('Alert kis email par aaye', '<input type="email" class="sjx-al-email" placeholder="aapka@gmail.com">')}</div><div class="btns"><button type="button" class="btn primary" data-act="sjx-al-save">Save + test email</button><button type="button" class="btn" data-act="sjx-al-perm" ${perm === 'granted' || perm === 'unsupported' ? 'disabled' : ''}>${perm === 'granted' ? '✓ Notification chalu' : perm === 'unsupported' ? 'Is browser mein notification nahi' : '🔔 Is device par notification chalu karo'}</button></div></div>`;
  }
  { const V = VIEWDEF.setup; if (V && V.body) VIEWDEF.setup = { ...V, body() { return alertSetupCard() + V.body.apply(V, arguments); } }; }
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act="sjx-al-save"],[data-act="sjx-al-perm"]'); if (!t) return; e.preventDefault();
    if (t.dataset.act === 'sjx-al-perm') { try { const p = await Notification.requestPermission(); toast(p === 'granted' ? '🔔 Notification chalu' : 'Notification ki ijaazat nahi mili', p === 'granted' ? '' : 'err'); } catch (er) { /* */ } renderView(true); return; }
    const el = q$('#sjx-al-card'); const em = q$('.sjx-al-email', el).value.trim();
    try { t.disabled = true; const r = await window.SJ_API_CALL('alert_cfg', { email: em, test: true }); toast(r.email ? (r.sent ? '✓ Save — test email bheja (spam folder bhi dekhiye)' : '✓ Save') : 'Email hata diya'); renderView(true); } catch (er) { toast(er.message || 'Nahi hua', 'err'); } finally { t.disabled = false; }
  });

  /* the chat may have been drawn before this file loaded */
  setTimeout(() => { try { if (q$('#chat-log') && typeof renderChat === 'function') renderChat(); } catch (e) { /* */ } }, 0);
})();
