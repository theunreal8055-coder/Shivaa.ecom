/* =====================================================================
   Shivaa Jewels — SHOWROOM TV (v43)
   Full-screen live display for the showroom TV / tablet:
   • Aaj ka bhaav — odometer numbers that roll when the rate changes,
     ▲▼ vs pichhla bhaav, 10-din ki chalti line (sparkline)
   • Showcase — naye design ki photo (Ken Burns + crossfade), offers,
     showroom countdown, promo slides — video ki tarah chalta rehta hai
   • Live ghadi (second tak), LIVE pill, token "Ab ki baari", ticker
   • Sone ki chamak: udte zarre (canvas), ghoomti roshni, shimmer
   • Screen jagi rehti hai (wake lock), burn-in se bachav, Esc se band
   v44: GPU-halka — sirf transform / opacity ki animation, peeche ka software
   chhupa, kamzor TV / tablet par apne aap 'halka' mode (blink / atakna band)
   ===================================================================== */
(function () {
  'use strict';
  if (typeof S === 'undefined') return;
  const pro = () => (settings().pro || {});
  const q$ = (s, r) => (r || document).querySelector(s);
  const RM = () => window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  let T = null;

  /* ---------------- fonts (bundled) ---------------- */
  let fp = null;
  function fonts() {
    if (fp) return fp;
    const L = [['SJ Lora', 'fonts/Lora-Variable.ttf', { weight: '400 700' }], ['SJ Poppins', 'fonts/Poppins-Regular.ttf', { weight: '400' }], ['SJ Poppins', 'fonts/Poppins-Medium.ttf', { weight: '500' }], ['SJ Poppins', 'fonts/Poppins-Bold.ttf', { weight: '700' }], ['SJ Poppins', 'fonts/Poppins-Light.ttf', { weight: '300' }]];
    fp = Promise.all(L.map(([f, u, d]) => { try { return new FontFace(f, `url(${u})`, d).load().then(x => document.fonts.add(x)).catch(() => null); } catch (e) { return null; } }));
    return fp;
  }

  /* ---------------- data ---------------- */
  function rates() {
    const s = settings(), g = num(s.gold24), sv = num(s.silver999);
    const H = (S.rateHistory || []).filter(r => r && r.date && (num(r.gold24) || num(r.silver999))).sort((a, b) => String(a.date).localeCompare(String(b.date)));
    const today = todayStr(); const prev = H.filter(r => r.date < today).pop() || null;
    const last = k => { const L = H.filter(r => num(r[k])).slice(-10).map(r => num(r[k])); const cur = k === 'gold24' ? g : sv; if (cur && (!L.length || L[L.length - 1] !== cur)) L.push(cur); return L; };
    const gl = last('gold24'), sl = last('silver999');
    const mk = (key, label, sub, v, pv, line, unit) => ({ key, label, sub, v: Math.round(v), d: pv ? Math.round(v - pv) : 0, line, unit });
    const pg = prev ? num(prev.gold24) : 0, ps = prev ? num(prev.silver999) : 0;
    return [
      mk('g24', 'Sona 24K', '999 · Fine Gold', g, pg, gl, '10 gram'),
      mk('g22', 'Sona 22K', '916 · Hallmark', g * 0.916, pg * 0.916, gl.map(x => x * 0.916), '10 gram'),
      mk('g18', 'Sona 18K', '750 · Diamond / Fancy', g * 0.75, pg * 0.75, gl.map(x => x * 0.75), '10 gram'),
      mk('s', 'Chandi', '999 · Fine Silver', sv, ps, sl, '1 kg')];
  }
  function slides() {
    const designs = S.products.filter(p => p.status === 'In Stock' && p.photo && !p.custody).sort((a, b) => num(b.createdAt) - num(a.createdAt)).slice(0, 30);
    const offers = String(pro().tvOffers || '').split('\n').map(x => x.trim()).filter(Boolean);
    const vis = pro().vision || {}; const vDate = vis.on === false ? '' : (vis.date || '2027-10-27');
    const extra = [];
    offers.forEach(t => extra.push({ t: 'offer', text: t }));
    extra.push({ t: 'promo', k: 'exchange', h: 'Purana Sona Badlein', s: 'Karat meter se turant jaanch · sabse achha bhaav · usi din naya gehna' });
    extra.push({ t: 'promo', k: 'hallmark', h: 'BIS Hallmark · HUID', s: 'Har gehne par HUID — BIS CARE app se khud jaanchiye' });
    if (vDate && daysBetween(todayStr(), vDate) > 0) extra.push({ t: 'cd', date: vDate, title: !vis.title || /naya showroom/i.test(vis.title) ? "Shivaa's Showroom" : vis.title });
    extra.push({ t: 'promo', k: 'wedding', h: 'Shaadi ki Booking Chalu', s: 'Bhaav lock karein · poore parivaar ka set ek jagah · custom design' });
    const out = []; let e = 0;
    if (!designs.length) { out.push({ t: 'shop' }); extra.forEach(x => { out.push(x); out.push({ t: 'shop' }); }); return out.slice(0, -1); }
    designs.forEach((p, i) => { out.push({ t: 'p', p }); if (i % 3 === 2) out.push(extra[e++ % extra.length]); });
    if (designs.length < 3) extra.forEach(x => out.push(x));
    return out;
  }
  const tokNow = () => (S.qTokens || []).filter(x => x.date === todayStr() && x.status === 'serve').sort((a, b) => b.servedAt - a.servedAt).slice(0, 3);
  const tNo = x => 'T-' + String(x.n).padStart(3, '0');

  /* ---------------- odometer numbers ---------------- */
  const fmt = n => Math.round(num(n)).toLocaleString('en-IN');
  function odo(el, value, delay) {
    const str = value ? fmt(value) : '—';
    if (el.dataset.s === str) return; const first = !el.dataset.s; el.dataset.s = str;
    if (!value) { el.innerHTML = '<span class="tv-dash">—</span>'; return; }
    const cells = [...str];
    if (el.children.length !== cells.length) el.innerHTML = cells.map(c => /\d/.test(c) ? `<span class="tv-dg"><span class="tv-rl">${'0123456789'.split('').map(d => `<i>${d}</i>`).join('')}</span></span>` : `<span class="tv-sep">${c}</span>`).join('');
    [...el.children].forEach((sp, i) => {
      const c = cells[i]; if (!/\d/.test(c)) return; const rl = sp.firstChild; const n = +c;
      if (first) { rl.style.transition = 'none'; rl.style.transform = 'translate3d(0,0,0)'; void rl.offsetWidth; }
      rl.style.transition = `transform ${RM() ? 0 : 1.4 + i * 0.12}s cubic-bezier(.2,.9,.25,1.12) ${first ? (delay || 0) + i * 0.05 : 0}s`;
      rl.style.transform = `translate3d(0,${-n * 10}%,0)`;
    });
  }
  function spark(line, w, h) {
    if (!line || line.length < 2) return '';
    const mn = Math.min(...line), mx = Math.max(...line), r = mx - mn || 1;
    const pts = line.map((v, i) => [i / (line.length - 1) * w, h - 4 - (v - mn) / r * (h - 8)]);
    const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
    const up = line[line.length - 1] >= line[0];
    return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" class="tv-spark ${up ? 'up' : 'dn'}"><defs><linearGradient id="tvsg${up ? 1 : 0}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="currentColor" stop-opacity=".35"/><stop offset="1" stop-color="currentColor" stop-opacity="0"/></linearGradient></defs><path d="${d} L${w} ${h} L0 ${h}Z" fill="url(#tvsg${up ? 1 : 0})" class="tv-area"/><path d="${d}" class="tv-line" pathLength="1"/><circle cx="${pts[pts.length - 1][0]}" cy="${pts[pts.length - 1][1]}" r="3.5" class="tv-dot"/></svg>`;
  }

  /* ---------------- build ---------------- */
  function shell() {
    const s = settings();
    return `<div class="tv-glow g1"></div><div class="tv-glow g2"></div><canvas class="tv-dust"></canvas><div class="tv-vig"></div>
      <button type="button" class="tv-x" aria-label="TV band karo">✕</button>
      <div class="tv-root">
        <div class="tv-top">
          <div class="tv-brand">${s.logo ? `<img class="tv-logo" alt="">` : ''}<div><div class="tv-firm">${esc(s.firm || 'Shivaa Jewels')}</div><div class="tv-tag">${esc(pro().tvTag || 'Vishwas ki chamak · Since generations')}</div></div></div>
          <div class="tv-clockbox"><span class="tv-live"><i></i>LIVE</span><div class="tv-clock"><b data-o="hm">--:--</b><span data-o="ss">--</span><em data-o="ap"></em></div><div class="tv-date" data-o="date"></div></div>
        </div>
        <div class="tv-main">
          <div class="tv-rates"><div class="tv-rh"><h2>Aaj ka Bhaav</h2><span>Today's Rate · ${esc(new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }))}</span></div><div class="tv-cards" data-o="cards"></div><div class="tv-note" data-o="note"></div></div>
          <div class="tv-show"><div class="tv-layer" data-l="a"></div><div class="tv-layer" data-l="b"></div><div class="tv-prog"><i data-o="prog"></i></div><div class="tv-dots" data-o="dots"></div></div>
        </div>
        <div class="tv-bot"><div class="tv-tok" data-o="tok"></div><div class="tv-tick"><div class="tv-track" data-o="track"></div></div></div>
      </div><div class="tv-flash" data-o="flash"><span>✦ BHAAV UPDATE ✦</span></div>`;
  }
  function paintCards(root, R, first) {
    const box = q$('[data-o="cards"]', root);
    if (first || box.children.length !== R.length) box.innerHTML = R.map((r, i) => `<div class="tv-card" data-k="${r.key}" style="--i:${i}"><div class="tv-cl"><b>${esc(r.label)}</b><span>${esc(r.sub)}</span></div><div class="tv-cv"><div class="tv-num"><span class="tv-rs">₹</span><span class="tv-odo"></span></div><div class="tv-unit">per ${esc(r.unit)}</div></div><div class="tv-cx"><span class="tv-chg"></span><div class="tv-sp"></div></div></div>`).join('');
    R.forEach((r, i) => {
      const c = box.children[i]; odo(q$('.tv-odo', c), r.v, first ? 0.3 + i * 0.25 : 0);
      const ch = q$('.tv-chg', c); ch.className = 'tv-chg ' + (r.d > 0 ? 'up' : r.d < 0 ? 'dn' : 'eq'); ch.textContent = r.d > 0 ? `▲ ₹${fmt(r.d)}` : r.d < 0 ? `▼ ₹${fmt(-r.d)}` : '● Sthir';
      const sp = q$('.tv-sp', c); const key = r.line.join(','); if (sp.dataset.k !== key) { sp.dataset.k = key; sp.innerHTML = spark(r.line, 160, 46); }
    });
    const s = settings(); q$('[data-o="note"]', root).textContent = (s.ratesUpdated === todayStr() ? 'Bhaav aaj update hua' : 'Bhaav ke liye counter par poochhiye') + ' · GST 3% + making alag · 916 Hallmark gehne';
  }
  function slideHtml(x) {
    if (x.t === 'p') { const p = x.p; return `<div class="tv-kb" style="background-image:url('${esc(p.photo)}')"></div><div class="tv-cap"><span class="tv-new">✦ NAYA DESIGN</span><b>${esc(p.category || 'Naya design')}</b><span>${esc(p.purity || '')}${num(p.gross) ? ' · ' + num(p.gross).toFixed(2) + ' g' : ''} · BIS Hallmark</span></div>`; }
    if (x.t === 'shop') return `<div class="tv-kb" style="background-image:url('vision-shop.jpg')"></div><div class="tv-cap"><span class="tv-new">✦ SHIVAA JEWELS</span><b>Sone ka Vishwas</b><span>Jayal, Nagaur · Wholesale &amp; Retail</span></div>`;
    if (x.t === 'offer') return `<div class="tv-promo"><div class="tv-orb"></div><span class="tv-new">✦ AAJ KA OFFER</span><b>${esc(x.text)}</b><em>Sirf ${esc(settings().firm || 'Shivaa Jewels')} par</em></div>`;
    if (x.t === 'promo') return `<div class="tv-promo k-${x.k}"><div class="tv-orb"></div><span class="tv-new">✦ ${x.k === 'exchange' ? 'EXCHANGE' : x.k === 'hallmark' ? 'SHUDDHTA KI GUARANTEE' : 'SHAADI SEASON'}</span><b>${esc(x.h)}</b><em>${esc(x.s)}</em></div>`;
    if (x.t === 'cd') return `<div class="tv-kb dim" style="background-image:url('vision-shop.jpg')"></div><div class="tv-cd"><span class="tv-new">✦ COMING SOON</span><b>${esc(x.title)}</b><div class="tv-cdn" data-cd="${esc(x.date)}"><div><i data-u="d">0</i><small>din</small></div><div><i data-u="h">00</i><small>ghante</small></div><div><i data-u="m">00</i><small>minute</small></div><div><i data-u="s">00</i><small>second</small></div></div><em>${esc(new Date(x.date + 'T12:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }))}</em></div>`;
    return '';
  }
  function tickerText() {
    const R = rates(); const offers = String(pro().tvOffers || '').split('\n').map(x => x.trim()).filter(Boolean);
    const parts = R.filter(r => r.v).map(r => `<b>${esc(r.label)}</b> ₹${fmt(r.v)} <small>/${esc(r.unit)}</small> <i class="${r.d > 0 ? 'up' : r.d < 0 ? 'dn' : ''}">${r.d > 0 ? '▲' : r.d < 0 ? '▼' : '●'}</i>`);
    offers.forEach(o => parts.push(esc(o)));
    parts.push('916 BIS Hallmark gehne', 'Purana sona badlein — turant jaanch', 'Shaadi ki booking chalu', `📞 ${esc(settings().phone || '')}`);
    return parts.filter(Boolean).map(p => `<span>${p}</span><span class="tv-star">✦</span>`).join('');
  }

  /* ---------------- motion engines ---------------- */
  /* gold dust: one pre-drawn sprite, max 30 frames / second, few particles — cheap on TV / tablet GPUs */
  function dust(cv, lite, few) {
    const x = cv.getContext('2d', { alpha: true }); let W = 0, H = 0, P = [], raf = 0, last = 0, on = true;
    const spr = document.createElement('canvas'); spr.width = spr.height = 32; { const g = spr.getContext('2d'); const gr = g.createRadialGradient(16, 16, 0, 16, 16, 16); gr.addColorStop(0, 'rgba(255,236,170,1)'); gr.addColorStop(.35, 'rgba(255,214,120,.55)'); gr.addColorStop(1, 'rgba(255,200,90,0)'); g.fillStyle = gr; g.fillRect(0, 0, 32, 32); }
    const size = () => { W = cv.clientWidth; H = cv.clientHeight; cv.width = W; cv.height = H; };
    const mk = y => ({ x: Math.random() * W, y: y == null ? Math.random() * H : y, s: Math.random() * 9 + 5, vy: -(Math.random() * 0.5 + 0.15), vx: (Math.random() - 0.5) * 0.2, a: Math.random() * 6.3, tw: Math.random() * 0.05 + 0.02 });
    size(); P = Array.from({ length: Math.round(Math.min(few ? 22 : 46, W * H / (few ? 70000 : 40000))) }, () => mk());
    const step = t => {
      raf = requestAnimationFrame(step); if (!on || t - last < 33) return; last = t;
      x.clearRect(0, 0, W, H);
      for (const p of P) { p.x += p.vx; p.y += p.vy; p.a += p.tw; if (p.y < -20) Object.assign(p, mk(H + 20)); x.globalAlpha = 0.25 + 0.6 * (0.5 + 0.5 * Math.sin(p.a)); x.drawImage(spr, p.x - p.s / 2, p.y - p.s / 2, p.s, p.s); }
      x.globalAlpha = 1;
    };
    if (!RM() && !lite) raf = requestAnimationFrame(step); window.addEventListener('resize', size);
    return { stop: () => { cancelAnimationFrame(raf); window.removeEventListener('resize', size); }, pause: v => { on = !v; if (v) x.clearRect(0, 0, W, H); } };
  }
  /* the black logo → gold, once, on a canvas (no live CSS filter / blend mode) */
  let goldLogo = null;
  function logoGold(src) {
    if (goldLogo) return Promise.resolve(goldLogo);
    return new Promise(res => { const im = new Image(); im.onload = () => { try { const w = im.naturalWidth, h = im.naturalHeight, c = document.createElement('canvas'); c.width = w; c.height = h; const g = c.getContext('2d'); g.drawImage(im, 0, 0); const d = g.getImageData(0, 0, w, h), a = d.data;
      for (let i = 0; i < a.length; i += 4) { const lum = (a[i] * 0.3 + a[i + 1] * 0.59 + a[i + 2] * 0.11) / 255; const al = (1 - lum) * (a[i + 3] / 255); const k = i / 4, yy = Math.floor(k / w) / h; a[i] = 250 - 30 * yy; a[i + 1] = 214 - 50 * yy; a[i + 2] = 120 - 70 * yy; a[i + 3] = Math.round(Math.min(1, al * 1.4) * 255); }
      g.putImageData(d, 0, 0); goldLogo = c.toDataURL('image/png'); } catch (e) { goldLogo = src; } res(goldLogo); }; im.onerror = () => res(src); im.src = src; });
  }

  function start(opt) {
    if (T) return; fonts(); opt = opt || {};
    const ov = document.createElement('div'); ov.className = 'tv-ov'; ov.innerHTML = shell(); document.body.appendChild(ov);
    document.documentElement.classList.add('tv-on');                  // the software behind stops painting
    const root = q$('.tv-root', ov), tm = [];
    const fx = pro().tvFx || 'auto'; let lite = fx === 'lite';
    const coarse = (() => { try { return matchMedia('(pointer: coarse)').matches || (navigator.deviceMemory && navigator.deviceMemory <= 4); } catch (e) { return false; } })();
    if (lite) ov.classList.add('tv-lite'); else if (fx === 'auto' && coarse) ov.classList.add('tv-mid');
    const D = dust(q$('.tv-dust', ov), lite, ov.classList.contains('tv-mid')); const stopDust = D.stop;
    const lg = q$('.tv-logo', ov); if (lg) logoGold(settings().logo).then(u => { lg.src = u; });
    // smooth-guard: a slow TV / tablet switches itself to the light mode (no blinking, no jerks)
    if (fx === 'auto' && !RM()) setTimeout(() => { if (!T) return; let n = 0, t0 = 0; const f = t => { if (!t0) t0 = t; n++; if (t - t0 < 2500) requestAnimationFrame(f); else { const fps = n / ((t - t0) / 1000); ov.dataset.fps = Math.round(fps); if (fps < 42) { lite = true; ov.classList.add('tv-lite'); D.pause(true); } } }; requestAnimationFrame(f); }, 5000);
    // rates
    let R = rates(); paintCards(root, R, true); let rk = JSON.stringify(R.map(r => r.v));
    // ticker
    const track = q$('[data-o="track"]', root); const setTick = () => { const h = tickerText(); track.innerHTML = `<div>${h}</div><div aria-hidden="true">${h}</div>`; requestAnimationFrame(() => { const w = track.firstChild.scrollWidth; track.style.setProperty('--dur', Math.max(30, w / 70) + 's'); }); };
    setTick();
    // clock + countdown
    const clock = () => {
      const d = new Date(); let h = d.getHours(); const ap = h >= 12 ? 'PM' : 'AM'; h = h % 12 || 12;
      q$('[data-o="hm"]', root).textContent = `${h}:${String(d.getMinutes()).padStart(2, '0')}`; q$('[data-o="ss"]', root).textContent = String(d.getSeconds()).padStart(2, '0'); q$('[data-o="ap"]', root).textContent = ap;
      q$('[data-o="date"]', root).textContent = d.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
      root.querySelectorAll('[data-cd]').forEach(c => { const ms = Math.max(0, new Date(c.dataset.cd + 'T10:00:00+05:30') - d); const u = { d: Math.floor(ms / 864e5), h: Math.floor(ms / 36e5) % 24, m: Math.floor(ms / 6e4) % 60, s: Math.floor(ms / 1e3) % 60 }; Object.entries(u).forEach(([k, v]) => { const i = c.querySelector(`[data-u="${k}"]`); const t = k === 'd' ? String(v) : String(v).padStart(2, '0'); if (i && i.textContent !== t) { i.textContent = t; i.classList.remove('tk'); void i.offsetWidth; i.classList.add('tk'); } }); });
    };
    clock(); tm.push(setInterval(clock, 1000));
    // spotlight on rate cards
    let hi = 0; tm.push(setInterval(() => { const cs = root.querySelectorAll('.tv-card'); cs.forEach((c, i) => c.classList.toggle('hot', i === hi % cs.length)); hi++; }, 4000));
    // slides
    let SL = slides(), si = -1, cur = 'a'; const dots = q$('[data-o="dots"]', root), prog = q$('[data-o="prog"]', root);
    const dur = () => Math.max(5, num(pro().tvSec) || 8) * 1000;
    const next = () => {
      if (!SL.length) return; si = (si + 1) % SL.length; if (si === 0) SL = slides();
      const nx = cur === 'a' ? 'b' : 'a'; const L = q$(`[data-l="${nx}"]`, root), O = q$(`[data-l="${cur}"]`, root);
      L.className = 'tv-layer t-' + SL[si].t; L.innerHTML = slideHtml(SL[si]); void L.offsetWidth; L.classList.add('on'); O.classList.remove('on'); cur = nx;
      prog.style.transition = 'none'; prog.style.transform = 'scaleX(0)'; void prog.offsetWidth; prog.style.transition = `transform ${dur()}ms linear`; prog.style.transform = 'scaleX(1)';
      const n = Math.min(SL.length, 12); dots.innerHTML = Array.from({ length: n }, (_, k) => `<i class="${k === si % n ? 'on' : ''}"></i>`).join('');
      clock();
    };
    let sT = null; const loop = () => { next(); sT = setTimeout(loop, dur()); }; loop();
    // live data (sync keeps S fresh)
    let tk = null;
    const live = () => {
      const R2 = rates(); const k2 = JSON.stringify(R2.map(r => r.v));
      if (k2 !== rk) { rk = k2; paintCards(root, R2, false); setTick(); const f = q$('[data-o="flash"]', ov); f.classList.remove('go'); void f.offsetWidth; f.classList.add('go'); }
      const T2 = tokNow(); const k3 = T2.map(x => x.id).join(',');
      if (k3 !== tk) { tk = k3; const el = q$('[data-o="tok"]', root); el.innerHTML = T2.length ? `<span class="tv-tl">Ab ki baari</span>${T2.map((x, i) => `<span class="tv-tb ${i ? 'old' : ''}"><b>${tNo(x)}</b><small>${esc(x.servedBy || '')}</small></span>`).join('')}` : `<span class="tv-tl">Swagat hai</span><span class="tv-tb"><b>🙏</b><small>Counter par padhariye</small></span>`; el.classList.remove('pop'); void el.offsetWidth; el.classList.add('pop'); }
    };
    live(); tm.push(setInterval(live, 4000));
    // burn-in shift + cursor
    tm.push(setInterval(() => { root.style.transform = `translate(${Math.round(Math.random() * 6 - 3)}px,${Math.round(Math.random() * 6 - 3)}px)`; }, 60000));
    let ct = null; const mv = () => { ov.classList.add('cur'); clearTimeout(ct); ct = setTimeout(() => ov.classList.remove('cur'), 2500); }; ov.addEventListener('mousemove', mv); ov.addEventListener('touchstart', mv, { passive: true });
    // screen awake
    let wl = null; const wake = async () => { try { if ('wakeLock' in navigator && document.visibilityState === 'visible') wl = await navigator.wakeLock.request('screen'); } catch (e) { /* not allowed */ } };
    wake(); const vis = () => { if (document.visibilityState === 'visible') wake(); }; document.addEventListener('visibilitychange', vis);
    const key = e => { if (e.key === 'Escape') close(); };
    function close() { tm.forEach(clearInterval); clearTimeout(sT); clearTimeout(ct); stopDust(); document.removeEventListener('keydown', key); document.removeEventListener('visibilitychange', vis); try { if (wl) wl.release(); } catch (e) { /* ignore */ } try { if (document.fullscreenElement) document.exitFullscreen(); } catch (e) { /* ignore */ } ov.remove(); document.documentElement.classList.remove('tv-on'); T = null; }
    document.addEventListener('keydown', key); q$('.tv-x', ov).onclick = close;
    try { if (opt.full !== false && ov.requestFullscreen) ov.requestFullscreen().catch(() => null); } catch (e) { /* ignore */ }
    T = { close, next };
  }
  window.SJ_TV = { start, close: () => T && T.close(), rates, slides };
  /* seedha TV link: https://aapki-site/?tv=1 — login ke baad TV apne aap khulta hai */
  try { if (/[?&]tv=1\b/.test(location.search)) { const iv = setInterval(() => { if (typeof MODE !== 'undefined' && MODE !== 'connecting' && window.SJ_USER && S.settings && !T) { clearInterval(iv); setTimeout(() => start({ full: false }), 800); } }, 700); } } catch (e) { /* ignore */ }

  const st = document.createElement('style');
  st.textContent = `
  html.tv-on body>*:not(.tv-ov){display:none!important}html.tv-on body::before,html.tv-on body::after{animation:none!important;display:none!important}html.tv-on,html.tv-on body{overflow:hidden!important}
  .tv-ov{--g1:#fff0c4;--g2:#f3cf6f;--g3:#c9952a;--ink:#f8efd6;--mut:#bba982;--bg:#080603;position:fixed;inset:0;z-index:3000;overflow:hidden;color:var(--ink);background:radial-gradient(120% 90% at 50% -10%,#3a2808 0%,#1a1206 38%,#080603 75%);font-family:'SJ Poppins',Poppins,system-ui,sans-serif;cursor:none;user-select:none;-webkit-font-smoothing:antialiased}
  .tv-ov.cur{cursor:default}.tv-ov.cur .tv-x{opacity:1}
  .tv-glow{position:absolute;width:70vmax;height:70vmax;border-radius:50%;pointer-events:none;will-change:transform;background:radial-gradient(circle,rgba(243,190,80,.16),rgba(243,190,80,0) 62%)}
  .tv-glow.g1{left:-20vmax;top:-30vmax;animation:tvDrift1 26s ease-in-out infinite alternate}.tv-glow.g2{right:-25vmax;bottom:-35vmax;animation:tvDrift2 32s ease-in-out infinite alternate;background:radial-gradient(circle,rgba(201,149,42,.14),rgba(201,149,42,0) 62%)}
  @keyframes tvDrift1{to{transform:translate3d(18vmax,10vmax,0) scale(1.15)}}@keyframes tvDrift2{to{transform:translate3d(-16vmax,-12vmax,0) scale(.9)}}
  .tv-dust{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}
  .tv-vig{position:absolute;inset:0;pointer-events:none;background:radial-gradient(ellipse at center,transparent 55%,rgba(0,0,0,.6))}
  .tv-x{position:absolute;top:16px;right:16px;z-index:5;width:46px;height:46px;border-radius:50%;border:1px solid rgba(243,207,111,.45);background:rgba(0,0,0,.6);color:var(--g2);font-size:20px;cursor:pointer;opacity:0;transition:opacity .3s}
  .tv-root{position:relative;z-index:2;height:100%;display:grid;grid-template-columns:minmax(0,1fr);grid-template-rows:auto minmax(0,1fr) auto;gap:2.2vh;padding:3vh 3.2vw 2.6vh;box-sizing:border-box;transition:transform 3s ease}
  .tv-top{display:flex;justify-content:space-between;align-items:center;gap:2vw;animation:tvDown 1s cubic-bezier(.2,.8,.2,1) both}
  @keyframes tvDown{from{opacity:0;transform:translate3d(0,-30px,0)}}
  .tv-brand{display:flex;align-items:center;gap:1.4vw;min-width:0}.tv-logo{height:clamp(50px,9vh,104px);width:auto;opacity:0;transition:opacity .8s}.tv-logo[src]{opacity:1}
  .tv-firm{font:700 clamp(30px,4.6vw,78px)/1.05 'SJ Lora',Lora,Georgia,serif;letter-spacing:.5px;color:#f6d47e;text-shadow:0 2px 0 #7a5514,0 0 28px rgba(243,190,80,.28);white-space:nowrap}
  .tv-tag{margin-top:.6vh;font-size:clamp(12px,1.25vw,22px);letter-spacing:.35em;text-transform:uppercase;color:var(--mut)}
  .tv-clockbox{display:flex;flex-direction:column;align-items:flex-end;gap:.4vh}
  .tv-live{display:inline-flex;align-items:center;gap:.5em;font:700 clamp(11px,1vw,18px) 'SJ Poppins',sans-serif;letter-spacing:.2em;color:#fff;background:#dc2626;padding:.35em .9em;border-radius:99px}.tv-live i{width:.6em;height:.6em;border-radius:50%;background:#fff;animation:tvBlink 1.4s ease-in-out infinite}
  @keyframes tvBlink{50%{opacity:.25}}
  .tv-clock{display:flex;align-items:baseline;gap:.25em;font-variant-numeric:tabular-nums}.tv-clock b{font:600 clamp(30px,4vw,68px)/1 'SJ Poppins',sans-serif;color:var(--ink);min-width:3.1em;text-align:right}.tv-clock span{font:500 clamp(18px,2vw,34px) 'SJ Poppins',sans-serif;color:var(--g2);width:1.3em}.tv-clock em{font-style:normal;font-size:clamp(12px,1.1vw,20px);color:var(--mut)}
  .tv-date{font-size:clamp(12px,1.2vw,21px);color:var(--mut)}
  .tv-main{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.05fr);gap:2.4vw}
  .tv-rates{min-height:0;display:flex;flex-direction:column;gap:1.4vh}
  .tv-rh{display:flex;align-items:baseline;gap:1vw;animation:tvFade 1s .2s both}.tv-rh h2{margin:0;font:700 clamp(22px,2.6vw,46px) 'SJ Lora',Georgia,serif;color:var(--g2)}.tv-rh span{font-size:clamp(11px,1.1vw,19px);color:var(--mut);letter-spacing:.12em;text-transform:uppercase}
  @keyframes tvFade{from{opacity:0}}
  .tv-cards{flex:1;min-height:0;display:grid;grid-template-rows:repeat(4,1fr);gap:1.4vh}
  .tv-card{position:relative;isolation:isolate;display:grid;grid-template-columns:minmax(0,1.05fr) minmax(0,1.5fr) minmax(0,.9fr);align-items:center;gap:1.2vw;padding:0 1.6vw;border-radius:clamp(14px,1.4vw,26px);background:linear-gradient(135deg,#2a1e0b,#15100a 55%,#0d0a06);border:1px solid rgba(243,207,111,.24);overflow:hidden;animation:tvIn .9s cubic-bezier(.2,.9,.2,1) both;animation-delay:calc(.35s + var(--i) * .18s);transition:border-color .8s}
  @keyframes tvIn{from{opacity:0;transform:translate3d(-60px,0,0)}}
  .tv-card::before{content:'';position:absolute;inset:0;z-index:-1;border-radius:inherit;background:radial-gradient(120% 140% at 20% 0,rgba(243,190,80,.22),transparent 60%);opacity:0;transition:opacity .8s}
  .tv-card::after{content:'';position:absolute;top:0;bottom:0;left:0;width:35%;z-index:2;pointer-events:none;background:linear-gradient(100deg,transparent,rgba(255,240,200,.16),transparent);transform:translate3d(-130%,0,0) skewX(-18deg)}
  .tv-card.hot{border-color:rgba(243,207,111,.8)}.tv-card.hot::before{opacity:1}.tv-card.hot::after{animation:tvSweep 1.8s .2s ease-in-out}
  @keyframes tvSweep{to{transform:translate3d(330%,0,0) skewX(-18deg)}}
  .tv-cl{display:flex;flex-direction:column;min-width:0}.tv-cl b{font:600 clamp(16px,1.75vw,32px) 'SJ Poppins',sans-serif;color:var(--ink);white-space:nowrap}.tv-cl span{font-size:clamp(10px,.95vw,17px);color:var(--mut);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
  .tv-cv{display:flex;flex-direction:column;align-items:flex-end}
  .tv-num{display:flex;align-items:baseline;font:700 clamp(30px,3.9vw,74px)/1 'SJ Lora',Georgia,serif;color:#f8dc8e}
  .tv-num .tv-rs{font-size:.62em;margin-right:.08em;color:var(--g2)}
  .tv-odo{display:inline-flex}.tv-dg{display:inline-block;position:relative;height:1.1em;overflow:hidden;width:.62em;text-align:center;contain:paint}
  .tv-rl{display:block;height:1000%;transform:translate3d(0,0,0);backface-visibility:hidden;will-change:transform}.tv-rl i{display:block;font-style:normal;height:10%;line-height:1.1em;color:#f8dc8e}
  .tv-sep{display:inline-block;width:.28em;text-align:center;color:var(--g3)}.tv-dash{color:var(--mut)}
  .tv-unit{font-size:clamp(10px,.9vw,16px);color:var(--mut);letter-spacing:.08em;margin-top:.3vh}
  .tv-cx{display:flex;flex-direction:column;align-items:flex-end;gap:.6vh;min-width:0}
  .tv-chg{font:600 clamp(11px,1vw,18px) 'SJ Poppins',sans-serif;padding:.25em .7em;border-radius:99px;white-space:nowrap}.tv-chg.up{color:#4ade80;background:rgba(74,222,128,.12)}.tv-chg.dn{color:#f87171;background:rgba(248,113,113,.12)}.tv-chg.eq{color:var(--mut);background:rgba(255,255,255,.06)}
  .tv-sp{width:100%;max-width:170px;height:clamp(28px,4.4vh,52px)}.tv-spark{width:100%;height:100%;overflow:visible}.tv-spark.up{color:#4ade80}.tv-spark.dn{color:#f87171}
  .tv-line{fill:none;stroke:currentColor;stroke-width:2.4;stroke-linejoin:round;stroke-linecap:round;stroke-dasharray:1;stroke-dashoffset:1;animation:tvDraw 2.2s .8s ease forwards}.tv-area{opacity:0;animation:tvFade2 1.2s 2s forwards}.tv-dot{fill:currentColor;opacity:0;animation:tvFade2 .5s 2.8s forwards}
  @keyframes tvDraw{to{stroke-dashoffset:0}}@keyframes tvFade2{to{opacity:1}}
  .tv-note{font-size:clamp(10px,.95vw,17px);color:var(--mut);animation:tvFade 1s 1.4s both}
  .tv-show{position:relative;isolation:isolate;min-height:0;border-radius:clamp(18px,1.8vw,34px);overflow:hidden;background:#0c0904;border:2px solid rgba(243,207,111,.45);box-shadow:0 0 0 6px rgba(243,207,111,.06);animation:tvRise 1.1s .3s cubic-bezier(.2,.9,.2,1) both}
  @keyframes tvRise{from{opacity:0;transform:translate3d(0,40px,0)}}
  .tv-layer{position:absolute;inset:0;opacity:0;transition:opacity 1.2s ease;display:flex;align-items:flex-end;overflow:hidden}.tv-layer.on{opacity:1;z-index:1}
  .tv-kb{position:absolute;inset:0;background-size:cover;background-position:center;transform:scale(1.12);backface-visibility:hidden;will-change:transform}.tv-layer.on .tv-kb{animation:tvKen 14s linear forwards}.tv-kb.dim::after{content:'';position:absolute;inset:0;background:rgba(5,3,1,.66)}
  @keyframes tvKen{from{transform:scale(1.12) translate3d(1.5%,1%,0)}to{transform:scale(1.02) translate3d(-1%,-.5%,0)}}
  .tv-cap{position:relative;z-index:1;width:100%;padding:8vh 2.4vw 4vh;background:linear-gradient(rgba(5,3,1,0),rgba(5,3,1,.62) 35%,rgba(5,3,1,.94));display:flex;flex-direction:column;gap:.6vh}
  .tv-new{display:inline-block;align-self:flex-start;font:700 clamp(10px,1vw,17px) 'SJ Poppins',sans-serif;letter-spacing:.3em;color:#1b1206;background:linear-gradient(90deg,var(--g1),var(--g2),var(--g3));padding:.35em .9em;border-radius:6px}
  .tv-cap b{font:700 clamp(26px,3.4vw,62px)/1.05 'SJ Lora',Georgia,serif;color:var(--g1)}.tv-cap span:not(.tv-new){font-size:clamp(13px,1.35vw,24px);color:var(--ink)}
  .tv-layer.on .tv-cap>*{animation:tvUp .9s cubic-bezier(.2,.9,.2,1) both}.tv-layer.on .tv-cap>*:nth-child(2){animation-delay:.15s}.tv-layer.on .tv-cap>*:nth-child(3){animation-delay:.3s}
  @keyframes tvUp{from{opacity:0;transform:translate3d(0,26px,0)}}
  .tv-promo,.tv-cd{position:relative;z-index:1;width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;gap:2.2vh;padding:4vh 3vw;box-sizing:border-box;background:radial-gradient(circle at 50% 40%,rgba(201,149,42,.22),rgba(201,149,42,0) 60%)}
  .tv-promo .tv-new,.tv-cd .tv-new{align-self:center}
  .tv-promo b{font:700 clamp(30px,4.2vw,80px)/1.1 'SJ Lora',Georgia,serif;color:#f6d47e;text-shadow:0 3px 0 #6b4a10;max-width:92%}
  .tv-promo em,.tv-cd em{font-style:normal;font-size:clamp(14px,1.5vw,27px);color:var(--ink);max-width:80%}
  .tv-layer.on .tv-promo>*:not(.tv-orb),.tv-layer.on .tv-cd>*{animation:tvZoomIn 1s cubic-bezier(.2,.9,.2,1) both}.tv-layer.on .tv-promo>*:nth-child(3),.tv-layer.on .tv-cd>*:nth-child(2){animation-delay:.18s}.tv-layer.on .tv-promo>*:nth-child(4),.tv-layer.on .tv-cd>*:nth-child(3){animation-delay:.36s}.tv-layer.on .tv-cd>*:nth-child(4){animation-delay:.5s}
  @keyframes tvZoomIn{from{opacity:0;transform:translate3d(0,20px,0) scale(.9)}}
  .tv-orb{position:absolute;width:60%;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle,rgba(243,207,111,.26),rgba(243,207,111,0) 65%);animation:tvOrb 10s ease-in-out infinite alternate;pointer-events:none;will-change:transform}
  @keyframes tvOrb{from{transform:translate3d(-20%,-10%,0) scale(.9)}to{transform:translate3d(20%,10%,0) scale(1.12)}}
  .tv-cd b{font:700 clamp(28px,3.8vw,72px)/1.05 'SJ Lora',Georgia,serif;color:var(--g1)}
  .tv-cdn{display:flex;gap:1.2vw}.tv-cdn div{display:flex;flex-direction:column;align-items:center;min-width:clamp(60px,6.5vw,128px);padding:1.4vh .6vw;border-radius:14px;background:#0b0804;border:1px solid rgba(243,207,111,.35)}
  .tv-cdn i{font:700 clamp(28px,3.6vw,68px)/1 'SJ Poppins',sans-serif;font-style:normal;color:var(--g1);font-variant-numeric:tabular-nums}.tv-cdn i.tk{animation:tvTick .45s ease}.tv-cdn small{font-size:clamp(10px,.9vw,16px);color:var(--mut);letter-spacing:.15em;text-transform:uppercase;margin-top:.6vh}
  @keyframes tvTick{from{transform:translate3d(0,-35%,0);opacity:.2}}
  .tv-prog{position:absolute;left:0;right:0;bottom:0;height:4px;z-index:4;background:rgba(255,255,255,.08)}.tv-prog i{display:block;height:100%;width:100%;transform:scaleX(0);transform-origin:left center;background:linear-gradient(90deg,var(--g3),var(--g1));will-change:transform}
  .tv-dots{position:absolute;top:2.2vh;right:1.6vw;z-index:4;display:flex;gap:6px}.tv-dots i{width:8px;height:8px;border-radius:99px;background:rgba(255,255,255,.3)}.tv-dots i.on{width:26px;background:var(--g2)}
  .tv-bot{display:flex;align-items:center;gap:1.6vw;min-width:0;overflow:hidden;min-height:clamp(54px,8vh,100px);border-top:1px solid rgba(243,207,111,.22);padding-top:1.6vh;animation:tvUp 1s .6s both}
  .tv-tok{display:flex;align-items:center;gap:.9vw;flex:none}.tv-tok.pop{animation:tvPop .8s cubic-bezier(.2,1.6,.4,1)}
  @keyframes tvPop{0%{transform:scale(.8);opacity:.3}100%{transform:scale(1)}}
  .tv-tl{font-size:clamp(11px,1vw,18px);letter-spacing:.2em;text-transform:uppercase;color:var(--mut)}
  .tv-tb{display:flex;flex-direction:column;align-items:center;padding:.5vh 1.1vw;border-radius:14px;background:linear-gradient(135deg,#3a2a0c,#1a1308);border:1px solid rgba(243,207,111,.55)}.tv-tb b{font:700 clamp(20px,2.4vw,44px)/1 'SJ Lora',Georgia,serif;color:var(--g1)}.tv-tb small{font-size:clamp(10px,.85vw,15px);color:var(--ink)}.tv-tb.old{opacity:.55;transform:scale(.85)}
  .tv-tick{position:relative;flex:1;min-width:0;overflow:hidden}.tv-tick::before,.tv-tick::after{content:'';position:absolute;top:0;bottom:0;width:6%;z-index:1;pointer-events:none}.tv-tick::before{left:0;background:linear-gradient(90deg,var(--bg),rgba(8,6,3,0))}.tv-tick::after{right:0;background:linear-gradient(270deg,var(--bg),rgba(8,6,3,0))}
  .tv-track{display:flex;width:max-content;animation:tvMarq var(--dur,60s) linear infinite;will-change:transform;backface-visibility:hidden}.tv-track>div{display:flex;align-items:center;gap:2.2vw;padding-right:2.2vw;white-space:nowrap;font-size:clamp(15px,1.6vw,30px)}
  .tv-track b{color:var(--g2);font-weight:600}.tv-track small{color:var(--mut);font-size:.65em}.tv-track i{font-style:normal;font-size:.75em}.tv-track i.up{color:#4ade80}.tv-track i.dn{color:#f87171}.tv-star{color:var(--g3)}
  @keyframes tvMarq{from{transform:translate3d(0,0,0)}to{transform:translate3d(-50%,0,0)}}
  .tv-flash{position:absolute;inset:0;z-index:4;pointer-events:none;display:flex;align-items:center;justify-content:center;opacity:0}.tv-flash span{font:700 clamp(28px,4vw,76px) 'SJ Lora',Georgia,serif;letter-spacing:.2em;color:#1b1206;background:linear-gradient(90deg,var(--g3),var(--g1),var(--g3));padding:.4em 1.2em;border-radius:20px}
  .tv-flash.go{animation:tvFlash 2.6s ease both}@keyframes tvFlash{0%{opacity:0;transform:scale(.6)}15%{opacity:1;transform:scale(1.05)}25%{transform:scale(1)}75%{opacity:1}100%{opacity:0;transform:scale(1.1)}}
  /* light mode: kamzor TV / tablet — same look, fewer moving layers */
  .tv-lite .tv-dust,.tv-lite .tv-glow,.tv-lite .tv-card::after,.tv-lite .tv-orb{display:none}
  .tv-lite .tv-layer.on .tv-kb{animation:none;transform:none}.tv-lite .tv-kb{transform:none}
  .tv-lite .tv-live i{animation:none}
  .tv-mid .tv-glow,.tv-mid .tv-card::after{display:none}
  @media (max-aspect-ratio:1/1){.tv-main{display:flex;flex-direction:column;gap:2vh}.tv-rates,.tv-show{width:100%;align-self:stretch}.tv-show{flex:1;min-height:30vh}.tv-sp{max-width:none}.tv-cards{grid-template-rows:none;grid-template-columns:1fr 1fr}.tv-card{grid-template-columns:1fr;padding:1.6vh 3vw;gap:.6vh}.tv-cv,.tv-cx{align-items:flex-start}.tv-firm{font-size:clamp(26px,7vw,64px)}.tv-tag{display:none}}
  @media (prefers-reduced-motion:reduce){.tv-ov *{animation-duration:.01s!important;animation-iteration-count:1!important}}`;
  document.head.appendChild(st);
})();
