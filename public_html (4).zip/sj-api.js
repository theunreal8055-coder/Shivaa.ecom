/* =====================================================================
   Shivaa Jewels — website connector
   The software was built to save into Claude's cloud. On your own website
   this file takes that place: every record is saved on your hosting
   server through sj-api.php, behind a password login, and every phone or
   computer that logs in sees the same data (checked every few seconds).
   ===================================================================== */
(() => {
  'use strict';
  const API = 'sj-api.php';
  const POLL_MS = 5000;
  const BATCH_BYTES = 2000000;

  /* ---------------- errors & server calls ---------------- */
  class ApiError extends Error {
    constructor(code, message, status) { super(message || code); this.code = code; this.status = status || 0; }
  }

  /* v42: practice mode — the software works on a copy in memory; nothing reaches the server or this device's saved copy */
  const PRACTICE = (() => { try { return sessionStorage.getItem('sj-practice') === '1'; } catch (e) { return false; } })();
  const PRACTICE_OK = new Set(['sync', 'status', 'ping', 'login', 'logout', 'sec_status', 'pin_check', 'pin_ok', 'health', 'uext_list', 'gps_live', 'gps_track', 'emerg_status', 'ai', 'ai_status', 'lock_status', 'totp_status', 'alert_status', 'catalog_status', 'backup_list', 'tg_status', 'err_list', 'login_untils', 'devices', 'confirm_tok', 'conf_hash', 'keys']);
  window.SJ_PRACTICE = PRACTICE;
  async function rawCall(action, body, o) {
    if (PRACTICE && !PRACTICE_OK.has(action)) throw new ApiError('practice', 'Practice mode mein ye kaam asli server par nahi jaata. Practice band karke kijiye.');
    let res, text; const ms = o && o.timeout; const ctl = ms ? new AbortController() : null; const tm = ctl ? setTimeout(() => ctl.abort(), ms) : null;
    try {
      res = await fetch(API + '?a=' + encodeURIComponent(action), {
        method: 'POST', credentials: 'same-origin', cache: 'no-store',
        headers: { 'Content-Type': 'application/json', 'X-SJ': '1' },
        body: JSON.stringify(body || {}), signal: ctl ? ctl.signal : undefined
      });
      text = await res.text();
    } catch (e) {
      if (ctl && ctl.signal.aborted) throw new ApiError('timeout', 'Server ne ' + Math.round(ms / 1000) + ' second mein jawab nahi diya. Internet / hosting check karke dobara try kijiye.');
      throw new ApiError('unavailable', 'Server se connection nahi ho paya. Internet check kijiye.');
    } finally { if (tm) clearTimeout(tm); }
    let j;
    try { j = JSON.parse(text); } catch (e) {
      if (text.indexOf('<?php') !== -1) throw new ApiError('no_php', 'Hosting par PHP nahi chal raha — sj-api.php file chal nahi rahi. Hosting mein PHP 7.4 ya naya on kijiye.');
      if (res.status === 404) throw new ApiError('no_api', 'sj-api.php file nahi mili. Zip ki saari files isi folder mein extract kijiye.');
      throw new ApiError(res.status >= 500 ? 'unavailable' : 'bad_response', 'Server ka jawab samajh nahi aaya (HTTP ' + res.status + ').', res.status);
    }
    if (!res.ok || !j || !j.ok) { const er = new ApiError((j && j.error) || 'unavailable', (j && j.message) || ('Server error (HTTP ' + res.status + ')'), res.status); er.data = j || null; throw er; }
    return j;
  }

  async function call(action, body, o) {
    for (let attempt = 0; ; attempt++) {
      try { return await rawCall(action, body, o); }
      catch (e) {
        if (e.code === 'login_required' && attempt < 2) { await requireLogin('Login ka samay khatam ho gaya — dobara login kijiye.'); continue; }
        if ((e.code === 'pin_required' || e.code === 'pin_not_set') && attempt < 3 && action !== 'pin_check' && action !== 'pin_set') { await askPin(e.code, e.message); continue; }
        if (e.code === 'off_hours') offHours(e.message);
        throw e;
      }
    }
  }

  // error codes the software already understands
  function appError(e) {
    const map = { too_large: 'invalid_argument', invalid_argument: 'invalid_argument', bad_json: 'invalid_argument', throttled: 'resource_exhausted', forbidden_role: 'invalid_argument', decrypt: 'invalid_argument', key_missing: 'invalid_argument' };
    const err = new Error(e && e.message ? e.message : 'save failed');
    err.code = map[e && e.code] || 'unavailable';
    if (e && e.code && map[e.code] === 'invalid_argument' && e.message) err.sjMsg = e.message;
    return err;
  }

  /* ---------------- who is logged in ---------------- */
  let CUR = null;
  const ROLE_L = { owner: 'Owner', manager: 'Manager', staff: 'Staff', viewer: 'View only' };
  function setUser(u) {
    CUR = u || null; window.SJ_USER = CUR;
    if (CUR) { try { localStorage.setItem('shivaa-user', JSON.stringify(CUR.name)); localStorage.setItem('sj-uname', CUR.uname); } catch (e) { /* ignore */ } }
    document.documentElement.dataset.sjRole = CUR ? CUR.role : '';
  }

  /* ---------------- little UI: login, errors, connection pill ---------------- */
  const domReady = new Promise(r => {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', r, { once: true }); else r();
  });
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const CSS = `
  .sjw-ov{position:fixed;inset:0;z-index:2000;display:flex;align-items:center;justify-content:center;padding:16px;background:var(--bg,#0B0F19);overflow-y:auto}
  .sjw-ov.dim{background:var(--overlay,rgba(3,6,12,.72));backdrop-filter:blur(3px)}
  .sjw-box{width:100%;max-width:400px;background:var(--card,#131A2A);border:1px solid var(--line2,#27344F);border-radius:26px;padding:24px 20px;box-shadow:var(--shadow,0 14px 40px rgba(0,0,0,.45));color:var(--ink,#E8ECF4);font-family:'Plus Jakarta Sans',system-ui,sans-serif}
  .sjw-brand{text-align:center;margin-bottom:18px}
  .sjw-goldlogo{display:none}
  .sjw-brand .m{width:54px;height:54px;border-radius:16px;margin:0 auto 10px;display:grid;place-items:center;background:var(--gold-soft,rgba(212,175,55,.12));border:1px solid var(--gold-line,rgba(212,175,55,.35));color:var(--gold,#D4AF37);font-weight:800;font-size:22px}
  .sjw-brand b{display:block;font-size:20px;color:var(--head,#fff)}
  .sjw-brand small{color:var(--muted,#7D8BA4);font-size:12.5px}
  .sjw-box h3{margin:0 0 6px;font-size:17px;color:var(--head,#fff)}
  .sjw-box p{margin:0 0 14px;color:var(--muted,#7D8BA4);font-size:13px;line-height:1.5}
  .sjw-f{display:flex;flex-direction:column;gap:6px;margin-bottom:12px}
  .sjw-f span{font-size:11px;font-weight:800;color:var(--muted,#7D8BA4);text-transform:uppercase;letter-spacing:.08em}
  .sjw-f input{width:100%;border:1px solid var(--line2,#27344F);border-radius:14px;padding:13px 14px;background:var(--card2,#0E1422);color:var(--ink,#E8ECF4);font:inherit;font-weight:600;outline:0}
  .sjw-f input:focus{border-color:var(--gold-line,rgba(212,175,55,.35));box-shadow:0 0 0 3px var(--gold-soft,rgba(212,175,55,.12))}
  .sjw-chk{display:flex;gap:8px;align-items:center;font-size:13px;color:var(--muted,#7D8BA4);margin:-2px 0 14px;cursor:pointer}
  .sjw-btn{width:100%;border:0;border-radius:16px;padding:14px;font:inherit;font-weight:800;font-size:15px;cursor:pointer;background:var(--gold,#D4AF37);color:var(--gold-ink,#16120A)}
  .sjw-btn.ghost{background:transparent;color:var(--ink,#E8ECF4);border:1px solid var(--line2,#27344F);margin-top:8px}
  .sjw-btn:disabled{opacity:.6;cursor:default}
  .sjw-err{display:none;background:var(--red-soft,rgba(244,63,94,.13));color:var(--red,#FB7185);border-radius:12px;padding:10px 12px;font-size:13px;font-weight:700;margin-bottom:12px;line-height:1.45}
  .sjw-warn{background:var(--gold-soft,rgba(212,175,55,.12));color:var(--ink,#E8ECF4);border:1px solid var(--gold-line,rgba(212,175,55,.35));border-radius:12px;padding:9px 11px;font-size:12px;margin-bottom:14px;line-height:1.45}
  .sjw-pill.safe{background:#b45309}
  .sjw-qr{display:flex;justify-content:center;margin:6px 0}.sjw-qr svg{width:190px;height:190px;background:#fff;padding:8px;border-radius:12px}
  .sjw-pill{position:fixed;left:50%;transform:translateX(-50%);top:calc(70px + env(safe-area-inset-top));z-index:450;background:#e11d48;color:#fff;font:700 12.5px/1.3 'Plus Jakarta Sans',system-ui,sans-serif;padding:9px 16px;border-radius:16px;box-shadow:0 8px 24px rgba(0,0,0,.35);width:max-content;max-width:min(620px,calc(100vw - 24px));box-sizing:border-box;text-align:center;display:none}
  `;
  let styled = false;
  function addStyle() {
    if (styled) return; styled = true;
    const s = document.createElement('style'); s.textContent = CSS; document.head.appendChild(s);
  }
  function overlay(html, dim) {
    addStyle();
    const ov = document.createElement('div');
    ov.className = 'sjw-ov' + (dim ? ' dim' : '');
    ov.innerHTML = '<div class="sjw-box">' + html + '</div>';
    document.body.appendChild(ov);
    return ov;
  }
  const BRAND = '<div class="sjw-brand"><div class="sjw-goldlogo" role="img" aria-label="Shivaa"></div><div class="m">SJ</div><b>Shivaa Jewels</b><small>Jewellery Software</small></div>';

  function showError(box, msg) { const e = box.querySelector('.sjw-err'); e.textContent = msg; e.style.display = msg ? 'block' : 'none'; }

  async function showFatal(err) {
    await domReady;
    return new Promise(resolve => {
      const ov = overlay(BRAND + '<h3>Software shuru nahi ho paya</h3><p>' + esc(err && err.message ? err.message : String(err)) + '</p><button class="sjw-btn" type="button">Dobara try karein</button>');
      ov.querySelector('button').onclick = () => { ov.remove(); resolve(); };
    });
  }

  /* ---------------- PIN before risky work (server asks for it) ---------------- */
  let pinP = null;
  function askPin(code, msg) {
    if (pinP) return pinP;
    pinP = new Promise((resolve, reject) => domReady.then(() => {
      const setup = code === 'pin_not_set';
      const ov = overlay('<form novalidate><h3>' + (setup ? '🔐 Apna PIN banaiye' : '🔐 PIN daaliye') + '</h3><p>' + esc(msg || (setup ? 'Is kaam ke liye PIN zaroori hai.' : 'Ye kaam karne se pehle apna PIN daaliye.')) + '</p><div class="sjw-err"></div>' +
        (setup ? '<label class="sjw-f"><span>Aapka login password</span><input name="pw" type="password" autocomplete="current-password" required></label><label class="sjw-f"><span>Naya PIN (4–8 ank)</span><input name="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="off" required></label>'
          : '<label class="sjw-f"><span>PIN</span><input name="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="off" required></label>') +
        '<button class="sjw-btn" type="submit">' + (setup ? 'PIN banao aur aage badho' : 'Aage badho') + '</button><button class="sjw-btn ghost" type="button" data-x>Cancel</button></form>', true);
      const f = ov.querySelector('form'); setTimeout(() => (f.pw || f.pin).focus(), 40);
      const done = ok => { ov.remove(); pinP = null; ok ? resolve() : reject(new ApiError('pin_cancel', 'PIN nahi diya — ye kaam nahi hua.')); };
      f.querySelector('[data-x]').onclick = () => done(false);
      f.onsubmit = async ev => {
        ev.preventDefault(); showError(f, ''); const pin = String(f.pin.value || '').replace(/\D/g, '');
        if (pin.length < 4) return showError(f, 'PIN kam se kam 4 ank ka.');
        const b = f.querySelector('button[type=submit]'); b.disabled = true;
        try { if (setup) await rawCall('pin_set', { password: f.pw.value, pin }); await rawCall('pin_check', { pin }); if (window.SJ_SEC) SJ_SEC.me.pin = true; done(true); }
        catch (er) { showError(f, er.message || 'PIN galat'); b.disabled = false; f.pin.value = ''; f.pin.focus(); }
      };
    }));
    return pinP;
  }
  /* ---------------- first login with "2-step for everybody" ---------------- */
  function enrollTotp(d) {
    return new Promise(resolve => {
      const qr = typeof window.qrSVG === 'function' ? window.qrSVG(d.uri) : '';
      const ov = overlay(BRAND + '<form novalidate><h3>🔐 2-step login chalu kijiye</h3><p>Owner ne sabke liye 2-step login zaroori kiya hai. Phone mein <b>Google Authenticator</b> app kholiye → <b>+</b> → <b>QR scan</b>.</p><div class="sjw-err"></div>' +
        (qr ? '<div class="sjw-qr">' + qr + '</div>' : '') + '<p style="font:600 12px ui-monospace,monospace;word-break:break-all;text-align:center">' + esc(d.secret) + '</p>' +
        '<label class="sjw-f"><span>App mein dikh raha 6 ank ka code</span><input name="code" inputmode="numeric" maxlength="6" autocomplete="one-time-code" required></label><button class="sjw-btn" type="submit">Chalu karo aur login</button></form>');
      const f = ov.querySelector('form'); setTimeout(() => f.code.focus(), 50);
      f.onsubmit = async ev => {
        ev.preventDefault(); showError(f, ''); const b = f.querySelector('button'); b.disabled = true;
        try {
          const r = await rawCall('totp_enroll', { ticket: d.ticket, code: f.code.value });
          setUser(r.user);
          f.innerHTML = '<h3>✓ 2-step login chalu</h3><p>Ye backup codes likh kar rakhiye — phone kho jaye to inse login hoga (har code ek baar):</p><pre style="text-align:center;font:600 16px/1.7 ui-monospace,monospace">' + esc((r.codes || []).join('\n')) + '</pre><button class="sjw-btn" type="button" data-ok>Maine likh liye — aage badho</button>';
          f.querySelector('[data-ok]').onclick = () => { ov.remove(); resolve(); };
        } catch (er) { showError(f, er.message || 'Code galat'); b.disabled = false; }
      };
    });
  }
  /* ---------------- outside shop hours ---------------- */
  let offShown = false;
  function offHours(msg) {
    if (offShown) return; offShown = true;
    domReady.then(() => { const ov = overlay(BRAND + '<h3>🕘 Abhi dukaan ka samay nahi</h3><p>' + esc(msg || '') + '</p><button class="sjw-btn" type="button" data-r>Dobara try karo</button><button class="sjw-btn ghost" type="button" data-lo>Logout</button>');
      ov.querySelector('[data-r]').onclick = () => location.reload();
      ov.querySelector('[data-lo]').onclick = async () => { try { await rawCall('logout'); } catch (e) { /* */ } await OFF.wipe(); location.reload(); }; });
  }

  let loginPromise = null;
  function requireLogin(msg) {
    if (!loginPromise) loginPromise = loginFlow(msg).finally(() => { loginPromise = null; });
    return loginPromise;
  }

  async function loginFlow(msg) {
    await domReady;
    let st;
    for (;;) {
      try { st = await rawCall('status', {}, { timeout: 12000 }); break; } catch (e) { if (isNet(e) && !CUR && OFF.ok && await OFF.has()) throw e; await showFatal(e); }
    }
    if (st.auth) { setUser(st.user); return; }
    if (st.secureRequired) {
      await showFatal({ message: 'Suraksha ke liye ye software sirf https:// par chalta hai. Hosting panel mein free SSL on kijiye aur website https://' + location.host + location.pathname + ' se kholiye.' });
      return loginFlow(msg);
    }
    let lastU = ''; try { lastU = localStorage.getItem('sj-uname') || ''; } catch (e) { /* ignore */ }
    return new Promise(resolve => {
      const httpsWarn = st.https ? '' : '<div class="sjw-warn">Ye website abhi <b>https</b> par nahi hai, isliye password surakshit nahi hai. Hosting panel mein free SSL on kijiye.</div>';
      const form = st.setup
        ? '<h3>Owner setup</h3><p>Setup code (software ke saath mila) daaliye aur Owner ka login banaiye. Staff ke alag login baad mein Setup → Website login se banenge.</p>' + httpsWarn +
          '<div class="sjw-err"></div>' +
          '<label class="sjw-f"><span>Setup code</span><input name="code" autocomplete="off" autocapitalize="characters" placeholder="XXXX-XXXX" required></label>' +
          '<label class="sjw-f"><span>Aapka naam</span><input name="name" autocomplete="name" value="Owner" required></label>' +
          '<label class="sjw-f"><span>Username</span><input name="uname" autocomplete="username" autocapitalize="none" value="owner" required></label>' +
          '<label class="sjw-f"><span>Naya password (8+ akshar)</span><input name="p1" type="password" autocomplete="new-password" minlength="8" required></label>' +
          '<label class="sjw-f"><span>Password dobara</span><input name="p2" type="password" autocomplete="new-password" minlength="8" required></label>' +
          '<label class="sjw-chk"><input type="checkbox" data-show> Password dikhao</label>' +
          '<button class="sjw-btn" type="submit">Login banao aur shuru karo</button>'
        : '<h3>Login</h3><p>' + esc(msg || 'Apna username aur password daaliye.') + '</p>' + httpsWarn +
          '<div class="sjw-err"></div>' +
          '<label class="sjw-f"><span>Username</span><input name="uname" autocomplete="username" autocapitalize="none" value="' + esc(lastU || 'owner') + '" required></label>' +
          '<label class="sjw-f"><span>Password</span><input name="p1" type="password" autocomplete="current-password" required></label>' +
          '<label class="sjw-chk"><input type="checkbox" data-show> Password dikhao</label>' +
          '<button class="sjw-btn" type="submit">Login</button>';
      const ov = overlay(BRAND + '<form novalidate>' + form + '</form>');
      const f = ov.querySelector('form');
      const btn = f.querySelector('button[type=submit]');
      f.querySelector('[data-show]').onchange = e => f.querySelectorAll('input[type=password],input[data-pw]').forEach(i => { i.type = e.target.checked ? 'text' : 'password'; i.dataset.pw = '1'; });
      const first = st.setup ? f.querySelector('input') : f.p1; if (first) setTimeout(() => first.focus(), 50);
      f.onsubmit = async ev => {
        ev.preventDefault();
        showError(f, '');
        const p1 = f.p1.value, uname = f.uname.value.trim().toLowerCase();
        if (!uname) return showError(f, 'Username daaliye.');
        if (st.setup) {
          if (!f.code.value.trim()) return showError(f, 'Setup code daaliye.');
          if (!/^[a-z0-9._-]{3,32}$/.test(uname)) return showError(f, 'Username 3–32 akshar: a-z, 0-9, . _ - (space nahi).');
          if (p1.length < 8) return showError(f, 'Password kam se kam 8 akshar ka rakhiye.');
          if (p1 !== f.p2.value) return showError(f, 'Dono password ek jaise nahi hain.');
        } else if (!p1) return showError(f, 'Password daaliye.');
        btn.disabled = true;
        try {
          if (st.setup) await rawCall('setup', { code: f.code.value, password: p1, username: uname, name: f.name.value.trim() });
          else {
            try { await rawCall('login', { username: uname, password: p1, otp: f.otp ? f.otp.value.trim() : '' }); }
            catch (le) { if (le.code === 'totp_setup' && le.data && le.data.ticket) { ov.remove(); await enrollTotp(le.data); resolve(); return; } throw le; }
          }
          const s2 = await rawCall('status'); setUser(s2.user);
          ov.remove();
          resolve();
        } catch (e) {
          if (e.code === 'already_setup' || e.code === 'setup_required') { ov.remove(); loginFlow(msg).then(resolve); return; }
          if (e.code === 'otp_required' && !f.otp) {   // owner has 2-step login on
            btn.insertAdjacentHTML('beforebegin', '<label class="sjw-f"><span>Authenticator code (6 ank) — ya backup code</span><input name="otp" inputmode="numeric" autocomplete="one-time-code" maxlength="9" placeholder="123456" required></label>');
            showError(f, '🔐 2-step login chalu hai — phone ki Authenticator app mein dikh raha code daaliye.'); setTimeout(() => f.otp && f.otp.focus(), 30); return;
          }
          showError(f, e.message || 'Login nahi ho paya.');
        } finally { btn.disabled = false; }
      };
    });
  }

  /* ---------------- OFFLINE: a copy of the data + an outbox on this device (IndexedDB) ----------------
     - every record the server sends / the user changes is copied here (per login)
     - no internet at start → the software opens from this copy
     - no internet while saving → the change waits in the outbox, in order, and goes as soon as the server answers
     - Logout wipes the copy from this device */
  const lsGet = k => { try { return localStorage.getItem(k) || ''; } catch (e) { return ''; } };
  const OB = []; let OB_USER = '', obFlushing = false; const obKeys = new Map();
  const obKey = op => op.c + '/' + op.i;
  const OB_INTERNAL = new Set(['audit', 'summary', 'tagState', 'alerts']);        // not counted as "entries" for the user
  const COLLAPSE = new Set(['summary', 'tagState']);                               // rewritten often — keep only the newest
  const obCount = () => OB.reduce((n, op) => n + (OB_INTERNAL.has(op.c) ? 0 : 1), 0);
  function obPush(ops) {
    if (!OB.length) OB_USER = CUR ? CUR.uname : lsGet('sj-uname');
    ops.forEach(op => {
      const k = obKey(op);
      if (COLLAPSE.has(op.c) && !obFlushing && obKeys.has(k)) { for (let i = OB.length - 1; i >= 0; i--) if (obKey(OB[i]) === k) OB.splice(i, 1); obKeys.delete(k); }
      OB.push(op); obKeys.set(k, (obKeys.get(k) || 0) + 1);
    });
    OFF.saveOB(); paintPill();
  }
  function obDone(n) {
    OB.splice(0, n).forEach(op => { const k = obKey(op), v = (obKeys.get(k) || 0) - 1; if (v > 0) obKeys.set(k, v); else obKeys.delete(k); });
    OFF.saveOB(); paintPill();
  }
  const OFF = (() => {
    const o = { ok: false, user: '', seq: 0, epoch: null };
    let db = null, docT = null, metaT = null, obSaving = null;
    const dirty = new Map(); const SEP = '\u0001';
    const done = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
    const tx = (mode, fn) => new Promise((res, rej) => {
      let x; try { x = db.transaction(['docs', 'kv'], mode); } catch (e) { rej(e); return; }
      let out; try { out = fn(x.objectStore('docs'), x.objectStore('kv')); } catch (e) { try { x.abort(); } catch (e2) { /* ignore */ } rej(e); return; }
      x.oncomplete = () => res(out); x.onerror = () => rej(x.error); x.onabort = () => rej(x.error || new Error('abort'));
    });
    const range = u => IDBKeyRange.bound(u + SEP, u + '\u0002', false, true);
    o.get = async k => { if (!db) return undefined; let r; await tx('readonly', (d, kv) => { r = kv.get(k); }); return r.result; };
    o.init = async () => {
      try {
        if (!window.indexedDB) return;
        db = await new Promise((res, rej) => {
          const r = indexedDB.open('sj-offline', 1);
          r.onupgradeneeded = () => { const d = r.result; if (!d.objectStoreNames.contains('docs')) d.createObjectStore('docs'); if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv'); };
          r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); r.onblocked = () => rej(new Error('blocked'));
          setTimeout(() => rej(new Error('idb timeout')), 6000);
        });
        o.ok = true;
        const last = lsGet('sj-uname');
        if (last) { const ob = await o.get('ob:' + last); if (Array.isArray(ob) && ob.length) { OB_USER = last; ob.forEach(op => { OB.push(op); const k = obKey(op); obKeys.set(k, (obKeys.get(k) || 0) + 1); }); } }
      } catch (e) { console.warn('[offline] not available on this browser', e); o.ok = false; db = null; }
    };
    o.has = async () => { const u = lsGet('sj-uname'); if (!u || !db) return false; try { const m = await o.get('meta:' + u); return !!(m && m.user); } catch (e) { return false; } };
    // after a full download from the server: replace this device's copy with it
    o.online = () => {
      if (!o.ok || !CUR) return;
      o.user = CUR.uname; dirty.clear();
      if (!OB.length) o.get('ob:' + CUR.uname).then(ob => { if (Array.isArray(ob) && ob.length && !OB.length) { OB_USER = CUR.uname; ob.forEach(op => { OB.push(op); const k = obKey(op); obKeys.set(k, (obKeys.get(k) || 0) + 1); }); paintPill(); pump(); } }).catch(() => null);
      const rows = []; store.forEach((m, c) => m.forEach((obj, id) => { const j = curJson.get(c + '/' + id); if (j) rows.push([c + SEP + id, j]); }));
      tx('readwrite', (d, kv) => {
        d.clear(); rows.forEach(([k, j]) => d.put(j, o.user + SEP + k));
        kv.put({ seq: lastSeq, epoch, user: CUR, at: Date.now() }, 'meta:' + o.user);
      }).catch(e => { console.warn('[offline] copy not saved', e); });
    };
    o.touch = (c, id, json) => {
      if (!o.ok || !o.user || PRACTICE) return;
      dirty.set(c + SEP + id, json);
      if (!docT) docT = setTimeout(o.flushDocs, 1200);
    };
    o.flushDocs = () => {
      docT = null; if (!dirty.size || !o.ok || !o.user) return;
      const list = Array.from(dirty); dirty.clear(); const u = o.user;
      tx('readwrite', (d, kv) => {
        list.forEach(([k, j]) => { if (j === null) d.delete(u + SEP + k); else d.put(j, u + SEP + k); });
        kv.put({ seq: lastSeq, epoch, user: CUR, at: Date.now() }, 'meta:' + u);
      }).catch(e => console.warn('[offline] copy not saved', e));
    };
    o.saveMeta = () => {
      if (!o.ok || !o.user || metaT) return;
      metaT = setTimeout(() => { metaT = null; const u = o.user; tx('readwrite', (d, kv) => kv.put({ seq: lastSeq, epoch, user: CUR, at: Date.now() }, 'meta:' + u)).catch(() => null); }, 3000);
    };
    o.saveOB = () => {
      if (!o.ok) return;
      const u = OB_USER || (CUR && CUR.uname) || lsGet('sj-uname'); if (!u) return;
      const snap = OB.slice();
      const p = tx('readwrite', (d, kv) => { if (snap.length) kv.put(snap, 'ob:' + u); else kv.delete('ob:' + u); }).catch(e => { console.warn('[offline] outbox not saved', e); domReady.then(() => toastMsg('⚠ Is device par jagah nahi — internet aane tak software band mat kijiye')); });
      obSaving = p; p.finally(() => { if (obSaving === p) obSaving = null; });
    };
    o.saving = () => !!obSaving;
    // no internet at start: open the software from this device's copy
    o.boot = async () => {
      const u = lsGet('sj-uname'); if (!u || !db) return false;
      let meta, keys, vals;
      try {
        meta = await o.get('meta:' + u); if (!meta || !meta.user) return false;
        await tx('readonly', d => { keys = d.getAllKeys(range(u)); vals = d.getAll(range(u)); });
        keys = keys.result; vals = vals.result;
      } catch (e) { console.warn('[offline] copy unreadable', e); return false; }
      keys.forEach((k, n) => {
        const rest = String(k).slice(u.length + 1), i = rest.indexOf(SEP); if (i < 0) return;
        const c = rest.slice(0, i), id = rest.slice(i + 1), j = vals[n];
        try { colMap(c).set(id, JSON.parse(j)); curJson.set(c + '/' + id, j); markDirty(c, id); } catch (e) { /* skip broken row */ }
      });
      setUser(meta.user); o.user = u; lastSeq = meta.seq || 0; epoch = meta.epoch === undefined ? null : meta.epoch;
      setOffline(true);
      const when = meta.at ? new Date(meta.at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';
      domReady.then(() => setTimeout(() => toastMsg('📴 Internet nahi hai — software is device ki copy se khula' + (when ? ' (' + when + ' tak ka data)' : '')), 1200));
      return true;
    };
    o.wipe = async () => { if (!db) return; try { await tx('readwrite', (d, kv) => { d.clear(); kv.clear(); }); } catch (e) { /* ignore */ } };
    window.addEventListener('beforeunload', e => { o.flushDocs(); if (obSaving) { e.preventDefault(); e.returnValue = ''; } });
    window.addEventListener('pagehide', () => o.flushDocs());
    return o;
  })();
  window.SJ_OFFLINE = { pending: () => obCount(), queued: () => OB.length, on: () => offline, ok: () => OFF.ok, wipe: () => OFF.wipe() };

  let pill = null, offline = false;
  function pillText() {
    const n = OB.length ? Math.max(1, obCount()) : 0;
    if (offline) return OFF.ok ? (n ? `📴 Internet nahi hai — ${n} entr${n === 1 ? 'y' : 'iyan'} is device par surakshit, net aate hi apne aap server par jayengi` : '📴 Internet nahi hai — kaam chalu rakhiye, entries is device par surakshit rahengi') : 'Server se connection nahi hai — nayi entries abhi save nahi hongi';
    if (n && CUR && OB_USER && CUR.uname !== OB_USER) return `⏳ Pichle login (${OB_USER}) ki ${n} entr${n === 1 ? 'y' : 'iyan'} abhi baaki — wo usi login se kholne par server par jayengi`;
    return n ? `⏳ ${n} entr${n === 1 ? 'y' : 'iyan'} server par bhej rahe hain…` : '';
  }
  function paintPill() {
    domReady.then(() => {
      addStyle();
      if (!pill) { pill = document.createElement('div'); pill.className = 'sjw-pill'; pill.setAttribute('role', 'status'); document.body.appendChild(pill); }
      const t = pillText(); pill.textContent = t; pill.style.display = t ? 'block' : 'none';
      pill.classList.toggle('safe', !!(offline && OFF.ok) || (!offline && OB.length > 0));
      document.documentElement.classList.toggle('sj-offline', offline);
    });
  }
  function setOffline(on) {
    if (on === offline && !pill && !on) return;
    offline = on; paintPill();
    if (!on && OB.length && !sending) pump();
  }

  /* ---------------- local copy of the data ---------------- */
  const store = new Map();     // collection -> Map(id -> data)
  const curJson = new Map();   // "col/id" -> JSON text of what is shown
  const pendingN = new Map();  // "col/id" -> writes still on their way
  const base = new Map();      // "col/id" -> last value the server confirmed while writes are pending
  const shadow = new Map();    // "col/id" -> change from another device that arrived while writes were pending
  const colSubs = new Map(), docSubs = new Map();
  const dirtyCols = new Set(), dirtyDocs = new Set();
  let flushTimer = null, lastSeq = 0, epoch = null, pullSeen = null;
  const META = Object.freeze({ fromCache: false, hasPendingWrites: false });

  const colMap = c => { let m = store.get(c); if (!m) { m = new Map(); store.set(c, m); } return m; };
  function markDirty(c, id) {
    dirtyCols.add(c); dirtyDocs.add(c + '/' + id);
    if (!flushTimer) flushTimer = setTimeout(flush, 0);
  }
  function flush() {
    flushTimer = null;
    const cs = Array.from(dirtyCols), ds = Array.from(dirtyDocs);
    dirtyCols.clear(); dirtyDocs.clear();
    cs.forEach(c => { const subs = colSubs.get(c); if (subs && subs.size) { const snap = colSnap(c); subs.forEach(fn => { try { fn(snap); } catch (e) { console.error(e); } }); } });
    ds.forEach(k => { const subs = docSubs.get(k); if (subs && subs.size) { const i = k.lastIndexOf('/'); const snap = docSnap(k.slice(0, i), k.slice(i + 1)); subs.forEach(fn => { try { fn(snap); } catch (e) { console.error(e); } }); } });
  }
  function docObj(c, id, d) {
    return { id, exists: d !== undefined, data: () => d, get: f => (d === undefined ? undefined : d[f]), ref: { id, path: c + '/' + id }, metadata: META };
  }
  function docSnap(c, id) { const m = store.get(c); return docObj(c, id, m ? m.get(id) : undefined); }
  function colSnap(c) {
    const m = store.get(c);
    const docs = m ? Array.from(m, ([id, d]) => docObj(c, id, d)) : [];
    return { docs, size: docs.length, empty: !docs.length, forEach: f => docs.forEach(f), docChanges: () => [], metadata: META };
  }
  function setLocal(c, id, obj, json) {
    const key = c + '/' + id, m = colMap(c);
    if (obj === undefined) { if (!m.has(id)) return; m.delete(id); curJson.delete(key); }
    else { m.set(id, obj); curJson.set(key, json); }
    markDirty(c, id); OFF.touch(c, id, obj === undefined ? null : json);
  }
  function applyRow(c, id, obj, seq) {
    const key = c + '/' + id;
    const json = obj === null ? null : JSON.stringify(obj);
    if ((pendingN.get(key) || 0) > 0) { shadow.set(key, { seq, obj, json }); return; }
    if (obKeys.has(key)) return;               // our own offline change is still on its way — it wins
    if (obj === null) { setLocal(c, id, undefined); return; }
    if (curJson.get(key) === json) return;
    setLocal(c, id, obj, json);
  }

  /* ---------------- saving: queued, batched, in order ----------------
     If the internet / server is gone, the change is kept in an "outbox" on this device
     (IndexedDB) and sent in the same order as soon as the server answers again. */
  const queue = [];
  let sending = false, retryT = null;
  const isNet = e => !!e && (e.code === 'unavailable' || e.code === 'timeout');
  function enqueue(op) {
    if (PRACTICE) return Promise.resolve(0);   // practice: kept in memory only
    if (OFF.ok && OB.length) { obPush([op]); pump(); return Promise.resolve(0); }   // already offline → straight into the outbox, keep order
    return new Promise((resolve, reject) => { queue.push({ op, resolve, reject }); pump(); });
  }
  function takeBatch(list, get) {
    const out = []; let size = 0;
    while (out.length < list.length && out.length < 400) {
      const op = get(list[out.length]); const sz = (op.d ? op.d.length : 0) + 200;
      if (out.length && size + sz > BATCH_BYTES) break;
      out.push(op); size += sz;
    }
    return out;
  }
  function retryLater(ms) { clearTimeout(retryT); retryT = setTimeout(() => { retryT = null; pump(); }, ms || 8000); }
  async function pump() {
    if (sending) return;
    sending = true;
    try {
      for (;;) {
        if (OB.length) {
          const r = await flushOutbox();
          if (r === 'net') {                         // still offline: everything new joins the outbox
            if (queue.length) { const xs = queue.splice(0); obPush(xs.map(x => x.op)); xs.forEach(x => x.resolve(0)); }
            retryLater(); break;
          }
          if (r === 'wait') { retryLater(15000); break; }
          continue;
        }
        if (!queue.length) break;
        const batch = takeBatch(queue, x => x.op).map(() => queue.shift());
        try {
          const r = await call('batch', { ops: batch.map(x => x.op) }, { timeout: 45000 });
          const first = r.seq - batch.length + 1;
          batch.forEach((x, k) => x.resolve(first + k));
          setOffline(false);
        } catch (e) {
          if (isNet(e) && OFF.ok && OFF.user && CUR && OFF.user === CUR.uname) {
            obPush(batch.map(x => x.op)); batch.forEach(x => x.resolve(0)); setOffline(true);
          } else {
            batch.forEach(x => x.reject(e));
            if (isNet(e)) setOffline(true);
          }
        }
      }
    } finally { sending = false; }
  }
  // send the outbox; returns 'ok' | 'net' (still offline) | 'wait' (other login / not now)
  async function flushOutbox() {
    if (!CUR || CUR.uname !== OB_USER) { paintPill(); return 'wait'; }
    let rejected = [];
    obFlushing = true;
    try {
    while (OB.length) {
      const ops = takeBatch(OB, op => op);
      try {
        await call('batch', { ops }, { timeout: 45000 });
        obDone(ops.length);
      } catch (e) {
        if (isNet(e)) { setOffline(true); return 'net'; }
        if (e.code === 'login_required') return 'wait';
        // server refused something (rights / locked bill …) — find the exact entry, send the rest
        if (ops.length > 1) {
          let sent = 0;
          for (const op of ops) {
            try { await call('batch', { ops: [op] }, { timeout: 45000 }); }
            catch (e2) { if (isNet(e2)) { obDone(sent); setOffline(true); return 'net'; } rejected.push({ op, msg: e2.message || e2.code }); }
            sent++;
          }
          obDone(sent);
        } else { rejected.push({ op: ops[0], msg: e.message || e.code }); obDone(1); }
      }
    }
    } finally { obFlushing = false; }
    setOffline(false);
    if (rejected.length) {
      console.warn('[offline] server refused', rejected);
      // show the server's real version again (and drop what the server never accepted)
      const seen = new Set(); pullSeen = seen; lastSeq = 0;
      try { await pullAll(); rejected.forEach(({ op }) => { const k = obKey(op); if (!seen.has(k) && !obKeys.has(k)) setLocal(op.c, op.i, undefined); }); } catch (e) { /* next poll will fix */ } finally { pullSeen = null; }
      domReady.then(() => toastMsg(`⚠ ${rejected.length} offline entr${rejected.length === 1 ? 'y' : 'iyan'} server ne nahi li: ${rejected[0].msg}`));
    }
    try { window.dispatchEvent(new CustomEvent('sj-outbox-sent', { detail: { rejected: rejected.length } })); } catch (e) { /* ignore */ }
    return 'ok';
  }

  async function writeOp(c, id, body, del) {
    const key = c + '/' + id;
    let json = null, obj;
    if (!del) {
      json = JSON.stringify(body);
      if (typeof json !== 'string' || json.charAt(0) !== '{') throw appError(new ApiError('invalid_argument', 'Record ka data sahi nahi hai.'));
      obj = JSON.parse(json);
    }
    const m = colMap(c);
    if (!(pendingN.get(key) > 0)) base.set(key, { obj: m.get(id), json: curJson.get(key), seq: 0 });
    pendingN.set(key, (pendingN.get(key) || 0) + 1);
    setLocal(c, id, del ? undefined : obj, json);            // show it straight away
    let seq = 0, err = null;
    try { seq = await enqueue(del ? { o: 'del', c, i: id } : { o: 'set', c, i: id, d: json }); }
    catch (e) { err = e; }
    if (!err) base.set(key, { obj: del ? undefined : obj, json, seq });
    const left = pendingN.get(key) - 1;
    if (left > 0) pendingN.set(key, left);
    else {
      pendingN.delete(key);
      let fin = base.get(key); base.delete(key);
      const sh = shadow.get(key); shadow.delete(key);
      if (sh && sh.seq > fin.seq && !obKeys.has(key)) fin = { obj: sh.obj === null ? undefined : sh.obj, json: sh.json };
      if (curJson.get(key) !== (fin.obj === undefined ? undefined : fin.json)) setLocal(c, id, fin.obj, fin.json);
    }
    if (err) throw appError(err);
  }

  /* ---------------- fetching changes from the server ---------------- */
  async function pullAll() {
    let more = true;
    while (more) {
      const r = await call('sync', { since: lastSeq });
      if (r.epoch !== undefined) {               // owner cleared all data on another device -> start clean here too
        if (epoch === null) epoch = r.epoch;
        else if (r.epoch !== epoch) { location.reload(); return; }
      }
      for (const row of r.rows) { if (pullSeen && row[2] !== null) pullSeen.add(row[0] + '/' + row[1]); applyRow(row[0], row[1], row[2], row[3]); }
      if (r.last > lastSeq) lastSeq = r.last;
      more = r.more;
      OFF.seq = lastSeq; OFF.epoch = epoch;
    }
  }

  // Setup -> "Sab data mitao": owner only, checked again on the server
  window.SJ_WIPE = async function (body) { const r = await rawCall('wipe', body || {}); return r; };
  window.SJ_EXPORT_URL = API + '?a=export';
  window.SJ_SEED = function () { return rawCall('seed', {}); };
  window.SJ_FILE = { put: b => call('file_put', b), get: id => call('file_get', { id }) };
  window.SJ_API_CALL = (action, body, ms) => call(action, body || {}, { timeout: ms || 30000 });

  /* v42: practice banner + app error record (Owner sees it in Setup → Software ki sehat) */
  domReady.then(() => {
    if (!PRACTICE) return;
    document.documentElement.classList.add('sj-practice');
    const b = document.createElement('div'); b.className = 'sj-practice-bar'; b.setAttribute('role', 'status');
    b.innerHTML = '<span>🎓 <b>PRACTICE MODE</b> — jo bhi karenge, asli hisaab mein save nahi hoga</span><button type="button">Practice band karo</button>';
    b.querySelector('button').onclick = () => { try { sessionStorage.removeItem('sj-practice'); } catch (e) { /* ignore */ } location.reload(); };
    document.body.appendChild(b);
    const st = document.createElement('style'); st.textContent = '.sj-practice-bar{position:fixed;left:0;right:0;top:0;z-index:2000;display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;padding:6px 12px;background:repeating-linear-gradient(45deg,#7c2d12,#7c2d12 14px,#9a3412 14px,#9a3412 28px);color:#fff;font:600 13px system-ui,sans-serif}.sj-practice-bar button{border:1px solid #fff;background:transparent;color:#fff;border-radius:10px;padding:4px 10px;font:inherit;cursor:pointer}html.sj-practice body{padding-top:36px}';
    document.head.appendChild(st);
  });
  let errN = 0, errAt = 0;
  function errSend(msg, src) {
    try {
      if (PRACTICE || !CUR || errN >= 25 || Date.now() - errAt < 4000) return; msg = String(msg || '').slice(0, 400); if (!msg || /ResizeObserver|Script error\.?$|AbortError/i.test(msg)) return;
      errN++; errAt = Date.now();
      rawCall('err_log', { msg, src: String(src || '').slice(0, 160), view: location.hash.slice(0, 40), ver: (document.querySelector('script[src*="sj-api.js"]') || {}).src ? (document.querySelector('script[src*="sj-api.js"]').src.split('v=')[1] || '') : '' }).catch(() => null);
    } catch (e) { /* never loop */ }
  }
  window.addEventListener('error', e => errSend(e.message || (e.error && e.error.message), (e.filename || '').split('/').pop() + ':' + (e.lineno || '')));
  window.addEventListener('unhandledrejection', e => { const r = e.reason; if (r && (r.code === 'unavailable' || r.code === 'timeout' || r.code === 'practice' || r.code === 'login_required')) return; errSend('Promise: ' + (r && r.message || r), r && r.stack ? String(r.stack).split('\n')[1] : ''); });
  window.SJ_AI = { status: () => call('ai_status', {}, { timeout: 20000 }), key: (key, model, provider, extra) => call('ai_key', Object.assign({ key, model, provider }, extra || {}), { timeout: 60000 }), ask: async b => { try { return await call('ai', b, { timeout: 180000 }); } catch (e) { if (e && e.code === 'unavailable') { await new Promise(r => setTimeout(r, 2500)); return call('ai', b, { timeout: 180000 }); } throw e; } } };

  let syncing = null;
  function syncNow() {
    if (syncing || loginPromise) return syncing;
    syncing = pullAll().then(() => { setOffline(false); if (OB.length) pump(); OFF.saveMeta(); }, e => { if (isNet(e)) setOffline(true); else console.warn('[sync]', e); })
      .finally(() => { syncing = null; });
    return syncing;
  }
  let polling = false;
  function startPolling() {
    if (polling) return; polling = true;
    setInterval(() => { if (document.visibilityState === 'visible') syncNow(); }, POLL_MS);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') syncNow(); });
    window.addEventListener('focus', () => syncNow());
    window.addEventListener('online', () => syncNow());
  }

  /* ---------------- database object the software talks to ---------------- */
  const genId = () => 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  function subscribe(map, key, next, snapFn) {
    if (next && typeof next === 'object' && typeof next.next === 'function') next = next.next.bind(next);
    let set = map.get(key); if (!set) { set = new Set(); map.set(key, set); }
    const fn = s => next(s);
    set.add(fn);
    setTimeout(() => { if (set.has(fn)) { try { fn(snapFn()); } catch (e) { console.error(e); } } }, 0);
    return () => { set.delete(fn); };
  }
  function docRef(c, id) {
    return {
      id, path: c + '/' + id,
      get: async () => docSnap(c, id),
      set: async data => { await writeOp(c, id, data, false); },
      update: async data => {
        const cur = curJson.get(c + '/' + id);
        if (cur === undefined) { const e = new Error('Record nahi mila'); e.code = 'not_found'; throw e; }
        await writeOp(c, id, Object.assign(JSON.parse(cur), data), false);
      },
      delete: async () => { await writeOp(c, id, null, true); },
      onSnapshot: (next) => subscribe(docSubs, c + '/' + id, next, () => docSnap(c, id)),
      collection: sub => colRef(c + '/' + id + '/' + sub)
    };
  }
  function colRef(c) {
    return {
      id: c.split('/').pop(), path: c,
      doc: id => docRef(c, id || genId()),
      get: async () => colSnap(c),
      add: async data => { const id = genId(); await writeOp(c, id, data, false); return docRef(c, id); },
      onSnapshot: (next) => subscribe(colSubs, c, next, () => colSnap(c))
    };
  }
  function docByPath(p) {
    const segs = String(p).split('/').filter(Boolean);
    if (segs.length < 2 || segs.length % 2) throw new Error('Bad document path: ' + p);
    return docRef(segs.slice(0, -1).join('/'), segs[segs.length - 1]);
  }
  const DB = { collection: colRef, doc: docByPath };

  window.SJ_SEC = { policy: {}, me: {}, ready: false };
  async function loadSec() {
    try { const r = await call('sec_status', {}, { timeout: 15000 }); window.SJ_SEC = { policy: r.policy || {}, me: r.me || {}, device: r.device, ready: true }; try { localStorage.setItem('sj-sec', JSON.stringify({ policy: r.policy, me: r.me })); } catch (e) { /* */ } }
    catch (e) { try { const c = JSON.parse(localStorage.getItem('sj-sec') || 'null'); if (c) window.SJ_SEC = { policy: c.policy || {}, me: c.me || {}, ready: true, cached: true }; } catch (e2) { /* */ } }
    try { window.dispatchEvent(new CustomEvent('sj-sec')); } catch (e) { /* */ }
  }
  window.SJ_SEC_RELOAD = loadSec;
  let dbPromise = null;
  function getDb() {
    if (!dbPromise) dbPromise = (async () => {
      await OFF.init();
      for (;;) {
        try { await requireLogin(); await pullAll(); OFF.online(); break; }
        catch (e) {
          if (isNet(e) && await OFF.boot()) break;        // no internet — open with the copy saved on this device
          await showFatal(e);
        }
      }
      startPolling();
      if (OB.length) { paintPill(); pump(); }
      loadSec();
      return DB;
    })();
    return dbPromise;
  }

  const downloads = {
    async save({ filename, data }) {
      const blob = data instanceof Blob ? data : new Blob([data]);
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = filename || 'download';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 15000);
    }
  };

  window.claude = {
    use: async name => {
      if (name === 'db') return getDb();
      if (name === 'downloads') return downloads;
      const e = new Error('"' + name + '" is only available inside Claude'); e.code = 'unsupported'; throw e;
    }
  };

  /* ---------------- "Website login" card on the Setup page ---------------- */
  function passwordDialog() {
    const ov = overlay('<form novalidate><h3>Password badlein</h3><p>Password badalne ke baad baaki sab devices par dobara login karna hoga.</p><div class="sjw-err"></div>' +
      '<label class="sjw-f"><span>Purana password</span><input name="old" type="password" autocomplete="current-password" required></label>' +
      '<label class="sjw-f"><span>Naya password (8+ akshar)</span><input name="p1" type="password" autocomplete="new-password" minlength="8" required></label>' +
      '<label class="sjw-f"><span>Naya password dobara</span><input name="p2" type="password" autocomplete="new-password" minlength="8" required></label>' +
      '<button class="sjw-btn" type="submit">Password badlo</button><button class="sjw-btn ghost" type="button" data-x>Cancel</button></form>', true);
    const f = ov.querySelector('form');
    f.querySelector('[data-x]').onclick = () => ov.remove();
    f.onsubmit = async ev => {
      ev.preventDefault(); showError(f, '');
      if (f.p1.value.length < 8) return showError(f, 'Naya password kam se kam 8 akshar ka rakhiye.');
      if (f.p1.value !== f.p2.value) return showError(f, 'Dono naye password ek jaise nahi hain.');
      try { await call('passwd', { old: f.old.value, password: f.p1.value }); ov.remove(); toastMsg('Password badal gaya'); }
      catch (e) { showError(f, e.message || 'Password nahi badla.'); }
    };
  }
  function toastMsg(t) {
    const el = document.getElementById('toast');
    if (!el) return alert(t);
    el.textContent = t; el.className = 'show';
    setTimeout(() => { el.className = ''; }, 2600);
  }
  /* ---------------- staff & logins (Owner) ---------------- */
  const ROLE_INFO = {
    manager: 'Sab kuch — delete, settings, backup bhi. Sirf logins nahi bana sakta.',
    staff: 'Bill, stock, estimate, parties — bana aur badal sakta hai. Delete, settings (rate chhodkar) aur backup nahi.',
    viewer: 'Sirf dekh sakta hai — kuch bhi save ya badal nahi sakta (jaise CA).'
  };
  const fmtTs = t => (t ? new Date(t * 1000).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—');
  async function staffScreen() {
    let users;
    try { users = (await call('users')).users; } catch (e) { return toastMsg(e.message || 'Logins nahi khule'); }
    const rows = users.map(u => `<div class="sp-row"><div style="min-width:0"><b>${esc(u.name)}</b> <span class="pill ${u.role === 'owner' ? 'gold' : u.role === 'manager' ? 'blue' : u.role === 'viewer' ? '' : 'green'}">${esc(ROLE_L[u.role] || u.role)}</span>${u.active ? '' : ' <span class="pill red">Band</span>'}
      <div class="small muted"><span class="mono">${esc(u.uname)}</span> · last login ${esc(fmtTs(u.last_login))} · ${u.sessions} device${u.sessions === 1 ? '' : 's'}</div></div>
      <button type="button" class="btn sm" data-sj="user-edit" data-id="${esc(u.id)}">Edit</button></div>`).join('');
    const ov = openModal(`${mHead('Staff & logins', 'Har member ka apna username aur password')}<div class="m-body">
      <div class="btns" style="margin-bottom:12px"><button type="button" class="btn gold" data-sj="user-new">+ Naya login</button></div>
      <div class="card" style="margin:0">${rows}</div>
      <div class="small muted" style="margin-top:12px;line-height:1.6"><b>Manager:</b> ${ROLE_INFO.manager}<br><b>Staff:</b> ${ROLE_INFO.staff}<br><b>View only:</b> ${ROLE_INFO.viewer}<br>Har badlaav audit trail mein us member ke naam se likha jata hai — ye server likhta hai, browser se badla nahi ja sakta.</div>
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Close</button></div>`, { wide: true });
    ov._users = users;
  }
  function userForm(u, list) {
    const isOwner = u && u.id === 'u_owner';
    const ov = openModal(`<form data-form="sjuser" data-id="${u ? esc(u.id) : ''}" novalidate>${mHead(u ? 'Login: ' + esc(u.name) : 'Naya login', isOwner ? 'Owner' : 'Staff member')}<div class="m-body"><div class="fg">
      ${fld('Naam', 'name', u ? u.name : '', { req: 1 })}
      ${fld('Username', 'username', u ? u.uname : '', { req: 1, ph: 'jaise ramesh' })}
      ${isOwner ? '' : selFld('Role', 'role', [['staff', 'Staff (counter / sales)'], ['manager', 'Manager'], ['viewer', 'View only']], u ? u.role : 'staff')}
      ${fld(u ? 'Naya password (khali = wahi rahega)' : 'Password (8+ akshar)', 'password', '', { ph: u ? 'badalna ho to hi' : '' })}
      ${!isOwner && u ? `<label class="chk"><input type="checkbox" name="active"${u.active ? ' checked' : ''}> Login chalu hai</label>` : ''}
      </div><p class="small muted" data-o="roleinfo" style="margin:10px 0 0">${isOwner ? 'Owner ka role nahi badalta.' : esc(ROLE_INFO[u ? u.role : 'staff'] || '')}</p></div>
      <div class="m-foot">${u && !isOwner ? `<button type="button" class="btn danger" data-sj="user-del" data-id="${esc(u.id)}">Delete</button>` : ''}<button type="button" class="btn" data-act="close">Cancel</button><button type="submit" class="btn gold">Save</button></div></form>`, { small: true });
    const pw = ov.querySelector('[name="password"]'); if (pw) { pw.type = 'password'; pw.autocomplete = 'new-password'; }
    const sel = ov.querySelector('[name="role"]'); if (sel) sel.addEventListener('change', () => { ov.querySelector('[data-o="roleinfo"]').textContent = ROLE_INFO[sel.value] || ''; });
    ov._list = list;
  }
  async function submitUser(form) {
    const ov = form.closest('.overlay'); const d = formObj(form); const id = form.dataset.id;
    const body = { id, name: d.name, username: String(d.username || '').toLowerCase(), role: d.role || 'staff', password: d.password, active: id ? !!d.active || id === 'u_owner' : true };
    if (!body.name || !body.username) return toast('Naam aur username bhariye', 'err');
    if (!/^[a-z0-9._-]{3,32}$/.test(body.username)) return toast('Username 3–32 akshar: a-z, 0-9, . _ -', 'err');
    if (!id && String(d.password || '').length < 8) return toast('Password kam se kam 8 akshar', 'err');
    try {
      await call('user_save', body);
      closeModal(ov);
      const list = $('#modal-root').lastElementChild; if (list && list._users) closeModal(list);
      toast('Login save ho gaya'); staffScreen();
    } catch (e) { toast(e.message || 'Save nahi hua', 'err'); }
  }

  /* ---------------- "Website login" card on the Setup page ---------------- */
  document.addEventListener('click', async e => {
    const b = e.target.closest && e.target.closest('[data-sj]');
    if (!b) return;
    const act = b.dataset.sj;
    if (act === 'passwd') passwordDialog();
    else if (act === 'backup') { try { await call('pin_ok', {}); window.location.href = API + '?a=export'; } catch (er) { if (er.code !== 'pin_cancel') toastMsg(er.message || 'Backup nahi hua'); } }
    else if (act === 'staff') staffScreen();
    else if (act === 'user-new') userForm(null);
    else if (act === 'user-edit') { const ov = b.closest('.overlay'); const u = ov && ov._users && ov._users.find(x => x.id === b.dataset.id); if (u) userForm(u); }
    else if (act === 'user-del') {
      const id = b.dataset.id;
      confirmBox('Ye login hamesha ke liye delete karein? Us member ka data aur audit trail rahega.', async () => {
        try { await call('user_delete', { id }); $$('#modal-root .overlay').forEach(o => closeModal(o)); toast('Login delete ho gaya'); staffScreen(); } catch (er) { toast(er.message, 'err'); }
      });
    }
    else if (act === 'logout') {
      if (OB.length && !confirm(`${OB.length} entries abhi server par nahi gayi hain. Logout karne se ye is device se mit jayengi. Phir bhi logout karein?`)) return;
      try { await rawCall('logout'); } catch (er) { /* ignore */ } await OFF.wipe(); location.reload();
    }
    else if (act === 'logout_all') {
      if (!confirm(CUR && CUR.role === 'owner' ? 'Sab members ke sab phones aur computers se logout karna hai? Sabko dobara login karna hoga.' : 'Aapke sab devices se logout karna hai?')) return;
      try { await call('logout_all'); } catch (er) { /* ignore */ }
      await OFF.wipe(); location.reload();
    }
  });
  function cardHTML() {
    const r = CUR ? CUR.role : '';
    const own = r === 'owner', mgr = own || r === 'manager';
    return '<div class="card" id="sj-web-card"><div class="card-h"><h3>Website login</h3>' + (CUR ? `<span class="pill ${own ? 'gold' : 'green'}">${esc(CUR.name)} · ${esc(ROLE_L[r] || r)}</span>` : '') + '</div>' +
      '<p class="small muted" style="margin-top:0">🔒 Aapka data aapke server par <b>AES-256 encryption</b> ke saath save hota hai. Har member ka apna login hai, aur kaun kya kar sakta hai ye server check karta hai.</p>' +
      '<div class="btns"><button class="btn sm" data-sj="passwd">Mera password badlein</button>' +
      (own ? '<button class="btn sm gold" data-sj="staff">Staff & logins</button>' : '') +
      (mgr ? '<button class="btn sm" data-sj="backup">Server backup (.json)</button>' : '') +
      '<button class="btn sm" data-sj="logout">Logout</button><button class="btn sm danger" data-sj="logout_all">' + (own ? 'Sab devices se logout' : 'Mere sab devices se logout') + '</button></div></div>';
  }
  domReady.then(() => {
    if (typeof SUBMIT2 !== 'undefined') SUBMIT2.sjuser = submitUser;
    if (typeof errMsg === 'function') { const em = errMsg; window.errMsg = function (e) { return (e && e.sjMsg) || em.apply(this, arguments); }; }
  });
  let cardQueued = false;
  function placeCard() {
    cardQueued = false;
    const anchor = document.getElementById('backup');
    if (anchor && !document.getElementById('sj-web-card')) anchor.insertAdjacentHTML('afterend', cardHTML());
  }
  domReady.then(() => {
    new MutationObserver(() => { if (!cardQueued) { cardQueued = true; requestAnimationFrame(placeCard); } })
      .observe(document.body, { childList: true, subtree: true });
  });
})();
