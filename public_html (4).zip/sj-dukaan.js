/* =====================================================================
   Shivaa Jewels — SHOWROOM + SEHAT (v42)
   • Showroom page: 🎫 Token · 💳 Kisht (EMI) · 🚗 Gaadi khaata · 🔐 Tijori ·
     📺 TV display · 🧪 Machine test · 🧾 Purity parchi
   • Setup: 🩺 Software ki sehat (Telegram, backup, restore test, galti ka
     record, emergency access, CA login), 🎓 Practice mode, ✅ Setup sahayak
   • Kanoon: ₹2 lakh+ bill par PAN / Form 60, cash ₹2 lakh ki rok
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { role: 'owner', name: 'Owner', id: 'u_owner', uname: 'owner' };
  const role = () => me().role || 'owner';
  const isOwner = () => !SITE || role() === 'owner';
  const boss = () => !SITE || ['owner', 'manager'].includes(role());
  const q$ = (s, r) => (r || document).querySelector(s);
  const API = (a, b, ms) => window.SJ_API_CALL ? window.SJ_API_CALL(a, b || {}, ms) : Promise.reject(new Error('Ye kaam website par chalta hai'));
  const pro = () => (settings().pro || {});
  const tm = ms => ms ? new Date(ms).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';
  const dt = ms => ms ? new Date(ms).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '';
  ['qTokens', 'emis', 'vehLog', 'tijoriLog', 'purityTests'].forEach(c => { if (!COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const RXPAN = /^[A-Z]{5}[0-9]{4}[A-Z]$/, RXGST = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;
  const card = (title, sub, inner, extra) => `<div class="card"${extra || ''}><div class="card-h"><h3>${title}</h3>${sub ? `<span class="small muted">${sub}</span>` : ''}</div>${inner}</div>`;
  const waOpen = (ph, t) => window.open((ph && typeof waUrl === 'function' && waUrl(ph, t)) || 'https://wa.me/?text=' + encodeURIComponent(t), '_blank', 'noopener');

  /* ================= KANOON: PAN / Form 60 + cash 269ST (before the bill is saved) ================= */
  if (typeof persistInvoice === 'function') {
    const P0 = persistInvoice;
    persistInvoice = async function (st) {
      try {
        if (st && isSaleT(st.type) && typeof validateInvoice === 'function') {
          const v = validateInvoice(st);
          if (!v.error && v.party) {
            const oldMetal = (st.oldMetal || []).filter(o => num(o.gross) > 0);
            const t = invTotals({ ...st, items: v.items, oldMetal }, v.party);
            const pol = (window.SJ_SEC && SJ_SEC.policy) || {};
            const cash = st.payMode === 'Cash' ? num(st.received) : 0;
            if (pol.cash269 !== false && cash >= 200000) {
              const msg = `Sec 269ST: ek bill par ${inr(cash)} cash — ₹2 lakh ya zyada cash lena mana hai (penalty = utni hi rakam). Baaki paisa UPI / bank / cheque se lijiye.`;
              if (!isOwner()) return { error: msg };
              if (!await SJ_CONFIRM('⚖ ' + msg + '\n\nAap Owner hain — phir bhi save karein?', 'Haan, save karo')) return { error: 'Bill save nahi hua (cash ₹2 lakh)' };
            }
            const p = v.party;
            if (pol.panRule !== false && t.payable >= 200000 && !RXPAN.test(String(p.pan || '').toUpperCase()) && !RXGST.test(String(p.gstin || '').toUpperCase()) && !p.form60) {
              const ans = await SJ_ASK('🪪 PAN zaroori (Rule 114B)', 'Grahak ka PAN number', { sub: `${inr(t.payable)} ke bill par PAN chahiye. PAN nahi hai to "FORM60" likhiye (Form 60 bharwa kar rakhiye).`, ph: 'ABCDE1234F', mono: true });
              if (ans === null) return { error: 'PAN ke bina ₹2 lakh+ ka bill save nahi hua' };
              const a = String(ans).toUpperCase().replace(/\s/g, '');
              if (a === 'FORM60' || a === 'FORM-60') { if (!await save('customers', { ...p, form60: todayStr(), updatedAt: Date.now() })) return { error: 'Form 60 save nahi hua' }; }
              else if (RXPAN.test(a)) { if (!await save('customers', { ...p, pan: a, updatedAt: Date.now() })) return { error: 'PAN save nahi hua' }; }
              else return { error: 'PAN galat hai (jaise ABCDE1234F) — bill save nahi hua' };
            }
          }
        }
      } catch (e) { console.error('[kanoon]', e); }
      return P0.apply(this, arguments);
    };
  }

  /* ================= TOKEN (grahak ki line) ================= */
  const todayTok = () => S.qTokens.filter(x => x.date === todayStr()).sort((a, b) => a.n - b.n);
  const tNo = x => 'T-' + String(x.n).padStart(3, '0');
  async function tokNew() {
    const el = openModal(`<form novalidate>${mHead('🎫 Naya token', 'Grahak ko number dijiye — jo staff free ho, wo bulayega')}<div class="m-body"><div class="fg">${fld('Naam (optional)', 'name', '')}${fld('Phone (optional)', 'phone', '', { im: 'tel', max: 14 })}
      <label class="f"><span>Kis kaam se</span><select name="purpose">${['Sona dekhna', 'Chandi dekhna', 'Shaadi ka maal', 'Repair', 'Order / delivery', 'Payment', 'Purana sona'].map(x => `<option>${x}</option>`).join('')}</select></label></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Token do</button></div></form>`);
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); const n = (todayTok().slice(-1)[0] || { n: 0 }).n + 1;
      const x = { id: uid('tk'), date: todayStr(), n, name: f.name, phone: cleanPhone(f.phone || ''), purpose: f.purpose, at: Date.now(), status: 'wait', floor: (window.SJ_FLOORS && SJ_FLOORS.cur()) || '', by: me().name };
      if (await save('qTokens', x, { quiet: true })) { closeModal(el); tokShow(x); renderView(true); }
    };
  }
  function tokShow(x) { openModal(`${mHead('🎫 Token', esc(x.purpose))}<div class="m-body" style="text-align:center"><div class="dk-tokbig">${tNo(x)}</div><p class="small muted">${esc(settings().firm || 'Shivaa Jewels')} · ${esc(tm(x.at))}${x.name ? ' · ' + esc(x.name) : ''}</p><p>Aage <b>${todayTok().filter(y => y.status === 'wait' && y.n < x.n).length}</b> log hain</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Theek</button>${x.phone ? `<button type="button" class="btn green" data-act="dk-tok-wa" data-id="${esc(x.id)}">WhatsApp par bhejo</button>` : ''}</div>`, { small: true }); }
  async function tokSet(id, status) {
    const x = S.qTokens.find(y => y.id === id); if (!x) return;
    const o = { ...x, status, updatedAt: Date.now() };
    if (status === 'serve') { o.servedAt = Date.now(); o.servedBy = me().name; }
    if (status === 'done' || status === 'gone') o.doneAt = Date.now();
    if (await save('qTokens', o, { quiet: true })) renderView(true);
  }
  function tokenBody() {
    const L = todayTok(), wait = L.filter(x => x.status === 'wait'), serve = L.filter(x => x.status === 'serve'), done = L.filter(x => x.status === 'done');
    const waits = L.filter(x => x.servedAt).map(x => (x.servedAt - x.at) / 60000), avg = waits.length ? Math.round(waits.reduce((a, b) => a + b, 0) / waits.length) : 0;
    const row = x => { const w = Math.round(((x.servedAt || Date.now()) - x.at) / 60000); return `<div class="dk-tk ${x.status} ${x.status === 'wait' && w >= 10 ? 'late' : ''}"><b>${tNo(x)}</b><div><span>${esc(x.name || 'Grahak')} · ${esc(x.purpose || '')}</span><small>${esc(tm(x.at))} · ${x.status === 'wait' ? `${w} min se intezaar` : x.status === 'serve' ? `${esc(x.servedBy || '')} dekh rahe · ${w} min intezaar kiya` : 'ho gaya'}</small></div><div class="btns">${x.status === 'wait' ? `<button type="button" class="btn sm gold" data-act="dk-tok" data-id="${esc(x.id)}" data-s="serve">Main dekhta hoon</button><button type="button" class="btn sm" data-act="dk-tok" data-id="${esc(x.id)}" data-s="gone">Chale gaye</button>` : x.status === 'serve' ? `<button type="button" class="btn sm green" data-act="dk-tok" data-id="${esc(x.id)}" data-s="done">✓ Ho gaya</button>` : ''}</div></div>`; };
    return `<div class="toolbar"><button type="button" class="btn gold" data-act="dk-tok-new">🎫 Naya token</button></div>
      <div class="stats">${stat('Intezaar mein', wait.length, wait.length ? `sabse purana ${Math.round((Date.now() - wait[0].at) / 60000)} min` : 'koi nahi', 'clock', wait.some(x => Date.now() - x.at > 600000) ? '' : 'sky')}${stat('Dekhe ja rahe', serve.length, '', 'user', 'gold')}${stat('Aaj ho gaye', done.length, `avg intezaar ${avg} min`, 'check', '')}</div>
      ${wait.length ? card('⏳ Intezaar', '10 min se zyada = laal', wait.map(row).join('')) : ''}${serve.length ? card('🙋 Abhi dekh rahe', '', serve.map(row).join('')) : ''}${!L.length ? emptyBox('Aaj abhi koi token nahi. Bheed ho to "Naya token" dijiye — TV par number dikhega.') : ''}`;
  }

  /* ================= KISHT (EMI) — bill ke baaki ko kishton mein ================= */
  const emiLeft = e => sum(e.plan.filter(k => !k.paidAt), k => k.amount);
  async function emiNew() {
    const bills = S.invoices.filter(v => isSaleT(v.type) && !v.deleted && invDue(v) > 0.5 && !S.emis.some(e => e.invId === v.id && e.status === 'open')).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 200);
    if (!bills.length) return toast('Koi bill baaki nahi jise kisht mein badla ja sake', 'err');
    const el = openModal(`<form novalidate>${mHead('💳 Kisht par gehna', 'Bill ka baaki paisa barabar kishton mein')}<div class="m-body"><div class="fg">
      <label class="f span2"><span>Bill <b class="req">*</b></span><select name="inv">${bills.map(v => `<option value="${esc(v.id)}">${esc(v.no)} · ${esc(v.partyName)} · baaki ${esc(inr(invDue(v)))}</option>`).join('')}</select></label>
      ${fld('Kitni kisht', 'n', 6, { type: 'number' })}${fld('Pehli kisht ki tareekh', 'start', addDays(todayStr(), 30), { type: 'date' })}
      <label class="f"><span>Har</span><select name="every"><option value="month">Mahine</option><option value="week">Hafte</option></select></label></div>
      <p class="small muted">Kisht milne par paisa seedha usi bill mein jama hota hai — hisaab ek hi jagah rahega. Byaaj chahiye to bill mein hi jodiye.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Kisht banao</button></div></form>`);
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); const v = S.invoices.find(x => x.id === f.inv); const n = Math.max(1, Math.min(60, Math.round(num(f.n)))); if (!v) return;
      const due = r2(invDue(v)), each = Math.floor(due / n), plan = [];
      for (let i = 0; i < n; i++) { const d = new Date(f.start + 'T12:00:00'); if (f.every === 'week') d.setDate(d.getDate() + 7 * i); else d.setMonth(d.getMonth() + i); plan.push({ i: i + 1, due: d.toISOString().slice(0, 10), amount: i === n - 1 ? r2(due - each * (n - 1)) : each }); }
      const party = S.customers.find(c => c.id === v.partyId) || {};
      const e = { id: uid('emi'), no: nextNo('emis', 'KS-'), invId: v.id, invNo: v.no, partyId: v.partyId, partyName: v.partyName, phone: party.phone || v.partyPhone || '', total: due, n, every: f.every, plan, status: 'open', createdAt: Date.now(), by: me().name };
      if (await save('emis', e)) { closeModal(el); toast(`✓ ${e.no}: ${n} kisht × ${inr(each)}`); renderView(true); }
    };
  }
  async function emiPay(id, i) {
    const e = S.emis.find(x => x.id === id); const k = e && e.plan.find(x => x.i === +i); const v = e && S.invoices.find(x => x.id === e.invId); if (!k || !v) return toast('Bill nahi mila', 'err');
    const el = openModal(`<form novalidate>${mHead('💳 Kisht ' + k.i + ' mili', esc(e.no) + ' · ' + esc(e.partyName))}<div class="m-body"><div class="fg">${fld('Rakam', 'amount', k.amount, { type: 'number' })}<label class="f"><span>Kaise</span><select name="mode">${['UPI', 'Cash', 'Bank', 'Cheque', 'Card'].map(x => `<option>${x}</option>`).join('')}</select></label>${fld('Tareekh', 'date', todayStr(), { type: 'date' })}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Jama karo</button></div></form>`, { small: true });
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); const amt = r2(num(f.amount)); if (!(amt > 0)) return toast('Rakam daaliye', 'err');
      const v2 = S.invoices.find(x => x.id === e.invId); const pid = uid('pay');
      if (!await save('invoices', { ...v2, payments: [...invPayments(v2), { id: pid, date: f.date || todayStr(), amount: amt, fine: 0, mode: f.mode, note: `Kisht ${k.i}/${e.n} · ${e.no}` }], updatedAt: Date.now() })) return;
      const e2 = S.emis.find(x => x.id === id); const plan = e2.plan.map(x => x.i === k.i ? { ...x, paidAt: Date.now(), paid: amt, payId: pid, mode: f.mode } : x);
      await save('emis', { ...e2, plan, status: plan.every(x => x.paidAt) ? 'closed' : 'open', updatedAt: Date.now() }, { quiet: true });
      closeModal(el); toast(`✓ ${inr(amt)} bill ${v2.no} mein jama`); renderView(true);
    };
  }
  function emiBody() {
    const open = S.emis.filter(e => e.status === 'open'), t = todayStr();
    const dueRows = open.flatMap(e => e.plan.filter(k => !k.paidAt && k.due <= addDays(t, 7)).map(k => ({ e, k }))).sort((a, b) => a.k.due.localeCompare(b.k.due));
    const remind = (e, k) => `Namaste ${e.partyName} ji, ${settings().firm || 'Shivaa Jewels'} se yaad dilana: aapki kisht ${k.i}/${e.n} — ${inr(k.amount)} — ${fmtD(k.due)} ko ${k.due < t ? 'baaki thi' : 'aani hai'}. UPI: ${settings().upi || ''} 🙏`;
    return `<div class="toolbar"><button type="button" class="btn gold" data-act="dk-emi-new">💳 Naya kisht plan</button></div>
      <div class="stats">${stat('Chalu plan', open.length, compactInr(sum(open, emiLeft)) + ' baaki', 'coin', 'gold')}${stat('Is hafte ki kisht', dueRows.length, compactInr(sum(dueRows, x => x.k.amount)), 'clock', 'sky')}${stat('Der wali', dueRows.filter(x => x.k.due < t).length, '', 'box', '')}</div>
      ${card('🔔 Aane wali / der wali kisht', '7 din tak', dueRows.length ? dueRows.map(({ e, k }) => `<div class="dk-row ${k.due < t ? 'late' : ''}"><div><b>${esc(e.partyName)}</b> · kisht ${k.i}/${e.n} · <b>${inr(k.amount)}</b><div class="small muted">${esc(fmtD(k.due))} · ${esc(e.no)} · bill ${esc(e.invNo)}</div></div><div class="btns"><button type="button" class="btn sm gold" data-act="dk-emi-pay" data-id="${esc(e.id)}" data-i="${k.i}">Mili</button><button type="button" class="btn sm green" data-act="dk-wa" data-ph="${esc(e.phone)}" data-t="${esc(remind(e, k))}">Yaad dilao</button></div></div>`).join('') : '<div class="small muted">Koi kisht baaki nahi 👍</div>')}
      ${card('Saare plan', '', open.length ? open.map(e => `<div class="dk-row"><div><b>${esc(e.no)}</b> · ${esc(e.partyName)} · bill ${esc(e.invNo)}<div class="dk-emi">${e.plan.map(k => `<i class="${k.paidAt ? 'ok' : k.due < t ? 'late' : ''}" title="${esc(fmtD(k.due))} · ${esc(inr(k.amount))}"></i>`).join('')}</div><div class="small muted">${e.plan.filter(k => k.paidAt).length}/${e.n} mili · baaki ${inr(emiLeft(e))}</div></div></div>`).join('') : '<div class="small muted">Koi chalu plan nahi</div>')}`;
  }

  /* ================= GAADI KHAATA ================= */
  function cars() { const L = new Set((pro().cars || []).filter(Boolean)); S.vehLog.forEach(x => x.car && L.add(x.car)); (S.challans || []).forEach(c => c.car && L.add(c.car)); return [...L]; }
  async function vehNew() {
    const last = car => S.vehLog.filter(x => x.car === car).sort((a, b) => b.date.localeCompare(a.date) || num(b.kmEnd) - num(a.kmEnd))[0];
    const C = cars();
    const el = openModal(`<form novalidate>${mHead('🚗 Gaadi ki entry', 'km, petrol, driver')}<div class="m-body"><div class="fg">${fld('Tareekh', 'date', todayStr(), { type: 'date' })}
      <label class="f"><span>Gaadi <b class="req">*</b></span><input name="car" list="dk-cars" value="${esc(C[0] || '')}" placeholder="RJ-21-xx-xxxx"><datalist id="dk-cars">${C.map(x => `<option value="${esc(x)}">`).join('')}</datalist></label>
      ${fld('Driver', 'driver', '')}${fld('Meter shuru (km)', 'kmStart', (last(C[0]) || {}).kmEnd || '', { type: 'number' })}${fld('Meter band (km)', 'kmEnd', '', { type: 'number' })}
      ${fld('Petrol / diesel (litre)', 'fuelL', '', { type: 'number' })}${fld('Petrol ₹', 'fuelAmt', '', { type: 'number' })}${fld('Doosra kharcha ₹ (toll, repair)', 'other', '', { type: 'number' })}${fld('Challan no.', 'challan', '')}${fld('Note', 'note', '')}</div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save</button></div></form>`);
    const car = q$('[name="car"]', el), ks = q$('[name="kmStart"]', el); car.addEventListener('change', () => { const l = last(car.value.trim()); if (l && !ks.value) ks.value = l.kmEnd || ''; });
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); if (!f.car) return toast('Gaadi ka number daaliye', 'err');
      if (num(f.kmEnd) && num(f.kmEnd) < num(f.kmStart)) return toast('Band meter shuru se kam nahi ho sakta', 'err');
      const x = { id: uid('vh'), date: f.date || todayStr(), car: f.car.toUpperCase(), driver: f.driver, kmStart: num(f.kmStart), kmEnd: num(f.kmEnd), fuelL: num(f.fuelL), fuelAmt: num(f.fuelAmt), other: num(f.other), challan: f.challan, note: f.note, by: me().name, createdAt: Date.now() };
      if (await save('vehLog', x)) { closeModal(el); toast('✓ Gaadi entry save'); renderView(true); }
    };
  }
  function vehBody() {
    const mk = ui.dkVehM || monthKey(todayStr()); const L = S.vehLog.filter(x => monthKey(x.date) === mk);
    const M = new Map(); L.forEach(x => { const y = M.get(x.car) || { car: x.car, km: 0, l: 0, amt: 0, other: 0, trips: 0 }; y.km += Math.max(0, num(x.kmEnd) - num(x.kmStart)); y.l += num(x.fuelL); y.amt += num(x.fuelAmt); y.other += num(x.other); y.trips++; M.set(x.car, y); });
    const months = []; for (let i = 0; i < 6; i++) { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i); months.push(d.toISOString().slice(0, 7)); }
    return `<div class="toolbar"><button type="button" class="btn gold" data-act="dk-veh-new">🚗 Nayi entry</button></div><div class="seg-mini" style="margin-bottom:10px">${months.map(m => `<button type="button" class="${mk === m ? 'on' : ''}" data-act="seg" data-k="dkVehM" data-v="${m}">${m}</button>`).join('')}</div>
      ${card('🚗 Gaadi ka hisaab', mk, M.size ? `<div class="tw"><table class="tbl"><thead><tr><th>Gaadi</th><th class="r">Chakkar</th><th class="r">km</th><th class="r">Petrol</th><th class="r">km / litre</th><th class="r">₹ / km</th><th class="r">Kul kharcha</th></tr></thead><tbody>${[...M.values()].map(y => `<tr><td><b>${esc(y.car)}</b></td><td class="r">${y.trips}</td><td class="r">${Math.round(y.km)}</td><td class="r">${y.l ? y.l.toFixed(1) + ' L' : '—'}<div class="small muted">${inr(y.amt)}</div></td><td class="r">${y.l && y.km ? (y.km / y.l).toFixed(1) : '—'}</td><td class="r">${y.km ? ((y.amt + y.other) / y.km).toFixed(1) : '—'}</td><td class="r"><b>${inr(y.amt + y.other)}</b></td></tr>`).join('')}</tbody></table></div>` : '<div class="small muted">Is mahine koi entry nahi</div>')}
      ${card('Entries', '', L.length ? `<div class="tw"><table class="tbl"><thead><tr><th>Tareekh</th><th>Gaadi</th><th>Driver</th><th class="r">km</th><th class="r">Petrol</th><th>Challan</th></tr></thead><tbody>${L.sort((a, b) => b.date.localeCompare(a.date)).map(x => `<tr><td>${esc(fmtD(x.date))}</td><td>${esc(x.car)}</td><td>${esc(x.driver || '')}</td><td class="r">${num(x.kmEnd) ? Math.max(0, num(x.kmEnd) - num(x.kmStart)) : '—'}</td><td class="r">${x.fuelAmt ? inr(x.fuelAmt) : '—'}</td><td class="small">${esc(x.challan || '')}${x.note ? ' · ' + esc(x.note) : ''}</td></tr>`).join('')}</tbody></table></div>` : '<div class="small muted">—</div>')}`;
  }

  /* ================= TIJORI (do PIN) ================= */
  function tijoriModal(kind) {
    if (!SITE) return toast('Tijori ka PIN website par chalta hai', 'err');
    const el = openModal(`<form novalidate>${mHead(kind === 'open' ? '🔐 Tijori kholo' : '🔒 Tijori band ki', kind === 'open' ? 'Do alag logon ka PIN zaroori — har baar record + alert' : 'Ek PIN')}<div class="m-body"><div class="fg">
      ${fld('Pehla vyakti (username)', 'uname', me().uname || '', { req: 1 })}<label class="f"><span>Uska PIN</span><input name="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="off"></label>
      ${kind === 'open' ? `${fld('Doosra vyakti (username)', 'uname2', '', { req: 1 })}<label class="f"><span>Uska PIN</span><input name="pin2" type="password" inputmode="numeric" maxlength="8" autocomplete="off"></label>` : ''}
      ${fld('Kyun / kya nikala', 'why', '', { span: 1 })}</div><div class="red small" data-e></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">${kind === 'open' ? '🔐 Kholo' : '🔒 Band'}</button></div></form>`);
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); const b = q$('button.gold', el); b.disabled = true;
      try { const r = await API('tijori_open', { ...f, kind }); closeModal(el); toast(kind === 'open' ? `🔐 Tijori khuli — ${r.log.by.join(' + ')}` : '🔒 Tijori band — record ho gaya'); setTimeout(() => renderView(true), 1500); }
      catch (e) { q$('[data-e]', el).textContent = e.message || 'Nahi hua'; } finally { b.disabled = false; }
    };
  }
  function tijoriBody() {
    const L = (S.tijoriLog || []).slice().sort((a, b) => b.at - a.at).slice(0, 100);
    const last = L[0]; const open = last && last.kind === 'open';
    return `<div class="toolbar"><button type="button" class="btn gold" data-act="dk-tj" data-k="open">🔐 Tijori kholo (2 PIN)</button><button type="button" class="btn" data-act="dk-tj" data-k="close">🔒 Band ki</button><button type="button" class="btn" data-act="dk-night">📶 Raat ka RFID milaan</button></div>
      <div class="stats">${stat('Abhi', last ? (open ? 'KHULI' : 'Band') : '—', last ? dt(last.at) + ' · ' + last.by.join(' + ') : 'koi record nahi', 'lock', open ? 'gold' : 'sky')}${stat('Aaj khuli', L.filter(x => x.date === todayStr() && x.kind === 'open').length + ' baar', '', 'clock', '')}${stat('Samay ke baahar', L.filter(x => x.night).length, 'pichhli 100 mein', 'box', '')}</div>
      ${card('📜 Tijori ka record', 'mitaaya ya badla nahi ja sakta', L.length ? L.map(x => `<div class="dk-row ${x.night ? 'late' : ''}"><div><b>${x.kind === 'open' ? '🔐 Khuli' : '🔒 Band'}</b> · ${esc(x.by.join(' + '))}${x.why ? ' — ' + esc(x.why) : ''}<div class="small muted">${esc(dt(x.at))} · ${esc(x.device || '')}${x.night ? ' · <b class="red">dukaan ke samay ke baahar</b>' : ''}</div></div></div>`).join('') : '<div class="small muted">Abhi tak koi record nahi. Tijori kholne se pehle yahan do PIN daliye.</div>')}
      <p class="small muted">Kaun tijori khol sakta hai: Owner, Manager, aur jinhe Owner "Tijori chaabi" de (Setup → 🩺 Software ki sehat → Tijori chaabi). PIN Setup → 🛡 Suraksha mein banta hai.</p>`;
  }

  /* ================= TV DISPLAY ================= */
  function tvStart() { if (window.SJ_TV) return SJ_TV.start(); toast('TV file (sj-tv.js) nahi mili', 'err'); }
  function tvBody() {
    const R = window.SJ_TV ? SJ_TV.rates() : [];
    return card('📺 Showroom TV — live display', 'TV / tablet par browser kholkar login kijiye (View only login kaafi hai), phir "TV shuru karo"', `
      <div class="dk-tvprev">${R.map(r => `<div><span>${esc(r.label)}</span><b>${r.v ? inr(r.v) : '—'}</b><small>per ${esc(r.unit)}</small></div>`).join('')}</div>
      <div class="fg">
      ${fld('Naam ke neeche tagline', 'dkTvTag', pro().tvTag || 'Vishwas ki chamak · Since generations')}
      ${fld('Har slide kitne second', 'dkTvSec', pro().tvSec || 8, { type: 'number' })}
      <label class="f"><span>Chamak / motion</span><select name="dkTvFx"><option value="auto" ${(pro().tvFx || 'auto') === 'auto' ? 'selected' : ''}>Apne aap (TV dheema ho to halka)</option><option value="full" ${pro().tvFx === 'full' ? 'selected' : ''}>Poori chamak (tez TV / computer)</option><option value="lite" ${pro().tvFx === 'lite' ? 'selected' : ''}>Halka — sasta tablet / purana TV</option></select></label>
      <label class="f span2"><span>Offer / sandesh (har line alag slide + chalti patti mein)</span><textarea name="dkTvOff" rows="4" placeholder="Making par 20% chhoot\nPurana sona badlein — sabse achha bhaav">${esc(pro().tvOffers || '')}</textarea></label></div>
      <div class="btns">${boss() ? '<button type="button" class="btn sm" data-act="dk-tv-save">Save</button>' : ''}<button type="button" class="btn gold" data-act="dk-tv">📺 TV shuru karo</button></div>
      <p class="small muted">TV par sab live chalta hai: bhaav badalte hi number ghoomkar naye ho jaate hain (▲▼ pichhle din se), 10 din ki line, naye design ki photo (Vault mein photo wale piece) video ki tarah, offers, showroom ka countdown, token "Ab ki baari", aur neeche chalti patti. Screen band nahi hoti. Band karne ke liye Esc ya ✕.</p><p class="small">📎 Seedha TV link (Fire TV / laptop ke liye bookmark kijiye): <b class="mono">${esc(location.origin + location.pathname)}?tv=1</b> — login ke baad TV apne aap khulta hai.</p>`);
  }

  /* ================= MACHINE TEST ================= */
  function testBody() {
    const sc = window.SJ_SCALE ? SJ_SCALE.state() : null;
    return `<div class="dk-tests">
      ${card('📶 RFID / barcode reader', 'reader ko USB mein lagaiye, phir neeche box mein tag padhwaiye', `<input class="dk-rf" placeholder="Yahan click karke reader se tag padhwaiye" autocomplete="off"><div class="dk-rf-log small"></div>`)}
      ${card('⚖ Kaanta (USB / RS232)', 'sirf computer ke Chrome / Edge mein', window.SJ_SCALE && SJ_SCALE.has ? `<div class="btns"><button type="button" class="btn sm gold" data-act="dk-scale">Kaanta jodo</button></div><div class="dk-sc small">${sc && sc.on ? `Juda hai · ${sc.w == null ? '—' : num(sc.w).toFixed(3) + ' g'} ${sc.stable ? '✓ sthir' : '…'}` : 'Abhi nahi juda'}</div>` : '<div class="warn-box small">Is browser mein kaanta nahi jud sakta (Web Serial nahi) — computer par Chrome kholiye.</div>')}
      ${card('📷 Camera se barcode / QR', '', `<div class="small">${'BarcodeDetector' in window ? '✓ Ye phone camera se barcode padh sakta hai' : '✗ Is browser mein camera barcode nahi — Chrome (Android) use kijiye'}</div>`)}
      ${card('📍 GPS', 'field staff ke phone ke liye', `<div class="btns"><button type="button" class="btn sm" data-act="dk-gps">Location jaancho</button></div><div class="dk-gp small"></div>`)}
      ${card('🖨 Printer', '', `<div class="btns"><button type="button" class="btn sm" data-act="dk-print">Test page print</button></div><div class="small muted">Tag printer (TSC / Zebra) ka test Setup → Tag mein hai.</div>`)}
      ${card('🔔 Alert', '', `<div class="small">${'Notification' in window ? 'Browser notification: ' + Notification.permission : 'Is browser mein notification nahi'}</div>${isOwner() && SITE ? '<div class="btns"><button type="button" class="btn sm" data-act="dk-tg-test">Telegram test alert</button></div>' : ''}`)}</div>
      <p class="small muted">Machine kharidne se pehle: dukaan par yahi page kholkar test kijiye. Reader ka tag yahan dikhe aur "✓ stock mein mila" aaye, tabhi software ke saath chalega.</p>`;
  }
  let rfT0 = 0, rfN = 0;
  document.addEventListener('keydown', e => { const t = e.target; if (!t.classList || !t.classList.contains('dk-rf')) return; if (!t.value) { rfT0 = performance.now(); rfN = 0; } rfN++; if (e.key !== 'Enter') return; e.preventDefault(); e.stopPropagation();
    const v = t.value.trim(); t.value = ''; if (!v) return; const ms = performance.now() - rfT0; const fast = rfN > 4 && ms / rfN < 35; const p = window.SJ_SCAN ? SJ_SCAN.find(v) : null;
    const log = t.parentElement.querySelector('.dk-rf-log'); log.insertAdjacentHTML('afterbegin', `<div class="dk-row"><div><b class="mono">${esc(v.slice(0, 40))}</b> <span class="small muted">${v.length} akshar · ${Math.round(ms)} ms · ${fast ? '✓ machine se aaya' : 'haath se type?'}</span><div class="small ${p ? 'green' : 'red'}">${p ? `✓ stock mein mila: #${esc(p.sku)} ${esc(p.category || '')} ${esc(p.purity || '')}` : '✗ stock mein ye tag / SKU nahi (tag jodna ho to Floors → 📶 RFID tag jodo)'}</div></div></div>`); }, true);

  /* ================= PURITY PARCHI (karat meter) ================= */
  async function parchiImg(x) {
    const W = 900, H = 1180, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const c = cv.getContext('2d');
    c.fillStyle = '#fffaf0'; c.fillRect(0, 0, W, H); c.strokeStyle = '#b8892b'; c.lineWidth = 6; c.strokeRect(18, 18, W - 36, H - 36); c.lineWidth = 1.5; c.strokeRect(30, 30, W - 60, H - 60);
    const T = (t, X, Y, o = {}) => { c.font = `${o.w || 400} ${o.s || 28}px ${o.f || 'Georgia, serif'}`; c.fillStyle = o.c || '#2a1d06'; c.textAlign = o.a || 'left'; c.fillText(String(t), X, Y); };
    const s = settings();
    T(s.firm || 'Shivaa Jewels', W / 2, 100, { s: 46, w: 700, a: 'center', c: '#8a6414' }); T(s.address || '', W / 2, 140, { s: 20, a: 'center', c: '#6b5a3a', f: 'system-ui' });
    T('SONE KI SHUDDHTA PARCHI', W / 2, 210, { s: 32, w: 700, a: 'center' }); T('Purity test slip · Karat meter', W / 2, 245, { s: 20, a: 'center', c: '#6b5a3a', f: 'system-ui' });
    c.strokeStyle = '#d9c189'; c.beginPath(); c.moveTo(60, 270); c.lineTo(W - 60, 270); c.stroke();
    const rows = [['Parchi no.', x.no], ['Tareekh', new Date(x.at).toLocaleString('en-IN')], ['Grahak', x.name || '—'], ['Phone', x.phone || '—'], ['Gehna', x.item || '—'], ['Wazan (gross)', num(x.gross).toFixed(3) + ' g'], ['Karat meter reading', num(x.purity).toFixed(2) + ' %'], ['Karat (lagbhag)', (num(x.purity) * 24 / 100).toFixed(1) + ' K'], ['Shuddh sona (fine)', (num(x.gross) * num(x.purity) / 100).toFixed(3) + ' g']];
    if (num(x.rate)) rows.push(['Bhaav (24K /10g)', inr(x.rate)], ['Andaazan keemat', inr(num(x.gross) * num(x.purity) / 100 * num(x.rate) / 10)]);
    rows.forEach((r, k) => { const y = 320 + k * 62; T(r[0], 80, y, { s: 24, c: '#6b5a3a', f: 'system-ui' }); T(r[1], W - 80, y, { s: 28, w: 700, a: 'right' }); c.strokeStyle = '#efe3c4'; c.beginPath(); c.moveTo(80, y + 18); c.lineTo(W - 80, y + 18); c.stroke(); });
    const y0 = 320 + rows.length * 62 + 40;
    T('Ye reading XRF karat meter se li gayi hai. Galane (melting) par asli shuddhta', 80, y0, { s: 18, c: '#6b5a3a', f: 'system-ui' }); T('thodi alag ho sakti hai. Ye parchi bill nahi hai.', 80, y0 + 28, { s: 18, c: '#6b5a3a', f: 'system-ui' });
    T('Jaanch karne wala: ' + (x.by || ''), 80, H - 110, { s: 22, f: 'system-ui' }); T('Grahak ke sign', W - 80, H - 110, { s: 22, a: 'right', f: 'system-ui' }); c.beginPath(); c.moveTo(W - 330, H - 140); c.lineTo(W - 80, H - 140); c.stroke();
    return await new Promise(r => cv.toBlob(r, 'image/png'));
  }
  async function parchiNew(pre) {
    const s = settings();
    const el = openModal(`<form novalidate>${mHead('🧾 Purity parchi', 'Karat meter ki reading — grahak ko parchi')}<div class="m-body"><div class="fg">${fld('Grahak ka naam', 'name', pre && pre.name || '')}${fld('Phone', 'phone', pre && pre.phone || '', { im: 'tel', max: 14 })}${fld('Gehna', 'item', pre && pre.item || '', { ph: 'chain, kangan, purana sona…' })}${fld('Wazan (g)', 'gross', pre && pre.gross || '', { type: 'number', req: 1 })}${fld('Karat meter reading %', 'purity', pre && pre.purity || '', { type: 'number', req: 1, ph: '91.60' })}${fld('Bhaav 24K /10g (optional)', 'rate', num(s.gold24) || '', { type: 'number' })}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Parchi banao</button></div></form>`);
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); if (!(num(f.gross) > 0) || !(num(f.purity) > 0 && num(f.purity) <= 100)) return toast('Wazan aur reading (0–100%) daaliye', 'err');
      const x = { id: uid('pt'), no: nextNo('purityTests', 'PT-'), at: Date.now(), date: todayStr(), name: f.name, phone: cleanPhone(f.phone || ''), item: f.item, gross: num(f.gross), purity: num(f.purity), rate: num(f.rate), by: me().name, inv: pre && pre.inv || '' };
      if (!await save('purityTests', x)) return; closeModal(el); parchiShow(x); renderView(true);
    };
  }
  async function parchiShow(x) {
    const b = await parchiImg(x); const url = URL.createObjectURL(b);
    const el = openModal(`${mHead('🧾 ' + esc(x.no), esc(x.name || ''))}<div class="m-body"><img class="fd-parchi" src="${url}" alt="Purity parchi"></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><button type="button" class="btn" data-o="dl">Image save</button><button type="button" class="btn green" data-o="wa">WhatsApp</button></div>`, { wide: true });
    const dl = () => { const a = document.createElement('a'); a.href = url; a.download = x.no + '.png'; document.body.appendChild(a); a.click(); a.remove(); };
    q$('[data-o="dl"]', el).onclick = dl;
    q$('[data-o="wa"]', el).onclick = async () => { const file = new File([b], x.no + '.png', { type: 'image/png' }); if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], text: `${settings().firm || ''} — purity parchi ${x.no}` }); return; } catch (e) { if (e && e.name === 'AbortError') return; } } dl(); waOpen(x.phone, `${settings().firm || 'Shivaa Jewels'} — aapke sone ki shuddhta parchi ${x.no}: ${num(x.gross).toFixed(3)} g · ${num(x.purity).toFixed(2)}% · fine ${(num(x.gross) * num(x.purity) / 100).toFixed(3)} g`); };
  }
  function parchiBody() {
    const og = S.invoices.filter(v => v.type === 'oldgold' && !v.deleted && v.date >= addDays(todayStr(), -30)).sort((a, b) => b.date.localeCompare(a.date)).slice(0, 30);
    const L = (S.purityTests || []).slice().sort((a, b) => b.at - a.at).slice(0, 60);
    return `<div class="toolbar"><button type="button" class="btn gold" data-act="dk-pt-new">🧾 Nayi parchi</button></div>
      ${og.length ? card('Purane sone ke bill se parchi', 'pichhle 30 din', og.map(v => `<div class="dk-row"><div><b>${esc(v.no)}</b> · ${esc(v.partyName)}<div class="small muted">${(v.items || []).map(it => `${esc(it.category || 'purana sona')} ${num(it.gross).toFixed(3)} g @ ${num(it.tunch).toFixed(2)}%`).join(' · ')}</div></div><button type="button" class="btn sm" data-act="dk-pt-og" data-id="${esc(v.id)}">Parchi</button></div>`).join('')) : ''}
      ${card('Pichhli parchiyan', '', L.length ? L.map(x => `<div class="dk-row"><div><b>${esc(x.no)}</b> · ${esc(x.name || 'Grahak')} · ${num(x.gross).toFixed(3)} g @ <b>${num(x.purity).toFixed(2)}%</b><div class="small muted">${esc(dt(x.at))} · ${esc(x.item || '')} · ${esc(x.by || '')}</div></div><button type="button" class="btn sm" data-act="dk-pt-show" data-id="${esc(x.id)}">Dekho</button></div>`).join('') : '<div class="small muted">Abhi koi parchi nahi</div>')}`;
  }

  /* ================= SHOWROOM VIEW ================= */
  Object.assign(ICON, { store: '<path d="M3 9l1.5-5h15L21 9"/><path d="M4 9v11h16V9"/><path d="M3 9h18M9 20v-6h6v6"/>' });
  if (!VIEWS.some(v => v[0] === 'showroom')) { const i = VIEWS.findIndex(v => v[0] === 'field' || v[0] === 'floors'); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, ['showroom', 'Showroom', 'store', '🏬 Showroom']); }
  const SR_TABS = [['token', '🎫 Token'], ['emi', '💳 Kisht'], ['gaadi', '🚗 Gaadi'], ['tijori', '🔐 Tijori'], ['tv', '📺 TV'], ['parchi', '🧾 Purity parchi'], ['test', '🧪 Machine test']];
  VIEWDEF.showroom = {
    shell: () => { const t = ui.srTab || 'token'; return `<div class="rep-tabs sm-tabs">${SR_TABS.map(([k, l]) => `<button type="button" data-act="seg" data-k="srTab" data-v="${k}" class="${t === k ? 'on' : ''}">${l}</button>`).join('')}</div><div id="vbody"></div>`; },
    body() { const t = ui.srTab || 'token'; try { return ({ token: tokenBody, emi: emiBody, gaadi: vehBody, tijori: tijoriBody, tv: tvBody, parchi: parchiBody, test: testBody }[t] || tokenBody)(); } catch (e) { console.error(e); return emptyBox('Ye page nahi khula: ' + esc(e.message || String(e))); } }
  };
  setInterval(() => { try { if (typeof ui !== 'undefined' && location.hash === '#showroom' && (ui.srTab || 'token') === 'token' && !document.querySelector('#modal-root .overlay')) renderView(true); } catch (e) { /* ignore */ } }, 30000);

  /* ================= SETUP: SEHAT, TELEGRAM, BACKUP, EMERGENCY, CA, PRACTICE ================= */
  async function tgModal() {
    let r; try { r = await API('tg_status'); } catch (e) { return toast(e.message, 'err'); }
    const c = r.cfg, on = c.on && c.chat;
    const el = openModal(`${mHead('📨 Telegram alert (free)', on ? `Juda hai${c.chatName ? ' · ' + esc(c.chatName) : ''}${c.bot ? ' · @' + esc(c.bot) : ''}` : 'Aapke phone par alert — bina paise')}<div class="m-body">
      <ol class="dk-steps"><li>Phone mein <b>Telegram</b> kholiye → search <b>@BotFather</b> → <b>/newbot</b> likhiye → koi bhi naam (jaise <i>Shivaa Alert</i>) → username (<i>shivaa_alert_bot</i>).</li><li>BotFather jo <b>token</b> de (123456789:AA…) use neeche paste kijiye → <b>Save</b>.</li><li>Ab apne naye bot ko kholkar <b>Start</b> dabaiye → yahan <b>"Chat jodo"</b>.</li></ol>
      <div class="fg"><label class="f span2"><span>Bot token ${r.token ? `(abhi: ${esc(r.token)})` : ''}</span><input name="tgTok" autocomplete="off" placeholder="123456789:AA…" class="mono"></label></div>
      <div class="btns"><button type="button" class="btn sm gold" data-act="dk-tg-save">Token save</button><button type="button" class="btn sm" data-act="dk-tg-find" ${r.token ? '' : 'disabled'}>Chat jodo</button><button type="button" class="btn sm" data-act="dk-tg-test" ${on ? '' : 'disabled'}>Test alert</button>${r.token ? '<button type="button" class="btn sm danger" data-act="dk-tg-off">Hatao</button>' : ''}</div>
      <h4 class="gd-h">Kya bhejna hai</h4><div class="fg">
        <label class="f"><span>Alert</span><select name="tgLevel"><option value="high" ${c.level === 'high' ? 'selected' : ''}>Sirf zaroori (panic, maal kam, delete, tijori…)</option><option value="all" ${c.level === 'all' ? 'selected' : ''}>Sab alert</option></select></label>
        <label class="f"><span>Backup ki copy (taala band)</span><select name="tgBk"><option value="week" ${c.backup === 'week' ? 'selected' : ''}>Hafte mein ek</option><option value="day" ${c.backup === 'day' ? 'selected' : ''}>Roz raat</option><option value="off" ${c.backup === 'off' ? 'selected' : ''}>Nahi</option></select></label>
        <label class="chk span2"><input type="checkbox" name="tgHealth" ${c.health !== false ? 'checked' : ''}> Roz raat "software ki sehat theek" ka sandesh</label>
        <label class="f span2"><span>Backup password ${r.bkpass ? '(rakha hua hai — badalne ke liye naya likhiye)' : '(zaroori — kam se kam 8 akshar, ise yaad rakhiye!)'}</span><input name="tgPass" type="password" autocomplete="new-password" placeholder="${r.bkpass ? '••••••••' : 'naya password'}"></label></div>
      <div class="btns"><button type="button" class="btn sm gold" data-act="dk-tg-opts">Save</button><button type="button" class="btn sm" data-act="dk-tg-bk" ${on && r.bkpass ? '' : 'disabled'}>Backup abhi bhejo</button></div>
      ${r.lastBk && r.lastBk.at ? `<p class="small muted">Aakhri backup: ${esc(new Date(r.lastBk.at * 1000).toLocaleString('en-IN'))} · ${r.lastBk.ok ? '✓ gaya' : '✗ nahi gaya'}</p>` : ''}
      ${r.curl ? '' : '<div class="warn-box small">Hosting par PHP curl band hai — hPanel → PHP Configuration → curl on kijiye.</div>'}
      <p class="small muted">Backup file par taala hota hai: bina password koi nahi khol sakta. Hostinger band ho jaye to bhi Telegram wali file + password se poora data wapas aata hai (Setup → 🩺 → "Telegram backup kholo").</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`, { wide: true });
    el.classList.add('dk-tg-ov');
  }
  async function tgAct(k, el) {
    const v = n => (q$(`[name="${n}"]`, el) || {}).value;
    try {
      if (k === 'save') { const t = String(v('tgTok') || '').trim(); if (!t) return toast('Token paste kijiye', 'err'); await API('tg_cfg', { token: t }); toast('✓ Token sahi — ab bot ko Start dabakar "Chat jodo"'); }
      if (k === 'find') { await API('tg_find'); toast('✓ Telegram jud gaya — phone par message aaya hoga'); }
      if (k === 'test') { await API('tg_test'); toast('✓ Test alert bheja'); return; }
      if (k === 'off') { if (!await SJ_CONFIRM('Telegram alert hatayein?', 'Hatao')) return; await API('tg_cfg', { token: '' }); }
      if (k === 'opts') { const b = { level: v('tgLevel'), backup: v('tgBk'), health: !!(q$('[name="tgHealth"]', el) || {}).checked }; const p = v('tgPass'); if (p) b.bkpass = p; await API('tg_cfg', b); toast('✓ Save'); }
      if (k === 'bk') { toast('Backup ban raha hai…'); const r = await API('tg_backup_now', {}, 200000); toast('✓ ' + (r.msg || 'Backup gaya')); return; }
      closeModal(el); tgModal();
    } catch (e) { toast(e.message || 'Nahi hua', 'err'); }
  }
  async function healthModal() {
    let r, er = { list: [] }; try { r = await API('health'); try { er = await API('err_list'); } catch (e) { /* manager */ } } catch (e) { return toast(e.message, 'err'); }
    const okN = r.checks.filter(c => c.ok).length;
    const el = openModal(`${mHead('🩺 Software ki sehat', `${okN}/${r.checks.length} theek`)}<div class="m-body">
      <div class="dk-hl">${r.checks.map(c => `<div class="${c.ok ? 'ok' : 'bad'}"><i>${c.ok ? '✓' : '!'}</i><div><b>${esc(c.txt)}</b>${c.ok ? '' : `<small>${esc(c.fix)}</small>`}</div></div>`).join('')}</div>
      <div class="btns">${isOwner() ? '<button type="button" class="btn sm gold" data-act="dk-rtest">🔁 Restore test chalao</button>' : ''}<button type="button" class="btn sm" data-act="dk-bkopen">📂 Telegram backup kholo</button></div>
      <h4 class="gd-h">🐞 Galti ka record (${er.list.length})</h4>${er.list.length ? `<div class="dk-errs">${er.list.slice(0, 40).map(x => `<div><b>${esc(x.msg)}</b><small>${esc(new Date(x.at).toLocaleString('en-IN'))} · ${esc(x.user)} · ${esc(x.view || '')} · ${esc(x.src || '')}${x.n > 1 ? ' · ' + x.n + ' baar' : ''}</small></div>`).join('')}</div><div class="btns"><button type="button" class="btn sm" data-act="dk-err-copy">📋 Report copy (developer ke liye)</button>${isOwner() ? '<button type="button" class="btn sm" data-act="dk-err-clear">Saaf karo</button>' : ''}</div>` : '<div class="small muted">Koi galti record nahi hui 👍</div>'}
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`, { wide: true });
    el._errs = er.list;
  }
  async function bkOpen() {
    const el = openModal(`${mHead('📂 Telegram backup kholo', '.sjbk file + backup password → normal backup file')}<div class="m-body"><div class="fg"><label class="f span2"><span>.sjbk file</span><input type="file" accept=".sjbk,application/octet-stream" data-o="f"></label><label class="f span2"><span>Backup password</span><input type="password" data-o="p" autocomplete="off"></label></div><div class="small" data-o="st"></div><p class="small muted">Khuli file ko Setup → Backup & restore → <b>Restore</b> mein chuniye. Ye kaam isi phone / computer par hota hai — file kahin nahi jaati.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><button type="button" class="btn gold" data-o="go">Kholo</button></div>`);
    let file = null; const fi = q$('[data-o="f"]', el);
    const onChg = ev => { if (ev.target === fi) { ev.stopPropagation(); file = fi.files && fi.files[0]; } }; window.addEventListener('change', onChg, true);
    new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); window.removeEventListener('change', onChg, true); } }).observe(q$('#modal-root'), { childList: true });
    q$('[data-o="go"]', el).onclick = async () => {
      const st = q$('[data-o="st"]', el); const pass = q$('[data-o="p"]', el).value; if (!file || !pass) return toast('File aur password dono chahiye', 'err');
      st.textContent = 'Khul raha hai… (thoda samay lagta hai)';
      try {
        const buf = new Uint8Array(await file.arrayBuffer()); if (String.fromCharCode(...buf.slice(0, 5)) !== 'SJBK1') throw new Error('Ye Shivaa backup (.sjbk) file nahi hai');
        const salt = buf.slice(5, 21), iv = buf.slice(21, 33), tag = buf.slice(33, 49), ct = buf.slice(49);
        const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']);
        const key = await crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: 150000 }, km, { name: 'AES-GCM', length: 256 }, false, ['decrypt']);
        const joined = new Uint8Array(ct.length + 16); joined.set(ct); joined.set(tag, ct.length);
        let plain; try { plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, tagLength: 128 }, key, joined); } catch (e) { throw new Error('Password galat hai (ya file kharab)'); }
        let out = new Blob([plain]); const b0 = new Uint8Array(plain.slice(0, 2));
        if (b0[0] === 0x1f && b0[1] === 0x8b) { if (!('DecompressionStream' in window)) throw new Error('Is browser mein unzip nahi — Chrome use kijiye'); out = await new Response(out.stream().pipeThrough(new DecompressionStream('gzip'))).blob(); }
        const name = file.name.replace(/\.sjbk$/i, '') + '.json'; const a = document.createElement('a'); a.href = URL.createObjectURL(out); a.download = name; document.body.appendChild(a); a.click(); a.remove();
        st.innerHTML = `<b class="green">✓ Khul gaya — ${esc(name)} download hui.</b> Ab Setup → Backup & restore → Restore mein ise chuniye.`;
      } catch (e) { st.innerHTML = `<b class="red">${esc(e.message || 'Nahi khula')}</b>`; }
    };
  }
  async function emergModal() {
    let r, us = []; try { r = await API('emerg_status'); if (isOwner()) us = (await API('uext_list')).users.filter(u => u.role !== 'owner' && u.role !== 'viewer' && u.active); } catch (e) { return toast(e.message, 'err'); }
    if (!isOwner()) return nomineeModal(r);
    const el = openModal(`<form novalidate>${mHead('🆘 Emergency access', 'Aap kuch din uplabdh na hon to bharosemand vyakti dukaan sambhaal sake')}<div class="m-body">
      <p class="small" style="margin-top:0">Jise chunenge wo apne login se "Emergency access" maang sakta hai. Aapko <b>turant alert</b> jayega (Telegram / email). Agar aap tay samay tak <b>software khol lete hain</b> to request apne aap radd. Samay poora hone par wo Owner ka naya password rakh sakta hai.</p>
      <div class="fg"><label class="f"><span>Bharosemand vyakti (login)</span><select name="uid"><option value="">— koi nahi —</option>${us.map(u => `<option value="${esc(u.id)}" ${r.uid === u.id ? 'selected' : ''}>${esc(u.name)} (${esc(u.role)})</option>`).join('')}</select></label>
      <label class="f"><span>Intezaar</span><select name="hours">${[24, 48, 72, 120, 168].map(h => `<option value="${h}" ${r.hours === h ? 'selected' : ''}>${h} ghante</option>`).join('')}</select></label></div>
      ${r.req ? `<div class="warn-box">Request chal rahi hai: ${esc(new Date(r.req.at * 1000).toLocaleString('en-IN'))}${r.req.why ? ' — ' + esc(r.req.why) : ''}${r.req.done ? ' · <b>access le liya gaya</b>' : ''}</div><div class="btns"><button type="button" class="btn sm danger" data-act="dk-em-cancel">Request radd karo</button></div>` : ''}
      <p class="small muted">Parivaar ka koi sadasya ho to unka Manager login banaiye (Setup → Logins), phir yahan chuniye.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save</button></div></form>`);
    q$('form', el).onsubmit = async ev => { ev.preventDefault(); try { await API('emerg_cfg', formObj(ev.target)); closeModal(el); toast('✓ Emergency access save'); } catch (e) { toast(e.message, 'err'); } };
  }
  function nomineeModal(r) {
    const left = r.left ? `${Math.floor(r.left / 3600)} ghante ${Math.floor(r.left % 3600 / 60)} minute` : '';
    const el = openModal(`${mHead('🆘 Emergency access', 'Owner ne aapko bharosemand vyakti chuna hai')}<div class="m-body">
      ${!r.req ? `<p>Owner bilkul uplabdh na hon (bimari / yatra / koi anhoni) tabhi maangiye. Owner ko turant alert jayega; ${r.hours} ghante mein wo software kholte hain to request radd ho jayegi.</p><label class="f"><span>Wajah</span><input data-o="why" maxlength="200"></label>`
        : r.req.done ? '<div class="fd-done">Access le liya gaya hai.</div>' : r.ready ? `<div class="fd-done">✓ Intezaar poora. Ab Owner ka naya password rakh sakte hain.</div><div class="fg"><label class="f"><span>Aapka apna password</span><input type="password" data-o="mp" autocomplete="current-password"></label><label class="f"><span>Owner ka naya password (8+ akshar)</span><input type="password" data-o="np" autocomplete="new-password"></label></div>` : `<div class="warn-box">Request bheji gayi — ${esc(left)} baaki.</div>`}
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button>${!r.req ? '<button type="button" class="btn danger" data-o="req">🆘 Access maango</button>' : !r.req.done && r.ready ? '<button type="button" class="btn gold" data-o="take">Owner ka access lo</button>' : !r.req.done ? '<button type="button" class="btn" data-o="cx">Request wapas lo</button>' : ''}</div>`);
    const b = (k, f) => { const x = q$(`[data-o="${k}"]`, el); if (x) x.onclick = f; };
    b('req', async () => { if (!await SJ_CONFIRM('Pakka? Owner ko turant alert jayega.', 'Haan, maango')) return; try { await API('emerg_req', { why: q$('[data-o="why"]', el).value }); closeModal(el); toast('Request bheji gayi'); } catch (e) { toast(e.message, 'err'); } });
    b('cx', async () => { try { await API('emerg_cancel'); closeModal(el); toast('Request wapas'); } catch (e) { toast(e.message, 'err'); } });
    b('take', async () => { try { const x = await API('emerg_take', { mypass: q$('[data-o="mp"]', el).value, newpass: q$('[data-o="np"]', el).value }); closeModal(el); await SJ_CONFIRM(`✓ Owner ka password badal gaya. Owner username: ${x.owner}. Ab logout karke is username aur naye password se login kijiye.`, 'Theek'); } catch (e) { toast(e.message, 'err'); } });
  }
  async function caModal() {
    let us, mp; try { us = (await API('uext_list')).users; mp = (await API('login_untils')).map || {}; } catch (e) { return toast(e.message, 'err'); }
    const L = us.filter(u => u.role !== 'owner');
    openModal(`${mHead('🧾 CA / auditor login', 'Sirf dekh sake, badal kuch na sake — tay tareekh par apne aap band')}<div class="m-body">
      <p class="small" style="margin-top:0">1) Setup → Logins mein <b>View only</b> login banaiye (jaise <i>ca_sharma</i>). 2) Yahan uski <b>aakhri tareekh</b> rakhiye. Us din ke baad login apne aap band ho jayega.</p>
      ${L.length ? L.map(u => `<div class="dk-row"><div><b>${esc(u.name)}</b> <span class="pill">${esc(u.role)}</span>${(mp[u.id] || {}).ca ? ' <span class="pill gold">CA</span>' : ''}<div class="small muted">${esc(u.uname)}${(mp[u.id] || {}).until ? ' · aakhri din ' + esc(fmtD(mp[u.id].until)) + ((mp[u.id].until < todayStr()) ? ' · <b class="red">band</b>' : '') : ''}</div></div><div class="btns"><input type="date" data-until="${esc(u.id)}" value="${esc((mp[u.id] || {}).until || '')}"><button type="button" class="btn sm gold" data-act="dk-ca-set" data-id="${esc(u.id)}" data-role="${esc(u.role)}">Save</button></div></div>`).join('') : '<div class="small muted">Koi doosra login nahi</div>'}
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`, { wide: true });
  }
  async function keyholderModal() {
    let us; try { us = (await API('uext_list')).users.filter(u => u.role === 'staff' && u.active); } catch (e) { return toast(e.message, 'err'); }
    openModal(`${mHead('🔐 Tijori chaabi', 'Owner / Manager hamesha khol sakte hain')}<div class="m-body">${us.length ? us.map(u => `<label class="chk dk-row"><input type="checkbox" data-kh="${esc(u.id)}" ${u.keyholder ? 'checked' : ''}> <span><b>${esc(u.name)}</b> <span class="small muted">${u.pin ? 'PIN bana hai' : 'PIN nahi bana'}</span></span></label>`).join('') : '<div class="small muted">Koi staff login nahi</div>'}</div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`);
  }
  document.addEventListener('change', async e => { const i = e.target; if (!i.dataset || !i.dataset.kh) return; e.stopPropagation(); try { await API('keyholder', { id: i.dataset.kh, on: i.checked }); toast('✓ Save'); } catch (er) { toast(er.message, 'err'); i.checked = !i.checked; } }, true);

  function practiceStart() { SJ_CONFIRM('🎓 Practice mode: software asli data ki copy par chalega — bill, stock, kuch bhi banaiye, kuch save nahi hoga. Is tab mein "Practice band karo" dabate hi sab pehle jaisa. Shuru karein?', 'Shuru karo').then(ok => { if (!ok) return; try { sessionStorage.setItem('sj-practice', '1'); } catch (e) { /* ignore */ } location.reload(); }); }

  function sehatCard() {
    const pr = window.SJ_PRACTICE;
    const practice = `<div class="card"><div class="card-h"><h3>🎓 Practice mode</h3>${pr ? '<span class="pill gold">chalu</span>' : ''}</div><p class="small muted" style="margin-top:0">Naya staff bill banana, scan karna seekhe — asli hisaab par koi asar nahi.</p><div class="btns">${pr ? '<span class="small">Upar ki patti se band kijiye.</span>' : '<button type="button" class="btn sm" data-act="dk-practice">Practice shuru karo</button>'}</div></div>`;
    if (!SITE) return practice;
    if (!boss()) return practice + `<div class="card" id="dk-nom" hidden></div>`;
    return `<div class="card" id="dk-sehat"><div class="card-h"><h3>🩺 Software ki sehat & alert</h3><span class="small muted">Telegram · backup · restore test · galtiyan</span></div>
      <div class="btns"><button type="button" class="btn sm gold" data-act="dk-health">🩺 Sehat dekho</button>${isOwner() ? '<button type="button" class="btn sm" data-act="dk-tg">📨 Telegram alert</button><button type="button" class="btn sm" data-act="dk-emerg">🆘 Emergency access</button><button type="button" class="btn sm" data-act="dk-ca">🧾 CA login</button><button type="button" class="btn sm" data-act="dk-kh">🔐 Tijori chaabi</button>' : ''}<button type="button" class="btn sm" data-act="dk-bkopen">📂 Telegram backup kholo</button></div></div>` + practice;
  }
  { const SU = VIEWDEF.setup; if (SU && SU.body) VIEWDEF.setup = { ...SU, body() { const h = SU.body.apply(SU, arguments); let x = ''; try { x = guideCard(true) + sehatCard(); } catch (e) { console.error(e); } return x + h; } }; }
  // the trusted person (non-owner) sees the emergency card only when chosen
  window.addEventListener('sj-sec', () => { if (!SITE || isOwner() || !window.SJ_USER) return; API('emerg_status').then(r => { if (!r.nominee) return; const fill = () => { const c = q$('#dk-nom'); if (c) { c.hidden = false; c.innerHTML = `<div class="card-h"><h3>🆘 Emergency access</h3></div><p class="small muted" style="margin-top:0">Owner ne aapko bharosemand vyakti chuna hai.</p><div class="btns"><button type="button" class="btn sm" data-act="dk-emerg">Kholo</button></div>`; } }; fill(); window.SJ_NOMINEE = true; }).catch(() => null); });

  /* ================= SETUP SAHAYAK ================= */
  let G = { at: 0, data: null, busy: false };
  async function guideLoad() {
    if (G.busy || !SITE || !boss()) return; G.busy = true;
    try {
      const out = {};
      try { const h = await API('health'); h.checks.forEach(c => { out[c.k] = c.ok; }); } catch (e) { /* ignore */ }
      try { const u = await API('uext_list'); out.staffPin = u.users.filter(x => x.active && x.role !== 'owner' && x.role !== 'viewer').every(x => x.pin); out.staffN = u.users.filter(x => x.active && x.role !== 'owner').length; } catch (e) { /* ignore */ }
      if (isOwner()) { try { out.emerg = !!(await API('emerg_status')).uid; } catch (e) { /* ignore */ } }
      G.data = out; G.at = Date.now();
    } finally { G.busy = false; }
    const el = q$('.dk-guide'); if (el) el.outerHTML = guideCard(el.dataset.setup === '1');
  }
  function guideItems() {
    const s = settings(), sec = (window.SJ_SEC || {}), m = sec.me || {}, p = sec.policy || {}, d = G.data || {};
    const L = [
      ['firm', !!(s.firm && (s.phone || s.gstin)), 'Dukaan ka naam, phone, GSTIN', 'setup'],
      ['rates', s.ratesUpdated === todayStr(), 'Aaj ka sone-chandi ka bhaav', 'rates'],
      ['pin', !!m.pin, 'Aapka PIN (delete / tijori ke liye)', 'gd-pin']];
    if (SITE) L.push(
      ['owner2fa', d.owner2fa, 'Owner ka 2-step login (Authenticator app)', 'setup'],
      ['pol', !!p.pin, 'Suraksha niyam: delete se pehle PIN', 'gd-policy'],
      ['cron', d.cron, 'Cron (raat ka backup + alert) Hostinger mein', 'gd-keys'],
      ['backup', d.backup, 'Roz ka backup ban raha hai', 'dk-health'],
      ['tg', d.telegram, 'Telegram par free alert', 'dk-tg'],
      ['staffPin', d.staffN ? d.staffPin : true, 'Har staff ka apna PIN', 'gd-staff'],
      ['emerg', isOwner() ? d.emerg : true, 'Emergency access ke liye bharosemand vyakti', 'dk-emerg'],
      ['restore', d.restore, 'Backup ka restore test', 'dk-health']);
    if (window.SJ_FLOORS) L.push(['floor', !!SJ_FLOORS.cur(), 'Is device ka floor chuna', 'floors']);
    return L.map(([k, ok, t, go]) => ({ k, ok: ok === undefined ? null : !!ok, t, go }));
  }
  function guideCard(inSetup) {
    if (!boss()) return '';
    if (SITE && (!G.data || Date.now() - G.at > 5 * 60000)) setTimeout(guideLoad, 50);
    const L = guideItems(), known = L.filter(x => x.ok !== null), done = known.filter(x => x.ok).length, pc = known.length ? Math.round(done / known.length * 100) : 0;
    if (!inSetup && known.length && done === known.length) return '';
    return `<div class="card dk-guide" data-setup="${inSetup ? 1 : 0}"><div class="card-h"><h3>✅ Setup sahayak</h3><span class="pill ${pc === 100 ? 'green' : 'gold'}">${done}/${known.length} pura</span></div><div class="dk-prog"><i style="width:${pc}%"></i></div>
      <div class="dk-gl">${L.map(x => `<div class="${x.ok ? 'ok' : x.ok === null ? 'wait' : ''}"><i>${x.ok ? '✓' : x.ok === null ? '…' : '○'}</i><span>${esc(x.t)}</span>${x.ok ? '' : `<button type="button" class="btn sm" data-act="dk-go" data-go="${esc(x.go)}">Abhi karo</button>`}</div>`).join('')}</div></div>`;
  }
  { const D = VIEWDEF.dashboard; if (D && D.body) VIEWDEF.dashboard = { ...D, body() { let x = ''; try { x = guideCard(false); } catch (e) { console.error(e); } return x + D.body.apply(D, arguments); } }; }
  function go(k) {
    if (k === 'rates') { if (typeof openRates === 'function') return openRates(); }
    if (k === 'floors') { location.hash = '#floors'; return; }
    if (k.startsWith('dk-') || k.startsWith('gd-')) { const b = document.createElement('button'); b.dataset.act = k; b.hidden = true; document.body.appendChild(b); b.click(); b.remove(); return; }
    location.hash = '#setup';
  }

  /* ================= clicks ================= */
  const ACT = {
    'dk-tok-new': () => tokNew(), 'dk-tok': t => tokSet(t.dataset.id, t.dataset.s), 'dk-tok-wa': t => { const x = S.qTokens.find(y => y.id === t.dataset.id); if (x) waOpen(x.phone, `${settings().firm || 'Shivaa Jewels'} — aapka token ${tNo(x)}. Aapki baari aane par bulayenge 🙏`); },
    'dk-emi-new': () => emiNew(), 'dk-emi-pay': t => emiPay(t.dataset.id, t.dataset.i), 'dk-wa': t => waOpen(t.dataset.ph, t.dataset.t),
    'dk-veh-new': () => vehNew(),
    'dk-tj': t => tijoriModal(t.dataset.k), 'dk-night': () => { ui.flTab = 'tally'; location.hash = '#floors'; },
    'dk-tv': () => tvStart(), 'dk-tv-save': async () => { const p = { ...pro(), tvOffers: (q$('[name="dkTvOff"]') || {}).value || '', tvSec: num((q$('[name="dkTvSec"]') || {}).value) || 8, tvTag: ((q$('[name="dkTvTag"]') || {}).value || '').slice(0, 80), tvFx: (q$('[name="dkTvFx"]') || {}).value || 'auto' }; if (await saveSettings({ ...S.settings, pro: p })) toast('✓ TV settings save'); },
    'dk-scale': async () => { try { await SJ_SCALE.connect(); toast('✓ Kaanta juda'); renderView(true); } catch (e) { toast(e.message || 'Kaanta nahi juda', 'err'); } },
    'dk-gps': t => { const o = t.closest('.card').querySelector('.dk-gp'); o.textContent = 'Dhoondh raha hai…'; if (!navigator.geolocation) { o.textContent = '✗ GPS nahi'; return; } navigator.geolocation.getCurrentPosition(p => { o.innerHTML = `✓ ${p.coords.latitude.toFixed(5)}, ${p.coords.longitude.toFixed(5)} · accuracy <b>${Math.round(p.coords.accuracy)} m</b> ${p.coords.accuracy <= 50 ? '(badhiya)' : p.coords.accuracy <= 150 ? '(theek)' : '(kamzor — bahar jaakar dekhiye)'}`; }, e => { o.textContent = '✗ ' + (e.code === 1 ? 'Location ki ijaazat nahi — browser settings mein allow kijiye' : 'Location nahi mili'); }, { enableHighAccuracy: true, timeout: 15000 }); },
    'dk-print': () => { const w = window.open('', '_blank', 'width=420,height=520'); if (!w) return toast('Popup allow kijiye', 'err'); w.document.write(`<!doctype html><title>Test</title><body style="font-family:system-ui;text-align:center;padding:30px"><h2>${esc(settings().firm || 'Shivaa Jewels')}</h2><p>Printer test ✓</p><p>${esc(new Date().toLocaleString('en-IN'))}</p>`); w.document.close(); setTimeout(() => { try { w.focus(); w.print(); } catch (e) { /* ignore */ } }, 300); },
    'dk-pt-new': () => parchiNew(), 'dk-pt-show': t => { const x = S.purityTests.find(y => y.id === t.dataset.id); if (x) parchiShow(x); },
    'dk-pt-og': t => { const v = S.invoices.find(x => x.id === t.dataset.id); if (!v) return; const it = (v.items || [])[0] || {}; const party = S.customers.find(c => c.id === v.partyId) || {}; parchiNew({ name: v.partyName, phone: party.phone || '', item: (v.items || []).map(i => i.category || 'purana sona').join(', '), gross: r3(sum(v.items || [], i => i.gross)), purity: num(it.tunch), inv: v.no }); },
    'dk-tg': () => tgModal(), 'dk-tg-save': t => tgAct('save', t.closest('.overlay')), 'dk-tg-find': t => tgAct('find', t.closest('.overlay')), 'dk-tg-test': t => tgAct('test', t.closest('.overlay')), 'dk-tg-off': t => tgAct('off', t.closest('.overlay')), 'dk-tg-opts': t => tgAct('opts', t.closest('.overlay')), 'dk-tg-bk': t => tgAct('bk', t.closest('.overlay')),
    'dk-health': () => healthModal(), 'dk-rtest': async () => { try { toast('Restore test chal raha hai…'); const r = await API('restore_test', {}, 120000); toast((r.result.ok ? '✓ ' : '⚠ ') + r.result.msg, r.result.ok ? '' : 'err'); const ov = q$('#modal-root .overlay:last-child'); if (ov) closeModal(ov); healthModal(); } catch (e) { toast(e.message, 'err'); } },
    'dk-bkopen': () => bkOpen(),
    'dk-err-copy': t => { const ov = t.closest('.overlay'); const L = (ov && ov._errs) || []; const txt = `Shivaa Jewels — galti ka record (${new Date().toLocaleString('en-IN')})\n` + L.map(x => `• ${x.msg}\n   ${new Date(x.at).toLocaleString('en-IN')} · ${x.user} · ${x.view} · ${x.src} · v${x.ver} · ${x.n}x · ${x.ua}`).join('\n'); navigator.clipboard.writeText(txt).then(() => toast('✓ Copy — developer ko bhej dijiye'), () => toast('Copy nahi hua', 'err')); },
    'dk-err-clear': async t => { try { await API('err_clear'); closeModal(t.closest('.overlay')); toast('✓ Saaf'); } catch (e) { toast(e.message, 'err'); } },
    'dk-emerg': () => emergModal(), 'dk-em-cancel': async t => { try { await API('emerg_cancel'); closeModal(t.closest('.overlay')); toast('Request radd'); } catch (e) { toast(e.message, 'err'); } },
    'dk-ca': () => caModal(), 'dk-ca-set': async t => { const d = (q$(`[data-until="${t.dataset.id}"]`) || {}).value || ''; try { await API('login_until', { id: t.dataset.id, until: d, ca: t.dataset.role === 'viewer' }); toast(d ? `✓ ${fmtD(d)} ke baad band` : '✓ Tareekh hata di'); } catch (e) { toast(e.message, 'err'); } },
    'dk-kh': () => keyholderModal(), 'dk-practice': () => practiceStart(),
    'dk-go': t => go(t.dataset.go)
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="dk-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);

  /* ================= Jarvis ================= */
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    agentTools = function () {
      const L = T0.apply(this, arguments); const add = (name, description, fn) => { if (!L.some(x => x.name === name)) L.push({ name, description, inputSchema: { type: 'object', properties: {} }, execute: async () => { try { return fn(); } catch (e) { return { error: String(e.message || e) }; } } }); };
      add('showroom_today', 'Showroom aaj: token (intezaar, avg wait), kisht (EMI) jo is hafte aani hai, tijori kab khuli, gaadi ka kharcha is mahine.', () => { const T = todayTok(); const t = todayStr(); const due = S.emis.filter(e => e.status === 'open').flatMap(e => e.plan.filter(k => !k.paidAt && k.due <= addDays(t, 7)).map(k => ({ party: e.partyName, kisht: k.i + '/' + e.n, amount: k.amount, due: k.due }))); const tj = (S.tijoriLog || []).slice().sort((a, b) => b.at - a.at).slice(0, 5).map(x => ({ kind: x.kind, by: x.by, at: new Date(x.at).toLocaleString('en-IN'), why: x.why })); const mk = monthKey(t); return { tokensToday: T.length, waiting: T.filter(x => x.status === 'wait').length, emiDue7d: due, tijori: tj, vehicleSpendThisMonth: Math.round(sum(S.vehLog.filter(x => monthKey(x.date) === mk), x => num(x.fuelAmt) + num(x.other))), screen: 'Showroom (🏬)' }; });
      return L;
    };
  }
  window.SJ_DUKAAN = { tvStart, guideItems, parchiImg };

  const st = document.createElement('style');
  st.textContent = `.dk-tokbig{font:800 72px/1.1 var(--serif,Georgia,serif);color:var(--gold);letter-spacing:2px;margin:10px 0}
    .dk-tk{display:flex;align-items:center;gap:12px;border:1px solid var(--line);border-left:4px solid var(--line);border-radius:12px;padding:8px 10px;margin-bottom:6px;flex-wrap:wrap}.dk-tk>b{font:800 22px var(--serif,Georgia,serif);color:var(--gold);min-width:74px}.dk-tk>div:nth-child(2){flex:1;min-width:150px;display:flex;flex-direction:column}.dk-tk small{color:var(--muted);font-size:12px}.dk-tk.serve{border-left-color:#22c55e}.dk-tk.late{border-left-color:#ef4444;background:rgba(239,68,68,.05)}.dk-tk .btns{margin:0}
    .dk-row{display:flex;justify-content:space-between;align-items:center;gap:10px;border:1px solid var(--line);border-radius:12px;padding:8px 10px;margin-bottom:6px;flex-wrap:wrap}.dk-row>div:first-child{min-width:0;flex:1}.dk-row.late{border-color:rgba(239,68,68,.5);background:rgba(239,68,68,.05)}.dk-row .btns{margin:0;flex-wrap:wrap}.dk-row input[type=date]{max-width:160px}
    .dk-emi{display:flex;gap:3px;margin:6px 0 2px;flex-wrap:wrap}.dk-emi i{width:16px;height:8px;border-radius:4px;background:var(--line)}.dk-emi i.ok{background:#22c55e}.dk-emi i.late{background:#ef4444}
    .dk-tests{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,320px),1fr));gap:12px}.dk-tests .card{margin:0}.dk-rf{width:100%;font-size:16px;padding:12px}.dk-rf-log{margin-top:8px;max-height:220px;overflow:auto}
    .dk-steps{margin:0 0 12px;padding-left:20px;font-size:13.5px;line-height:1.6}.dk-steps li{margin-bottom:4px}
    .dk-hl{display:flex;flex-direction:column;gap:6px;margin-bottom:12px}.dk-hl>div{display:flex;gap:10px;align-items:flex-start;border:1px solid var(--line);border-radius:12px;padding:8px 10px}.dk-hl i{flex:none;display:grid;place-items:center;width:24px;height:24px;border-radius:50%;font-style:normal;font-weight:800;background:#16a34a;color:#fff}.dk-hl .bad i{background:#f59e0b}.dk-hl .bad{border-color:rgba(245,158,11,.5)}.dk-hl small{display:block;color:var(--muted);font-size:12px}
    .dk-errs{display:flex;flex-direction:column;gap:6px;max-height:280px;overflow:auto;margin-bottom:8px}.dk-errs>div{border:1px solid var(--line);border-radius:10px;padding:6px 10px;font-size:12.5px;overflow-wrap:anywhere}.dk-errs small{display:block;color:var(--muted)}
    .dk-prog{height:8px;border-radius:6px;background:var(--line);overflow:hidden;margin:2px 0 10px}.dk-prog i{display:block;height:100%;background:linear-gradient(90deg,var(--gold),#f3d77a);border-radius:6px;transition:width .4s}
    .dk-gl{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));gap:6px}.dk-gl>div{display:flex;align-items:center;gap:8px;border:1px solid var(--line);border-radius:12px;padding:6px 10px;font-size:13px}.dk-gl>div span{flex:1;min-width:0}.dk-gl i{flex:none;display:grid;place-items:center;width:22px;height:22px;border-radius:50%;border:2px solid var(--line);font-style:normal;font-weight:800;font-size:12px;color:var(--muted)}.dk-gl .ok{opacity:.7}.dk-gl .ok i{background:#16a34a;border-color:#16a34a;color:#fff}.dk-gl .btn{flex:none}
    .dk-tvprev{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin-bottom:12px}.dk-tvprev div{border-radius:14px;padding:10px 12px;background:radial-gradient(circle at 30% 0,#3a2808,#0b0805);border:1px solid rgba(243,207,111,.35);display:flex;flex-direction:column}.dk-tvprev span,.dk-tvprev small{font-size:11.5px;color:#bba982}.dk-tvprev b{font:700 20px var(--serif,Georgia,serif);color:#f6dd8c}`;
  document.head.appendChild(st);
})();
