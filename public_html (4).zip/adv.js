/* =====================================================================
   ADVANCED LAYER — live dashboard & motion, interactive charts,
   action centre, smart bill auto-fill, bill error guard, split payment,
   profit engine and automatic double-entry books
   ===================================================================== */
const ADV_RM=window.matchMedia('(prefers-reduced-motion: reduce)');
const advCalm=()=>ADV_RM.matches;
const advSign=n=>n>0.0001?'adv-up':n<-0.0001?'adv-dn':'';
const advArrow=n=>n>0.0001?'▲':n<-0.0001?'▼':'•';
const advPct=(cur,prev)=>{cur=num(cur);prev=num(prev);if(!prev)return null;return (cur-prev)/Math.abs(prev)*100};
const advPctTxt=p=>p==null?'new':(p>0?'+':'')+(Math.abs(p)>=100?Math.round(p):p.toFixed(1))+'%';
let ADV_N=0;const advId=p=>(p||'a')+(++ADV_N);
const advW=()=>{const w=innerWidth;return w>=1024?Math.min(1240,w-320):Math.max(300,w-40)};

/* ---- gold/silver rate on any day (from the saved rate history) ---- */
let ADV_RH={n:-1,arr:[]};
function advRH(){const H=S.rateHistory||[];if(ADV_RH.n!==H.length||ADV_RH.src!==H){ADV_RH={n:H.length,src:H,arr:H.filter(r=>r&&r.date).slice().sort((a,b)=>a.date.localeCompare(b.date))}}return ADV_RH.arr}
function advRateAt(date,metal){const A=advRH();const k=metal==='silver'?'silver999':'gold24';let lo=0,hi=A.length-1,best=null;
  while(lo<=hi){const m=(lo+hi)>>1;if(A[m].date<=date){best=m;lo=m+1}else hi=m-1}
  for(let i=best;i!=null&&i>=0;i--){const v=num(A[i][k]);if(v>0)return metal==='silver'?v/1000:v/10}
  return rateFor(metal)}

/* ---- sparkline & charts (pure SVG, theme aware) ---- */
function advSpark(vals,color,o){o=o||{};const n=vals.length;if(n<2||vals.every(v=>!num(v)))return `<svg class="sp" viewBox="0 0 100 30" preserveAspectRatio="none" aria-hidden="true"><line x1="0" y1="27" x2="100" y2="27" style="stroke:var(--line)" stroke-width="1" vector-effect="non-scaling-stroke"/></svg>`;
  const mx=Math.max(...vals.map(num)),mn=Math.min(0,...vals.map(num));const rg=mx-mn||1;const X=i=>i*100/(n-1),Y=v=>27-(num(v)-mn)/rg*24;
  const pts=vals.map((v,i)=>`${X(i).toFixed(2)},${Y(v).toFixed(2)}`);const gid=advId('sg');
  return `<svg class="sp" viewBox="0 0 100 30" preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:${color};stop-opacity:.32"/><stop offset="1" style="stop-color:${color};stop-opacity:0"/></linearGradient></defs><path d="M0,30 L${pts.join(' L')} L100,30 Z" style="fill:url(#${gid})"/><polyline points="${pts.join(' ')}" style="fill:none;stroke:${color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>${o.dot!==false?`<circle cx="100" cy="${Y(vals[n-1]).toFixed(2)}" r="2.2" style="fill:${color}" vector-effect="non-scaling-stroke"/>`:''}</svg>`}
const ADV_CH={};
function advNice(mx){if(mx<=0)return 1;const p=Math.pow(10,Math.floor(Math.log10(mx)));const f=mx/p;return (f<=1?1:f<=2?2:f<=2.5?2.5:f<=5?5:10)*p}
function advLine(o){const id=advId('ch');const W=Math.round(o.w||advW()),H=o.h||230,P={l:58,r:14,t:14,b:28};const n=o.labels.length;
  const all=o.sets.flatMap(s=>s.values.map(num));let mx=Math.max(0,...all),mn=Math.min(0,...all);const top=advNice(mx||1);const step=top/4;const bot=mn<0?-Math.ceil(-mn/step)*step:0;
  const pw=W-P.l-P.r,ph=H-P.t-P.b;const X=i=>P.l+(n<=1?pw/2:i*pw/(n-1)),Y=v=>P.t+(top-num(v))/((top-bot)||1)*ph;
  let g='';for(let v=bot;v<=top+1e-9;v+=step){const y=Y(v).toFixed(1);g+=`<line class="gl" x1="${P.l}" x2="${W-P.r}" y1="${y}" y2="${y}"/><text x="${P.l-8}" y="${(+y+4).toFixed(1)}" text-anchor="end">${esc((o.yfmt||compactInr)(v))}</text>`}
  const every=Math.max(1,Math.ceil(n/(W<520?4:W<900?7:10)));let xl='';o.labels.forEach((l,i)=>{if(i%every===0||i===n-1&&(n-1)%every>every/2)xl+=`<text x="${X(i).toFixed(1)}" y="${H-8}" text-anchor="middle">${esc(l)}</text>`});
  let paths='';o.sets.forEach((s,si)=>{const pts=s.values.map((v,i)=>`${X(i).toFixed(1)},${Y(v).toFixed(1)}`);if(!pts.length)return;
    if(si===0){const gid=id+'g';paths+=`<defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:${s.color};stop-opacity:.28"/><stop offset="1" style="stop-color:${s.color};stop-opacity:0"/></linearGradient></defs><path class="ar" d="M${X(0).toFixed(1)},${Y(0).toFixed(1)} L${pts.join(' L')} L${X(n-1).toFixed(1)},${Y(0).toFixed(1)} Z" style="fill:url(#${gid})"/>`}
    paths+=`<path class="ln" pathLength="1" d="M${pts.join(' L')}" style="stroke:${s.color}${s.dash?';stroke-dasharray:5 4':''}"/>`});
  const dots=o.sets.map((s,si)=>`<circle class="hd" data-s="${si}" r="4.5" cx="0" cy="0" style="fill:${s.color}"/>`).join('');
  ADV_CH[id]={...o,W,H,P,n,X,Y};
  const leg=o.sets.map(s=>`<span><i style="background:${s.color}"></i>${esc(s.name)}${s.total!=null?` <b>${esc(s.total)}</b>`:''}</span>`).join('');
  return `<div class="achart" data-chart="${id}">${o.legend!==false?`<div class="achart-legend">${leg}</div>`:''}<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(o.title||'Chart')}">${g}${xl}${paths}<line class="cx" x1="0" x2="0" y1="${P.t}" y2="${H-P.b}"/>${dots}</svg><div class="achart-tip"></div></div>`}
function advBindCharts(root){$$('.achart:not([data-b])',root||document).forEach(el=>{el.dataset.b='1';const svg=$('svg',el);const tip=$('.achart-tip',el);
  const move=e=>{const c=ADV_CH[el.dataset.chart];if(!c||!c.n)return;const r=svg.getBoundingClientRect();if(!r.width)return;const x=(e.clientX-r.left)/r.width*c.W;
    const i=c.n<=1?0:Math.max(0,Math.min(c.n-1,Math.round((x-c.P.l)/((c.W-c.P.l-c.P.r)/(c.n-1)))));const cx=c.X(i);el.classList.add('hov');
    const ln=$('.cx',svg);ln.setAttribute('x1',cx);ln.setAttribute('x2',cx);
    $$('.hd',svg).forEach(d=>{const s=c.sets[+d.dataset.s];d.setAttribute('cx',cx);d.setAttribute('cy',c.Y(s.values[i]))});
    tip.innerHTML=`<b>${esc(c.tips?c.tips[i]:c.labels[i])}</b>`+c.sets.map(s=>`<div><i style="background:${s.color}"></i>${esc(s.name)}: <b>${esc((s.fmt||inr)(s.values[i]))}</b></div>`).join('')+(c.extra?c.extra(i):'');
    const px=cx/c.W*r.width;const tw=tip.offsetWidth;tip.style.left=Math.max(0,Math.min(el.clientWidth-tw,px+(px>el.clientWidth/2?-tw-14:14)))+'px'};
  el.addEventListener('pointermove',move);el.addEventListener('pointerdown',move);el.addEventListener('pointerleave',()=>el.classList.remove('hov'))})}

/* ---- numbers that count up when they change ---- */
const ADV_CU=new Map();
function advParseNum(s){const m=String(s).trim().match(/^([^\d-]*?)(-?[\d,]*\.?\d+)(\D*)$/);if(!m)return null;const raw=m[2];const v=parseFloat(raw.replace(/,/g,''));if(!isFinite(v))return null;
  return {pre:m[1],suf:m[3],v,dec:(raw.split('.')[1]||'').length,grp:raw.includes(',')}}
function advFmtNum(p,v){const t=p.grp?Math.abs(v).toLocaleString('en-IN',{minimumFractionDigits:p.dec,maximumFractionDigits:p.dec}):Math.abs(v).toFixed(p.dec);return p.pre+(v<0?'-':'')+t+p.suf}
function advCountUp(scope){if(advCalm())return;$$('.stat .v,.kpi .v,.adv-pc .v,.adv-tick .tv,.adv-eq .v',scope).forEach((el,i)=>{const lbl=(el.parentElement&&el.parentElement.querySelector('.l,.tl')||{}).textContent||'';const key=view+'|'+lbl+'|'+i;const txt=el.textContent;const p=advParseNum(txt);
  const prev=ADV_CU.get(key);ADV_CU.set(key,p?p.v:null);if(!p||prev===p.v)return;const from=prev==null?0:prev;if(Math.abs(p.v-from)<1e-9)return;
  const t0=performance.now(),dur=prev==null?900:650;const tick=now=>{if(!el.isConnected)return;const k=Math.min(1,(now-t0)/dur);const e=1-Math.pow(1-k,3);el.textContent=k>=1?txt:advFmtNum(p,from+(p.v-from)*e);if(k<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)})}

/* ---- motion: page transitions, shimmer while loading, celebration on save ---- */
let ADV_LASTV=null,ADV_VT=null;
function advSkeleton(){return `<div class="adv-skel" aria-busy="true"><div class="sk-row"><div class="sk"></div><div class="sk"></div><div class="sk"></div></div><div class="sk tall"></div><div class="sk-row"><div class="sk line"></div><div class="sk line"></div></div><div class="cap">Loading your data…</div></div>`}
function advAfterRender(changed){const root=$('#view');if(!root)return;
  const sp=$('#vbody .empty .spinner');if(sp&&/Loading your data/.test(sp.parentElement.textContent))sp.parentElement.outerHTML=advSkeleton();
  if(changed&&!advCalm()){root.classList.remove('vt');void root.offsetWidth;root.classList.add('vt');clearTimeout(ADV_VT);ADV_VT=setTimeout(()=>root.classList.remove('vt'),1700)}
  if(changed)[...ADV_CU.keys()].forEach(k=>{if(!k.startsWith(view+'|'))ADV_CU.delete(k)});
  advBindCharts(root);advCountUp(root)}
{const RV2=renderView;renderView=function(){const changed=ADV_LASTV!==view;ADV_LASTV=view;RV2.apply(this,arguments);try{advAfterRender(changed)}catch(e){console.error(e)}}}
function advBurst(title,sub){if(advCalm()){toast(title);return}const el=document.createElement('div');el.className='adv-burst';
  const parts=Array.from({length:18},(_,i)=>{const a=i/18*Math.PI*2+Math.random()*.3,d=90+Math.random()*80;return `<i style="--dx:${Math.round(Math.cos(a)*d)}px;--dy:${Math.round(Math.sin(a)*d)}px;animation-delay:${(.1+Math.random()*.12).toFixed(2)}s"></i>`}).join('');
  el.innerHTML=`<div class="bx">${parts}<svg class="ck" viewBox="0 0 76 76" aria-hidden="true"><circle cx="38" cy="38" r="36"/><path d="M22 39l11 11 21-23"/></svg><b>${esc(title)}</b>${sub?`<small>${esc(sub)}</small>`:''}</div>`;
  document.body.appendChild(el);setTimeout(()=>el.classList.add('out'),1250);setTimeout(()=>el.remove(),1700)}

/* =====================================================================
   PROFIT ENGINE — real profit on every sale / estimate / metal bill
   cost = what the piece cost us (purchase tunch + wastage at the purchase
   rate, purchase labour) + stone / hallmark charges passed on
   ===================================================================== */
let ADV_PF={key:'',map:null};
const ADV_BASIS={vault:'Vault piece (purchase bill)',card:'Supplier rate card',avg:'Average purchase',none:'No cost found — tunch only'};
function advPfKey(){const s=settings();return [FVER.invoices,FVER.products,RAW.invoices.length,RAW.products.length,(S.rateHistory||[]).length,activeFirm(),S.suppliers.length,sum(S.suppliers,x=>num(x.updatedAt)||num(x.createdAt)),num(s.gold24),num(s.silver999)].join('|')}
function advPfCtx(){const prod=new Map(S.products.map(p=>[p.id,p]));const pRate=new Map();const acc={};
  S.invoices.forEach(v=>{if(!isBuy(v.type)||v.type==='oldgold')return;(v.items||[]).forEach(it=>{if(it.productId&&num(it.rate)>0)pRate.set(it.productId,num(it.rate));
    const n=num(it.net);if(n>0){const k=it.category+'|'+it.purity;const a=acc[k]||(acc[k]={wn:0,ln:0,n:0});a.wn+=num(it.wastage)*n;a.ln+=num(it.labour)*n;a.n+=n}})});
  const avg={};Object.entries(acc).forEach(([k,a])=>{if(a.n>0)avg[k]={w:a.wn/a.n,l:a.ln/a.n}});
  return {prod,pRate,avg,cost:costIndex()}}
function advItemProfit(v,it,ctx,disc){const metal=metalOf(it.purity),net=num(it.net),mb=v.type==='metal';
  const rate=mb?advRateAt(v.date,metal):(num(it.rate)||advRateAt(v.date,metal));
  const revenue=mb?r2(num(it.fine)*rate+num(it.amount)):r2(num(it.amount)*disc);
  const p=it.productId?ctx.prod.get(it.productId):null;let tc=(PUR[it.purity]||{}).t||num(it.tunch),wc=0,lc=0,cr=rate,basis='none';
  if(p&&p.wastage!==''&&p.wastage!=null){wc=num(p.wastage);lc=num(p.labour);if(num(p.tunch))tc=num(p.tunch);if(ctx.pRate.get(p.id))cr=ctx.pRate.get(p.id);basis='vault'}
  else{const c=ctx.cost(it);if(c){wc=num(c.w);lc=c.l==null?0:num(c.l);basis='card'}else{const a=ctx.avg[it.category+'|'+it.purity];if(a){wc=a.w;lc=a.l;basis='avg'}}}
  const costFine=r3(net*(tc+wc)/100);const cost=r2(costFine*cr+net*lc+num(it.stone)+(mb?0:num(it.hm)));
  return {revenue,cost,profit:r2(revenue-cost),basis,net,costFine,saleFine:num(it.fine),category:it.category,purity:it.purity,making:it.making||'',sku:it.sku||''}}
function advProfits(){const k=advPfKey();if(ADV_PF.key===k&&ADV_PF.map)return ADV_PF.map;const ctx=advPfCtx();const m=new Map();
  S.invoices.forEach(v=>{if(!(isSaleT(v.type)||v.type==='metal'))return;const t=v.totals||{};const disc=num(t.itemsTotal)>0?Math.max(0,num(t.taxable))/num(t.itemsTotal):1;
    const lines=(v.items||[]).filter(it=>num(it.net)>0).map(it=>advItemProfit(v,it,ctx,disc));const rev=r2(sum(lines,l=>l.revenue)),cost=r2(sum(lines,l=>l.cost));
    m.set(v.id,{v,revenue:rev,cost,profit:r2(rev-cost),margin:rev?(rev-cost)/rev*100:0,lines,known:lines.filter(l=>l.basis!=='none').length})});
  ADV_PF={key:k,map:m};return m}
const advPf=v=>v?advProfits().get(v.id)||null:null;
function advProfitIn(a,b){const L=[];advProfits().forEach(x=>{if(inBook(x.v)&&inRange(x.v.date,a,b))L.push(x)});return L}

/* ---- day / month series for the dashboard ---- */
function advSeries(days){const t=todayStr();const keys=[];for(let i=days-1;i>=0;i--)keys.push(addDays(t,-i));return advSeriesFor(keys,d=>d)}
function advSeriesMonths(n){const keys=[];let m=shiftMonth(monthKey(todayStr()),-(n-1));for(let i=0;i<n;i++){keys.push(m);m=shiftMonth(m,1)}return advSeriesFor(keys,d=>monthKey(d))}
function advSeriesFor(keys,kf){const idx=new Map(keys.map((k,i)=>[k,i]));const z=()=>keys.map(()=>0);const o={keys,sales:z(),coll:z(),profit:z(),fine:z(),bills:z()};const PF=advProfits();
  S.invoices.forEach(v=>{const i=idx.get(kf(v.date||''));if(i!=null){if(isSaleT(v.type)){o.sales[i]+=num(v.totals&&v.totals.grand);o.bills[i]++}
      if(isSaleT(v.type)||v.type==='metal'){const p=PF.get(v.id);if(p)o.profit[i]+=p.profit;(v.items||[]).forEach(it=>{if(metalOf(it.purity)==='gold')o.fine[i]+=num(it.fine)})}}
    if(!isBuy(v.type))invPayments(v).forEach(p=>{if(NON_MONEY.has(p.mode))return;const j=idx.get(kf(p.date||v.date||''));if(j!=null)o.coll[j]+=num(p.amount)})});
  ['sales','coll','profit'].forEach(k=>o[k]=o[k].map(r2));o.fine=o.fine.map(r3);return o}

/* =====================================================================
   LIVE DASHBOARD — rate strip, pulse cards, action centre, trends
   ===================================================================== */
if(!ui.advTrend)ui.advTrend='30';
function advTicker(){const s=settings();const g=num(s.gold24),sv=num(s.silver999);const t=todayStr();const H=advRH();
  if(!g&&!sv)return `<div class="adv-tick" data-act="rates" role="button" aria-label="Set today's rates"><div class="ti"><div class="tl"><span class="live old"></span>Live rates</div><div class="tv">Set today's rates</div><div class="td">Tap to enter the gold & silver rate</div></div></div>`;
  const ref=s.ratesUpdated||t;const prevOf=k=>{for(let i=H.length-1;i>=0;i--){const r=H[i];if(r.date<ref&&num(r[k])>0)return {v:num(r[k]),d:r.date}}return null};
  const hist=k=>{const a=H.filter(r=>num(r[k])>0).slice(-30).map(r=>num(r[k]));if(!a.length||a[a.length-1]!==num(s[k]))a.push(num(s[k]));return a};
  const fresh=s.ratesUpdated===t;const at=s.ratesAt&&fresh?new Date(s.ratesAt).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}):'';
  const cell=(label,val,cls,k,mult,first)=>{const base=num(s[k]);if(!base)return '';const p=prevOf(k);const d=p?(base-p.v)/p.v*100:null;
    const sub=first?(fresh?`Live${at?' · '+at:''}`:`Rates of ${fmtD(s.ratesUpdated)} — tap to update`):(d==null?'—':`${advArrow(d)} ${advPctTxt(d)} vs ${fmtD(p.d).slice(0,5)}`);
    return `<div class="ti"><div class="tl">${first?`<span class="live ${fresh?'':'old'}"></span>`:''}${label}</div><div class="tv ${cls}">${val}</div><div class="td ${first?'':advSign(d)}">${esc(sub)}</div>${advSpark(hist(k).map(x=>x*mult),cls==='ag'?'var(--sky)':'var(--gold)',{dot:true})}</div>`};
  return `<div class="adv-tick" data-act="rates" role="button" aria-label="Today's rates — tap to update">${cell('Gold 24K · 10 g',inr(g),'au','gold24',1,true)}${cell('Gold 22K · 1 g',inr(g/10*0.916),'au','gold24',0.0916)}${cell('Gold 18K · 1 g',inr(g/10*0.75),'au','gold24',0.075)}${cell('Silver 999 · 1 kg',inr(sv),'ag','silver999',1)}${cell('Silver · 1 g',inr2(sv/1000),'ag','silver999',0.001)}</div>`}
function advPulse(){const t=todayStr();const d=advSeries(31);const n=d.keys.length-1;const mon=monthKey(t);const ms=advSeriesMonths(12);
  const today=d.sales[n],yday=d.sales[n-1];const dom=+t.slice(8,10);const pmA=shiftMonth(mon,-1)+'-01';const pmB=addDays(pmA,dom-1);
  const pm=r2(sum(S.invoices.filter(v=>isSaleT(v.type)&&inRange(v.date,pmA,pmB)&&monthKey(v.date)===shiftMonth(mon,-1)),v=>v.totals&&v.totals.grand));
  const cust=S.invoices.filter(v=>!isBuy(v.type));const recv=r2(sum(cust,v=>Math.max(0,invDue(v)))),od=r2(sum(cust.filter(invOverdue),invDue));
  const mp=advProfitIn(mon+'-01',t);const prof=r2(sum(mp,x=>x.profit)),rev=sum(mp,x=>x.revenue);const marg=rev?prof/rev*100:0;
  const monIdx=d.keys.map((k,i)=>monthKey(k)===mon?i:-1).filter(i=>i>=0);
  const card=(cls,l,v,s,sp,color,tip)=>`<div class="adv-pc ${cls}"${tip?` data-tip="${esc(tip)}"`:''}><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div>${advSpark(sp,color)}</div>`;
  const dlt=advPct(today,yday);
  return `<div class="adv-pulse">
   ${card('',"Today's sales",inr(today),`${d.bills[n]} bill${d.bills[n]===1?'':'s'} · <span class="${advSign(today-yday)}">${advArrow(today-yday)} ${yday||today?advPctTxt(dlt):'—'}</span> vs yesterday`,d.sales.slice(-14),'var(--gold)','Sales (GST + estimate bills) — last 14 days')}
   ${card('','Sales this month',inr(ms.sales[11]),`<span class="${advSign(ms.sales[11]-pm)}">${advArrow(ms.sales[11]-pm)} ${pm||ms.sales[11]?advPctTxt(advPct(ms.sales[11],pm)):'—'}</span> vs same days last month`,ms.sales,'var(--gold)','Monthly sales — last 12 months')}
   ${card('sky','Collected today',inr(d.coll[n]),`Due ${compactInr(recv)}${od>0.5?` · <span class="adv-dn">${compactInr(od)} late</span>`:''}`,d.coll.slice(-14),'var(--sky)','Money received from customers — last 14 days')}
   ${card(prof<0?'red':'green','Profit this month',inr(prof),`margin ${marg.toFixed(1)}% · on ${mp.length} bill${mp.length===1?'':'s'}`,monIdx.map(i=>d.profit[i]),prof<0?'var(--red)':'var(--green)','Profit = sale value (without GST) − cost of the pieces. Reports → Profit for every bill.')}
   ${card('','Fine gold sold · month',g3(ms.fine[11]),`today ${g3(d.fine[n])}`,d.fine.slice(-14),'var(--gold)','Fine gold sold (sale, estimate & metal bills) — last 14 days')}
  </div>`}
const ACX_G=[['money','Money to collect','var(--red)',['remind','collect']],['comp','Compliance & daily','var(--sky)',['gst','closing','rates','backup','health']],['cust','Customers','var(--green)',['scheme','lead','occasion','reengage','growth','booking','repair']],['stock','Stock & work','var(--gold)',['restock','drafts','order','job','hallmark','approval']],['target','Targets','var(--c2)',['target']]];
function advActionCentre(){let tasks=[];try{tasks=dailyTasks()}catch(e){console.error(e)}const done=tasksDone();const isDone=x=>x.auto||done.has(x.id);
  const total=tasks.length,dn=tasks.filter(isDone).length;const pct=total?dn/total:1;const R=24,C=2*Math.PI*R;
  const known=new Set(ACX_G.flatMap(g=>g[3]));const groups=ACX_G.map(g=>({g,list:tasks.filter(x=>g[3].includes(x.kind))}));const other=tasks.filter(x=>!known.has(x.kind));if(other.length)groups.push({g:['other','Other','var(--muted)',[]],list:other});
  const t=todayStr();const cust=S.invoices.filter(v=>!isBuy(v.type));const overdue=r2(sum(cust.filter(invOverdue),invDue));const dueToday=r2(sum(cust.filter(v=>invDue(v)>0.5&&invDueDate(v)===t),invDue));
  const rem=tasks.filter(x=>x.kind==='remind'&&x.wa&&!isDone(x));
  const ring=`<svg class="acx-ring" viewBox="0 0 56 56" aria-label="${Math.round(pct*100)}% done"><circle cx="28" cy="28" r="${R}" style="stroke:var(--track)"/><circle cx="28" cy="28" r="${R}" style="stroke:var(--gold);stroke-dasharray:${(pct*C).toFixed(1)} ${C.toFixed(1)};transform:rotate(-90deg);transform-origin:28px 28px" stroke-linecap="round"/><text x="28" y="33" text-anchor="middle">${Math.round(pct*100)}%</text></svg>`;
  const body=groups.filter(x=>x.list.length).map(({g,list})=>`<div class="acx-g"><div class="acx-gh"><span class="d" style="background:${g[2]}"></span>${esc(g[1])}<span class="n">${list.filter(x=>!isDone(x)).length} open</span></div>${tasksHTML(list)}</div>`).join('');
  return `<div class="card acx"><div class="acx-h">${ring}<div><h3>Action centre</h3><div class="small muted">${esc(parseD(t).toLocaleDateString('en-IN',{weekday:'long',day:'numeric',month:'long'}))} · ${total-dn} to do · ${dn} done</div></div>
   <div class="acx-sum"><div class="acx-k"><span>Overdue</span><b class="${overdue>0.5?'red':''}">${inr(overdue)}</b></div><div class="acx-k"><span>Due today</span><b>${inr(dueToday)}</b></div>${rem.length?`<button type="button" class="btn sm green" data-act="acx-queue">${ic('send',14)} Send ${rem.length} reminder${rem.length>1?'s':''}</button>`:''}</div></div>
   ${body?`<div class="acx-grid">${body}</div>`:`<div class="acx-empty">✓ All clear for today — nothing pending.</div>`}</div>`}
function advReminderQueue(){const done=tasksDone();const L=dailyTasks().filter(x=>x.kind==='remind'&&x.wa&&!done.has(x.id));if(!L.length)return toast('No reminders pending');
  const el=openModal(`${mHead('Send payment reminders',`${L.length} customer${L.length>1?'s':''} · WhatsApp opens with the message ready — press send there`)}<div class="m-body acx-q"><div class="tcard">${L.map(x=>`<div class="row static"><div style="min-width:0;flex:1"><b>${esc(x.text)}</b><div class="small muted">${esc(x.sub||'')}</div></div><a class="btn sm green" href="${esc(x.wa)}" target="_blank" rel="noopener" data-act="remind" data-id="${esc(x.cid)}">WhatsApp</a></div>`).join('')}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Done</button><button type="button" class="btn primary" data-act="acx-next">Open next ›</button></div>`,{wide:true});el.classList.add('acx-qov')}
function advTrendCard(){const span=String(ui.advTrend||'30');let d,labels,tips;const WD=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  if(span==='365'){d=advSeriesMonths(12);labels=d.keys.map(k=>monthLabel(k).split(' ')[0]);tips=d.keys.map(monthLabel)}
  else{d=advSeries(+span||30);labels=d.keys.map(k=>k.slice(8,10)+'/'+k.slice(5,7));tips=d.keys.map(k=>`${WD[parseD(k).getDay()]}, ${fmtD(k)}`)}
  const T=k=>compactInr(sum(d[k]));
  const chart=advLine({title:'Sales, profit and collections',labels,tips,sets:[{name:'Sales',color:'var(--gold)',values:d.sales,total:T('sales')},{name:'Profit',color:'var(--green)',values:d.profit,total:T('profit')},{name:'Collections',color:'var(--sky)',values:d.coll,total:T('coll'),dash:true}],extra:i=>`<div class="small muted">${d.bills[i]} bill${d.bills[i]===1?'':'s'}${d.fine[i]?' · '+g3(d.fine[i])+' fine gold':''}</div>`});
  return `<div class="card adv-trend"><div class="card-h"><h3>Business trends</h3>${seg('advTrend',[['30','30 days'],['90','90 days'],['365','12 months']])}</div>${chart}${advHeat()}</div>`}
function advHeat(){const weeks=innerWidth>=1024?52:innerWidth>=700?30:17;const t=todayStr();const dow=(parseD(t).getDay()+6)%7;const start=addDays(t,-(weeks-1)*7-dow);const days=daysBetween(start,t)+1;
  const val={};S.invoices.forEach(v=>{if(isSaleT(v.type)&&v.date>=start&&v.date<=t)val[v.date]=(val[v.date]||0)+num(v.totals&&v.totals.grand)});
  const vs=Object.values(val).filter(x=>x>0).sort((a,b)=>a-b);const q=p=>vs.length?vs[Math.min(vs.length-1,Math.floor(p*vs.length))]:0;const th=[q(.25),q(.5),q(.75)];
  const lvl=x=>!x?0:x<=th[0]?1:x<=th[1]?2:x<=th[2]?3:4;const op=[1,.28,.5,.75,1];const C=13,G=3,L=24,T=16;const W=L+weeks*(C+G),H=T+7*(C+G);let rects='',months='',lastM='';
  for(let i=0;i<days;i++){const d=addDays(start,i);const w=Math.floor(i/7),r=i%7;const x=L+w*(C+G),y=T+r*(C+G);const v=val[d]||0;const l=lvl(v);
    rects+=`<rect class="c" x="${x}" y="${y}" width="${C}" height="${C}" rx="3" style="fill:${l?'var(--gold)':'var(--track)'};fill-opacity:${op[l]}" data-act="adv-day" data-d="${d}" data-tip="${esc(WD3(d)+' '+fmtD(d)+'\n'+(v?inr(v)+' sales':'No sales'))}"/>`;
    if(r===0&&d.slice(0,7)!==lastM){lastM=d.slice(0,7);if(w<weeks-1)months+=`<text x="${x}" y="10">${esc(monthLabel(lastM).slice(0,3))}</text>`}}
  const dl=['Mon','','Wed','','Fri','',''].map((l,r)=>l?`<text x="0" y="${T+r*(C+G)+10}">${l}</text>`:'').join('');
  return `<div class="adv-heat"><div class="sublabel">Sales calendar · last ${weeks} weeks — tap a day to see its bills</div><svg viewBox="0 0 ${W} ${H}" style="max-width:${Math.round(W*1.35)}px" aria-label="Sales calendar">${months}${dl}${rects}</svg><div class="adv-heat-k">Less <i style="background:var(--track)"></i>${[1,2,3,4].map(l=>`<i style="background:var(--gold);opacity:${op[l]}"></i>`).join('')} More</div></div>`}
const WD3=d=>['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][parseD(d).getDay()];
function advRingCard(){const t=todayStr();const mon=monthKey(t);const a=mon+'-01';const inv=S.invoices.filter(v=>isSaleT(v.type)&&inRange(v.date,a,t));
  const pk=r2(sum(inv.filter(v=>bookOf(v)==='pakka'),v=>v.totals&&v.totals.grand)),kc=r2(sum(inv.filter(v=>bookOf(v)!=='pakka'),v=>v.totals&&v.totals.grand));const tot=pk+kc;const R=46,C=2*Math.PI*R;const pp=tot?pk/tot:0,kp=tot?kc/tot:0;
  const arc=(f,off,col)=>f>0?`<circle class="arc" cx="60" cy="60" r="${R}" style="stroke:${col};stroke-dasharray:${(f*C).toFixed(2)} ${C.toFixed(2)};stroke-dashoffset:${(-off*C).toFixed(2)}"/>`:'';
  let top='';try{const g=groupLines(saleLines(a,t),'catpur').sort((x,y)=>y.amount-x.amount).slice(0,5);const mx=Math.max(1,...g.map(x=>x.amount));top=g.map(x=>`<div class="adv-bar"><span>${esc(x.key)}</span><span class="t"><i style="width:${(x.amount/mx*100).toFixed(1)}%"></i></span><b>${compactInr(x.amount)}</b></div>`).join('')}catch(e){}
  return `<div class="card"><div class="card-h"><h3>Pakka vs Kacha · ${esc(monthLabel(mon))}</h3><button class="link" data-act="go-rep" data-v="overview">Reports →</button></div>
   <div class="adv-ring"><svg viewBox="0 0 120 120" aria-label="Pakka ${Math.round(pp*100)}%, Kacha ${Math.round(kp*100)}%"><circle cx="60" cy="60" r="${R}" style="fill:none;stroke:var(--track);stroke-width:15"/>${arc(pp,0,'var(--gold)')}${arc(kp,pp,'var(--sky)')}<text class="ctr" x="60" y="58" style="fill:var(--head);font-size:15px;font-weight:800">${esc(compactInr(tot))}</text><text class="ctr" x="60" y="74" style="fill:var(--muted);font-size:9px">sales this month</text></svg>
   <div class="lg"><div><i style="background:var(--gold)"></i>Pakka (GST)<b>${inr(pk)}</b></div><div><i style="background:var(--sky)"></i>Kacha (estimate)<b>${inr(kc)}</b></div><div class="small muted">${tot?Math.round(pp*100)+'% Pakka · '+Math.round(kp*100)+'% Kacha':'No sales yet this month'}</div></div></div>
   ${top?`<div class="sublabel" style="margin-top:14px">Top items this month</div>${top}`:''}</div>`}
{const D1=VIEWDEF.dashboard;VIEWDEF.dashboard={...D1,body(){let h=D1.body();try{
    const re=/<div class="two">\s*<div class="card"><div class="card-h"><h3>Today's tasks<\/h3>[\s\S]*?<\/div>\s*(?=<div class="card"><div class="card-h"><h3>Targets<\/h3>)/;
    if(re.test(h))h=h.replace(re,'<div class="two">'+advRingCard());else h+=advRingCard();
    const kp='<div class="kpis" style="margin-top:14px">';const tr=advTrendCard();h=h.includes(kp)?h.replace(kp,tr+kp):h+tr;
    return advTicker()+advPulse()+advActionCentre()+h}catch(e){console.error(e);return h}}}}

/* =====================================================================
   SMART BILL AUTO-FILL — remembers each party's last wastage, labour,
   making and margin for every Category + Purity, and their usual items
   ===================================================================== */
let ADV_HI={key:'',map:null};
const advGrp=t=>isBuy(t)?'buy':t==='metal'?'metal':'sale';
function advHist(){const key=[FVER.invoices,RAW.invoices.length,activeFirm()].join('|');if(ADV_HI.key===key&&ADV_HI.map)return ADV_HI.map;const m=new Map();
  S.invoices.slice().sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||num(a.createdAt)-num(b.createdAt)).forEach(v=>{if(!v.partyId)return;(v.items||[]).forEach(it=>{if(!it.category||!it.purity)return;
    const k=advGrp(v.type)+'|'+v.partyId+'|'+it.category+'|'+it.purity;const p=m.get(k);m.set(k,{wastage:it.wastage,labour:it.labour,margin:it.margin,making:it.making||'',date:v.date,no:v.no,count:(p?p.count:0)+1,cat:it.category,pur:it.purity})})});
  ADV_HI={key,map:m};return m}
function advHistFor(st,it){if(!st||!st.partyId||!it.category||!it.purity)return null;return advHist().get(advGrp(st.type)+'|'+st.partyId+'|'+it.category+'|'+it.purity)||null}
function advUsual(st){if(!st||!st.partyId)return [];const pre=advGrp(st.type)+'|'+st.partyId+'|';const L=[];advHist().forEach((h,k)=>{if(k.startsWith(pre))L.push(h)});return L.sort((a,b)=>b.count-a.count||String(b.date).localeCompare(String(a.date))).slice(0,6)}
{const AA=applyAuto;applyAuto=function(it,st){st=st||INV;const h=st&&!st.orig?advHistFor(st,it):null;
  if(st&&!st.orig&&!it.mkManual&&(!it.making||it.mkAuto)){const mk=(h&&h.making)||'';it.making=mk;it.mkAuto=!!mk}
  AA.call(this,it,st);it.wHist=false;
  if(h){if(!it.wManual&&!it.wAuto&&h.wastage!==''&&h.wastage!=null){it.wastage=num(h.wastage);it.wAuto=true;it.wHist=true}
    if(!it.lManual&&!it.lAuto&&num(h.labour)){it.labour=num(h.labour);it.lAuto=true}
    if(st&&isSaleT(st.type)&&!it.mManual&&!it.mAuto&&h.margin!==''&&h.margin!=null&&num(h.margin)){it.margin=num(h.margin);it.mAuto=true}}
  return it}}
{const WT=wTag;wTag=function(it,st){if(it&&it.wHist&&!it.wManual)return ['last bill','hist'];return WT.apply(this,arguments)}}
{const OII=onItemInput;onItemInput=function(t){const card=t.closest('.item');const it=card&&INV?INV.items[+card.dataset.idx]:null;if(it&&t.dataset.f==='making')it.mkManual=true;
  OII.apply(this,arguments);if(it&&['category','purity'].includes(t.dataset.f)){const mk=card.querySelector('[data-f="making"]');if(mk&&mk!==document.activeElement&&mk.value!==(it.making||''))mk.value=it.making||''}}}
{const RIP=renderInvParty;renderInvParty=function(){RIP.apply(this,arguments);try{if(!INV||INV.orig||!INV.partyId)return;const U=advUsual(INV);if(!U.length)return;const box=$('#inv-party',INV.el);if(!box)return;
  box.insertAdjacentHTML('beforeend',`<div class="adv-usual"><span class="small muted">${INV_TYPES[INV.type].party==='supplier'?'Usually supplies':'Usually buys'}:</span>${U.map(h=>`<button type="button" class="chip" data-act="adv-usual" data-c="${esc(h.cat)}" data-p="${esc(h.pur)}" data-m="${esc(h.making||'')}" title="Last on ${esc(h.no)} (${esc(fmtD(h.date))})${h.wastage!==''&&h.wastage!=null?' · wastage '+esc(h.wastage)+'%':''}">${esc(h.cat)} ${esc(h.pur)}${h.making?' · '+esc(h.making):''} <b>×${h.count}</b></button>`).join('')}</div>`)}catch(e){console.error(e)}}}
function advUseUsual(t){if(!INV)return;const it0=INV.items.findIndex(x=>!x.productId&&!x.category&&!num(x.gross));const it=it0>=0?INV.items[it0]:newItem();if(it0<0)INV.items.push(it);
  it.category=t.dataset.c;it.purity=t.dataset.p;it.making=t.dataset.m||'';applyAuto(it);renderItems();refreshTotals();
  const i=INV.items.indexOf(it);const g=$(`.item[data-idx="${i}"] [data-f="gross"]`,INV.el);if(g){g.focus();g.scrollIntoView({block:'center',behavior:advCalm()?'auto':'smooth'})}toast(`${it.category} ${it.purity} added — enter the weight`)}

/* =====================================================================
   SPLIT PAYMENT while making the bill (Cash + UPI + Card + Bank + Cheque)
   ===================================================================== */
const ADV_SPLIT=['Cash','UPI','Card','Bank Transfer','Cheque'];
function advSplitBox(sh){const rec=$('[data-inv="received"]',sh);if(!rec||INV.orig||$('.adv-split-wrap',sh))return;const fg=rec.closest('.fg');if(!fg)return;const B=banksList();
  fg.insertAdjacentHTML('afterend',`<div class="adv-split-wrap"><button type="button" class="link" data-act="split-toggle">⇄ Split payment — Cash + UPI + Card…</button><div class="adv-split" hidden><div class="fg">${ADV_SPLIT.map(m=>`<label class="f"><span>${esc(m)} ₹</span><input type="number" step="any" min="0" inputmode="decimal" data-split="${esc(m)}" placeholder="0"></label>`).join('')}${B.length>1?`<label class="f"><span>UPI / card / bank into</span><select data-split-bank>${B.map(b=>`<option value="${esc(b.id)}"${b.id===primaryBankId()?' selected':''}>${esc(bankName(b.id))}</option>`).join('')}</select></label>`:''}</div><div class="tot"><span>Total received</span><b data-o="split-tot">₹0</b></div></div></div>`)}
function advSplitSync(){if(!INV||!INV.el)return;const box=$('.adv-split',INV.el);if(!box)return;const sp={};let tot=0;$$('[data-split]',box).forEach(i=>{const v=num(i.value);if(v>0){sp[i.dataset.split]=r2(v);tot+=v}});
  INV.splits=sp;const bs=$('[data-split-bank]',box);INV.splitBank=bs?bs.value:'';INV.received=tot?String(r2(tot)):'';const rec=$('[data-inv="received"]',INV.el);if(rec)rec.value=INV.received;$('[data-o="split-tot"]',box).textContent=inr2(tot);refreshTotals()}
function advSplitToggle(){if(!INV||!INV.el)return;const box=$('.adv-split',INV.el);if(!box)return;const on=box.hidden;box.hidden=!on;const rec=$('[data-inv="received"]',INV.el),mode=$('[data-inv="payMode"]',INV.el);
  if(on){const cur=num(INV.received);if(cur>0){const f=$(`[data-split="${CSS.escape(INV.payMode||'Cash')}"]`,box)||$('[data-split="Cash"]',box);if(f)f.value=cur}if(rec)rec.readOnly=true;if(mode)mode.disabled=true;advSplitSync();const f=$('[data-split]',box);if(f)f.focus()}
  else{INV.splits=null;$$('[data-split]',box).forEach(i=>i.value='');if(rec){rec.readOnly=false;rec.value='';}INV.received='';if(mode)mode.disabled=false;refreshTotals()}
  $('[data-act="split-toggle"]',INV.el).textContent=on?'× Use a single payment mode':'⇄ Split payment — Cash + UPI + Card…'}
{const PI=persistInvoice;persistInvoice=async function(st){const sp=st&&st.splits&&!st.orig?Object.entries(st.splits).filter(([,a])=>num(a)>0):[];if(!sp.length)return PI.apply(this,arguments);
  const r=await PI.call(this,{...st,received:''});if(!r||!r.inv)return r;
  const pays=sp.map(([m,a])=>({id:uid('pay'),date:st.date,amount:r2(num(a)),fine:0,mode:m,bankId:m==='Cash'?'':(st.splitBank||primaryBankId()),note:'At billing · split'}));
  const fp=(r.inv.payments||[]);const inv={...r.inv,payments:[...fp,...pays],updatedAt:Date.now()};if(await save('invoices',inv))return {inv};return r}}

/* =====================================================================
   BILL ERROR GUARD — checks a bill before it is saved
   ===================================================================== */
function advGuard(st){const W=[];const type=st.type;const party=partyFor(type,st.partyId);if(!party)return W;const t=invTotals(st,party);const sale=isSaleT(type),buy=isBuy(type);const today=todayStr();
  const items=(st.items||[]).filter(it=>calcItem(it,type).net>0);const nm=(it,i)=>`Item ${st.items.indexOf(it)+1} (${it.category||'?'} ${it.purity||''})`;let ctx=null;
  items.forEach((it,i)=>{const c=calcItem(it,type);const m=metalOf(it.purity);const r=rateFor(m);
    if(num(it.less)>0&&num(it.less)>=num(it.gross))W.push(['stop',`${nm(it)}: less / stone weight is equal to or more than the gross weight.`]);
    if(type!=='metal'&&r>0&&num(it.rate)>0){const d=(num(it.rate)-r)/r*100;if(sale&&d<-2)W.push(['warn',`${nm(it)}: rate ${inr2(it.rate)}/g is <b>${Math.abs(d).toFixed(1)}% below</b> today's ${inr2(r)}/g.`]);if(buy&&type!=='oldgold'&&d>2)W.push(['warn',`${nm(it)}: purchase rate ${inr2(it.rate)}/g is <b>${d.toFixed(1)}% above</b> today's ${inr2(r)}/g.`])}
    if(sale&&(num(it.wastage)<0||num(it.labour)<0||num(it.margin)<0))W.push(['stop',`${nm(it)}: negative ${[num(it.wastage)<0&&'wastage',num(it.labour)<0&&'labour',num(it.margin)<0&&'margin'].filter(Boolean).join(' / ')} — making charge comes out negative.`]);
    if(sale){try{ctx=ctx||advPfCtx();const disc=num(t.itemsTotal)>0?num(t.taxable)/num(t.itemsTotal):1;const x=advItemProfit({type,date:st.date},{...it,net:c.net,fine:c.fine,amount:c.amount},ctx,disc);if(x.basis!=='none'&&x.profit<-1)W.push(['warn',`${nm(it)} is being sold <b>below cost</b> — loss of about ${inr(-x.profit)} (cost from ${ADV_BASIS[x.basis].toLowerCase()}).`])}catch(e){}}
    if(type==='sale'&&m==='gold'&&!/coin|biscuit/i.test(it.category||'')&&c.net>=2&&!String(it.huid||'').trim())W.push(['warn',`${nm(it)}: no HUID — hallmarked HUID is required on gold jewellery sold (2 g and above).`])});
  const dup=S.invoices.find(v=>v.id!==(st.orig&&st.orig.id)&&v.type===type&&v.partyId===st.partyId&&v.date===st.date&&Math.abs(num(v.totals&&v.totals.grand)-num(t.grand))<=1);
  if(dup)W.push(['warn',`Possible <b>duplicate</b>: bill ${esc(dup.no)} for ${esc(party.name)} on the same date has the same total ${inr(t.grand)}.`]);
  if(!st.orig){const cash=st.splits?num(st.splits.Cash):(st.payMode==='Cash'?num(st.received):0);
    if(!buy&&cash>=200000)W.push(['stop',`Cash ${inr(cash)} received — taking ₹2 lakh or more in cash for one bill is not allowed (Income-tax section 269ST). Take the extra by bank / UPI.`]);
    if(num(st.received)>num(t.payable)+1)W.push(['warn',`Amount received ${inr(st.received)} is more than the bill ${inr(t.payable)}.`])}
  if(sale&&num(t.grand)>=200000&&!String(party.pan||'').trim()&&!String(party.gstin||'').trim())W.push(['warn',`Bill of ${inr(t.grand)} — customer's <b>PAN</b> is needed for sales of ₹2 lakh or more (Rule 114B). Add it in the customer's details.`]);
  if(!buy&&num(party.creditLimit)>0){const out=partyDue(party.id,'customer')-(st.orig?invDue(st.orig):0)+num(t.payable)-num(st.received);if(out>num(party.creditLimit))W.push(['warn',`Credit limit crossed: outstanding becomes ${inr(out)} against the limit ${inr(party.creditLimit)}.`])}
  if(st.date>today)W.push(['warn',`Bill date ${fmtD(st.date)} is in the future.`]);else if(!st.orig&&daysBetween(st.date,today)>30)W.push(['warn',`Bill date ${fmtD(st.date)} is more than 30 days old.`]);
  if(!buy&&type!=='metal'&&num(t.payable)<=0)W.push(['stop',`Net payable is ${inr(t.payable)} — check the old gold value and discount.`]);
  return W}
function advGuardModal(W){const stop=W.filter(w=>w[0]==='stop').length;const el=openModal(`${mHead('Please check this bill',`${W.length} thing${W.length>1?'s':''} looked unusual${stop?' — '+stop+' need attention':''}`)}<div class="m-body"><div class="adv-guard">${W.map(([k,m])=>`<div class="${k==='stop'?'':'w'}"><span class="ico">${k==='stop'?'⛔':'⚠️'}</span><span>${m}</span></div>`).join('')}</div></div><div class="m-foot"><button type="button" class="btn" data-act="guard-save">Save anyway</button><button type="button" class="btn primary" data-act="close">Go back &amp; fix</button></div>`,{small:true});el.classList.add('guard-ov');setTimeout(()=>{const b=$('.m-foot .btn.primary',el);if(b)b.focus()},30)}
{const SIB=saveInvoiceFromBuilder;saveInvoiceFromBuilder=async function(btn){if(INV&&!INV._guardOk){let W=[];try{W=advGuard(INV)}catch(e){console.error(e)}if(W.length){advGuardModal(W);return}}
  const before=INV;const wasEdit=!!(INV&&INV.orig);const type=INV&&INV.type;await SIB.apply(this,arguments);
  if(before&&INV!==before){const v=S.invoices.slice().sort((a,b)=>num(b.updatedAt)-num(a.updatedAt))[0];advBurst(wasEdit?'Bill updated':'Bill saved',v?`${(INV_TYPES[type]||{}).short||''} ${v.no}${v.type==='metal'?'':' · '+inr(invPayable(v))}`:'')}else if(INV)INV._guardOk=false}}

/* =====================================================================
   PROFIT on the open bill (owner's eyes only — not printed)
   ===================================================================== */
function advProfitPanel(v){const P=advPf(v);if(!P||!P.lines.length)return '';const cls=P.profit<0?'adv-neg':'adv-pos';
  const rows=P.lines.map(l=>`<tr>${td(esc(l.category+' '+l.purity)+(l.sku?' <span class="small muted mono">#'+esc(l.sku)+'</span>':''))}${td(inr(l.revenue),1)}${td(inr(l.cost),1)}${td(`<b class="${l.profit<0?'adv-neg':'adv-pos'}">${inr(l.profit)}</b>`,1)}${td(l.revenue?((l.profit/l.revenue)*100).toFixed(1)+'%':'—',1)}${td(`<span class="pill basis ${l.basis==='none'?'red':l.basis==='vault'?'green':''}">${esc(ADV_BASIS[l.basis])}</span>`)}</tr>`);
  return `<details class="sec adv-prof"${isPC()?' open':''}><summary><h4>Profit on this bill</h4><span class="big ${cls}">${inr(P.profit)}</span><span class="pill ${P.profit<0?'red':'green'}">${P.margin.toFixed(1)}% margin</span><span class="small muted">sale ${inr(P.revenue)} (without GST) − cost ${inr(P.cost)} · only you see this, it is not printed</span></summary>
   ${btable([['Item'],['Sale ₹','r'],['Cost ₹','r'],['Profit ₹','r'],['Margin','r'],['Cost from']],rows,{cls:'fit'})}${P.known<P.lines.length?`<p class="small muted" style="margin:8px 0 0">${P.lines.length-P.known} item${P.lines.length-P.known>1?'s have':' has'} no purchase cost on record — counted at tunch only (no wastage / labour paid). Add pieces through purchase bills or fill the supplier rate card for exact profit.</p>`:''}</details>`}
{const OIV5=openInvoiceView;openInvoiceView=function(id){const r=OIV5.apply(this,arguments);try{const v=S.invoices.find(x=>x.id===id);const el=$('#modal-root').lastElementChild;
  if(v&&el&&el._invId===id&&(isSaleT(v.type)||v.type==='metal')&&!$('.adv-prof',el)){const doc=$('.inv-doc',el);const h=advProfitPanel(v);if(doc&&h)doc.insertAdjacentHTML('afterend',h)}}catch(e){console.error(e)}return r}}

/* ---- bill maker hooks ---- */
{const OI3=openInvoice;openInvoice=function(){const before=INV&&INV.el;const r=OI3.apply(this,arguments);try{if(INV&&INV.el&&INV.el!==before&&INV.el.isConnected){INV.splits=null;INV._guardOk=false;advSplitBox(INV.el.firstElementChild)}}catch(e){console.error(e)}return r}}

/* =====================================================================
   REPORTS → PROFIT
   ===================================================================== */
REP_TABS.splice(Math.max(0,REP_TABS.findIndex(x=>x[0]==='wastage')),0,['profit','Profit']);
function advProfitData(){const r=rpRange();const L=advProfitIn(r.a,r.b).sort((x,y)=>String(y.v.date).localeCompare(String(x.v.date))||String(y.v.no).localeCompare(String(x.v.no)));const P=r.pa?advProfitIn(r.pa,r.pb):[];
  const tot=A=>({rev:r2(sum(A,x=>x.revenue)),cost:r2(sum(A,x=>x.cost)),profit:r2(sum(A,x=>x.profit)),bills:A.length,loss:A.filter(x=>x.profit<-0.5).length});
  const exp=a=>(b=>r2(sum(S.expenses.filter(e=>inRange(e.date,a,b)),e=>e.amount)));
  return {r,L,c:tot(L),p:tot(P),expC:exp(r.a)(r.b),expP:r.pa?exp(r.pa)(r.pb):0}}
function advProfitReport(){const {r,L,c,p,expC,expP}=advProfitData();if(!S.invoices.some(v=>isSaleT(v.type)||v.type==='metal'))return emptyBox('No sale bills yet — profit appears here as soon as you bill.');
  const marg=x=>x.rev?x.profit/x.rev*100:0;const net=c.profit-expC,netP=p.profit-expP;
  const ch=(cur,prev)=>{const x=change(cur,prev);return r.pa?`<span class="${x.dir>0?'adv-up':x.dir<0?'adv-dn':''}">${x.dir>0?'▲':x.dir<0?'▼':''} ${esc(x.txt)}</span> vs before`:''};
  const k=(l,v,s,tip)=>`<div class="kpi"${tip?` data-tip="${esc(tip)}"`:''}><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s}</div></div>`;
  const kp=`<div class="kpis adv-k7">${k('Gross profit',inr(c.profit),ch(c.profit,p.profit),'Sale value without GST minus the cost of the pieces sold')}${k('Margin',marg(c).toFixed(1)+'%',r.pa&&p.rev?`was ${marg(p).toFixed(1)}%`:'')}${k('Sales (without GST)',inr(c.rev),ch(c.rev,p.rev))}${k('Cost of pieces sold',inr(c.cost),`${c.bills} bills`)}${k('Profit per bill',inr(c.bills?c.profit/c.bills:0),`${c.loss} loss bill${c.loss===1?'':'s'}`)}${k('Expenses',inr(expC),ch(expC,expP))}${k('Net profit',inr(net),ch(net,netP),'Gross profit minus shop expenses in this period')}</div>`;
  // trend
  const days=daysBetween(r.a,r.b)+1;const byDay=days<=100&&r.preset!=='all';const keys=[];if(byDay){for(let i=0;i<days;i++)keys.push(addDays(r.a,i))}else{let m=monthKey(r.a==='2000-01-01'&&L.length?L[L.length-1].v.date:r.a);const e=monthKey(r.b);let g=0;while(m<=e&&g++<120){keys.push(m);m=shiftMonth(m,1)}}
  const ix=new Map(keys.map((x,i)=>[x,i]));const sv=keys.map(()=>0),pv=keys.map(()=>0);L.forEach(x=>{const i=ix.get(byDay?x.v.date:monthKey(x.v.date));if(i!=null){sv[i]+=x.revenue;pv[i]+=x.profit}});
  const chart=keys.length>1?`<div class="card">${advLine({title:'Sales and profit',labels:keys.map(x=>byDay?x.slice(8,10)+'/'+x.slice(5,7):monthLabel(x).split(' ')[0]),tips:keys.map(x=>byDay?WD3(x)+', '+fmtD(x):monthLabel(x)),sets:[{name:'Sales (without GST)',color:'var(--gold)',values:sv.map(r2),total:compactInr(c.rev)},{name:'Profit',color:'var(--green)',values:pv.map(r2),total:compactInr(c.profit)}],extra:i=>`<div class="small muted">margin ${sv[i]?(pv[i]/sv[i]*100).toFixed(1):'0'}%</div>`})}</div>`:'';
  // by item
  const G=new Map();L.forEach(x=>x.lines.forEach(l=>{const key=l.category+' '+l.purity;const a=G.get(key)||{key,pcs:0,net:0,rev:0,cost:0,profit:0};a.net+=l.net;a.rev+=l.revenue;a.cost+=l.cost;a.profit+=l.profit;a.pcs++;G.set(key,a)}));
  const gr=[...G.values()].sort((a,b)=>b.profit-a.profit);
  const itemT=btable([['Item'],['Lines','r'],['Net g','r'],['Sale ₹','r'],['Cost ₹','r'],['Profit ₹','r'],['Margin','r']],gr.slice(0,40).map(a=>`<tr>${td('<b>'+esc(a.key)+'</b>')}${td(a.pcs,1)}${td(g3(a.net),1)}${td(inr(a.rev),1)}${td(inr(a.cost),1)}${td(`<b class="${a.profit<0?'adv-neg':'adv-pos'}">${inr(a.profit)}</b>`,1)}${td(a.rev?(a.profit/a.rev*100).toFixed(1)+'%':'—',1)}</tr>`),{empty:'No sales in this period.',cls:'fit'});
  // by party
  const PG=new Map();L.forEach(x=>{const a=PG.get(x.v.partyId)||{name:x.v.partyName,bills:0,rev:0,profit:0};a.bills++;a.rev+=x.revenue;a.profit+=x.profit;PG.set(x.v.partyId,a)});
  const pr=[...PG.values()].sort((a,b)=>b.profit-a.profit).slice(0,15);
  const partyT=btable([['Customer'],['Bills','r'],['Sale ₹','r'],['Profit ₹','r'],['Margin','r']],pr.map(a=>`<tr>${td('<b>'+esc(a.name)+'</b>')}${td(a.bills,1)}${td(inr(a.rev),1)}${td(`<b class="${a.profit<0?'adv-neg':'adv-pos'}">${inr(a.profit)}</b>`,1)}${td(a.rev?(a.profit/a.rev*100).toFixed(1)+'%':'—',1)}</tr>`),{empty:'No sales in this period.',cls:'fit'});
  // bills
  const billT=btable([['Date'],['Bill'],['Party'],['Book'],['Sale ₹','r'],['Cost ₹','r'],['Profit ₹','r'],['Margin','r'],['Cost known','r']],L.slice(0,400).map(x=>`<tr class="click" data-act="inv-view" data-id="${esc(x.v.id)}">${td(fmtD(x.v.date))}${td('<b class="mono">'+esc(x.v.no)+'</b>')}${td(esc(x.v.partyName||''))}${td(bookPill(x.v))}${td(inr(x.revenue),1)}${td(inr(x.cost),1)}${td(`<b class="${x.profit<0?'adv-neg':'adv-pos'}">${inr(x.profit)}</b>`,1)}${td(x.margin.toFixed(1)+'%',1)}${td(`${x.known}/${x.lines.length}`,1)}</tr>`),{empty:'No sale bills in this period.'});
  const best=L.slice().sort((a,b)=>b.profit-a.profit)[0],worst=L.slice().sort((a,b)=>a.profit-b.profit)[0];
  return kp+chart+`<div class="two"><div class="card"><h3>Profit by item</h3>${itemT}</div><div class="card"><h3>Most profitable customers</h3>${partyT}</div></div>`+
   `<div class="card" style="margin-top:14px"><div class="card-h"><h3>Profit on every bill</h3><span class="small muted">${best?`Best ${esc(best.v.no)} ${inr(best.profit)}`:''}${worst&&worst!==best?` · lowest ${esc(worst.v.no)} ${inr(worst.profit)}`:''}</span></div>${billT}${L.length>400?'<p class="small muted">Showing the latest 400 bills — export CSV for all.</p>':''}<p class="small muted" style="margin:10px 0 0">Profit = sale value without GST − cost. Cost uses the piece's purchase tunch + wastage at its purchase rate and the purchase labour (vault pieces), otherwise the supplier rate card or your average purchase wastage. Stone and hallmark charges are treated as pass-through. Old gold taken in exchange is not counted.</p></div>`}
{const R2=VIEWDEF.reports;VIEWDEF.reports={...R2,shell(){return R2.shell.apply(this,arguments)},body(){if(ui.rTab==='profit')return withBook(ui.rpBook,advProfitReport);return R2.body.apply(this,arguments)}}}
{const RE3=reportExport;reportExport=function(){if(ui.rTab!=='profit')return RE3.apply(this,arguments);return withBook(ui.rpBook,()=>{const {r,L,c}=advProfitData();const R=n=>Math.round(num(n));
  return {title:(ui.rpBook&&ui.rpBook!=='both'?bookLabel(ui.rpBook)+' · ':'')+'Profit report',sub:r.label,summary:[['Sales (without GST)',R(c.rev)],['Cost',R(c.cost)],['Profit',R(c.profit)],['Margin %',c.rev?(c.profit/c.rev*100).toFixed(1):'0'],['Bills',c.bills]],
    cols:[{h:'Date',w:1.2},{h:'Bill',w:1.8},{h:'Party',w:2.6},{h:'Book',w:.9},{h:'Sale',w:1.3,a:'r'},{h:'Cost',w:1.3,a:'r'},{h:'Profit',w:1.3,a:'r'},{h:'Margin %',w:1,a:'r'},{h:'Cost known',w:1,a:'r'}],
    rows:L.map(x=>[fmtD(x.v.date),x.v.no,x.v.partyName||'',bookOf(x.v)==='pakka'?'Pakka':'Kacha',R(x.revenue),R(x.cost),R(x.profit),x.margin.toFixed(1),x.known+'/'+x.lines.length]),file:safeName('shivaa_profit_'+r.a+'_to_'+r.b)}})}}

/* =====================================================================
   DOUBLE-ENTRY BOOKS — every bill, payment, expense, scheme, advance and
   bank / cash entry becomes a balanced journal entry (built live, nothing
   extra is stored). Journal · Trial balance · Account ledger
   ===================================================================== */
const DE_G={A:'Assets',L:'Liabilities',C:'Capital',I:'Income',E:'Expenses'};const DE_ORDER='ALCIE';
const DE_SRC={'Cash sales — Pakka (GST bills)':['unb:pakka','Sales not billed — Pakka','I'],'Cash sales — Kacha (estimates)':['unb:kacha','Sales not billed — Kacha','I'],'Collections from customers':['deb:un','Sundry debtors — unallocated receipts','A'],'Gold scheme instalments':['scheme','Gold scheme deposits','L'],'Owner capital introduced':['capital','Capital & opening balances','C'],'Loan received':['loans','Loans','L'],'Advance from customer':['advance','Customer advances','L'],'Old gold / scrap sold':['scrap','Old gold / scrap sales','I'],'Opening cash balance':['capital','Capital & opening balances','C'],'Other income':['othinc','Other income','I']};
const DE_PUR={'Shop expenses':['exp:Shop expenses','Expense — Shop expenses','E'],'Supplier / karigar payment':['cred:un','Sundry creditors — unallocated payments','L'],'Purchase of gold / silver':['pur:unb','Purchases not billed','E'],'Salary':['exp:Salary','Expense — Salary','E'],'Rent':['exp:Rent','Expense — Rent','E'],'GST payment':['gstpaid','GST paid to government','L'],'Income tax / TDS':['tax','Income tax / TDS paid','C'],'Loan repayment':['loans','Loans','L'],'Owner drawings (personal)':['drawings','Drawings','C'],'Advance to supplier':['supadv','Advances to suppliers','A']};
let DE_CACHE={key:'',val:null};
function deKey(book){const s=settings();return [book,activeFirm(),...['invoices','expenses','schemes','banktx','cdn','bookings','repairs'].map(c=>(FVER[c]||0)+':'+((RAW[c]||S[c]||[]).length)),S.customers.length,S.suppliers.length,JSON.stringify(banksList().map(b=>[b.id,b.opening,b.openDate])),num(s.openingCash),s.openingDate||''].join('|')}
function deBuild(book){book=book==='pakka'?'pakka':'both';const key=deKey(book);if(DE_CACHE.key===key&&DE_CACHE.val)return DE_CACHE.val;
  const A={};const acc=(id,name,g,grp)=>{if(!A[id])A[id]={id,name,g,grp:grp||''};return id};const E=[];
  const cash=()=>acc('cash','Cash in hand','A');const bank=id=>id?acc('bank:'+id,'Bank — '+bankName(id),'A'):acc('bank:none','Bank (no account set up)','A');
  const money=(m,x)=>m==='Cash'?cash():bank(bankOf(x||{}));
  const party=v=>INV_TYPES[v.type]&&INV_TYPES[v.type].party==='supplier'?acc('sup:'+v.partyId,v.partyName||'Supplier','L','Sundry creditors'):acc('cust:'+v.partyId,v.partyName||'Customer','A','Sundry debtors');
  const RO=()=>acc('roundoff','Round off','I');const map=(o,k,fallback)=>{const x=o[k];return x?acc(x[0],x[1],x[2]):acc(...fallback)};const SUS=['suspense','Suspense (not classified)','L'];
  const ln=(a,amt,side)=>{amt=r2(num(amt));if(Math.abs(amt)<0.005)return null;if(amt<0){amt=-amt;side=side==='dr'?'cr':'dr'}return {acc:a,dr:side==='dr'?amt:0,cr:side==='cr'?amt:0}};
  const dr=(a,x)=>ln(a,x,'dr'),cr=(a,x)=>ln(a,x,'cr');
  const add=(date,no,narr,lines,ref)=>{lines=lines.filter(Boolean);if(!lines.length)return;const d=r2(sum(lines,l=>l.dr)-sum(lines,l=>l.cr));if(Math.abs(d)>=0.005)lines.push(d>0?{acc:RO(),dr:0,cr:d}:{acc:RO(),dr:-d,cr:0});
    E.push({date:date||'2000-01-01',no:no||'',narr,lines,ref:ref||'',seq:E.length})};
  const inc=v=>book==='both'||bookOf(v)==='pakka';
  const gst=(t,side,dir)=>{const f=side==='out'?'Output':'Input';const g=side==='out'?'L':'A';return [['cgst','CGST'],['sgst','SGST'],['igst','IGST']].map(([k,l])=>num(t[k])?ln(acc('gst:'+side+':'+k,`${f} ${l}${side==='in'?' (ITC)':''}`,g),t[k],dir):null)};
  // opening balances
  {const s=settings();if(num(s.openingCash))add(s.openingDate||'2000-01-01','Opening','Opening cash balance',[dr(cash(),s.openingCash),cr(acc('capital','Capital & opening balances','C'),s.openingCash)])}
  banksList().forEach(b=>{if(num(b.opening))add(b.openDate||'2000-01-01','Opening','Opening bank balance — '+bankName(b.id),[dr(bank(b.id),b.opening),cr(acc('capital','Capital & opening balances','C'),b.opening)])});
  // bills
  S.invoices.forEach(v=>{if(!inc(v))return;const t=v.totals||{};const bk=bookOf(v);const P=party(v);const T=INV_TYPES[v.type]||{};
    if(isSaleT(v.type)){add(v.date,v.no,`${T.short||'Sale'} to ${v.partyName||''}`,[dr(P,t.grand),cr(acc('sales:'+bk,bk==='pakka'?'Sales — Pakka (GST)':'Sales — Kacha (estimates)','I'),t.taxable),...gst(t,'out','cr'),cr(RO(),t.roundoff)],v.id);
      if(num(t.oldValue)>0)add(v.date,v.no,`Old gold taken in exchange — ${v.partyName||''}`,[dr(acc('oldgold','Old gold purchases','E'),t.oldValue),cr(P,t.oldValue)],v.id)}
    else if(v.type==='metal')add(v.date,v.no,`Metal bill charges — ${v.partyName||''}`,[dr(P,t.grand),cr(acc('metalchg','Metal bill labour & charges','I'),t.taxable),cr(RO(),t.roundoff)],v.id);
    else if(v.type==='oldgold')add(v.date,v.no,`Old gold bought from ${v.partyName||''}`,[dr(acc('oldgold','Old gold purchases','E'),invPayable(v)),cr(P,invPayable(v))],v.id);
    else if(isBuy(v.type))add(v.date,v.no,`${T.short||'Purchase'} from ${v.partyName||''}`,[dr(acc('pur:'+bk,bk==='pakka'?'Purchases — Pakka (GST)':'Purchases — Kacha (estimates)','E'),t.taxable),...gst(t,'in','dr'),dr(RO(),t.roundoff),cr(P,t.grand)],v.id);
    // payments & adjustments
    const buy=isBuy(v.type);invPayments(v).forEach(p=>{const amt=num(p.amount);if(Math.abs(amt)<0.005)return;const m=p.mode||'Cash';const d=p.date||v.date;
      if(m==='Credit note'||m==='Debit note'){const n=(S.cdn||[]).find(x=>x.id===p.cdnId);
        if(!buy)add(d,p.note||(n&&n.no)||v.no,`Credit note to ${v.partyName||''} on ${v.no}`,n?[dr(acc('salesret','Sales returns (credit notes)','I'),n.taxable),...gst(n,'out','dr'),cr(P,amt)]:[dr(acc('salesret','Sales returns (credit notes)','I'),amt),cr(P,amt)],v.id);
        else add(d,p.note||(n&&n.no)||v.no,`Debit note to ${v.partyName||''} on ${v.no}`,n?[dr(P,amt),cr(acc('purret','Purchase returns (debit notes)','E'),n.taxable),...gst(n,'in','cr')]:[dr(P,amt),cr(acc('purret','Purchase returns (debit notes)','E'),amt)],v.id);return}
      const C=m==='Scheme'?acc('scheme','Gold scheme deposits','L'):m==='Advance'?acc('advance','Customer advances','L'):NON_MONEY.has(m)?acc(...SUS):money(m,p);
      if(buy)add(d,v.no,`Paid to ${v.partyName||''}${m!=='Cash'?' · '+m:''}`,[dr(P,amt),cr(C,amt)],v.id);else add(d,v.no,`Received from ${v.partyName||''}${m!=='Cash'?' · '+m:''}`,[dr(C,amt),cr(P,amt)],v.id)})});
  // expenses
  S.expenses.forEach(e=>{const m=e.mode||'Cash';add(e.date,'Expense',`${e.category||'Expense'}${e.notes?' — '+e.notes:''}`,[dr(acc('exp:'+(e.category||'Other'),'Expense — '+(e.category||'Other'),'E'),e.amount),cr(money(m,e),e.amount)],e.id)});
  // gold scheme, advances, repairs
  S.schemes.forEach(sc=>{(sc.payments||[]).forEach(p=>add(p.date,sc.no,`Scheme instalment — ${sc.customerName||''}`,[dr(money(p.mode||'Cash',p),p.amount),cr(acc('scheme','Gold scheme deposits','L'),p.amount)],sc.id));
    if(sc.refund&&sc.closedOn)add(sc.closedOn,sc.no,`Scheme refund — ${sc.customerName||''}`,[dr(acc('scheme','Gold scheme deposits','L'),sc.refund),cr(money(sc.refundMode||'Cash',sc),sc.refund)],sc.id)});
  (S.bookings||[]).forEach(b=>(b.advances||[]).forEach(p=>add(p.date,b.no,`Rate booking advance — ${b.customerName||''}`,[dr(money(p.mode||'Cash',p),p.amount),cr(acc('advance','Customer advances','L'),p.amount)],b.id)));
  (S.repairs||[]).forEach(rp=>(rp.payments||[]).forEach(p=>add(p.date,rp.no,`Repair charges — ${rp.customerName||''}`,[dr(money(p.mode||'Cash',p),p.amount),cr(acc('repair','Repair income','I'),p.amount)],rp.id)));
  // bank & cash entries
  (S.banktx||[]).forEach(x=>{const a=num(x.amount);const T=BTX[x.kind]||{};const nar=[T.label||x.kind,x.party,x.source,x.purpose,x.notes].filter(Boolean).join(' · ');const src=map(DE_SRC,x.source,SUS),pur=map(DE_PUR,x.purpose,SUS);let L;
    switch(x.kind){case 'deposit':L=[dr(bank(x.bankId),a),cr(cash(),a)];break;case 'withdraw':L=[dr(cash(),a),cr(bank(x.bankId),a)];break;case 'transfer':L=[dr(bank(x.toBankId),a),cr(bank(x.bankId),a)];break;
      case 'receipt':L=[dr(bank(x.bankId),a),cr(src,a)];break;case 'payment':L=[dr(pur,a),cr(bank(x.bankId),a)];break;case 'charges':L=[dr(acc('bankchg','Bank charges','E'),a),cr(bank(x.bankId),a)];break;
      case 'interest':L=[dr(bank(x.bankId),a),cr(acc('interest','Interest income','I'),a)];break;case 'cashin':L=[dr(cash(),a),cr(src,a)];break;case 'cashout':L=[dr(pur,a),cr(cash(),a)];break;
      default:L=(T.dir||1)>0?[dr(bank(x.bankId),a),cr(acc(...SUS),a)]:[dr(acc(...SUS),a),cr(bank(x.bankId),a)]}
    add(x.date,x.ref||'Bank/cash',nar,L,x.id)});
  E.sort((a,b)=>a.date.localeCompare(b.date)||a.seq-b.seq);
  const val={A,E};DE_CACHE={key,val};return val}
function deBalances(D,upto,from){const bal={};D.E.forEach(e=>{if(upto&&e.date>upto)return;if(from&&e.date<from)return;e.lines.forEach(l=>{bal[l.acc]=r2((bal[l.acc]||0)+l.dr-l.cr)})});return bal}
const deAccName=(D,id)=>(D.A[id]||{}).name||id;
const deAmt=v=>Math.abs(v)<0.005?'':inr2(v);
/* ---- screens ---- */
AC_TABS.splice(Math.max(0,AC_TABS.findIndex(x=>x[0]==='expenses')),0,['journal','Journal'],['trial','Trial balance'],['acledger','Account ledger']);
const DE_TABS=['journal','trial','acledger'];
function deAccounts(D){return Object.values(D.A).sort((a,b)=>DE_ORDER.indexOf(a.g)-DE_ORDER.indexOf(b.g)||(a.grp||'').localeCompare(b.grp||'')||a.name.localeCompare(b.name))}
{const A1=VIEWDEF.accounts;VIEWDEF.accounts={...A1,shell(){const tab=ui.accTab||'ledger';if(!DE_TABS.includes(tab))return A1.shell.apply(this,arguments);const h=A1.shell.apply(this,arguments);
    const D=deBuild(ui.deBook);let extra='';if(tab==='acledger'){const L=deAccounts(D);if(!L.some(a=>a.id===ui.deAcc))ui.deAcc=(L.find(a=>a.id==='cash')||L[0]||{}).id||'';
      extra=`<select data-ui="deAcc" data-full="1" aria-label="Account">${Object.keys(DE_G).map(g=>{const xs=L.filter(a=>a.g===g);return xs.length?`<optgroup label="${esc(DE_G[g])}">${xs.map(a=>`<option value="${esc(a.id)}"${a.id===ui.deAcc?' selected':''}>${esc((a.grp?a.grp+' · ':'')+a.name)}</option>`).join('')}</optgroup>`:''}).join('')}</select>`}
    if(tab==='trial')extra=`<label class="chk" style="margin:0"><input type="checkbox" data-act="de-parties"${ui.deParties?' checked':''}> Show every party</label>`;
    const bar=`<div class="toolbar">${tab==='trial'?`<span class="small muted" style="font-weight:700">As on</span><input type="date" data-ui="deAsOf" data-full="1" value="${esc(ui.deAsOf||todayStr())}" aria-label="As on date">`:periodSel('acRp','acFrom','acTo')}${seg('deBook',[['both','All books'],['pakka','Pakka only (official)']])}${extra}<span style="flex:1"></span><button class="btn sm" data-act="ac-csv">${ic('dl',14)} CSV</button><button class="btn sm" data-act="ac-pdf">${ic('dl',14)} PDF</button></div>`;
    return h.replace('<div id="vbody"></div>',bar+'<div id="vbody"></div>')},
  body(){const tab=ui.accTab||'ledger';if(tab==='journal')return deJournalBody();if(tab==='trial')return deTrialBody();if(tab==='acledger')return deLedgerBody();return A1.body.apply(this,arguments)}}}
if(!ui.deBook)ui.deBook='both';
function deJournalBody(){const D=deBuild(ui.deBook);const r=acRange();const L=D.E.filter(e=>inRange(e.date,r.a,r.b));if(!D.E.length)return emptyBox('No transactions yet — the journal fills itself from your bills, payments, expenses and bank entries.');
  const tDr=r2(sum(L,e=>sum(e.lines,l=>l.dr))),tCr=r2(sum(L,e=>sum(e.lines,l=>l.cr)));const ok=Math.abs(tDr-tCr)<0.01;const show=L.slice().reverse().slice(0,400);
  const rows=show.map(e=>{const ds=e.lines.filter(l=>l.dr),cs=e.lines.filter(l=>l.cr);const ref=S.invoices.some(v=>v.id===e.ref);
    return `<tr${ref?` class="click" data-act="inv-view" data-id="${esc(e.ref)}"`:''}>${td(fmtD(e.date))}${td('<span class="mono">'+esc(e.no)+'</span>')}<td class="je">${ds.map(l=>`<div>${esc(deAccName(D,l.acc))} <span class="muted small">Dr</span></div>`).join('')}${cs.map(l=>`<div class="to">To ${esc(deAccName(D,l.acc))}</div>`).join('')}<div class="nar">${esc(e.narr)}</div></td><td class="r num">${ds.map(l=>`<div>${inr2(l.dr)}</div>`).join('')}</td><td class="r num">${ds.map(()=>'<div>&nbsp;</div>').join('')}${cs.map(l=>`<div>${inr2(l.cr)}</div>`).join('')}</td></tr>`});
  return `<div class="list-sum"><span><b>${L.length}</b> entries · ${esc(r.label)}</span><span>Total debit <b>${inr2(tDr)}</b></span><span>Total credit <b>${inr2(tCr)}</b></span><span class="adv-bal ${ok?'':'bad'}">${ok?'✓ Debits = Credits':'Out by '+inr2(tDr-tCr)}</span></div>
   <div class="card" style="padding:8px">${btable([['Date'],['Voucher'],['Particulars'],['Debit ₹','r'],['Credit ₹','r']],rows,{empty:'No entries in this period.'})}</div>${L.length>400?'<p class="small muted">Showing the latest 400 entries — export CSV for all.</p>':''}
   <p class="small muted">Built automatically: sale bill → customer Dr, sales & output GST Cr; purchase → purchases & input GST Dr, supplier Cr; receipts → cash/bank Dr, party Cr; expenses, gold scheme, advances, repairs and bank/cash entries post the same way. Nothing to type twice.</p>`}
function deTB(){const D=deBuild(ui.deBook);const asOf=ui.deAsOf||todayStr();const bal=deBalances(D,asOf);const all=deAccounts(D).filter(a=>Math.abs(bal[a.id]||0)>=0.005);
  let rows=[];if(ui.deParties)rows=all.map(a=>({name:a.name,grp:a.grp,g:a.g,b:bal[a.id],id:a.id}));
  else{const agg={};all.forEach(a=>{if(a.grp){const k=a.grp;const x=agg[k]||(agg[k]={name:k,grp:'',g:a.g,b:0,n:0,id:''});x.b=r2(x.b+bal[a.id]);x.n++}else rows.push({name:a.name,grp:'',g:a.g,b:bal[a.id],id:a.id})});Object.values(agg).forEach(x=>{if(Math.abs(x.b)>=0.005||x.n)rows.push({...x,name:`${x.name} (${x.n} part${x.n>1?'ies':'y'})`})})}
  rows.sort((a,b)=>DE_ORDER.indexOf(a.g)-DE_ORDER.indexOf(b.g)||a.name.localeCompare(b.name));const tDr=r2(sum(rows,x=>Math.max(0,x.b))),tCr=r2(sum(rows,x=>Math.max(0,-x.b)));
  const S_=g=>r2(sum(all.filter(a=>a.g===g),a=>bal[a.id]));return {D,asOf,rows,tDr,tCr,assets:S_('A'),liab:-S_('L'),cap:-S_('C'),profit:-(S_('I')+S_('E')),inc:-S_('I'),exp:S_('E')}}
function deTrialBody(){const T=deTB();if(!T.D.E.length)return emptyBox('No transactions yet — the trial balance builds itself from your bills, payments and expenses.');const ok=Math.abs(T.tDr-T.tCr)<0.01;
  const eq=`<div class="adv-eq"><div><div class="l">Assets</div><div class="v">${inr(T.assets)}</div></div><div class="op">=</div><div><div class="l">Liabilities</div><div class="v">${inr(T.liab)}</div></div><div class="op">+</div><div><div class="l">Capital</div><div class="v">${inr(T.cap)}</div></div><div class="op">+</div><div><div class="l">Income − expenses</div><div class="v ${T.profit<0?'adv-neg':'adv-pos'}">${inr(T.profit)}</div></div></div>`;
  const stk=deStockCost();const stock=stk.n?`<p class="small muted" style="margin:-4px 2px 14px">Vault stock at cost ≈ <b>${inr(stk.value)}</b> (${stk.n} piece${stk.n>1?'s':''} in stock / on approval, valued at their purchase rate${T.asOf!==todayStr()?' — stock as of today':''}). Income − expenses + closing stock = <b class="${T.profit+stk.value<0?'adv-neg':'adv-pos'}">profit after stock ${inr(T.profit+stk.value)}</b>.</p>`:'';
  const rows=T.rows.map(x=>`<tr${x.id?` class="click" data-act="de-open" data-id="${esc(x.id)}"`:''}>${td('<b>'+esc(x.name)+'</b>'+(x.grp?` <span class="small muted">${esc(x.grp)}</span>`:''))}${td(esc(DE_G[x.g]))}${td(x.b>0?inr2(x.b):'',1)}${td(x.b<0?inr2(-x.b):'',1)}</tr>`);
  return `<div class="list-sum"><span>Trial balance as on <b>${fmtD(T.asOf)}</b> · ${ui.deBook==='pakka'?'Pakka (official) books':'all books'}</span><span>Income <b>${inr(T.inc)}</b></span><span>Expenses <b>${inr(T.exp)}</b></span><span class="adv-bal ${ok?'':'bad'}">${ok?'✓ Balanced':'Out by '+inr2(T.tDr-T.tCr)}</span></div>${eq}${stock}
   <div class="card" style="padding:8px">${btable([['Account'],['Group'],['Debit ₹','r'],['Credit ₹','r']],rows,{foot:`<tr><td><b>Total</b></td><td></td><td class="r"><b>${inr2(T.tDr)}</b></td><td class="r"><b>${inr2(T.tCr)}</b></td></tr>`,empty:'No balances yet.'})}</div>
   <p class="small muted">Click an account to open its ledger. Purchases and old gold are shown as expenses at cost (closing stock is not deducted here — see Ledger → Profit &amp; Loss and Balance for the stock-adjusted view).</p>`}
function deStockCost(){const ctx=advPfCtx();let v=0,n=0;S.products.forEach(p=>{if(p.status!=='In Stock'&&p.status!=='On Approval')return;const net=num(p.net);if(!(net>0))return;const tc=num(p.tunch)||(PUR[p.purity]||{}).t||0;const cr=ctx.pRate.get(p.id)||advRateAt(p.purchaseDate||todayStr(),metalOf(p.purity));v+=net*(tc+num(p.wastage))/100*cr+net*num(p.labour);n++});return {value:r2(v),n}}
function deLedger(){const D=deBuild(ui.deBook);const r=acRange();const id=ui.deAcc;const a=D.A[id];if(!a)return null;let open=0;const rows=[];let bal=0;
  D.E.forEach(e=>e.lines.forEach(l=>{if(l.acc!==id)return;if(e.date<r.a){open=r2(open+l.dr-l.cr);return}if(e.date>r.b)return;rows.push({e,l})}));bal=open;
  const out=rows.map(({e,l})=>{bal=r2(bal+l.dr-l.cr);const other=e.lines.filter(x=>x.acc!==id).map(x=>deAccName(D,x.acc));return {date:e.date,no:e.no,ref:e.ref,part:(l.dr?'By ':'To ')+other.slice(0,2).join(', ')+(other.length>2?' +'+(other.length-2):''),narr:e.narr,dr:l.dr,cr:l.cr,bal}});
  return {D,a,r,open,rows:out,close:bal,tDr:r2(sum(out,x=>x.dr)),tCr:r2(sum(out,x=>x.cr))}}
const deBal=v=>Math.abs(v)<0.005?'0.00':inr2(Math.abs(v))+(v>0?' Dr':' Cr');
function deLedgerBody(){if(!deBuild(ui.deBook).E.length)return emptyBox('No transactions yet — account ledgers build themselves from your bills, payments and expenses.');const X=deLedger();if(!X)return emptyBox('Choose an account.');
  const rows=X.rows.slice().reverse().slice(0,500).map(x=>`<tr${S.invoices.some(v=>v.id===x.ref)?` class="click" data-act="inv-view" data-id="${esc(x.ref)}"`:''}>${td(fmtD(x.date))}${td('<span class="mono">'+esc(x.no)+'</span>')}${td(esc(x.part)+`<div class="small muted">${esc(x.narr)}</div>`)}${td(deAmt(x.dr),1)}${td(deAmt(x.cr),1)}${td('<b>'+deBal(x.bal)+'</b>',1)}</tr>`);
  return `<div class="adv-eq" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))"><div><div class="l">Opening</div><div class="v">${deBal(X.open)}</div></div><div><div class="l">Debits</div><div class="v">${inr2(X.tDr)}</div></div><div><div class="l">Credits</div><div class="v">${inr2(X.tCr)}</div></div><div><div class="l">Closing</div><div class="v">${deBal(X.close)}</div></div></div>
   <div class="card" style="padding:8px"><h3 style="margin:6px 8px 10px">${esc(X.a.name)} <span class="small muted">${esc(DE_G[X.a.g])}${X.a.grp?' · '+esc(X.a.grp):''} · ${esc(X.r.label)}</span></h3>${btable([['Date'],['Voucher'],['Particulars'],['Debit ₹','r'],['Credit ₹','r'],['Balance','r']],rows,{empty:'No entries in this period.'})}</div>${X.rows.length>500?'<p class="small muted">Showing the latest 500 entries — export CSV for all.</p>':''}`}
{const AE=acExport;acExport=function(){const tab=ui.accTab;if(!DE_TABS.includes(tab))return AE.apply(this,arguments);const R=n=>r2(n);const bk=ui.deBook==='pakka'?' (Pakka)':'';
  if(tab==='journal'){const D=deBuild(ui.deBook);const r=acRange();const L=D.E.filter(e=>inRange(e.date,r.a,r.b));const rows=[];L.forEach(e=>e.lines.forEach(l=>rows.push([fmtD(e.date),e.no,deAccName(D,l.acc),l.dr?R(l.dr):'',l.cr?R(l.cr):'',e.narr])));
    return {title:'Journal'+bk,sub:r.label,summary:[['Entries',L.length],['Debit',Math.round(sum(L,e=>sum(e.lines,l=>l.dr)))],['Credit',Math.round(sum(L,e=>sum(e.lines,l=>l.cr)))]],cols:[{h:'Date',w:1.1},{h:'Voucher',w:1.6},{h:'Account',w:2.8},{h:'Debit',w:1.2,a:'r'},{h:'Credit',w:1.2,a:'r'},{h:'Narration',w:3.4}],rows,file:safeName('shivaa_journal_'+r.a+'_to_'+r.b)}}
  if(tab==='trial'){const T=deTB();return {title:'Trial balance'+bk,sub:'As on '+fmtD(T.asOf),summary:[['Total debit',Math.round(T.tDr)],['Total credit',Math.round(T.tCr)],['Income - expenses',Math.round(T.profit)]],cols:[{h:'Account',w:3.4},{h:'Group',w:1.4},{h:'Debit',w:1.4,a:'r'},{h:'Credit',w:1.4,a:'r'}],rows:[...T.rows.map(x=>[x.name,DE_G[x.g],x.b>0?R(x.b):'',x.b<0?R(-x.b):'']),['Total','',R(T.tDr),R(T.tCr)]],file:safeName('shivaa_trial_balance_'+T.asOf)}}
  const X=deLedger();if(!X)return null;return {title:'Ledger — '+X.a.name+bk,sub:X.r.label,summary:[['Opening',deBal(X.open)],['Debits',Math.round(X.tDr)],['Credits',Math.round(X.tCr)],['Closing',deBal(X.close)]],cols:[{h:'Date',w:1.1},{h:'Voucher',w:1.6},{h:'Particulars',w:3.6},{h:'Debit',w:1.2,a:'r'},{h:'Credit',w:1.2,a:'r'},{h:'Balance',w:1.5,a:'r'}],rows:X.rows.map(x=>[fmtD(x.date),x.no,x.part+' — '+x.narr,x.dr?R(x.dr):'',x.cr?R(x.cr):'',deBal(x.bal)]),file:safeName('shivaa_ledger_'+X.a.name+'_'+X.r.a+'_to_'+X.r.b)}}}

/* ---- events for the advanced layer ---- */
document.addEventListener('click',async e=>{const t=e.target.closest&&e.target.closest('[data-act]');if(!t)return;const a=t.dataset.act;
  try{switch(a){
    case 'acx-queue':advReminderQueue();break;
    case 'acx-next':{const ov=t.closest('.overlay');const n=ov&&$$('.acx-q .row:not(.sent) a[data-act="remind"]',ov)[0];if(n)n.click();else{toast('All reminders opened ✓');if(ov)closeModal(ov)}break}
    case 'remind':{const row=t.closest('.acx-q .row');if(row)row.classList.add('sent');break}
    case 'adv-day':{const d=t.dataset.d;if(!d)break;ui.q.reports='';goTo('reports',{rTab:'sales',rp:'custom',rFrom:d,rTo:d,rGroup:'none',rParty:'',rCat:'',rPur:''});window.scrollTo(0,0);break}
    case 'adv-usual':advUseUsual(t);break;
    case 'split-toggle':advSplitToggle();break;
    case 'guard-save':{const ov=t.closest('.overlay');if(ov)closeModal(ov);if(INV&&INV.el&&INV.el.isConnected){INV._guardOk=true;const b=$('[data-act="inv-save"]',INV.el);if(b)b.click()}break}
    case 'de-parties':ui.deParties=!!t.checked;renderView(true);break;
    case 'de-open':if(t.dataset.id){ui.accTab='acledger';ui.deAcc=t.dataset.id;renderView(true);window.scrollTo(0,0)}break;
  }}catch(err){console.error(err);toast('Something went wrong — please try again','err')}});
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&(t.dataset.split!==undefined||t.dataset.splitBank!==undefined)&&INV)advSplitSync()});
document.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.splitBank!==undefined&&INV)advSplitSync()});
/* celebrate payments and day closing too */
{const AP=addPayment;addPayment=async function(ov,id){const v0=S.invoices.find(x=>x.id===id);const n0=v0?invPayments(v0).length:0;const r=await AP.apply(this,arguments);const v1=S.invoices.find(x=>x.id===id);
  if(v1&&invPayments(v1).length>n0){const p=invPayments(v1).slice(-1)[0]||{};advBurst('Payment recorded',`${inr2(p.amount)} · ${p.mode||''}${invDue(v1)>0.5?' · balance '+inr(invDue(v1)):' · fully paid'}`)}return r}}
if(SUBMIT2&&SUBMIT2.closing){const SC=SUBMIT2.closing;SUBMIT2.closing=async function(){const sig=()=>(S.closings||[]).map(c=>c.id+':'+(c.updatedAt||c.closedAt||'')).join(',');const b=sig();const r=await SC.apply(this,arguments);if(sig()!==b)advBurst('Day closed','Books for the day are closed');return r}}
/* quick find knows the new screens */
{const PCC=pcPalCmds;pcPalCmds=function(){const L=PCC.apply(this,arguments);L.push({ic:'trend',t:'Profit report',s:'Reports',run:()=>goTo('reports',{rTab:'profit'})},{ic:'book',t:'Journal (double entry)',s:'Ledger',run:()=>goTo('accounts',{accTab:'journal'})},{ic:'book',t:'Trial balance',s:'Ledger',run:()=>goTo('accounts',{accTab:'trial'})},{ic:'book',t:'Account ledger',s:'Ledger',run:()=>goTo('accounts',{accTab:'acledger'})});return L}}
/* the AI assistant knows the new features */
{const AR2=agentRules;agentRules=function(){return AR2.apply(this,arguments)+`\nADVANCED FEATURES: Dashboard has a live rate strip (24K/22K/18K gold, silver with change vs last rate), pulse cards (today's sales, month sales, collections, profit, fine gold) with trend lines, an Action centre grouping today's tasks (money to collect, compliance, customers, stock) with a "Send reminders" queue, a Business trends chart (sales, profit, collections — 30/90 days or 12 months, hover for details) and a sales calendar heatmap (tap a day to open its bills). Bill maker: remembers each party's last wastage, labour, making and margin per Category+Purity (tag "last bill") and shows their usual items as one-tap chips; Split payment (Cash + UPI + Card + Bank + Cheque in one bill); a Bill error guard checks before saving (rate below today's, negative making, selling below cost, missing HUID on pakka gold, duplicate bill, cash ₹2 lakh+ (269ST), PAN for ₹2 lakh+ sales (Rule 114B), credit limit, odd dates). Every sale bill shows "Profit on this bill" (not printed). Reports → Profit: gross profit, margin, net profit after expenses, profit by item, customer and bill. Ledger → Journal, Trial balance and Account ledger are automatic double-entry books built from bills, payments, expenses, gold scheme, advances and bank/cash entries (All books or Pakka only).`}}
/* start */
try{renderView(true)}catch(e){console.error(e)}
