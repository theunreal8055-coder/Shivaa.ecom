/* =====================================================================
   SJ BILL — premium GST bill PDF + graphic rate card image
   - Royal bill: black & gold header with the Shivaa INC. logo, clean
     cards, HSN-wise tax table, amount in words, bank + UPI QR, signatures
     · Wholesale bills show Tunch + Wastage + Fine, Retail bills show
       Rate + Making — same data, laid out for each sector
     · "Ivory" variant = same design on white (saves ink) · "Classic" = old
   - Rate card: 1080 × 1350 post or 1080 × 1920 status IMAGE (PNG) with
     gold + silver rates, change vs yesterday, Hindi booking + website lines
   ===================================================================== */
(() => {
  'use strict';
  if (typeof Pdf === 'undefined' || typeof billData === 'undefined') return;
  const cfg = () => (window.SJ_PRO ? SJ_PRO.proCfg() : { billStyle: 'royal' });
  const site = () => String((cfg().website || 'shivaa.in')).replace(/^https?:\/\//, '');
  const phone91 = p => { const d = String(p || '').replace(/\D/g, '').slice(-10); return d.length === 10 ? '+91 ' + d.slice(0, 5) + ' ' + d.slice(5) : String(p || ''); };
  const loadImg = src => new Promise(res => { if (!src) return res(null); const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = src; });
  const GOLD = ['#fff3c4', '#ebc867', '#b98a2d', '#f2d68a', '#a8781f'];
  const goldGrad = (x, x0, y0, x1, y1) => { const g = x.createLinearGradient(x0, y0, x1, y1); GOLD.forEach((c, i) => g.addColorStop(i / (GOLD.length - 1), c)); return g; };
  // the logo tinted with the gold gradient (for dark backgrounds)
  async function goldLogoCanvas(w) { const im = await loadImg(SJ_LOGO); if (!im || !im.naturalWidth) return null; const h = Math.round(w * im.naturalHeight / im.naturalWidth); const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.drawImage(im, 0, 0, w, h); x.globalCompositeOperation = 'source-in'; x.fillStyle = goldGrad(x, 0, 0, w, h); x.fillRect(0, 0, w, h); return c; }
  const jpegOf = (c, q) => { const bin = atob(c.toDataURL('image/jpeg', q || 0.92).split(',')[1]); const d = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) d[i] = bin.charCodeAt(i); return { data: d, w: c.width, h: c.height }; };

  /* =================================================================
     ROYAL BILL PDF
     ================================================================= */
  function rrect(pdf, x, y, w, h, r, mode) { r = Math.min(r, w / 2, h / 2); const k = 0.5523 * r, X = v => pdf.X(v), Y = v => pdf.Y(v);
    pdf.cur.push(`${X(x + r)} ${Y(y)} m ${X(x + w - r)} ${Y(y)} l ${X(x + w - r + k)} ${Y(y)} ${X(x + w)} ${Y(y + r - k)} ${X(x + w)} ${Y(y + r)} c ${X(x + w)} ${Y(y + h - r)} l ${X(x + w)} ${Y(y + h - r + k)} ${X(x + w - r + k)} ${Y(y + h)} ${X(x + w - r)} ${Y(y + h)} c ${X(x + r)} ${Y(y + h)} l ${X(x + r - k)} ${Y(y + h)} ${X(x)} ${Y(y + h - r + k)} ${X(x)} ${Y(y + h - r)} c ${X(x)} ${Y(y + r)} l ${X(x)} ${Y(y + r - k)} ${X(x + r - k)} ${Y(y)} ${X(x + r)} ${Y(y)} c h ${mode || 'S'}`); return pdf; }

  async function royalInvoicePdf(v, style) {
    const D = billData(v), B = D.B, t = D.t; const dark = style !== 'ivory'; const pdf = new Pdf(210, 297);
    const K = dark ? { band: '#0b0a08', name: '#f2d68a', sub: '#d9cdb0', txt: '#ece5d3', th: '#0b0a08', thT: '#f2d68a', accent: '#b98a2d' } : { band: '#ffffff', name: '#7a5a12', sub: '#4a4234', txt: '#2a251b', th: '#efe2bd', thT: '#3a2d0c', accent: '#b98a2d' };
    const INK = '#17140f', MUT = '#6b6557', LINE = '#d9cdb0', CREAM = '#fbf7ec', GOLDT = '#8a6a1c';
    const M = 9, W = 192, R = M + W, BOT = 286;
    const own = !B.logo || B.logo === SJ_LOGO || (typeof BILL_LOGO !== 'undefined' && B.logo === BILL_LOGO);
    let logo = null, logoOnWhite = false;
    if (dark && own) { const c = await goldLogoCanvas(760); if (c) { const k = document.createElement('canvas'); k.width = c.width; k.height = c.height; const x = k.getContext('2d'); x.fillStyle = K.band; x.fillRect(0, 0, k.width, k.height); x.drawImage(c, 0, 0); logo = jpegOf(k); } }
    if (!logo && B.logo) { logo = await loadJpeg(B.logo, 700); logoOnWhite = dark; }
    const bis = B.showBis ? await loadJpeg(BIS_LOGO, 420) : null;
    const [tMain, tSub] = String(D.docTitle || 'TAX INVOICE').split(' -- ');
    const chips = [D.qual, !D.buy && D.type !== 'metal' ? (D.chan === 'wholesale' ? 'WHOLESALE' : 'RETAIL') : ''].filter(Boolean);

    /* ---- columns (scaled from the app's own bill columns, so every GST field stays) ---- */
    const sc = W / sum(D.cols, c => c.w); const cols = D.cols.map((c, i) => ({ ...c, w: c.w * sc, al: i === 1 ? 'l' : (i === 0 || /^(HSN|PCS)$/.test(c.h)) ? 'c' : 'r' }));
    const colX = []; { let x = M; cols.forEach(c => { colX.push(x); x += c.w; }); }
    const rowsM = D.items.map((it, i) => { const cells = cols.map(c => c.v(it, i)); const d = cells[1] || {}; const dw = cols[1].w - 4; const l1 = pdf.font(true, 8).wrap(d.l1 || '', dw); const l2 = d.l2 ? pdf.font(false, 6.5).wrap(d.l2, dw) : []; return { cells, l1, l2, h: Math.max(7.4, 3 + l1.length * 3.5 + l2.length * 2.9 + 1.4) }; });

    /* ---- measured blocks ---- */
    const sumRows = D.rows.filter(r => r[1] !== '' && r[1] != null); const RH = 5.6; const sumH = sumRows.reduce((a, r) => a + (r[2] === 'band' ? 8 : RH), 0) + 3;
    const wordsL = []; D.words.forEach(([k, w]) => { wordsL.push([k, true]); pdf.font(false, 7.6).wrap(w, 56).forEach(l => wordsL.push([l, false])); });
    const extra = []; if (D.old.length) { extra.push([D.metal ? 'Metal received' : 'Old gold / silver received', true]); D.old.slice(0, 5).forEach(o => pdf.font(false, 7).wrap(o, 56).forEach(l => extra.push([l, false]))); }
    if (v.notes) pdf.font(false, 7).wrap('Note: ' + v.notes, 56).slice(0, 4).forEach((l, i) => extra.push([l, false]));
    if (D.irn) { pdf.font(false, 6.3).wrap('IRN: ' + D.irn.irn, 56).forEach(l => extra.push([l, false])); if (D.irn.ack) extra.push([D.irn.ack, false]); }
    const midH = 6 + wordsL.length * 3.5 + (extra.length ? 3 + extra.length * 3.3 : 0) + 2;
    const bank = !D.buy && B.bank ? [['A/c No.', B.bank.accNo], ['Bank', B.bank.bank], ['Branch', B.bank.branch], ['IFSC', B.bank.ifsc]].filter(x => x[1]) : [];
    const modeL = D.modeText ? pdf.font(false, 7.6).wrap('Paid by — ' + D.modeText, 62) : [];
    const leftH = 6 + (bank.length ? bank.length * 3.9 + 2 : 0) + (D.qr ? 22 : (!D.buy && B.upi ? 5 : 0)) + modeL.length * 3.6 + 2;
    const botH = Math.max(sumH, midH, leftH, 30);
    // HSN-wise tax
    let hsn = []; if (D.gstOn && D.items.length) { const ratio = num(t.itemsTotal) ? num(t.taxable) / num(t.itemsTotal) : 1; const m = new Map(); D.items.forEach(it => { const code = String((typeof hsnInfo === 'function' && hsnInfo(it).code) || hsnOf(it)); m.set(code, (m.get(code) || 0) + num(it.amount) * ratio); }); const tot = [...m.values()].reduce((a, b) => a + b, 0) || 1;
      hsn = [...m].map(([code, tx]) => { const sh = tx / tot; return [code, tx, num(t.cgst) * sh, num(t.sgst) * sh, num(t.igst) * sh]; }); }
    const hsnH = hsn.length ? 6.5 + (hsn.length + 1) * 4.6 + 3 : 0;
    const decl = pdf.font(false, 6.8).wrap(B.declaration, 104); const terms = []; String(B.terms || '').split('\n').filter(x => x.trim()).forEach(l => pdf.font(false, 6.8).wrap(l.trim(), 104).forEach(x => terms.push(x)));
    const footH = Math.max(27, (decl.length ? 4 + decl.length * 3 + 1.5 : 0) + (terms.length ? 4 + terms.length * 3 : 0) + 3);
    /* v22: today's rate strip + BIS-style price breakup (sale / estimate bills) */
    const showRate = !D.buy && D.type !== 'metal' && D.items.length > 0, showBk = showRate && D.chan !== 'wholesale';
    let rate24 = 0, rateAg = 0; try { const st = settings(); if (v.date === todayStr() || typeof advRateAt !== 'function') { rate24 = num(st.gold24); rateAg = num(st.silver999); } else { rate24 = num(advRateAt(v.date, 'gold')) || num(st.gold24); rateAg = num(advRateAt(v.date, 'silver')) || num(st.silver999); } } catch (e) { /* no rate */ }
    const bkItems = showBk ? D.items.slice(0, 10).map(it => { const c = calcItem(it, v.type); const pure = v.type === 'metal' ? 0 : r2(c.net * num(it.tunch) / 100 * num(it.rate)); const stone = num(it.stone), hm = num(it.hm); return { name: [it.category, it.purity].filter(Boolean).join(' '), huid: String(it.huid || ''), net: c.net, tunch: num(it.tunch), pure, making: r2(Math.max(0, c.amount - pure - stone - hm)), other: r2(stone + hm), amount: c.amount }; }) : [];
    const rateH = showRate && (rate24 || rateAg) ? 10 : 0;
    const bkH = bkItems.length ? 6 + (bkItems.length + 1) * 4.6 + (D.items.length > 10 ? 4 : 0) + 8 : 0;
    const tailH = botH + 4 + hsnH + bkH + rateH + footH + 6;

    /* ---- page furniture ---- */
    const header = () => {
      const HB = 38; pdf.fill(K.band).rect(0, 0, 210, HB, 'f'); pdf.fill(K.accent).rect(0, HB, 210, 0.9, 'f'); if (dark) pdf.fill('#f2d68a').rect(0, HB + 1.3, 210, 0.2, 'f');
      let nx = M; if (logo) { const h = 23, w = Math.min(54, h * logo.w / logo.h), hh = w * logo.h / logo.w; if (logoOnWhite) { pdf.fill('#ffffff'); rrect(pdf, M - 1.5, 7 - 1.5, w + 3, hh + 3, 2, 'f'); } pdf.image(logo, M, 7 + (h - hh) / 2, w, hh); nx = M + w + 6; }
      const rw = 60, lim = R - rw - nx; let fs = 15; pdf.font(true, fs); while (fs > 9.5 && pdf.width(B.name) > lim) { fs -= 0.5; pdf.font(true, fs); }
      pdf.fill(K.name).text(B.name, nx, 13, { maxW: lim }); let yy = 13;
      if (B.tagline) { yy += 4.3; pdf.fill(K.sub).font(false, 7.2).text(B.tagline, nx, yy, { maxW: lim }); }
      pdf.fill(K.txt).font(false, 7.2);
      if (B.address) pdf.wrap(B.address + (B.stateCode && !/CODE\s*:/i.test(B.address) ? ', Code ' + B.stateCode : ''), lim).slice(0, 2).forEach(l => { yy += 3.6; pdf.text(l, nx, yy); });
      const ct = [B.phone ? 'Mobile ' + B.phone : '', B.email || ''].filter(Boolean).join('   |   '); if (ct) { yy += 3.6; pdf.text(ct, nx, yy, { maxW: lim }); }
      const gl = [D.gstOn && B.gstin ? 'GSTIN ' + B.gstin : '', D.gstOn && B.cin ? 'CIN ' + B.cin : ''].filter(Boolean).join('   |   '); if (gl) { yy += 3.8; pdf.fill(K.name).font(true, 7.4); if (pdf.width(gl) <= lim || !(D.gstOn && B.gstin && B.cin)) pdf.text(gl, nx, yy, { maxW: lim }); else { pdf.text('GSTIN ' + B.gstin, nx, yy, { maxW: lim }); yy += 3.4; pdf.font(true, 6.8).text('CIN ' + B.cin, nx, yy, { maxW: lim }); } }
      // title block
      let ts = 15; pdf.font(true, ts); while (ts > 9 && pdf.width(tMain) > rw) { ts -= 0.5; pdf.font(true, ts); }
      pdf.fill(K.name).text(tMain, R, 13.5, { align: 'right' }); if (tSub) pdf.fill(K.sub).font(false, 7).text(tSub, R, 17.6, { align: 'right' });
      let cx = R; chips.slice().reverse().forEach(c => { pdf.font(true, 6.6); const w = pdf.width(c) + 5; pdf.stroke(K.accent).lw(0.3); if (dark) { pdf.fill('#1c170d'); rrect(pdf, cx - w, 21, w, 5, 2.4, 'B'); } else rrect(pdf, cx - w, 21, w, 5, 2.4, 'S'); pdf.fill(K.name).text(c, cx - w / 2, 24.5, { align: 'center' }); cx -= w + 2; });
      pdf.fill(K.sub).font(false, 6.8).text(D.noLbl.replace(/:\s*$/, ''), R, 31, { align: 'right' }); pdf.fill(dark ? '#ffffff' : INK).font(true, 9.6).text(String(v.no || ''), R, 35.2, { align: 'right' });
      return HB + 5;
    };
    const partyCards = top => {
      const lw = 118, rx = M + lw + 4, rw2 = W - lw - 4; const lines = []; D.pinfo.forEach(p => { (p.wrap ? pdf.font(false, 8).wrap(p.t, lw - 8).slice(0, 2) : [p.t]).forEach(l => lines.push(l)); });
      const meta = [[D.dtLbl.replace(/:\s*$/, ''), longDate(v.date)], ...D.pright.map(x => { const i = x.indexOf(': '); return i > 0 ? [x.slice(0, i), x.slice(i + 2)] : ['', x]; })]; if (num(v.creditDays) && !D.pright.some(x => /^Due/.test(x))) meta.push(['Credit', num(v.creditDays) + ' days']);
      const h = Math.max(27, 10.5 + lines.length * 3.9 + 3, 6 + meta.length * 5 + 3);
      pdf.stroke(LINE).lw(0.25).fill(CREAM); rrect(pdf, M, top, lw, h, 2.6, 'B'); rrect(pdf, rx, top, rw2, h, 2.6, 'B');
      pdf.fill(K.accent).rect(M, top + 3, 0.9, h - 6, 'f');
      pdf.fill(GOLDT).font(true, 6.4).text(String(D.partyLbl).toUpperCase(), M + 4, top + 4.6); pdf.fill(INK).font(true, 10.5).text(v.partyName || '', M + 4, top + 9.6, { maxW: lw - 8 });
      let y = top + 9.6; pdf.fill('#3a352b').font(false, 8); lines.forEach(l => { y += 3.9; pdf.text(l, M + 4, y, { maxW: lw - 8 }); });
      let my = top + 6.5; meta.forEach(([k, val]) => { pdf.fill(MUT).font(false, 7.2).text(k, rx + 3.5, my); pdf.fill(INK).font(true, 8.2).text(val, rx + rw2 - 3.5, my, { align: 'right', maxW: rw2 - 30 }); my += 5; });
      return h;
    };
    const tableHead = y => { pdf.fill(K.th); rrect(pdf, M, y, W, 8, 1.6, 'f'); pdf.fill(K.thT).font(true, cols.length > 10 ? 6.6 : 7.1);
      cols.forEach((c, i) => pdf.text(c.h, c.al === 'l' ? colX[i] + 2.2 : c.al === 'r' ? colX[i] + c.w - 2 : colX[i] + c.w / 2, y + 5.2, { align: c.al === 'l' ? 'left' : c.al === 'r' ? 'right' : 'center', maxW: c.w - 1.5 })); return y + 8; };

    /* ---- paginate ---- */
    const top0 = 43; const pages = [];
    { pdf.pages.length = 0; pdf.addPage(); const ph = partyCards(-500); pdf.pages.length = 0; pdf.addPage();
      const first = top0 + ph + 5 + 8, other = 24 + 8; let cur = [], h = 0, startY = first;
      rowsM.forEach((r, i) => { if (startY + h + r.h > BOT - 6 && cur.length) { pages.push(cur); cur = []; h = 0; startY = other; } cur.push(i); h += r.h; });
      if (startY + h + 7.5 + 4 + tailH > BOT + 2) { // the totals don't fit under these rows → move rows (or just the tail) to a new page
        const keep = []; let kh = 0; for (let k = cur.length - 1; k >= 0; k--) { if (other + kh + rowsM[cur[k]].h + 7.5 + 4 + tailH > BOT + 2) break; keep.unshift(cur[k]); kh += rowsM[cur[k]].h; }
        const moved = cur.slice(0, cur.length - keep.length); if (moved.length || !pages.length) pages.push(moved); cur = keep; }
      pages.push(cur); }
    const nP = pages.length;
    pages.forEach((idx, pi) => {
      if (pi) pdf.addPage(); const last = pi === nP - 1; let y;
      if (pi === 0) { y = header(); y += partyCards(y) + 5; }
      else { pdf.fill(K.band).rect(0, 0, 210, 17, 'f'); pdf.fill(K.accent).rect(0, 17, 210, 0.7, 'f'); pdf.fill(K.name).font(true, 10).text(B.name, M, 10.5, { maxW: 110 }); pdf.fill(K.txt).font(false, 8).text(`${tMain} ${v.no}  ·  continued`, R, 10.5, { align: 'right' }); y = 24; }
      if (idx.length || pi === 0) {
        y = tableHead(y);
        idx.forEach((ri, n) => { const r = rowsM[ri]; if (n % 2) { pdf.fill('#fbf8f0').rect(M, y, W, r.h, 'f'); }
          cols.forEach((c, i) => { const val = r.cells[i]; const tx = c.al === 'l' ? colX[i] + 2.2 : c.al === 'r' ? colX[i] + c.w - 2 : colX[i] + c.w / 2, al = c.al === 'l' ? 'left' : c.al === 'r' ? 'right' : 'center';
            if (i === 1) { let yy = y + 4.5; pdf.fill(INK).font(true, 8); r.l1.forEach(l => { pdf.text(l, tx, yy); yy += 3.5; }); pdf.fill(MUT).font(false, 6.5); r.l2.forEach(l => { pdf.text(l, tx, yy - 0.3); yy += 2.9; }); }
            else pdf.fill(i === cols.length - 1 ? INK : '#2b271e').font(i === cols.length - 1, 7.9).text(val, tx, y + 4.5, { align: al, maxW: c.w - 1.6 }); });
          y += r.h; pdf.stroke('#ece3cc').lw(0.15).line(M, y, R, y); });
        if (last) { pdf.fill('#f3ead2'); rrect(pdf, M, y + 0.6, W, 7.2, 1.4, 'f'); pdf.fill(INK);
          cols.forEach((c, i) => { if (c.k && D.items.length) { const val = c.k === 'pcs' ? String(D.tot.pcs) : num(D.tot[c.k]).toFixed(3) + ' g'; pdf.font(true, 7.6).text(val, c.al === 'r' ? colX[i] + c.w - 2 : colX[i] + c.w / 2, y + 5.4, { align: c.al === 'r' ? 'right' : 'center', maxW: c.w - 1 }); } });
          pdf.font(true, 7.6).text('TOTAL', colX[1] + 2.2, y + 5.4); pdf.font(true, 8.6).text(fmtAmt(t.itemsTotal), R - 2, y + 5.4, { align: 'right' }); y += 7.8; }
        else { pdf.fill(MUT).font(false, 7.4).text(`Continued on next page…`, R, y + 5, { align: 'right' }); }
      }
      if (last && rateH) {   // today's rate + weight summary strip
        y += 3; pdf.stroke(LINE).lw(0.25).fill('#fffaf0'); rrect(pdf, M, y, W, 7, 1.6, 'B'); pdf.fill(K.accent).rect(M, y + 1.4, 0.9, 4.2, 'f');
        pdf.fill(GOLDT).font(true, 6.4).text(v.date === todayStr() ? "AAJ KA BHAV" : 'BILL KE DIN KA BHAV', M + 3.5, y + 4.6);
        const rt = [rate24 ? 'Gold 24K ' + fmtAmt(rate24) + '/10g' : '', rate24 ? '22K ' + fmtAmt(Math.round(rate24 * 0.916)) + '/10g' : '', rateAg ? 'Silver 999 ' + fmtAmt(rateAg) + '/kg' : ''].filter(Boolean).join('   |   ');
        pdf.fill(INK).font(true, 7.4).text(rt, M + 30, y + 4.6, { maxW: 100 });
        pdf.fill(MUT).font(false, 7).text(`Gross ${num(D.tot.gross).toFixed(3)} g  ·  Net ${num(D.tot.net).toFixed(3)} g  ·  Fine ${num(D.tot.fine || sum(D.items, it => calcItem(it, v.type).fine)).toFixed(3)} g`, R - 3, y + 4.6, { align: 'right', maxW: 70 });
        y += 7; }
      if (last) {
        y += 4; const y0 = y, xl = M, wl = 66, xm = M + 69, wm = 60, xr = M + 132, wr = W - 132;
        // left: bank + UPI
        pdf.stroke(LINE).lw(0.25).fill('#ffffff'); rrect(pdf, xl, y0, wl, botH, 2.4, 'S'); rrect(pdf, xm, y0, wm, botH, 2.4, 'S');
        let ly = y0 + 4.8; pdf.fill(GOLDT).font(true, 6.4).text(D.buy ? 'PAYMENT' : 'PAYMENT DETAILS', xl + 3, ly); ly += 1;
        bank.forEach(([k, val]) => { ly += 3.9; pdf.fill(MUT).font(false, 7.2).text(k, xl + 3, ly); pdf.fill(INK).font(true, 7.6).text(String(val), xl + 17, ly, { maxW: wl - 20 }); });
        if (D.qr) { ly += 3; drawQR(pdf, D.qr, xl + 3, ly, 17); pdf.fill(INK).font(true, 7.4).text('Scan & pay (UPI)', xl + 23, ly + 5); pdf.fill(MUT).font(false, 6.6); let us = 6.6; while (us > 5 && pdf.width(B.upi) > wl - 26) { us -= 0.2; pdf.font(false, us); } pdf.text(B.upi, xl + 23, ly + 9); pdf.font(false, 6.4).text('GPay · PhonePe · Paytm · BHIM', xl + 23, ly + 12.6, { maxW: wl - 26 }); ly += 19; }
        else if (!D.buy && B.upi) { ly += 4.2; pdf.fill(MUT).font(false, 7.2).text('UPI', xl + 3, ly); pdf.fill(INK).font(true, 7.4).text(B.upi, xl + 17, ly, { maxW: wl - 20 }); }
        modeL.forEach(l => { ly += 3.6; pdf.fill('#3a352b').font(false, 7.6).text(l, xl + 3, ly); });
        // middle: words + notes
        let my = y0 + 4.8; wordsL.forEach(([l, head]) => { if (head) { pdf.fill(GOLDT).font(true, 6.4).text(String(l).replace(/:$/, '').toUpperCase(), xm + 3, my); } else { pdf.fill(INK).font(false, 7.6).text(l, xm + 3, my); } my += 3.5; });
        if (extra.length) { my += 2; extra.forEach(([l, head]) => { if (head) pdf.fill(GOLDT).font(true, 6.4).text(String(l).toUpperCase(), xm + 3, my); else pdf.fill('#3a352b').font(false, 7).text(l, xm + 3, my); my += 3.3; }); }
        // right: totals
        let ry = y0; sumRows.forEach(r => { if (r[2] === 'band') { pdf.fill(K.th === '#0b0a08' ? '#0b0a08' : '#b98a2d'); rrect(pdf, xr, ry + 0.6, wr, 7, 1.6, 'f'); pdf.fill(dark ? '#f2d68a' : '#ffffff').font(true, 9.4).text(r[0], xr + 3, ry + 5.3); pdf.text((/Fine|g$/.test(r[1]) ? '' : '₹ ') + r[1], xr + wr - 3, ry + 5.3, { align: 'right' }); ry += 8; }
          else { pdf.fill(r[2] === 'bold' ? INK : MUT).font(r[2] === 'bold', 8).text(r[0], xr + 3, ry + 4); pdf.fill(INK).font(r[2] === 'bold' || /^Balance/.test(r[0]), 8.2).text(r[1], xr + wr - 3, ry + 4, { align: 'right' }); ry += RH; pdf.stroke('#ece3cc').lw(0.15).line(xr + 2, ry, xr + wr - 2, ry); } });
        y = y0 + botH + 4;
        if (hsn.length) { const hc = [['HSN / SAC', 30, 'l'], ['Taxable value', 38, 'r'], [t.intra !== false ? 'CGST 1.5%' : 'CGST', 30, 'r'], [t.intra !== false ? 'SGST 1.5%' : 'SGST', 30, 'r'], [t.intra === false ? 'IGST 3%' : 'IGST', 30, 'r'], ['Total tax', 34, 'r']]; const hx = []; { let x = M; hc.forEach(c => { hx.push(x); x += c[1]; }); }
          pdf.fill(GOLDT).font(true, 6.4).text('HSN-WISE TAX SUMMARY', M, y + 3); y += 4.6; pdf.fill('#f3ead2'); rrect(pdf, M, y, W, 4.8, 1.2, 'f'); pdf.fill(INK).font(true, 6.8); hc.forEach((c, i) => pdf.text(c[0], c[2] === 'l' ? hx[i] + 2 : hx[i] + c[1] - 2, y + 3.4, { align: c[2] === 'l' ? 'left' : 'right' })); y += 4.8;
          const line = (r, b) => { pdf.fill(INK).font(!!b, 7.2); [r[0], fmtAmt(r[1]), fmtAmt(r[2]), fmtAmt(r[3]), fmtAmt(r[4]), fmtAmt(r[2] + r[3] + r[4])].forEach((val, i) => pdf.text(val, hc[i][2] === 'l' ? hx[i] + 2 : hx[i] + hc[i][1] - 2, y + 3.3, { align: hc[i][2] === 'l' ? 'left' : 'right' })); y += 4.6; };
          hsn.forEach(r => line(r)); y += 2; }
        if (bkItems.length) {   // BIS-style price breakup: metal value, making, stone / hallmark shown separately
          const bc = [['Item', 46, 'l'], ['HUID', 22, 'l'], ['Net wt', 20, 'r'], ['Purity', 16, 'r'], ['Metal value', 26, 'r'], ['Making + wastage', 28, 'r'], ['Stone / HM', 16, 'r'], ['Amount', 18, 'r']]; const bx = []; { let x = M; bc.forEach(c => { bx.push(x); x += c[1]; }); }
          y += 2; pdf.fill(GOLDT).font(true, 6.4).text('PRICE BREAKUP (BIS HALLMARKING NORMS)', M, y + 3); y += 4.6; pdf.fill('#f3ead2'); rrect(pdf, M, y, W, 4.8, 1.2, 'f'); pdf.fill(INK).font(true, 6.8); bc.forEach((c, i) => pdf.text(c[0], c[2] === 'l' ? bx[i] + 2 : bx[i] + c[1] - 2, y + 3.4, { align: c[2] === 'l' ? 'left' : 'right', maxW: c[1] - 2 })); y += 4.8;
          bkItems.forEach(b => { pdf.fill('#2b271e').font(false, 7.1); [b.name, b.huid || '—', b.net.toFixed(3) + ' g', b.tunch ? b.tunch + '%' : '', fmtAmt(b.pure), fmtAmt(b.making), b.other ? fmtAmt(b.other) : '—', fmtAmt(b.amount)].forEach((val, i) => pdf.font(i === 7, 7.1).text(String(val), bc[i][2] === 'l' ? bx[i] + 2 : bx[i] + bc[i][1] - 2, y + 3.3, { align: bc[i][2] === 'l' ? 'left' : 'right', maxW: bc[i][1] - 2.5 })); y += 4.6; pdf.stroke('#ece3cc').lw(0.15).line(M, y, R, y); });
          if (D.items.length > 10) { pdf.fill(MUT).font(false, 6.6).text(`+ ${D.items.length - 10} aur item — upar ki table mein`, M + 2, y + 3); y += 4; }
          pdf.fill(MUT).font(false, 6.6).text('Metal value = net wt x purity x rate. Har hallmarked gehne ka HUID BIS CARE app par verify kar sakte hain.', M, y + 4); y += 7; }
        // footer
        const yF = BOT - footH; pdf.stroke(LINE).lw(0.25).line(M, yF, R, yF); let fy = yF + 4.2;
        if (decl.length) { pdf.fill(GOLDT).font(true, 6.4).text('DECLARATION', M, fy); fy += 3.4; pdf.fill('#3a352b').font(false, 6.8); decl.forEach(l => { pdf.text(l, M, fy); fy += 3; }); fy += 1.5; }
        if (terms.length) { pdf.fill(GOLDT).font(true, 6.4).text('TERMS & CONDITIONS', M, fy); fy += 3.4; pdf.fill('#3a352b').font(false, 6.8); terms.forEach(l => { pdf.text(l, M, fy); fy += 3; }); }
        const sx = M + 112; if (bis) { const bw = 12, bh = bw * bis.h / bis.w; pdf.image(bis, sx, yF + 3, bw, bh); }
        pdf.stroke('#8f8778').lw(0.2).line(sx + 16, BOT - 6.5, sx + 44, BOT - 6.5).line(R - 46, BOT - 6.5, R, BOT - 6.5);
        pdf.fill(MUT).font(false, 6.8).text(D.signL, sx + 30, BOT - 3.2, { align: 'center' }); pdf.text('Authorised Signatory', R - 23, BOT - 3.2, { align: 'center' });
        pdf.fill(GOLDT).font(true, 7.2).text('for ' + B.name, R, yF + 5, { align: 'right', maxW: 62 });
      }
      // bottom strip
      pdf.fill(K.accent).rect(M, BOT + 1.6, W, 0.35, 'f');
      const thanks = ['Thank you for your business', B.main ? 'www.' + site() : '', B.phone ? phone91(B.phone) : ''].filter(Boolean).join('   ·   ');
      pdf.fill(GOLDT).font(true, 7).text(thanks, 105, BOT + 6, { align: 'center' }); pdf.fill(MUT).font(false, 6.4).text('This is a computer generated bill.', M, BOT + 6); pdf.text(`Page ${pi + 1} of ${nP}`, R, BOT + 6, { align: 'right' });
    });
    return pdf.blob();
  }
  { const _classic = invoicePdf; invoicePdf = async function (v) { const st = cfg().billStyle; if (st === 'classic') return _classic.call(this, v); try { return await royalInvoicePdf(v, st); } catch (e) { console.error(e); return _classic.call(this, v); } }; }
  window.SJ_BILL = { royalInvoicePdf };

  /* =================================================================
     RATE CARD IMAGE
     ================================================================= */
  const HI = '"Mukta","Noto Sans Devanagari","Nirmala UI","Kohinoor Devanagari","Mangal","FreeSans",sans-serif';
  const EN = '"Plus Jakarta Sans",system-ui,"Segoe UI",Roboto,Arial,sans-serif';
  const SERIF = '"Cinzel","Times New Roman",Georgia,serif';
  const HM = ['जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'], HD = ['रविवार', 'सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार'];
  const rupee = n => '₹' + Math.round(num(n)).toLocaleString('en-IN');
  async function fontsReady() { if (!document.fonts || !document.fonts.load) return; const want = ['700 40px "Mukta"', '800 40px "Mukta"', '500 40px "Mukta"', '800 40px "Plus Jakarta Sans"', '700 40px "Cinzel"']; try { await Promise.race([Promise.all(want.map(f => document.fonts.load(f, 'आज का भाव Shivaa 0123'))), new Promise(r => setTimeout(r, 2500))]); } catch (e) { /* system fonts are fine */ } }
  function rr(x, X, Y, w, h, r) { x.beginPath(); if (x.roundRect) x.roundRect(X, Y, w, h, r); else { x.moveTo(X + r, Y); x.arcTo(X + w, Y, X + w, Y + h, r); x.arcTo(X + w, Y + h, X, Y + h, r); x.arcTo(X, Y + h, X, Y, r); x.arcTo(X, Y, X + w, Y, r); x.closePath(); } }

  async function rateCardCanvas(tall) {
    const s = settings(); const W = 1080, H = tall ? 1920 : 1350; const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
    await fontsReady(); const g24 = num(s.gold24), sv = num(s.silver999); const t = todayStr();
    const hist = S.rateHistory.filter(r => r.date && r.date <= t).sort((a, b) => a.date.localeCompare(b.date)); const prev = hist.filter(r => r.date < t).pop() || null;
    // ---- background
    x.fillStyle = '#070605'; x.fillRect(0, 0, W, H);
    const glow = (cx, cy, r, col) => { const g = x.createRadialGradient(cx, cy, 0, cx, cy, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = g; x.fillRect(0, 0, W, H); };
    glow(W * 0.85, H * 0.06, 620, 'rgba(230,194,94,.26)'); glow(W * 0.08, H * 0.94, 560, 'rgba(184,134,43,.20)'); glow(W / 2, H * 0.42, 700, 'rgba(255,236,179,.05)');
    x.save(); x.globalAlpha = 0.05; x.strokeStyle = '#f2d68a'; x.lineWidth = 1; for (let i = -H; i < W; i += 26) { x.beginPath(); x.moveTo(i, 0); x.lineTo(i + H, H); x.stroke(); } x.restore();
    // ---- frame with corner ornaments
    x.strokeStyle = goldGrad(x, 0, 0, W, H); x.lineWidth = 3; rr(x, 26, 26, W - 52, H - 52, 34); x.stroke(); x.lineWidth = 1; x.globalAlpha = 0.55; rr(x, 40, 40, W - 80, H - 80, 24); x.stroke(); x.globalAlpha = 1;
    [[40, 40], [W - 40, 40], [40, H - 40], [W - 40, H - 40]].forEach(([px, py]) => { x.save(); x.translate(px, py); x.rotate(Math.PI / 4); x.fillStyle = '#070605'; x.fillRect(-13, -13, 26, 26); x.fillStyle = goldGrad(x, -9, -9, 9, 9); x.fillRect(-8, -8, 16, 16); x.restore(); });
    const off = tall ? 250 : 0; x.save(); x.translate(0, off); const Z = tall ? { lw: 470, ly: 74, ty: 372, dy: 420, oy: 446, py: 474, rh: 96, hd: 92, g: 20, bh: 172 } : { lw: 400, ly: 62, ty: 318, dy: 362, oy: 388, py: 412, rh: 86, hd: 84, g: 18, bh: 150 };
    // ---- logo
    const lg = await goldLogoCanvas(900); if (lg) { const lw = Z.lw, lh = lw * lg.height / lg.width; x.drawImage(lg, (W - lw) / 2, Z.ly, lw, lh); }
    else { x.fillStyle = goldGrad(x, 300, 100, 780, 240); x.font = `700 92px ${SERIF}`; x.textAlign = 'center'; x.fillText(String(s.firm || 'Shivaa'), W / 2, 210); }
    // ---- title
    x.textAlign = 'center'; x.fillStyle = goldGrad(x, 330, 300, 750, 380); x.font = `800 76px ${HI}`; x.fillText('आज का भाव', W / 2, Z.ty);
    const d = new Date(t + 'T00:00:00'); x.fillStyle = '#cdbf9f'; x.font = `500 31px ${HI}`; x.fillText(`${d.getDate()} ${HM[d.getMonth()]} ${d.getFullYear()}  ·  ${HD[d.getDay()]}`, W / 2, Z.dy);
    const orn = y => { x.strokeStyle = 'rgba(230,194,94,.55)'; x.lineWidth = 1.5; x.beginPath(); x.moveTo(W / 2 - 250, y); x.lineTo(W / 2 - 22, y); x.moveTo(W / 2 + 22, y); x.lineTo(W / 2 + 250, y); x.stroke(); x.save(); x.translate(W / 2, y); x.rotate(Math.PI / 4); x.fillStyle = '#e6c25e'; x.fillRect(-6, -6, 12, 12); x.restore(); }; orn(Z.oy);
    // ---- a metal panel
    const panel = (y, hi, en, rows, key, unitHi, silver) => {
      const X0 = 78, PW = W - 156, rh = Z.rh, HD0 = Z.hd, ph = HD0 + rows.length * rh + 14;
      const bg = x.createLinearGradient(0, y, 0, y + ph); bg.addColorStop(0, silver ? 'rgba(207,214,223,.10)' : 'rgba(255,236,179,.10)'); bg.addColorStop(1, 'rgba(255,255,255,.02)'); x.fillStyle = bg; rr(x, X0, y, PW, ph, 30); x.fill();
      x.strokeStyle = silver ? 'rgba(207,214,223,.42)' : 'rgba(230,194,94,.46)'; x.lineWidth = 1.5; rr(x, X0, y, PW, ph, 30); x.stroke();
      const tone = silver ? (() => { const g = x.createLinearGradient(X0, y, X0 + 300, y + 80); g.addColorStop(0, '#ffffff'); g.addColorStop(0.5, '#cfd6df'); g.addColorStop(1, '#8e99a8'); return g; })() : goldGrad(x, X0, y, X0 + 300, y + 80);
      x.textAlign = 'left'; x.fillStyle = tone; x.font = `800 58px ${HI}`; x.fillText(hi, X0 + 34, y + 68); const hw = x.measureText(hi).width; x.font = `700 24px ${SERIF}`; x.fillStyle = silver ? '#aab4c2' : '#cdbf9f'; x.fillText(en, X0 + 34 + hw + 18, y + 64);
      // change vs the last rate + sparkline
      const cur = num(s[key]), pv = prev ? num(prev[key]) : 0; let cxr = X0 + PW - 34;
      const L = hist.map(r => num(r[key])).filter(v => v > 0).slice(-14); if (cur && L[L.length - 1] !== cur) L.push(cur);
      if (L.length >= 3) { const sw = 150, sh = 42, mn = Math.min(...L), mx = Math.max(...L), sp = mx - mn || 1; x.strokeStyle = tone; x.lineWidth = 3; x.lineJoin = 'round'; x.lineCap = 'round'; x.beginPath(); L.forEach((v2, i) => { const px = cxr - sw + i / (L.length - 1) * sw, py = y + 30 + sh - (v2 - mn) / sp * sh; if (i) x.lineTo(px, py); else x.moveTo(px, py); }); x.stroke(); x.fillStyle = silver ? '#ffffff' : '#fff3c4'; x.beginPath(); x.arc(cxr, y + 30 + sh - (L[L.length - 1] - mn) / sp * sh, 5, 0, 6.2832); x.fill(); cxr -= sw + 22; }
      if (cur && pv && Math.abs(cur - pv) >= 1) { const up = cur > pv; const txt = (up ? '▲ ' : '▼ ') + rupee(Math.abs(cur - pv)); x.font = `800 26px ${EN}`; const tw = x.measureText(txt).width + 34; x.fillStyle = up ? 'rgba(52,211,153,.16)' : 'rgba(248,113,113,.16)'; rr(x, cxr - tw, y + 32, tw, 44, 22); x.fill(); x.fillStyle = up ? '#4ade80' : '#f87171'; x.textAlign = 'center'; x.fillText(txt, cxr - tw / 2, y + 63); }
      x.strokeStyle = silver ? 'rgba(207,214,223,.22)' : 'rgba(230,194,94,.24)'; x.lineWidth = 1; x.beginPath(); x.moveTo(X0 + 30, y + HD0); x.lineTo(X0 + PW - 30, y + HD0); x.stroke();
      rows.forEach(([badge, label, val, small], i) => { const ry = y + HD0 + i * rh, ro = (rh - 96) / 2;
        if (i) { x.strokeStyle = 'rgba(255,255,255,.07)'; x.beginPath(); x.moveTo(X0 + 30, ry); x.lineTo(X0 + PW - 30, ry); x.stroke(); }
        x.fillStyle = tone; rr(x, X0 + 30, ry + 20 + ro, 118, 58, 29); x.fill(); x.fillStyle = '#14100a'; x.textAlign = 'center'; x.font = `800 31px ${EN}`; x.fillText(badge, X0 + 89, ry + 60 + ro);
        x.textAlign = 'left'; x.fillStyle = '#efe7d4'; x.font = `700 34px ${HI}`; x.fillText(label, X0 + 172, ry + 52 + ro); x.fillStyle = '#958a72'; x.font = `500 23px ${HI}`; x.fillText(small, X0 + 172, ry + 82 + ro);
        x.textAlign = 'right'; x.fillStyle = '#ffffff'; x.font = `800 60px ${EN}`; x.fillText(val ? rupee(val) : '—', X0 + PW - 34, ry + 66 + ro); });
      return y + ph;
    };
    let y = Z.py;
    y = panel(y, 'सोना', 'GOLD', [['24K', 'शुद्ध सोना · 999', g24, 'प्रति 10 ग्राम'], ['22K', 'हॉलमार्क · 916', g24 * 0.916, 'प्रति 10 ग्राम'], ['18K', '750', g24 * 0.75, 'प्रति 10 ग्राम']], 'gold24', '', false) + Z.g;
    y = panel(y, 'चाँदी', 'SILVER', [['999', 'शुद्ध चाँदी', sv, 'प्रति किलो'], ['925', 'स्टर्लिंग चाँदी', sv * 0.925, 'प्रति किलो']], 'silver999', '', true) + Z.g;
    // ---- booking + website band
    const bh = Z.bh, X0 = 78, PW = W - 156; x.fillStyle = goldGrad(x, X0, y, X0 + PW, y + bh); rr(x, X0, y, PW, bh, 30); x.fill();
    x.fillStyle = 'rgba(20,16,10,.16)'; x.fillRect(W / 2 - 1, y + 26, 2, bh - 52);
    const half = PW / 2, ink = '#14100a';
    // phone icon
    const icon = (cx, cy, kind) => { x.fillStyle = ink; x.beginPath(); x.arc(cx, cy, 34, 0, 6.2832); x.fill(); x.strokeStyle = '#f2d68a'; x.fillStyle = '#f2d68a'; x.lineWidth = 4; x.lineCap = 'round';
      if (kind === 'phone') { rr(x, cx - 11, cy - 19, 22, 38, 6); x.stroke(); x.beginPath(); x.arc(cx, cy + 11, 2.6, 0, 6.2832); x.fill(); x.beginPath(); x.moveTo(cx - 4, cy - 12); x.lineTo(cx + 4, cy - 12); x.stroke(); }
      else { x.beginPath(); x.arc(cx, cy, 17, 0, 6.2832); x.stroke(); x.beginPath(); x.ellipse(cx, cy, 7.5, 17, 0, 0, 6.2832); x.stroke(); x.beginPath(); x.moveTo(cx - 17, cy); x.lineTo(cx + 17, cy); x.stroke(); } };
    const bo = (bh - 172) / 2; icon(X0 + 58, y + 62 + bo, 'phone'); x.textAlign = 'left'; x.fillStyle = ink; x.font = `700 30px ${HI}`; x.fillText('बुकिंग के लिए कॉल करें', X0 + 104, y + 58 + bo);
    let ph = phone91(cfg().bookPhone || s.phone || '8905005921'); x.font = `800 46px ${EN}`; while (x.measureText(ph).width > half - 50 && parseInt(x.font.match(/(\d+)px/)[1]) > 30) x.font = x.font.replace(/(\d+)px/, (m, n) => (n - 2) + 'px'); x.fillText(ph, X0 + 30, y + 132 + bo);
    icon(X0 + half + 58, y + 62 + bo, 'web'); x.fillStyle = ink; x.textAlign = 'left'; x.font = `700 30px ${HI}`; x.fillText('ऑनलाइन खरीदने के लिए', X0 + half + 104, y + 58 + bo);
    x.font = `800 50px ${EN}`; const st = site(); let wf = 50; x.font = `800 ${wf}px ${EN}`; while (x.measureText(st).width > half - 190 && wf > 30) { wf -= 2; x.font = `800 ${wf}px ${EN}`; } x.fillText(st, X0 + half + 30, y + 134 + bo); const sw2 = x.measureText(st).width; x.font = `700 32px ${HI}`; x.fillText('पर जाएँ', X0 + half + 30 + sw2 + 16, y + 132 + bo);
    y += bh;
    x.textAlign = 'center'; x.fillStyle = '#958a72'; x.font = `500 24px ${HI}`; x.fillText('भाव में GST और मजदूरी अलग से  ·  Rates exclude GST & making', W / 2, y + (tall ? 44 : 40));
    x.restore();
    if (tall) { x.textAlign = 'center'; x.fillStyle = goldGrad(x, 300, 0, 780, 0); x.font = `700 30px ${SERIF}`; x.fillText(String(s.tagline || '').toUpperCase(), W / 2, 150); x.strokeStyle = 'rgba(230,194,94,.5)'; x.lineWidth = 1.5; x.beginPath(); x.moveTo(W / 2 - 200, 178); x.lineTo(W / 2 + 200, 178); x.stroke();
      x.fillStyle = '#cdbf9f'; x.font = `500 26px ${EN}`; const ad = String(s.address || ''); x.fillText(ad.length > 62 ? ad.slice(0, 60) + '…' : ad, W / 2, H - 150); x.fillStyle = goldGrad(x, 400, 0, 680, 0); x.font = `800 40px ${HI}`; x.fillText('धन्यवाद  🙏', W / 2, H - 92); }
    return c;
  }
  rateCardPng = function (fmt) { return rateCardCanvas(fmt === 'status').then(c => new Promise(res => c.toBlob(b => res(b), 'image/png'))).catch(e => { console.error(e); return null; }); };
  { const _txt = rateCardText; rateCardText = function () { const s = settings(); return _txt.call(this) + `\n\n📞 बुकिंग के लिए कॉल करें: ${phone91(cfg().bookPhone || s.phone)}\n🌐 ऑनलाइन खरीदने के लिए ${site()} पर जाएँ`; }; }

  let RC = null;
  async function openRateCard(fmt) {
    if (!num(settings().gold24) && !num(settings().silver999)) return toast('Pehle aaj ke rate set kijiye', 'err');
    fmt = fmt || 'post'; toast('Rate card ban raha hai…'); const blob = await rateCardPng(fmt); if (!blob) return toast('Image nahi ban payi', 'err');
    if (RC && RC.url) URL.revokeObjectURL(RC.url); RC = { blob, fmt, url: URL.createObjectURL(blob), name: `shivaa_rate_card_${todayStr()}${fmt === 'status' ? '_status' : ''}.png` };
    const old = [...document.querySelectorAll('#modal-root .overlay')].find(o => o._rc); if (old) closeModal(old);
    const el = openModal(`${mHead('Aaj ka rate card', 'Image (PNG) — WhatsApp status, group ya Instagram par bhejiye')}<div class="m-body"><div class="seg" style="margin-bottom:12px"><button type="button" data-act="rc-fmt" data-v="post" class="${fmt === 'post' ? 'on' : ''}">Post 4:5</button><button type="button" data-act="rc-fmt" data-v="status" class="${fmt === 'status' ? 'on' : ''}">Status / Story 9:16</button></div><div class="rc-prev"><img src="${RC.url}" alt="Rate card"></div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Close</button><button type="button" class="btn" data-act="rc-save">${ic('dl', 16)} Image download</button><button type="button" class="btn gold" data-act="rc-share">Share / WhatsApp</button></div>`);
    el._rc = true;
  }
  if (typeof ACT2 !== 'undefined') ACT2['cat-ratecard'] = () => openRateCard('post');
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act]'); if (!t) return; const a = t.dataset.act;
    try {
      if (a === 'rc-open') return openRateCard('post');
      if (a === 'rc-fmt') return openRateCard(t.dataset.v);
      if (!RC) return;
      if (a === 'rc-save') return offerDownload(RC.name, RC.blob);
      if (a === 'rc-share') { const f = new File([RC.blob], RC.name, { type: 'image/png' }); if (navigator.canShare && navigator.canShare({ files: [f] })) { try { await navigator.share({ files: [f], text: 'Aaj ka bhaav — ' + (settings().firm || 'Shivaa') }); } catch (er) { /* cancelled */ } } else { await offerDownload(RC.name, RC.blob); toast('Image download ho gayi — ab WhatsApp mein attach kijiye'); } }
    } catch (er) { console.error(er); toast('Kuch gadbad hui — dobara try kijiye', 'err'); }
  });
  // quick button on the dashboard hero
  if (typeof refreshHero === 'function') { const _rh = refreshHero; refreshHero = function () { const r = _rh.apply(this, arguments); const u = document.getElementById('hero-upd'); if (u && !document.getElementById('rc-quick')) u.insertAdjacentHTML('afterend', '<div style="text-align:center;margin-top:10px"><button type="button" class="btn sm" id="rc-quick" data-act="rc-open">🖼 Rate card image banao</button></div>'); return r; }; }
  window.SJ_BILL.rateCardCanvas = rateCardCanvas; window.SJ_BILL.openRateCard = openRateCard;
})();

// on-screen GST bill: the same royal skin as the PDF (classic setting keeps the old look)
{ const _bdh = billDocHTML; billDocHTML = function (v) { const html = _bdh.apply(this, arguments); try { return (window.SJ_PRO ? SJ_PRO.proCfg() : {}).billStyle === 'classic' ? html : '<div class="rb">' + html + '</div>'; } catch (e) { return html; } }; }
