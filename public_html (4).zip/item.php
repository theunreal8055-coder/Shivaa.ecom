<?php
/* Shivaa Jewels — one jewellery piece, opened from its QR code (item.php?i=…&k=…). */
$_GET['a'] = 'item';
$_SERVER['REQUEST_METHOD'] = 'GET';
require __DIR__ . '/sj-api.php';
