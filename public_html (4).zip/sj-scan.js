/* =====================================================================
   Shivaa Jewels — SCAN ENGINE + KAANTA (v41)
   SJ_SCAN.session(o)  one scanning screen for everything (challan issue,
                       every shop's entry / exit, evening return, floor
                       transfer, floor tally, stock audit)
     • RFID reader that types like a keyboard (most handhelds / desktop
       readers: "keyboard wedge"), barcode gun, phone camera (QR), or a
       USB / Bluetooth-serial reader (Web Serial, Chrome on computer)
     • knows what SHOULD be there → shows what is missing / extra
     • "ginti 3 second tak same" stability check for bulk RFID reads
     • optional total weight check on the kaanta with tolerance
   SJ_SCALE            kaanta over USB / RS232 (Web Serial): live weight,
                       "stable" detection, ⚖ button next to every weight
                       box in the bill; manual weights are flagged
   RFID tag jodo       bind an RFID tag (EPC) to a stock piece
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const q$ = (s, r) => (r || document).querySelector(s), q$$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const pol = () => (window.SJ_SEC && SJ_SEC.policy) || { tolG: 0.10, tolPc: 0.02 };
  const css = t => { const s = document.createElement('style'); s.textContent = t; document.head.appendChild(s); };
  function beep(ok) { try { const a = new (window.AudioContext || window.webkitAudioContext)(); const o = a.createOscillator(), g = a.createGain(); o.frequency.value = ok === false ? 320 : 1250; g.gain.value = 0.07; o.connect(g); g.connect(a.destination); o.start(); setTimeout(() => { o.stop(); a.close(); }, ok === false ? 260 : 80); } catch (e) { /* no audio */ } }
  const buzz = p => { try { navigator.vibrate && navigator.vibrate(p); } catch (e) { /* */ } };

  /* yes / no question that resolves either way (confirmBox only reports "yes") */
  window.SJ_CONFIRM = function (msg, yesLabel) {
    return new Promise(res => { let v = false; const el = openModal(`<div class="m-head"><h3>Pakka?</h3></div><div class="m-body"><p style="margin:0;white-space:pre-line">${esc(String(msg)).replace(/&lt;(\/?)b&gt;/g, '<$1b>')}</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Nahi</button><button type="button" class="btn gold" data-sjc-yes>${esc(yesLabel || 'Haan')}</button></div>`, { small: true });
      q$('[data-sjc-yes]', el).onclick = () => { v = true; closeModal(el); };
      new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); res(v); } }).observe(q$('#modal-root'), { childList: true }); });
  };
  /* one-line text question (instead of the browser's plain prompt) */
  window.SJ_ASK = function (title, label, o) {
    o = o || {};
    return new Promise(res => { let v = null; const el = openModal(`<form novalidate>${mHead(esc(title), esc(o.sub || ''))}<div class="m-body"><label class="f"><span>${esc(label)}</span>${o.area ? `<textarea name="v" rows="3" placeholder="${esc(o.ph || '')}"></textarea>` : `<input name="v" autocomplete="off" placeholder="${esc(o.ph || '')}" value="${esc(o.val || '')}"${o.mono ? ' class="mono"' : ''}>`}</label></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">${esc(o.ok || 'Aage')}</button></div></form>`, { small: true });
      const i = q$('[name=v]', el); setTimeout(() => i.focus(), 50);
      q$('form', el).onsubmit = ev => { ev.preventDefault(); const t = String(i.value || '').trim(); if (!t && !o.allowEmpty) { i.focus(); return; } v = t; closeModal(el); };
      new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); res(v); } }).observe(q$('#modal-root'), { childList: true }); });
  };
  /* ---------------- code → piece ---------------- */
  const normEpc = s => String(s || '').toUpperCase().replace(/[^0-9A-F]/g, '');
  const normSku = s => String(s || '').trim().replace(/^#/, '').toUpperCase();
  function codeOf(raw) {
    const s = String(raw || '').trim(); if (!s) return '';
    const m = s.match(/[?&](?:sku|s|i)=([A-Za-z0-9_-]+)/); if (m) return m[1];
    return s;
  }
  let IDX = null, IDXN = -1;
  function index() {
    const n = S.products.length + '|' + (S.products[S.products.length - 1] || {}).updatedAt;
    if (IDX && IDXN === n) return IDX;
    const epc = new Map(), sku = new Map(), huid = new Map(), id = new Map();
    S.products.forEach(p => { id.set(p.id, p); if (p.rfid) epc.set(normEpc(p.rfid), p); if (p.sku) sku.set(normSku(p.sku), p); if (p.huid) huid.set(String(p.huid).toUpperCase(), p); });
    IDXN = n; return (IDX = { epc, sku, huid, id });
  }
  function find(raw) {
    const c = codeOf(raw); if (!c) return null; const I = index();
    const e = normEpc(c); if (e.length >= 8 && I.epc.has(e)) return I.epc.get(e);
    const k = normSku(c); return I.sku.get(k) || I.huid.get(k) || I.id.get(c) || null;
  }

  /* ---------------- Web Serial line reader (RFID desk reader / kaanta) ---------------- */
  const HAS_SERIAL = 'serial' in navigator;
  async function openSerial(baud, onLine, onClose) {
    const port = await navigator.serial.requestPort();
    await port.open({ baudRate: baud || 9600 });
    let alive = true, reader = null; const dec = new TextDecoder();
    (async () => {
      let buf = '';
      try {
        while (alive && port.readable) {
          reader = port.readable.getReader();
          try { for (;;) { const { value, done } = await reader.read(); if (done) break; buf += dec.decode(value, { stream: true }); let i; while ((i = buf.search(/[\r\n]/)) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (line) onLine(line); } if (buf.length > 400) buf = buf.slice(-200); } }
          finally { try { reader.releaseLock(); } catch (e) { /* */ } }
        }
      } catch (e) { console.warn('[serial]', e); }
      try { await port.close(); } catch (e) { /* */ } onClose && onClose();
    })();
    return { close: async () => { alive = false; try { reader && await reader.cancel(); } catch (e) { /* */ } } };
  }

  /* ---------------- KAANTA (scale) ---------------- */
  const SC = { port: null, w: null, stable: false, at: 0, hist: [], unit: 'g', subs: new Set() };
  function parseWeight(line) {
    const m = String(line).match(/([-+]?\s*\d+(?:[.,]\d+)?)\s*(kg|g|gm|ct|tl)?/i); if (!m) return null;
    let v = parseFloat(m[1].replace(/\s/g, '').replace(',', '.')); const u = (m[2] || 'g').toLowerCase();
    if (u === 'kg') v *= 1000; if (u === 'ct') v *= 0.2; if (!isFinite(v)) return null;
    const flag = /\bST\b|STABLE/i.test(line) ? true : /\bUS\b|UNSTABLE|MOTION/i.test(line) ? false : null;
    return { v: Math.round(v * 1000) / 1000, flag };
  }
  function onScaleLine(line) {
    const r = parseWeight(line); if (!r) return; const now = Date.now();
    SC.hist.push({ v: r.v, at: now }); SC.hist = SC.hist.filter(h => now - h.at < 1500);
    const same = SC.hist.length >= 3 && SC.hist.every(h => Math.abs(h.v - r.v) < 0.0015);
    SC.w = r.v; SC.stable = r.flag === null ? same : r.flag && same; SC.at = now;
    SC.subs.forEach(f => { try { f(SC); } catch (e) { /* */ } }); paintChip();
  }
  async function scaleConnect() {
    if (!HAS_SERIAL) { toast('Kaanta jodne ke liye computer par Chrome / Edge chahiye (Web Serial). Phone par weight haath se likhiye.', 'err'); return false; }
    try {
      const baud = num((settings().pro || {}).scaleBaud) || 9600;
      SC.port = await openSerial(baud, onScaleLine, () => { SC.port = null; SC.w = null; paintChip(); toast('Kaanta disconnect ho gaya', 'err'); });
      toast('⚖ Kaanta jud gaya — weight aate hi dikhega'); paintChip(); return true;
    } catch (e) { if (e && e.name !== 'NotFoundError') toast('Kaanta nahi juda: ' + (e.message || e), 'err'); return false; }
  }
  function scaleNow(maxAgeMs) { return SC.port && SC.w !== null && SC.stable && Date.now() - SC.at < (maxAgeMs || 4000) ? SC.w : null; }
  let chip = null;
  function paintChip() {
    if (!chip) { chip = document.createElement('button'); chip.type = 'button'; chip.className = 'sc-chip'; chip.dataset.act = 'sc-chip'; document.body.appendChild(chip); }
    chip.style.display = SC.port ? 'flex' : 'none';
    chip.innerHTML = SC.w === null ? '⚖ <b>—</b>' : `⚖ <b>${SC.w.toFixed(3)} g</b>${SC.stable ? '<i>stable</i>' : '<i class="mv">hil raha</i>'}`;
  }
  // ⚖ button next to every weight box in the bill builder; typed weights are marked "manual"
  function decorate(root) {
    q$$('.item [data-f="gross"]', root).forEach(inp => {
      if (inp.dataset.scDone) return; inp.dataset.scDone = '1';
      const b = document.createElement('button'); b.type = 'button'; b.className = 'sc-take'; b.dataset.act = 'sc-take'; b.title = 'Kaante se weight lo'; b.textContent = '⚖';
      inp.insertAdjacentElement('afterend', b); inp.parentElement.classList.add('sc-wrap');
    });
  }
  new MutationObserver(() => { const r = q$('#modal-root'); if (r && r.querySelector('.item [data-f="gross"]:not([data-sc-done])')) decorate(r); }).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('input', e => {
    const t = e.target; if (!t.matches || !t.matches('.item [data-f="gross"]') || typeof INV === 'undefined' || !INV) return;
    const it = INV.items[+t.closest('.item').dataset.idx]; if (!it) return;
    it.wSrc = e.isTrusted ? (SC.port ? 'manual' : (it.wSrc === 'scale' ? 'manual' : '')) : it.wSrc;
  }, true);
  function takeWeight(btn) {
    const inp = btn.parentElement.querySelector('[data-f="gross"]'); if (!inp) return;
    if (!SC.port) { scaleConnect(); return; }
    const w = scaleNow(); if (w === null) { toast(SC.w === null ? 'Kaante se weight nahi aa raha' : 'Kaanta abhi hil raha hai — ruk kar dobara dabaiye', 'err'); return; }
    if (w <= 0) { toast('Kaante par kuch nahi rakha', 'err'); return; }
    const it = typeof INV !== 'undefined' && INV ? INV.items[+inp.closest('.item').dataset.idx] : null;
    inp.value = w.toFixed(3); if (it) it.wSrc = 'scale';
    inp.dispatchEvent(new Event('input', { bubbles: true })); if (it) it.wSrc = 'scale';
    inp.classList.add('sc-ok'); setTimeout(() => inp.classList.remove('sc-ok'), 900); beep();
  }
  // keep wSrc on the saved bill (the bill saver keeps only known fields)
  if (typeof persistInvoice === 'function') {
    const P0 = persistInvoice;
    persistInvoice = async function (st) {
      const src = (st.items || []).map(it => ({ g: num(it.gross), c: it.category, p: it.purity, w: it.wSrc || '' }));
      const r = await P0.apply(this, arguments);
      try {
        if (r && r.inv && src.some(x => x.w)) {
          const used = new Set();
          const items = r.inv.items.map(it => { const k = src.findIndex((x, n) => !used.has(n) && Math.abs(x.g - num(it.gross)) < 0.0005 && x.c === it.category && x.p === it.purity); if (k < 0) return it; used.add(k); return src[k].w ? { ...it, wSrc: src[k].w } : it; });
          if (items.some((it, n) => it.wSrc !== r.inv.items[n].wSrc)) { r.inv = { ...r.inv, items }; await save('invoices', r.inv, { quiet: true }); }
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }

  /* ---------------- SCAN SESSION ---------------- */
  let SEQ = 0;
  function session(o) {
    return new Promise(resolve => {
      o = o || {}; const id = 'scn' + (++SEQ);
      const exp = new Map((o.expected || []).map(pid => [pid, S.products.find(p => p.id === pid) || { id: pid, sku: '?', category: 'Piece', net: 0, gross: 0 }]));
      const pool = o.pool ? new Set(o.pool) : null;
      const seen = new Map(), extra = new Map(); let lastChange = Date.now(), done = false, serial = null;
      const verify = exp.size > 0;
      const el = openModal(`${mHead(esc(o.title || 'Scan'), esc(o.sub || (verify ? 'Saare piece scan kijiye — kya kam hai, software batayega' : 'Piece ek-ek karke scan kijiye')))}<div class="m-body scn">
        <div class="scn-top"><div class="scn-count"><b data-o="n">0</b><span>${verify ? '/ ' + exp.size + ' mile' : 'piece'}</span></div><div class="scn-bar"><i data-o="bar"></i></div><div class="scn-st" data-o="st">${verify ? 'Scan shuru kijiye' : ''}</div></div>
        <div class="scn-in"><input id="${id}-in" class="scn-q" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="RFID / QR / SKU — reader se scan kijiye ya likhiye" aria-label="Scan code"><button type="button" class="btn" data-act="sjx-cam" data-for="${id}-in" data-cont="1" data-title="${esc(o.title || 'Scan')}">📷 Camera</button>${HAS_SERIAL ? `<button type="button" class="btn" data-act="scn-serial">🔌 Reader</button>` : ''}</div>
        ${o.weight ? `<div class="scn-w"><label class="f"><span>Kaante par kul weight (g)</span><input type="number" step="0.001" inputmode="decimal" data-o="w" placeholder="0.000"></label><button type="button" class="btn" data-act="scn-scale">⚖ Kaante se lo</button><div class="scn-wr" data-o="wr">${verify ? 'Hona chahiye: <b>' + g3(sum([...exp.values()], p => p.gross)) + '</b>' : ''}</div></div>` : ''}
        <div class="scn-lists">${verify ? '<div class="scn-col"><h4>❌ Nahi mile <span data-o="mc"></span></h4><div data-o="miss" class="scn-l"></div></div>' : ''}<div class="scn-col"><h4>✅ ${verify ? 'Mile' : 'Scan hue'} <span data-o="sc"></span></h4><div data-o="seen" class="scn-l"></div></div><div class="scn-col"><h4>⚠ ${verify ? 'Zyada / anjaan' : 'Anjaan code'} <span data-o="xc"></span></h4><div data-o="extra" class="scn-l"></div></div></div>
        ${o.note ? `<p class="small muted" style="margin:8px 0 0">${o.note}</p>` : ''}
      </div><div class="m-foot"><button type="button" class="btn" data-act="scn-cancel">Cancel</button>${verify ? '<button type="button" class="btn" data-act="scn-short">Kam ke saath aage</button>' : ''}<button type="button" class="btn gold" data-act="scn-done">${esc(o.doneLabel || 'Ho gaya')}</button></div>`, { wide: true });
      el.classList.add('scn-ov'); const inp = q$('#' + id + '-in', el); const out = k => q$(`[data-o="${k}"]`, el);
      const row = (p, cls, tag) => `<div class="scn-r ${cls || ''}"><b class="mono">#${esc(p.sku || '?')}</b><span>${esc(p.category || '')} ${esc(p.purity || '')}</span><small>${g3(p.net || p.gross)}</small>${tag ? `<em>${esc(tag)}</em>` : ''}</div>`;
      function paint() {
        const n = verify ? [...exp.keys()].filter(k => seen.has(k)).length : seen.size;
        out('n').textContent = n; out('bar').style.width = (verify ? (exp.size ? n / exp.size * 100 : 0) : Math.min(100, n * 5)) + '%';
        if (verify) { const miss = [...exp.values()].filter(p => !seen.has(p.id)); out('miss').innerHTML = miss.slice(0, 200).map(p => row(p, 'miss')).join('') || '<div class="small muted">Sab mil gaye 🎉</div>'; out('mc').textContent = miss.length ? '(' + miss.length + ')' : ''; }
        out('seen').innerHTML = [...seen.values()].slice(-60).reverse().map(p => row(p)).join('') || '<div class="small muted">Abhi kuch nahi</div>'; out('sc').textContent = seen.size ? '(' + seen.size + ')' : '';
        out('extra').innerHTML = [...extra.values()].map(x => x.p ? row(x.p, 'xtra', x.why) : `<div class="scn-r xtra"><b class="mono">${esc(x.code.slice(0, 26))}</b><span>${esc(x.why)}</span></div>`).join('') || '<div class="small muted">—</div>'; out('xc').textContent = extra.size ? '(' + extra.size + ')' : '';
        paintW();
      }
      function paintW() {
        if (!o.weight) return; const wi = out('w'); const wr = out('wr'); if (!wi || !wr) return;
        const expW = verify ? sum([...exp.values()], p => p.gross) : sum([...seen.values()], p => p.gross);
        const cnt = verify ? exp.size : seen.size; const tol = num(pol().tolG) + num(pol().tolPc) * cnt;
        if (wi.value === '') { wr.innerHTML = 'Hona chahiye: <b>' + g3(expW) + '</b>'; return; }
        const d = r3(num(wi.value) - expW); const ok = Math.abs(d) <= tol + 1e-9;
        wr.innerHTML = `Hona chahiye <b>${g3(expW)}</b> · fark <b class="${ok ? 'green' : 'red'}">${d > 0 ? '+' : ''}${d.toFixed(3)} g</b> ${ok ? '✓' : '✗ (seema ±' + tol.toFixed(3) + ' g)'}`;
      }
      function add(raw, via) {
        const code = String(raw || '').trim(); if (!code || done) return;
        if (code.indexOf('\n') >= 0 || code.indexOf(',') >= 0 && code.split(',').length > 2) { code.split(/[\n,]+/).forEach(c => add(c, via)); return; }
        const p = find(code);
        if (!p) { const k = 'c:' + code; if (!extra.has(k)) { extra.set(k, { code, why: 'Ye code kisi piece se nahi juda' }); beep(false); buzz(150); lastChange = Date.now(); paint(); } return; }
        if (seen.has(p.id) || extra.has(p.id)) return;
        if (verify && !exp.has(p.id)) { extra.set(p.id, { p, why: 'Is list mein nahi tha' }); beep(false); buzz([80, 60, 80]); lastChange = Date.now(); paint(); return; }
        if (!verify && pool && !pool.has(p.id)) { extra.set(p.id, { p, why: o.poolWhy || 'Is bag / list ka nahi' }); beep(false); buzz([80, 60, 80]); lastChange = Date.now(); paint(); return; }
        if (!verify && o.accept) { const why = o.accept(p); if (why) { extra.set(p.id, { p, why }); beep(false); lastChange = Date.now(); paint(); return; } }
        seen.set(p.id, p); beep(); lastChange = Date.now(); paint();
      }
      // keyboard-wedge readers type very fast and end with Enter; bulk readers may paste many lines
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); const v = inp.value; inp.value = ''; add(v, 'key'); } }, true);
      inp.addEventListener('paste', e => { const t = (e.clipboardData || window.clipboardData).getData('text'); if (t && /[\n,]/.test(t)) { e.preventDefault(); add(t, 'paste'); } });
      el.addEventListener('input', e => { if (e.target === out('w')) paintW(); });
      const keepFocus = () => { if (!done && document.activeElement !== inp && !el.querySelector('input:focus:not(.scn-q)') && !q$('.sjx-cam')) inp.focus({ preventScroll: true }); };
      const fT = setInterval(keepFocus, 800);
      const stT = setInterval(() => { if (!verify || done) return; const st = out('st'); const n = [...exp.keys()].filter(k => seen.has(k)).length; const quiet = Date.now() - lastChange;
        st.innerHTML = n === exp.size ? '<b class="green">✓ Sab piece mil gaye</b>' : (quiet > 3000 && seen.size ? `<b class="red">Ginti ${Math.round(quiet / 1000)}s se ruki hai — ${exp.size - n} piece nahi mile</b>` : 'Scan chal raha hai…'); }, 500);
      function finish(kind) {
        if (done) return; const missing = verify ? [...exp.keys()].filter(k => !seen.has(k)) : [];
        const wv = o.weight && out('w') && out('w').value !== '' ? num(out('w').value) : null;
        const expW = verify ? sum([...exp.values()], p => p.gross) : sum([...seen.values()], p => p.gross);
        const cnt = verify ? exp.size : seen.size; const tol = num(pol().tolG) + num(pol().tolPc) * cnt;
        const wDiff = wv === null ? null : r3(wv - (verify ? sum([...exp.values()].filter(p => seen.has(p.id)), p => p.gross) : expW));
        if (kind === 'done' && verify && missing.length) { toast(`${missing.length} piece abhi nahi mile — dhoondh kar scan kijiye, ya "Kam ke saath aage" dabaiye`, 'err'); return; }
        if (kind !== 'cancel' && o.weight && o.weightRequired && wv === null) { toast('Kaante ka kul weight daaliye', 'err'); out('w').focus(); return; }
        done = true; clearInterval(fT); clearInterval(stT); if (serial) serial.close();
        closeModal(el);
        resolve(kind === 'cancel' ? null : { seen: [...seen.keys()], missing, extra: [...extra.values()].map(x => x.p ? x.p.id : x.code), extraCodes: [...extra.values()].filter(x => !x.p).map(x => x.code), weight: wv, wDiff, wBad: wDiff !== null && Math.abs(wDiff) > tol + 1e-9, tol, short: kind === 'short', at: Date.now() });
      }
      el._scn = { add, finish, setSerial: s => { serial = s; }, paintW };
      new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); if (!done) { done = true; clearInterval(fT); clearInterval(stT); if (serial) serial.close(); resolve(null); } } }).observe(q$('#modal-root'), { childList: true });
      (o.preset || []).forEach(pid => { const p = S.products.find(x => x.id === pid); if (p) seen.set(p.id, p); });
      paint(); setTimeout(() => inp.focus(), 60);
    });
  }

  /* ---------------- RFID tag jodo (bind EPC → piece) ---------------- */
  function bindTool() {
    const el = openModal(`${mHead('🏷 RFID tag jodo', 'Pehle tag scan kijiye, phir us piece ka SKU / QR — dono jud jayenge')}<div class="m-body">
      <div class="scn-in"><input id="bnd-in" class="scn-q" autocomplete="off" placeholder="Tag ya SKU scan kijiye" aria-label="Scan"><button type="button" class="btn" data-act="sjx-cam" data-for="bnd-in" data-cont="1" data-title="Piece ka QR">📷 Camera</button></div>
      <div class="bnd-st" data-o="st">1️⃣ RFID tag scan kijiye</div><div class="scn-l" data-o="log"></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`, { wide: true });
    const inp = q$('#bnd-in', el); let epc = ''; const log = q$('[data-o="log"]', el), st = q$('[data-o="st"]', el);
    inp.addEventListener('keydown', async e => {
      if (e.key !== 'Enter') return; e.preventDefault(); e.stopPropagation(); const v = inp.value.trim(); inp.value = ''; if (!v) return;
      const p = find(v); const isEpc = normEpc(v).length >= 16 && normEpc(v) === v.toUpperCase().replace(/[^0-9A-F]/g, '') && !p;
      if (!epc) {
        if (p && p.rfid && normEpc(p.rfid) === normEpc(v)) { st.innerHTML = `Ye tag pehle se <b>#${esc(p.sku)}</b> se juda hai`; beep(false); return; }
        if (!isEpc) { st.innerHTML = '⚠ Pehle RFID tag scan kijiye (lamba code, jaise E2801170…)'; beep(false); return; }
        epc = normEpc(v); st.innerHTML = `2️⃣ Tag <b class="mono">${esc(epc.slice(-10))}</b> mila — ab us piece ka SKU / QR scan kijiye`; beep(); return;
      }
      if (!p) { st.innerHTML = '⚠ Ye SKU nahi mila — dobara scan kijiye'; beep(false); return; }
      const clash = S.products.find(x => x.id !== p.id && x.rfid && normEpc(x.rfid) === epc);
      if (clash) { st.innerHTML = `⚠ Ye tag pehle se <b>#${esc(clash.sku)}</b> se juda hai — pehle wahan se hataiye`; beep(false); epc = ''; return; }
      if (await save('products', { ...p, rfid: epc, updatedAt: Date.now() })) { log.insertAdjacentHTML('afterbegin', `<div class="scn-r"><b class="mono">#${esc(p.sku)}</b><span>${esc(p.category)} ${esc(p.purity)}</span><small class="mono">${esc(epc.slice(-10))}</small><em>✓ juda</em></div>`); beep(); IDX = null; }
      epc = ''; st.innerHTML = '1️⃣ Agla RFID tag scan kijiye';
    }, true);
    setTimeout(() => inp.focus(), 60);
  }

  /* ---------------- clicks ---------------- */
  const ACT = {
    'scn-cancel': t => { const el = t.closest('.overlay'); el && el._scn && el._scn.finish('cancel'); },
    'scn-done': t => { const el = t.closest('.overlay'); el && el._scn && el._scn.finish('done'); },
    'scn-short': async t => { const el = t.closest('.overlay'); if (el && el._scn && await SJ_CONFIRM('Kuch piece nahi mile — phir bhi aage badhein? Ye gadbad record hogi aur Owner / Manager ko alert jayega.', 'Haan, aage')) el._scn.finish('short'); },
    'scn-serial': async t => { const el = t.closest('.overlay'); if (!el || !el._scn) return; try { const s = await openSerial(num((settings().pro || {}).rfidBaud) || 115200, line => { const m = line.match(/[0-9A-Fa-f]{16,32}/g); (m || [line]).forEach(c => el._scn.add(c, 'serial')); }); el._scn.setSerial(s); t.textContent = '🔌 Reader juda'; t.disabled = true; } catch (e) { if (e && e.name !== 'NotFoundError') toast('Reader nahi juda: ' + (e.message || e), 'err'); } },
    'scn-scale': async t => { const el = t.closest('.overlay'); const w = scaleNow(); if (!SC.port) { await scaleConnect(); return; } if (w === null) return toast('Kaanta abhi stable nahi — ruk kar dobara dabaiye', 'err'); const i = q$('[data-o="w"]', el); i.value = w.toFixed(3); el._scn.paintW(); beep(); },
    'sc-take': t => takeWeight(t),
    'sc-chip': async () => { if (!SC.port) scaleConnect(); else if (await SJ_CONFIRM('Kaanta disconnect karein?', 'Disconnect')) { try { await SC.port.close(); } catch (e) { /* */ } SC.port = null; paintChip(); } },
    'scn-bind': () => bindTool(),
    'sc-connect': () => scaleConnect()
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="scn-"],[data-act^="sc-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);

  window.SJ_SCAN = { session, find, bindTool, normEpc };
  window.SJ_SCALE = { connect: scaleConnect, now: scaleNow, state: () => ({ on: !!SC.port, w: SC.w, stable: SC.stable }), sub: f => { SC.subs.add(f); return () => SC.subs.delete(f); }, has: HAS_SERIAL };

  css(`.scn .scn-top{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;align-items:center;margin-bottom:12px}.scn-count{grid-row:1/3;display:flex;align-items:baseline;gap:6px}.scn-count b{font:700 40px/1 var(--serif,Georgia,serif);color:var(--gold)}.scn-count span{color:var(--muted);font-size:13px}
    .scn-bar{height:8px;border-radius:8px;background:var(--line);overflow:hidden}.scn-bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#b98a2d,#f2d68a);transition:width .25s}.scn-st{font-size:12.5px;color:var(--muted)}
    .scn-in{display:flex;gap:8px;margin-bottom:12px}.scn-q{flex:1;min-width:0;font:600 16px/1.2 ui-monospace,monospace!important;letter-spacing:.5px;padding:14px!important;border:2px solid var(--gold-line,rgba(212,175,55,.45))!important}
    .scn-w{display:grid;grid-template-columns:minmax(0,220px) auto 1fr;gap:10px;align-items:end;margin-bottom:12px}.scn-wr{font-size:13px;padding-bottom:10px}
    .scn-lists{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}.scn-col h4{margin:0 0 6px;font-size:13px}.scn-l{max-height:34vh;overflow:auto;border:1px solid var(--line);border-radius:12px}
    .scn-r{display:grid;grid-template-columns:auto 1fr auto;gap:2px 10px;align-items:center;padding:7px 10px;border-bottom:1px solid var(--line);font-size:13px}.scn-r:last-child{border-bottom:0}.scn-r em{grid-column:1/-1;font-style:normal;font-size:11.5px;color:var(--muted)}.scn-r.miss b{color:var(--red,#fb7185)}.scn-r.xtra b{color:#f59e0b}
    .scn-ov .m-foot{flex-wrap:wrap}.bnd-st{margin:4px 0 10px;font-size:14px}
    .sc-chip{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(52px + env(safe-area-inset-bottom));z-index:95;display:none;align-items:center;gap:8px;padding:8px 14px;border-radius:999px;border:1px solid var(--gold-line,rgba(212,175,55,.45));background:var(--card);color:var(--ink);font:600 13px system-ui;box-shadow:0 8px 20px rgba(0,0,0,.35);cursor:pointer}.sc-chip i{font-style:normal;font-size:11px;color:#22c55e}.sc-chip i.mv{color:#f59e0b}
    .sc-wrap{position:relative}.sc-take{position:absolute;right:4px;top:50%;transform:translateY(-50%);border:0;background:transparent;font-size:16px;cursor:pointer;padding:4px 6px;border-radius:8px}.sc-take:hover{background:var(--gold-soft,rgba(212,175,55,.12))}.sc-wrap input{padding-right:34px!important}.sc-ok{box-shadow:0 0 0 3px rgba(34,197,94,.45)!important}
    @media(max-width:640px){.scn-w{grid-template-columns:1fr auto}.scn-wr{grid-column:1/-1;padding:0}.scn-in{flex-wrap:wrap}.scn-q{flex-basis:100%}.sc-chip{bottom:calc(84px + env(safe-area-inset-bottom))}}`);
})();
