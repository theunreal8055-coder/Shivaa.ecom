/* =====================================================================
   SJ INSIGHTS — interactive charts & tracking
   - Reports → "Analytics" tab (sector × metal, trends, categories,
     parties, receivables, rates, stock value, activity calendar)
   - every existing report chart becomes interactive
   - Dashboard "Business pulse" + smart alerts
   - "Target" page: 700 B2B + 1100 retail goal, fully visual
   ===================================================================== */
(() => {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined' || typeof SJC === 'undefined') return;
  const C = { gold: 'var(--v1)', silver: 'var(--v2)', retail: 'var(--v3)', buy: 'var(--v4)', whole: 'var(--v5)', pink: 'var(--v6)', gray: 'var(--v0)' };
  const P = () => window.SJ_PRO || null;
  const wt = (g, m) => m === 'silver' && Math.abs(num(g)) >= 1000 ? (num(g) / 1000).toFixed(3) + ' kg' : g3(g);
  const card = (title, sub, body, extra) => body ? `<div class="card ch-card"><div class="card-h"><div><h3>${title}</h3>${sub ? `<div class="small muted">${sub}</div>` : ''}</div>${extra || ''}</div>${body}</div>` : '';
  const delta = (cur, prev) => { if (prev == null || !isFinite(prev) || Math.abs(prev) < 0.5) return ''; const d = (cur - prev) / Math.abs(prev) * 100; return `<span class="${d >= 0 ? 'green' : 'red'}">${d >= 0 ? '▲' : '▼'} ${Math.abs(d) >= 100 ? Math.round(Math.abs(d)) : Math.abs(d).toFixed(1)}%</span>`; };

  /* every existing bar chart in Reports → interactive */
  { const map = c => c === 'var(--c1)' ? C.gold : c === 'var(--c2)' ? C.silver : c; miniChart = function (rows, series, fmt) { if (!rows || !rows.length) return ''; return SJC.bars(rows, series.map(s => ({ ...s, c: map(s.c) })), { fmt, wide: true }); }; }

  /* ================= Reports → Analytics ================= */
  function sectorMatrix(SL, prevSL, ch) {
    const cell = (L, metal, c) => { if (!L) return null; const X = L.filter(l => l.metal === metal && ch.get(l.invId) === c); const s = sumLines(X); return { amount: s.amount, net: s.net, fine: s.fine, gFine: s.gainFine, gValue: s.gainValue, bills: new Set(X.map(l => l.invId)).size }; };
    const chans = ui.chan === 'wholesale' || ui.chan === 'retail' ? [ui.chan] : ['wholesale', 'retail'];
    const tiles = []; ['gold', 'silver'].forEach(m => chans.forEach(c => { const x = cell(SL, m, c), p = cell(prevSL, m, c);
      tiles.push(`<div class="mx ${m} ${c}"><div class="mx-h"><span class="mx-m">${m === 'gold' ? '🟡 Gold' : '⚪ Silver'}</span><span class="pill ch-${c}">${c === 'wholesale' ? 'Wholesale' : 'Retail'}</span></div><div class="v">${compactInr(x.amount)}</div><div class="s">${p ? delta(x.amount, p.amount) + ' ' : ''}${x.bills} bills</div>
        <div class="mx-r"><div><span>Net becha</span><b>${wt(x.net, m)}</b></div><div><span>Fine</span><b>${wt(x.fine, m)}</b></div><div><span>Wastage profit</span><b class="${x.gValue < 0 ? 'red' : 'green'}">${wt(x.gFine, m)}</b><em>${inr(x.gValue)}</em></div></div></div>`); }));
    return `<div class="mxgrid n${tiles.length}">${tiles.join('')}</div>`;
  }
  function ageing() {
    const t = todayStr(); const b = [['0–30 din', 0], ['31–60 din', 0], ['61–90 din', 0], ['90+ din', 0]]; let tot = 0;
    S.invoices.forEach(v => { if (isBuy(v.type) || v.type === 'metal') return; const d = invDue(v); if (d <= 0.5) return; const age = daysBetween(v.date, t); b[age <= 30 ? 0 : age <= 60 ? 1 : age <= 90 ? 2 : 3][1] += d; tot += d; });
    return { b, tot };
  }
  function analyticsBody() {
    const r = rpRange(); const SL = saleLines(r.a, r.b), PL = purchaseLines(r.a, r.b); const prevSL = r.pa ? saleLines(r.pa, r.pb) : null;
    const ch = new Map(S.invoices.map(v => [v.id, chanOf(v)])); const tot = sumLines(SL), ptot = prevSL ? sumLines(prevSL) : null, pur = sumLines(PL);
    const B = bucketKeys(r.a, r.b); const rows = {}; B.keys.forEach(k => rows[k] = { lab: B.lab(k), w: 0, r: 0, g: 0, s: 0, pf: 0, p: 0 });
    SL.forEach(l => { const x = rows[B.k(l.date)]; if (!x) return; x[ch.get(l.invId) === 'wholesale' ? 'w' : 'r'] += l.amount; x[l.metal === 'silver' ? 's' : 'g'] += l.amount; x.pf += l.gainValue || 0; });
    PL.forEach(l => { const x = rows[B.k(l.date)]; if (x) x.p += l.amount; });
    const R = Object.values(rows); R.forEach(x => { x.t = x.w + x.r; }); const one = ui.chan === 'wholesale' || ui.chan === 'retail';
    const nBills = new Set(SL.map(l => l.invId)).size;
    const kp = `<div class="kpis">${cmpKpi('Sales', tot.amount, ptot && ptot.amount, compactInr, true, nBills + ' bills')}${cmpKpi('Gold fine becha', sum(SL.filter(l => l.metal === 'gold'), l => l.fine), prevSL && sum(prevSL.filter(l => l.metal === 'gold'), l => l.fine), g3, true)}${cmpKpi('Silver net becha', sum(SL.filter(l => l.metal === 'silver'), l => l.net), prevSL && sum(prevSL.filter(l => l.metal === 'silver'), l => l.net), v => wt(v, 'silver'), true)}${cmpKpi('Wastage profit', tot.gainValue, ptot && ptot.gainValue, compactInr, true, g3(tot.gainFine) + ' fine')}${kpi('Purchases', compactInr(pur.amount), wt(pur.net, 'gold') + ' net')}</div>`;
    const sector = one ? '' : (() => { const w = sum(R, x => x.w), rr = sum(R, x => x.r); return w + rr > 0 ? card('Wholesale vs Retail', r.label, SJC.donut([{ l: 'Wholesale', v: w, c: C.whole }, { l: 'Retail', v: rr, c: C.retail }], { fmt: compactInr, center: { t: compactInr(w + rr), s: 'sales' } })) : ''; })();
    const trend = card(one ? `Sales trend — ${ui.chan === 'wholesale' ? 'Wholesale' : 'Retail'}` : 'Sales trend — Wholesale vs Retail', r.label + (B.byDay ? ' · roz' : ' · mahine'), SJC.line(R, one ? [{ k: ui.chan === 'wholesale' ? 'w' : 'r', l: 'Sales', c: ui.chan === 'wholesale' ? C.whole : C.retail, area: true }] : [{ k: 'w', l: 'Wholesale', c: C.whole, area: true }, { k: 'r', l: 'Retail', c: C.retail, area: true }], { fmt: inr }));
    const metal = card('Gold vs Silver ki bikri', 'value ₹', SJC.bars(R, [{ k: 'g', l: 'Gold', c: C.gold }, { k: 's', l: 'Silver', c: C.silver }], { fmt: inr, stacked: true }));
    const profit = card('Wastage profit trend', 'bikri wastage − kharid wastage, ₹', SJC.line(R, [{ k: 'pf', l: 'Wastage profit', c: C.gold, area: true }], { fmt: inr }));
    const sp = card('Sales vs Purchases', r.label, SJC.bars(R, [{ k: 't', l: 'Sales', c: C.gold }, { k: 'p', l: 'Purchases', c: C.buy }], { fmt: inr }));
    const cats = groupLines(SL, 'category').sort((a, b) => b.amount - a.amount);
    const catDonut = card('Category wise bikri', 'value ka hissa', SJC.donut(cats.map(c => ({ l: String(c.key), v: c.amount })), { fmt: compactInr }));
    const catProfit = card('Sabse zyada profit wali category', 'wastage profit ₹', SJC.hbar(cats.filter(c => Math.abs(c.gainValue) >= 1).sort((a, b) => b.gainValue - a.gainValue).slice(0, 8).map(c => ({ l: String(c.key), v: c.gainValue, sub: g3(c.gainFine) + ' fine · ' + g3(c.net) + ' becha' })), { fmt: compactInr, c: C.retail, rank: true }));
    const parties = groupLines(SL, 'party').sort((a, b) => b.amount - a.amount).slice(0, 8);
    const pid = new Map(); SL.forEach(l => pid.set(l.party, l.partyId));
    const top = card('Top parties', 'tap karke unki bikri kholiye', SJC.hbar(parties.map(p => ({ l: String(p.key), v: p.amount, sub: `${p.bills} bills · ${g3(p.net)}`, attrs: pid.get(p.key) ? `data-act="rep-party" data-id="${esc(pid.get(p.key))}"` : '' })), { fmt: compactInr, c: C.gold, rank: true }));
    const ag = ageing(); const ageCard = ag.tot > 0 ? card('Udhaari kitni purani', `kul baaki ${inr(ag.tot)}`, SJC.hbar(ag.b.map(([l, v]) => ({ l, v })), { fmt: inr, c: C.buy })) : '';
    const modes = {}; S.invoices.forEach(v => { if (isBuy(v.type)) return; invPayments(v).forEach(p => { if (inRange(p.date, r.a, r.b) && num(p.amount) > 0) modes[p.mode || '—'] = (modes[p.mode || '—'] || 0) + num(p.amount); }); });
    const modeCard = Object.keys(modes).length ? card('Paisa kaise aaya', r.label, SJC.donut(Object.entries(modes).map(([l, v]) => ({ l, v })), { fmt: compactInr, center: { s: 'collected' } })) : '';
    const t = todayStr(); const cnt = {}; S.invoices.forEach(v => { if (!isBuy(v.type)) cnt[v.date] = (cnt[v.date] || 0) + 1; }); const days = []; for (let i = 118; i >= 0; i--) { const d = addDays(t, -i); days.push({ d, v: cnt[d] || 0, today: i === 0 }); }
    const heat = card('Bikri ka calendar', 'pichhle 17 hafte — har din kitne bill', SJC.heat(days, { fmt: v => v + ' bill', c: C.gold }));
    if (!SL.length && !PL.length) return `<div class="card">${kp}</div>` + emptyBox('Is period mein koi bill nahi hai — period badal kar dekhiye.') + stockRateCards();
    const cards = [trend, sector, metal, profit, catDonut, catProfit, top, ageCard, sp, modeCard, heat].filter(Boolean); let grid = '';
    for (let i = 0; i < cards.length; i += 2) grid += i + 1 < cards.length ? `<div class="two">${cards[i]}${cards[i + 1]}</div>` : cards[i];
    return `<div class="card">${kp}</div>${sectorMatrix(SL, prevSL, ch)}${grid}${stockRateCards()}`;
  }
  function stockRateCards() {
    const t = todayStr(); const H = S.rateHistory.filter(x => x.date && x.date >= addDays(t, -120)).sort((a, b) => a.date.localeCompare(b.date));
    const rc = (k, l, c, unit) => { const L = H.filter(x => num(x[k]) > 0); if (L.length < 2) return ''; const f = num(L[0][k]), z = num(L[L.length - 1][k]); return card(l, `${unit} · ${fmtD(L[0].date)} se ${delta(z, f) || ''}`, SJC.line(L.map(x => ({ lab: x.date.slice(8) + '/' + x.date.slice(5, 7), tip: fmtD(x.date), v: num(x[k]) })), [{ k: 'v', l, c, area: true }], { fmt: inr, h: 180, zoom: true, axis: v => v >= 1e5 ? (v / 1e5).toFixed(2) + 'L' : (v / 1e3).toFixed(1) + 'K' }), `<button class="btn sm" data-act="dm-open-rh">${ic('edit', 14)} Edit</button>`); };
    const sn = P() ? P().snaps().slice(-90) : []; const snap = sn.length >= 2 ? card('Stock ki value — roz ka trend', 'aaj ke bhaav par, apne aap record hota hai', SJC.line(sn.map(x => ({ lab: x.date.slice(8) + '/' + x.date.slice(5, 7), tip: fmtD(x.date), g: x.g ? x.g.val : 0, s: x.s ? x.s.val : 0 })), [{ k: 'g', l: 'Gold', c: C.gold, area: true }, { k: 's', l: 'Silver', c: C.silver, area: true }], { fmt: inr, wide: true })) : '';
    const a = rc('gold24', 'Gold 24K ka bhaav', C.gold, '₹ / 10 g'), b = rc('silver999', 'Silver 999 ka bhaav', C.silver, '₹ / kg');
    return (a || b ? `<div class="two">${a}${b}</div>` : '') + snap;
  }
  if (!REP_TABS.some(x => x[0] === 'analytics')) REP_TABS.unshift(['analytics', '📊 Analytics']);
  ui.rTab = 'analytics';
  { const R = VIEWDEF.reports; VIEWDEF.reports = { ...R, shell() { return R.shell.call(R); }, body() { if (ui.rTab === 'analytics') return withBook(ui.rpBook, analyticsBody); return R.body.call(R); } }; }

  /* ================= Dashboard pulse ================= */
  function pulse() {
    if (!S.invoices.length && !S.products.length) return '';
    const t = todayStr(), a30 = addDays(t, -29), mk = monthKey(t), [ma] = monthRange(mk); const SL = saleLines(a30 < ma ? a30 : ma, t);
    const ch = new Map(S.invoices.map(v => [v.id, chanOf(v)])); const days = []; const idx = {};
    for (let i = 29; i >= 0; i--) { const d = addDays(t, -i); const o = { lab: d.slice(8) + '/' + d.slice(5, 7), tip: fmtD(d), w: 0, r: 0 }; idx[d] = o; days.push(o); }
    SL.forEach(l => { const o = idx[l.date]; if (o) o[ch.get(l.invId) === 'wholesale' ? 'w' : 'r'] += l.amount; });
    const todayL = SL.filter(l => l.date === t), monL = SL.filter(l => l.date >= ma); const dayN = +t.slice(8); const pm = prevYm(mk), [pa] = monthRange(pm); const pb = addDays(pa, dayN - 1);
    const prevM = sum(saleLines(pa, pb), l => l.amount); const monS = sum(monL, l => l.amount), monP = sum(monL, l => l.gainValue || 0), monPf = sum(monL, l => l.gainFine || 0);
    const MT = P() ? P().metalTotals() : null; const sn = P() ? P().snaps().slice(-30) : [];
    const one = ui.chan === 'wholesale' || ui.chan === 'retail';
    const tile = (l, v, s, sp) => `<div class="pl-t"><div class="l">${l}</div><div class="v">${v}</div><div class="s">${s || ''}</div>${sp || ''}</div>`;
    const tiles = [tile('Aaj ki bikri', compactInr(sum(todayL, l => l.amount)), new Set(todayL.map(l => l.invId)).size + ' bills', SJC.spark(days.slice(-14).map(d => d.w + d.r), C.gold)),
      tile('Is mahine', compactInr(monS), (delta(monS, prevM) || '') + ' <span class="muted">pichhle mahine se</span>', ''),
      tile('Wastage profit (mahina)', compactInr(monP), g3(monPf) + ' fine', ''),
      MT ? tile('Stock value', compactInr(MT.gold.value + MT.silver.value), `G ${wt(MT.gold.net, 'gold')} · S ${wt(MT.silver.net, 'silver')}`, SJC.spark(sn.map(x => (x.g ? x.g.val : 0) + (x.s ? x.s.val : 0)), C.silver)) : ''].join('');
    const has = days.some(d => d.w || d.r);
    const chart = has ? SJC.line(days, one ? [{ k: ui.chan === 'wholesale' ? 'w' : 'r', l: 'Sales', c: ui.chan === 'wholesale' ? C.whole : C.retail, area: true }] : [{ k: 'w', l: 'Wholesale', c: C.whole, area: true }, { k: 'r', l: 'Retail', c: C.retail, area: true }], { fmt: inr, wide: true, h: 200, label: 'Pichhle 30 din ki bikri' }) : '';
    const al = P() ? P().alerts() : [];
    const alerts = al.length ? `<div class="pl-al">${al.slice(0, 6).map(x => `<div class="al ${x.lvl || ''}"><span>${x.lvl === 'bad' ? '🔴' : x.lvl === 'warn' ? '🟠' : '🔔'} ${esc(x.t)}</span>${x.b ? `<button type="button" class="btn sm" ${x.a}>${esc(x.b)}</button>` : ''}</div>`).join('')}</div>` : '<div class="pl-ok">✓ Sab theek hai — koi alert nahi.</div>';
    return `<div class="card pulse"><div class="card-h"><div><h3>Business pulse</h3><div class="small muted">${one ? (ui.chan === 'wholesale' ? 'Wholesale' : 'Retail') + ' · ' : ''}pichhle 30 din</div></div><button class="link" data-act="go-rep" data-v="analytics">Analytics →</button></div><div class="pl-ts">${tiles}</div>${chart}<div class="pl-ah">Automation & alerts</div>${alerts}</div>`;
  }
  { const D = VIEWDEF.dashboard; VIEWDEF.dashboard = { ...D, body() { let p = ''; try { p = pulse(); } catch (e) { console.error(e); } return p + D.body.call(D); } }; }

  /* ================= Target page ================= */
  function targetBody() {
    const G = growthStats(), g = G.g, t = todayStr(); const total = Math.max(1, daysBetween(g.start, g.deadline)), elapsed = Math.max(0, Math.min(total, daysBetween(g.start, t)));
    const all = { goal: G.b2b.goal + G.retail.goal, have: Math.min(G.b2b.have, G.b2b.goal) + Math.min(G.retail.have, G.retail.goal) }; all.pct = all.goal ? all.have / all.goal * 100 : 0; const timePct = elapsed / total * 100;
    const C0 = S.customers.map(c => ({ c, type: ptypeOf(c), d: tsDate(c.createdAt) || '' }));
    const win = Math.max(1, Math.min(30, elapsed + 1));
    const curve = (type, x, col) => {
      const L = C0.filter(z => z.type === type); const base = L.filter(z => !z.d || z.d < g.start).length; const pace = L.filter(z => z.d && z.d >= addDays(t, -(win - 1))).length / win;
      const pts = new Set(); for (let i = 0; i <= total; i += Math.max(1, Math.round(total / 22))) pts.add(addDays(g.start, i)); pts.add(g.deadline); if (t >= g.start && t <= g.deadline) pts.add(t);
      const rows = [...pts].sort().map(d => { const k = daysBetween(g.start, d); const act = d <= t ? base + L.filter(z => z.d && z.d >= g.start && z.d <= d).length : null;
        return { lab: d.slice(8) + '/' + d.slice(5, 7), tip: fmtD(d), need: Math.round(base + (x.goal - base) * k / total), act, proj: d >= t ? Math.min(Math.round(x.goal * 1.2), Math.round(x.have + pace * daysBetween(t, d))) : null }; });
      return SJC.line(rows, [{ k: 'act', l: 'Ab tak', c: col, area: true }, { k: 'need', l: 'Zaroori raasta', c: C.gray, dash: true }, { k: 'proj', l: 'Is raftaar se', c: C.gold, dash: true }], { fmt: v => Math.round(v).toLocaleString('en-IN'), top: x.goal, h: 200, axis: v => String(Math.round(v)) });
    };
    const side = (x, col, title, who) => {
      const st = x.left === 0 ? ['Goal poora 🎉', 'green'] : x.onTrack ? ['Raaste par ✓', 'green'] : ['Peeche — raftaar badhao', 'red']; const gap = x.have - x.expected;
      return `<div class="card tg-side"><div class="card-h"><div><h3>${title}</h3><div class="small muted">${who}</div></div><span class="pill ${st[1] === 'green' ? 'green' : 'overdue'}">${st[0]}</span></div>
        <div class="tg-top">${SJC.ring(x.pct, { c: col, label: title, r: 62, sw: 13, fs: 26, sub: x.have + ' / ' + x.goal })}<div class="tg-nums">
          <div><span>Baaki</span><b>${x.left.toLocaleString('en-IN')}</b></div><div><span>Roz chahiye</span><b>${(Math.ceil(x.perDay * 10) / 10)}</b></div><div><span>Hafte mein</span><b>${Math.ceil(x.perWeek)}</b></div>
          <div><span>Aaj jode</span><b>${x.today}${x.todayNeed ? ` <em class="red">+${x.todayNeed} aur</em>` : ' <em class="green">✓</em>'}</b></div><div><span>7 din mein</span><b>${x.last7}</b></div><div><span>Aaj tak hone chahiye</span><b>${x.expected} <em class="${gap >= 0 ? 'green' : 'red'}">${gap >= 0 ? '+' : ''}${gap}</em></b></div></div></div>
        ${curve(x.type, x, col)}<p class="small muted" style="margin:8px 0 0">${x.left ? (x.proj ? `Is raftaar se goal <b>${fmtD(x.proj)}</b> tak poora hoga${x.proj <= g.deadline ? ' — time se pehle 👍' : ' — deadline ke baad, roz ' + (Math.ceil(x.perDay * 10) / 10) + ' chahiye'}.` : 'Pichhle dino mein koi nayi party nahi judi — aaj se shuru kijiye.') : 'Shabash! Ye goal poora ho gaya.'}</p></div>`; };
    // weekly bars
    const weeks = []; const w0 = g.start; const nW = Math.min(30, Math.max(1, Math.ceil((Math.min(elapsed, total) + 1) / 7)));
    for (let i = 0; i < nW; i++) { const a = addDays(w0, i * 7), b = addDays(a, 6); weeks.push({ lab: a.slice(8) + '/' + a.slice(5, 7), tip: fmtD(a) + ' – ' + fmtD(b), b: C0.filter(z => z.type === 'B2B' && z.d >= a && z.d <= b).length, r: C0.filter(z => z.type === 'Retail' && z.d >= a && z.d <= b).length }); }
    const needW = Math.ceil(G.b2b.perWeek + G.retail.perWeek);
    const weekly = card('Har hafte kitni party judi', `ab har hafte ${needW} chahiye (B2B ${Math.ceil(G.b2b.perWeek)} + Retail ${Math.ceil(G.retail.perWeek)})`, SJC.bars(weeks, [{ k: 'b', l: 'B2B / Retailer', c: C.whole }, { k: 'r', l: 'Retail customer', c: C.retail }], { fmt: v => String(Math.round(v)), stacked: true, wide: true, axis: v => String(Math.round(v)) }));
    // calendar
    const cnt = {}; C0.forEach(z => { if (z.d) cnt[z.d] = (cnt[z.d] || 0) + 1; }); const span = Math.min(125, Math.max(27, daysBetween(g.start, t))); const days = []; for (let i = span; i >= 0; i--) { const d = addDays(t, -i); days.push({ d, v: cnt[d] || 0, today: i === 0 }); }
    const cal = card('Roz ka record', 'har din kitni party judi — gehra rang = zyada', SJC.heat(days, { fmt: v => v + ' party', c: C.gold, cs: 17 }));
    // cities
    const city = new Map(); C0.forEach(z => { const k = String(z.c.city || '').trim() || '—'; let x = city.get(k); if (!x) { x = { l: k, b: 0, r: 0 }; city.set(k, x); } x[z.type === 'B2B' ? 'b' : 'r']++; });
    const cities = [...city.values()].sort((a, b) => (b.b + b.r) - (a.b + a.r)).slice(0, 8);
    const cityCard = cities.length ? card('Kis shehar se', 'top jagah — B2B · Retail', SJC.hbar(cities.map(x => ({ l: x.l, v: x.b + x.r, sub: `${x.b} B2B · ${x.r} retail` })), { fmt: v => String(Math.round(v)), c: C.gold, rank: true })) : '';
    // milestones
    const ms = [25, 50, 75, 100].map(p => { const by = addDays(g.start, Math.round(total * p / 100)); const need = Math.ceil(all.goal * p / 100); const done = all.have >= need; return `<div class="tg-ms ${done ? 'done' : by < t ? 'late' : ''}"><i>${done ? '✓' : p + '%'}</i><div><b>${need.toLocaleString('en-IN')} parties</b><span>${fmtD(by)} tak${done ? ' · ho gaya' : by < t ? ' · late' : ' · ' + Math.max(0, need - all.have) + ' baaki'}</span></div></div>`; }).join('');
    const recent = [...G.b2b.recent, ...G.retail.recent].sort((a, b) => b.d.localeCompare(a.d)).slice(0, 8).map(x => `<div class="sp-row"><div><b>${esc(x.c.name)}</b><div class="small muted">${esc(x.c.city || '')} · ${fmtD(x.d)}</div></div><span class="pill ch-${x.type === 'B2B' ? 'wholesale' : 'retail'}">${x.type === 'B2B' ? 'B2B' : 'Retail'}</span></div>`).join('') || '<p class="small muted">Abhi koi customer nahi juda.</p>';
    const ahead = all.pct - timePct;
    return `<div class="tg-hero"><div class="tg-hl"><div class="tg-k">🎯 MISSION ${fmtD(g.deadline)}</div><h2>${g.b2b} Retailers (B2B) + ${g.retail} Customers</h2><p>${G.daysLeft} din baaki · shuru ${fmtD(g.start)} · <button class="link" data-act="growth-edit">Goal badlo</button></p>${cdBoxes()}
        <div class="tg-bar"><div class="tb-l"><span>Goal</span><b>${all.have.toLocaleString('en-IN')} / ${all.goal.toLocaleString('en-IN')}</b></div><div class="tb-t"><i style="width:${Math.min(100, all.pct).toFixed(1)}%"></i><u style="left:${Math.min(100, timePct).toFixed(1)}%" data-tip="Aaj tak itna time nikal gaya"></u></div><div class="small ${ahead >= 0 ? 'green' : 'red'}">${ahead >= 0 ? 'Time se aage' : 'Time se peeche'} — goal ${all.pct.toFixed(1)}% · time ${timePct.toFixed(1)}%</div></div></div>
      <div class="tg-hr">${SJC.ring(all.pct, { c: C.gold, c2: '#fff3c4', r: 78, sw: 15, fs: 34, sub: 'poora hua', label: 'Overall' })}<div class="tg-today"><span>Aaj ka kaam</span><b>${G.b2b.todayNeed} B2B + ${G.retail.todayNeed} Retail</b><div class="btns"><button class="btn gold sm" data-act="cust-new">${ic('plus', 14)} Customer jodo</button><a class="btn sm" href="#leads">Leads</a></div></div></div></div>
      <div class="two">${side(G.b2b, C.whole, 'Retailers / B2B', 'GSTIN wale ya B2B mark kiye')}${side(G.retail, C.retail, 'Retail customers', 'seedhe grahak')}</div>
      ${weekly}<div class="two">${cal}${cityCard}</div>
      <div class="two"><div class="card"><div class="card-h"><h3>Milestones</h3></div><div class="tg-mss">${ms}</div></div><div class="card"><div class="card-h"><h3>Abhi abhi jude</h3></div>${recent}</div></div>`;
  }
  VIEWDEF.target = { shell: () => '<div id="vbody"></div>', body: targetBody };
  if (!VIEWS.some(v => v[0] === 'target')) { const i = VIEWS.findIndex(v => v[0] === 'reports'); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, ['target', 'Target', 'target', 'Target 🎯']); }
  // the old "Party growth" tab in Reports now shows the same visual page
  repGrowth = function () { return targetBody(); };

  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act="dm-open-rh"]'); if (!t) return; const b = document.createElement('button'); b.dataset.act = 'dm-open'; b.style.display = 'none'; document.body.appendChild(b); b.click(); b.remove(); setTimeout(() => { const s = document.getElementById('dm-col'); if (s) { s.value = 'rateHistory'; s.dispatchEvent(new Event('change', { bubbles: true })); } }, 30); });

  try { renderHeader(); if (location.hash === '#target' && view !== 'target') goView('target'); } catch (e) { console.error(e); }
})();
