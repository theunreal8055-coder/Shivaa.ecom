<?php
/* =====================================================================
   Shivaa Jewels — website data server (v2)
   - Stores the software's records on your own hosting (SQLite or MySQL)
   - Every record is encrypted on disk (AES-256-GCM)
   - Owner + staff logins with roles; permissions are checked here on the
     server, so they cannot be bypassed from a browser
   Needs PHP 7.2+ with PDO (SQLite or MySQL) and OpenSSL.
   ===================================================================== */
define('SJ', 1);
error_reporting(E_ALL);
ini_set('display_errors', '0');
@ini_set('serialize_precision', '-1');

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'");

$CFG = require __DIR__ . '/sj-config.php';

const SJ_SEG = '[A-Za-z0-9_\-.~:@+]{1,200}';
const SJ_MAX_OPS = 1000;
const SJ_PAGE_ROWS = 500;
const SJ_PAGE_BYTES = 4000000;
const SJ_SCHEMA = 3;
const SJ_OWNER_ID = 'u_owner';
const SJ_ROLES = ['owner', 'manager', 'staff', 'viewer'];
const SJ_RATE_KEYS = ['gold24', 'silver999', 'ratesUpdated', 'ratesSource', 'ratesAt'];

class SjError extends Exception {
    public $sjCode; public $http;
    public function __construct($code, $msg, $http = 500) { parent::__construct($msg); $this->sjCode = $code; $this->http = $http; }
}
function sj_out($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function sj_fail($code, $http = 400, $msg = '') { sj_out(['ok' => false, 'error' => $code, 'message' => $msg], $http); }
set_exception_handler(function ($e) {
    if ($e instanceof SjError) sj_fail($e->sjCode, $e->http, $e->getMessage());
    error_log('[shivaa] ' . get_class($e) . ': ' . $e->getMessage());
    sj_fail('server_error', 500, 'Server par error aaya. Hosting ka PHP error log dekhiye.');
});
function sj_cfg($k, $d = null) { global $CFG; return array_key_exists($k, $CFG) ? $CFG[$k] : $d; }

/* ---------------- database ---------------- */
function sj_is_mysql() { return sj_cfg('driver', 'sqlite') === 'mysql'; }
function sj_db() {
    static $pdo = null;
    if ($pdo) return $pdo;
    if (!class_exists('PDO')) throw new SjError('no_pdo', 'Hosting par PHP PDO extension band hai. hPanel/cPanel → PHP settings mein PDO on kijiye.');
    $drivers = PDO::getAvailableDrivers();
    $opt = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC];
    if (sj_is_mysql()) {
        if (!in_array('mysql', $drivers, true)) throw new SjError('no_mysql', 'Hosting par PDO MySQL driver nahi hai.');
        if (sj_cfg('mysql_db', '') === '' || sj_cfg('mysql_user', '') === '') throw new SjError('mysql_config', 'sj-config.php mein MySQL database ka naam, user aur password bhariye.');
        try {
            $pdo = new PDO('mysql:host=' . sj_cfg('mysql_host', 'localhost') . ';dbname=' . sj_cfg('mysql_db') . ';charset=utf8mb4', sj_cfg('mysql_user'), sj_cfg('mysql_pass'), $opt);
        } catch (PDOException $e) {
            error_log('[shivaa] mysql connect: ' . $e->getMessage());
            throw new SjError('mysql_connect', 'MySQL se connect nahi ho paya. sj-config.php mein database details check kijiye.');
        }
        $pdo->exec("SET SESSION sql_mode = 'STRICT_TRANS_TABLES'");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_docs (col VARCHAR(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, id VARCHAR(200) CHARACTER SET ascii COLLATE ascii_bin NOT NULL, data LONGTEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL, seq BIGINT NOT NULL, deleted TINYINT NOT NULL DEFAULT 0, updated BIGINT NOT NULL, PRIMARY KEY (col, id), KEY sj_docs_seq (seq)) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_counter (id INT NOT NULL PRIMARY KEY, v BIGINT NOT NULL) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_meta (k VARCHAR(64) CHARACTER SET ascii NOT NULL PRIMARY KEY, v TEXT CHARACTER SET utf8mb4) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_tokens (h CHAR(64) CHARACTER SET ascii NOT NULL PRIMARY KEY, created BIGINT NOT NULL, expires BIGINT NOT NULL, seen BIGINT NOT NULL, ua VARCHAR(200) CHARACTER SET utf8mb4) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_fails (ip VARCHAR(64) CHARACTER SET ascii NOT NULL, at BIGINT NOT NULL, KEY sj_fails_at (at)) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_users (id VARCHAR(32) CHARACTER SET ascii NOT NULL PRIMARY KEY, uname VARCHAR(40) CHARACTER SET ascii NOT NULL, name VARCHAR(80) CHARACTER SET utf8mb4 NOT NULL, pass VARCHAR(255) CHARACTER SET ascii NULL, role VARCHAR(16) CHARACTER SET ascii NOT NULL, active TINYINT NOT NULL DEFAULT 1, created BIGINT NOT NULL, last_login BIGINT NULL, UNIQUE KEY sj_users_uname (uname)) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_history (hid BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, col VARCHAR(255) CHARACTER SET ascii NOT NULL, id VARCHAR(200) CHARACTER SET ascii NOT NULL, data LONGTEXT CHARACTER SET utf8mb4 NULL, seq BIGINT NOT NULL, uby VARCHAR(32) CHARACTER SET ascii NULL, replaced_at BIGINT NOT NULL, replaced_by VARCHAR(32) CHARACTER SET ascii NULL, KEY sj_hist_doc (col, id), KEY sj_hist_at (replaced_at)) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_chain (n BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, at BIGINT NOT NULL, uid VARCHAR(40) CHARACTER SET ascii NULL, ops LONGTEXT CHARACTER SET utf8mb4 NOT NULL, h CHAR(64) CHARACTER SET ascii NOT NULL) ENGINE=InnoDB");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_gps (dev VARCHAR(64) CHARACTER SET ascii NOT NULL, at BIGINT NOT NULL, lat DOUBLE NOT NULL, lon DOUBLE NOT NULL, spd DOUBLE NULL, acc DOUBLE NULL, batt DOUBLE NULL, KEY sj_gps_dev (dev, at)) ENGINE=InnoDB");
        $pdo->exec("INSERT IGNORE INTO sj_counter (id, v) VALUES (1, 0)");
    } else {
        if (!in_array('sqlite', $drivers, true)) throw new SjError('no_sqlite', 'Is hosting par SQLite nahi hai. sj-config.php mein driver => mysql karke MySQL database ki details bhariye.');
        $file = sj_cfg('sqlite_file');
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        if (!is_dir($dir) || !is_writable($dir)) throw new SjError('not_writable', 'sj-data folder mein likhne ki permission nahi hai. File Manager mein sj-data folder ki permission 755 (ya 775) kijiye.');
        if (file_exists($file) && !is_writable($file)) throw new SjError('not_writable', 'Database file mein likhne ki permission nahi hai (sj-data folder ki files 644 ya 664 kijiye).');
        $opt[PDO::ATTR_TIMEOUT] = 20;
        $pdo = new PDO('sqlite:' . $file, null, null, $opt);
        $pdo->exec('PRAGMA busy_timeout = 20000');
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_docs (col TEXT NOT NULL, id TEXT NOT NULL, data TEXT, seq INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0, updated INTEGER NOT NULL, PRIMARY KEY (col, id))");
        $pdo->exec("CREATE INDEX IF NOT EXISTS sj_docs_seq ON sj_docs (seq)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_counter (id INTEGER PRIMARY KEY, v INTEGER NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_meta (k TEXT PRIMARY KEY, v TEXT)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_tokens (h TEXT PRIMARY KEY, created INTEGER NOT NULL, expires INTEGER NOT NULL, seen INTEGER NOT NULL, ua TEXT)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_fails (ip TEXT NOT NULL, at INTEGER NOT NULL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS sj_fails_at ON sj_fails (at)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_users (id TEXT PRIMARY KEY, uname TEXT NOT NULL UNIQUE, name TEXT NOT NULL, pass TEXT, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created INTEGER NOT NULL, last_login INTEGER)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_history (hid INTEGER PRIMARY KEY AUTOINCREMENT, col TEXT NOT NULL, id TEXT NOT NULL, data TEXT, seq INTEGER NOT NULL, uby TEXT, replaced_at INTEGER NOT NULL, replaced_by TEXT)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS sj_hist_doc ON sj_history (col, id)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_chain (n INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL, uid TEXT, ops TEXT NOT NULL, h TEXT NOT NULL)");
        $pdo->exec("CREATE TABLE IF NOT EXISTS sj_gps (dev TEXT NOT NULL, at INTEGER NOT NULL, lat REAL NOT NULL, lon REAL NOT NULL, spd REAL, acc REAL, batt REAL)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS sj_gps_dev ON sj_gps (dev, at)");
        $pdo->exec("INSERT OR IGNORE INTO sj_counter (id, v) VALUES (1, 0)");
        @chmod($file, 0644);
    }
    sj_upgrade($pdo);
    return $pdo;
}
function sj_add_column($pdo, $table, $col, $type) {
    try { $pdo->exec("ALTER TABLE $table ADD COLUMN $col $type"); } catch (Exception $e) { /* already there */ }
}
/* one-time upgrade of databases made by the first version (single password) */
function sj_upgrade($pdo) {
    $st = $pdo->prepare('SELECT v FROM sj_meta WHERE k = ?'); $st->execute(['schema']);
    $v = (int)$st->fetchColumn();
    if ($v >= SJ_SCHEMA) return;
    sj_add_column($pdo, 'sj_tokens', 'uid', sj_is_mysql() ? 'VARCHAR(32) CHARACTER SET ascii NULL' : 'TEXT');
    sj_add_column($pdo, 'sj_docs', 'uby', sj_is_mysql() ? 'VARCHAR(32) CHARACTER SET ascii NULL' : 'TEXT');
    sj_add_column($pdo, 'sj_tokens', 'dev', sj_is_mysql() ? 'VARCHAR(32) CHARACTER SET ascii NULL' : 'TEXT');
    sj_add_column($pdo, 'sj_tokens', 'elev', sj_is_mysql() ? 'BIGINT NULL' : 'INTEGER');
    $st->execute(['pass']); $old = $st->fetchColumn();
    if ($old !== false && $old !== null) {
        $ins = $pdo->prepare(sj_is_mysql() ? 'INSERT IGNORE INTO sj_users (id, uname, name, pass, role, active, created) VALUES (?, ?, ?, ?, ?, 1, ?)' : 'INSERT OR IGNORE INTO sj_users (id, uname, name, pass, role, active, created) VALUES (?, ?, ?, ?, ?, 1, ?)');
        $ins->execute([SJ_OWNER_ID, 'owner', 'Owner', $old, 'owner', time()]);
        $pdo->prepare('UPDATE sj_tokens SET uid = ? WHERE uid IS NULL')->execute([SJ_OWNER_ID]);
        $pdo->prepare('DELETE FROM sj_meta WHERE k = ?')->execute(['pass']);
    }
    $pdo->prepare('REPLACE INTO sj_meta (k, v) VALUES (?, ?)')->execute(['schema', (string)SJ_SCHEMA]);
    if ($v < 3) $GLOBALS['SJ_NEED_GENESIS'] = true;   // first link of the tamper-proof chain is made once the rest of the code is loaded
}
function sj_meta_get($k) { $st = sj_db()->prepare('SELECT v FROM sj_meta WHERE k = ?'); $st->execute([$k]); $v = $st->fetchColumn(); return $v === false ? null : $v; }
function sj_meta_set($k, $v) { sj_db()->prepare('REPLACE INTO sj_meta (k, v) VALUES (?, ?)')->execute([$k, $v]); }

/* ---------------- encryption at rest (AES-256-GCM) ---------------- */
function sj_enc_available() { return function_exists('openssl_encrypt') && in_array('aes-256-gcm', array_map('strtolower', openssl_get_cipher_methods()), true); }
function sj_key() {
    static $k = null;
    if ($k !== null) return $k;
    if (!sj_enc_available()) return $k = false;
    $f = __DIR__ . '/sj-data/sj-key.php';
    if (!is_file($f)) {
        // never make a new key when encrypted data already exists — that data would become unreadable
        $c = sj_db()->query("SELECT COUNT(*) FROM sj_docs WHERE data LIKE 'e1:%'")->fetchColumn();
        if ((int)$c > 0) throw new SjError('key_missing', 'Encryption key file (sj-data/sj-key.php) nahi mili. Backup se ye file wapas rakhiye — iske bina data nahi khulega.');
        $raw = random_bytes(32);
        $php = "<?php\n// Shivaa Jewels — data encryption key. Is file ko KABHI delete ya badaliye mat.\n// Iske bina aapka data nahi khulega. Backup mein poora sj-data folder rakhiye.\nif (!defined('SJ')) { http_response_code(404); exit; }\nreturn '" . base64_encode($raw) . "';\n";
        $h = @fopen($f, 'x');                       // exclusive create: two requests can never make two keys
        if ($h) { fwrite($h, $php); fclose($h); @chmod($f, 0644); }
        elseif (!is_file($f)) throw new SjError('not_writable', 'sj-data folder mein encryption key nahi ban payi (permission check kijiye).');
    }
    $v = include $f;
    $raw = is_string($v) ? base64_decode($v, true) : false;
    if (!$raw || strlen($raw) !== 32) throw new SjError('key_bad', 'Encryption key file (sj-data/sj-key.php) kharab hai.');
    return $k = $raw;
}
function sj_enc($plain, $col, $id) {
    $key = sj_key(); if (!$key) return $plain;
    $iv = random_bytes(12); $tag = '';
    $ct = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, $col . "\0" . $id, 16);
    if ($ct === false) throw new SjError('encrypt', 'Data encrypt nahi hua.');
    return 'e1:' . base64_encode($iv . $tag . $ct);
}
function sj_dec($stored, $col, $id) {
    if ($stored === null || strncmp($stored, 'e1:', 3) !== 0) return $stored;
    $key = sj_key();
    if (!$key) throw new SjError('no_openssl', 'Data encrypted hai par hosting par OpenSSL band hai.');
    $b = base64_decode(substr($stored, 3), true);
    $p = $b === false ? false : openssl_decrypt(substr($b, 28), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, substr($b, 0, 12), substr($b, 12, 16), $col . "\0" . $id);
    if ($p === false) throw new SjError('decrypt', 'Record nahi khula (' . $col . '/' . $id . ') — encryption key badal gayi hai kya?');
    return $p;
}
/* encrypts older plain rows a few hundred at a time */
function sj_migrate_enc() {
    if (!sj_key() || sj_meta_get('enc_done') === '1') return;
    $db = sj_db();
    $rows = $db->query("SELECT col, id, data FROM sj_docs WHERE data IS NOT NULL AND data NOT LIKE 'e1:%' LIMIT 400")->fetchAll();
    if ($rows) {
        $db->beginTransaction();
        try {
            $up = $db->prepare('UPDATE sj_docs SET data = ? WHERE col = ? AND id = ? AND data = ?');
            foreach ($rows as $r) $up->execute([sj_enc($r['data'], $r['col'], $r['id']), $r['col'], $r['id'], $r['data']]);
            $db->commit();
        } catch (Exception $e) { $db->rollBack(); throw $e; }
    }
    if (count($rows) < 400) sj_meta_set('enc_done', '1');
}

/* ---------------- login ---------------- */
function sj_https() {
    if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') return true;
    if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') return true;
    if (isset($_SERVER['HTTP_X_FORWARDED_SSL']) && strtolower($_SERVER['HTTP_X_FORWARDED_SSL']) === 'on') return true;
    if (isset($_SERVER['HTTP_CF_VISITOR']) && stripos($_SERVER['HTTP_CF_VISITOR'], 'https') !== false) return true;
    if (isset($_SERVER['SERVER_PORT']) && (string)$_SERVER['SERVER_PORT'] === '443') return true;
    return false;
}
function sj_local() { $h = strtolower(preg_replace('/:\d+$/', '', isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '')); return $h === 'localhost' || $h === '127.0.0.1' || $h === '[::1]'; }
function sj_cookie_path() { $p = str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/')); return rtrim($p, '/') . '/'; }
function sj_set_cookie($val, $exp) {
    if (PHP_VERSION_ID >= 70300) setcookie('sj_auth', $val, ['expires' => $exp, 'path' => sj_cookie_path(), 'secure' => sj_https(), 'httponly' => true, 'samesite' => 'Strict']);
    else setcookie('sj_auth', $val, $exp, sj_cookie_path() . '; samesite=Strict', '', sj_https(), true);
}
function sj_login_days() { return max(1, (int)sj_cfg('login_days', 90)); }
function sj_issue_token($uid) {
    $t = bin2hex(random_bytes(32)); $now = time(); $exp = $now + 86400 * sj_login_days();
    $ua = substr(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 0, 200);
    sj_db()->prepare('INSERT INTO sj_tokens (h, created, expires, seen, ua, uid, dev) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([hash('sha256', $t), $now, $exp, $now, $ua, $uid, sj_dev_id()]);
    sj_db()->prepare('DELETE FROM sj_tokens WHERE expires < ?')->execute([$now]);
    sj_db()->prepare('UPDATE sj_users SET last_login = ? WHERE id = ?')->execute([$now, $uid]);
    sj_set_cookie($t, $exp);
}
function sj_token_hash() { $t = isset($_COOKIE['sj_auth']) ? $_COOKIE['sj_auth'] : ''; return is_string($t) && preg_match('/^[a-f0-9]{64}$/', $t) ? hash('sha256', $t) : null; }
function sj_owner() { $st = sj_db()->prepare('SELECT * FROM sj_users WHERE id = ?'); $st->execute([SJ_OWNER_ID]); return $st->fetch() ?: null; }
function sj_needs_setup() { $o = sj_owner(); return !$o || $o['pass'] === null || $o['pass'] === ''; }
/** the logged-in user, or null */
function sj_user() {
    static $u = false;
    if ($u !== false) return $u;
    $h = sj_token_hash(); if (!$h) return $u = null;
    $st = sj_db()->prepare('SELECT t.expires, t.seen, t.dev, u.id, u.uname, u.name, u.role, u.active, u.pass FROM sj_tokens t JOIN sj_users u ON u.id = t.uid WHERE t.h = ?');
    $st->execute([$h]); $r = $st->fetch();
    if (!$r || (int)$r['expires'] < time() || !(int)$r['active'] || $r['pass'] === null || !in_array($r['role'], SJ_ROLES, true)) return $u = null;
    if ($r['role'] !== 'owner' && function_exists('sj_login_expired') && sj_login_expired($r['id'])) return $u = null;
    if ($r['role'] === 'owner' && function_exists('sj_emerg_owner_seen')) sj_emerg_owner_seen();
    if (!empty($r['dev']) && $r['role'] !== 'owner') { $dv = sj_devs(); if (isset($dv[$r['dev']]['st']) && $dv[$r['dev']]['st'] === 'blocked') return $u = null; }
    if (time() - (int)$r['seen'] > 86400) {
        $exp = time() + 86400 * sj_login_days();
        sj_db()->prepare('UPDATE sj_tokens SET seen = ?, expires = ? WHERE h = ?')->execute([time(), $exp, $h]);
        sj_set_cookie($_COOKIE['sj_auth'], $exp);
    }
    return $u = ['id' => $r['id'], 'uname' => $r['uname'], 'name' => $r['name'], 'role' => $r['role']];
}
function sj_require_user() { $u = sj_user(); if (!$u) sj_fail('login_required', 401, 'Login kijiye.'); $hb = sj_hours_block($u); if ($hb) { if (sj_once_today('offh:' . $u['id'])) sj_sec_alert('off_hours', 'Dukaan ke samay ke BAAHAR koshish: ' . $u['name'] . ' · ' . sj_hm_now(), 'medium', $u); sj_fail('off_hours', 403, $hb); } return $u; }
function sj_require_role($roles) { $u = sj_require_user(); if (!in_array($u['role'], $roles, true)) sj_fail('forbidden_role', 403, 'Ye kaam sirf ' . implode(' / ', array_map('ucfirst', $roles)) . ' kar sakte hain.'); return $u; }
function sj_public_user($u) { return $u ? ['id' => $u['id'], 'uname' => $u['uname'], 'name' => $u['name'], 'role' => $u['role']] : null; }

function sj_ip() { return substr(isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '?', 0, 64); }
function sj_throttled($key = null) {
    $db = sj_db(); $db->prepare('DELETE FROM sj_fails WHERE at < ?')->execute([time() - 86400]);
    $st = $db->prepare('SELECT COUNT(*) FROM sj_fails WHERE ip = ? AND at >= ?');
    $st->execute([sj_ip(), time() - 900]); if ((int)$st->fetchColumn() >= 8) return true;
    if ($key) { $st->execute(['u:' . $key, time() - 900]); if ((int)$st->fetchColumn() >= 15) return true; }
    return false;
}
function sj_add_fail($key = null) {
    $ins = sj_db()->prepare('INSERT INTO sj_fails (ip, at) VALUES (?, ?)');
    $ins->execute([sj_ip(), time()]); if ($key) $ins->execute(['u:' . substr($key, 0, 60), time()]);
    usleep(700000);
}
function sj_require_secure() {
    if (sj_https() || sj_local() || sj_cfg('allow_http', false)) return;
    sj_fail('https_required', 403, 'Suraksha ke liye login sirf https:// par hota hai. Hosting panel mein free SSL on kijiye aur website https:// se kholiye.');
}
/* Password bhool gaye? sj-data folder mein RESET-PASSWORD naam ki file banaiye (sirf Owner ka password reset hota hai). */
function sj_check_reset() {
    foreach (['RESET-PASSWORD', 'RESET-PASSWORD.txt', 'reset-password', 'reset-password.txt'] as $n) {
        $f = __DIR__ . '/sj-data/' . $n;
        if (file_exists($f)) {
            sj_db()->prepare('UPDATE sj_users SET pass = NULL WHERE id = ?')->execute([SJ_OWNER_ID]);
            sj_db()->exec('DELETE FROM sj_tokens');
            @unlink($f); return;
        }
    }
}

/* ---------------- permissions (checked for every write) ---------------- */
function sj_load_doc($col, $id) {
    $st = sj_db()->prepare('SELECT data, deleted FROM sj_docs WHERE col = ? AND id = ?'); $st->execute([$col, $id]); $r = $st->fetch();
    if (!$r || (int)$r['deleted'] === 1 || $r['data'] === null) return null;
    return json_decode(sj_dec($r['data'], $col, $id), true);
}
function sj_check_op($u, $o, $c, $i, &$d) {
    $role = $u['role'];
    if ($c === 'summary') return null;                     // the app keeps this up to date for everyone
    if ($role === 'viewer') return 'Aapka login sirf dekhne (View only) ke liye hai.';
    $sw = sj_sec_check($u, $o, $c, $i, $d); if ($sw) return $sw;
    if ($c === 'sjReqs') return null;
    if ($c === 'alerts' && $role !== 'owner') return 'Alerts sirf Owner badal sakta hai.';
    if ($c === 'vouchers' && $o === 'set') { $nv = json_decode($d, true); if (is_array($nv) && ((float)(isset($nv['balance']) ? $nv['balance'] : 0) < -0.005 || (float)(isset($nv['amount']) ? $nv['amount'] : 0) < 0)) return 'Voucher ka balance minus nahi ho sakta.'; }
    if ($c === 'vouchers' && $role !== 'owner') {           // staff may sell (new) and redeem (balance down) — never top a voucher up or rewrite it
        $old = sj_load_doc($c, $i);
        if ($o === 'del') { if ($old !== null && $role !== 'manager') return 'Gift voucher sirf Owner / Manager hata sakta hai.'; return null; }
        $new = json_decode($d, true); if (!is_array($new)) return 'Galat voucher.';
        if ($old === null) { if ((float)(isset($new['balance']) ? $new['balance'] : 0) > (float)(isset($new['amount']) ? $new['amount'] : 0) + 0.005) return 'Voucher ka balance rakam se zyada nahi ho sakta.'; return null; }
        foreach (['code', 'amount', 'customerId', 'issueDate', 'expiry', 'source'] as $k) if (json_encode(isset($old[$k]) ? $old[$k] : null) !== json_encode(isset($new[$k]) ? $new[$k] : null)) return 'Gift voucher ki rakam / code / tareekh sirf Owner badal sakta hai.';
        if ((float)(isset($new['balance']) ? $new['balance'] : 0) > (float)(isset($old['balance']) ? $old['balance'] : 0) + 0.005) return 'Voucher ka balance badhaya nahi ja sakta — sirf Owner.';
        return null;
    }
    if ($c === 'audit') {                                  // audit trail is write-once for everybody
        if ($o !== 'set') return 'Audit trail ki entry mitaayi nahi ja sakti.';
        $old = sj_load_doc($c, $i);
        $new = json_decode($d, true);
        if (!is_array($new)) return 'Galat audit entry.';
        $stamp = ['by', 'byUser', 'byRole'];
        if ($old !== null) {                               // same entry again (e.g. restoring a backup) is fine, a changed one is not
            $a = $old; $b = $new; foreach ($stamp as $k) { unset($a[$k], $b[$k]); }
            ksort($a); ksort($b);
            if (json_encode($a) !== json_encode($b)) return 'Audit trail ki entry badli nahi ja sakti.';
            $d = json_encode($old, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
            return null;
        }
        $keep = ($role === 'owner' || $role === 'manager') && isset($new['by']);   // restored entries keep who did them
        if (!$keep) { $new['by'] = $u['name']; $new['byUser'] = $u['uname']; $new['byRole'] = $role; }   // the browser cannot fake this
        $d = json_encode($new, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        return null;
    }
    if ($role !== 'owner' && $c === 'invoices') { $why = sj_lock_check($u, $o, $i, $d); if ($why) return $why; }
    if ($role === 'owner' || $role === 'manager') return null;
    // staff
    if ($o === 'del') {
        if ($c === 'trash') { $t = sj_load_doc($c, $i); if (!$t || (isset($t['deletedAt']) && $t['deletedAt'] < (time() - 29 * 86400) * 1000)) return null; }
        return 'Delete karne ki permission sirf Owner / Manager ke paas hai.';
    }
    if ($c === 'customers' && $o === 'set') {   // the customer's public portal link is managed by the Owner / Manager only
        $old = sj_load_doc($c, $i); $new = json_decode($d, true);
        foreach (['portalToken', 'portalOff', 'portalKacha'] as $k) if (json_encode(is_array($old) && array_key_exists($k, $old) ? $old[$k] : null) !== json_encode(is_array($new) && array_key_exists($k, $new) ? $new[$k] : null)) return 'Customer portal link sirf Owner / Manager badal sakte hain.';
    }
    if ($c === 'settings') {
        $old = sj_load_doc($c, $i); $new = json_decode($d, true);
        if (!is_array($old) || !is_array($new)) return 'Settings sirf Owner / Manager badal sakte hain.';
        foreach (array_unique(array_merge(array_keys($old), array_keys($new))) as $k) {
            $a = array_key_exists($k, $old) ? $old[$k] : null; $b = array_key_exists($k, $new) ? $new[$k] : null;
            if (json_encode($a) !== json_encode($b) && !in_array($k, SJ_RATE_KEYS, true)) return 'Staff sirf aaj ke rate badal sakta hai — baaki settings Owner / Manager badalte hain.';
        }
    }
    return null;
}

/* ---------------- request helpers ---------------- */
function sj_body() {
    $raw = file_get_contents('php://input');
    $len = isset($_SERVER['CONTENT_LENGTH']) ? (int)$_SERVER['CONTENT_LENGTH'] : 0;
    if ($raw === '' || $raw === false) { if ($len > 0) sj_fail('too_large', 413, 'Record bahut bada hai (hosting ki post_max_size limit).'); return []; }
    $j = json_decode($raw, true); if (!is_array($j)) sj_fail('bad_json', 400); return $j;
}
function sj_valid_col($c) {
    if (!is_string($c) || strlen($c) > 255 || !preg_match('#^' . SJ_SEG . '(/' . SJ_SEG . ')*$#', $c)) return false;
    $segs = explode('/', $c); foreach ($segs as $s) if ($s === '.' || $s === '..') return false;
    return count($segs) % 2 === 1;
}
function sj_valid_id($i) { return is_string($i) && preg_match('#^' . SJ_SEG . '$#', $i) && $i !== '.' && $i !== '..'; }
function sj_str($b, $k, $max = 200) { return isset($b[$k]) ? substr(trim((string)$b[$k]), 0, $max) : ''; }

/* ---------------- AI Assistant on the website: the server talks to Google Gemini or Claude (key stays on the server, encrypted) ---------------- */
function sj_ai_key() { $v = sj_meta_get('ai_key'); if (!$v) return ''; try { return (string)sj_dec($v, 'meta', 'ai_key'); } catch (Exception $e) { return ''; } }
function sj_ai_provider() { $p = sj_meta_get('ai_provider'); return $p === 'gemini' ? 'gemini' : 'claude'; }
function sj_ai_model($quick) {
    $m = sj_meta_get('ai_model');
    if (sj_ai_provider() === 'gemini') return $m ? $m : 'gemini-flash-latest';
    if (!$m) $m = sj_cfg('ai_model', 'claude-sonnet-5-5');
    return $quick ? sj_cfg('ai_model_quick', 'claude-haiku-5-5') : $m;
}
function sj_ai_gbase() { return rtrim(sj_cfg('ai_url_gemini', 'https://generativelanguage.googleapis.com/v1beta/models/'), '/'); }
/* Gemini (Google) free plan may keep / review prompts — phone numbers and PAN are masked before sending */
function sj_ai_mask($t) { $t = preg_replace('/(?<![0-9])(?:\+?91[\s-]?)?[6-9][0-9]{4}\s?[0-9]{5}(?![0-9])/', '[phone]', (string)$t); return preg_replace('/\b[A-Z]{5}[0-9]{4}[A-Z]\b/', '[PAN]', $t); }
const SJ_AI_SYS = 'You are Shivaa AI inside the Shivaa Jewels software. Use the tools whenever you need facts. Your FINAL answer is ONLY one JSON object exactly in the OUTPUT FORMAT the first message describes — no text before or after it.';

/* one HTTP call with firm time limits (IPv4 first — many shared hosts hang on IPv6) */
function sj_ai_http($url, $hdr, $body, $timeout = 100) {
    $code = 0; $resp = false; $get = $body === null;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $o = [CURLOPT_HTTPHEADER => $hdr, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 12];
        if (!$get) { $o[CURLOPT_POST] = true; $o[CURLOPT_POSTFIELDS] = $body; }
        if (defined('CURLOPT_IPRESOLVE')) $o[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V4;
        curl_setopt_array($ch, $o);
        $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $err = curl_error($ch); $eno = curl_errno($ch); curl_close($ch);
        if ($resp === false) return ['ok' => false, 'code' => 'upstream_error', 'http' => 502, 'message' => ($eno === 28 ? 'AI server ne ' . $timeout . ' second mein jawab nahi diya (timeout). Dobara try kijiye.' : 'AI server se connection nahi hua: ' . $err)];
    } else {
        $ctx = stream_context_create(['http' => ['method' => $get ? 'GET' : 'POST', 'header' => implode("\r\n", $hdr), 'content' => $get ? '' : $body, 'timeout' => $timeout, 'ignore_errors' => true]]);
        $resp = @file_get_contents($url, false, $ctx);
        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) $code = (int)$m[1];
        if ($resp === false) return ['ok' => false, 'code' => 'upstream_error', 'http' => 502, 'message' => 'AI server se connection nahi hua (hosting par curl / allow_url_fopen band?).'];
    }
    $j = json_decode($resp, true);
    if ($code >= 400 || !is_array($j) || isset($j['error'])) {
        $msg = is_array($j) && isset($j['error']['message']) ? $j['error']['message'] : ('HTTP ' . $code);
        $busy = in_array($code, [500, 502, 503, 504], true) || preg_match('/high demand|overloaded|unavailable|try again later|internal error/i', $msg);
        $c = $code === 429 || $code === 529 ? 'rate_limited' : ($code === 413 ? 'prompt_too_large' : ($code === 401 || $code === 403 || ($code === 400 && stripos($msg, 'api key') !== false) ? 'ai_key_bad' : ($code === 404 ? 'model_missing' : ($busy ? 'ai_busy' : 'upstream_error'))));
        error_log('[shivaa] ai: ' . $code . ' ' . $msg);
        return ['ok' => false, 'code' => $c, 'http' => $code === 429 ? 429 : 502, 'message' => $msg];
    }
    return ['ok' => true, 'json' => $j];
}
function sj_ai_hdr($prov, $key) { return $prov === 'gemini' ? ['content-type: application/json', 'x-goog-api-key: ' . $key] : ['content-type: application/json', 'x-api-key: ' . $key, 'anthropic-version: ' . sj_cfg('ai_version', '2026-10-21')]; }

/* fast key check (no answer generated, no quota used) — also tells which models this key can use */
function sj_ai_check_key($prov, $key) {
    if ($prov === 'gemini') {
        $r = sj_ai_http(sj_ai_gbase() . '?pageSize=200', sj_ai_hdr('gemini', $key), null, 25); if (!$r['ok']) return $r;
        $names = [];
        foreach (isset($r['json']['models']) && is_array($r['json']['models']) ? $r['json']['models'] : [] as $m) {
            if (!isset($m['name'])) continue; $meth = isset($m['supportedGenerationMethods']) ? (array)$m['supportedGenerationMethods'] : ['generateContent'];
            if (!in_array('generateContent', $meth, true)) continue;
            $n = preg_replace('#^models/#', '', $m['name']);
            if (!preg_match('/^gemini-/', $n) || preg_match('/tts|image|live|embed|audio|transcribe|robotics|computer|translate|banana|omni/', $n)) continue;
            $names[] = $n;
        }
        return ['ok' => true, 'models' => array_values(array_unique($names))];
    }
    $r = sj_ai_http(sj_cfg('ai_models_url', 'https://api.anthropic.com/v1/models'), sj_ai_hdr('claude', $key), null, 25); if (!$r['ok']) return $r;
    $names = []; foreach (isset($r['json']['data']) && is_array($r['json']['data']) ? $r['json']['data'] : [] as $m) if (isset($m['id'])) $names[] = $m['id'];
    return ['ok' => true, 'models' => $names];
}
/* best Gemini model for this key: the owner's pick if it exists, else the newest stable Flash */
function sj_ai_pick_gemini($want, $list) {
    if (!$list) return $want && $want !== 'auto' ? $want : 'gemini-flash-latest';
    if ($want && $want !== 'auto' && in_array($want, $list, true)) return $want;
    if (in_array('gemini-flash-latest', $list, true)) return 'gemini-flash-latest';
    $best = ''; $bv = -1;
    foreach ($list as $n) if (preg_match('/^gemini-(\d+(?:\.\d+)?)-flash$/', $n, $m) && (float)$m[1] > $bv) { $bv = (float)$m[1]; $best = $n; }
    if ($best) return $best;
    foreach ($list as $n) if (strpos($n, 'flash') !== false && strpos($n, 'preview') === false) return $n;
    return $list[0];
}
function sj_ai_lite($list, $cur) {
    if (in_array('gemini-flash-lite-latest', $list, true) && $cur !== 'gemini-flash-lite-latest') return 'gemini-flash-lite-latest';
    $best = ''; $bv = -1;
    foreach ($list as $n) if ($n !== $cur && preg_match('/^gemini-(\d+(?:\.\d+)?)-flash-lite$/', $n, $m) && (float)$m[1] > $bv) { $bv = (float)$m[1]; $best = $n; }
    return $best;
}

/* messages (provider-neutral): {role:user|assistant, content} · {role:assistant, raw:<provider's own turn>} · {role:tool, results:[{id,name,result}]} */
function sj_ai_gemini($key, $messages, $max, $tools, $model) {
    $contents = [];
    foreach ($messages as $m) {
        if ($m['role'] === 'tool') { $parts = []; foreach ($m['results'] as $x) { $fr = ['name' => (string)$x['name'], 'response' => ['result' => sj_ai_mask((string)$x['result'])]]; if (!empty($x['id'])) $fr['id'] = (string)$x['id']; $parts[] = ['functionResponse' => $fr]; } $contents[] = ['role' => 'user', 'parts' => $parts]; continue; }
        if ($m['role'] === 'assistant' && isset($m['raw']) && is_array($m['raw'])) { $raw = $m['raw']; $raw['role'] = 'model'; if (isset($raw['parts']) && is_array($raw['parts'])) foreach ($raw['parts'] as $pi => $pt) if (isset($pt['functionCall']) && (!isset($pt['functionCall']['args']) || $pt['functionCall']['args'] === [])) $raw['parts'][$pi]['functionCall']['args'] = new stdClass(); $contents[] = $raw; continue; }
        $parts = []; if (!empty($m['images'])) foreach ($m['images'] as $x) $parts[] = ['inlineData' => ['mimeType' => $x['mime'], 'data' => $x['data']]];
        $parts[] = ['text' => sj_ai_mask($m['content'])];
        $contents[] = ['role' => $m['role'] === 'assistant' ? 'model' : 'user', 'parts' => $parts];
    }
    $req = ['systemInstruction' => ['parts' => [['text' => SJ_AI_SYS]]], 'contents' => $contents, 'generationConfig' => ['maxOutputTokens' => (int)$max]];
    if ($tools) {
        $fd = []; foreach ($tools as $t) { $d = ['name' => $t['name'], 'description' => $t['description']]; if (count((array)$t['schema']['properties'])) $d['parameters'] = $t['schema']; $fd[] = $d; }
        $req['tools'] = [['functionDeclarations' => $fd]];
    } else $req['generationConfig']['responseMimeType'] = 'application/json';
    $body = json_encode($req, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $r = sj_ai_http(sj_ai_gbase() . '/' . rawurlencode($model) . ':generateContent', sj_ai_hdr('gemini', $key), $body); if (!$r['ok']) return $r;
    $j = $r['json']; $cont = isset($j['candidates'][0]['content']) && is_array($j['candidates'][0]['content']) ? $j['candidates'][0]['content'] : ['role' => 'model', 'parts' => []];
    $t = ''; $calls = [];
    foreach (isset($cont['parts']) && is_array($cont['parts']) ? $cont['parts'] : [] as $i => $pt) {
        if (isset($pt['functionCall'])) $calls[] = ['id' => isset($pt['functionCall']['id']) ? $pt['functionCall']['id'] : '', 'name' => $pt['functionCall']['name'], 'args' => isset($pt['functionCall']['args']) ? $pt['functionCall']['args'] : new stdClass()];
        elseif (isset($pt['text']) && empty($pt['thought'])) $t .= $pt['text'];
    }
    if ($calls) return ['ok' => true, 'calls' => $calls, 'raw' => $cont, 'model' => $model];
    if ($t === '') { $fr = isset($j['candidates'][0]['finishReason']) ? $j['candidates'][0]['finishReason'] : (isset($j['promptFeedback']['blockReason']) ? $j['promptFeedback']['blockReason'] : '');
        return ['ok' => false, 'code' => 'refused', 'http' => 502, 'message' => 'Gemini ne jawab nahi diya' . ($fr ? ' (' . $fr . ')' : '') . ' — sawal dobara ya thoda alag tarah se poochiye.']; }
    return ['ok' => true, 'text' => $t, 'model' => $model];
}
function sj_ai_claude($key, $messages, $max, $tools, $model) {
    $out = [];
    foreach ($messages as $m) {
        if ($m['role'] === 'tool') { $c = []; foreach ($m['results'] as $x) $c[] = ['type' => 'tool_result', 'tool_use_id' => (string)$x['id'], 'content' => (string)$x['result']]; $out[] = ['role' => 'user', 'content' => $c]; continue; }
        if ($m['role'] === 'assistant' && isset($m['raw']) && is_array($m['raw'])) { $rb = $m['raw']; foreach ($rb as $bi => $blk) if (is_array($blk) && isset($blk['type']) && $blk['type'] === 'tool_use' && (!isset($blk['input']) || $blk['input'] === [])) $rb[$bi]['input'] = new stdClass(); $out[] = ['role' => 'assistant', 'content' => $rb]; continue; }
        if (!empty($m['images'])) { $cb = []; foreach ($m['images'] as $x) $cb[] = ['type' => 'image', 'source' => ['type' => 'base64', 'media_type' => $x['mime'], 'data' => $x['data']]]; $cb[] = ['type' => 'text', 'text' => $m['content']]; $out[] = ['role' => $m['role'], 'content' => $cb]; continue; }
        $out[] = ['role' => $m['role'], 'content' => $m['content']];
    }
    $req = ['model' => $model, 'max_tokens' => (int)$max, 'system' => SJ_AI_SYS, 'messages' => $out];
    if ($tools) { $req['tools'] = []; foreach ($tools as $t) $req['tools'][] = ['name' => $t['name'], 'description' => $t['description'], 'input_schema' => $t['schema'] ? $t['schema'] : ['type' => 'object', 'properties' => new stdClass()]]; }
    $r = sj_ai_http(sj_cfg('ai_url', 'https://api.anthropic.com/v1/messages'), sj_ai_hdr('claude', $key), json_encode($req, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); if (!$r['ok']) return $r;
    $j = $r['json']; $blocks = isset($j['content']) && is_array($j['content']) ? $j['content'] : []; $t = ''; $calls = [];
    foreach ($blocks as $b) { if (!isset($b['type'])) continue; if ($b['type'] === 'text') $t .= $b['text']; elseif ($b['type'] === 'tool_use') $calls[] = ['id' => $b['id'], 'name' => $b['name'], 'args' => isset($b['input']) ? $b['input'] : new stdClass()]; }
    if ($calls) return ['ok' => true, 'calls' => $calls, 'raw' => $blocks, 'model' => $model];
    return ['ok' => true, 'text' => $t, 'model' => $model];
}
function sj_ai_call($messages, $quick, $max, $tools = []) {
    $key = sj_ai_key(); if ($key === '') return ['ok' => false, 'code' => 'ai_not_set', 'http' => 400, 'message' => 'AI key nahi hai.'];
    if (sj_ai_provider() !== 'gemini') return sj_ai_claude($key, $messages, $max, $tools, sj_ai_model($quick));
    $t0 = microtime(true); $main = sj_ai_model(false);
    // Google side busy ("high demand") / free limit / retired model → same key, other Gemini models, one after another
    $list = json_decode((string)sj_meta_get('ai_models'), true); $list = is_array($list) ? $list : [];
    $order = [];
    $sticky = (string)sj_meta_get('ai_alt'); if ($sticky !== '' && strpos($sticky, '|') !== false) { list($sm, $st) = explode('|', $sticky, 2); if (time() - (int)$st < 900 && $sm !== $main) $order[] = $sm; }
    $order[] = $main;
    $lite = sj_ai_lite($list, $main); if ($lite) $order[] = $lite;
    $num = []; foreach ($list as $n) if (preg_match('/^gemini-(\d+(?:\.\d+)?)-flash(-lite)?$/', $n, $m)) $num[$n] = (float)$m[1] - (empty($m[2]) ? 0 : 0.01); arsort($num); foreach (array_slice(array_keys($num), 0, 3) as $n) $order[] = $n;
    foreach (['gemini-flash-latest', 'gemini-2.5-flash', 'gemini-flash-lite-latest', 'gemini-2.5-flash-lite', 'gemini-2.0-flash'] as $n) if (!$list || in_array($n, $list, true)) $order[] = $n;
    $order = array_slice(array_values(array_unique($order)), 0, 5);
    $r = null; $tried = 0; $busy = null; $limit = null;
    foreach ($order as $i => $model) {
        if ($i > 0 && microtime(true) - $t0 > 95) break;          // stay inside the hosting / phone time limit
        $r = sj_ai_gemini($key, $messages, max($max, 8192), $tools, $model); $tried++;
        if ($r['ok']) { if ($model !== $main) sj_meta_set('ai_alt', $model . '|' . time()); elseif ($sticky !== '') sj_meta_set('ai_alt', ''); return $r; }
        if ($r['code'] === 'ai_busy' && $i === 0 && microtime(true) - $t0 < 60) { usleep(1500000); $r = sj_ai_gemini($key, $messages, max($max, 8192), $tools, $model); $tried++; if ($r['ok']) return $r; }
        if ($r['code'] === 'ai_busy') $busy = $r; elseif ($r['code'] === 'rate_limited') $limit = $r;
        if (!in_array($r['code'], ['rate_limited', 'model_missing', 'ai_busy', 'upstream_error'], true)) return $r;   // key bad / prompt too big → switching model won't help
    }
    if ($busy) $r = $busy; elseif ($limit) $r = $limit;
    if ($r && $r['code'] === 'ai_busy') { $r['http'] = 503; $r['message'] = 'Google Gemini abhi bahut busy hai (' . $tried . ' baar alag-alag model try kiye). Aapki key sahi hai — key badalne se fark nahi padega. 1–2 minute baad dobara poochiye.'; }
    elseif ($r && $r['code'] === 'rate_limited') $r['message'] = 'Gemini ki free limit abhi khatam hai — thodi der (ya kal) baad poochiye. (' . $r['message'] . ')';
    return $r;
}

/* ---------------- Shivaa B2B party list: added on the server itself (once), right after an Owner / Manager logs in ---------------- */
function sj_seed_parties($u) {
    if (!in_array($u['role'], ['owner', 'manager'], true)) return;
    $f = __DIR__ . '/sj-data/sj-b2b-seed.php';
    if (!is_file($f)) return;
    $list = require $f;
    if (!is_array($list) || empty($list['parties']) || empty($list['version'])) return;
    if (sj_meta_get('b2b_seed') === $list['version']) return;
    $db = sj_db();
    $have = []; $ids = [];
    $st = $db->query("SELECT id, data FROM sj_docs WHERE col = 'customers' AND deleted = 0 AND data IS NOT NULL");
    foreach ($st->fetchAll() as $r) {
        $ids[$r['id']] = 1;
        $d = json_decode(sj_dec($r['data'], 'customers', $r['id']), true); if (!is_array($d)) continue;
        $ph = isset($d['phones']) && is_array($d['phones']) ? $d['phones'] : [];
        if (!empty($d['phone'])) $ph[] = $d['phone'];
        foreach ($ph as $p) { $p = substr(preg_replace('/\D/', '', (string)$p), -10); if ($p !== '') $have[$p] = 1; }
    }
    $now = (int)round(microtime(true) * 1000); $new = [];
    foreach ($list['parties'] as $i => $p) {
        if (!is_array($p) || empty($p['phone']) || empty($p['name'])) continue;
        $id = 'c_b2b_' . preg_replace('/\D/', '', $p['phone']);
        if (isset($ids[$id])) continue;
        $phones = isset($p['phones']) && is_array($p['phones']) ? array_values($p['phones']) : [$p['phone']];
        $dup = false; foreach ($phones as $q) if (isset($have[substr(preg_replace('/\D/', '', (string)$q), -10)])) $dup = true;
        if ($dup) continue;
        $new[] = [$id, ['id' => $id, 'name' => $p['name'], 'phone' => $p['phone'], 'phones' => $phones, 'contact' => isset($p['contact']) ? $p['contact'] : '', 'city' => isset($p['city']) ? $p['city'] : '', 'address' => isset($p['address']) ? $p['address'] : '', 'pin' => '', 'gstin' => '', 'pan' => '',
            'notes' => isset($p['notes']) ? $p['notes'] : '', 'source' => 'Shivaa B2B list', 'imported' => true, 'ptype' => (isset($p['kind']) && $p['kind'] === 'retail') ? 'Retail' : 'B2B', 'creditLimit' => 500000, 'creditDays' => 0, 'margins' => [], 'wastage' => [], 'createdAt' => $now + $i, 'updatedAt' => $now]];
    }
    $db->beginTransaction();
    try {
        if ($new) {
            $db->prepare('UPDATE sj_counter SET v = v + ? WHERE id = 1')->execute([count($new)]);
            $seq = (int)$db->query('SELECT v FROM sj_counter WHERE id = 1')->fetchColumn() - count($new);
            $ins = $db->prepare('REPLACE INTO sj_docs (col, id, data, seq, deleted, updated, uby) VALUES (?, ?, ?, ?, 0, ?, ?)');
            $ch = []; foreach ($new as $n) { $seq++; $j = json_encode($n[1], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); $ins->execute(['customers', $n[0], sj_enc($j, 'customers', $n[0]), $seq, $now, $u['id']]); $ch[] = ['customers', $n[0], $j]; }
            sj_chain_add($db, $ch, $u['id'], 'b2b');
        }
        $db->prepare('REPLACE INTO sj_meta (k, v) VALUES (?, ?)')->execute(['b2b_seed', $list['version']]);
        $db->commit();
    } catch (Exception $e) { $db->rollBack(); error_log('[shivaa] b2b seed: ' . $e->getMessage()); }
}



/* ---------------- Bill lock: after N hours only the Owner can change a bill (new payments are still allowed) ---------------- */
function sj_lock_hours() { $v = sj_meta_get('bill_lock_hours'); return $v === null || $v === false || $v === '' ? 24 : max(0, (int)$v); }
function sj_lock_check($u, $o, $i, $d) {
    $h = sj_lock_hours(); if ($h <= 0) return null;
    $old = sj_load_doc('invoices', $i); if (!$old) return null;
    $made = isset($old['createdAt']) && is_numeric($old['createdAt']) ? (int)($old['createdAt'] / 1000) : (isset($old['date']) ? strtotime($old['date'] . ' 23:59:59 +0530') : time());
    if (time() - $made < $h * 3600) return null;
    $no = isset($old['no']) ? $old['no'] : $i; $msg = '🔒 Bill ' . $no . ' lock hai (' . $h . ' ghante se purana) — ise sirf Owner badal ya mita sakta hai. Payment jodna chalta hai.';
    $bad = '';
    if ($o === 'del') $bad = 'delete';
    else {
        $new = json_decode($d, true); if (!is_array($new)) return null;
        foreach (['id', 'createdAt', 'privilege', 'items', 'totals', 'partyId', 'partyName', 'date', 'type', 'no', 'oldMetal', 'discMode', 'discValue', 'discount', 'roundOff', 'book', 'creditDays', 'gstMode', 'pos', 'splits', 'received', 'payMode'] as $k) {
            $a = array_key_exists($k, $old) ? $old[$k] : null; $b = array_key_exists($k, $new) ? $new[$k] : null;
            if (json_encode($a) !== json_encode($b)) { $bad = $k; break; }
        }
        if (!$bad) {   // payments: may only be added; an existing payment may only get its bank / reconcile stamp
            $np = []; foreach (isset($new['payments']) && is_array($new['payments']) ? $new['payments'] : [] as $p) { if (!is_array($p) || !isset($p['id'])) { $bad = 'payment galat'; break; } if ((float)(isset($p['amount']) ? $p['amount'] : 0) < 0 || (float)(isset($p['fine']) ? $p['fine'] : 0) < 0) { $bad = 'minus payment'; break; } $np[$p['id']] = $p; }
            if (!$bad) foreach (isset($old['payments']) && is_array($old['payments']) ? $old['payments'] : [] as $p) {
                if (!isset($p['id'])) continue;
                if (!isset($np[$p['id']])) { $bad = 'payment hataya'; break; }
                $q = $np[$p['id']]; foreach (['amount', 'date', 'mode', 'fine'] as $k) if (json_encode(isset($p[$k]) ? $p[$k] : null) !== json_encode(isset($q[$k]) ? $q[$k] : null)) { $bad = 'payment badla'; break 2; }
            }
            if (!$bad && empty($old['payments']) && isset($old['totals']['received']) && (float)$old['totals']['received'] > 0) {   // old bills keep the amount received at billing as the first payment
                $sum = 0; foreach ($np as $p) $sum += (float)(isset($p['amount']) ? $p['amount'] : 0); if ($sum + 0.5 < (float)$old['totals']['received']) $bad = 'payment ghataya';
            }
        }
    }
    if (!$bad) return null;
    try { sj_put_docs([['alerts', 'al_' . base_convert((string)round(microtime(true) * 1000), 10, 36) . '_' . bin2hex(random_bytes(3)), ['kind' => 'lock_try', 'text' => 'LOCK todne ki koshish: bill ' . $no . ' (' . $bad . ') — rok diya gaya', 'col' => 'invoices', 'docId' => $i, 'level' => 'high', 'night' => sj_ist_hour() >= 22 || sj_ist_hour() < 7, 'by' => $u['name'] . ' (' . $u['role'] . ')', 'byUser' => $u['uname'], 'at' => (int)round(microtime(true) * 1000), 'seen' => false]]], $u['id']); } catch (Exception $e) { error_log('[shivaa] lock alert: ' . $e->getMessage()); }
    return $msg;
}

/* ---------------- Suspicious-activity alerts (made here on the server — a staff browser cannot skip them) ---------------- */
function sj_ist_hour() { return (int)gmdate('G', time() + 19800); }
function sj_doc_payable($v) { $t = isset($v['totals']) && is_array($v['totals']) ? $v['totals'] : []; return (float)(isset($t['payable']) ? $t['payable'] : (isset($t['grand']) ? $t['grand'] : 0)); }
function sj_doc_paid($v) { $s = 0; if (isset($v['payments']) && is_array($v['payments'])) { foreach ($v['payments'] as $p) $s += (float)(isset($p['amount']) ? $p['amount'] : 0); } elseif (isset($v['totals']['received'])) $s = (float)$v['totals']['received']; return round($s, 2); }
function sj_inr($n) { $n = round((float)$n); $neg = $n < 0; $n = abs($n); $s = (string)$n; if (strlen($s) > 3) { $last = substr($s, -3); $rest = substr($s, 0, -3); $rest = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', $rest); $s = $rest . ',' . $last; } return ($neg ? '-' : '') . '₹' . $s; }
function sj_alerts_for($u, $clean) {
    if ($u['role'] === 'owner') { $hasField = false; foreach ($clean as $r) if ($r[0] === 'challans') $hasField = true; if (!$hasField) return []; }
    $out = []; $night = sj_ist_hour() >= 22 || sj_ist_hour() < 7; $who = $u['name'] . ' (' . $u['role'] . ')';
    $add = function ($kind, $text, $col, $id, $level) use (&$out, $night, $u, $who) { $out[] = ['kind' => $kind, 'text' => $text, 'col' => $col, 'docId' => $id, 'level' => $night ? 'high' : $level, 'night' => $night, 'by' => $who, 'byUser' => $u['uname'], 'at' => (int)round(microtime(true) * 1000), 'seen' => false]; };
    foreach ($clean as $r) {
        list($c, $i, $d, $del) = $r;
        if (in_array($c, ['summary', 'tagState', 'audit', 'alerts', 'trash', 'notes'], true)) continue;
        $old = sj_load_doc($c, $i); $new = $d === null ? null : json_decode($d, true);
        sj_sec_alerts($u, $c, $i, $old, $new, $add);
        if ($c === 'challans' || $c === 'floorTx' || $c === 'audits') continue;
        if ($c === 'invoices') {
            if ($del && $old) { $add('bill_delete', 'Bill DELETE kiya: ' . (isset($old['no']) ? $old['no'] : $i) . ' · ' . (isset($old['partyName']) ? $old['partyName'] : '') . ' · ' . sj_inr(sj_doc_payable($old)), $c, $i, 'high'); continue; }
            if ($old && is_array($new)) {
                $ch = [];
                if (abs(sj_doc_payable($old) - sj_doc_payable($new)) > 1) $ch[] = 'amount ' . sj_inr(sj_doc_payable($old)) . ' → ' . sj_inr(sj_doc_payable($new));
                if (sj_doc_paid($new) + 1 < sj_doc_paid($old)) $ch[] = 'payment ghataya ' . sj_inr(sj_doc_paid($old)) . ' → ' . sj_inr(sj_doc_paid($new));
                if ((isset($old['partyId']) ? $old['partyId'] : '') !== (isset($new['partyId']) ? $new['partyId'] : '')) $ch[] = 'party badli ' . (isset($old['partyName']) ? $old['partyName'] : '') . ' → ' . (isset($new['partyName']) ? $new['partyName'] : '');
                if ((isset($old['date']) ? $old['date'] : '') !== (isset($new['date']) ? $new['date'] : '')) $ch[] = 'date badli ' . (isset($old['date']) ? $old['date'] : '') . ' → ' . (isset($new['date']) ? $new['date'] : '');
                if ($ch) $add('bill_edit', 'Bill BADLA: ' . (isset($new['no']) ? $new['no'] : $i) . ' — ' . implode('; ', $ch), $c, $i, 'medium');
                continue;
            }
            if (!$old && is_array($new) && $night) $add('night_bill', 'Raat ko naya bill bana: ' . (isset($new['no']) ? $new['no'] : $i) . ' · ' . (isset($new['partyName']) ? $new['partyName'] : '') . ' · ' . sj_inr(sj_doc_payable($new)), $c, $i, 'high');
            continue;
        }
        if ($c === 'closings' && is_array($new) && isset($new['diff']) && $new['diff'] !== '' && (!$old || !isset($old['diff']) || abs((float)$old['diff'] - (float)$new['diff']) >= 0.5) && abs((float)$new['diff']) >= (float)(sj_meta_get('cash_alert_min') ?: 100)) { $add('cash_diff', 'CASH milaan ' . (isset($new['date']) ? $new['date'] : '') . ': ' . ((float)$new['diff'] < 0 ? sj_inr(-(float)$new['diff']) . ' KAM' : sj_inr($new['diff']) . ' zyada') . ' (hisaab ' . sj_inr(isset($new['expected']) ? $new['expected'] : 0) . ', gina ' . sj_inr(isset($new['counted']) ? $new['counted'] : 0) . ')' . (!empty($new['note']) ? ' — ' . mb_substr((string)$new['note'], 0, 80) : ''), $c, $i, abs((float)$new['diff']) >= 1000 ? 'high' : 'medium'); continue; }
        if ($c === 'settings' && is_array($new)) {
            $ch = []; foreach (['gold24' => 'Sona 24K /10g', 'silver999' => 'Chandi /kg'] as $k => $lb) { $a = isset($old[$k]) ? (float)$old[$k] : 0; $b = isset($new[$k]) ? (float)$new[$k] : 0; if ($a && abs($a - $b) > 0.5) $ch[] = $lb . ' ' . sj_inr($a) . ' → ' . sj_inr($b) . ' (' . ($b > $a ? '+' : '') . round(($b - $a) / $a * 100, 2) . '%)'; }
            if ($ch) $add('rate_change', 'RATE badla: ' . implode('; ', $ch), $c, $i, 'medium');
            continue;
        }
        if ($del && $old) { $nm = isset($old['name']) ? $old['name'] : (isset($old['sku']) ? '#' . $old['sku'] : (isset($old['no']) ? $old['no'] : $i)); $add('delete', ucfirst($c) . ' DELETE: ' . $nm . (isset($old['amount']) ? ' · ' . sj_inr($old['amount']) : ''), $c, $i, 'medium'); continue; }
        if ($c === 'products' && $old && is_array($new) && isset($old['gross'], $new['gross']) && abs((float)$old['gross'] - (float)$new['gross']) > 0.001) $add('stock_edit', 'Stock ka WAZAN badla: #' . (isset($new['sku']) ? $new['sku'] : $i) . ' ' . $old['gross'] . ' g → ' . $new['gross'] . ' g', $c, $i, 'medium');
        if ($night && is_array($new) && in_array($c, ['expenses', 'banktx', 'products'], true) && !$old) $add('night_entry', 'Raat ko nayi entry: ' . $c . (isset($new['amount']) ? ' · ' . sj_inr($new['amount']) : ''), $c, $i, 'high');
    }
    return $out;
}
function sj_put_docs($rows, $uid) {   // rows: [[col, id, array]]
    if (!$rows) return; $db = sj_db(); $db->beginTransaction();
    try {
        $db->prepare('UPDATE sj_counter SET v = v + ? WHERE id = 1')->execute([count($rows)]);
        $seq = (int)$db->query('SELECT v FROM sj_counter WHERE id = 1')->fetchColumn() - count($rows); $now = (int)round(microtime(true) * 1000);
        $rep = $db->prepare('REPLACE INTO sj_docs (col, id, data, seq, deleted, updated, uby) VALUES (?, ?, ?, ?, 0, ?, ?)');
        $ch = []; foreach ($rows as $r) { $seq++; $j = json_encode($r[2], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); $rep->execute([$r[0], $r[1], sj_enc($j, $r[0], $r[1]), $seq, $now, $uid]); $ch[] = [$r[0], $r[1], $j]; }
        sj_chain_add($db, $ch, $uid, 's');
        $db->commit();
    } catch (Exception $e) { $db->rollBack(); error_log('[shivaa] put docs: ' . $e->getMessage()); }
}
function sj_alert_mail($alerts) {
    if (function_exists('sj_tg_alerts')) { try { sj_tg_alerts($alerts); } catch (Exception $e) { /* best effort */ } }
    $to = (string)sj_meta_get('alert_email'); if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL) || !function_exists('mail')) return;
    $day = gmdate('Y-m-d', time() + 19800); $cnt = json_decode((string)sj_meta_get('alert_mail_count'), true); if (!is_array($cnt) || $cnt['d'] !== $day) $cnt = ['d' => $day, 'n' => 0];
    if ($cnt['n'] >= 60) return; $cnt['n']++; sj_meta_set('alert_mail_count', json_encode($cnt));
    $host = preg_replace('/[^a-z0-9.\-]/', '', strtolower(isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']) : 'localhost'));
    $lines = []; foreach ($alerts as $a) $lines[] = ($a['night'] ? '[RAAT] ' : '') . $a['text'] . "\n   — " . $a['by'] . ', ' . gmdate('d-m-Y h:i A', (int)($a['at'] / 1000) + 19800) . ' IST';
    $subj = '=?UTF-8?B?' . base64_encode('🚨 Shivaa Jewels alert: ' . mb_substr($alerts[0]['text'], 0, 60)) . '?=';
    @mail($to, $subj, implode("\n\n", $lines) . "\n\nSoftware kholiye: https://" . $host . "/\n(Ye email Shivaa Jewels software ne apne-aap bheja hai.)", "From: Shivaa Jewels <no-reply@" . $host . ">\r\nContent-Type: text/plain; charset=UTF-8");
}

/* ---------------- Customer portal (public page by secret link) ---------------- */
function sj_all_docs($col) { $st = sj_db()->prepare('SELECT id, data FROM sj_docs WHERE col = ? AND deleted = 0 AND data IS NOT NULL'); $st->execute([$col]); $out = []; while ($r = $st->fetch()) { $j = json_decode(sj_dec($r['data'], $col, $r['id']), true); if (is_array($j)) $out[] = $j; } return $out; }
function sj_h($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function sj_portal_page($tok) {
    header_remove('Content-Security-Policy'); header('Content-Type: text/html; charset=utf-8');
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; img-src data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    header('X-Robots-Tag: noindex, nofollow'); header('Referrer-Policy: no-referrer');
    $c = null;
    if (preg_match('/^[A-Za-z0-9]{20,64}$/', $tok)) foreach (sj_all_docs('customers') as $x) if (!empty($x['portalToken']) && hash_equals((string)$x['portalToken'], $tok) && empty($x['portalOff'])) { $c = $x; break; }
    $set = sj_load_doc('settings', 'main'); if (!is_array($set)) $set = [];
    $firm = isset($set['firm']) && $set['firm'] !== '' ? $set['firm'] : 'Shivaa Jewels'; $fphone = preg_replace('/\D/', '', isset($set['phone']) ? $set['phone'] : '');
    $head = '<!doctype html><html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . sj_h($firm) . ' — Mera khata</title><style>
:root{--bg:#0f0d09;--card:#17130c;--ink:#f3e9cf;--mut:#b5a888;--gold:#e7c35f;--line:#3a3020;--ok:#3ccf7a;--bad:#ef6b6b}
@media (prefers-color-scheme:light){:root{--bg:#faf6ec;--card:#fff;--ink:#2a2213;--mut:#7a6b4b;--gold:#9b7316;--line:#eadfc4}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.w{max-width:760px;margin:0 auto;padding:18px 16px 40px}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px}
.firm{font-family:Georgia,serif;font-size:22px;color:var(--gold);letter-spacing:.5px}.sub{color:var(--mut);font-size:13px}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;margin:12px 0}
h2{font-size:15px;margin:0 0 10px;color:var(--gold);font-weight:600}.k{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}
.k div{border:1px solid var(--line);border-radius:12px;padding:10px 12px}.k b{display:block;font-size:20px}.k span{color:var(--mut);font-size:12px}
table{width:100%;border-collapse:collapse;font-size:13.5px}th,td{padding:7px 6px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{color:var(--mut);font-weight:500;font-size:12px}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.due{color:var(--bad);font-weight:600}.ok{color:var(--ok)}
.tw{overflow-x:auto}td.d{white-space:nowrap}@media(max-width:480px){table{font-size:12.5px}th,td{padding:6px 4px}}.pill{display:inline-block;font-size:11.5px;padding:1px 8px;border-radius:20px;border:1px solid var(--line)}
.steps{display:flex;gap:4px;margin-top:6px}.steps i{flex:1;height:5px;border-radius:4px;background:var(--line)}.steps i.on{background:var(--gold)}
.btn{display:inline-block;background:#25d366;color:#05220f;text-decoration:none;font-weight:600;padding:10px 16px;border-radius:12px}.foot{color:var(--mut);font-size:12px;text-align:center;margin-top:22px}
</style></head><body><div class="w">';
    if (!$c) { sj_db()->prepare('INSERT INTO sj_fails (ip, at) VALUES (?, ?)')->execute(['p:' . sj_ip(), time()]); echo $head . '<div class="top"><div><div class="firm">' . sj_h($firm) . '</div></div></div><div class="card"><h2>Link band hai</h2><p>Ye link galat hai ya dukaan ne ise band kar diya hai. Kripya dukaan se naya link maangiye.</p></div></div></body></html>'; exit; }
    $kacha = !empty($c['portalKacha']); $cid = $c['id']; $today = gmdate('Y-m-d', time() + 19800);
    $flash = ''; if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST') { $res = sj_portal_request($c, $tok); $flash = $res === true ? '<div class="card" style="border-color:var(--ok)"><b class="ok">✓ Aapki request dukaan tak pahunch gayi.</b><div class="sub">Dukaan jaldi aapse WhatsApp / phone par sampark karegi.</div></div>' : '<div class="card"><b class="due">' . sj_h($res) . '</b></div>'; }
    $bills = []; $pays = []; $due = 0; $billed = 0; $paid = 0; $fineDue = 0; $locker = [];
    foreach (sj_all_docs('invoices') as $v) {
        if ((isset($v['partyId']) ? $v['partyId'] : '') !== $cid) continue; $t = isset($v['type']) ? $v['type'] : '';
        if (!in_array($t, ['sale', 'estimate', 'metal'], true)) continue; if ($t === 'estimate' && !$kacha) continue;
        if ($t !== 'metal' && isset($v['items']) && is_array($v['items'])) foreach ($v['items'] as $it) if (is_array($it) && ((float)(isset($it['net']) ? $it['net'] : 0) > 0 || (float)(isset($it['gross']) ? $it['gross'] : 0) > 0)) $locker[] = ['it' => $it, 'date' => isset($v['date']) ? $v['date'] : '', 'no' => isset($v['no']) ? $v['no'] : '', 'id' => isset($v['id']) ? $v['id'] : ''];
        $pay = sj_doc_payable($v); $pd = sj_doc_paid($v); $d = round($pay - $pd, 2);
        $bills[] = ['date' => isset($v['date']) ? $v['date'] : '', 'no' => isset($v['no']) ? $v['no'] : '', 'type' => $t, 'amt' => $pay, 'paid' => $pd, 'due' => $d, 'fine' => $t === 'metal' && isset($v['totals']['fineBalance']) ? (float)$v['totals']['fineBalance'] : 0];
        $billed += $pay; $paid += $pd; if ($d > 0.5) $due += $d;
        if (isset($v['payments']) && is_array($v['payments'])) foreach ($v['payments'] as $p) if ((float)(isset($p['amount']) ? $p['amount'] : 0) > 0) $pays[] = ['date' => isset($p['date']) ? $p['date'] : '', 'amt' => (float)$p['amount'], 'mode' => isset($p['mode']) ? $p['mode'] : '', 'no' => isset($v['no']) ? $v['no'] : ''];
        if ($t === 'metal') { $fp = 0; if (isset($v['payments'])) foreach ($v['payments'] as $p) $fp += (float)(isset($p['fine']) ? $p['fine'] : 0); $fineDue += max(0, (isset($v['totals']['fineBalance']) ? (float)$v['totals']['fineBalance'] : 0) - $fp); }
    }
    usort($bills, function ($a, $b) { return strcmp($b['date'], $a['date']); }); usort($pays, function ($a, $b) { return strcmp($b['date'], $a['date']); });
    $orders = array_values(array_filter(sj_all_docs('orders'), function ($o) use ($cid) { return (isset($o['partyId']) ? $o['partyId'] : '') === $cid && (isset($o['type']) ? $o['type'] : 'sale') === 'sale'; }));
    usort($orders, function ($a, $b) { return strcmp(isset($b['orderDate']) ? $b['orderDate'] : '', isset($a['orderDate']) ? $a['orderDate'] : ''); });
    $schemes = array_values(array_filter(sj_all_docs('schemes'), function ($m) use ($cid) { return (isset($m['customerId']) ? $m['customerId'] : (isset($m['partyId']) ? $m['partyId'] : '')) === $cid; }));
    $fd = function ($d) { return preg_match('/^(\d{4})-(\d{2})-(\d{2})/', (string)$d, $m) ? $m[3] . '-' . $m[2] . '-' . $m[1] : sj_h($d); };
    $tl = ['sale' => 'Bill', 'estimate' => 'Estimate', 'metal' => 'Metal'];
    $fs = function ($d) { return preg_match('/^\d{2}(\d{2})-(\d{2})-(\d{2})/', (string)$d, $m) ? $m[3] . '-' . $m[2] . '-' . $m[1] : sj_h($d); };
    $o = $head . '<div class="top"><div><div class="firm">' . sj_h($firm) . '</div><div class="sub">' . sj_h(isset($set['address']) ? $set['address'] : '') . '</div></div>' . ($fphone ? '<a class="btn" href="https://wa.me/91' . sj_h(substr($fphone, -10)) . '?text=' . rawurlencode('Namaste, main ' . $c['name'] . ' — mera khata dekh raha tha.') . '" rel="noopener">WhatsApp</a>' : '') . '</div>';
    $o .= '<div class="card"><div style="font-size:18px;font-weight:600">' . sj_h($c['name']) . '</div><div class="sub">' . sj_h(isset($c['city']) ? $c['city'] : '') . ' · Aaj ' . $fd($today) . '</div>';
    $o .= '<div class="k" style="margin-top:12px"><div><span>Kul baaki</span><b class="' . ($due > 0.5 ? 'due' : 'ok') . '">' . sj_inr($due) . '</b></div><div><span>Kul kharid</span><b>' . sj_inr($billed) . '</b></div><div><span>Kul jama</span><b>' . sj_inr($paid) . '</b></div>' . ($fineDue > 0.0005 ? '<div><span>Fine sona baaki</span><b class="due">' . number_format($fineDue, 3) . ' g</b></div>' : '') . '</div>';
    if (!empty($set['gold24']) || !empty($set['silver999'])) $o .= '<div class="sub" style="margin-top:10px">Aaj ka rate: ' . (!empty($set['gold24']) ? 'Sona 24K ' . sj_inr($set['gold24']) . '/10g' : '') . (!empty($set['silver999']) ? ' · Chandi ' . sj_inr($set['silver999']) . '/kg' : '') . '</div>';
    $o .= '</div>';
    if ($orders) { $stages = ['New', 'Pending', 'In Progress', 'Ready', 'Completed']; $o .= '<div class="card"><h2>Mere order</h2>'; foreach (array_slice($orders, 0, 12) as $r) { $st = isset($r['status']) ? $r['status'] : 'New'; $ix = array_search($st, $stages, true); $lbl = ['Draft' => 'Draft', 'New' => 'Mil gaya', 'Pending' => 'Shuru hone wala', 'In Progress' => 'Ban raha hai', 'Ready' => 'Taiyaar — le jaaiye', 'Completed' => 'De diya', 'Cancelled' => 'Cancel'];
        $o .= '<div style="padding:8px 0;border-bottom:1px solid var(--line)"><b>' . sj_h(isset($r['no']) ? $r['no'] : '') . '</b> · ' . sj_h(trim((isset($r['category']) ? $r['category'] : '') . ' ' . (isset($r['purity']) ? $r['purity'] : ''))) . (!empty($r['gross']) ? ' · ' . sj_h($r['gross']) . ' g' : '') . ' <span class="pill">' . sj_h(isset($lbl[$st]) ? $lbl[$st] : $st) . '</span><div class="sub">Order ' . $fd(isset($r['orderDate']) ? $r['orderDate'] : '') . (!empty($r['dueDate']) ? ' · Taiyaar hone ki tareekh ' . $fd($r['dueDate']) : '') . '</div>' . ($st !== 'Cancelled' ? '<div class="steps">' . implode('', array_map(function ($k) use ($ix) { return '<i class="' . ($ix !== false && $k <= $ix ? 'on' : '') . '"></i>'; }, [0, 1, 2, 3, 4])) . '</div>' : '') . '</div>'; } $o .= '</div>'; }
    if ($schemes) { $o .= '<div class="card"><h2>Meri scheme</h2>'; foreach ($schemes as $m) { $n = isset($m['payments']) && is_array($m['payments']) ? count($m['payments']) : 0; $tot = 0; if ($n) foreach ($m['payments'] as $p) $tot += (float)(isset($p['amount']) ? $p['amount'] : 0); $months = max(1, (int)(isset($m['months']) ? $m['months'] : 11));
        $o .= '<div style="padding:6px 0;border-bottom:1px solid var(--line)"><b>' . sj_h(isset($m['no']) ? $m['no'] : 'Scheme') . '</b> · ' . $n . '/' . $months . ' kishtein · jama ' . sj_inr($tot) . (!empty($m['startDate']) ? '<div class="sub">Shuru ' . $fd($m['startDate']) . '</div>' : '') . '<div class="steps">' . str_repeat('<i class="on"></i>', min($n, $months)) . str_repeat('<i></i>', max(0, $months - $n)) . '</div></div>'; } $o .= '</div>'; }
    $o .= $flash . sj_portal_locker($c, $locker, $set, $fd) . sj_portal_catalog($c, $tok);
    $o .= '<div class="card"><h2>Bills (' . count($bills) . ')</h2><div class="tw"><table><tr><th>Date</th><th>Bill</th><th class="n">Amount</th><th class="n">Jama</th><th class="n">Baaki</th></tr>';
    foreach (array_slice($bills, 0, 80) as $b) $o .= '<tr><td class="d">' . $fs($b['date']) . '</td><td>' . sj_h($b['no']) . ' <span class="sub">' . $tl[$b['type']] . '</span></td><td class="n">' . sj_inr($b['amt']) . '</td><td class="n">' . sj_inr($b['paid']) . '</td><td class="n ' . ($b['due'] > 0.5 ? 'due' : 'ok') . '">' . ($b['due'] > 0.5 ? sj_inr($b['due']) : '✓') . '</td></tr>';
    if (!$bills) $o .= '<tr><td colspan="5" class="sub">Abhi koi bill nahi.</td></tr>';
    $o .= '</table></div></div><div class="card"><h2>Jama kiye paise</h2><div class="tw"><table><tr><th>Date</th><th>Kaise</th><th>Bill</th><th class="n">Rakam</th></tr>';
    foreach (array_slice($pays, 0, 80) as $p) $o .= '<tr><td class="d">' . $fs($p['date']) . '</td><td>' . sj_h($p['mode']) . '</td><td>' . sj_h($p['no']) . '</td><td class="n">' . sj_inr($p['amt']) . '</td></tr>';
    if (!$pays) $o .= '<tr><td colspan="4" class="sub">Abhi koi payment nahi.</td></tr>';
    $o .= '</table></div></div><div class="foot">Ye page sirf aapke liye hai — link kisi aur ko na bhejein.<br>Koi galti lage to dukaan se sampark karein. · ' . sj_h($firm) . '</div></div></body></html>';
    echo $o; exit;
}

/* =====================================================================
   v25: bill verification, owner 2-step login, daily auto-backup,
        AI market-rate lookup, portal catalogue requests
   ===================================================================== */

/* ---------- Bill verification (QR on every bill → verify.php) ---------- */
function sj_vtok($id) {
    $k = sj_key(); if (!$k) $k = 'sj|' . (string)sj_cfg('setup_code', '') . '|' . (string)sj_cfg('sqlite_file', '');
    return rtrim(strtr(base64_encode(substr(hash_hmac('sha256', 'verify|' . $id, $k, true), 0, 12)), '+/', '-_'), '=');
}
function sj_mask_name($n) {
    $p = preg_split('/\s+/u', trim((string)$n)); if (!$p || $p[0] === '') return '—';
    $o = $p[0]; if (count($p) > 1) $o .= ' ' . mb_substr($p[count($p) - 1], 0, 1) . '.';
    return $o;
}
function sj_page_head($title, $extraCsp = '') {
    header_remove('Content-Security-Policy'); header('Content-Type: text/html; charset=utf-8');
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; img-src data:; frame-ancestors 'none'; base-uri 'none'; form-action " . ($extraCsp ?: "'none'"));
    header('X-Robots-Tag: noindex, nofollow'); header('Referrer-Policy: no-referrer');
    return '<!doctype html><html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>' . sj_h($title) . '</title><style>
:root{--bg:#0f0d09;--card:#17130c;--ink:#f3e9cf;--mut:#b5a888;--gold:#e7c35f;--line:#3a3020;--ok:#3ccf7a;--bad:#ef6b6b}
@media (prefers-color-scheme:light){:root{--bg:#faf6ec;--card:#fff;--ink:#2a2213;--mut:#7a6b4b;--gold:#9b7316;--line:#eadfc4;--ok:#1d8a4c;--bad:#c23b3b}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif}
.w{max-width:760px;margin:0 auto;padding:18px 16px 40px}.firm{font-family:Georgia,serif;font-size:22px;color:var(--gold);letter-spacing:.5px}.sub{color:var(--mut);font-size:13px}
.card{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:16px;margin:12px 0}h2{font-size:15px;margin:0 0 10px;color:var(--gold);font-weight:600}
table{width:100%;border-collapse:collapse;font-size:13.5px}th,td{padding:7px 6px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}th{color:var(--mut);font-weight:500;font-size:12px}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.tw{overflow-x:auto}.big{font-size:20px;font-weight:700}
.ok{color:var(--ok)}.bad{color:var(--bad)}.badge{display:flex;align-items:center;gap:12px;font-size:19px;font-weight:700}.badge i{font-style:normal;display:inline-grid;place-items:center;width:44px;height:44px;border-radius:50%;font-size:24px;color:#fff}
.badge.ok i{background:#1d8a4c}.badge.bad i{background:#c23b3b}.k{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-top:12px}.k div{border:1px solid var(--line);border-radius:12px;padding:10px 12px}.k span{display:block;color:var(--mut);font-size:12px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}.tile{border:1px solid var(--line);border-radius:14px;overflow:hidden;background:var(--card)}.tile img{width:100%;aspect-ratio:1;object-fit:cover;display:block;background:#fff}
.tile div{padding:8px 10px;font-size:13px}.tile form{padding:0 10px 10px}.tile button,.btn{display:inline-block;width:100%;background:var(--gold);color:#1b1206;border:0;border-radius:10px;padding:9px 10px;font-weight:700;font-size:13px;cursor:pointer;text-decoration:none;text-align:center}
.foot{color:var(--mut);font-size:12px;text-align:center;margin-top:22px}.note{border:1px dashed var(--line);border-radius:12px;padding:10px 12px;font-size:13px}
</style></head><body><div class="w">';
}
function sj_verify_page($id, $tok) {
    $set = sj_load_doc('settings', 'main'); if (!is_array($set)) $set = [];
    $firm = isset($set['firm']) && $set['firm'] !== '' ? $set['firm'] : 'Shivaa Jewels';
    $legal = isset($set['legal']) && $set['legal'] !== '' ? $set['legal'] : $firm;
    $o = sj_page_head($firm . ' — Bill verification');
    $o .= '<div class="firm">' . sj_h($firm) . '</div><div class="sub">' . sj_h($legal) . (!empty($set['gstin']) ? ' · GSTIN ' . sj_h($set['gstin']) : '') . '</div>';
    $okTok = sj_valid_id($id) && preg_match('/^[A-Za-z0-9_-]{16}$/', $tok) && hash_equals(sj_vtok($id), $tok);
    if (!$okTok) {
        sj_db()->prepare('INSERT INTO sj_fails (ip, at) VALUES (?, ?)')->execute(['v:' . sj_ip(), time()]);
        echo $o . '<div class="card"><div class="badge bad"><i>✕</i>Ye bill hamare record mein nahi mila</div><p>QR code galat ya badla hua hai. Ye bill ' . sj_h($firm) . ' ka asli bill nahi ho sakta. Kripya dukaan se sampark karein.</p></div></div></body></html>'; exit;
    }
    $st = sj_db()->prepare('SELECT data, deleted, updated FROM sj_docs WHERE col = ? AND id = ?'); $st->execute(['invoices', $id]); $r = $st->fetch();
    if (!$r || (int)$r['deleted'] === 1 || $r['data'] === null) {
        echo $o . '<div class="card"><div class="badge bad"><i>!</i>Ye bill cancel ho chuka hai</div><p>Ye bill pehle ' . sj_h($firm) . ' ne banaya tha, lekin ab cancel / delete kar diya gaya hai. Is bill ke aadhar par lena-dena na karein — dukaan se naya bill maangiye.</p></div></div></body></html>'; exit;
    }
    $v = json_decode(sj_dec($r['data'], 'invoices', $id), true); if (!is_array($v)) $v = [];
    $fd = function ($d) { return preg_match('/^(\d{4})-(\d{2})-(\d{2})/', (string)$d, $m) ? $m[3] . '-' . $m[2] . '-' . $m[1] : sj_h($d); };
    $tl = ['sale' => 'Tax Invoice', 'estimate' => 'Estimate', 'purchase' => 'Purchase bill', 'estpurchase' => 'Purchase estimate', 'oldgold' => 'Old gold voucher', 'metal' => 'Metal voucher'];
    $type = isset($v['type']) ? $v['type'] : '';
    $o .= '<div class="card"><div class="badge ok"><i>✓</i>Asli bill — ' . sj_h($firm) . ' ke record se mila</div>';
    $o .= '<div class="k"><div><span>Bill no.</span><b>' . sj_h(isset($v['no']) ? $v['no'] : '') . '</b></div><div><span>Tareekh</span><b>' . $fd(isset($v['date']) ? $v['date'] : '') . '</b></div><div><span>' . sj_h(isset($tl[$type]) ? $tl[$type] : 'Bill') . '</span><b>' . sj_h(sj_mask_name(isset($v['partyName']) ? $v['partyName'] : '')) . '</b></div>';
    if ($type !== 'metal') $o .= '<div><span>Kul rakam</span><b>' . sj_inr(sj_doc_payable($v)) . '</b></div>';
    $o .= '</div>';
    $upd = isset($v['updatedAt']) ? (int)$v['updatedAt'] : (int)$r['updated']; $made = isset($v['createdAt']) ? (int)$v['createdAt'] : $upd;
    if ($upd && $made && $upd - $made > 120000) $o .= '<p class="sub">Is bill mein aakhri badlaav: ' . gmdate('d-m-Y h:i A', (int)($upd / 1000) + 19800) . ' IST. Agar aapke paas purani copy hai aur rakam alag hai, to dukaan se poochhiye.</p>';
    $o .= '</div>';
    $items = isset($v['items']) && is_array($v['items']) ? $v['items'] : [];
    if ($items) {
        $o .= '<div class="card"><h2>Gehne (' . count($items) . ')</h2><div class="tw"><table><tr><th>#</th><th>Gehna</th><th>HUID</th><th class="n">Net wazan</th>' . ($type !== 'metal' ? '<th class="n">Rakam</th>' : '') . '</tr>';
        foreach ($items as $k => $it) {
            $o .= '<tr><td>' . ($k + 1) . '</td><td>' . sj_h(trim((isset($it['category']) ? $it['category'] : '') . ' ' . (isset($it['purity']) ? $it['purity'] : ''))) . '</td><td>' . (!empty($it['huid']) ? '<b>' . sj_h($it['huid']) . '</b>' : '<span class="sub">—</span>') . '</td><td class="n">' . number_format((float)(isset($it['net']) ? $it['net'] : 0), 3) . ' g</td>' . ($type !== 'metal' ? '<td class="n">' . sj_inr(isset($it['amount']) ? $it['amount'] : 0) . '</td>' : '') . '</tr>';
        }
        $o .= '</table></div>';
        $o .= '<p class="note">HUID wale gehne ki hallmark jaanch: Play Store / App Store se <b>BIS CARE</b> app → “Verify HUID” → upar likha 6 akshar ka HUID daaliye. App mein wahi purity aur jeweller ka naam dikhna chahiye.</p></div>';
    }
    $o .= '<div class="foot">Ye page ' . sj_h($firm) . ' ke software ne banaya hai. Bill ke QR code se hi khulta hai.<br>Galti lage to dukaan se sampark karein.</div></div></body></html>';
    echo $o; exit;
}

/* ---------- Owner 2-step login (Google Authenticator / TOTP) ---------- */
function sj_b32_dec($s) { $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $s = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $s)); $bits = ''; $out = '';
    for ($i = 0; $i < strlen($s); $i++) $bits .= str_pad(decbin(strpos($a, $s[$i])), 5, '0', STR_PAD_LEFT);
    for ($i = 0; $i + 8 <= strlen($bits); $i += 8) $out .= chr(bindec(substr($bits, $i, 8))); return $out; }
function sj_b32_enc($raw) { $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; foreach (str_split($raw) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    $out = ''; for ($i = 0; $i < strlen($bits); $i += 5) $out .= $a[bindec(str_pad(substr($bits, $i, 5), 5, '0'))]; return $out; }
function sj_totp_at($secret, $ctr) { $bin = pack('N*', 0) . pack('N*', $ctr); $h = hash_hmac('sha1', $bin, sj_b32_dec($secret), true); $o = ord($h[19]) & 0xf;
    $n = ((ord($h[$o]) & 0x7f) << 24) | ((ord($h[$o + 1]) & 0xff) << 16) | ((ord($h[$o + 2]) & 0xff) << 8) | (ord($h[$o + 3]) & 0xff); return str_pad((string)($n % 1000000), 6, '0', STR_PAD_LEFT); }
function sj_totp_get() { $v = sj_meta_get('totp'); if (!$v) return null; try { $j = json_decode((string)sj_dec($v, 'meta', 'totp'), true); } catch (Exception $e) { return null; } return is_array($j) && !empty($j['secret']) ? $j : null; }
function sj_totp_put($j) { if ($j === null) { sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute(['totp']); return; } sj_meta_set('totp', sj_enc(json_encode($j), 'meta', 'totp')); }
function sj_totp_on() { return !sj_cfg('disable_2fa', false) && sj_totp_get() !== null; }
/* true when the code (6-digit or one backup code) is right; backup codes are used once, a 6-digit code cannot be replayed */
function sj_totp_check($code) {
    $j = sj_totp_get(); if (!$j) return false; $code = strtoupper(preg_replace('/[\s-]/', '', (string)$code)); if ($code === '') return false;
    if (preg_match('/^\d{6}$/', $code)) { $now = (int)floor(time() / 30); foreach ([0, -1, 1] as $d) { $c = $now + $d; if ($c <= (int)(isset($j['last']) ? $j['last'] : 0)) continue; if (hash_equals(sj_totp_at($j['secret'], $c), $code)) { $j['last'] = $c; sj_totp_put($j); return true; } } return false; }
    $h = hash('sha256', $code); $codes = isset($j['codes']) && is_array($j['codes']) ? $j['codes'] : [];
    foreach ($codes as $i => $c) if (hash_equals($c, $h)) { array_splice($codes, $i, 1); $j['codes'] = $codes; sj_totp_put($j); return true; }
    return false;
}

/* ---------- Daily auto-backup (kept on the server, encrypted as stored) ---------- */
function sj_bk_dir() { $d = __DIR__ . '/sj-data/backups'; if (!is_dir($d)) { @mkdir($d, 0755, true); @file_put_contents($d . '/index.html', ''); } return $d; }
function sj_bk_list() { $d = sj_bk_dir(); $out = []; foreach (glob($d . '/sj-auto-*.json*') ?: [] as $f) { if (!preg_match('/sj-auto-(\d{4}-\d{2}-\d{2})\.json(\.gz)?$/', $f, $m)) continue; $out[] = ['name' => basename($f), 'date' => $m[1], 'size' => filesize($f)]; } usort($out, function ($a, $b) { return strcmp($b['date'], $a['date']); }); return $out; }
function sj_auto_backup($force = false) {
    $day = gmdate('Y-m-d', time() + 19800);
    if (!$force && sj_meta_get('auto_bk_day') === $day) return null;
    sj_meta_set('auto_bk_day', $day);                     // first, so two requests never both write
    @set_time_limit(120);
    $d = sj_bk_dir(); if (!is_writable($d)) return null;
    $gz = function_exists('gzopen'); $f = $d . '/sj-auto-' . $day . '.json' . ($gz ? '.gz' : '');
    $tmp = $f . '.part'; $h = $gz ? gzopen($tmp, 'wb6') : fopen($tmp, 'wb'); if (!$h) return null;
    $w = function ($s) use ($h, $gz) { $gz ? gzwrite($h, $s) : fwrite($h, $s); };
    $db = sj_db(); if (sj_is_mysql()) $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
    $w('{"app":"shivaa-auto-backup","version":1,"at":' . json_encode(gmdate('c')) . ',"rows":[');
    $st = $db->query('SELECT col, id, data, seq, deleted, updated, uby FROM sj_docs WHERE deleted = 0 AND data IS NOT NULL'); $n = 0;
    while ($r = $st->fetch()) { $w(($n++ ? ',' : '') . json_encode([$r['col'], $r['id'], $r['data'], (int)$r['seq'], (int)$r['updated'], $r['uby']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); }
    $st->closeCursor(); if (sj_is_mysql()) $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
    $users = $db->query('SELECT id, uname, name, pass, role, active, created FROM sj_users')->fetchAll();
    $w('],"count":' . $n . ',"users":' . json_encode($users, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '}');
    $gz ? gzclose($h) : fclose($h); @rename($tmp, $f); @chmod($f, 0644);
    // keep: the last 14 days + the oldest backup of each of the 12 months before that
    $L = sj_bk_list(); $keep = []; $month = [];
    foreach ($L as $i => $b) { if ($i < 14) { $keep[$b['name']] = 1; continue; } $month[substr($b['date'], 0, 7)] = $b['name']; }
    foreach (array_slice($month, 0, 12, true) as $nm) $keep[$nm] = 1;
    foreach ($L as $b) if (empty($keep[$b['name']])) @unlink($d . '/' . $b['name']);
    if (sj_meta_get('backup_mail') === '1') { try { sj_backup_mail(false); } catch (Exception $e) { error_log('[shivaa] backup mail: ' . $e->getMessage()); } }
    return $f;
}
/* the backup as a normal "Export" file (readable by Setup → Restore) */
function sj_bk_export($name, $out) {
    if (!preg_match('/^sj-auto-\d{4}-\d{2}-\d{2}\.json(\.gz)?$/', $name)) sj_fail('invalid_argument', 400, 'Galat backup.');
    $f = sj_bk_dir() . '/' . $name; if (!is_file($f)) sj_fail('not_found', 404, 'Backup nahi mila.');
    $raw = substr($name, -3) === '.gz' ? gzdecode(file_get_contents($f)) : file_get_contents($f);
    $j = json_decode($raw, true); if (!is_array($j) || !isset($j['rows'])) sj_fail('decrypt', 500, 'Backup file kharab hai.');
    $by = []; $settings = null;
    foreach ($j['rows'] as $r) { $col = $r[0]; if (strpos($col, '/') !== false || $col === 'alerts') continue; $doc = sj_dec($r[2], $col, $r[1]); if ($col === 'settings') { if ($r[1] === 'main') $settings = $doc; continue; } $by[$col][] = $doc; }
    $s = '{"app":"shivaa-jewellery-software","version":2,"source":"auto-backup","backupDate":' . json_encode(substr($name, 8, 10)) . ',"exportedAt":' . json_encode(gmdate('c'));
    if ($settings !== null) $s .= ',"settings":' . $settings;
    foreach ($by as $col => $docs) $s .= ',' . json_encode($col) . ':[' . implode(',', $docs) . ']';
    $s .= '}'; return $s;
}
function sj_backup_mail($test) {
    $to = (string)sj_meta_get('alert_email'); if (!$to || !filter_var($to, FILTER_VALIDATE_EMAIL) || !function_exists('mail')) return 'no_email';
    $last = (int)sj_meta_get('backup_mail_at'); if (!$test && time() - $last < 6.5 * 86400) return 'not_due';
    $L = sj_bk_list(); if (!$L) return 'no_backup';
    $json = sj_bk_export($L[0]['name'], true); $gzd = function_exists('gzencode') ? gzencode($json, 9) : $json;
    if (strlen($gzd) > 15 * 1024 * 1024) return 'too_big';
    sj_meta_set('backup_mail_at', (string)time());
    $host = preg_replace('/[^a-z0-9.\-]/', '', strtolower(isset($_SERVER['HTTP_HOST']) ? preg_replace('/:\d+$/', '', $_SERVER['HTTP_HOST']) : 'localhost'));
    $bnd = 'sjb' . bin2hex(random_bytes(8)); $fn = 'shivaa-backup-' . $L[0]['date'] . (function_exists('gzencode') ? '.json.gz' : '.json');
    $body = "--$bnd\r\nContent-Type: text/plain; charset=UTF-8\r\n\r\nShivaa Jewels — hafte ka backup (" . $L[0]['date'] . ").\r\n\r\nIs file ko sambhal kar rakhiye. Data wapas laane ke liye: software → Setup → Backup & restore → Restore, aur ye file chuniye (.gz ho to pehle unzip kijiye).\r\n\r\nDhyan: is file mein aapka poora business data hai — kisi ko forward na karein.\r\n\r\n--$bnd\r\nContent-Type: application/octet-stream; name=\"$fn\"\r\nContent-Transfer-Encoding: base64\r\nContent-Disposition: attachment; filename=\"$fn\"\r\n\r\n" . chunk_split(base64_encode($gzd)) . "\r\n--$bnd--";
    $ok = @mail($to, '=?UTF-8?B?' . base64_encode('🗄 Shivaa Jewels backup ' . $L[0]['date']) . '?=', $body, "From: Shivaa Jewels <no-reply@$host>\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"$bnd\"");
    return $ok ? 'sent' : 'mail_failed';
}

/* ---------- AI: today's market rate from the web (owner confirms before it is used) ---------- */
function sj_ai_rate($city) {
    $key = sj_ai_key(); if ($key === '') return ['ok' => false, 'code' => 'ai_not_set', 'http' => 400, 'message' => 'AI key nahi hai — Setup → AI Assistant mein key daaliye.'];
    $today = gmdate('d M Y', time() + 19800);
    $q = "Today is $today (India). Search the web for TODAY's gold and silver rates in $city, Rajasthan, India (if $city is not found use Jaipur). I need: 24K (999) gold per 10 grams in INR, 22K gold per 10 grams in INR, silver 999 per kg in INR. Prefer local bullion / sarafa association rates or major Indian rate sites published today. Reply ONLY with JSON: {\"gold24\":number,\"gold22\":number,\"silver\":number,\"city\":\"...\",\"asOf\":\"date/time text from the source\",\"note\":\"short Hinglish note on where these numbers come from\"}";
    if (sj_ai_provider() === 'gemini') {
        $req = ['contents' => [['role' => 'user', 'parts' => [['text' => $q]]]], 'tools' => [['google_search' => new stdClass()]], 'generationConfig' => ['maxOutputTokens' => 2048]];
        $model = sj_ai_model(false);
        $r = sj_ai_http(sj_ai_gbase() . '/' . rawurlencode($model) . ':generateContent', sj_ai_hdr('gemini', $key), json_encode($req, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 60); if (!$r['ok']) return $r;
        $c = isset($r['json']['candidates'][0]) ? $r['json']['candidates'][0] : []; $t = '';
        foreach (isset($c['content']['parts']) ? $c['content']['parts'] : [] as $p) if (isset($p['text']) && empty($p['thought'])) $t .= $p['text'];
        $src = []; foreach (isset($c['groundingMetadata']['groundingChunks']) ? $c['groundingMetadata']['groundingChunks'] : [] as $g) if (isset($g['web']['uri'])) $src[] = ['url' => $g['web']['uri'], 'title' => isset($g['web']['title']) ? $g['web']['title'] : ''];
    } else {
        $req = ['model' => sj_ai_model(false), 'max_tokens' => 2048, 'messages' => [['role' => 'user', 'content' => $q]], 'tools' => [['type' => sj_cfg('ai_websearch_tool', 'web_search_20250305'), 'name' => 'web_search', 'max_uses' => 4]]];
        $r = sj_ai_http(sj_cfg('ai_url', 'https://api.anthropic.com/v1/messages'), sj_ai_hdr('claude', $key), json_encode($req, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 90); if (!$r['ok']) return $r;
        $t = ''; $src = [];
        foreach (isset($r['json']['content']) ? $r['json']['content'] : [] as $b) { if (isset($b['type']) && $b['type'] === 'text') { $t .= $b['text']; foreach (isset($b['citations']) ? $b['citations'] : [] as $ci) if (isset($ci['url'])) $src[] = ['url' => $ci['url'], 'title' => isset($ci['title']) ? $ci['title'] : '']; } }
    }
    if (!preg_match('/\{[^{}]*"gold24"[^{}]*\}/s', $t, $m)) return ['ok' => false, 'code' => 'refused', 'http' => 502, 'message' => 'AI ko aaj ka bhav pakka nahi mila — haath se daaliye.'];
    $j = json_decode($m[0], true); if (!is_array($j)) return ['ok' => false, 'code' => 'refused', 'http' => 502, 'message' => 'AI ka jawab samajh nahi aaya — haath se daaliye.'];
    $uniq = []; foreach ($src as $s) $uniq[$s['url']] = $s;
    return ['ok' => true, 'gold24' => (float)(isset($j['gold24']) ? $j['gold24'] : 0), 'gold22' => (float)(isset($j['gold22']) ? $j['gold22'] : 0), 'silver' => (float)(isset($j['silver']) ? $j['silver'] : 0), 'city' => (string)(isset($j['city']) ? $j['city'] : $city), 'asOf' => (string)(isset($j['asOf']) ? $j['asOf'] : ''), 'note' => (string)(isset($j['note']) ? $j['note'] : ''), 'sources' => array_slice(array_values($uniq), 0, 5)];
}

/* ---------- Portal: "naye design" catalogue + request button ---------- */
function sj_portal_nonce($tok) { $k = sj_key() ?: 'sj'; return substr(hash_hmac('sha256', 'pf|' . $tok . '|' . gmdate('Y-m-d', time() + 19800), $k), 0, 24); }
function sj_portal_catalog($c, $tok) {
    $cfg = json_decode((string)sj_meta_get('portal_catalog'), true); if (!is_array($cfg) || empty($cfg['on'])) return '';
    $cats = isset($cfg['cats']) && is_array($cfg['cats']) ? $cfg['cats'] : []; $max = max(6, min(60, (int)(isset($cfg['max']) ? $cfg['max'] : 24)));
    $L = array_values(array_filter(sj_all_docs('products'), function ($p) use ($cats) { return (isset($p['status']) ? $p['status'] : '') === 'In Stock' && !empty($p['photo']) && is_string($p['photo']) && strpos($p['photo'], 'data:image/') === 0 && strlen($p['photo']) < 900000 && (!$cats || in_array(isset($p['category']) ? $p['category'] : '', $cats, true)); }));
    if (!$L) return '';
    usort($L, function ($a, $b) { return (isset($b['createdAt']) ? $b['createdAt'] : 0) <=> (isset($a['createdAt']) ? $a['createdAt'] : 0); });
    $L = array_slice($L, 0, $max); $nonce = sj_portal_nonce($tok);
    $o = '<style>.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(150px,100%),1fr));gap:12px}.tile{min-width:0;border:1px solid var(--line);border-radius:14px;overflow:hidden;background:var(--card)}.tile img{width:100%;aspect-ratio:1;object-fit:cover;display:block;background:#fff}.tile div{padding:8px 10px;font-size:13px;overflow-wrap:anywhere}.tile form{padding:0 10px 10px}.tile button{display:block;width:100%;background:var(--gold);color:#1b1206;border:0;border-radius:10px;padding:9px 10px;font-weight:700;font-size:13px;cursor:pointer}</style><div class="card" id="naye"><h2>Naye design — dukaan mein abhi maujood</h2><p class="sub" style="margin-top:-4px">Pasand aaye to “Mujhe ye chahiye” dabaiye — dukaan aapse sampark karegi. Rate us din ke bhav se lagega.</p><div class="grid">';
    foreach ($L as $p) {
        $o .= '<div class="tile"><img src="' . sj_h($p['photo']) . '" alt="" loading="lazy"><div><b>' . sj_h(trim((isset($p['category']) ? $p['category'] : '') . ' ' . (isset($p['purity']) ? $p['purity'] : ''))) . '</b><br><span class="sub">' . (isset($p['net']) && (float)$p['net'] > 0 ? 'Lagbhag ' . number_format((float)$p['net'], 2) . ' g · ' : '') . '#' . sj_h(isset($p['sku']) ? $p['sku'] : '') . '</span></div>';
        $o .= '<form method="post" action="portal.php?t=' . sj_h($tok) . '#naye"><input type="hidden" name="n" value="' . $nonce . '"><input type="hidden" name="p" value="' . sj_h($p['id']) . '"><button type="submit">Mujhe ye chahiye</button></form></div>';
    }
    return $o . '</div></div>';
}
function sj_portal_request($c, $tok) {
    $n = isset($_POST['n']) ? (string)$_POST['n'] : ''; $pid = isset($_POST['p']) ? (string)$_POST['p'] : '';
    if (!hash_equals(sj_portal_nonce($tok), $n) || !sj_valid_id($pid)) return 'Page purana ho gaya — dobara khol kar try kijiye.';
    $p = sj_load_doc('products', $pid); if (!$p || (isset($p['status']) ? $p['status'] : '') !== 'In Stock') return 'Ye design abhi uplabdh nahi hai.';
    $st = sj_db()->prepare('SELECT COUNT(*) FROM sj_fails WHERE ip = ? AND at >= ?'); $st->execute(['pr:' . $c['id'], time() - 86400]); if ((int)$st->fetchColumn() >= 10) return 'Aaj ke liye bahut request ho gayi — dukaan aapse sampark karegi.';
    sj_db()->prepare('INSERT INTO sj_fails (ip, at) VALUES (?, ?)')->execute(['pr:' . $c['id'], time()]);
    $now = (int)round(microtime(true) * 1000); $id = 'pq_' . base_convert((string)$now, 10, 36) . '_' . bin2hex(random_bytes(3));
    $label = trim((isset($p['category']) ? $p['category'] : '') . ' ' . (isset($p['purity']) ? $p['purity'] : '')) . ' #' . (isset($p['sku']) ? $p['sku'] : '');
    $req = ['id' => $id, 'customerId' => $c['id'], 'name' => isset($c['name']) ? $c['name'] : '', 'phone' => isset($c['phone']) ? $c['phone'] : '', 'productId' => $pid, 'sku' => isset($p['sku']) ? $p['sku'] : '', 'label' => $label, 'status' => 'new', 'at' => $now, 'createdAt' => $now, 'updatedAt' => $now, 'source' => 'portal'];
    $al = ['id' => 'al_' . base_convert((string)$now, 10, 36) . '_' . bin2hex(random_bytes(3)), 'kind' => 'portal_req', 'text' => '🛍 ' . (isset($c['name']) ? $c['name'] : 'Customer') . ' ne portal se maanga: ' . $label, 'col' => 'portalReqs', 'docId' => $id, 'level' => 'info', 'night' => false, 'by' => 'Customer portal', 'byUser' => '', 'at' => $now, 'seen' => false];
    sj_put_docs([['portalReqs', $id, $req], ['alerts', $al['id'], $al]], null);
    try { sj_alert_mail([$al]); } catch (Exception $e) { /* */ }
    return true;
}

/* ---------- Portal: "Mera Locker" (every piece the customer bought), gift vouchers, referral code ---------- */
function sj_portal_locker($c, $locker, $set, $fd) {
    $o = '';
    if ($locker) {
        usort($locker, function ($a, $b) { return strcmp($b['date'], $a['date']); });
        $prod = []; foreach (sj_all_docs('products') as $p) { if (!empty($p['id'])) $prod['i:' . $p['id']] = $p; if (!empty($p['sku'])) $prod['s:' . $p['sku']] = $p; }
        $g24 = (float)(isset($set['gold24']) ? $set['gold24'] : 0); $ag = (float)(isset($set['silver999']) ? $set['silver999'] : 0); $fineG = 0; $fineS = 0; $vToday = 0;
        $o .= '<div class="card" id="locker"><h2>🔐 Mera Locker — mere gehne (' . count($locker) . ')</h2><p class="sub" style="margin-top:-4px">Aapne ' . sj_h(!empty($set['firm']) ? $set['firm'] : 'hamari dukaan') . ' se jo bhi gehne liye — photo, wazan, purity aur HUID ke saath. Bill asli hai ya nahi, “Bill check” se dekhiye.</p><div class="lk">';
        foreach (array_slice($locker, 0, 60) as $x) {
            $it = $x['it']; $p = null; if (!empty($it['productId']) && isset($prod['i:' . $it['productId']])) $p = $prod['i:' . $it['productId']]; elseif (!empty($it['sku']) && isset($prod['s:' . $it['sku']])) $p = $prod['s:' . $it['sku']];
            $ph = $p && !empty($p['photo']) && is_string($p['photo']) && strpos($p['photo'], 'data:image/') === 0 && strlen($p['photo']) < 700000 ? $p['photo'] : '';
            $net = (float)(isset($it['net']) && (float)$it['net'] > 0 ? $it['net'] : (isset($it['gross']) ? $it['gross'] : 0)); $tn = (float)(isset($it['tunch']) ? $it['tunch'] : 0);
            $isAg = stripos((string)(isset($it['purity']) ? $it['purity'] : ''), 'silver') !== false || stripos((string)(isset($it['metal']) ? $it['metal'] : ''), 'silver') !== false || (in_array(trim((string)(isset($it['purity']) ? $it['purity'] : '')), ['92.5', '925', '80', '70', '999 Silver'], true));
            $fine = $tn > 0 ? $net * $tn / 100 : 0; if ($isAg) { $fineS += $fine; $vToday += $fine * $ag / 1000; } else { $fineG += $fine; $vToday += $fine * $g24 / 10; }
            $o .= '<div class="lki">' . ($ph ? '<img src="' . sj_h($ph) . '" alt="" loading="lazy">' : '<div class="lkn">' . sj_h(mb_strtoupper(mb_substr((string)(isset($it['category']) ? $it['category'] : 'S'), 0, 1))) . '</div>') . '<div class="lkt"><b>' . sj_h(trim((isset($it['category']) ? $it['category'] : 'Gehna') . ' ' . (isset($it['purity']) ? $it['purity'] : ''))) . '</b><div class="sub">' . number_format($net, 3) . ' g' . ($tn > 0 ? ' · ' . sj_h($tn) . '%' : '') . (!empty($it['huid']) ? ' · HUID <b>' . sj_h(strtoupper($it['huid'])) . '</b>' : '') . '</div><div class="sub">' . $fd($x['date']) . ' · ' . sj_h($x['no']) . ($x['id'] && sj_valid_id($x['id']) ? ' · <a href="verify.php?i=' . rawurlencode($x['id']) . '&amp;k=' . sj_vtok($x['id']) . '">Bill check</a>' : '') . '</div></div></div>';
        }
        $o .= '</div>';
        if ($vToday > 0) $o .= '<div class="k" style="margin-top:12px"><div><span>Kul fine sona</span><b>' . number_format($fineG, 3) . ' g</b></div>' . ($fineS > 0 ? '<div><span>Kul fine chandi</span><b>' . number_format($fineS, 3) . ' g</b></div>' : '') . '<div><span>Aaj ke bhav se dhatu ki keemat*</span><b>' . sj_inr($vToday) . '</b></div></div><div class="sub" style="margin-top:6px">*Sirf sone / chandi ki keemat, aaj ke bhav se — making, stone aur GST shamil nahi. Sirf jaankari ke liye.</div>';
        $o .= '<style>.lk{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}.lki{display:flex;gap:10px;align-items:center;border:1px solid var(--line);border-radius:12px;padding:8px}.lki img,.lkn{width:64px;height:64px;border-radius:10px;object-fit:cover;flex:none;background:#fff}.lkn{display:grid;place-items:center;font:700 26px Georgia,serif;color:var(--gold);background:var(--bg)}.lkt{min-width:0;font-size:13.5px}.lkt a{color:var(--gold)}</style></div>';
    }
    $vs = array_values(array_filter(sj_all_docs('vouchers'), function ($g) use ($c) { return (isset($g['customerId']) ? $g['customerId'] : '') === $c['id'] && (isset($g['status']) ? $g['status'] : '') !== 'cancelled'; }));
    if ($vs) {
        $o .= '<div class="card"><h2>🎁 Mere gift voucher</h2>';
        foreach ($vs as $g) { $bal = (float)(isset($g['balance']) ? $g['balance'] : 0); $exp = isset($g['expiry']) ? $g['expiry'] : ''; $old = $exp && $exp < gmdate('Y-m-d', time() + 19800);
            $o .= '<div style="display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--line)"><div><b>' . sj_h(isset($g['code']) ? $g['code'] : '') . '</b><div class="sub">' . ($exp ? ($old ? 'Samay nikal gaya ' : 'Valid ') . $fd($exp) . ' tak' : '') . (!empty($g['source']) && $g['source'] === 'referral' ? ' · referral inaam' : '') . '</div></div><b class="' . ($bal > 0.5 && !$old ? 'ok' : 'sub') . '">' . sj_inr($bal) . '</b></div>'; }
        $o .= '<div class="sub" style="margin-top:6px">Agli kharid par bill banwate waqt voucher code bataiye.</div></div>';
    }
    if (!empty($c['refCode'])) {
        $rf = json_decode((string)sj_meta_get('referral_cfg'), true); $amt = is_array($rf) && isset($rf['reward']) ? (float)$rf['reward'] : 500;
        $o .= '<div class="card"><h2>🤝 Dost ko bulaiye, inaam paiye</h2><p style="margin:0">Aapka referral code: <b style="font-size:18px;letter-spacing:1px;color:var(--gold)">' . sj_h($c['refCode']) . '</b></p><p class="sub" style="margin:6px 0 0">Jab aapka dost ye code batakar pehli kharid karega, aapko <b>' . sj_inr($amt) . '</b> ka gift voucher milega' . (is_array($rf) && !empty($rf['newPct']) ? ' aur dost ko making par ' . sj_h($rf['newPct']) . '% extra chhoot' : '') . '.</p></div>';
    }
    return $o;
}

/* ---------- Item QR page (tag / display card QR → item.php?i=&k=) ---------- */
function sj_itok($id) { $k = sj_key() ?: 'sj'; return rtrim(strtr(base64_encode(substr(hash_hmac('sha256', 'item|' . $id, $k, true), 0, 9)), '+/', '-_'), '='); }
function sj_item_page($id, $tok) {
    $set = sj_load_doc('settings', 'main'); if (!is_array($set)) $set = [];
    $firm = isset($set['firm']) && $set['firm'] !== '' ? $set['firm'] : 'Shivaa Jewels'; $ph = preg_replace('/\D/', '', isset($set['phone']) ? $set['phone'] : '');
    $o = sj_page_head($firm . ' — Gehne ki jaankari');
    $o .= '<div class="firm">' . sj_h($firm) . '</div><div class="sub">' . sj_h(isset($set['address']) ? $set['address'] : '') . '</div>';
    $p = (sj_valid_id($id) && preg_match('/^[A-Za-z0-9_-]{12}$/', $tok) && hash_equals(sj_itok($id), $tok)) ? sj_load_doc('products', $id) : null;
    if (!$p) { sj_db()->prepare('INSERT INTO sj_fails (ip, at) VALUES (?, ?)')->execute(['v:' . sj_ip(), time()]); echo $o . '<div class="card"><div class="badge bad"><i>✕</i>Ye gehna hamare record mein nahi mila</div><p>QR code galat ya purana hai. Dukaan se sampark karein.</p></div></div></body></html>'; exit; }
    $st = isset($p['status']) ? $p['status'] : ''; $sold = $st !== 'In Stock';
    $o .= '<div class="card">';
    if (!empty($p['photo']) && is_string($p['photo']) && strpos($p['photo'], 'data:image/') === 0 && strlen($p['photo']) < 2500000) $o .= '<img src="' . sj_h($p['photo']) . '" alt="" style="width:100%;max-height:520px;object-fit:contain;border-radius:14px;background:#fff">';
    $o .= '<div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-top:12px"><div><div style="font:700 22px Georgia,serif">' . sj_h(trim((isset($p['category']) ? $p['category'] : 'Gehna') . ' ' . (isset($p['purity']) ? $p['purity'] : ''))) . '</div><div class="sub">#' . sj_h(isset($p['sku']) ? $p['sku'] : '') . '</div></div><span class="badge ' . ($sold ? 'bad' : 'ok') . '" style="font-size:14px"><i style="width:30px;height:30px;font-size:16px">' . ($sold ? '•' : '✓') . '</i>' . ($sold ? 'Bik chuka' : 'Uplabdh') . '</span></div>';
    $rows = []; $gw = (float)(isset($p['gross']) ? $p['gross'] : 0); $nw = (float)(isset($p['net']) ? $p['net'] : 0); $tn = (float)(isset($p['tunch']) ? $p['tunch'] : 0);
    if ($gw > 0) $rows[] = ['Gross wazan', number_format($gw, 3) . ' g']; if ($nw > 0 && abs($nw - $gw) > 0.0005) $rows[] = ['Net wazan', number_format($nw, 3) . ' g'];
    if ($tn > 0) $rows[] = ['Shuddhata (tunch)', sj_h($tn) . '%']; if (!empty($p['huid'])) $rows[] = ['HUID (hallmark)', '<b>' . sj_h(strtoupper($p['huid'])) . '</b>'];
    if (!empty($p['stoneWt']) || !empty($p['stone'])) $rows[] = ['Stone', sj_h(!empty($p['stoneWt']) ? $p['stoneWt'] . ' ct/g' : 'Haan')];
    if (!empty($p['description'])) $rows[] = ['Vivran', sj_h($p['description'])];
    $o .= '<div class="k">'; foreach ($rows as $r) $o .= '<div><span>' . $r[0] . '</span>' . $r[1] . '</div>'; $o .= '</div>';
    if (!empty($set['gold24'])) $o .= '<p class="sub" style="margin:12px 0 0">Aaj ka bhav: sona 24K ' . sj_inr($set['gold24']) . '/10g' . (!empty($set['silver999']) ? ' · chandi ' . sj_inr($set['silver999']) . '/kg' : '') . '. Keemat dukaan par us din ke bhav se.</p>';
    if (!empty($p['huid'])) $o .= '<p class="note" style="margin-top:12px">Hallmark jaanch: <b>BIS CARE</b> app → “Verify HUID” → ' . sj_h(strtoupper($p['huid'])) . '</p>';
    if (strlen($ph) >= 10 && !$sold) $o .= '<p style="margin-top:14px"><a class="btn" style="background:#25d366;color:#05220f" href="https://wa.me/91' . sj_h(substr($ph, -10)) . '?text=' . rawurlencode('Namaste, mujhe ye gehna pasand aaya: #' . (isset($p['sku']) ? $p['sku'] : '') . ' ' . trim((isset($p['category']) ? $p['category'] : '') . ' ' . (isset($p['purity']) ? $p['purity'] : '')) . '. Keemat aur jaankari bhejiye.') . '">WhatsApp par poochhiye</a></p>';
    $o .= '</div><div class="foot">' . sj_h($firm) . ' · ye page gehne ke QR code se khulta hai</div></div></body></html>';
    echo $o; exit;
}

/* ---------------- routes ---------------- */
require __DIR__ . '/sj-sec.php';
require __DIR__ . '/sj-v42.php';
$a = isset($_GET['a']) ? (string)$_GET['a'] : '';
$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
$SJ_KEYED = ['gps_push', 'rfid_push', 'cron', 'confirm'];   // carry their own secret key / signed link
if ($method !== 'GET') {
    if ($method !== 'POST') sj_fail('method', 405);
    if ($a !== 'portal' && !in_array($a, $SJ_KEYED, true) && (!isset($_SERVER['HTTP_X_SJ']) || $_SERVER['HTTP_X_SJ'] !== '1')) sj_fail('forbidden', 403);   // blocks cross-site form posts (portal posts carry their own signed nonce)
} elseif (!in_array($a, array_merge(['status', 'export', 'ping', 'portal', 'verify', 'item'], $SJ_KEYED), true)) sj_fail('method', 405);
if (sj_https()) header('Strict-Transport-Security: max-age=15552000');
if ($a === 'ping') sj_out(['ok' => true, 'php' => PHP_VERSION]);

sj_db();
if (!empty($GLOBALS['SJ_NEED_GENESIS'])) sj_chain_genesis('start');
sj_check_reset();
if (in_array($a, ['gps_push', 'rfid_push', 'cron', 'confirm'], true)) {
    $pst = sj_db()->prepare('SELECT COUNT(*) FROM sj_fails WHERE ip = ? AND at >= ?'); $pst->execute([substr($a, 0, 1) . ':' . sj_ip(), time() - 900]);
    if ((int)$pst->fetchColumn() >= 40) { http_response_code(429); header('Content-Type: text/plain'); echo 'Too many tries'; exit; }
    if ($a === 'gps_push') sj_gps_push(); if ($a === 'rfid_push') sj_rfid_push(); if ($a === 'cron') sj_cron(); if ($a === 'confirm') sj_confirm_page();
}
sj_sec_route($a);
sj_v42_route($a);
if ($a === 'portal') { $pst = sj_db()->prepare('SELECT COUNT(*) FROM sj_fails WHERE ip = ? AND at >= ?'); $pst->execute(['p:' . sj_ip(), time() - 900]); if ((int)$pst->fetchColumn() >= 20) { http_response_code(429); header('Content-Type: text/plain; charset=utf-8'); echo 'Thodi der baad try kijiye.'; exit; } sj_portal_page(isset($_GET['t']) ? (string)$_GET['t'] : ''); }
if ($a === 'verify') { $pst = sj_db()->prepare('SELECT COUNT(*) FROM sj_fails WHERE ip = ? AND at >= ?'); $pst->execute(['v:' . sj_ip(), time() - 900]); if ((int)$pst->fetchColumn() >= 30) { http_response_code(429); header('Content-Type: text/plain; charset=utf-8'); echo 'Thodi der baad try kijiye.'; exit; } sj_verify_page(isset($_GET['i']) ? (string)$_GET['i'] : '', isset($_GET['k']) ? (string)$_GET['k'] : ''); }
if ($a === 'item') { $pst = sj_db()->prepare('SELECT COUNT(*) FROM sj_fails WHERE ip = ? AND at >= ?'); $pst->execute(['v:' . sj_ip(), time() - 900]); if ((int)$pst->fetchColumn() >= 30) { http_response_code(429); header('Content-Type: text/plain; charset=utf-8'); echo 'Thodi der baad try kijiye.'; exit; } sj_item_page(isset($_GET['i']) ? (string)$_GET['i'] : '', isset($_GET['k']) ? (string)$_GET['k'] : ''); }

switch ($a) {

case 'status':
    $u = sj_user();
    sj_out(['ok' => true, 'setup' => sj_needs_setup(), 'auth' => !!$u, 'user' => sj_public_user($u), 'https' => sj_https() || sj_local(),
        'enc' => !!sj_enc_available(), 'secureRequired' => !sj_https() && !sj_local() && !sj_cfg('allow_http', false)]);

case 'setup':
    sj_require_secure();
    $b = sj_body();
    if (!sj_needs_setup()) sj_fail('already_setup', 409, 'Owner ka password pehle se bana hua hai — login kijiye.');
    if (sj_throttled()) sj_fail('throttled', 429, 'Bahut baar galat koshish hui. 15 minute baad try kijiye.');
    $norm = function ($s) { return strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string)$s)); };
    if (!hash_equals($norm(sj_cfg('setup_code', '')), $norm(isset($b['code']) ? $b['code'] : ''))) { sj_add_fail(); sj_fail('wrong_code', 403, 'Setup code galat hai.'); }
    $p = isset($b['password']) ? (string)$b['password'] : '';
    if (strlen($p) < 8) sj_fail('weak_password', 400, 'Password kam se kam 8 akshar ka rakhiye.');
    $uname = strtolower(sj_str($b, 'username', 40)) ?: 'owner';
    if (!preg_match('/^[a-z0-9._-]{3,32}$/', $uname)) sj_fail('bad_username', 400, 'Username 3–32 akshar: a-z, 0-9, . _ - (space nahi).');
    $name = sj_str($b, 'name', 80) ?: 'Owner';
    $db = sj_db(); $o = sj_owner();
    $clash = $db->prepare('SELECT id FROM sj_users WHERE uname = ? AND id <> ?'); $clash->execute([$uname, SJ_OWNER_ID]);
    if ($clash->fetch()) sj_fail('username_taken', 409, 'Ye username kisi staff ka hai — doosra chuniye.');
    if ($o) $db->prepare('UPDATE sj_users SET uname = ?, name = ?, pass = ?, role = ?, active = 1 WHERE id = ?')->execute([$uname, $name, password_hash($p, PASSWORD_DEFAULT), 'owner', SJ_OWNER_ID]);
    else $db->prepare('INSERT INTO sj_users (id, uname, name, pass, role, active, created) VALUES (?, ?, ?, ?, ?, 1, ?)')->execute([SJ_OWNER_ID, $uname, $name, password_hash($p, PASSWORD_DEFAULT), 'owner', time()]);
    sj_issue_token(SJ_OWNER_ID);
    sj_out(['ok' => true]);

case 'login':
    sj_require_secure();
    $b = sj_body();
    if (sj_needs_setup()) sj_fail('setup_required', 409, 'Pehle Owner ka password banaiye.');
    $uname = strtolower(sj_str($b, 'username', 40)) ?: 'owner';
    if (sj_throttled($uname)) sj_fail('throttled', 429, 'Bahut baar galat password daala gaya. 15 minute baad try kijiye.');
    $st = sj_db()->prepare('SELECT * FROM sj_users WHERE uname = ?'); $st->execute([$uname]); $u = $st->fetch();
    $p = isset($b['password']) ? (string)$b['password'] : '';
    $okp = $u && $u['pass'] && password_verify($p, $u['pass']);
    if (!$okp) { sj_add_fail($uname); sj_fail('wrong_password', 403, 'Username ya password galat hai.'); }
    if (!(int)$u['active']) sj_fail('inactive', 403, 'Ye login band kar diya gaya hai — Owner se baat kijiye.');
    if (sj_login_expired($u['id'])) sj_fail('expired', 403, 'Is login ki muddat khatam ho gayi hai — Owner se baat kijiye.');
    $hb = sj_hours_block($u); if ($hb) { if (sj_once_today('offh:' . $u['id'])) sj_sec_alert('off_hours', 'Dukaan ke samay ke BAAHAR login ki koshish: ' . $u['name'] . ' · ' . sj_hm_now(), 'medium', $u); sj_fail('off_hours', 403, $hb); }
    if (sj_utotp_on($u['id'])) {
        $otp = isset($b['otp']) ? trim((string)$b['otp']) : '';
        if ($otp === '') sj_fail('otp_required', 401, 'Authenticator app ka 6 ank ka code daaliye.');
        if (!sj_utotp_check($u['id'], $otp)) { sj_add_fail($uname); sj_fail('wrong_otp', 403, 'Code galat hai ya purana ho gaya — app mein naya code dekhkar daaliye.'); }
    } elseif (sj_pol()['totpAll'] && $u['role'] !== 'owner' && !sj_cfg('disable_2fa', false)) {   // must set up 2-step now
        $dg = sj_dev_gate($u); if ($dg) sj_fail($dg, 403, $dg === 'device_blocked' ? 'Ye phone / computer block hai — Owner se baat kijiye.' : 'Ye naya phone / computer hai — Owner ke approve karne ke baad login hoga. (Owner: Setup → Suraksha → Devices)');
        $t = bin2hex(random_bytes(16)); $sec = sj_b32_enc(random_bytes(20)); $k = 'tenroll:' . $t;
        sj_meta_set($k, sj_enc(json_encode(['uid' => $u['id'], 'secret' => $sec, 'at' => time()]), 'meta', $k));
        sj_out(['ok' => false, 'error' => 'totp_setup', 'message' => '2-step login zaroori hai — phone mein Authenticator app se QR scan kijiye.', 'ticket' => $t, 'secret' => $sec, 'uri' => sj_totp_uri($u['uname'], $sec)], 401);
    }
    $dg = sj_dev_gate($u); if ($dg) sj_fail($dg, 403, $dg === 'device_blocked' ? 'Ye phone / computer block hai — Owner se baat kijiye.' : 'Ye naya phone / computer hai — Owner ke approve karne ke baad login hoga. (Owner: Setup → Suraksha → Devices)');
    if (password_needs_rehash($u['pass'], PASSWORD_DEFAULT)) sj_db()->prepare('UPDATE sj_users SET pass = ? WHERE id = ?')->execute([password_hash($p, PASSWORD_DEFAULT), $u['id']]);
    sj_issue_token($u['id']);
    sj_out(['ok' => true, 'user' => sj_public_user($u)]);

case 'logout':
    $h = sj_token_hash(); if ($h) sj_db()->prepare('DELETE FROM sj_tokens WHERE h = ?')->execute([$h]);
    sj_set_cookie('', time() - 3600);
    sj_out(['ok' => true]);

case 'logout_all':
    $u = sj_require_user();
    if ($u['role'] === 'owner') sj_db()->exec('DELETE FROM sj_tokens');
    else sj_db()->prepare('DELETE FROM sj_tokens WHERE uid = ?')->execute([$u['id']]);
    sj_set_cookie('', time() - 3600);
    sj_out(['ok' => true]);

case 'passwd':
    $u = sj_require_user(); $b = sj_body();
    if (sj_throttled($u['uname'])) sj_fail('throttled', 429, 'Bahut baar galat koshish hui. 15 minute baad try kijiye.');
    $st = sj_db()->prepare('SELECT pass FROM sj_users WHERE id = ?'); $st->execute([$u['id']]); $hash = $st->fetchColumn();
    if (!password_verify(isset($b['old']) ? (string)$b['old'] : '', $hash)) { sj_add_fail($u['uname']); sj_fail('wrong_password', 403, 'Purana password galat hai.'); }
    $p = isset($b['password']) ? (string)$b['password'] : '';
    if (strlen($p) < 8) sj_fail('weak_password', 400, 'Naya password kam se kam 8 akshar ka rakhiye.');
    sj_db()->prepare('UPDATE sj_users SET pass = ? WHERE id = ?')->execute([password_hash($p, PASSWORD_DEFAULT), $u['id']]);
    sj_db()->prepare('DELETE FROM sj_tokens WHERE uid = ? AND h <> ?')->execute([$u['id'], sj_token_hash()]);
    sj_out(['ok' => true]);

case 'users':
    sj_require_role(['owner']);
    $rows = sj_db()->query('SELECT u.id, u.uname, u.name, u.role, u.active, u.created, u.last_login, (SELECT COUNT(*) FROM sj_tokens t WHERE t.uid = u.id AND t.expires > ' . time() . ') AS sessions FROM sj_users u ORDER BY (u.role = \'owner\') DESC, u.name')->fetchAll();
    foreach ($rows as &$r) { $r['active'] = (int)$r['active']; $r['sessions'] = (int)$r['sessions']; $r['created'] = (int)$r['created']; $r['last_login'] = $r['last_login'] === null ? null : (int)$r['last_login']; }
    sj_out(['ok' => true, 'users' => $rows]);

case 'user_save':
    $me = sj_require_role(['owner']); $b = sj_body(); $db = sj_db();
    $id = sj_str($b, 'id', 32);
    $uname = strtolower(sj_str($b, 'username', 40)); $name = sj_str($b, 'name', 80); $role = sj_str($b, 'role', 16);
    $p = isset($b['password']) ? (string)$b['password'] : ''; $active = !isset($b['active']) || $b['active'] ? 1 : 0;
    if (!preg_match('/^[a-z0-9._-]{3,32}$/', $uname)) sj_fail('bad_username', 400, 'Username 3–32 akshar: a-z, 0-9, . _ - (space nahi).');
    if ($name === '') sj_fail('bad_name', 400, 'Naam likhiye.');
    $clash = $db->prepare('SELECT id FROM sj_users WHERE uname = ? AND id <> ?'); $clash->execute([$uname, $id]);
    if ($clash->fetch()) sj_fail('username_taken', 409, 'Ye username pehle se kisi aur ka hai.');
    if ($p !== '' && strlen($p) < 8) sj_fail('weak_password', 400, 'Password kam se kam 8 akshar ka rakhiye.');
    if ($id === SJ_OWNER_ID) {                                       // owner edits own name / username
        $db->prepare('UPDATE sj_users SET uname = ?, name = ? WHERE id = ?')->execute([$uname, $name, SJ_OWNER_ID]);
        if ($p !== '') { $db->prepare('UPDATE sj_users SET pass = ? WHERE id = ?')->execute([password_hash($p, PASSWORD_DEFAULT), SJ_OWNER_ID]); $db->prepare('DELETE FROM sj_tokens WHERE uid = ? AND h <> ?')->execute([SJ_OWNER_ID, sj_token_hash()]); }
        sj_out(['ok' => true, 'id' => SJ_OWNER_ID]);
    }
    if (!in_array($role, ['manager', 'staff', 'viewer'], true)) sj_fail('bad_role', 400, 'Role chuniye.');
    if ($id === '') {
        if ($p === '') sj_fail('weak_password', 400, 'Naye login ke liye password zaroori hai.');
        $id = 'u_' . bin2hex(random_bytes(8));
        $db->prepare('INSERT INTO sj_users (id, uname, name, pass, role, active, created) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([$id, $uname, $name, password_hash($p, PASSWORD_DEFAULT), $role, $active, time()]);
    } else {
        $st = $db->prepare('SELECT id FROM sj_users WHERE id = ?'); $st->execute([$id]); if (!$st->fetch()) sj_fail('not_found', 404, 'Login nahi mila.');
        $db->prepare('UPDATE sj_users SET uname = ?, name = ?, role = ?, active = ? WHERE id = ?')->execute([$uname, $name, $role, $active, $id]);
        if ($p !== '') $db->prepare('UPDATE sj_users SET pass = ? WHERE id = ?')->execute([password_hash($p, PASSWORD_DEFAULT), $id]);
        if ($p !== '' || !$active) $db->prepare('DELETE FROM sj_tokens WHERE uid = ?')->execute([$id]);   // must log in again
    }
    sj_out(['ok' => true, 'id' => $id]);

case 'user_delete':
    sj_require_role(['owner']); $b = sj_body(); $id = sj_str($b, 'id', 32);
    if ($id === SJ_OWNER_ID) sj_fail('forbidden_role', 403, 'Owner ka login delete nahi ho sakta.');
    sj_db()->prepare('DELETE FROM sj_tokens WHERE uid = ?')->execute([$id]);
    sj_db()->prepare('DELETE FROM sj_users WHERE id = ?')->execute([$id]);
    sj_out(['ok' => true]);

case 'ai_status':
    sj_require_user(); $k = sj_ai_key(); $ml = json_decode((string)sj_meta_get('ai_models'), true);
    sj_out(['ok' => true, 'set' => $k !== '', 'hint' => $k !== '' ? '…' . substr($k, -4) : '', 'provider' => sj_ai_provider(), 'model' => sj_ai_model(false), 'models' => is_array($ml) ? $ml : [], 'curl' => function_exists('curl_init')]);

case 'ai_key':
    sj_require_role(['owner']); @set_time_limit(60); $b = sj_body(); $k = trim(isset($b['key']) ? (string)$b['key'] : '');
    $prov = isset($b['provider']) && $b['provider'] === 'gemini' ? 'gemini' : 'claude';
    $want = !empty($b['model']) ? preg_replace('/[^a-z0-9.\-]/', '', strtolower((string)$b['model'])) : '';
    if ($k === '') {
        if (!empty($b['modelOnly']) && sj_ai_key() !== '') {   // change only the model, keep the key
            $ml = json_decode((string)sj_meta_get('ai_models'), true); $ml = is_array($ml) ? $ml : [];
            $m = sj_ai_provider() === 'gemini' ? sj_ai_pick_gemini($want, $ml) : ($want ? $want : '');
            sj_meta_set('ai_model', $m); sj_out(['ok' => true, 'set' => true, 'model' => sj_ai_model(false)]);
        }
        foreach (['ai_key', 'ai_models'] as $mk) sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute([$mk]);
        sj_out(['ok' => true, 'set' => false]);
    }
    $k = preg_replace('/\s+/', '', $k);
    if ($prov === 'claude' && !preg_match('/^sk-ant-[A-Za-z0-9_\-]{20,300}$/', $k)) sj_fail('invalid_argument', 400, 'Ye Claude API key nahi lagti (sk-ant- se shuru hoti hai).');
    if ($prov === 'gemini' && !preg_match('/^[A-Za-z0-9_\-.]{20,300}$/', $k)) sj_fail('invalid_argument', 400, 'Ye Gemini API key sahi nahi lagti (Google AI Studio se poori copy kijiye).');
    if (!function_exists('curl_init') && !ini_get('allow_url_fopen')) sj_fail('ai_test', 400, 'Hosting par PHP "curl" band hai — hPanel → Advanced → PHP Configuration → Extensions mein curl on kijiye.');
    $t = sj_ai_check_key($prov, $k);
    if (!$t['ok']) sj_fail('ai_test', 400, 'Key save nahi hui — ' . ($t['code'] === 'ai_key_bad' ? 'ye key ' . ($prov === 'gemini' ? 'Google' : 'Claude') . ' ne nahi maani (galat ya band key). ' : '') . $t['message']);
    $m = $prov === 'gemini' ? sj_ai_pick_gemini($want, $t['models']) : ($want ? $want : '');
    sj_meta_set('ai_key', sj_enc($k, 'meta', 'ai_key'));
    sj_meta_set('ai_provider', $prov);
    sj_meta_set('ai_model', $m);
    sj_meta_set('ai_models', json_encode($t['models']));
    sj_out(['ok' => true, 'set' => true, 'hint' => '…' . substr($k, -4), 'model' => sj_ai_model(false), 'models' => $t['models']]);

case 'ai':
    $u = sj_require_user(); @set_time_limit(170);
    if ($u['role'] === 'viewer') sj_fail('forbidden_role', 403, 'View only login AI use nahi kar sakta.');
    if (sj_ai_key() === '') sj_out(['ok' => true, 'notSet' => true]);
    $b = sj_body(); $msgs = isset($b['messages']) && is_array($b['messages']) ? $b['messages'] : [];
    $clean = [];
    foreach (array_slice($msgs, -60) as $m) {
        if (!is_array($m) || !isset($m['role'])) continue;
        if ($m['role'] === 'tool') { $res = []; foreach (isset($m['results']) && is_array($m['results']) ? $m['results'] : [] as $x) if (is_array($x) && !empty($x['name'])) $res[] = ['id' => isset($x['id']) ? (string)$x['id'] : '', 'name' => substr((string)$x['name'], 0, 64), 'result' => substr(is_string($x['result']) ? $x['result'] : json_encode($x['result'], JSON_UNESCAPED_UNICODE), 0, 40000)]; if ($res) $clean[] = ['role' => 'tool', 'results' => $res]; continue; }
        if ($m['role'] === 'assistant' && isset($m['raw']) && is_array($m['raw'])) { $clean[] = ['role' => 'assistant', 'raw' => $m['raw']]; continue; }
        if (!in_array($m['role'], ['user', 'assistant'], true)) continue;
        $c = isset($m['content']) ? (string)$m['content'] : ''; if ($c === '') continue; $row = ['role' => $m['role'], 'content' => $c];
        if ($m['role'] === 'user' && isset($m['images']) && is_array($m['images'])) { $im = []; foreach (array_slice($m['images'], 0, 3) as $x) { if (!is_array($x) || empty($x['data']) || !is_string($x['data'])) continue; $mt = isset($x['mime']) && in_array($x['mime'], ['image/jpeg', 'image/png', 'image/webp'], true) ? $x['mime'] : 'image/jpeg'; if (strlen($x['data']) > 5500000 || !preg_match('#^[A-Za-z0-9+/=]+$#', $x['data'])) sj_fail('too_large', 413, 'Photo bahut badi hai.'); $im[] = ['mime' => $mt, 'data' => $x['data']]; } if ($im) $row['images'] = $im; }
        $clean[] = $row;
    }
    if (!$clean || $clean[0]['role'] !== 'user') sj_fail('invalid_argument', 400, 'Sawal khaali hai.');
    $tools = [];
    foreach (isset($b['tools']) && is_array($b['tools']) ? array_slice($b['tools'], 0, 40) : [] as $t) {
        if (!is_array($t) || empty($t['name']) || !preg_match('/^[a-zA-Z0-9_]{1,64}$/', $t['name'])) continue;
        $sc = isset($t['schema']) && is_array($t['schema']) ? $t['schema'] : ['type' => 'object', 'properties' => []];
        if (empty($sc['properties'])) $sc['properties'] = new stdClass();
        $tools[] = ['name' => $t['name'], 'description' => substr((string)(isset($t['description']) ? $t['description'] : ''), 0, 1500), 'schema' => $sc];
    }
    $r = sj_ai_call($clean, !empty($b['quick']), 4000, $tools);
    if (!$r['ok']) sj_fail($r['code'], $r['http'], $r['message']);
    sj_out(isset($r['calls']) ? ['ok' => true, 'calls' => $r['calls'], 'raw' => $r['raw'], 'model' => $r['model']] : ['ok' => true, 'text' => $r['text'], 'model' => $r['model']]);

case 'alert_cfg':
    sj_require_role(['owner']); $b = sj_body(); $em = trim(isset($b['email']) ? (string)$b['email'] : '');
    if ($em !== '' && !filter_var($em, FILTER_VALIDATE_EMAIL)) sj_fail('invalid_argument', 400, 'Email sahi nahi hai.');
    if ($em === '') sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute(['alert_email']); else sj_meta_set('alert_email', $em);
    $sent = false; if ($em !== '' && !empty($b['test']) && function_exists('mail')) { sj_alert_mail([['text' => 'Test alert — email chalu hai ✓', 'night' => false, 'by' => 'Software', 'at' => (int)round(microtime(true) * 1000)]]); $sent = true; }
    sj_out(['ok' => true, 'email' => $em, 'mail' => function_exists('mail'), 'sent' => $sent]);

case 'lock_cfg':
    sj_require_role(['owner']); $b = sj_body();
    if (isset($b['hours'])) sj_meta_set('bill_lock_hours', (string)max(0, min(24 * 90, (int)$b['hours'])));
    if (isset($b['cashMin'])) sj_meta_set('cash_alert_min', (string)max(1, (int)$b['cashMin']));
    sj_out(['ok' => true, 'hours' => sj_lock_hours(), 'cashMin' => (int)(sj_meta_get('cash_alert_min') ?: 100)]);

case 'lock_status':
    sj_require_user(); sj_out(['ok' => true, 'hours' => sj_lock_hours(), 'cashMin' => (int)(sj_meta_get('cash_alert_min') ?: 100)]);

case 'alert_status':
    sj_require_role(['owner']); sj_out(['ok' => true, 'email' => (string)sj_meta_get('alert_email'), 'mail' => function_exists('mail')]);

case 'sync':
    $u = sj_require_user();
    sj_migrate_enc();
    if (sj_meta_get('auto_bk_day') !== gmdate('Y-m-d', time() + 19800)) register_shutdown_function(function () { try { if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request(); sj_auto_backup(); } catch (Exception $e) { error_log('[shivaa] auto backup: ' . $e->getMessage()); } });
    $b = sj_body();
    if (empty($b['since'])) { try { sj_seed_parties($u); } catch (Exception $e) { error_log('[shivaa] b2b seed: ' . $e->getMessage()); } }
    $since = isset($b['since']) ? max(0, (int)$b['since']) : 0;
    $db = sj_db();
    if (sj_is_mysql()) $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
    $st = $db->prepare('SELECT col, id, data, seq, deleted FROM sj_docs WHERE seq > ? ORDER BY seq LIMIT ' . (SJ_PAGE_ROWS + 1));
    $st->execute([$since]);
    $parts = []; $bytes = 0; $last = $since; $more = false; $n = 0; $fetched = 0;
    while ($row = $st->fetch()) {
        $fetched++;
        if ($n >= SJ_PAGE_ROWS || ($n > 0 && $bytes > SJ_PAGE_BYTES)) { $more = true; break; }
        if (($row['col'] === 'alerts' && $u['role'] !== 'owner') || ($row['col'] === 'fieldCodes' && !in_array($u['role'], ['owner', 'manager'], true))) { $last = (int)$row['seq']; continue; }
        $del = (int)$row['deleted'] === 1 || $row['data'] === null;
        $json = $del ? 'null' : sj_dec($row['data'], $row['col'], $row['id']);   // stored JSON passes through untouched
        $parts[] = '[' . json_encode($row['col']) . ',' . json_encode($row['id']) . ',' . $json . ',' . (int)$row['seq'] . ']';
        $bytes += $del ? 0 : strlen($json); $last = (int)$row['seq']; $n++;
    }
    $st->closeCursor();
    if (!$more && $fetched > SJ_PAGE_ROWS) $more = true;   // rows skipped for this login (alerts) must not end the page early
    http_response_code(200);
    $ep = sj_meta_get('epoch');
    echo '{"ok":true,"rows":[' . implode(',', $parts) . '],"last":' . $last . ',"more":' . ($more ? 'true' : 'false') . ',"epoch":' . json_encode((string)$ep) . '}';
    exit;

case 'batch':
    $u = sj_require_user();
    sj_migrate_enc();
    $b = sj_body();
    $ops = isset($b['ops']) && is_array($b['ops']) ? $b['ops'] : null;
    if (!$ops || count($ops) > SJ_MAX_OPS) sj_fail('invalid_argument', 400, 'Galat request.');
    $clean = [];
    foreach ($ops as $op) {
        if (!is_array($op)) sj_fail('invalid_argument', 400);
        $o = isset($op['o']) ? $op['o'] : ''; $c = isset($op['c']) ? $op['c'] : null; $i = isset($op['i']) ? $op['i'] : null;
        if (!sj_valid_col($c) || !sj_valid_id($i)) sj_fail('invalid_argument', 400, 'Galat record ka naam.');
        if ($o === 'set') {
            $d = isset($op['d']) ? $op['d'] : null;
            if (!is_string($d) || !is_object(json_decode($d))) sj_fail('invalid_argument', 400, 'Record ka data sahi nahi hai.');
        } elseif ($o === 'del') $d = null;
        else sj_fail('invalid_argument', 400);
        $why = sj_check_op($u, $o, $c, $i, $d);
        if ($why) {
            if ($why[0] === '#') { if (strpos($why, '#pin') === 0) sj_pin_fail(substr($why, 1)); $pp = explode(':', substr($why, 1), 2); sj_fail($pp[0], 403, isset($pp[1]) ? $pp[1] : ''); }
            sj_fail('forbidden_role', 403, $why);
        }
        $clean[] = [$c, $i, $d, $o === 'del' ? 1 : 0];
    }
    $alerts = []; try { $alerts = sj_alerts_for($u, $clean); } catch (Exception $e) { error_log('[shivaa] alerts: ' . $e->getMessage()); }
    $db = sj_db();
    $db->beginTransaction();
    try {
        $db->prepare('UPDATE sj_counter SET v = v + ? WHERE id = 1')->execute([count($clean)]);
        $last = (int)$db->query('SELECT v FROM sj_counter WHERE id = 1')->fetchColumn();
        $seq = $last - count($clean);
        $rep = $db->prepare('REPLACE INTO sj_docs (col, id, data, seq, deleted, updated, uby) VALUES (?, ?, ?, ?, ?, ?, ?)');
        // keep the previous version of every changed / deleted record (encrypted) so nothing can silently disappear
        $hist = $db->prepare('INSERT INTO sj_history (col, id, data, seq, uby, replaced_at, replaced_by) SELECT col, id, data, seq, uby, ?, ? FROM sj_docs WHERE col = ? AND id = ? AND data IS NOT NULL');
        $now = (int)round(microtime(true) * 1000);
        foreach ($clean as $r) {
            $seq++;
            if (!in_array($r[0], ['summary', 'tagState'], true)) $hist->execute([$now, $u['id'], $r[0], $r[1]]);
            $rep->execute([$r[0], $r[1], $r[2] === null ? null : sj_enc($r[2], $r[0], $r[1]), $seq, $r[3], $now, $u['id']]);
        }
        sj_chain_add($db, $clean, $u['id']);
        $db->commit();
    } catch (Exception $e) { $db->rollBack(); throw $e; }
    if ($alerts) { $rows = []; foreach ($alerts as $k => $al) { $id = 'al_' . base_convert((string)$al['at'], 10, 36) . '_' . bin2hex(random_bytes(3)); $al['id'] = $id; $rows[] = ['alerts', $id, $al]; } sj_put_docs($rows, $u['id']); try { sj_alert_mail($alerts); } catch (Exception $e) { error_log('[shivaa] alert mail: ' . $e->getMessage()); } $last = (int)$db->query('SELECT v FROM sj_counter WHERE id = 1')->fetchColumn(); }
    if (mt_rand(1, 300) === 1) $db->prepare('DELETE FROM sj_history WHERE replaced_at < ?')->execute([(time() - 400 * 86400) * 1000]);
    sj_out(['ok' => true, 'seq' => $last]);

case 'file_put':
    /* attachments (bank receipts, kacha parchi, tunch photos …) — stored encrypted in sj-data/files, never public */
    $u = sj_require_user();
    if ($u['role'] === 'viewer') sj_fail('forbidden_role', 403, 'Aapka login sirf dekhne (View only) ke liye hai.');
    $b = sj_body(); $id = sj_str($b, 'id', 60);
    if (!preg_match('/^f_[a-z0-9]{6,40}$/', $id)) sj_fail('invalid_argument', 400, 'Galat file id.');
    $data = isset($b['data']) ? (string)$b['data'] : '';
    if ($data === '' || !preg_match('#^[A-Za-z0-9+/=]+$#', $data)) sj_fail('invalid_argument', 400, 'File khaali hai.');
    if (strlen($data) > 8 * 1024 * 1024) sj_fail('too_large', 413, 'File 6 MB se badi hai — chhoti file / photo lagaiye.');
    $mime = sj_str($b, 'mime', 80); $name = sj_str($b, 'name', 160);
    $dir = __DIR__ . '/sj-data/files';
    if (!is_dir($dir)) { @mkdir($dir, 0755, true); @file_put_contents($dir . '/index.html', ''); }
    if (!is_dir($dir) || !is_writable($dir)) sj_fail('not_writable', 500, 'sj-data/files folder mein likhne ki permission nahi hai.');
    $f = $dir . '/' . $id . '.bin';
    if (file_exists($f)) sj_fail('exists', 409, 'Ye file pehle se hai.');
    $payload = json_encode(['name' => $name, 'mime' => $mime, 'data' => $data, 'by' => $u['name'], 'at' => time()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (@file_put_contents($f, sj_enc($payload, 'file', $id), LOCK_EX) === false) sj_fail('not_writable', 500, 'File save nahi hui.');
    @chmod($f, 0644);
    sj_out(['ok' => true, 'id' => $id, 'size' => (int)floor(strlen($data) * 3 / 4)]);

case 'file_get':
    sj_require_user(); $b = sj_body(); $id = sj_str($b, 'id', 60);
    if (!preg_match('/^f_[a-z0-9]{6,40}$/', $id)) sj_fail('invalid_argument', 400, 'Galat file id.');
    $f = __DIR__ . '/sj-data/files/' . $id . '.bin';
    if (!is_file($f)) sj_fail('not_found', 404, 'File server par nahi mili.');
    $j = json_decode(sj_dec(file_get_contents($f), 'file', $id), true);
    if (!is_array($j)) sj_fail('decrypt', 500, 'File nahi khuli.');
    sj_out(['ok' => true, 'name' => $j['name'], 'mime' => $j['mime'], 'data' => $j['data']]);

case 'seed':
    /* Shivaa's B2B party list (sj-data/sj-b2b-seed.php) — only for Owner / Manager; the app adds the missing parties */
    sj_require_role(['owner', 'manager']);
    $f = __DIR__ . '/sj-data/sj-b2b-seed.php';
    $list = file_exists($f) ? require $f : null;
    if (!is_array($list)) sj_out(['ok' => true, 'version' => '', 'parties' => []]);
    sj_out(['ok' => true] + $list);

case 'wipe':
    /* Owner-only: clear every business record and start fresh.
       A full copy of the records is kept inside the database first (table sj_docs_bak_<time>)
       and the change reaches every phone/computer through the normal sync. */
    $u = sj_require_role(['owner']); $b = sj_body();
    if (sj_throttled('wipe:' . $u['id'])) sj_fail('throttled', 429, 'Bahut baar galat password. 15 minute baad try kijiye.');
    $st = sj_db()->prepare('SELECT pass FROM sj_users WHERE id = ?'); $st->execute([$u['id']]); $hash = $st->fetchColumn();
    $p = isset($b['password']) ? (string)$b['password'] : '';
    if (!$hash || !password_verify($p, $hash)) { sj_add_fail('wipe:' . $u['id']); sj_fail('wrong_password', 403, 'Owner ka password galat hai.'); }
    if (sj_str($b, 'confirm', 20) !== 'DELETE') sj_fail('invalid_argument', 400, 'Confirm karne ke liye DELETE likhiye.');
    $keep = ['settings' => !empty($b['keepSettings']), 'customers' => !empty($b['keepParties']), 'suppliers' => !empty($b['keepParties']), 'leads' => !empty($b['keepParties'])];
    $db = sj_db(); $now = (int)round(microtime(true) * 1000); $tag = gmdate('YmdHis');
    // 1. safety copy (kept inside the same database, encrypted as before). Only the 3 newest copies are kept.
    $bak = 'sj_docs_bak_' . $tag;
    $db->exec("CREATE TABLE $bak AS SELECT * FROM sj_docs");
    $tabs = sj_is_mysql() ? $db->query("SHOW TABLES LIKE 'sj\\_docs\\_bak\\_%'")->fetchAll(PDO::FETCH_COLUMN) : $db->query("SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'sj_docs_bak_%'")->fetchAll(PDO::FETCH_COLUMN);
    rsort($tabs); foreach (array_slice($tabs, 3) as $t) { if (preg_match('/^sj_docs_bak_\d{14}$/', $t)) $db->exec("DROP TABLE $t"); }
    // 2. mark every record deleted with a fresh sequence number so all devices drop it on their next sync
    $rows = $db->query('SELECT col, id, data FROM sj_docs WHERE deleted = 0 AND data IS NOT NULL')->fetchAll();
    $del = []; $settingsDocs = [];
    foreach ($rows as $r) {
        $root = explode('/', $r['col'])[0];
        if (!empty($keep[$root])) { if ($root === 'settings' && $r['col'] === 'settings') $settingsDocs[] = $r; continue; }
        $del[] = $r;
    }
    $db->beginTransaction();
    try {
        $n = count($del) + count($settingsDocs) + 1;
        $db->prepare('UPDATE sj_counter SET v = v + ? WHERE id = 1')->execute([$n]);
        $seq = (int)$db->query('SELECT v FROM sj_counter WHERE id = 1')->fetchColumn() - $n;
        $up = $db->prepare('UPDATE sj_docs SET data = NULL, deleted = 1, seq = ?, updated = ?, uby = ? WHERE col = ? AND id = ?');
        foreach ($del as $r) { $seq++; $up->execute([$seq, $now, $u['id'], $r['col'], $r['id']]); }
        // settings kept: opening balances and GST-filed marks belong to the old data, so they are cleared
        $rep = $db->prepare('UPDATE sj_docs SET data = ?, seq = ?, updated = ?, uby = ? WHERE col = ? AND id = ?');
        foreach ($settingsDocs as $r) {
            $d = json_decode(sj_dec($r['data'], $r['col'], $r['id']), true); if (!is_array($d)) continue;
            foreach (['openingCash' => 0, 'openingDate' => '', 'gstFiled' => new stdClass(), 'ratesUpdated' => ''] as $k => $v) if (array_key_exists($k, $d)) $d[$k] = $v;
            if (empty($keep['customers'])) unset($d['b2bSeed']);   // parties cleared: the B2B list is added again on next open
            if (isset($d['banks']) && is_array($d['banks'])) foreach ($d['banks'] as &$bk) { if (is_array($bk)) { $bk['opening'] = 0; $bk['openDate'] = ''; } } unset($bk);
            $seq++; $j = json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
            $rep->execute([sj_enc($j, $r['col'], $r['id']), $seq, $now, $u['id'], $r['col'], $r['id']]);
        }
        // one audit line so everybody can see when and by whom the data was cleared
        $seq++; $aid = 'au_reset_' . $tag;
        $ae = json_encode(['id' => $aid, 'at' => $now, 'date' => date('Y-m-d'), 'col' => 'system', 'docId' => '', 'action' => 'reset', 'label' => 'Saara data mitaya gaya (fresh start) — ' . count($del) . ' records', 'changes' => [], 'by' => $u['name'], 'byUser' => $u['uname'], 'byRole' => $u['role']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $db->prepare('REPLACE INTO sj_docs (col, id, data, seq, deleted, updated, uby) VALUES (?, ?, ?, ?, 0, ?, ?)')->execute(['audit', $aid, sj_enc($ae, 'audit', $aid), $seq, $now, $u['id']]);
        $db->exec('DELETE FROM sj_history');
        $db->commit();
    } catch (Exception $e) { $db->rollBack(); throw $e; }
    if (empty($keep['customers'])) $db->prepare('DELETE FROM sj_meta WHERE k = ?')->execute(['b2b_seed']);
    sj_meta_set('epoch', (string)$now);
    sj_chain_genesis('wipe');
    sj_out(['ok' => true, 'deleted' => count($del), 'backup' => $bak]);

case 'history':
    sj_require_role(['owner']); $b = sj_body();
    $c = isset($b['c']) ? $b['c'] : ''; $i = isset($b['i']) ? $b['i'] : '';
    if (!sj_valid_col($c) || !sj_valid_id($i)) sj_fail('invalid_argument', 400);
    $st = sj_db()->prepare('SELECT h.data, h.replaced_at, u.name AS by_name, w.name AS wrote_name FROM sj_history h LEFT JOIN sj_users u ON u.id = h.replaced_by LEFT JOIN sj_users w ON w.id = h.uby WHERE h.col = ? AND h.id = ? ORDER BY h.hid DESC LIMIT 50');
    $st->execute([$c, $i]); $out = [];
    while ($r = $st->fetch()) $out[] = ['at' => (int)$r['replaced_at'], 'replacedBy' => $r['by_name'], 'writtenBy' => $r['wrote_name'], 'data' => json_decode(sj_dec($r['data'], $c, $i), true)];
    sj_out(['ok' => true, 'versions' => $out]);

case 'export':
    $eu = sj_require_role(sj_pol()['exportOwner'] ? ['owner'] : ['owner', 'manager']);
    $need = sj_need_pin($eu); if ($need) { header('Content-Type: text/html; charset=utf-8'); http_response_code(403); echo '<!doctype html><meta charset="utf-8"><p style="font:16px system-ui;padding:24px">' . ($need === 'pin_not_set' ? 'Backup se pehle apna PIN banaiye (Setup → Suraksha).' : 'Backup ke liye pehle software mein PIN daaliye, phir dobara dabaiye.') . '</p>'; exit; }
    sj_sec_alert('export', 'Poora data BACKUP download kiya: ' . $eu['name'], 'medium', $eu);
    $db = sj_db();
    if (sj_is_mysql()) $db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
    header('Content-Disposition: attachment; filename="shivaa-server-backup-' . date('Y-m-d') . '.json"');
    echo '{"app":"shivaa-jewellery-software","version":2,"source":"website-server","exportedAt":' . json_encode(gmdate('c')) . ',"exportedBy":' . json_encode($eu['name'] . ' (' . $eu['uname'] . ')');
    $st = $db->query("SELECT col, id, data FROM sj_docs WHERE deleted = 0 AND data IS NOT NULL ORDER BY col, id");
    $cur = null;
    while ($row = $st->fetch()) {
        if (($row['col'] === 'alerts' && $eu['role'] !== 'owner') || ($row['col'] === 'fieldCodes' && !in_array($eu['role'], ['owner', 'manager'], true))) continue;
        $json = sj_dec($row['data'], $row['col'], $row['id']);
        if ($row['col'] === 'settings') { if ($row['id'] === 'main') { if ($cur !== null) { echo ']'; $cur = null; } echo ',"settings":' . $json; } continue; }
        if (strpos($row['col'], '/') !== false) continue;
        if ($row['col'] !== $cur) { if ($cur !== null) echo ']'; echo ',' . json_encode($row['col']) . ':[' . $json; $cur = $row['col']; }
        else echo ',' . $json;
    }
    if ($cur !== null) echo ']';
    echo '}';
    exit;

case 'verify_tok':
    sj_require_user(); $b = sj_body(); $out = [];
    foreach (array_slice(isset($b['ids']) && is_array($b['ids']) ? $b['ids'] : [], 0, 200) as $i) if (is_string($i) && sj_valid_id($i)) $out[$i] = sj_vtok($i);
    sj_out(['ok' => true, 'tokens' => $out]);

case 'item_tok':
    sj_require_user(); $b = sj_body(); $out = [];
    foreach (array_slice(isset($b['ids']) && is_array($b['ids']) ? $b['ids'] : [], 0, 500) as $i) if (is_string($i) && sj_valid_id($i)) $out[$i] = sj_itok($i);
    sj_out(['ok' => true, 'tokens' => $out]);

case 'referral_cfg':
    sj_require_role(['owner', 'manager']); $b = sj_body();
    sj_meta_set('referral_cfg', json_encode(['reward' => max(0, min(100000, (float)(isset($b['reward']) ? $b['reward'] : 500))), 'newPct' => max(0, min(50, (float)(isset($b['newPct']) ? $b['newPct'] : 0))), 'months' => max(1, min(36, (int)(isset($b['months']) ? $b['months'] : 12)))]));
    sj_out(['ok' => true]);

case 'totp_status':
    sj_require_role(['owner']); $j = sj_totp_get();
    sj_out(['ok' => true, 'on' => $j !== null, 'bypass' => (bool)sj_cfg('disable_2fa', false), 'codesLeft' => $j && isset($j['codes']) ? count($j['codes']) : 0]);

case 'totp_init':
    $u = sj_require_role(['owner']); $b = sj_body();
    if (sj_throttled($u['uname'])) sj_fail('throttled', 429, 'Bahut baar galat koshish hui. 15 minute baad try kijiye.');
    $st = sj_db()->prepare('SELECT pass FROM sj_users WHERE id = ?'); $st->execute([$u['id']]);
    if (!password_verify(isset($b['password']) ? (string)$b['password'] : '', (string)$st->fetchColumn())) { sj_add_fail($u['uname']); sj_fail('wrong_password', 403, 'Password galat hai.'); }
    $sec = sj_b32_enc(random_bytes(20)); sj_meta_set('totp_pending', sj_enc(json_encode(['secret' => $sec, 'at' => time()]), 'meta', 'totp_pending'));
    $set = sj_load_doc('settings', 'main'); $iss = is_array($set) && !empty($set['firm']) ? $set['firm'] : 'Shivaa Jewels';
    sj_out(['ok' => true, 'secret' => $sec, 'uri' => 'otpauth://totp/' . rawurlencode($iss . ':' . $u['uname']) . '?secret=' . $sec . '&issuer=' . rawurlencode($iss) . '&digits=6&period=30']);

case 'totp_enable':
    $u = sj_require_role(['owner']); $b = sj_body();
    $pv = sj_meta_get('totp_pending'); $pj = $pv ? json_decode((string)sj_dec($pv, 'meta', 'totp_pending'), true) : null;
    if (!is_array($pj) || time() - (int)$pj['at'] > 1800) sj_fail('expired', 400, 'Setup purana ho gaya — dobara shuru kijiye.');
    $code = preg_replace('/\D/', '', isset($b['code']) ? (string)$b['code'] : ''); $now = (int)floor(time() / 30); $hit = false;
    foreach ([0, -1, 1] as $d) if (hash_equals(sj_totp_at($pj['secret'], $now + $d), $code)) { $hit = $now + $d; break; }
    if ($hit === false) { sj_add_fail($u['uname']); sj_fail('wrong_otp', 403, 'Code nahi mila — phone ka time sahi hai? App mein naya code daaliye.'); }
    $codes = []; $hash = []; for ($k = 0; $k < 8; $k++) { $c = strtoupper(substr(sj_b32_enc(random_bytes(6)), 0, 8)); $codes[] = substr($c, 0, 4) . '-' . substr($c, 4); $hash[] = hash('sha256', $c); }
    sj_totp_put(['secret' => $pj['secret'], 'codes' => $hash, 'last' => $hit, 'since' => time()]);
    sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute(['totp_pending']);
    sj_out(['ok' => true, 'codes' => $codes]);

case 'totp_disable':
    $u = sj_require_role(['owner']); $b = sj_body();
    if (sj_throttled($u['uname'])) sj_fail('throttled', 429, 'Bahut baar galat koshish hui. 15 minute baad try kijiye.');
    $st = sj_db()->prepare('SELECT pass FROM sj_users WHERE id = ?'); $st->execute([$u['id']]);
    if (!password_verify(isset($b['password']) ? (string)$b['password'] : '', (string)$st->fetchColumn())) { sj_add_fail($u['uname']); sj_fail('wrong_password', 403, 'Password galat hai.'); }
    if (sj_totp_get() && !sj_totp_check(isset($b['code']) ? (string)$b['code'] : '')) { sj_add_fail($u['uname']); sj_fail('wrong_otp', 403, 'Authenticator / backup code galat hai.'); }
    sj_totp_put(null); sj_out(['ok' => true]);

case 'backup_list':
    sj_require_role(['owner']);
    sj_out(['ok' => true, 'list' => sj_bk_list(), 'mail' => sj_meta_get('backup_mail') === '1', 'email' => (string)sj_meta_get('alert_email'), 'mailFn' => function_exists('mail'), 'lastMail' => (int)sj_meta_get('backup_mail_at')]);

case 'backup_now':
    sj_require_role(['owner']); $f = sj_auto_backup(true);
    sj_out(['ok' => (bool)$f, 'list' => sj_bk_list(), 'message' => $f ? '' : 'Backup nahi bana — sj-data folder ki permission dekhiye.']);

case 'backup_get':
    sj_require_role(['owner']); $b = sj_body(); $s = sj_bk_export(sj_str($b, 'name', 60), true);
    header('Content-Disposition: attachment; filename="shivaa-backup-' . substr(sj_str($b, 'name', 60), 8, 10) . '.json"'); http_response_code(200); echo $s; exit;

case 'backup_cfg':
    sj_require_role(['owner']); $b = sj_body();
    if (isset($b['mail'])) { if ($b['mail'] && !sj_meta_get('alert_email')) sj_fail('invalid_argument', 400, 'Pehle Setup → "Shaq wali activity — email" mein email daaliye.'); sj_meta_set('backup_mail', $b['mail'] ? '1' : '0'); }
    $res = !empty($b['test']) ? sj_backup_mail(true) : '';
    sj_out(['ok' => true, 'mail' => sj_meta_get('backup_mail') === '1', 'result' => $res]);

case 'ai_rate':
    $u = sj_require_user(); @set_time_limit(120);
    if ($u['role'] === 'viewer') sj_fail('forbidden_role', 403, 'View only login rate nahi badal sakta.');
    $b = sj_body(); $city = preg_replace('/[^\p{L} .-]/u', '', sj_str($b, 'city', 40)) ?: 'Jaipur';
    $r = sj_ai_rate($city); if (!$r['ok']) sj_fail($r['code'], $r['http'], $r['message']); sj_out($r);

case 'catalog_cfg':
    sj_require_role(['owner', 'manager']); $b = sj_body();
    $cats = []; foreach (isset($b['cats']) && is_array($b['cats']) ? array_slice($b['cats'], 0, 40) : [] as $c) if (is_string($c) && $c !== '') $cats[] = substr($c, 0, 60);
    sj_meta_set('portal_catalog', json_encode(['on' => !empty($b['on']), 'cats' => $cats, 'max' => max(6, min(60, (int)(isset($b['max']) ? $b['max'] : 24)))]));
    sj_out(['ok' => true]);

case 'catalog_status':
    sj_require_user(); $j = json_decode((string)sj_meta_get('portal_catalog'), true); sj_out(['ok' => true, 'cfg' => is_array($j) ? $j : ['on' => false, 'cats' => [], 'max' => 24]]);

default:
    sj_fail('unknown_action', 404);
}
