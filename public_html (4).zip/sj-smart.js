/* =====================================================================
   Shivaa Jewels — SMART DUKAAN (v42)
   Ek jagah: Malik ka 1 minute · Sone ka kul hisaab · Purana stock ·
   Gadbad pakadne wala AI · Weight ka jaasoos · Karigar ghatt ·
   Reorder + season · Making sujhav · Supplier tulna · Staff incentive
   Sab kuch software ke apne data se — koi bahar ki service nahi.
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { role: 'owner', name: 'Owner', id: 'u_owner', uname: 'owner' };
  const boss = () => !SITE || ['owner', 'manager'].includes(me().role);
  const q$ = (s, r) => (r || document).querySelector(s);
  const DAY = 864e5;
  const pro = () => (settings().pro || {});
  const ageOf = p => { const t = num(p.createdAt) || Date.parse(p.date || p.inDate || '') || 0; return t ? Math.max(0, Math.floor((Date.now() - t) / DAY)) : null; };
  const pct = (a, b) => (b ? Math.round(a / b * 1000) / 10 : 0);
  const med = a => { const x = a.filter(n => isFinite(n)).sort((p, q) => p - q); return x.length ? x[Math.floor(x.length / 2)] : null; };
  const q = (a, f) => { const x = a.filter(n => isFinite(n)).sort((p, r) => p - r); return x.length ? x[Math.min(x.length - 1, Math.floor(x.length * f))] : null; };
  const g = n => (typeof g3 === 'function' ? g3(n) : num(n).toFixed(3) + ' g');
  const salesSince = d => S.invoices.filter(v => isSaleT(v.type) && !v.deleted && v.date >= d);
  const itemNet = it => num(it.net) || Math.max(0, num(it.gross) - num(it.less));
  const tunchOf = (pur, t) => num(t) || num((PUR[pur] || {}).t);
  const goldRate = () => { try { return num(rateFor('gold')); } catch (e) { return num(settings().gold24) / 10; } };

  /* ---------------- 1. Sone ka kul hisaab (fine gold position) ---------------- */
  function fine() {
    const gold = p => metalOf(p.purity) === 'gold';
    const st = S.products.filter(p => p.status === 'In Stock' && gold(p));
    const field = st.filter(p => p.custody);
    const appr = S.products.filter(p => p.status === 'On Approval' && gold(p));
    const jobs = (S.jobs || []).filter(j => j.status === 'Issued' && metalOf(j.purity) === 'gold');
    const kar = sum(jobs, j => jobCalc(j).issuedFine);
    const karOwe = sum((S.jobs || []).filter(j => j.status === 'Received' && metalOf(j.purity) === 'gold'), j => Math.max(0, jobCalc(j).balance));
    const custFine = sum(S.invoices.filter(v => v.type === 'metal' && !v.deleted), v => Math.max(0, invFineDue(v)));
    const advFine = sum(S.invoices.filter(v => v.type === 'metal' && !v.deleted), v => Math.min(0, invFineDue(v)));
    const oldG = sum((S.meltLots || []).filter(m => m.status !== 'Received' && m.status !== 'Done'), m => num(m.fineSent || m.fine || 0));
    const lockFine = sum((S.weddings || []).flatMap(w => (w.advances || []).filter(a => a.lock && a.lock.metal === 'gold')), a => num(a.lock.fine));
    const vault = sum(st, prodFine), ap = sum(appr, prodFine);
    const own = vault + ap + kar + karOwe + custFine + advFine;
    const net = own - lockFine;
    const r = goldRate();
    return { vault, field: sum(field, prodFine), ap, kar, karOwe, custFine, advFine: -advFine, oldG, lockFine, own, net, rate: r, per100: Math.round(net * 100), value: Math.round(net * r) };
  }

  /* ---------------- 2. Purana stock ---------------- */
  const BUCKETS = [[0, 30, '0–30 din'], [31, 60, '31–60'], [61, 90, '61–90'], [91, 180, '91–180'], [181, 1e9, '180+ din']];
  function aging() {
    const st = S.products.filter(p => p.status === 'In Stock');
    const rows = st.map(p => ({ p, age: ageOf(p), val: prodValue(p) })).filter(x => x.age !== null);
    const b = BUCKETS.map(([a, z, l]) => { const L = rows.filter(x => x.age >= a && x.age <= z); return { l, n: L.length, g: sum(L, x => x.p.gross), v: sum(L, x => x.val) }; });
    const old = rows.filter(x => x.age > 90).sort((a, z) => z.age - a.age);
    return { b, old, total: sum(rows, x => x.val), oldVal: sum(old, x => x.val), unknown: st.length - rows.length };
  }
  const advice = age => age > 180 ? 'Galao / naya design banwao' : age > 120 ? 'Offer ya discount' : 'Field challan par bhejo';

  /* ---------------- 3. Gadbad pakadne wala AI (risk score per login) ---------------- */
  function risk(days) {
    days = days || 30; const since = Date.now() - days * DAY, sinceD = addDays(todayStr(), -days);
    const M = new Map(); const get = k => { if (!M.has(k)) M.set(k, { who: k, bills: 0, edits: 0, dels: 0, night: 0, discN: 0, discSum: 0, bigDisc: 0, manual: 0, lockTry: 0, cashDiff: 0, alerts: 0 }); return M.get(k); };
    (S.audit || []).filter(a => num(a.at) >= since).forEach(a => {
      const who = a.by || a.user || '—'; const x = get(who); const h = new Date(a.at).getHours();
      if (a.col === 'invoices') { if (a.action === 'create') x.bills++; if (a.action === 'update' && (a.changes || []).some(c => /items|totals|discount|partyId|date|payments/.test(c.f))) x.edits++; if (a.action === 'delete') x.dels++; }
      else if (a.action === 'delete' && !['notes', 'trash', 'alerts'].includes(a.col)) x.dels++;
      if (h >= 22 || h < 7) x.night++;
    });
    const creator = new Map(); (S.audit || []).forEach(a => { if (a.col === 'invoices' && a.action === 'create') creator.set(a.docId, a.by || a.user); });
    S.invoices.filter(v => isSaleT(v.type) && v.date >= sinceD && !v.deleted).forEach(v => {
      const who = v.byName || creator.get(v.id); if (!who) return; const t = v.totals || {}; const it = num(t.itemsTotal); const d = num(t.discount);
      if (it > 0 && d > 0) { const x = get(who); const p = d / it * 100; x.discN++; x.discSum += p; if (p >= 5) x.bigDisc++; }
    });
    (S.alerts || []).filter(a => num(a.at) >= since).forEach(a => { const who = String(a.by || '').replace(/\s*\(.*\)$/, ''); if (!who || who === 'system') return; const x = get(who); x.alerts++; if (a.kind === 'manual_weight') x.manual++; if (a.kind === 'lock_try') x.lockTry++; if (a.kind === 'cash_diff') x.cashDiff++; });
    const L = [...M.values()].filter(x => x.who && x.who !== '—').map(x => {
      const base = Math.max(5, x.bills);
      const s = Math.min(100, Math.round(x.edits / base * 120 + x.dels * 8 + x.night * 2 + (x.discN ? x.discSum / x.discN : 0) * 3 + x.bigDisc * 4 + x.manual * 3 + x.lockTry * 15 + x.cashDiff * 10));
      const why = []; if (x.edits) why.push(`${x.edits} bill badle`); if (x.dels) why.push(`${x.dels} delete`); if (x.bigDisc) why.push(`${x.bigDisc} bill par 5%+ discount`); if (x.night) why.push(`${x.night} raat ki entry`); if (x.manual) why.push(`${x.manual} baar haath se weight`); if (x.lockTry) why.push(`${x.lockTry} lock todne ki koshish`); if (x.cashDiff) why.push(`${x.cashDiff} cash fark`);
      return { ...x, score: s, level: s >= 60 ? 'red' : s >= 30 ? 'amber' : 'green', why, avgDisc: x.discN ? Math.round(x.discSum / x.discN * 10) / 10 : 0 };
    }).sort((a, b) => b.score - a.score);
    return L;
  }

  /* ---------------- 4. Weight ka jaasoos ---------------- */
  function weightSpy(days) {
    days = days || 90; const since = Date.now() - days * DAY, sinceD = addDays(todayStr(), -days); const tol = Math.max(0.005, num(pro().wSpyTol) || 0.02); const out = [];
    (S.audit || []).filter(a => a.col === 'products' && a.action === 'update' && num(a.at) >= since).forEach(a => { (a.changes || []).filter(c => c.f === 'gross' || c.f === 'net').forEach(c => { const d = num(c.new) - num(c.old); if (d < -tol) out.push({ kind: 'Stock record mein wazan ghataya', ref: a.label, d, at: a.at, who: a.by || a.user || '' }); }); });
    S.invoices.filter(v => isSaleT(v.type) && !v.deleted && v.date >= sinceD).forEach(v => (v.items || []).forEach(it => { if (!it.productId) return; const p = S.products.find(x => x.id === it.productId); const was = p && num(p.gross); if (was && num(it.gross) && num(it.gross) < was - tol) out.push({ kind: 'Bikte waqt piece halka nikla', ref: `#${it.sku || (p && p.sku) || ''} · bill ${v.no}`, d: num(it.gross) - was, at: Date.parse(v.date), who: v.byName || '' }); }));
    (S.approvals || []).filter(a => a.date >= addDays(todayStr(), -days)).forEach(a => (a.lines || []).filter(l => l.status === 'returned' && l.retGross != null).forEach(l => { const d = num(l.retGross) - num(l.gross); if (d < -tol) out.push({ kind: 'Approval se halka wapas aaya', ref: `#${l.sku} · ${a.no} · ${a.partyName}`, d, at: Date.parse(l.retOn || a.date), who: a.partyName }); }));
    (S.challans || []).filter(c => c.ret && c.date >= sinceD).forEach(c => { if (c.ret.weight != null && c.ret.expW != null && num(c.ret.weight) < num(c.ret.expW) - tol) out.push({ kind: 'Challan wapsi mein bag halka', ref: c.no + ' · ' + (c.staff || ''), d: num(c.ret.weight) - num(c.ret.expW), at: num(c.ret.at), who: c.staff || '' }); });
    return out.sort((a, b) => a.d - b.d);
  }

  /* ---------------- 5. Karigar ghatt ---------------- */
  function karigar() {
    const extra = num(pro().ghattMax) || 0.5;
    const M = new Map();
    (S.jobs || []).forEach(j => {
      const k = j.karigarId || j.karigarName; const x = M.get(k) || { name: j.karigarName || '—', open: 0, openFine: 0, over: 0, done: 0, iss: 0, rec: 0, lossPct: [], allow: [], owe: 0, late: 0 };
      const c = jobCalc(j);
      if (j.status === 'Issued') { x.open++; x.openFine += c.issuedFine; if (j.dueDate && j.dueDate < todayStr()) x.late++; }
      if (j.status === 'Received') { x.done++; const iss = num(j.issuedWt), rec = num(j.receivedWt) + num(j.scrapWt); x.iss += iss; x.rec += rec; if (iss > 0) { x.lossPct.push((iss - rec) / iss * 100); x.allow.push(num(j.wastage)); } x.owe += Math.max(0, c.balance); }
      M.set(k, x);
    });
    return [...M.values()].map(x => { const real = x.iss > 0 ? (x.iss - x.rec) / x.iss * 100 : null; const allow = x.allow.length ? x.allow.reduce((a, b) => a + b, 0) / x.allow.length : null; const bad = real != null && allow != null && real > allow + extra; return { ...x, real, allowAvg: allow, bad, extra }; }).sort((a, b) => (b.bad - a.bad) || (b.openFine - a.openFine));
  }

  /* ---------------- 6. Reorder + season ---------------- */
  function demand(fromD, toD) { const M = new Map(); S.invoices.filter(v => isSaleT(v.type) && !v.deleted && v.date >= fromD && v.date <= toD).forEach(v => (v.items || []).forEach(it => { const k = `${(it.category || '').trim()}|${it.purity || ''}`; if (k === '|') return; const x = M.get(k) || { cat: (it.category || '').trim(), pur: it.purity || '', pcs: 0, net: 0 }; x.pcs += Math.max(1, num(it.pcs) || 1); x.net += itemNet(it); M.set(k, x); })); return M; }
  function stockBy() { const M = new Map(); S.products.filter(p => p.status === 'In Stock').forEach(p => { const k = `${(p.category || '').trim()}|${p.purity || ''}`; const x = M.get(k) || { pcs: 0, net: 0 }; x.pcs += Math.max(1, num(p.pcs) || 1); x.net += num(p.net); M.set(k, x); }); return M; }
  function reorder() {
    const t = todayStr(), D30 = demand(addDays(t, -30), t), ST = stockBy(), out = [];
    D30.forEach((x, k) => { const st = ST.get(k) || { pcs: 0, net: 0 }; const perDay = x.pcs / 30; const cover = perDay > 0 ? st.pcs / perDay : 999; if (x.pcs >= 2 && cover < 20) out.push({ ...x, stock: st.pcs, cover: Math.round(cover), need: Math.max(1, Math.ceil(perDay * 30 - st.pcs)), avgW: x.net / x.pcs }); });
    return out.sort((a, b) => a.cover - b.cover);
  }
  function season() {
    const t = todayStr(), a = addDays(t, -365), z = addDays(t, -365 + 60);
    const LY = demand(a, z), ST = stockBy(), out = [];
    const now = demand(addDays(t, -60), t), prev = demand(addDays(t, -425), addDays(t, -365));
    const sum1 = M => [...M.values()].reduce((s, x) => s + x.pcs, 0); const grow = sum1(prev) > 0 ? Math.max(0.6, Math.min(2, sum1(now) / sum1(prev))) : 1;
    LY.forEach((x, k) => { const st = ST.get(k) || { pcs: 0 }; const want = Math.ceil(x.pcs * grow); if (want - st.pcs >= 2) out.push({ ...x, want, stock: st.pcs, make: want - st.pcs, avgW: x.net / x.pcs }); });
    return { list: out.sort((p, r) => r.make - p.make).slice(0, 40), from: a, to: z, grow: Math.round(grow * 100) / 100 };
  }

  /* ---------------- 7. Making sujhav ---------------- */
  function making(days) {
    days = days || 180; const M = new Map();
    salesSince(addDays(todayStr(), -days)).forEach(v => (v.items || []).forEach(it => {
      const net = itemNet(it), t = tunchOf(it.purity, it.tunch), rate = num(it.rate); if (!(net > 0 && t > 0 && rate > 0)) return;
      const pure = net * t / 100 * rate; const c = calcItem(it, v.type); if (!(pure > 0)) return;
      const mk = (c.amount - pure) / pure * 100; if (!isFinite(mk) || mk < -20 || mk > 200) return;
      const sect = (typeof sectorOf === 'function' ? sectorOf(v) : '') || '';
      const k = `${(it.category || '').trim() || '—'}|${it.purity || ''}`; const x = M.get(k) || { cat: (it.category || '').trim() || '—', pur: it.purity || '', mk: [], w: [], n: 0, sect: new Set() }; x.mk.push(mk); x.w.push(num(it.wastage)); x.n++; if (sect) x.sect.add(sect); M.set(k, x);
    }));
    return [...M.values()].filter(x => x.n >= 3).map(x => ({ ...x, med: med(x.mk), lo: q(x.mk, 0.25), hi: q(x.mk, 0.75), wMed: med(x.w) })).sort((a, b) => b.n - a.n);
  }

  /* ---------------- 8. Supplier tulna ---------------- */
  function suppliers(days) {
    days = days || 365; const M = new Map();
    S.invoices.filter(v => ['purchase', 'estpurchase'].includes(v.type) && !v.deleted && v.date >= addDays(todayStr(), -days)).forEach(v => {
      const x = M.get(v.partyId) || { name: v.partyName, bills: 0, net: 0, cost: [], short: [], last: '' }; x.bills++; x.last = v.date > x.last ? v.date : x.last;
      (v.items || []).forEach(it => { const net = itemNet(it); if (!(net > 0)) return; x.net += net; const std = num((PUR[it.purity] || {}).t); const t = num(it.tunch); if (std && t) x.short.push(std - t); const rate = num(it.rate); if (t && rate) { const pure = net * t / 100 * rate; const c = calcItem(it, v.type); if (pure > 0) x.cost.push((c.amount - pure) / pure * 100); } });
      M.set(v.partyId, x);
    });
    return [...M.values()].filter(x => x.net > 0).map(x => ({ ...x, costMed: med(x.cost), shortMed: med(x.short) })).sort((a, b) => (a.costMed == null) - (b.costMed == null) || (a.costMed || 0) - (b.costMed || 0));
  }

  /* ---------------- 9. Staff incentive ---------------- */
  function incentive(month) {
    const p = pro().incentive || {}; const rate = num(p.pct != null ? p.pct : 0.25), fieldBonus = num(p.fieldPct != null ? p.fieldPct : 0.1), tgt = num(p.target || 0), tgtBonus = num(p.targetBonus || 0);
    const creator = new Map(); (S.audit || []).forEach(a => { if (a.col === 'invoices' && a.action === 'create') creator.set(a.docId, a.by || a.user); });
    const M = new Map(); const get = k => { if (!M.has(k)) M.set(k, { who: k, bills: 0, sale: 0, field: 0, inc: 0 }); return M.get(k); };
    S.invoices.filter(v => isSaleT(v.type) && !v.deleted && monthKey(v.date) === month).forEach(v => { const who = v.byName || creator.get(v.id); if (!who) return; const x = get(who); x.bills++; x.sale += num((v.totals || {}).taxable || invPayable(v)); });
    (S.challans || []).filter(c => monthKey(c.date || '') === month).forEach(c => (c.visits || []).forEach(v => (v.sel || []).filter(s => s.mode === 'sale').forEach(s => { get(c.staff || '—').field += num(s.value); })));
    return { rows: [...M.values()].map(x => { const base = x.sale * rate / 100 + x.field * fieldBonus / 100; const bonus = tgt > 0 && x.sale + x.field >= tgt ? tgtBonus : 0; return { ...x, base: Math.round(base), bonus, total: Math.round(base + bonus) }; }).sort((a, b) => b.total - a.total), rate, fieldBonus, tgt, tgtBonus };
  }

  /* ---------------- 10. Malik ka 1 minute ---------------- */
  function minute() {
    const t = todayStr(); let c = null; try { c = dayClosing(t); } catch (e) { /* older data */ }
    const sales = c ? num((c.bills.sell_pakka || {}).value) + num((c.bills.sell_kacha || {}).value) : sum(salesSince(t).filter(v => v.date === t), invPayable);
    const bills = c ? num((c.bills.sell_pakka || {}).n) + num((c.bills.sell_kacha || {}).n) : 0;
    const out = (S.challans || []).filter(x => x.status === 'out' || x.status === 'issued');
    const bagV = sum(out, ch => window.SJ_FIELD ? sum(SJ_FIELD.bag(ch), i => i.value) : num(ch.value));
    const apV = sum(S.products.filter(p => p.status === 'On Approval'), prodValue);
    const recv = sum(S.invoices.filter(v => !isBuy(v.type) && !v.deleted), v => Math.max(0, invDue(v)));
    const al = (S.alerts || []).filter(a => !a.seen && num(a.at) > Date.now() - 2 * DAY);
    const f = fine(), ag = aging(), rk = risk(30).filter(x => x.level === 'red'), kr = karigar().filter(x => x.bad || x.late);
    const s = settings();
    return { sales, bills, cash: c ? c.expected : null, out: out.length, bagV, apV, recv, al, alHigh: al.filter(a => a.level === 'high').length, f, ag, rk, kr, rate24: num(s.gold24), rateOk: s.ratesUpdated === t, panic: out.some(x => (x.panic || []).length) };
  }

  /* ================= VIEW ================= */
  Object.assign(ICON, { brain: '<path d="M9 4a3 3 0 0 0-3 3v1a3 3 0 0 0-2 5 3 3 0 0 0 3 5 3 3 0 0 0 5 1V5a3 3 0 0 0-3-1z"/><path d="M15 4a3 3 0 0 1 3 3v1a3 3 0 0 1 2 5 3 3 0 0 1-3 5 3 3 0 0 1-5 1"/>' });
  if (!VIEWS.some(v => v[0] === 'smart')) { const i = VIEWS.findIndex(v => v[0] === 'field' || v[0] === 'floors' || v[0] === 'vault'); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, ['smart', 'Smart', 'brain', '🧠 Smart Dukaan']); }
  const TABS = [['malik', '⏱ Malik ka 1 minute'], ['sona', '🟡 Sone ka hisaab'], ['purana', '🕰 Purana stock'], ['gadbad', '🕵 Gadbad AI'], ['wazan', '⚖ Weight jaasoos'], ['karigar', '🔨 Karigar ghatt'], ['reorder', '📦 Reorder + season'], ['making', '💎 Making sujhav'], ['supplier', '🏭 Supplier tulna'], ['incentive', '🎁 Staff incentive']];
  VIEWDEF.smart = {
    shell: () => { const t = ui.smTab || 'malik'; return `<div class="rep-tabs sm-tabs">${TABS.map(([k, l]) => `<button type="button" data-act="seg" data-k="smTab" data-v="${k}" class="${t === k ? 'on' : ''}">${l}</button>`).join('')}</div><div id="vbody"></div>`; },
    body() {
      if (!boss()) return emptyBox('Ye page sirf Owner / Manager ke liye hai.');
      const t = ui.smTab || 'malik';
      try { return ({ malik: malikBody, sona: sonaBody, purana: puranaBody, gadbad: gadbadBody, wazan: wazanBody, karigar: karigarBody, reorder: reorderBody, making: makingBody, supplier: supplierBody, incentive: incBody }[t] || malikBody)(); }
      catch (e) { console.error(e); return emptyBox('Ye hisaab abhi nahi ban paya: ' + esc(e.message || String(e))); }
    }
  };
  const card = (title, sub, inner) => `<div class="card"><div class="card-h"><h3>${title}</h3>${sub ? `<span class="small muted">${sub}</span>` : ''}</div>${inner}</div>`;
  const table = (heads, rows, empty) => rows.length ? `<div class="tw"><table class="tbl"><thead><tr>${heads.map(h => `<th class="${h[1] || ''}">${h[0]}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>` : `<div class="small muted">${empty || 'Abhi data nahi'}</div>`;
  const tile = (l, v, s, tone) => `<div class="sm-tile ${tone || ''}"><span>${l}</span><b>${v}</b>${s ? `<small>${s}</small>` : ''}</div>`;

  function malikBody() {
    const m = minute(), f = m.f;
    const todo = [];
    if (m.panic) todo.push(['red', '🆘 Field mein PANIC alert — turant dekhiye', 'field']);
    if (m.alHigh) todo.push(['red', `${m.alHigh} zaroori alert (2 din mein) — dekhiye`, 'alerts']);
    if (!m.rateOk) todo.push(['amber', 'Aaj ka bhaav abhi set nahi hua', 'rates']);
    m.rk.slice(0, 3).forEach(x => todo.push(['amber', `🕵 ${x.who}: jokhim score ${x.score} — ${x.why.slice(0, 2).join(', ')}`, 'gadbad']));
    m.kr.slice(0, 3).forEach(x => todo.push(['amber', `🔨 ${x.name}: ${x.bad ? `ghatt ${x.real.toFixed(2)}% (seema ${(x.allowAvg + x.extra).toFixed(2)}%)` : ''}${x.late ? ` ${x.late} kaam der se` : ''}`, 'karigar']));
    if (m.ag.oldVal > 0) todo.push(['', `🕰 ${m.ag.old.length} piece 90 din se pade — ${compactInr(m.ag.oldVal)} phansa`, 'purana']);
    return `<div class="sm-hero"><div><span class="small muted">${esc(new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' }))}</span><h2>Namaste ${esc((me().name || 'Malik').split(' ')[0])} ji 🙏</h2><p class="small muted" style="margin:0">Dukaan ki poori haalat — ek nazar mein</p></div></div>
      <div class="sm-grid">${tile('Aaj ki bikri', inr(m.sales), m.bills + ' bill', 'gold')}${tile('Galle mein hona chahiye', m.cash == null ? '—' : inr(m.cash), 'cash')}${tile('Shuddh sona (aapka)', g(f.net), `≈ ${compactInr(f.value)}`, 'gold')}${tile('Field mein maal', compactInr(m.bagV), m.out + ' challan', m.panic ? 'red' : '')}${tile('Approval par', compactInr(m.apV), 'dukaandaron ke paas')}${tile('Kul udhaar (lena)', compactInr(m.recv), '')}${tile('Alert (2 din)', m.al.length, m.alHigh ? m.alHigh + ' zaroori' : 'sab theek', m.alHigh ? 'red' : 'green')}${tile('Aaj ka bhaav', m.rate24 ? inr(m.rate24) : '—', m.rateOk ? '24K /10g ✓' : 'set karo', m.rateOk ? '' : 'red')}</div>
      ${card('✅ Aaj aapko kya dekhna hai', '', todo.length ? `<div class="sm-todo">${todo.map(([tone, txt, k]) => `<button type="button" class="sm-td ${tone}" data-act="${['field', 'alerts', 'rates'].includes(k) ? 'sm-go' : 'seg'}" ${['field', 'alerts', 'rates'].includes(k) ? `data-to="${k}"` : `data-k="smTab" data-v="${k}"`}>${esc(txt)}<span>›</span></button>`).join('')}</div>` : '<div class="fd-done">👍 Sab theek hai — koi zaroori kaam nahi.</div>')}`;
  }
  function sonaBody() {
    const f = fine();
    const rows = [['Vault stock (dukaan + floors)', f.vault, 'In Stock gehne ka shuddh sona'], ['  └ jisme field challan mein', f.field, 'staff ke bag mein (vault mein shamil)'], ['Approval par (dukaandaron ke paas)', f.ap, 'memo par gaya maal'], ['Karigar ke paas (kaam chal raha)', f.kar, 'issue kiya, abhi aaya nahi'], ['Karigar par baaki (kaam ke baad)', f.karOwe, 'ghatt / kam lautaya'], ['Grahak / dukaandar ko dena hai — metal khata', f.custFine, 'metal bill ka fine baaki']];
    const neg = [['Advance mein liya sona (metal khata)', f.advFine], ['Shaadi package mein bhaav-lock fine', f.lockFine]];
    return `<div class="sm-grid">${tile('Aapka shuddh sona (net)', g(f.net), '24K ke hisaab se', 'gold')}${tile('Aaj ki keemat', compactInr(f.value), f.rate ? inr(f.rate * 10) + ' /10g' : 'bhaav set karo')}${tile('Bhaav ₹100/g badhe to', (f.net >= 0 ? '+' : '') + compactInr(f.per100), f.net >= 0 ? 'fayda' : 'nuksaan', f.net >= 0 ? 'green' : 'red')}${tile('Bhaav ₹100/g ghate to', (f.net >= 0 ? '-' : '+') + compactInr(Math.abs(f.per100)), f.net >= 0 ? 'nuksaan' : 'fayda', f.net >= 0 ? 'red' : 'green')}</div>
      ${card('🟡 Sona kahan-kahan hai', 'shuddh (fine) gram', table([['Jagah'], ['Fine', 'r'], ['Matlab']], rows.map(r => `<tr><td>${esc(r[0])}</td><td class="r"><b>${g(r[1])}</b></td><td class="small muted">${esc(r[2])}</td></tr>`).concat(neg.map(r => `<tr><td>− ${esc(r[0])}</td><td class="r red">${g(r[1])}</td><td class="small muted">dena hai / pakka ho chuka</td></tr>`)).concat([`<tr><td><b>Net — aapka apna sona</b></td><td class="r"><b class="gold-t">${g(f.net)}</b></td><td class="small muted">≈ ${esc(compactInr(f.value))}</td></tr>`])))}
      <p class="small muted">Net sona jitna zyada, bhaav badhne par utna fayda aur ghatne par utna nuksaan. Bahut zyada sona ho to bhaav-lock / hedging par CA ya bullion dealer se baat kijiye. Chandi is hisaab mein nahi.</p>`;
  }
  function puranaBody() {
    const a = aging();
    const mx = Math.max(1, ...a.b.map(x => x.v));
    return `<div class="sm-grid">${tile('90 din se purana stock', a.old.length + ' pcs', compactInr(a.oldVal) + ' phansa', a.oldVal ? 'red' : 'green')}${tile('Kul stock keemat', compactInr(a.total), '')}${tile('Umar pata nahi', a.unknown + ' pcs', 'purane import')}</div>
      ${card('🕰 Stock ki umar', 'keemat aaj ke bhaav par', `<div class="sm-bars">${a.b.map((x, i) => `<div class="sm-bar"><span>${x.l}</span><div><i style="width:${Math.round(x.v / mx * 100)}%" class="b${i}"></i></div><b>${compactInr(x.v)}</b><small>${x.n} pcs · ${g(x.g)}</small></div>`).join('')}</div>`)}
      ${card('Sabse purane piece', 'chuniye aur ek click mein field challan banaiye', a.old.length ? `<div class="btns" style="margin-bottom:8px"><button type="button" class="btn sm gold" data-act="sm-old-ch">🚚 Chune hue — naya challan draft</button><button type="button" class="btn sm" data-act="sm-old-all">Sab chuno</button></div>` + table([[''], ['Piece'], ['Umar', 'r'], ['Wazan', 'r'], ['Keemat', 'r'], ['Sujhav']], a.old.slice(0, 200).map(x => `<tr><td><input type="checkbox" data-old="${esc(x.p.id)}" ${x.p.custody ? 'disabled' : ''}></td><td><b class="mono">#${esc(x.p.sku || '')}</b> ${esc(x.p.category || '')} ${esc(x.p.purity || '')}${x.p.custody ? ' <span class="pill sky">field</span>' : ''}</td><td class="r ${x.age > 180 ? 'red' : ''}">${x.age} din</td><td class="r">${g(x.p.gross)}</td><td class="r">${inr(x.val)}</td><td class="small">${advice(x.age)}</td></tr>`)) : '<div class="fd-done">👍 90 din se purana koi piece nahi.</div>')}`;
  }
  function gadbadBody() {
    const D = +(ui.smRiskD || 30); const L = risk(D);
    const own = me().role === 'owner' || !SITE;
    return `<div class="seg-mini" style="margin-bottom:10px">${[7, 30, 90].map(d => `<button type="button" class="${D === d ? 'on' : ''}" data-act="seg" data-k="smRiskD" data-v="${d}">${d} din</button>`).join('')}</div>
      ${card('🕵 Har login ka jokhim score', '0 = sab theek · 60+ = dhyan dijiye', table([['Login'], ['Score', 'r'], ['Bill', 'r'], ['Badle', 'r'], ['Delete', 'r'], ['Avg discount', 'r'], ['Raat', 'r'], ['Kyun']], L.map(x => `<tr><td><b>${esc(x.who)}</b></td><td class="r"><span class="pill ${x.level === 'red' ? 'red' : x.level === 'amber' ? 'gold' : 'green'}">${x.score}</span></td><td class="r">${x.bills}</td><td class="r ${x.edits ? 'red' : ''}">${x.edits}</td><td class="r ${x.dels ? 'red' : ''}">${x.dels}</td><td class="r">${x.avgDisc ? x.avgDisc + '%' : '—'}</td><td class="r">${x.night}</td><td class="small">${esc(x.why.join(' · ') || 'kuch khaas nahi')}</td></tr>`), 'Is samay mein koi entry nahi'))}
      <p class="small muted">Score edit-log (audit), bills, discount${own ? ', alerts' : ''} aur raat ki entries se banta hai. Ye sirf ishaara hai — kisi par shaq karne se pehle bill aur log khud dekhiye (Setup → Edit log).</p>`;
  }
  function wazanBody() {
    const L = weightSpy(90);
    return card('⚖ Weight ka jaasoos', 'piece ka wazan kahin ghata to — nag nikla / piece badla?', table([['Kya hua'], ['Piece / bill'], ['Fark', 'r'], ['Kab'], ['Kaun']], L.slice(0, 200).map(x => `<tr><td>${esc(x.kind)}</td><td>${esc(x.ref)}</td><td class="r red"><b>${num(x.d).toFixed(3)} g</b></td><td class="small">${x.at ? esc(new Date(x.at).toLocaleDateString('en-IN')) : ''}</td><td class="small">${esc(x.who || '')}</td></tr>`), '👍 Pichhle 90 din mein kisi piece ka wazan nahi ghata.')) +
      `<p class="small muted">Har baar piece tolne par (bikri, approval wapsi, challan wapsi, stock edit) purane wazan se milaya jaata hai. Seema: ${num(pro().wSpyTol) || 0.02} g. Kaante se tolna (⚖ button) sabse pakka hai.</p>`;
  }
  function karigarBody() {
    const L = karigar();
    return card('🔨 Karigar — ghatt aur baaki', `ghatt seema = tay wastage + ${L[0] ? L[0].extra : 0.5}%`, table([['Karigar'], ['Chal raha', 'r'], ['Unke paas (fine)', 'r'], ['Asli ghatt', 'r'], ['Tay wastage', 'r'], ['Baaki (fine)', 'r'], ['Der', 'r'], ['']], L.map(x => `<tr class="${x.bad ? 'sm-bad' : ''}"><td><b>${esc(x.name)}</b><div class="small muted">${x.done} kaam pure</div></td><td class="r">${x.open}</td><td class="r">${g(x.openFine)}</td><td class="r ${x.bad ? 'red' : ''}">${x.real == null ? '—' : x.real.toFixed(2) + '%'}</td><td class="r">${x.allowAvg == null ? '—' : x.allowAvg.toFixed(2) + '%'}</td><td class="r ${x.owe > 0.001 ? 'red' : ''}">${g(x.owe)}</td><td class="r ${x.late ? 'red' : ''}">${x.late}</td><td class="small">${x.bad ? '⚠ ghatt zyada — baat kijiye' : ''}</td></tr>`), 'Abhi koi karigar kaam nahi')) +
      `<p class="small muted">Asli ghatt = (diya − wapas aaya gehna − scrap) ÷ diya. Karigar ka kaam Metal → Karigar mein entry hota hai.</p>`;
  }
  function reorderBody() {
    const R = reorder(), Sn = season();
    const txt = R.map(x => `• ${x.cat} ${x.pur} — ${x.need} pcs (lagbhag ${x.avgW.toFixed(1)} g)`).join('\n');
    return card('📦 Jaldi khatam hone wala maal', 'pichhle 30 din ki bikri vs stock', table([['Design'], ['30 din bika', 'r'], ['Stock', 'r'], ['Kitne din chalega', 'r'], ['Banwao', 'r']], R.map(x => `<tr><td><b>${esc(x.cat)}</b> ${esc(x.pur)}<div class="small muted">avg ${x.avgW.toFixed(2)} g</div></td><td class="r">${x.pcs}</td><td class="r">${x.stock}</td><td class="r ${x.cover < 7 ? 'red' : ''}">${x.cover} din</td><td class="r"><b>${x.need} pcs</b></td></tr>`), '👍 Koi design khatam hone ke kareeb nahi.') + (R.length ? `<div class="btns" style="margin-top:8px"><button type="button" class="btn sm green" data-act="sm-wa" data-t="${esc(encodeURIComponent('Karigar order — ' + (settings().firm || 'Shivaa Jewels') + '\n' + txt))}">WhatsApp par karigar ko bhejo</button></div>` : '')) +
      card('📅 Season ki bhavishyavani', `pichhle saal ${esc(fmtD(Sn.from))} – ${esc(fmtD(Sn.to))} (agle 60 din) ki bikri × raftaar ${Sn.grow}`, table([['Design'], ['Pichhle saal bika', 'r'], ['Is baar chahiye', 'r'], ['Stock', 'r'], ['Abhi banwao', 'r']], Sn.list.map(x => `<tr><td><b>${esc(x.cat)}</b> ${esc(x.pur)}<div class="small muted">avg ${x.avgW.toFixed(2)} g</div></td><td class="r">${x.pcs}</td><td class="r">${x.want}</td><td class="r">${x.stock}</td><td class="r"><b>${x.make} pcs</b></td></tr>`), 'Pichhle saal ka data nahi — agle saal se ye apne aap banega.'));
  }
  function makingBody() {
    const L = making(180);
    return card('💎 Making charge — grahak kitna dete hain', 'pichhle 6 mahine ki bikri (sone ki asli keemat ke upar kitna %)', table([['Design'], ['Bill', 'r'], ['Aam taur par', 'r'], ['Beech ka range', 'r'], ['Wastage (median)', 'r'], ['Sujhav']], L.map(x => `<tr><td><b>${esc(x.cat)}</b> ${esc(x.pur)}</td><td class="r">${x.n}</td><td class="r"><b>${x.med.toFixed(1)}%</b></td><td class="r">${x.lo.toFixed(1)}–${x.hi.toFixed(1)}%</td><td class="r">${x.wMed == null ? '—' : x.wMed.toFixed(2) + '%'}</td><td class="small">${x.lo < x.med - 4 ? `${x.lo.toFixed(1)}% se kam mat jaiye` : 'Rate theek chal raha'}</td></tr>`), 'Har design ke kam se kam 3 bill chahiye.')) +
      `<p class="small muted">Making % = (bill ki rakam − sone ki shuddh keemat) ÷ shuddh keemat. Isme wastage, labour, nag aur margin sab shamil.</p>`;
  }
  function supplierBody() {
    const L = suppliers(365);
    return card('🏭 Supplier tulna', 'pichhle 12 mahine ki kharid — kam % = sasta', table([['Supplier'], ['Bill', 'r'], ['Kul wazan', 'r'], ['Shuddh ke upar kharcha', 'r'], ['Tunch kam diya', 'r'], ['Aakhri kharid']], L.map((x, i) => `<tr><td><b>${esc(x.name)}</b>${i === 0 && x.costMed != null ? ' <span class="pill green">sabse sasta</span>' : ''}</td><td class="r">${x.bills}</td><td class="r">${g(x.net)}</td><td class="r">${x.costMed == null ? '—' : x.costMed.toFixed(1) + '%'}</td><td class="r ${x.shortMed > 0.3 ? 'red' : ''}">${x.shortMed == null ? '—' : x.shortMed.toFixed(2) + ' pt'}</td><td class="small">${esc(fmtD(x.last))}</td></tr>`), 'Abhi kharid ke bill nahi')) +
      `<p class="small muted">"Tunch kam diya" = standard purity (jaise 22K = ${num((PUR['22K'] || {}).t) || 91.6}) se bill ki tunch kitni kam. Zyada ho to purity check karwaiye.</p>`;
  }
  function incBody() {
    const mk = ui.smIncM || monthKey(todayStr()); const R = incentive(mk); const own = me().role === 'owner' || !SITE;
    const months = []; for (let i = 0; i < 6; i++) { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i); months.push(d.toISOString().slice(0, 7)); }
    return `<div class="seg-mini" style="margin-bottom:10px">${months.map(m => `<button type="button" class="${mk === m ? 'on' : ''}" data-act="seg" data-k="smIncM" data-v="${m}">${m}</button>`).join('')}</div>
      ${card('🎁 Staff incentive', `counter bikri ${R.rate}% · field bikri ${R.fieldBonus}%${R.tgt ? ` · ${compactInr(R.tgt)} paar karne par ${inr(R.tgtBonus)} bonus` : ''}`, table([['Staff'], ['Bill', 'r'], ['Counter bikri', 'r'], ['Field bikri', 'r'], ['Incentive', 'r'], ['Bonus', 'r'], ['Kul', 'r'], ['']], R.rows.map(x => `<tr><td><b>${esc(x.who)}</b></td><td class="r">${x.bills}</td><td class="r">${compactInr(x.sale)}</td><td class="r">${compactInr(x.field)}</td><td class="r">${inr(x.base)}</td><td class="r">${x.bonus ? inr(x.bonus) : '—'}</td><td class="r"><b>${inr(x.total)}</b></td><td><button type="button" class="btn sm" data-act="sm-inc-wa" data-w="${esc(x.who)}" data-m="${esc(mk)}">Parchi</button></td></tr>`), 'Is mahine koi bikri nahi'))}
      ${own ? `<details class="card"><summary><b>⚙ Incentive ke niyam</b></summary><div class="fg" style="margin-top:10px">${fld('Counter bikri par %', 'smIncPct', (pro().incentive || {}).pct != null ? pro().incentive.pct : 0.25, { type: 'number', step: '0.01' })}${fld('Field bikri par %', 'smIncF', (pro().incentive || {}).fieldPct != null ? pro().incentive.fieldPct : 0.1, { type: 'number', step: '0.01' })}${fld('Mahine ka target ₹ (0 = nahi)', 'smIncT', (pro().incentive || {}).target || 0, { type: 'number' })}${fld('Target bonus ₹', 'smIncB', (pro().incentive || {}).targetBonus || 0, { type: 'number' })}</div><div class="btns"><button type="button" class="btn gold sm" data-act="sm-inc-save">Save</button></div></details>` : ''}
      <p class="small muted">Bikri us login ke naam judti hai jisne bill banaya. Field bikri challan ke staff ke naam.</p>`;
  }

  /* ---------------- actions ---------------- */
  async function oldToChallan() {
    const ids = [...document.querySelectorAll('[data-old]:checked')].map(i => i.dataset.old);
    if (!ids.length) return toast('Pehle piece chuniye', 'err');
    if (!window.SJ_FIELD) return toast('Field module nahi mila', 'err');
    const items = ids.map(id => S.products.find(p => p.id === id)).filter(p => p && p.status === 'In Stock' && !p.custody).map(p => ({ id: p.id, sku: p.sku, name: `${p.category || ''} ${p.purity || ''}`.trim(), purity: p.purity, gross: num(p.gross), net: num(p.net), value: r2(prodValue(p)), floor: p.floor || '' }));
    const c = { id: uid('dc'), no: nextNo('challans', 'DC-'), date: todayStr(), status: 'draft', route: [], items, createdAt: Date.now(), updatedAt: Date.now(), note: 'Purana stock' };
    if (!await save('challans', c)) return;
    toast(`✓ Draft ${c.no} — ${items.length} purane piece. Ab dukaanein jodiye aur scan kijiye.`);
    SJ_FIELD.newChallan(c.id);
  }
  async function incSave() {
    const v = n => num((q$(`[name="${n}"]`) || {}).value);
    const p = { ...pro(), incentive: { pct: v('smIncPct'), fieldPct: v('smIncF'), target: v('smIncT'), targetBonus: v('smIncB') } };
    if (await saveSettings({ ...S.settings, pro: p })) { toast('✓ Incentive ke niyam save'); renderView(true); }
  }
  function incWa(who, mk) {
    const R = incentive(mk).rows.find(x => x.who === who); if (!R) return;
    const t = `*${settings().firm || 'Shivaa Jewels'} — Incentive parchi ${mk}*\n${who}\nBill: ${R.bills}\nCounter bikri: ${inr(R.sale)}\nField bikri: ${inr(R.field)}\nIncentive: ${inr(R.base)}${R.bonus ? `\nTarget bonus: ${inr(R.bonus)}` : ''}\n*Kul: ${inr(R.total)}*\nShabash! 🙏`;
    window.open('https://wa.me/?text=' + encodeURIComponent(t), '_blank', 'noopener');
  }
  const ACT = {
    'sm-old-ch': () => oldToChallan(),
    'sm-old-all': () => document.querySelectorAll('[data-old]:not(:disabled)').forEach(i => { i.checked = true; }),
    'sm-wa': t => window.open('https://wa.me/?text=' + t.dataset.t, '_blank', 'noopener'),
    'sm-inc-save': () => incSave(), 'sm-inc-wa': t => incWa(t.dataset.w, t.dataset.m),
    'sm-go': t => { const k = t.dataset.to; if (k === 'field') { ui.fdTab = 'today'; location.hash = '#field'; } else if (k === 'rates') { if (typeof openRates === 'function') openRates(); else location.hash = '#dashboard'; } else { location.hash = '#dashboard'; } },
    'sm-open': () => { ui.smTab = 'malik'; location.hash = '#smart'; }
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="sm-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);

  /* ---------------- dashboard card: Malik ka 1 minute ---------------- */
  { const D = VIEWDEF.dashboard; if (D && D.body) VIEWDEF.dashboard = { ...D, body() { let x = ''; try { if (boss()) { const m = minute(); const bad = m.alHigh + m.rk.length + m.kr.length + (m.panic ? 1 : 0) + (m.rateOk ? 0 : 1); x = `<div class="card sm-dash" data-act="sm-open" role="button" tabindex="0"><div><b>⏱ Malik ka 1 minute</b><span>Bikri ${esc(inr(m.sales))} · shuddh sona ${esc(g(m.f.net))} · field ${esc(compactInr(m.bagV))} · udhaar ${esc(compactInr(m.recv))}</span></div><span class="pill ${bad ? 'red' : 'green'}">${bad ? bad + ' dhyan do' : 'sab theek'}</span></div>`; } } catch (e) { console.error(e); } return x + D.body.apply(D, arguments); } }; }

  /* ---------------- Jarvis tools ---------------- */
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    agentTools = function () {
      const L = T0.apply(this, arguments); const add = (name, description, fn) => { if (!L.some(x => x.name === name)) L.push({ name, description, inputSchema: { type: 'object', properties: { days: { type: 'number' } } }, execute: async a => { try { return fn(a || {}); } catch (e) { return { error: String(e.message || e) }; } } }); };
      add('malik_minute', 'Owner ka 1-minute summary: aaj ki bikri, galle ka cash, shuddh sona (fine gold net), field mein maal, approval, udhaar, alerts, jokhim wale staff, karigar gadbad, purana stock.', () => { const m = minute(); return { salesToday: Math.round(m.sales), bills: m.bills, expectedCash: m.cash, fineGoldNet_g: r3(m.f.net), fineGoldValue: m.f.value, fieldMaal: Math.round(m.bagV), challansOut: m.out, approvalValue: Math.round(m.apV), receivable: Math.round(m.recv), alerts2d: m.al.length, highAlerts: m.alHigh, riskyStaff: m.rk.map(x => ({ who: x.who, score: x.score, why: x.why })), karigarIssues: m.kr.map(x => x.name), oldStockValue: Math.round(m.ag.oldVal), screen: 'Smart → Malik ka 1 minute' }; });
      add('fine_gold_position', 'Sone ka kul hisaab: vault, approval, karigar, metal khata — net shuddh sona aur bhaav badalne par fayda/nuksaan.', () => { const f = fine(); return { ...Object.fromEntries(Object.entries(f).map(([k, v]) => [k, typeof v === 'number' ? Math.round(v * 1000) / 1000 : v])), screen: 'Smart → Sone ka hisaab' }; });
      add('old_stock', 'Purana stock (90+ din): count, value, oldest pieces with advice.', () => { const a = aging(); return { buckets: a.b.map(x => ({ range: x.l, pcs: x.n, value: Math.round(x.v) })), old90: a.old.slice(0, 30).map(x => ({ sku: x.p.sku, item: `${x.p.category || ''} ${x.p.purity || ''}`, ageDays: x.age, value: Math.round(x.val), advice: advice(x.age) })), screen: 'Smart → Purana stock' }; });
      add('staff_risk', 'Gadbad AI: har login ka jokhim score (bill edit, delete, discount, raat ki entry, haath se weight, lock todna). days default 30.', a => risk(num(a.days) || 30).map(x => ({ who: x.who, score: x.score, bills: x.bills, edits: x.edits, deletes: x.dels, avgDiscountPct: x.avgDisc, night: x.night, why: x.why })));
      add('weight_spy', 'Weight ka jaasoos: piece jinka wazan ghata (stock edit, bikri, approval wapsi, challan wapsi).', () => weightSpy(90).slice(0, 40).map(x => ({ what: x.kind, ref: x.ref, diff_g: Math.round(x.d * 1000) / 1000, who: x.who })));
      add('karigar_ghatt', 'Karigar: chal rahe kaam, unke paas fine, asli ghatt % vs tay wastage, baaki fine, der.', () => karigar().map(x => ({ karigar: x.name, open: x.open, openFine: r3(x.openFine), realGhattPct: x.real == null ? null : Math.round(x.real * 100) / 100, allowedPct: x.allowAvg == null ? null : Math.round(x.allowAvg * 100) / 100, overLimit: x.bad, oweFine: r3(x.owe), late: x.late })));
      add('reorder_season', 'Reorder list (30 din bikri vs stock) aur season bhavishyavani (pichhle saal agle 60 din).', () => ({ reorder: reorder().slice(0, 25), season: season() }));
      add('making_supplier', 'Making charge sujhav (design-wise median %) aur supplier tulna (sabse sasta, tunch kam).', () => ({ making: making(180).slice(0, 25).map(x => ({ design: x.cat + ' ' + x.pur, bills: x.n, medianPct: Math.round(x.med * 10) / 10, range: [Math.round(x.lo * 10) / 10, Math.round(x.hi * 10) / 10] })), suppliers: suppliers(365).slice(0, 15).map(x => ({ name: x.name, bills: x.bills, net_g: r3(x.net), costOverPurePct: x.costMed == null ? null : Math.round(x.costMed * 10) / 10, tunchShortPts: x.shortMed })) }));
      add('staff_incentive', 'Is mahine ka staff incentive (counter + field bikri).', () => incentive(monthKey(todayStr())).rows);
      return L;
    };
    if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { return R0.apply(this, arguments) + '\nSMART: malik_minute for "aaj kya dekhna hai / summary"; fine_gold_position for sone ka hisaab; old_stock; staff_risk for chori / gadbad; weight_spy; karigar_ghatt; reorder_season for "kya banwaun"; making_supplier; staff_incentive. Screens are under Smart (🧠).'; }; }
  }
  window.SJ_SMART = { fine, aging, risk, weightSpy, karigar, reorder, season, making, suppliers, incentive, minute };

  const st = document.createElement('style');
  st.textContent = `.sm-tabs{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:thin}.sm-tabs button{white-space:nowrap}
    .sm-hero{display:flex;align-items:center;justify-content:space-between;margin:0 0 12px}.sm-hero h2{margin:2px 0 4px;font-family:var(--serif,Georgia,serif);color:var(--gold)}
    .sm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,170px),1fr));gap:10px;margin-bottom:14px}
    .sm-tile{border:1px solid var(--line);background:var(--card);border-radius:16px;padding:12px 14px;display:flex;flex-direction:column;gap:2px;min-width:0}.sm-tile span,.sm-tile small{font-size:12px;color:var(--muted)}.sm-tile b{font-size:19px;overflow-wrap:anywhere}
    .sm-tile.gold{border-color:var(--gold-line,rgba(212,175,55,.5))}.sm-tile.gold b{color:var(--gold)}.sm-tile.red{border-color:rgba(239,68,68,.55)}.sm-tile.red b{color:#ef4444}.sm-tile.green b{color:#22c55e}
    .sm-todo{display:flex;flex-direction:column;gap:6px}.sm-td{display:flex;justify-content:space-between;align-items:center;gap:10px;text-align:left;border:1px solid var(--line);border-left:4px solid var(--line);background:transparent;color:var(--ink);border-radius:12px;padding:10px 12px;font:inherit;font-size:13.5px;cursor:pointer}.sm-td.red{border-left-color:#ef4444}.sm-td.amber{border-left-color:#f59e0b}.sm-td span{color:var(--muted);font-size:18px}
    .sm-bars{display:flex;flex-direction:column;gap:8px}.sm-bar{display:grid;grid-template-columns:90px 1fr auto;gap:4px 10px;align-items:center;font-size:13px}.sm-bar>div{height:12px;border-radius:8px;background:var(--line);overflow:hidden}.sm-bar i{display:block;height:100%;border-radius:8px;background:var(--gold)}.sm-bar i.b3{background:#f59e0b}.sm-bar i.b4{background:#ef4444}.sm-bar small{grid-column:2/4;color:var(--muted);font-size:11.5px}
    tr.sm-bad td{background:rgba(239,68,68,.06)}
    .sm-dash{display:flex;align-items:center;justify-content:space-between;gap:12px;cursor:pointer;padding:14px 16px;border-color:var(--gold-line,rgba(212,175,55,.5))}.sm-dash>div{display:flex;flex-direction:column;gap:2px;min-width:0}.sm-dash span:not(.pill){font-size:12.5px;color:var(--muted)}`;
  document.head.appendChild(st);
})();
