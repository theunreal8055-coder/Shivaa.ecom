/* =====================================================================
   Shivaa Jewels — SHAADI PACKAGE v2 (v29)
   One place for a whole wedding order:
   • parivaar, shaadi / delivery dates, budget, making %, GST
   • every gehna — sona ya chandi, purity, qty, wazan range, photos (camera / gallery / Vault),
     customisation (size, lambai, nag, meena, finish, naam, peech, aur), extra charge, karigar, due date,
     status, asli wazan + HUID
   • advance: cash / UPI / bank, ya purana sona-chandi (fine credit)
   • bhav cutting: advance ke saath fine wazan ka bhav lock (sona / chandi alag), bachat live
   • hisaab: aaj ke bhav vs kate bhav, GST, advance, baaki
   • seedha bill: chune gehne + kata bhav + purana sona + advance apne-aap
   • premium package PDF (photos ke saath), advance / bhav cutting rasid, WhatsApp
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { name: 'Owner', role: 'owner' };
  const role = () => me().role || 'owner';
  const canAdmin = () => !SITE || ['owner', 'manager'].includes(role());
  const canEdit = () => role() !== 'viewer';
  const q$ = (s, r) => (r || document).querySelector(s);
  const F = (label, inner, cls) => `<label class="f${cls ? ' ' + cls : ''}"><span>${label}</span>${inner}</label>`;
  const inp = (name, v, o = {}) => `<input name="${name}"${o.type ? ` type="${o.type}"` : ''}${o.step ? ` step="${o.step}"` : ''}${o.min != null ? ` min="${o.min}"` : ''}${o.max != null ? ` max="${o.max}"` : ''}${o.ph ? ` placeholder="${esc(o.ph)}"` : ''}${o.im ? ` inputmode="${o.im}"` : ''}${o.list ? ` list="${o.list}"` : ''}${o.req ? ' required' : ''} value="${esc(v == null ? '' : v)}">`;
  const sel = (name, list, v) => `<select name="${name}">${opts(list, v)}</select>`;
  const tabs = (k, arr, def) => `<div class="rep-tabs">${arr.map(([v, l]) => `<button type="button" data-act="seg" data-k="${k}" data-v="${v}" class="${(ui[k] || def || arr[0][0]) === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  const kpis = arr => `<div class="kpis">${arr.map(([l, v, s]) => kpi(esc(l), v, s || '')).join('')}</div>`;
  const formVals = f => { const o = {}; [...f.elements].forEach(e => { if (!e.name) return; if (e.type === 'checkbox') o[e.name] = e.checked; else if (e.type === 'radio') { if (e.checked) o[e.name] = e.value; } else o[e.name] = e.value; }); return o; };
  const ph10 = p => String(p || '').replace(/\D/g, '').slice(-10);
  const waUrl = (ph, msg) => { const d = ph10(ph); return d.length === 10 ? `https://wa.me/91${d}${msg ? '?text=' + encodeURIComponent(msg) : ''}` : ''; };
  const nextNo = (col, pre) => { let mx = 0; (S[col] || []).forEach(x => { if (x.no && x.no.startsWith(pre)) mx = Math.max(mx, parseInt(x.no.slice(pre.length)) || 0); }); return pre + String(mx + 1).padStart(4, '0'); };
  const firm = () => settings().firm || 'Shivaa Jewels';
  const pro = () => (settings().pro || {});
  const css = document.createElement('style'); document.head.appendChild(css); const addCss = t => { css.textContent += t; };
  if (typeof COLS !== 'undefined' && !COLS.includes('weddings')) COLS.push('weddings'); if (!S.weddings) S.weddings = [];
  const ACT = {}, SUBMIT = {};
  document.addEventListener('click', async e => { const t = e.target.closest && e.target.closest('[data-act]'); if (!t) return; const h = ACT[t.dataset.act]; if (!h) return; e.preventDefault(); e.stopPropagation(); if (t.disabled) return; try { await h(t, e); } catch (err) { console.error(err); toast(err && err.message ? err.message : 'Kuch galat hua', 'err'); } }, true);
  document.addEventListener('submit', async e => { const f = e.target; const k = f && f.dataset && f.dataset.sjw; if (!k || !SUBMIT[k]) return; e.preventDefault(); e.stopPropagation(); const b = f.querySelector('button.primary'); if (b) b.disabled = true; try { await SUBMIT[k](f); } catch (err) { console.error(err); toast(err.message || 'Save nahi hua', 'err'); } finally { if (b) b.disabled = false; } }, true);

  /* ---------------- metal, purity, rates ---------------- */
  const PUR = { gold: [['22K', '22K (916)'], ['18K', '18K (750)'], ['24K', '24K (999)'], ['20K', '20K (833)'], ['14K', '14K (585)']], silver: [['92.5', '92.5 Sterling'], ['80', '80 Chandi'], ['70', '70 Chandi'], ['999', '999 Fine']] };
  const TUNCH = { '24K': 99.9, '22K': 91.6, '20K': 83.3, '18K': 75, '14K': 58.5, '999': 99.9, '92.5': 92.5, '80': 80, '70': 70 };
  const tunchOf = p => TUNCH[String(p)] || (parseFloat(p) > 0 && parseFloat(p) <= 100 ? parseFloat(p) : 91.6);
  const metalOf = it => it.metal === 'silver' || (!it.metal && /^(92\.5|80|70|999)$/.test(String(it.purity))) ? 'silver' : 'gold';
  const todayG = m => m === 'silver' ? num(settings().silver999) / 1000 : num(settings().gold24) / 10;   // ₹ per fine gram
  const showRate = m => m === 'silver' ? num(settings().silver999) : num(settings().gold24);              // as people say it
  const rateUnit = m => m === 'silver' ? '/kg' : '/10g';
  const toG = (m, r) => m === 'silver' ? num(r) / 1000 : num(r) / 10;
  const MN = m => m === 'silver' ? 'Chandi' : 'Sona';
  const ST = [['pending', 'Baaki'], ['ordered', 'Order diya'], ['making', 'Karigar ke paas'], ['ready', 'Taiyaar'], ['delivered', 'De diya']];
  const stName = s => (ST.find(x => x[0] === (s || 'pending')) || ST[0])[1];
  const FINISH = { gold: ['', 'Yellow (seedha)', 'Antique', 'Rose gold', 'Rhodium / white', 'Matte', 'Dual tone', 'Kundan / Polki', 'Meenakari'], silver: ['', 'Chamakdar (high polish)', 'Oxidised', 'Antique', 'Rhodium', 'Matte', 'Gold polish'] };
  const TEMPLATE = { gold: ['Rani haar / Necklace set', 'Mangalsutra', 'Choker / Gale ka set', 'Jhumka / Earrings', 'Nath', 'Maang tikka', 'Kangan / Chudi (jodi)', 'Bajuband', 'Anguthi (dulhan)', 'Anguthi (dulha)', 'Chain (dulha)', 'Kada (dulha)', 'Sagai ki anguthi (jodi)', 'Haath phool'], silver: ['Payal (jodi)', 'Bichhiya (set)', 'Kamarbandh', 'Chandi ke bartan / thali set', 'Chandi ka sikka (shagun)', 'Gucchha / Chabi chhalla', 'Pooja set'] };
  const UNIT = n => /jodi|jhumka|earring|payal|kangan|chudi|kada|bajuband|bichhiya/i.test(n) ? 'Pairs' : /set/i.test(n) ? 'Sets' : 'Pcs';

  /* ---------------- the numbers ---------------- */
  const pkgMk = w => w.makingPct === '' || w.makingPct == null ? num(pro().shaadiMaking || 12) : num(w.makingPct);
  const itMk = (w, it) => it.makingPct === '' || it.makingPct == null ? pkgMk(w) : num(it.makingPct);
  function itNet(it) { const a = num(it.actualGross); if (a > 0) return r3(Math.max(0, a - num(it.actualLess))); const lo = num(it.wMin), hi = num(it.wMax) || lo; return r3((lo + hi) / 2 * (num(it.qty) || 1)); }
  function itRange(it) { const q = num(it.qty) || 1; if (num(it.actualGross) > 0) { const n = itNet(it); return [n, n]; } const lo = num(it.wMin) || num(it.wMax), hi = num(it.wMax) || lo; return [r3(lo * q), r3(hi * q)]; }
  function itFine(w, it) { return r3(itNet(it) * (tunchOf(it.purity) + itMk(w, it)) / 100); }       // fine needed incl. making (wastage)
  function itCharges(it) { return r2(num(it.extra) + num(it.stone)); }
  function itLabour(it) { return r2(itNet(it) * num(it.labour)); }
  const cashAdv = w => (w.advances || []).filter(a => a.type !== 'metal');
  const metalAdv = w => (w.advances || []).filter(a => a.type === 'metal');
  const advCash = w => r2(sum(cashAdv(w), a => a.amount));
  const advUsed = w => r2(sum(w.used || [], u => u.amount));
  const advFree = w => r2(advCash(w) - advUsed(w));
  function locks(w, m) { const L = cashAdv(w).filter(a => a.lock && a.lock.metal === m && num(a.lock.fine) > 0); const fine = r3(sum(L, a => a.lock.fine)); const val = r2(sum(L, a => num(a.lock.fine) * toG(m, a.lock.rate))); const used = r3(sum(w.billed || [], b => num((b.lock || {})[m]))); return { L, fine, used, free: r3(Math.max(0, fine - used)), rateG: fine ? val / fine : 0 }; }
  function metalCredit(w, m, onlyFree) { return r3(sum(metalAdv(w).filter(a => a.metal && a.metal.metal === m && (!onlyFree || !a.usedIn)), a => a.metal.fine)); }
  function calc(w) {
    const out = { gold: {}, silver: {} }; let charges = 0, labour = 0;
    ['gold', 'silver'].forEach(m => {
      const its = (w.items || []).filter(it => metalOf(it) === m && !it.billed); const need = r3(sum(its, it => itFine(w, it))); const lk = locks(w, m);
      const lf = Math.min(lk.free, need); const today = r2(need * todayG(m)); const withLock = r2(lf * lk.rateG + (need - lf) * todayG(m));
      out[m] = { items: its.length, net: r3(sum(its, itNet)), range: [r3(sum(its, it => itRange(it)[0])), r3(sum(its, it => itRange(it)[1]))], need, today, withLock, lockFine: lk.fine, lockFree: lk.free, lockRateG: lk.rateG, lockApplied: r3(lf), saving: r2(today - withLock), credit: metalCredit(w, m, true), creditVal: r2(metalCredit(w, m, true) * todayG(m)) };
      charges += sum(its, itCharges); labour += sum(its, itLabour);
    });
    const gst = num(w.gstPct === '' || w.gstPct == null ? 3 : w.gstPct);
    const sub = r2(out.gold.withLock + out.silver.withLock + charges + labour), subToday = r2(out.gold.today + out.silver.today + charges + labour);
    const total = r2(sub * (1 + gst / 100)), totalToday = r2(subToday * (1 + gst / 100));
    const credit = r2(out.gold.creditVal + out.silver.creditVal);
    return { ...out, charges: r2(charges), labour: r2(labour), gst, sub, subToday, total, totalToday, saving: r2(totalToday - total), cash: advCash(w), cashFree: advFree(w), credit, balance: r2(total - advFree(w) - credit) };
  }
  const wDays = w => w.eventDate ? daysBetween(todayStr(), w.eventDate) : null;
  const custOf = w => w.customerId ? custById(w.customerId) : null;
  const itemsDone = w => (w.items || []).filter(i => i.status === 'delivered').length;
  const photosOf = it => { const L = (it.photos || []).map(p => p.src).filter(Boolean); if (it.productId) { const p = S.products.find(x => x.id === it.productId); if (p && p.photo) L.unshift(p.photo); } return L; };
  const customTxt = it => { const c = it.custom || {}; return [c.size && 'Size ' + c.size, c.length && 'Lambai ' + c.length, c.stone && 'Nag: ' + c.stone, c.meena && 'Meena/rang: ' + c.meena, c.finish && c.finish, c.engraving && 'Naam: "' + c.engraving + '"', c.back && 'Peech/hook: ' + c.back, c.other].filter(Boolean); };
  function blank(o) { return { id: uid('wi'), name: '', metal: 'gold', purity: '22K', qty: 1, unit: 'Pcs', wMin: '', wMax: '', makingPct: '', labour: '', stone: '', extra: '', photos: [], productId: '', custom: {}, status: 'pending', karigar: '', due: '', actualGross: '', actualLess: '', huid: '', note: '', ...o }; }
  function norm(w) {   // packages saved by v28 have no item ids / metal
    let ch = false; const items = (w.items || []).map(it => { if (it.id && it.metal) return it; ch = true; return blank({ ...it, id: it.id || uid('wi'), metal: metalOf(it), unit: it.unit || UNIT(it.name || '') }); });
    const adv = (w.advances || []).map(a => { if (a.type) return a; ch = true; return { ...a, type: 'cash' }; });
    return ch ? { ...w, items, advances: adv } : w;
  }
  const getW = id => { const w = S.weddings.find(x => x.id === id); return w ? norm(w) : null; };
  const saveW = async (w, quiet) => save('weddings', { ...w, updatedAt: Date.now() }, quiet ? { quiet: true } : undefined);
  async function moneyIn(date, amount, mode, party, notes, ref) {
    if (!(num(amount) > 0)) return '';
    const cash = !mode || mode === 'Cash'; const bank = cash ? '' : ((banksList().find(b => b.primary) || banksList()[0]) || {}).id;
    if (!cash && !bank) throw new Error('UPI / bank — pehle Setup mein bank account jodiye (ya Cash chuniye)');
    const x = { id: uid('bt'), kind: cash ? 'cashin' : 'receipt', date, amount: r2(num(amount)), bankId: bank || '', toBankId: '', source: 'Advance from customer', purpose: '', party: party || '', ref: ref || '', notes: notes || '', createdAt: Date.now(), updatedAt: Date.now() };
    if (!await save('banktx', x, { quiet: true })) throw new Error('Paisa ki entry save nahi hui'); return x.id;
  }
  function compress(file, max, q) { return new Promise((res, rej) => { const fr = new FileReader(); fr.onerror = () => rej(new Error('Photo nahi padhi')); fr.onload = () => { const im = new Image(); im.onerror = () => rej(new Error('Photo nahi khuli')); im.onload = () => { const k = Math.min(1, max / Math.max(im.width, im.height)); const c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k); const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height); res(c.toDataURL('image/jpeg', q)); }; im.src = fr.result; }; fr.readAsDataURL(file); }); }

  /* =====================================================================
     LIST + DETAIL VIEW
     ===================================================================== */
  if (!ui.wdTab) ui.wdTab = 'active';
  VIEWDEF.shaadi = {
    shell() {
      if (ui.wdOpen && getW(ui.wdOpen)) return `<div class="toolbar"><button class="btn" data-act="wd-back">← Saare package</button></div><div id="vbody"></div>`;
      return tabs('wdTab', [['active', '💍 Chalu'], ['done', '✅ Poore'], ['all', 'Sab']]) + `<div class="toolbar">${canEdit() ? `<button class="btn primary" data-act="wd-new">${ic('plus', 16)} Naya shaadi package</button>` : ''}<input type="search" data-ui="wdQ" value="${esc(ui.wdQ || '')}" placeholder="Naam / phone / SH no. khojo" aria-label="Khojo"></div><div id="vbody"></div>`;
    },
    body() { const w = ui.wdOpen && getW(ui.wdOpen); return w ? detail(w) : list(); }
  };
  ACT['wd-back'] = () => { ui.wdOpen = ''; renderView(true); };
  ACT['wd-open'] = t => { ui.wdOpen = t.dataset.id; ui.wdSec = ui.wdSec || 'gehne'; renderView(true); window.scrollTo(0, 0); };
  function list() {
    const t = ui.wdTab || 'active', q = String(ui.wdQ || '').toLowerCase().trim();
    let L = S.weddings.map(norm).filter(w => !q || [w.name, w.phone, w.no, w.bride, w.groom, w.city].some(x => String(x || '').toLowerCase().includes(q)));
    if (t === 'active') L = L.filter(w => w.status !== 'done' && w.status !== 'cancelled'); else if (t === 'done') L = L.filter(w => w.status === 'done');
    L.sort((a, b) => String(a.eventDate || '9').localeCompare(String(b.eventDate || '9')));
    const act = S.weddings.map(norm).filter(w => w.status !== 'done' && w.status !== 'cancelled');
    const head = kpis([['Chalu package', act.length], ['30 din mein shaadi', act.filter(w => { const d = wDays(w); return d != null && d >= 0 && d <= 30; }).length], ['Advance (bacha)', inr(sum(act, advFree))], ['Kata bhav (sona)', g3(sum(act, w => locks(w, 'gold').free))], ['Gehne baaki', sum(act, w => (w.items || []).filter(i => i.status !== 'delivered').length)]]);
    if (!L.length) return head + emptyBox(t === 'done' ? 'Abhi koi package poora nahi hua.' : 'Koi shaadi package nahi. "Naya shaadi package" se poori list, photo, customisation, advance aur bhav cutting ek jagah rakhiye.');
    return head + `<div class="grid-cards wd-list">${L.map(w => { const d = wDays(w), c = calc(w), it = w.items || [], ph = it.flatMap(photosOf).slice(0, 6), gl = locks(w, 'gold'), sl = locks(w, 'silver');
      return `<div class="card wd-card" data-act="wd-open" data-id="${w.id}" role="button" tabindex="0"><div class="wd-ch"><div><b>${esc(w.name)}</b> <span class="pill">${esc(w.no)}</span>${w.status === 'done' ? ' <span class="pill green">Poora</span>' : d != null ? ` <span class="pill ${d < 0 ? 'red' : d <= 15 ? 'overdue' : ''}">${d < 0 ? 'Shaadi ho gayi' : d === 0 ? 'Aaj shaadi!' : d + ' din'}</span>` : ''}<div class="small muted">${w.eventDate ? fmtD(w.eventDate) + ' · ' : ''}${esc([w.bride && 'Dulhan ' + w.bride, w.groom && 'Dulha ' + w.groom].filter(Boolean).join(' · '))}</div></div></div>
        ${ph.length ? `<div class="wd-strip">${ph.map(s => `<img src="${esc(s)}" alt="" loading="lazy">`).join('')}</div>` : ''}
        <div class="wd-st"><div><span>Gehne</span><b>${itemsDone(w)}/${it.length}</b><small>de diye</small></div><div><span>Andaaza bill</span><b>${inr(c.total)}</b><small class="${num(w.budget) && c.total > num(w.budget) ? 'red' : 'muted'}">${num(w.budget) ? 'budget ' + inr(w.budget) : 'GST ke saath'}</small></div><div><span>Advance</span><b>${inr(c.cash)}</b><small>${c.credit ? '+ purana ' + inr(c.credit) : 'jama'}</small></div><div><span>Kata bhav</span><b>${gl.fine ? g3(gl.fine) : sl.fine ? g3(sl.fine) : '—'}</b><small>${gl.fine ? 'sona' : sl.fine ? 'chandi' : 'nahi'}${c.saving > 0.5 ? ' · bachat ' + inr(c.saving) : ''}</small></div></div></div>`; }).join('')}</div>`;
  }
  function detail(w) {
    const c = calc(w), d = wDays(w), cu = custOf(w), sec = ui.wdSec || 'gehne';
    const head = `<div class="card wd-head"><div class="wd-ch"><div><h2 style="margin:0">${esc(w.name)} <span class="pill">${esc(w.no)}</span>${w.status === 'done' ? ' <span class="pill green">Poora</span>' : ''}</h2><div class="small muted">${esc([w.phone, w.city].filter(Boolean).join(' · '))}${w.bride || w.groom ? ' · ' + esc([w.bride && 'Dulhan ' + w.bride, w.groom && 'Dulha ' + w.groom].filter(Boolean).join(' · ')) : ''}</div>${cu && cu.sizes && Object.keys(cu.sizes).length > 1 ? `<div class="small">📏 ${esc(Object.entries(cu.sizes).filter(([k]) => !['updatedAt', 'note'].includes(k)).map(([k, v]) => ({ ring: 'Anguthi', ring2: 'Doosri', bangle: 'Kangan', bracelet: 'Bracelet', chain: 'Chain', waist: 'Kamar', toe: 'Bichhiya' }[k] || k) + ' ' + v).join(' · '))}</div>` : ''}</div>
      <div class="wd-date">${w.eventDate ? `<b>${parseD(w.eventDate).getDate()}</b><span>${parseD(w.eventDate).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' })}</span><i>${d < 0 ? 'ho gayi' : d === 0 ? 'AAJ' : d + ' din'}</i>` : '<span>Tareekh tay nahi</span>'}</div></div>
      <div class="btns" style="margin-top:10px">${canEdit() && w.status !== 'done' ? `<button class="btn sm" data-act="wd-edit" data-id="${w.id}">${ic('edit', 14)} Package badlo</button>` : ''}<button class="btn sm gold" data-act="wd-pdf" data-id="${w.id}">${ic('dl', 14)} Package PDF</button>${w.phone ? `<button class="btn sm green" data-act="wd-wa" data-id="${w.id}">WhatsApp</button>` : ''}${canEdit() && w.status !== 'done' && (w.items || []).length && itemsDone(w) === w.items.length ? `<button class="btn sm" data-act="wd-done" data-id="${w.id}">✓ Package poora</button>` : ''}${canAdmin() ? `<button class="btn sm danger" data-act="wd-del" data-id="${w.id}">Delete</button>` : ''}</div></div>`;
    const k = kpis([['Andaaza bill (GST ke saath)', inr(c.total), c.saving > 0.5 ? `aaj ke bhav se ${inr(c.totalToday)} · bachat ${inr(c.saving)}` : 'aaj ke bhav se'], ['Advance (bacha)', inr(c.cashFree), c.credit ? `+ purana sona/chandi ${inr(c.credit)}` : `kul jama ${inr(c.cash)}`], ['Baaki (andaaza)', `<span class="${c.balance > 0 ? '' : 'green'}">${inr(Math.max(0, c.balance))}</span>`, c.balance < 0 ? 'advance zyada: ' + inr(-c.balance) : ''], ['Kata bhav', c.gold.lockFine || c.silver.lockFine ? `${c.gold.lockFine ? g3(c.gold.lockFine) + ' sona' : ''}${c.gold.lockFine && c.silver.lockFine ? ' · ' : ''}${c.silver.lockFine ? g3(c.silver.lockFine) + ' chandi' : ''}` : '—', c.gold.lockFine ? `₹${fmtAmt(c.gold.lockRateG * 10)}/10g · bacha ${g3(c.gold.lockFree)}` : c.silver.lockFine ? `bacha ${g3(c.silver.lockFree)}` : '']]);
    const tb = tabs('wdSec', [['gehne', `💍 Gehne (${(w.items || []).length})`], ['advance', `💰 Advance & bhav (${(w.advances || []).length})`], ['hisaab', '🧮 Hisaab'], ['bill', `🧾 Bill${(w.billed || []).length ? ' (' + w.billed.length + ')' : ''}`]], 'gehne');
    return head + k + tb + (sec === 'advance' ? advSec(w, c) : sec === 'hisaab' ? hisaabSec(w, c) : sec === 'bill' ? billSec(w) : itemsSec(w));
  }

  /* ---------------- items section ---------------- */
  function itemsSec(w) {
    const it = w.items || [];
    const top = `<div class="toolbar">${canEdit() && w.status !== 'done' ? `<button class="btn primary sm" data-act="wd-item" data-id="${w.id}">${ic('plus', 14)} Gehna jodo</button><button class="btn sm" data-act="wd-tpl" data-id="${w.id}">📋 List se chuno</button>${it.some(i => i.status === 'pending') ? `<button class="btn sm" data-act="wd-est" data-id="${w.id}">Order estimate (baaki gehne)</button>` : ''}` : ''}</div>`;
    if (!it.length) return top + emptyBox('Abhi koi gehna nahi. "List se chuno" se dulhan / dulha ke aam gehne ek saath jodiye.');
    const grp = m => it.filter(i => metalOf(i) === m);
    return top + ['gold', 'silver'].filter(m => grp(m).length).map(m => `<h3 class="wd-mh">${m === 'gold' ? '🟡 Sona' : '⚪ Chandi'} <span class="small muted">${grp(m).length} gehne · ${(() => { const r = [sum(grp(m), i => itRange(i)[0]), sum(grp(m), i => itRange(i)[1])]; return r[0] === r[1] ? g3(r[0]) : g3(r[0]) + ' – ' + g3(r[1]); })()}</span></h3><div class="wd-items">${grp(m).map(i => itemCard(w, i)).join('')}</div>`).join('');
  }
  function itemCard(w, i) {
    const ph = photosOf(i), cz = customTxt(i), rg = itRange(i), late = i.due && i.due < todayStr() && !['ready', 'delivered'].includes(i.status);
    return `<div class="card wd-it st-${i.status || 'pending'}"><div class="wd-it-ph">${ph.length ? `<img src="${esc(ph[0])}" alt="">${ph.length > 1 ? `<span>+${ph.length - 1}</span>` : ''}` : `<div class="wd-noph">${esc((i.name || 'G')[0].toUpperCase())}</div>`}</div>
      <div class="wd-it-b"><div class="wd-ch"><div><b>${esc(i.name)}</b>${num(i.qty) > 1 ? ` <span class="small">×${num(i.qty)} ${esc(i.unit || '')}</span>` : ''}<div class="small muted">${MN(metalOf(i))} ${esc(i.purity)} · ${num(i.actualGross) ? '<b>asli ' + g3(itNet(i)) + '</b>' : rg[0] === rg[1] ? g3(rg[0]) : g3(rg[0]) + ' – ' + g3(rg[1])}${num(itMk(w, i)) ? ' · making ' + itMk(w, i) + '%' : ''}${itCharges(i) ? ' · extra ' + inr(itCharges(i)) : ''}${i.huid ? ' · HUID ' + esc(i.huid) : ''}</div></div>${i.billed ? '<span class="pill green">Bill ho gaya</span>' : `<select class="wd-stsel" data-wid="${w.id}" data-iid="${i.id}" ${canEdit() ? '' : 'disabled'}>${opts(ST, i.status || 'pending')}</select>`}</div>
      ${cz.length ? `<div class="wd-cz">${cz.map(x => `<span>${esc(x)}</span>`).join('')}</div>` : ''}${i.note ? `<div class="small">${esc(i.note)}</div>` : ''}
      <div class="small muted">${[i.karigar && '🛠 ' + esc(i.karigar), i.due && `<span class="${late ? 'red' : ''}">📅 ${fmtD(i.due)}${late ? ' (der)' : ''}</span>`].filter(Boolean).join(' · ')}</div>
      ${canEdit() && !i.billed ? `<div class="btns"><button class="btn sm" data-act="wd-item" data-id="${w.id}" data-iid="${i.id}">${ic('edit', 13)} Badlo</button><label class="btn sm" style="cursor:pointer">📷 Photo<input type="file" accept="image/*" multiple class="wd-ph-in" data-wid="${w.id}" data-iid="${i.id}" hidden></label></div>` : ''}</div></div>`;
  }
  document.addEventListener('change', async e => {
    const s = e.target;
    if (s.classList && s.classList.contains('wd-stsel')) { const w = getW(s.dataset.wid); const items = w.items.map(i => i.id === s.dataset.iid ? { ...i, status: s.value, ...(s.value === 'delivered' ? { deliveredOn: todayStr() } : {}) } : i); await saveW({ ...w, items }, true); toast('Status: ' + stName(s.value)); if (s.value === 'ready' && w.phone) { const it = items.find(i => i.id === s.dataset.iid); const u = waUrl(w.phone, `Namaste ${w.name} ji 🙏\n${firm()} — aapka *${it.name}* taiyaar hai! 💍\nAap kab dekhne aa sakte hain?`); if (u) { const el = openModal(`${mHead('✓ ' + esc(it.name) + ' taiyaar', 'Customer ko bataiye')}<div class="m-body"><p>${esc(w.name)} ko WhatsApp par bata dein?</p></div><div class="m-foot"><button class="btn" data-act="close">Baad mein</button><a class="btn green primary" target="_blank" rel="noopener" href="${esc(u)}">WhatsApp</a></div>`, { small: true }); } } return; }
    if (s.classList && s.classList.contains('wd-ph-in') && s.files && s.files.length) { e.stopPropagation(); await addPhotos(s.dataset.wid, s.dataset.iid, [...s.files]); s.value = ''; }
  }, true);
  async function addPhotos(wid, iid, files) {
    const w = getW(wid); const it = w.items.find(i => i.id === iid); const have = (it.photos || []).length; const room = Math.max(0, 4 - have); if (!room) return toast('Ek gehne par 4 photo tak', 'err');
    toast('Photo jud rahi hai…'); const add = []; for (const f of files.slice(0, room)) { if (!/^image\//.test(f.type)) continue; add.push({ src: await compress(f, 1000, 0.78), at: Date.now() }); }
    const items = w.items.map(i => i.id === iid ? { ...i, photos: [...(i.photos || []), ...add] } : i); const size = JSON.stringify({ ...w, items }).length;
    if (size > 6e6) return toast('Package mein photo bahut zyada (6 MB+) — purani photo hatayiye', 'err');
    if (await saveW({ ...w, items }, true)) toast('✓ ' + add.length + ' photo judi');
  }

  /* ---------------- item form ---------------- */
  ACT['wd-item'] = t => itemForm(t.dataset.id, t.dataset.iid || '');
  function itemForm(wid, iid) {
    const w = getW(wid); const i = iid ? w.items.find(x => x.id === iid) : blank(); const m = metalOf(i); const c = i.custom || {}; const cu = custOf(w);
    const kar = [...new Set([...(S.karigars || []).map(k => k.name), ...(S.weddings || []).flatMap(x => (x.items || []).map(y => y.karigar))].filter(Boolean))];
    const vault = S.products.filter(p => p.status === 'In Stock').slice(0, 400).map(p => [p.id, `${p.sku} · ${p.category || ''} ${p.purity || ''} · ${num(p.net || p.gross).toFixed(2)}g${p.photo ? ' · 📷' : ''}`]);
    openModal(`<form data-sjw="item" data-wid="${esc(wid)}" data-iid="${esc(iid)}" novalidate>${mHead(iid ? 'Gehna badlo' : 'Naya gehna', esc(w.name) + ' · ' + esc(w.no))}<div class="m-body">
      <div class="fg">${F('Gehna *', inp('name', i.name, { list: 'wd-names', req: 1, ph: 'jaise Rani haar' }))}${F('Dhatu', `<select name="metal" class="wd-metal">${opts([['gold', 'Sona'], ['silver', 'Chandi']], m)}</select>`)}${F('Purity', `<select name="purity" class="wd-pur">${opts(PUR[m], i.purity)}</select>`)}${F('Qty', inp('qty', i.qty || 1, { type: 'number', min: 1, step: '1' }))}${F('Unit', sel('unit', [['Pcs', 'Pcs'], ['Pairs', 'Jodi'], ['Sets', 'Set']], i.unit || 'Pcs'))}${F('Wazan se (g, ek piece)', inp('wMin', i.wMin, { type: 'number', step: '0.001', min: 0, im: 'decimal' }))}${F('tak (g)', inp('wMax', i.wMax, { type: 'number', step: '0.001', min: 0, im: 'decimal' }))}</div>
      <datalist id="wd-names">${[...TEMPLATE.gold, ...TEMPLATE.silver].map(n => `<option value="${esc(n)}">`).join('')}</datalist><datalist id="wd-kar">${kar.map(n => `<option value="${esc(n)}">`).join('')}</datalist>
      <h4 class="wd-h4">✨ Customisation</h4>
      ${cu && cu.sizes ? `<div class="small muted" style="margin:-4px 0 6px">Saved size: ${esc(Object.entries(cu.sizes).filter(([k]) => !['updatedAt', 'note'].includes(k)).map(([k, v]) => k + ' ' + v).join(' · '))}</div>` : ''}
      <div class="fg">${F('Size', inp('c_size', c.size, { ph: 'anguthi 14 / kangan 2.6' }))}${F('Lambai', inp('c_length', c.length, { ph: 'chain 18 inch' }))}${F('Nag / stone', inp('c_stone', c.stone, { ph: 'ruby, emerald, CZ, polki…' }))}${F('Meena / rang', inp('c_meena', c.meena, { ph: 'laal-hara meena' }))}${F('Finish', `<select name="c_finish" class="wd-fin">${opts(FINISH[m].map(x => [x, x || '—']), c.finish || '')}</select>`)}${F('Naam / engraving', inp('c_engraving', c.engraving, { ph: 'R ❤ P' }))}${F('Peech / hook / back', inp('c_back', c.back, { ph: 'screw, hook, chain back…' }))}${F('Aur kuch', inp('c_other', c.other, { ph: 'design jaisa photo mein, halka…' }))}</div>
      <h4 class="wd-h4">💰 Making & charges <span class="small muted">— khaali chhodein to package ki making (${pkgMk(w)}%)</span></h4>
      <div class="fg">${F('Making / wastage %', inp('makingPct', i.makingPct, { type: 'number', step: '0.1', min: 0, ph: String(pkgMk(w)) }))}${F('Labour ₹/g', inp('labour', i.labour, { type: 'number', step: '1', min: 0 }))}${F('Stone / nag ₹', inp('stone', i.stone, { type: 'number', step: '1', min: 0 }))}${F('Customisation charge ₹', inp('extra', i.extra, { type: 'number', step: '1', min: 0 }))}</div>
      <h4 class="wd-h4">📷 Photo <span class="small muted">— design / reference (4 tak)</span></h4>
      <div class="wd-phs">${(i.photos || []).map((p, k) => `<div><img src="${esc(p.src)}" alt=""><button type="button" class="btn sm danger" data-act="wd-ph-del" data-k="${k}">✕</button></div>`).join('')}</div>
      <div class="fg">${F('Photo jodo (camera / gallery)', '<input type="file" name="photosIn" accept="image/*" multiple><span class="wd-phn small green"></span>')}${F('Ya Vault ka piece (stock se)', `<select name="productId">${opts(vault, i.productId || '', '— koi nahi —')}</select>`)}</div>
      <h4 class="wd-h4">🛠 Kaam</h4>
      <div class="fg">${F('Status', sel('status', ST, i.status || 'pending'))}${F('Karigar', inp('karigar', i.karigar, { list: 'wd-kar' }))}${F('Kab tak (karigar)', inp('due', i.due, { type: 'date' }))}${F('Asli gross wazan (g)', inp('actualGross', i.actualGross, { type: 'number', step: '0.001', min: 0, im: 'decimal' }))}${F('Less / nag wazan (g)', inp('actualLess', i.actualLess, { type: 'number', step: '0.001', min: 0, im: 'decimal' }))}${F('HUID', inp('huid', i.huid, { ph: '6 akshar' }))}${F('Note', inp('note', i.note))}</div>
      </div><div class="m-foot">${iid && canAdmin() && !i.billed ? `<button type="button" class="btn danger" data-act="wd-item-del" data-wid="${esc(wid)}" data-iid="${esc(iid)}">Hatao</button><span style="flex:1"></span>` : ''}<button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { wide: true });
  }
  document.addEventListener('change', e => { const s = e.target; if (!s.classList || !s.classList.contains('wd-metal')) return; const f = s.closest('form'); const m = s.value; f.elements.purity.innerHTML = opts(PUR[m], PUR[m][0][0]); f.elements.c_finish.innerHTML = opts(FINISH[m].map(x => [x, x || '—']), ''); });
  // the app's old global file handler empties every file input after "change" — keep our picks first
  document.addEventListener('change', e => { const i = e.target; if (!i.matches || !i.matches('form[data-sjw="item"] input[name="photosIn"]')) return; e.stopPropagation(); const f = i.closest('form'); f._files = [...(f._files || []), ...[...(i.files || [])]].slice(0, 4); const n = q$('.wd-phn', f); if (n) n.textContent = f._files.length ? f._files.length + ' nayi photo chuni' : ''; }, true);
  ACT['wd-ph-del'] = t => { const f = t.closest('form'); f._del = [...(f._del || []), +t.dataset.k]; t.closest('div').style.display = 'none'; };
  SUBMIT.item = async f => {
    const w = getW(f.dataset.wid), iid = f.dataset.iid, prev = iid ? w.items.find(x => x.id === iid) : null, v = formVals(f);
    if (!String(v.name || '').trim()) return toast('Gehne ka naam daaliye', 'err'); if (num(v.wMax) && num(v.wMin) > num(v.wMax)) return toast('Wazan "se" "tak" se zyada hai', 'err');
    if (v.huid && !/^[A-Z0-9]{6}$/i.test(String(v.huid).trim())) return toast('HUID 6 akshar / ank ka hota hai', 'err');
    let photos = (prev ? prev.photos || [] : []).filter((p, k) => !(f._del || []).includes(k));
    const files = [...(f._files || f.elements.photosIn.files || [])].slice(0, Math.max(0, 4 - photos.length)); for (const fl of files) if (/^image\//.test(fl.type)) photos.push({ src: await compress(fl, 1000, 0.78), at: Date.now() });
    const custom = {}; ['size', 'length', 'stone', 'meena', 'finish', 'engraving', 'back', 'other'].forEach(k => { const x = String(v['c_' + k] || '').trim(); if (x) custom[k] = x.slice(0, 120); });
    const it = blank({ ...(prev || {}), id: prev ? prev.id : uid('wi'), name: v.name.trim().slice(0, 80), metal: v.metal, purity: v.purity, qty: Math.max(1, Math.round(num(v.qty)) || 1), unit: v.unit, wMin: num(v.wMin) ? r3(num(v.wMin)) : '', wMax: num(v.wMax) ? r3(num(v.wMax)) : '', makingPct: v.makingPct === '' ? '' : num(v.makingPct), labour: num(v.labour) || '', stone: num(v.stone) || '', extra: num(v.extra) || '', photos, productId: v.productId || '', custom, status: v.status, karigar: String(v.karigar || '').trim(), due: v.due || '', actualGross: num(v.actualGross) ? r3(num(v.actualGross)) : '', actualLess: num(v.actualLess) ? r3(num(v.actualLess)) : '', huid: String(v.huid || '').trim().toUpperCase(), note: String(v.note || '').trim() });
    if (it.productId && !it.actualGross) { const p = S.products.find(x => x.id === it.productId); if (p) { it.actualGross = r3(num(p.gross)); it.actualLess = r3(num(p.less)); it.huid = it.huid || p.huid || ''; } }
    const items = prev ? w.items.map(x => x.id === prev.id ? it : x) : [...w.items, it];
    if (JSON.stringify({ ...w, items }).length > 6e6) return toast('Package mein photo bahut zyada — kuch hatayiye', 'err');
    if (await saveW({ ...w, items })) { closeModal(f.closest('.overlay')); toast('✓ ' + it.name + ' save'); }
  };
  ACT['wd-item-del'] = t => { const w = getW(t.dataset.wid); const it = w.items.find(i => i.id === t.dataset.iid); confirmBox(`"${it.name}" package se hatayein?`, async () => { if (await saveW({ ...w, items: w.items.filter(i => i.id !== it.id) })) { document.querySelectorAll('form[data-sjw="item"]').forEach(f => closeModal(f.closest('.overlay'))); toast('Hata diya'); } }, 'Hatao'); };
  ACT['wd-tpl'] = t => {
    const w = getW(t.dataset.id); const have = new Set((w.items || []).map(i => i.name));
    const row = (m, n) => `<label class="chk wd-tpl"><input type="checkbox" name="t" value="${esc(m + '|' + n)}" ${have.has(n) ? 'disabled' : ''}> ${esc(n)}${have.has(n) ? ' <span class="small muted">(hai)</span>' : ''}</label>`;
    openModal(`<form data-sjw="tpl" data-wid="${esc(w.id)}" novalidate>${mHead('📋 Aam shaadi ke gehne', 'Tick kijiye — baad mein har gehne mein wazan, photo, customisation')}<div class="m-body"><h4 class="wd-h4">🟡 Sona</h4><div class="wd-tpls">${TEMPLATE.gold.map(n => row('gold', n)).join('')}</div><h4 class="wd-h4">⚪ Chandi</h4><div class="wd-tpls">${TEMPLATE.silver.map(n => row('silver', n)).join('')}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Jodo</button></div></form>`, { small: true });
  };
  SUBMIT.tpl = async f => { const w = getW(f.dataset.wid); const pick = [...f.querySelectorAll('input[name="t"]:checked')].map(x => x.value.split('|')); if (!pick.length) return toast('Kuch tick kijiye', 'err'); const add = pick.map(([m, n]) => blank({ name: n, metal: m, purity: m === 'silver' ? '92.5' : '22K', unit: UNIT(n) })); if (await saveW({ ...w, items: [...(w.items || []), ...add] })) { closeModal(f.closest('.overlay')); toast('✓ ' + add.length + ' gehne jude'); } };

  /* ---------------- package form ---------------- */
  ACT['wd-new'] = () => pkgForm('');
  ACT['wd-edit'] = t => pkgForm(t.dataset.id);
  function pkgForm(id) {
    const w = id ? getW(id) : { makingPct: '', gstPct: 3 };
    const custs = S.customers.slice().sort((a, b) => String(a.name).localeCompare(String(b.name))).map(c => [c.id, c.name + (c.phone ? ' · ' + c.phone : '')]);
    openModal(`<form data-sjw="pkg" data-id="${esc(id || '')}" novalidate>${mHead(id ? 'Package badlo — ' + esc(w.no) : '💍 Naya shaadi package', 'Parivaar, tareekh, budget, making')}<div class="m-body">
      <div class="fg">${F('Customer (list se)', `<select name="customerId">${opts(custs, w.customerId || '', '— naya grahak —')}</select>`)}${F('Naam *', inp('name', w.name || ''))}${F('Phone', inp('phone', w.phone || '', { im: 'tel' }))}${F('Shahar', inp('city', w.city || ''))}${F('Shaadi ki tareekh', inp('eventDate', w.eventDate || '', { type: 'date' }))}${F('Gehne kab tak chahiye', inp('needBy', w.needBy || '', { type: 'date' }))}${F('Dulhan', inp('bride', w.bride || ''))}${F('Dulha', inp('groom', w.groom || ''))}${F('Kis taraf se', sel('side', [['', '—'], ['bride', 'Dulhan paksh'], ['groom', 'Dulha paksh']], w.side || ''))}${F('Budget ₹', inp('budget', w.budget || '', { type: 'number', step: '1000', min: 0, im: 'numeric' }))}${F('Making / wastage %', inp('makingPct', w.makingPct, { type: 'number', step: '0.1', min: 0, ph: String(num(pro().shaadiMaking || 12)) }))}${F('GST %', inp('gstPct', w.gstPct == null ? 3 : w.gstPct, { type: 'number', step: '0.5', min: 0 }))}</div>
      ${F('Note (pasand, rang, design ki baat)', `<textarea name="notes" rows="2">${esc(w.notes || '')}</textarea>`)}
      ${!id ? `<h4 class="wd-h4">📋 Shuru ke gehne <span class="small muted">— baad mein aur jod sakte hain</span></h4><div class="wd-tpls">${[...TEMPLATE.gold.slice(0, 8).map(n => ['gold', n]), ...TEMPLATE.silver.slice(0, 2).map(n => ['silver', n])].map(([m, n], k) => `<label class="chk wd-tpl"><input type="checkbox" name="t" value="${esc(m + '|' + n)}" ${k < 7 || m === 'silver' ? 'checked' : ''}> ${m === 'silver' ? '⚪' : '🟡'} ${esc(n)}</label>`).join('')}</div>` : ''}
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { wide: true });
  }
  document.addEventListener('change', e => { const f = e.target.closest && e.target.closest('form[data-sjw="pkg"]'); if (!f || e.target.name !== 'customerId' || !e.target.value) return; const c = custById(e.target.value); if (c) ['name', 'phone', 'city'].forEach(k => { if (!f.elements[k].value) f.elements[k].value = c[k] || ''; }); });
  SUBMIT.pkg = async f => {
    const id = f.dataset.id, prev = id ? getW(id) : null, v = formVals(f);
    if (!String(v.name || '').trim()) return toast('Naam daaliye', 'err');
    const tpl = [...f.querySelectorAll('input[name="t"]:checked')].map(x => x.value.split('|')).map(([m, n]) => blank({ name: n, metal: m, purity: m === 'silver' ? '92.5' : '22K', unit: UNIT(n) }));
    const w = { ...(prev || {}), id: prev ? prev.id : uid('wd'), no: prev ? prev.no : nextNo('weddings', 'SH-'), customerId: v.customerId || '', name: v.name.trim(), phone: String(v.phone || '').trim(), city: String(v.city || '').trim(), eventDate: v.eventDate || '', needBy: v.needBy || '', bride: String(v.bride || '').trim(), groom: String(v.groom || '').trim(), side: v.side || '', budget: num(v.budget) || 0, makingPct: v.makingPct === '' ? '' : num(v.makingPct), gstPct: v.gstPct === '' ? 3 : num(v.gstPct), notes: String(v.notes || ''), items: prev ? prev.items : tpl, advances: prev ? prev.advances || [] : [], used: prev ? prev.used || [] : [], billed: prev ? prev.billed || [] : [], status: prev ? prev.status : 'active', createdAt: prev ? prev.createdAt : Date.now(), by: prev ? prev.by : (me().name || '') };
    if (await saveW(w)) { closeModal(f.closest('.overlay')); toast('✓ Package ' + w.no + ' save'); if (!prev) { ui.wdOpen = w.id; ui.wdSec = 'gehne'; renderView(true); } }
  };
  ACT['wd-del'] = t => { const w = getW(t.dataset.id); if (advFree(w) > 0.5 || metalAdv(w).some(a => !a.usedIn)) return toast('Is package mein advance / purana sona bacha hai — pehle bill mein lagaiye ya wapas kijiye', 'err'); confirmBox(`Package ${w.no} (${w.name}) delete karein?`, async () => { await removeDoc('weddings', w.id); ui.wdOpen = ''; renderView(true); toast('Delete'); }, 'Delete'); };
  ACT['wd-done'] = t => { const w = getW(t.dataset.id); confirmBox(`Package ${w.no} poora mark karein?${advFree(w) > 0.5 ? ` Dhyan: ${inr(advFree(w))} advance abhi bacha hai.` : ''}`, async () => { await saveW({ ...w, status: 'done', doneAt: todayStr() }); toast('✓ Poora'); }, 'Poora'); };

  /* =====================================================================
     ADVANCE + BHAV CUTTING
     ===================================================================== */
  function advSec(w, c) {
    const A = (w.advances || []).slice().sort((a, b) => String(a.date).localeCompare(String(b.date)));
    const lk = ['gold', 'silver'].map(m => ({ m, ...locks(w, m) })).filter(x => x.fine);
    return `<div class="toolbar">${canEdit() && w.status !== 'done' ? `<button class="btn primary sm" data-act="wd-adv" data-id="${w.id}" data-t="cash">💰 Advance (cash / UPI)</button><button class="btn sm gold" data-act="wd-adv" data-id="${w.id}" data-t="cash" data-lock="1">🔒 Advance + bhav cutting</button><button class="btn sm" data-act="wd-adv" data-id="${w.id}" data-t="metal">🪙 Purana sona / chandi</button>` : ''}</div>
      ${lk.length ? `<div class="card wd-lock"><h3>🔒 Kata hua bhav</h3>${lk.map(x => { const now = todayG(x.m), diff = (now - x.rateG) * x.free; return `<div class="wd-lk"><div><b>${MN(x.m)}: ${g3(x.fine)} fine</b> <span class="small muted">avg ₹${fmtAmt(x.rateG * (x.m === 'silver' ? 1000 : 10))}${rateUnit(x.m)}</span><div class="small muted">Bill mein laga ${g3(x.used)} · bacha <b>${g3(x.free)}</b></div></div><div class="right"><div class="small muted">Aaj ₹${fmtAmt(showRate(x.m))}${rateUnit(x.m)}</div><b class="${diff >= 0 ? 'green' : 'red'}">${diff >= 0 ? 'Bachat' : 'Nuksaan'} ${inr(Math.abs(diff))}</b></div></div>`; }).join('')}<p class="small muted" style="margin:6px 0 0">Bill banate waqt kata bhav us dhatu ke fine wazan (making samet) par apne-aap lagta hai — baaki aaj ke bhav se.</p></div>` : ''}
      ${A.length ? `<div class="wd-advs">${A.map(a => `<div class="card wd-adv"><div class="wd-adv-l"><b>${a.type === 'metal' ? `🪙 Purana ${MN(a.metal.metal).toLowerCase()}` : '💰 ' + esc(a.mode || 'Cash')}</b> <span class="small muted">${fmtD(a.date)}</span><div class="small">${a.type === 'metal' ? `${esc(a.metal.desc || '')} ${g3(a.metal.gross)} @ ${num(a.metal.tunch)}%${a.usedIn ? ' · <span class="green">bill mein laga</span>' : ''}` : esc(a.note || '')}</div>${a.lock && num(a.lock.fine) ? `<div class="small wd-lockchip">🔒 ${MN(a.lock.metal)} ${g3(a.lock.fine)} @ ₹${fmtAmt(a.lock.rate)}${rateUnit(a.lock.metal)}</div>` : ''}</div><div class="wd-adv-r"><b>${a.type === 'metal' ? g3(a.metal.fine) + ' fine' : inr(a.amount)}</b>${a.type === 'metal' ? `<div class="small muted">≈ ${inr(num(a.metal.fine) * todayG(a.metal.metal))}</div>` : ''}<div class="btns" style="flex-wrap:nowrap;justify-content:flex-end"><button class="btn sm" data-act="wd-rasid" data-id="${w.id}" data-aid="${a.id}" title="Rasid PDF">${ic('dl', 13)}</button>${w.phone ? `<button class="btn sm green" data-act="wd-adv-wa" data-id="${w.id}" data-aid="${a.id}" title="WhatsApp">WA</button>` : ''}${canAdmin() && !a.usedIn ? `<button class="btn sm danger" data-act="wd-adv-del" data-id="${w.id}" data-aid="${a.id}" title="Hatao">✕</button>` : ''}</div></div></div>`).join('')}</div>` : emptyBox('Abhi koi advance nahi. Cash / UPI advance, bhav cutting ke saath advance, ya purana sona-chandi jama kijiye.')}
      ${(w.used || []).length ? `<p class="small muted">Bill mein laga advance: ${(w.used || []).map(u => `${esc(u.invNo)} ${inr(u.amount)}`).join(' · ')}</p>` : ''}`;
  }
  ACT['wd-adv'] = t => advForm(t.dataset.id, t.dataset.t, !!t.dataset.lock);
  function advForm(wid, type, lock) {
    const w = getW(wid); const metal = type === 'metal'; const c = calc(w); const needG = c.gold.need, needS = c.silver.need;
    openModal(`<form data-sjw="adv" data-wid="${esc(wid)}" data-type="${metal ? 'metal' : 'cash'}" novalidate>${mHead(metal ? '🪙 Purana sona / chandi advance' : lock ? '🔒 Advance + bhav cutting' : '💰 Advance', esc(w.name) + ' · ' + esc(w.no))}<div class="m-body">
      ${metal ? `<div class="fg">${F('Date', inp('date', todayStr(), { type: 'date' }))}${F('Dhatu', sel('metal', [['gold', 'Sona'], ['silver', 'Chandi']], 'gold'))}${F('Kya hai', inp('desc', '', { ph: 'purani chain, kangan…' }))}${F('Gross wazan (g)', inp('gross', '', { type: 'number', step: '0.001', min: 0, im: 'decimal', req: 1 }))}${F('Tunch % (jaanch ke baad)', inp('tunch', '', { type: 'number', step: '0.01', min: 1, max: 100, im: 'decimal', req: 1 }))}${F('Note', inp('note', ''))}</div><div class="wd-advcalc small"></div><p class="small muted">Ye fine wazan package ke naye gehnon ke badle mein jama rahega (dhatu ke badle dhatu). Bill banate waqt purane sone ki line apne-aap judegi.</p>`
      : `<div class="fg">${F('Date', inp('date', todayStr(), { type: 'date' }))}${F('Rakam ₹ *', inp('amount', '', { type: 'number', step: '1', min: 1, im: 'numeric', req: 1 }))}${F('Kaise', sel('mode', PAY_MODES, 'Cash'))}${F('Note', inp('note', ''))}</div>
        <label class="chk" style="margin-top:10px"><input type="checkbox" name="lock" ${lock ? 'checked' : ''}> 🔒 Is advance se bhav kaato (rate lock)</label>
        <div class="wd-lockbox"${lock ? '' : ' hidden'}><div class="fg">${F('Dhatu', sel('lmetal', [['gold', 'Sona'], ['silver', 'Chandi']], 'gold'))}${F('Bhav (24K ₹/10g · chandi ₹/kg)', inp('lrate', showRate('gold'), { type: 'number', step: '1', min: 1, im: 'numeric' }))}${F('Kitna fine wazan kaatna hai (g)', inp('lfine', '', { type: 'number', step: '0.001', min: 0, im: 'decimal' }))}</div><div class="wd-advcalc small"></div>
        <p class="small muted" style="margin:4px 0 0">Khaali chhodein to rakam ÷ bhav jitna wazan kategaa. Kam advance par zyada wazan bhi kaat sakte hain (token advance). Package mein sone ki zaroorat: ${g3(needG)} fine${needS ? ' · chandi ' + g3(needS) : ''}.</p></div>`}
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { small: true });
    advCalc();
  }
  function advCalc() {
    const f = q$('form[data-sjw="adv"]'); if (!f) return; const v = formVals(f); const out = q$('.wd-advcalc', f); if (!out) return;
    if (f.dataset.type === 'metal') { const fine = r3(num(v.gross) * num(v.tunch) / 100); out.innerHTML = fine ? `Fine: <b>${g3(fine)}</b> · aaj ke bhav se lagbhag <b>${inr(fine * todayG(v.metal))}</b>` : ''; return; }
    const box = q$('.wd-lockbox', f); if (box) box.hidden = !v.lock; if (!v.lock) return;
    const m = v.lmetal, rg = toG(m, v.lrate), auto = rg ? r3(num(v.amount) / rg) : 0, fine = num(v.lfine) || auto, cover = fine * rg;
    out.innerHTML = rg ? `${inr(num(v.amount))} ÷ ₹${fmtAmt(num(v.lrate))}${rateUnit(m)} = <b>${g3(auto)}</b> fine${num(v.lfine) ? ` · kaat rahe: <b>${g3(fine)}</b> (keemat ${inr(cover)} — advance ${Math.round(num(v.amount) / Math.max(1, cover) * 100)}%)` : ''}` : '';
  }
  document.addEventListener('input', e => { if (e.target.closest && e.target.closest('form[data-sjw="adv"]')) advCalc(); });
  document.addEventListener('change', e => { const f = e.target.closest && e.target.closest('form[data-sjw="adv"]'); if (!f) return; if (e.target.name === 'lmetal') f.elements.lrate.value = showRate(e.target.value) || ''; advCalc(); });
  SUBMIT.adv = async f => {
    const w = getW(f.dataset.wid), v = formVals(f); let a;
    if (f.dataset.type === 'metal') {
      const fine = r3(num(v.gross) * num(v.tunch) / 100); if (!(num(v.gross) > 0)) return toast('Wazan daaliye', 'err'); if (!(num(v.tunch) > 0 && num(v.tunch) <= 100)) return toast('Tunch % 1 se 100 ke beech', 'err');
      a = { id: uid('wa'), type: 'metal', date: v.date || todayStr(), metal: { metal: v.metal, desc: String(v.desc || '').trim(), gross: r3(num(v.gross)), tunch: num(v.tunch), fine, rateAtDate: todayG(v.metal) }, note: String(v.note || ''), by: me().name || '' };
    } else {
      if (!(num(v.amount) > 0)) return toast('Rakam daaliye', 'err');
      let lock = null; if (v.lock) { const rg = toG(v.lmetal, v.lrate); if (!(rg > 0)) return toast('Bhav daaliye', 'err'); const fine = r3(num(v.lfine) || num(v.amount) / rg); if (!(fine > 0)) return toast('Fine wazan 0 hai', 'err'); const now = showRate(v.lmetal); if (now && Math.abs(num(v.lrate) - now) / now > 0.05 && !f._rOk) { f._rOk = true; return toast(`Bhav aaj ke bhav (₹${fmtAmt(now)}) se 5% se zyada alag — pakka hai to Save dobara dabaiye`, 'err'); } lock = { metal: v.lmetal, rate: num(v.lrate), fine, at: Date.now() }; }
      const btx = await moneyIn(v.date || todayStr(), v.amount, v.mode, w.name, 'Shaadi advance ' + w.no + (lock ? ` · bhav cutting ${g3(lock.fine)} @ ${lock.rate}` : '') + (v.note ? ' · ' + v.note : ''), w.no);
      a = { id: uid('wa'), type: 'cash', date: v.date || todayStr(), amount: r2(num(v.amount)), mode: v.mode || 'Cash', note: String(v.note || ''), btxId: btx, lock, by: me().name || '' };
    }
    if (await saveW({ ...w, advances: [...(w.advances || []), a] })) { closeModal(f.closest('.overlay')); toast(a.type === 'metal' ? `✓ ${g3(a.metal.fine)} fine jama` : `✓ ${inr(a.amount)} advance${a.lock ? ' + bhav cutting' : ''}`); ui.wdSec = 'advance'; renderView(); if (w.phone) setTimeout(() => offerWa(w, a), 500); }
  };
  function advMsg(w, a) { return `Namaste ${w.name} ji 🙏\n${firm()} — shaadi package ${w.no}:\n` + (a.type === 'metal' ? `Aapka purana ${MN(a.metal.metal).toLowerCase()} ${g3(a.metal.gross)} (${a.metal.tunch}% tunch) = *${g3(a.metal.fine)} fine* jama hua.` : `*${inr(a.amount)}* advance jama hua (${a.mode}, ${fmtD(a.date)}).` + (a.lock ? `\n🔒 Bhav cutting: ${MN(a.lock.metal).toLowerCase()} *${g3(a.lock.fine)} fine* ₹${fmtAmt(a.lock.rate)}${rateUnit(a.lock.metal)} par kata.` : '')) + `\nDhanyavaad! 💛`; }
  function offerWa(w, a) { const u = waUrl(w.phone, advMsg(w, a)); if (!u) return; openModal(`${mHead('Customer ko rasid bhejein?', esc(w.name))}<div class="m-body"><pre class="wd-pre">${esc(advMsg(w, a))}</pre></div><div class="m-foot"><button class="btn" data-act="close">Baad mein</button><button class="btn" data-act="wd-rasid" data-id="${w.id}" data-aid="${a.id}">${ic('dl', 14)} Rasid PDF</button><a class="btn green primary" target="_blank" rel="noopener" href="${esc(u)}">WhatsApp</a></div>`, { small: true }); }
  ACT['wd-adv-wa'] = t => { const w = getW(t.dataset.id); const a = w.advances.find(x => x.id === t.dataset.aid); const u = waUrl(w.phone, advMsg(w, a)); if (u) window.open(u, '_blank', 'noopener'); };
  ACT['wd-adv-del'] = t => {
    const w = getW(t.dataset.id); const a = w.advances.find(x => x.id === t.dataset.aid);
    if (a.type !== 'metal' && advFree(w) - num(a.amount) < -0.5) return toast('Ye advance bill mein lag chuka — hata nahi sakte', 'err');
    if (a.lock && locks(w, a.lock.metal).free - num(a.lock.fine) < -0.0005) return toast('Is advance ka kata bhav bill mein lag chuka — hata nahi sakte', 'err');
    confirmBox(`Ye ${a.type === 'metal' ? 'purane sone ka' : inr(a.amount) + ' ka'} advance hatayein?${a.btxId ? ' Bank & cash ki entry bhi hategi.' : ''}`, async () => { if (a.btxId) await removeDoc('banktx', a.btxId); await saveW({ ...w, advances: w.advances.filter(x => x.id !== a.id) }); toast('Hata diya'); }, 'Hatao');
  };
  ACT['wd-rasid'] = async t => {
    const w = getW(t.dataset.id); const a = w.advances.find(x => x.id === t.dataset.aid); const s = settings(); const pdf = new Pdf(148, 210); const L = 10, R = 138; let y = 13;
    pdf.fill('#7a5410').font(true, 14).text(s.firm || 'Shivaa Jewels', 74, y, { align: 'center' }); y += 5; pdf.fill('#444444').font(false, 7.5).text(String(s.address || ''), 74, y, { align: 'center', maxW: 128 }); y += 3.8; pdf.text([s.phone ? 'Mob ' + s.phone : '', s.gstin ? 'GSTIN ' + s.gstin : ''].filter(Boolean).join('   '), 74, y, { align: 'center' }); y += 5;
    pdf.stroke('#c9a046').lw(0.6).line(L, y, R, y); y += 7; pdf.fill('#000000').font(true, 12).text(a.type === 'metal' ? 'PURANA SONA / CHANDI JAMA RASID' : a.lock ? 'ADVANCE + BHAV CUTTING RASID' : 'ADVANCE RASID', 74, y, { align: 'center' }); y += 8;
    const kv = (k, v2, x2) => { pdf.font(false, 8).fill('#555555').text(k, x2, y); pdf.font(true, 9).fill('#000000').text(String(v2 || '-'), x2 + 25, y, { maxW: 42 }); };
    kv('Rasid', a.id.slice(-6).toUpperCase(), L); kv('Date', fmtD(a.date), 76); y += 5.5; kv('Package', w.no, L); kv('Shaadi', w.eventDate ? fmtD(w.eventDate) : '-', 76); y += 5.5; kv('Naam', w.name, L); kv('Phone', w.phone, 76); y += 9;
    const box = (lines) => { const h = lines.length * 6.5 + 6; pdf.fill('#f6efdc').rect(L, y - 4.5, R - L, h, 'F'); lines.forEach(([k, v2, b]) => { pdf.font(!!b, b ? 11 : 9.5).fill('#000000').text(k, L + 4, y); pdf.text(v2, R - 4, y, { align: 'right' }); y += 6.5; }); y += 4; };
    if (a.type === 'metal') box([['Kya', a.metal.desc || MN(a.metal.metal)], ['Gross wazan', g3(a.metal.gross).replace(' g', '') + ' g'], ['Tunch', a.metal.tunch + '%'], ['Fine jama', a.metal.fine.toFixed(3) + ' g', true]]);
    else box([['Rakam', 'Rs ' + fmtAmt(a.amount), true], ['Kaise', a.mode || 'Cash'], ...(a.lock ? [['Bhav cutting (' + MN(a.lock.metal) + ')', a.lock.fine.toFixed(3) + ' g fine'], ['Kata bhav', 'Rs ' + fmtAmt(a.lock.rate) + (a.lock.metal === 'silver' ? ' / kg' : ' / 10g (24K)'), true]] : [])]);
    const c = calc(w); pdf.font(false, 9).fill('#333333').text(`Package mein ab tak: advance Rs ${fmtAmt(advCash(w))}${c.gold.lockFine ? ` · kata sona ${c.gold.lockFine.toFixed(3)} g` : ''}${c.silver.lockFine ? ` · kati chandi ${c.silver.lockFine.toFixed(3)} g` : ''}`, L, y, { maxW: R - L }); y += 8;
    pdf.font(true, 8.5).fill('#000000').text('Niyam', L, y); y += 4.5; pdf.font(false, 7.6).fill('#333333');
    (a.type === 'metal' ? ['1. Upar likha fine wazan is shaadi package ke naye gehnon ke bill mein dhatu ke badle dhatu jama hoga.', '2. Tunch dono pakshon ke saamne jaancha gaya.'] : ['1. Ye advance shaadi package ' + w.no + ' ke gehnon ke final bill mein jama hoga.', ...(a.lock ? [`2. Kata bhav sirf is package ke ${MN(a.lock.metal).toLowerCase()} ke ${a.lock.fine.toFixed(3)} g fine tak laagu; usse zyada wazan bill ke din ke bhav se.`] : []), (a.lock ? '3' : '2') + '. Final bill gehnon ke asli wazan, making aur GST ke saath banega.']).concat(['Ye rasid computer se bani hai — sambhal kar rakhiye.']).forEach(t2 => pdf.wrap(t2, R - L).forEach(l => { pdf.text(l, L, y); y += 3.8; }));
    y = Math.max(y + 14, 188); pdf.stroke('#888888').lw(0.3).line(L, y, L + 45, y).line(R - 45, y, R, y); pdf.fill('#555555').font(false, 8).text('Customer', L + 22.5, y + 4, { align: 'center' }).text('for ' + (s.firm || ''), R - 22.5, y + 4, { align: 'center' });
    await offerDownload('rasid_' + safeName(w.no + '_' + a.date) + '.pdf', pdf.blob());
  };

  /* =====================================================================
     HISAAB
     ===================================================================== */
  function hisaabSec(w, c) {
    const row = (k, v2, cls) => `<div class="wd-hr ${cls || ''}"><span>${k}</span><b>${v2}</b></div>`;
    const mrow = m => { const x = c[m]; if (!x.items) return ''; return `<div class="card"><h3>${m === 'gold' ? '🟡 Sona' : '⚪ Chandi'} — ${x.items} gehne (bill baaki)</h3>${row('Wazan (net)', g3(x.net) + (x.range[0] !== x.range[1] ? ` <span class="small muted">(${g3(x.range[0])} – ${g3(x.range[1])})</span>` : ''))}${row('Fine chahiye (making samet)', g3(x.need))}${row(`Aaj ke bhav se (₹${fmtAmt(showRate(m))}${rateUnit(m)})`, inr(x.today))}${x.lockApplied ? row(`Kata bhav: ${g3(x.lockApplied)} @ ₹${fmtAmt(x.lockRateG * (m === 'silver' ? 1000 : 10))}`, inr(x.withLock), 'green') : ''}${x.credit ? row(`Purana ${MN(m).toLowerCase()} jama: ${g3(x.credit)} fine`, '− ' + inr(x.creditVal)) : ''}</div>`; };
    return mrow('gold') + mrow('silver') + `<div class="card wd-sum"><h3>🧮 Kul andaaza</h3>${row('Sona + chandi (kate bhav ke saath)', inr(c.gold.withLock + c.silver.withLock))}${c.labour ? row('Labour', inr(c.labour)) : ''}${c.charges ? row('Stone + customisation', inr(c.charges)) : ''}${row('GST ' + c.gst + '%', inr(c.total - c.sub))}${row('Andaaza bill', inr(c.total), 'big')}${c.saving > 0.5 ? row('Bhav cutting se bachat', inr(c.saving), 'green') : c.saving < -0.5 ? row('Kata bhav aaj se mehnga', inr(-c.saving), 'red') : ''}${row('Advance (bacha)', '− ' + inr(c.cashFree))}${c.credit ? row('Purana sona / chandi', '− ' + inr(c.credit)) : ''}${row('Baaki (andaaza)', inr(Math.max(0, c.balance)), 'big')}${num(w.budget) ? row('Budget', inr(w.budget) + ` <span class="small ${c.total > num(w.budget) ? 'red' : 'green'}">(${c.total > num(w.budget) ? 'zyada ' + inr(c.total - num(w.budget)) : 'andar'})</span>`) : ''}<p class="small muted" style="margin:8px 0 0">Andaaza: wazan ka beech ka hisaab (asli wazan bhara ho to wahi), making ${pkgMk(w)}% (gehne ki alag ho to wo). Final bill asli wazan par banega.${(w.billed || []).length ? ' Jin gehnon ka bill ban chuka wo is hisaab mein nahi.' : ''}</p></div>`;
  }

  /* =====================================================================
     BILL — chune gehne → sale bill (kata bhav, purana sona, advance apne-aap)
     ===================================================================== */
  function billSec(w) {
    const L = (w.items || []).filter(i => !i.billed); const B = w.billed || [];
    return `${B.length ? `<div class="card"><h3>Bane hue bill</h3>${B.map(b => { const v = S.invoices.find(x => x.id === b.invId); return `<div class="row static"><div><b>${esc(b.invNo)}</b> <span class="small muted">${fmtD(b.date)} · ${b.items.length} gehne${b.lock && (b.lock.gold || b.lock.silver) ? ' · kata bhav ' + [b.lock.gold && g3(b.lock.gold) + ' sona', b.lock.silver && g3(b.lock.silver) + ' chandi'].filter(Boolean).join(', ') : ''}</span></div>${v ? `<button class="btn sm" data-act="wd-inv" data-id="${v.id}">Bill dekho</button>` : '<span class="small red">delete ho gaya</span>'}</div>`; }).join('')}</div>` : ''}
      ${L.length ? `<div class="card"><h3>Bill banao</h3><p class="small muted" style="margin-top:-4px">Jo gehne dene hain unhe chuniye. Asli wazan na bhara ho to "tak" wala wazan lagega — bill mein badal sakte hain.</p><form data-sjw="bill" data-wid="${esc(w.id)}" novalidate>${L.map(i => `<label class="chk wd-bi"><input type="checkbox" name="i" value="${i.id}" ${['ready', 'delivered'].includes(i.status) ? 'checked' : ''}> <span><b>${esc(i.name)}</b> <span class="small muted">${MN(metalOf(i))} ${esc(i.purity)} · ${num(i.actualGross) ? 'asli ' + g3(i.actualGross) : '<span class="red">asli wazan nahi</span>'} · ${esc(stName(i.status))}</span></span></label>`).join('')}<div class="btns" style="margin-top:10px">${canEdit() ? '<button class="btn primary">🧾 Chune gehnon ka bill banao</button>' : ''}</div></form>
      <p class="small muted" style="margin:8px 0 0">Bill mein apne-aap: kata bhav (bacha ${g3(locks(w, 'gold').free)} sona${locks(w, 'silver').free ? ', ' + g3(locks(w, 'silver').free) + ' chandi' : ''}), making ${pkgMk(w)}%, stone + customisation charge, HUID, purana sona / chandi (${g3(metalCredit(w, 'gold', true))}${metalCredit(w, 'silver', true) ? ' + ' + g3(metalCredit(w, 'silver', true)) + ' chandi' : ''}) aur bacha advance ${inr(advFree(w))}.</p></div>` : emptyBox('Saare gehnon ka bill ban chuka. 👍')}`;
  }
  ACT['wd-inv'] = t => openInvoiceView(t.dataset.id);
  SUBMIT.bill = async f => {
    let w = getW(f.dataset.wid); const ids = [...f.querySelectorAll('input[name="i"]:checked')].map(x => x.value); if (!ids.length) return toast('Gehne chuniye', 'err');
    const its = w.items.filter(i => ids.includes(i.id)); const noWt = its.filter(i => !num(i.actualGross) && !num(i.wMax) && !num(i.wMin)); if (noWt.length) return toast(noWt.map(i => i.name).join(', ') + ' — wazan nahi bhara', 'err');
    if (INV && INV.el && INV.el.isConnected) return toast('Pehle khula hua bill band kijiye', 'err');
    let c = custOf(w);
    if (!c) { c = S.customers.find(x => ph10(x.phone) && ph10(x.phone) === ph10(w.phone)); if (!c) { c = { id: uid('c'), name: w.name, phone: w.phone || '', city: w.city || '', ptype: 'Retail', createdAt: Date.now(), updatedAt: Date.now() }; if (!await save('customers', c)) return; } w = { ...w, customerId: c.id }; await saveW(w, true); }
    // rate per metal: kata bhav first, rest today
    const rate = {}, lockUse = {}; ['gold', 'silver'].forEach(m => { const mi = its.filter(i => metalOf(i) === m); const need = r3(sum(mi, i => itFine(w, i))); const lk = locks(w, m); const lf = r3(Math.min(lk.free, need)); lockUse[m] = lf; rate[m] = need ? r2((lf * lk.rateG + (need - lf) * todayG(m)) / need) : todayG(m); });
    openInvoice('sale'); if (!INV) return;
    INV.partyId = c.id; INV.channel = 'retail';
    INV.items = its.map(i => { const gross = num(i.actualGross) || r3((num(i.wMax) || num(i.wMin)) * (num(i.qty) || 1)); const p = i.productId ? S.products.find(x => x.id === i.productId && x.status === 'In Stock') : null;
      return newItem({ ...(p ? { productId: p.id, sku: p.sku, stockType: p.stockType || '', addToVault: false } : {}), category: i.name, purity: i.purity, pcs: num(i.qty) || 1, gross, less: num(i.actualLess) || '', tunch: tunchOf(i.purity), wastage: itMk(w, i), rate: rate[metalOf(i)], labour: num(i.labour) || '', stone: itCharges(i) || '', huid: i.huid || '', note: [i.name, ...customTxt(i)].join(' · ').slice(0, 200), wManual: true, tManual: true, rManual: true, mManual: true, lManual: true }); });
    const mAdv = metalAdv(w).filter(a => !a.usedIn); INV.oldMetal = mAdv.map(a => newOld({ desc: (a.metal.desc || 'Purana ' + MN(a.metal.metal).toLowerCase()) + ' (' + w.no + ')', metal: a.metal.metal, gross: a.metal.gross, tunch: a.metal.tunch, rate: rate[a.metal.metal] || todayG(a.metal.metal), rManual: true }));
    INV.notes = [INV.notes, `Shaadi package ${w.no}${w.eventDate ? ' · shaadi ' + fmtD(w.eventDate) : ''}${lockUse.gold || lockUse.silver ? ` · kata bhav: ${[lockUse.gold && g3(lockUse.gold) + ' sona', lockUse.silver && g3(lockUse.silver) + ' chandi'].filter(Boolean).join(', ')}` : ''}`].filter(Boolean).join('\n');
    INV.wedding = { id: w.id, itemIds: ids, lock: lockUse, metalAdv: mAdv.map(a => a.id) };
    try { renderItems(); renderOld && renderOld(); } catch (e) { console.error(e); }
    try { const n = q$('[data-inv="notes"]', INV.el); if (n) n.value = INV.notes; } catch (e) { /* */ }
    renderInvParty(); refreshTotals();
    toast(`💍 ${its.length} gehne bill mein · kata bhav ${lockUse.gold ? g3(lockUse.gold) : '0'} · advance ${inr(advFree(w))} save ke baad apne-aap jama`);
  };
  if (typeof persistInvoice === 'function') {
    const P0 = persistInvoice;
    persistInvoice = async function (st) {
      const wd = st && st.wedding ? { ...st.wedding } : null; const r = await P0.apply(this, arguments);
      try {
        if (wd && r && r.inv && !r.error) {
          let w = getW(wd.id); if (!w) return r; const inv = r.inv;
          const items = w.items.map(i => wd.itemIds.includes(i.id) ? { ...i, billed: inv.id, billNo: inv.no, status: i.status === 'delivered' ? 'delivered' : 'ready' } : i);
          const advances = w.advances.map(a => wd.metalAdv.includes(a.id) ? { ...a, usedIn: inv.id } : a);
          w = { ...w, items, advances, billed: [...(w.billed || []), { invId: inv.id, invNo: inv.no, date: inv.date, items: wd.itemIds, lock: wd.lock, metalAdv: wd.metalAdv }] };
          const free = advFree(w), due = invDue(inv), use = r2(Math.min(free, due));
          if (use > 0.5) { const pay = { id: uid('pay'), date: todayStr(), amount: use, fine: 0, mode: 'Advance', note: 'Shaadi ' + w.no }; const inv2 = { ...inv, payments: [...invPayments(inv), pay], updatedAt: Date.now() }; if (await save('invoices', inv2, { quiet: true })) { r.inv = inv2; w.used = [...(w.used || []), { date: todayStr(), invId: inv.id, invNo: inv.no, amount: use, payId: pay.id }]; } }
          await saveW(w, true); toast(`💍 Package ${w.no}: ${wd.itemIds.length} gehne bill mein${use > 0.5 ? ' · ' + inr(use) + ' advance jama' : ''}`);
        }
      } catch (e) { console.error(e); toast('Package update mein dikkat: ' + e.message, 'err'); }
      return r;
    };
  }
  // leftover advance on any later bill of this customer
  if (typeof openInvoiceView === 'function') {
    const OV = openInvoiceView;
    openInvoiceView = function (id) {
      const r = OV.apply(this, arguments);
      try { const v = S.invoices.find(x => x.id === id); const el = q$('#modal-root').lastElementChild; const pb = el && q$('.m-foot [data-act="inv-pdf"]', el);
        if (v && pb && (v.type === 'sale' || v.type === 'estimate') && canEdit() && invDue(v) > 0.5) { const w = S.weddings.map(norm).find(x => x.status !== 'cancelled' && ((x.customerId && x.customerId === v.partyId) || (x.phone && ph10(x.phone) === ph10((custById(v.partyId) || {}).phone))) && advFree(x) > 0.5); if (w) pb.insertAdjacentHTML('beforebegin', `<button type="button" class="btn" data-act="wd-use" data-id="${esc(v.id)}" data-w="${esc(w.id)}">💍 Shaadi advance ${inr(advFree(w))}</button>`); } } catch (e) { console.error(e); }
      return r;
    };
  }
  ACT['wd-use'] = t => { const inv = S.invoices.find(x => x.id === t.dataset.id); const w = getW(t.dataset.w); const use = r2(Math.min(advFree(w), invDue(inv))); if (!(use > 0)) return; confirmBox(`Package ${w.no} ke advance se ${inr(use)} is bill (${inv.no}) mein jama karein?`, async () => { const pay = { id: uid('pay'), date: todayStr(), amount: use, fine: 0, mode: 'Advance', note: 'Shaadi ' + w.no }; if (!await save('invoices', { ...inv, payments: [...invPayments(inv), pay], updatedAt: Date.now() })) return; await saveW({ ...w, used: [...(w.used || []), { date: todayStr(), invId: inv.id, invNo: inv.no, amount: use, payId: pay.id }] }); toast('✓ ' + inr(use) + ' advance se jama'); document.querySelectorAll('#modal-root .overlay').forEach(o => { if (o.querySelector('.inv-doc')) closeModal(o); }); openInvoiceView(inv.id); }, 'Jama karo'); };

  /* ---------------- order estimate (pending items, with photos) ---------------- */
  ACT['wd-est'] = t => {
    const w = getW(t.dataset.id); const it = w.items.filter(i => i.status === 'pending'); if (!it.length) return toast('Saare gehne order ho chuke', 'err');
    if (!window.SJ_ESTIMATES || !SJ_ESTIMATES.openEstimate) return toast('Order estimate nahi khula', 'err'); const c = custOf(w) || {};
    SJ_ESTIMATES.openEstimate(null, { partyId: w.customerId || '', partyName: w.name, partyPhone: w.phone || c.phone || '', partyCity: w.city || c.city || '', deliveryDate: w.needBy || (w.eventDate ? addDays(w.eventDate, -7) : addDays(todayStr(), 21)), notes: `Shaadi package ${w.no}${w.eventDate ? ' · shaadi ' + fmtD(w.eventDate) : ''}${w.notes ? '\n' + w.notes : ''}`,
      items: it.map(i => ({ name: i.name, desc: customTxt(i).join(' · '), qty: num(i.qty) || 1, unit: i.unit || UNIT(i.name), purity: i.purity, melting: String(tunchOf(i.purity)), wMin: i.wMin || '', wMax: i.wMax || '', photos: photosOf(i).slice(0, 3).map(src => ({ src })) })) });
    saveW({ ...w, items: w.items.map(i => i.status === 'pending' ? { ...i, status: 'ordered' } : i) }, true);
  };
  ACT['wd-wa'] = t => { const w = getW(t.dataset.id); const c = calc(w); const it = w.items || []; const msg = `Namaste ${w.name} ji 🙏💍\n${firm()} — shaadi package ${w.no}${w.eventDate ? ' (' + fmtD(w.eventDate) + ')' : ''}:\n` + it.map(i => `• ${i.name}${num(i.qty) > 1 ? ' ×' + i.qty : ''} (${MN(metalOf(i))} ${i.purity}) — ${i.billed ? 'bill ho gaya' : stName(i.status)}`).join('\n') + (c.cash ? `\nAdvance jama: ${inr(c.cash)}` : '') + (c.gold.lockFine ? `\n🔒 Kata bhav: sona ${g3(c.gold.lockFine)}` : '') + `\nAndaaza bill: ${inr(c.total)} · baaki ${inr(Math.max(0, c.balance))}\nKoi badlav ho to bataiye. 💛`; const u = waUrl(w.phone, msg); if (u) window.open(u, '_blank', 'noopener'); };

  /* =====================================================================
     PACKAGE PDF — Signature look, photos, customisation, bhav cutting, hisaab
     ===================================================================== */
  ACT['wd-pdf'] = async t => { const w = getW(t.dataset.id); toast('PDF ban raha hai…'); await offerDownload('shaadi_package_' + safeName(w.no + '_' + w.name) + '.pdf', await packagePdf(w)); };
  async function packagePdf(w, o) {
    o = o || {}; const K = window.SJ_BILLX && SJ_BILLX.kit; if (!K) throw new Error('PDF kit nahi mila'); await SJ_BILLX.loadFonts();
    const { PX, PY, M, CW, SERIF, HIN, C, font, grad, rr, fit, T, wrap, jpeg, sheen, goldLogo, loadImg, DPI_K, shrink, qrDraw } = K;
    const s = settings(), c = calc(w), HDR = 520, CONT = 240, BOTTOM = PY - 120; const legal = typeof BILL_MAIN !== 'undefined' && BILL_MAIN && BILL_MAIN.name ? BILL_MAIN.name : (s.legal || firm());
    const logo = typeof SJ_LOGO !== 'undefined' ? await goldLogo(SJ_LOGO, 900) : null; const items = w.items || []; const pics = await Promise.all(items.map(i => Promise.all(photosOf(i).slice(0, 3).map(loadImg))));
    const meas = document.createElement('canvas').getContext('2d'); const blocks = [];
    const TW = CW - 330 - 560;
    ['gold', 'silver'].forEach(m => { const L = items.map((it, k) => [it, k]).filter(([it]) => metalOf(it) === m); if (!L.length) return; blocks.push({ h: 90, keep: true, draw: (x, y) => secTitle(x, y, m === 'gold' ? 'SONA KE GEHNE' : 'CHANDI KE GEHNE', `${L.length} gehne`) });
      L.forEach(([it, k]) => { const cz = customTxt(it); const lines = cz.length ? wrap(meas, cz.join('  ·  '), TW, 400, 26).slice(0, 3) : []; const nl = it.note ? wrap(meas, it.note, TW, 400, 25).slice(0, 2) : []; const h = Math.max(320, 150 + (lines.length + nl.length) * 36 + 70); blocks.push({ h: h + 20, draw: (x, y) => itemCard(x, y, it, k, h, lines, nl) }); }); });
    if ((w.advances || []).length) { const A = w.advances.slice().sort((a, b) => String(a.date).localeCompare(String(b.date))); blocks.push({ h: 90, keep: true, draw: (x, y) => secTitle(x, y, 'ADVANCE & BHAV CUTTING', '') }); for (let i = 0; i < A.length; i += 12) { const part = A.slice(i, i + 12); blocks.push({ h: 90 + part.length * 62 + 30, draw: (x, y) => advTable(x, y, part) }); } }
    blocks.push({ h: 640, draw: (x, y) => sumBox(x, y) });
    const terms = (pro().shaadiTerms || 'Kata bhav sirf is package ke gehnon par, kate hue fine wazan tak laagu — usse zyada wazan bill ke din ke bhav se.\nFinal bill gehnon ke asli wazan, making aur GST ke saath banega; upar likha hisaab andaaza hai.\nDesign / size ka badlav karigar ko order dene se pehle hi ho sakta hai.\nAdvance ki rasid sambhal kar rakhiye. HUID ke saath hallmark gehne.').split('\n').filter(Boolean);
    const tl = []; terms.forEach((t2, k) => wrap(meas, (k + 1) + '. ' + t2, CW - 100, 400, 26).forEach(l => tl.push(l)));
    blocks.push({ h: 100 + tl.length * 38, draw: (x, y) => { T(x, 'NIYAM', M, y + 50, { size: 24, w: 700, color: C.goldT, ls: 4 }); tl.forEach((l, k) => T(x, l, M + 10, y + 100 + k * 38, { size: 26, color: '#3d362a' })); } });
    blocks.push({ h: 330, draw: (x, y) => signBox(x, y) });
    const TOP1 = HDR + 23 + 40 + 320 + 50, TOP2 = CONT + 40; const pages = [[]]; { let y = TOP1; blocks.forEach((b, bi) => { const need = b.h + (b.keep && blocks[bi + 1] ? blocks[bi + 1].h : 0); if (y + need > BOTTOM - 30 && pages[pages.length - 1].length) { pages.push([]); y = TOP2; } pages[pages.length - 1].push(b); y += b.h; }); }
    const nP = pages.length; const pdf = new Pdf(210, 297); pdf.pages.length = 0;
    for (let pi = 0; pi < nP; pi++) {
      const k = o.preview ? 1 : DPI_K(); const cv = document.createElement('canvas'); cv.width = Math.round(PX * k); cv.height = Math.round(PY * k); const x = cv.getContext('2d'); x.scale(k, k); x.imageSmoothingQuality = 'high';
      x.fillStyle = C.ivory; x.fillRect(0, 0, PX, PY); frame(x, pi); let y = pi === 0 ? header(x) : contHeader(x, pi); y = pi === 0 ? infoCards(x, y + 40) + 50 : TOP2;
      pages[pi].forEach(b => { b.draw(x, y); y += b.h; }); bottomStrip(x, pi);
      if (o.preview) { o.pages = o.pages || []; o.pages.push(shrink(cv, 0.5).toDataURL('image/jpeg', 0.85)); continue; }
      pdf.addPage(); pdf.image(jpeg(cv, 0.95), 0, 0, 210, 297);
    }
    if (o.preview) return null; return pdf.blob();

    function frame(x, pi) { const top = (pi === 0 ? HDR : CONT) + 44, bot = PY - 114; x.strokeStyle = '#d6b871'; x.lineWidth = 3; x.strokeRect(52, top, PX - 104, bot - top); x.strokeStyle = '#ead7a6'; x.lineWidth = 1.5; x.strokeRect(64, top + 12, PX - 128, bot - top - 24); x.save(); x.globalAlpha = 0.045; x.strokeStyle = '#a07a22'; x.lineWidth = 3; for (let r = 0; r < 5; r++) { x.beginPath(); x.arc(PX / 2, pi === 0 ? 2000 : 1700, 220 + r * 160, 0, Math.PI * 2); x.stroke(); } x.restore(); }
    function band(x, h) { const g = x.createLinearGradient(0, 0, PX, h); g.addColorStop(0, '#07060a'); g.addColorStop(0.55, '#15100a'); g.addColorStop(1, '#2a1d0c'); x.fillStyle = g; x.fillRect(0, 0, PX, h); x.save(); x.globalAlpha = 0.07; x.strokeStyle = '#f2d68a'; x.lineWidth = 1.4; for (let q = -h; q < PX; q += 26) { x.beginPath(); x.moveTo(q, h); x.lineTo(q + h * 0.6, 0); x.stroke(); } x.restore(); x.fillStyle = grad(x, 0, 0, PX, 0); x.fillRect(0, h, PX, 12); x.fillStyle = '#f6dc8c'; x.fillRect(0, h + 18, PX, 3); }
    function header(x) {
      band(x, HDR); let nx = M; if (logo) { const lh = Math.min(300, 520 * logo.height / logo.width), lw = lh * logo.width / logo.height; x.drawImage(logo, M, (HDR - lh) / 2, lw, lh); nx = M + lw + 60; }
      const lim = PX - M - 800 - nx; fit(x, legal, lim, 700, 66, SERIF, 42); x.textAlign = 'left'; x.fillStyle = sheen(x, nx, 120, nx + lim, 200); x.fillText(legal, nx, 180);
      let yy = 180; wrap(x, s.address || '', lim, 400, 27).slice(0, 2).forEach(l => { yy += 44; T(x, l, nx, yy, { size: 27, color: '#d8ccb0', maxW: lim }); }); if (s.phone) { yy += 44; T(x, '☎ ' + s.phone, nx, yy, { size: 27, color: '#d8ccb0' }); }
      const R = PX - M; x.save(); fit(x, 'SHAADI PACKAGE', 780, 700, 88, SERIF, 56); x.textAlign = 'right'; x.fillStyle = sheen(x, R - 780, 100, R, 200); x.fillText('SHAADI PACKAGE', R, 180); x.restore();
      T(x, 'विवाह आभूषण  ·  Bridal jewellery plan', R, 232, { align: 'right', size: 28, fam: HIN, color: '#d8ccb0' }); T(x, 'PACKAGE NO.', R, 340, { align: 'right', size: 24, color: '#bfb08c', ls: 3 }); T(x, w.no, R, 400, { align: 'right', size: 54, w: 700, color: '#fff' }); T(x, 'Banaya ' + fmtD(todayStr()), R, 452, { align: 'right', size: 27, color: '#e3d3a6' });
      return HDR + 21;
    }
    function contHeader(x, pi) { band(x, CONT); x.fillStyle = grad(x, M, 0, M + 1200, 0); fit(x, legal, 1300, 700, 56, SERIF); x.textAlign = 'left'; x.fillText(legal, M, 140); T(x, `SHAADI PACKAGE  ·  ${w.no}  ·  ${w.name}  ·  page ${pi + 1}`, PX - M, 140, { align: 'right', size: 30, color: '#e3d3a6', maxW: 1000 }); return CONT + 10; }
    function card(x, X, Y, W, H, dark) { rr(x, X, Y, W, H, 26); if (dark) { const g = x.createLinearGradient(X, Y, X + W, Y + H); g.addColorStop(0, '#120d06'); g.addColorStop(1, '#2b1c09'); x.fillStyle = g; x.fill(); x.lineWidth = 3; x.strokeStyle = '#c9a046'; x.stroke(); } else { x.fillStyle = C.cream; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke(); } }
    function infoCards(x, top) {
      const h = 320, lw = 980, gap = 34, w2 = (CW - lw - 2 * gap) / 2; card(x, M, top, lw, h);
      T(x, 'PARIVAAR', M + 46, top + 62, { size: 24, w: 700, color: C.goldT, ls: 3 }); T(x, w.name, M + 46, top + 132, { size: 54, w: 700, fam: SERIF, maxW: lw - 90 });
      let yy = top + 132; [[w.bride && 'Dulhan: ' + w.bride, w.groom && 'Dulha: ' + w.groom].filter(Boolean).join('   ·   '), [w.phone && 'Mobile ' + w.phone, w.city].filter(Boolean).join('  ·  ')].filter(Boolean).forEach(l => { yy += 50; T(x, l, M + 46, yy, { size: 29, color: '#3d362a', maxW: lw - 90 }); });
      const X2 = M + lw + gap; card(x, X2, top, w2, h); T(x, 'SHAADI', X2 + 40, top + 62, { size: 24, w: 700, color: C.goldT, ls: 3 });
      if (w.eventDate) { const d = parseD(w.eventDate), dl = wDays(w); T(x, String(d.getDate()), X2 + 40, top + 190, { size: 116, w: 700, fam: SERIF }); font(x, 700, 116, SERIF); const dw = x.measureText(String(d.getDate())).width; T(x, d.toLocaleDateString('en-IN', { month: 'long' }).toUpperCase(), X2 + 60 + dw, top + 136, { size: 30, w: 700, maxW: w2 - dw - 90 }); T(x, d.getFullYear() + ' · ' + d.toLocaleDateString('en-IN', { weekday: 'long' }), X2 + 60 + dw, top + 184, { size: 25, color: C.mut, maxW: w2 - dw - 90 }); T(x, dl > 0 ? dl + ' din baaki' : dl === 0 ? 'Aaj!' : 'Ho gayi', X2 + 40, top + 262, { size: 28, w: 700, color: C.goldT }); }
      else T(x, 'Tay hona baaki', X2 + 40, top + 170, { size: 40, w: 700, fam: SERIF, color: C.mut });
      if (w.needBy) T(x, 'Gehne: ' + fmtD(w.needBy) + ' tak', X2 + 40, top + 300, { size: 23, color: C.mut, maxW: w2 - 70 });
      const X3 = X2 + w2 + gap; card(x, X3, top, w2, h, true); T(x, 'ANDAAZA BILL', X3 + 40, top + 62, { size: 24, w: 700, color: '#d9b45a', ls: 3 });
      x.save(); fit(x, inr(c.total), w2 - 80, 700, 76, SERIF, 40); x.textAlign = 'left'; x.fillStyle = sheen(x, X3 + 40, top + 100, X3 + w2, top + 190); x.fillText(inr(c.total), X3 + 40, top + 170); x.restore();
      T(x, `Advance ${inr(c.cash)}${c.credit ? ' + purana ' + inr(c.credit) : ''}`, X3 + 40, top + 228, { size: 25, color: '#e9d7a5', maxW: w2 - 80 }); T(x, 'Baaki ≈ ' + inr(Math.max(0, c.balance)), X3 + 40, top + 276, { size: 30, w: 700, color: '#fff4d6', maxW: w2 - 80 });
      return top + h;
    }
    function secTitle(x, y, t2, sub) { T(x, t2, M, y + 56, { size: 28, w: 700, color: C.goldT, ls: 4 }); font(x, 700, 28); const tw = x.measureText(t2).width + 4 * t2.length; x.fillStyle = grad(x, M + tw + 30, 0, M + CW, 0); x.fillRect(M + tw + 30, y + 46, CW - tw - 30 - (sub ? 260 : 0), 3); if (sub) T(x, sub, M + CW, y + 56, { align: 'right', size: 24, color: C.mut }); }
    function itemCard(x, y, it, k, h, lines, nl) {
      x.save(); x.shadowColor = 'rgba(90,60,10,0.12)'; x.shadowBlur = 20; x.shadowOffsetY = 6; rr(x, M, y, CW, h, 24); x.fillStyle = '#fff'; x.fill(); x.restore(); rr(x, M, y, CW, h, 24); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      const sz = h - 60, px = M + 30, py = y + 30, im = pics[k].find(Boolean);
      x.save(); rr(x, px, py, sz, sz, 20); x.clip(); if (im) { const kk = Math.max(sz / im.naturalWidth, sz / im.naturalHeight); x.drawImage(im, px + (sz - im.naturalWidth * kk) / 2, py + (sz - im.naturalHeight * kk) / 2, im.naturalWidth * kk, im.naturalHeight * kk); } else { x.fillStyle = '#f3ead2'; x.fillRect(px, py, sz, sz); T(x, (it.name || 'S')[0].toUpperCase(), px + sz / 2, py + sz / 2 + 38, { align: 'center', size: 110, w: 700, fam: SERIF, color: '#d9c38c' }); } x.restore(); rr(x, px, py, sz, sz, 20); x.lineWidth = 4; x.strokeStyle = '#d4b062'; x.stroke();
      const more = pics[k].filter(Boolean).length - 1; if (more > 0) { pics[k].filter(Boolean).slice(1, 3).forEach((p2, j) => { const ts = 92, tx = px + sz - (j + 1) * (ts + 10), ty = py + sz - ts - 10; x.save(); rr(x, tx, ty, ts, ts, 12); x.clip(); const kk = Math.max(ts / p2.naturalWidth, ts / p2.naturalHeight); x.drawImage(p2, tx + (ts - p2.naturalWidth * kk) / 2, ty + (ts - p2.naturalHeight * kk) / 2, p2.naturalWidth * kk, p2.naturalHeight * kk); x.restore(); rr(x, tx, ty, ts, ts, 12); x.lineWidth = 3; x.strokeStyle = '#fff'; x.stroke(); }); }
      const tx = px + sz + 46; T(x, it.name, tx, y + 86, { size: 46, w: 700, fam: SERIF, maxW: TW }); let ly = y + 86;
      const chips = [`${MN(metalOf(it))} ${it.purity}`, num(it.qty) > 1 ? `${num(it.qty)} ${it.unit === 'Pairs' ? 'jodi' : it.unit === 'Sets' ? 'set' : 'pcs'}` : '', it.huid ? 'HUID ' + it.huid : ''].filter(Boolean); let cx = tx; ly += 26; chips.forEach((ch, j) => { font(x, 700, 23); const cw = x.measureText(ch).width + 40; rr(x, cx, ly, cw, 48, 24); x.fillStyle = j === 0 ? grad(x, cx, ly, cx + cw, ly + 48) : '#f6efdc'; x.fill(); T(x, ch, cx + cw / 2, ly + 33, { align: 'center', size: 23, w: 700, color: j === 0 ? '#1b1206' : '#5a4512' }); cx += cw + 12; }); ly += 48;
      lines.forEach(l => { ly += 36; T(x, l, tx, ly, { size: 26, color: '#2f291f', maxW: TW }); }); nl.forEach(l => { ly += 36; T(x, l, tx, ly, { size: 25, color: C.mut, maxW: TW }); });
      const R = M + CW - 40, mid = y + h / 2, rg = itRange(it);
      T(x, num(it.actualGross) ? 'ASLI WAZAN' : 'WAZAN (ANDAAZA)', R, mid - 70, { align: 'right', size: 22, w: 700, color: C.goldT, ls: 2 }); T(x, rg[0] === rg[1] ? g3(rg[0]) : g3(rg[0]) + ' – ' + g3(rg[1]), R, mid - 18, { align: 'right', size: 44, w: 700, fam: SERIF, maxW: 520 });
      const stc = { pending: '#8f8778', ordered: '#b7791f', making: '#b7791f', ready: '#2563eb', delivered: '#1d8a4c' }[it.status || 'pending']; const stl = it.billed ? 'BILL HO GAYA' : stName(it.status).toUpperCase(); font(x, 700, 22); const sw = x.measureText(stl).width + 44; rr(x, R - sw, mid + 18, sw, 48, 24); x.fillStyle = it.billed ? '#1d8a4c' : stc; x.fill(); T(x, stl, R - sw / 2, mid + 50, { align: 'center', size: 22, w: 700, color: '#fff', ls: 1 });
      if (it.due) T(x, 'Kab tak: ' + fmtD(it.due), R, mid + 104, { align: 'right', size: 23, color: C.mut });
    }
    function advTable(x, y, A) {
      const cols = [M + 30, M + 330, M + 1180, M + 1640, M + CW - 30]; rr(x, M, y + 10, CW, 64, 14); x.fillStyle = '#1f180c'; x.fill(); ['DATE', 'KYA', 'RAKAM / FINE', 'BHAV CUTTING'].forEach((h2, j) => T(x, h2, j === 2 ? cols[3] - 40 : cols[j], y + 52, { align: j === 2 ? 'right' : 'left', size: 22, w: 700, color: '#f2d68a', ls: 2 }));
      A.forEach((a, j) => { const yy = y + 74 + j * 62 + 42; if (j % 2) { x.fillStyle = '#faf4e4'; x.fillRect(M, yy - 40, CW, 62); } T(x, fmtD(a.date), cols[0], yy, { size: 26 }); T(x, a.type === 'metal' ? `Purana ${MN(a.metal.metal).toLowerCase()} ${a.metal.desc ? '(' + a.metal.desc + ') ' : ''}${g3(a.metal.gross)} @ ${a.metal.tunch}%` : `${a.mode || 'Cash'}${a.note ? ' · ' + a.note : ''}`, cols[1], yy, { size: 26, maxW: 820 }); T(x, a.type === 'metal' ? g3(a.metal.fine) + ' fine' : inr(a.amount), cols[3] - 40, yy, { align: 'right', size: 27, w: 700 }); T(x, a.lock && num(a.lock.fine) ? `${MN(a.lock.metal)} ${g3(a.lock.fine)} @ ₹${fmtAmt(a.lock.rate)}${rateUnit(a.lock.metal)}` : '—', cols[3], yy, { size: 25, color: a.lock ? '#1d6b3c' : C.mut, maxW: cols[4] - cols[3] }); });
    }
    function sumBox(x, y) {
      const Y = y + 30, H = 560, lw = 1080; card(x, M, Y, lw, H); T(x, 'KATA BHAV', M + 44, Y + 64, { size: 24, w: 700, color: C.goldT, ls: 3 });
      let yy = Y + 64; const lk = ['gold', 'silver'].map(m => ({ m, ...locks(w, m) })).filter(z => z.fine);
      if (!lk.length) { T(x, 'Abhi bhav nahi kata — bill ke din ka bhav lagega.', M + 44, yy + 70, { size: 28, color: C.mut, maxW: lw - 90 }); }
      lk.forEach(z => { yy += 92; T(x, `${MN(z.m)}: ${g3(z.fine)} fine`, M + 44, yy, { size: 40, w: 700, fam: SERIF }); T(x, `avg ₹${fmtAmt(z.rateG * (z.m === 'silver' ? 1000 : 10))}${rateUnit(z.m)} · aaj ₹${fmtAmt(showRate(z.m))} · bacha ${g3(z.free)}`, M + 44, yy + 44, { size: 25, color: C.mut, maxW: lw - 90 }); const dif = (todayG(z.m) - z.rateG) * z.free; T(x, (dif >= 0 ? 'Aaj tak bachat ' : 'Aaj se mehnga ') + inr(Math.abs(dif)), M + 44, yy + 84, { size: 27, w: 700, color: dif >= 0 ? '#1d6b3c' : C.red }); yy += 60; });
      const X2 = M + lw + 36, W2 = CW - lw - 36; card(x, X2, Y, W2, H, true); T(x, 'HISAAB (ANDAAZA)', X2 + 44, Y + 64, { size: 24, w: 700, color: '#d9b45a', ls: 3 });
      const rows = [['Sona + chandi', inr(c.gold.withLock + c.silver.withLock)], c.labour ? ['Labour', inr(c.labour)] : null, c.charges ? ['Stone + customisation', inr(c.charges)] : null, ['GST ' + c.gst + '%', inr(c.total - c.sub)], ['Kul', inr(c.total), 1], c.saving > 0.5 ? ['Bhav cutting se bachat', inr(c.saving)] : null, ['Advance', '− ' + inr(c.cashFree)], c.credit ? ['Purana sona / chandi', '− ' + inr(c.credit)] : null, ['Baaki', inr(Math.max(0, c.balance)), 1]].filter(Boolean);
      let ry = Y + 64; rows.forEach(([k2, v2, b]) => { ry += b ? 62 : 50; if (b) { x.fillStyle = 'rgba(242,214,138,.25)'; x.fillRect(X2 + 30, ry - 44, W2 - 60, 2); } T(x, k2, X2 + 44, ry, { size: b ? 32 : 27, w: b ? 700 : 400, color: b ? '#fff4d6' : '#e9d7a5', maxW: W2 - 400 }); T(x, v2, X2 + W2 - 44, ry, { align: 'right', size: b ? 38 : 28, w: 700, fam: b ? SERIF : undefined, color: b ? '#f6dc8c' : '#fff' }); });
      T(x, 'Final bill asli wazan par', X2 + 44, Y + H - 28, { size: 21, color: '#bfa970' });
    }
    function signBox(x, y) {
      const Y = y + 20, H = 290; rr(x, M, Y, CW, H, 24); x.fillStyle = '#fff'; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      const shop = ph10(s.phone); const qs = 190, qx = M + 50, qy = Y + 50; if (shop.length === 10) qrDraw(x, `https://wa.me/91${shop}?text=${encodeURIComponent('Namaste! Shaadi package ' + w.no + ' ke baare mein baat karni hai.')}`, qx, qy, qs, '#1a1206');
      T(x, 'Scan · WhatsApp', qx + qs / 2, qy + qs + 36, { align: 'center', size: 19, color: C.mut });
      T(x, 'Is plan par sahmati ke liye sign kijiye — badlav ke liye dukaan se baat kijiye.', qx + qs + 60, Y + 90, { size: 27, color: '#3d362a', maxW: CW - qs - 1100 });
      const R = M + CW - 60, sw = 440; x.strokeStyle = '#8f8778'; x.lineWidth = 2; x.beginPath(); x.moveTo(R - sw, Y + 200); x.lineTo(R, Y + 200); x.moveTo(R - 2 * sw - 60, Y + 200); x.lineTo(R - sw - 60, Y + 200); x.stroke();
      T(x, 'Parivaar ke hastakshar', R - 1.5 * sw - 60, Y + 240, { align: 'center', size: 23, color: C.mut }); T(x, 'For ' + legal, R - sw / 2, Y + 240, { align: 'center', size: 23, w: 700, color: C.goldT, maxW: sw + 30 });
    }
    function bottomStrip(x, pi) { const yb = PY - 92; x.fillStyle = '#0d0b07'; x.fillRect(0, yb, PX, 92); x.fillStyle = grad(x, 0, 0, PX, 0); x.fillRect(0, yb, PX, 5); T(x, 'शुभ विवाह  ·  Aapki khushiyon mein shaamil hone ke liye dhanyavaad', PX / 2, yb + 58, { align: 'center', size: 26, fam: HIN, color: '#f2d68a', maxW: PX - 2 * M - 700 }); T(x, w.no, M, yb + 58, { size: 21, color: '#a89a78' }); T(x, `Page ${pi + 1} of ${nP}`, PX - M, yb + 58, { align: 'right', size: 21, color: '#a89a78' }); }
  }

  /* ---------------- dashboard ---------------- */
  function dash() {
    const act = S.weddings.map(norm).filter(w => w.status !== 'done' && w.status !== 'cancelled'); const soon = act.map(w => ({ w, d: wDays(w) })).filter(x => x.d != null && x.d >= 0 && x.d <= 45 && (x.w.items || []).some(i => i.status !== 'delivered')).sort((a, b) => a.d - b.d);
    const late = act.flatMap(w => (w.items || []).filter(i => i.due && i.due < todayStr() && !['ready', 'delivered'].includes(i.status) && !i.billed).map(i => ({ w, i })));
    if (!soon.length && !late.length) return '';
    return `<div class="card"><div class="card-h"><h3>💍 Shaadi — dhyan dein</h3><button class="link" data-act="wd-go">Shaadi →</button></div>${soon.slice(0, 5).map(({ w, d }) => `<div class="row static" data-act="wd-open" data-id="${w.id}" role="button"><div><b>${esc(w.name)}</b> <span class="pill ${d <= 15 ? 'overdue' : ''}">${d === 0 ? 'Aaj' : d + ' din'}</span><div class="small muted">${esc(w.no)} · ${(w.items || []).filter(i => i.status !== 'delivered').length} gehne baaki · advance ${inr(advFree(w))}</div></div></div>`).join('')}${late.slice(0, 5).map(({ w, i }) => `<div class="row static" data-act="wd-open" data-id="${w.id}" role="button"><div><span class="red">⏰ ${esc(i.name)}</span> <span class="small muted">${esc(w.name)} · ${esc(i.karigar || 'karigar')} · ${fmtD(i.due)} tha</span></div></div>`).join('')}</div>`;
  }
  ACT['wd-go'] = () => { ui.wdOpen = ''; goTo('shaadi'); };
  { const V = VIEWDEF.dashboard; if (V && V.body) VIEWDEF.dashboard = { ...V, body() { let x = ''; try { x = dash(); } catch (e) { console.error(e); } return x + V.body.apply(V, arguments); } }; }
  // opening from the dashboard should land on the detail page
  const OPEN0 = ACT['wd-open']; ACT['wd-open'] = t => { if (view !== 'shaadi') { ui.wdOpen = t.dataset.id; ui.wdSec = 'gehne'; goTo('shaadi'); return; } OPEN0(t); };

  /* ---------------- AI ---------------- */
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    agentTools = function () {
      const L = T0.apply(this, arguments);
      if (!L.some(x => x.name === 'wedding_packages')) L.push({ name: 'wedding_packages', description: 'Shaadi (wedding) packages: customer, wedding date, days left, every item (metal, purity, weight, customisation, status, karigar, due, billed), advances (cash / old metal), bhav cutting (locked fine + rate + saving), estimated bill, balance.', inputSchema: { type: 'object', properties: { name: { type: 'string' } }, required: [] },
        execute: async a => { if (typeof setChatStatus === 'function') setChatStatus('Shaadi package dekh raha hoon…'); const q = String((a && a.name) || '').toLowerCase(); return S.weddings.map(norm).filter(w => !q || [w.name, w.no, w.bride, w.groom].some(x => String(x || '').toLowerCase().includes(q))).slice(0, 20).map(w => { const c = calc(w); return { no: w.no, name: w.name, eventDate: w.eventDate, daysLeft: wDays(w), status: w.status, budget: w.budget, estimateTotal: c.total, estimateAtToday: c.totalToday, saving: c.saving, cashAdvanceLeft: c.cashFree, oldMetalCredit: c.credit, balance: c.balance, lockedGold: locks(w, 'gold'), lockedSilver: locks(w, 'silver'), items: (w.items || []).map(i => ({ name: i.name, metal: metalOf(i), purity: i.purity, qty: i.qty, weight: itRange(i), custom: customTxt(i), status: i.billed ? 'billed ' + i.billNo : i.status, karigar: i.karigar, due: i.due, photos: photosOf(i).length })) }; }); } });
      return L;
    };
    if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { return R0.apply(this, arguments) + `\nSHAADI: wedding_packages for any shaadi / wedding / bhav cutting / "kitna advance" / "kaun sa gehna baaki" question. Screen "shaadi".`; }; }
  }

  addCss(`.wd-list .wd-card{cursor:pointer;display:flex;flex-direction:column;gap:10px}.wd-ch{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.wd-strip{display:flex;gap:6px;overflow:hidden}.wd-strip img{width:56px;height:56px;object-fit:cover;border-radius:10px;flex:none}
    .wd-st{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.wd-st div{border:1px solid var(--line,#3a2f1a);border-radius:10px;padding:6px 8px;min-width:0}.wd-st span{display:block;font-size:11px;opacity:.7}.wd-st b{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.wd-st small{display:block;font-size:11px}@media(max-width:560px){.wd-st{grid-template-columns:repeat(2,1fr)}}
    .wd-head .wd-date{text-align:center;border:1px solid var(--gold,#c9a046);border-radius:14px;padding:8px 14px;min-width:96px}.wd-date b{display:block;font:700 34px/1 Georgia,serif}.wd-date span{display:block;font-size:12px;opacity:.75}.wd-date i{display:block;font-style:normal;font-size:12px;color:var(--gold,#c9a046);font-weight:700;margin-top:2px}
    .wd-mh{margin:16px 0 8px}.wd-items{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,420px),1fr));gap:12px}.wd-it{display:flex;gap:12px;margin:0}.wd-it-ph{position:relative;flex:none;width:96px;height:96px}.wd-it-ph img,.wd-noph{width:96px;height:96px;object-fit:cover;border-radius:12px;display:grid;place-items:center;background:rgba(201,160,70,.12);font:700 34px Georgia,serif;color:var(--gold,#c9a046)}.wd-it-ph span{position:absolute;right:4px;bottom:4px;background:rgba(0,0,0,.65);color:#fff;font-size:11px;border-radius:8px;padding:1px 6px}
    .wd-it-b{flex:1;min-width:0;display:flex;flex-direction:column;gap:6px}.wd-stsel{max-width:150px;font-size:12px;padding:4px 6px}.wd-cz{display:flex;flex-wrap:wrap;gap:5px}.wd-cz span{font-size:11.5px;border:1px solid var(--line,#3a2f1a);border-radius:12px;padding:2px 8px}.wd-it.st-ready{border-color:#3b82f6}.wd-it.st-delivered{border-color:#22a35a}
    .wd-h4{margin:14px 0 6px}.wd-phs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:6px}.wd-phs div{position:relative}.wd-phs img{width:84px;height:84px;object-fit:cover;border-radius:10px}.wd-phs button{position:absolute;top:2px;right:2px;padding:0 6px}
    .wd-tpls{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:4px 12px}.wd-lock .wd-lk{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--line,#3a2f1a)}.wd-lk .right{text-align:right}
    .wd-hr{display:flex;justify-content:space-between;gap:10px;padding:6px 0;border-bottom:1px dashed var(--line,#3a2f1a)}.wd-hr.big b{font-size:18px}.wd-hr.green b{color:var(--green,#22a35a)}.wd-hr.red b{color:var(--red,#e05252)}.wd-bi{display:flex;gap:8px;padding:6px 0;align-items:flex-start}.wd-advs{display:flex;flex-direction:column;gap:10px}.wd-adv{display:flex;justify-content:space-between;gap:12px;margin:0}.wd-adv-l{min-width:0}.wd-adv-r{text-align:right;flex:none}.wd-lockchip{display:inline-block;margin-top:4px;border:1px solid var(--gold,#c9a046);border-radius:10px;padding:1px 8px}.wd-pre{white-space:pre-wrap;font:13px/1.5 inherit;background:rgba(201,160,70,.08);padding:10px;border-radius:10px}`);
  window.SJ_SHAADI = { calc, locks, packagePdf, norm, itFine, metalCredit };
})();
