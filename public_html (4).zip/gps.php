<?php
/* Shivaa Jewels — GPS receiver for car trackers / Traccar Client (OsmAnd protocol).
   Traccar Client → Server URL: https://YOUR-SITE/gps.php · Device identifier: the ID shown in Field → Gaadiyan & GPS */
$_GET['a'] = 'gps_push';
require __DIR__ . '/sj-api.php';
