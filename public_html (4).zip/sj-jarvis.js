/* =====================================================================
   Shivaa AI — "Jarvis" upgrade
   - website: talks to Google Gemini or Claude through sj-api.php with REAL tool use
     (the AI looks things up itself, chains several lookups, runs any report,
      queries every record type, calculates exactly, opens screens)
   - smarter rules, richer answers (tables, headings), proactive insight line
   - top-bar ✦ button: tap = open AI, press & hold = talk; Ctrl/⌘+J
   - Setup card: provider, auto model, key test with a time limit (never hangs)
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof agentTools !== 'function') return;
  const SITE = !!window.SJ_AI;
  const role = () => (window.SJ_USER || {}).role || 'owner';
  const F = (label, inner, cls) => `<label class="f${cls ? ' ' + cls : ''}"><span>${label}</span>${inner}</label>`;
  const q$ = (s, r) => (r || document).querySelector(s);
  const MAX_ROUNDS = 9, RES_MAX = 14000;
  const errOf = (code, msg) => { const e = new Error(msg || code); e.code = code; return e; };

  /* ---------------------------------------------------------------
     1. Website bridge: tool-use loop (the data stays in the browser;
        the AI asks for exactly what it needs, the browser answers)
     --------------------------------------------------------------- */
  const NOTSET = 'AI Assistant abhi chalu nahi hai. Owner ek baar **Setup & Backup → 🤖 AI Assistant** mein apni API key (Google Gemini free ya Claude) daal de — phir main har sawal ka jawab de sakta hoon.';
  function parseFinal(t) {
    t = String(t || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '').trim();
    const i = t.indexOf('{'), j = t.lastIndexOf('}');
    if (i >= 0 && j > i) { try { const o = JSON.parse(t.slice(i, j + 1)); if (o && typeof o === 'object') return o; } catch (e) { /* fall through */ } }
    if (!t) return { reply: 'Mujhe jawab nahi mila — sawal dobara poochiye.' };
    return { reply: t };
  }
  function friendlyErr(e) {
    const m = (e && e.message) || '', c = (e && e.code) || '';
    if (c === 'ai_key_bad' || /api key|authentication|invalid x-api-key/i.test(m)) return '⚠ AI key kaam nahi kar rahi (galat / band ho gayi). Owner: **Setup & Backup → 🤖 AI Assistant** mein key dobara daaliye.\n\n_' + m + '_';
    if (c === 'rate_limited') return '⏳ ' + (/limit/i.test(m) ? m : 'AI ki limit abhi khatam hai — 1-2 minute baad poochiye. (' + m + ')');
    if (c === 'timeout') return '⏳ AI ne samay par jawab nahi diya. Internet theek hai to sawal dobara poochiye (ya chhota karke).';
    if (c === 'prompt_too_large') return 'Sawal ke saath data bahut bada ho gaya — thoda seedha / chhota sawal poochiye (jaise ek party ya ek mahina).';
    if (c === 'login_required') return 'Login dobara kijiye, phir poochiye.';
    return '⚠ AI se jawab nahi aaya: ' + (m || 'connection problem') + '\n\nDobara try kijiye.';
  }
  /* things a tool wants shown under the answer (WhatsApp buttons, charts) — added by the browser, never retyped by the AI */
  const EXTRAS = [];
  window.SJX_EXTRA = m => { EXTRAS.push(String(m)); };
  function withExtras(o) {
    if (!o || typeof o !== 'object') return o;
    if (!EXTRAS.length) { if (typeof o.reply === 'string') o.reply = o.reply.replace(/\[\[(?:wa|chart)\|.*?\]\](?!\])/g, '').trimEnd(); return o; }   // buttons only ever come from the app's own tools
    let rep = String(o.reply || '').replace(/\[\[(?:wa|chart)\|.*?\]\](?!\])/g, '').trimEnd();
    rep += '\n\n' + EXTRAS.join('\n'); EXTRAS.length = 0; o.reply = rep; return o;
  }
  async function bridgeJson(input, opts) {
    opts = opts || {};
    const tools = Array.isArray(opts.tools) ? opts.tools : [];
    const decl = tools.map(t => ({ name: t.name, description: t.description, schema: t.inputSchema }));
    const msgs = input.map(m => ({ role: m.role, content: String(m.content || '') }));
    const img = typeof window.SJX_TAKE_IMG === 'function' ? window.SJX_TAKE_IMG() : null;   // photo attached in the chat (sj-2050.js)
    if (img) for (let k = msgs.length - 1; k >= 0; k--) if (msgs[k].role === 'user') { msgs[k].images = [{ mime: img.mime, data: img.b64 }]; break; }
    const memo = new Map();
    EXTRAS.length = 0;
    for (let round = 0; round < MAX_ROUNDS; round++) {
      if (opts.signal && opts.signal.aborted) throw errOf('cancelled');
      let r;
      try { r = await window.SJ_AI.ask({ messages: msgs, tools: decl, quick: opts.modelTier === 'quick' }); }
      catch (e) { if (opts.signal && opts.signal.aborted) throw errOf('cancelled'); return { reply: friendlyErr(e) }; }
      if (opts.signal && opts.signal.aborted) throw errOf('cancelled');
      if (!r || r.notSet) return { reply: NOTSET };
      if (Array.isArray(r.calls) && r.calls.length) {
        msgs.push({ role: 'assistant', raw: r.raw });
        const results = [];
        for (const c of r.calls) {
          const t = tools.find(x => x.name === c.name); let out;
          const args = c.args && typeof c.args === 'object' && !Array.isArray(c.args) ? c.args : {};
          const k = c.name + '|' + JSON.stringify(args);
          if (!t) out = { error: 'Unknown tool ' + c.name };
          else if (memo.has(k)) out = memo.get(k);
          else { try { out = await t.execute(args); } catch (e) { out = { error: String((e && e.message) || e) }; } memo.set(k, out); }
          let s; try { s = JSON.stringify(out === undefined ? { ok: true } : out); } catch (e) { s = '{"error":"result could not be read"}'; }
          if (s.length > RES_MAX) s = s.slice(0, RES_MAX) + '…[cut — ask with a narrower filter or smaller limit]';
          results.push({ id: c.id || '', name: c.name, result: s });
        }
        msgs.push({ role: 'tool', results });
        if (typeof setChatStatus === 'function') setChatStatus(round < 2 ? 'Soch raha hoon…' : 'Aur gehrai se dekh raha hoon… (' + (round + 1) + ')');
        continue;
      }
      return withExtras(parseFinal(r.text));
    }
    return { reply: 'Is sawal mein bahut saari cheezein dekhni padi aur jawab poora nahi ho paya — thoda chhota / seedha sawal poochiye.' };
  }
  if (SITE && typeof getSample === 'function') {
    const bridge = { limits: async () => ({ tools: true }), json: bridgeJson };
    getSample = function () { return Promise.resolve(bridge); };
    getLimits = function () { return Promise.resolve({ tools: true }); };
  }

  /* ---------------------------------------------------------------
     2. New tools
     --------------------------------------------------------------- */
  const clip = (v, d) => {
    if (v == null) return v;
    if (typeof v === 'string') return v.startsWith('data:') ? '[file]' : (v.length > 300 ? v.slice(0, 300) + '…' : v);
    if (typeof v !== 'object') return v;
    if (d > 3) return Array.isArray(v) ? '[' + v.length + ' items]' : '{…}';
    if (Array.isArray(v)) { const a = v.slice(0, 25).map(x => clip(x, d + 1)); if (v.length > 25) a.push('…+' + (v.length - 25) + ' more'); return a; }
    const o = {}; Object.keys(v).forEach(k => { if (/^(photo|photos|img|image|thumb|sig|signature|password|pass|hash|token|pinHash)$/i.test(k)) return; const x = clip(v[k], d + 1); if (x !== '' && x != null) o[k] = x; }); return o;
  };
  const DATE_KEYS = ['date', 'orderDate', 'issueDate', 'startDate', 'meltDate', 'paidDate', 'dueDate'];
  const getPath = (o, p) => String(p).split('.').reduce((a, k) => (a == null ? a : a[k]), o);
  const rowDate = (x, f) => { if (f) return String(getPath(x, f) || '').slice(0, 10); for (const k of DATE_KEYS) if (x[k]) return String(x[k]).slice(0, 10); return x.createdAt ? (typeof tsDate === 'function' ? tsDate(x.createdAt) : '') : ''; };
  const nrm = v => String(v == null ? '' : v).toLowerCase().trim();
  function matchWhere(x, where) {
    return Object.entries(where || {}).every(([k, cond]) => {
      const v = getPath(x, k);
      if (cond && typeof cond === 'object' && !Array.isArray(cond)) {
        const n = num(v);
        if (cond.gt != null && !(n > num(cond.gt))) return false; if (cond.gte != null && !(n >= num(cond.gte))) return false;
        if (cond.lt != null && !(n < num(cond.lt))) return false; if (cond.lte != null && !(n <= num(cond.lte))) return false;
        if (cond.ne != null && nrm(v) === nrm(cond.ne)) return false;
        if (cond.contains != null && !nrm(v).includes(nrm(cond.contains))) return false;
        if (cond.in && Array.isArray(cond.in) && !cond.in.map(nrm).includes(nrm(v))) return false;
        if (cond.exists != null && (!!(v !== '' && v != null) !== !!cond.exists)) return false;
        return true;
      }
      if (Array.isArray(cond)) return cond.map(nrm).includes(nrm(v));
      if (typeof cond === 'boolean') return !!v === cond;
      return nrm(v) === nrm(cond);
    });
  }
  function colList() { return (typeof COLS !== 'undefined' ? COLS : Object.keys(S)).filter(c => Array.isArray(S[c])); }
  function toolQuery(i) {
    const col = String(i.collection || '');
    if (!Array.isArray(S[col])) throw new Error('Unknown collection "' + col + '". Available: ' + colList().join(', '));
    const text = nrm(i.text);
    let L = S[col].filter(x => x && !x.deleted);
    let wh = i.where; if (typeof wh === 'string' && wh.trim()) { try { wh = JSON.parse(wh); } catch (e) { throw new Error('where must be JSON text like {"status":"open"}'); } }
    if (wh && typeof wh === 'object') L = L.filter(x => matchWhere(x, wh));
    if (validD(i.from) || validD(i.to)) L = L.filter(x => { const d = rowDate(x, i.dateField); return d && (!validD(i.from) || d >= i.from) && (!validD(i.to) || d <= i.to); });
    if (text) L = L.filter(x => { try { return JSON.stringify(x).toLowerCase().includes(text); } catch (e) { return false; } });
    const out = { collection: col, count: L.length };
    const sums = Array.isArray(i.sum) ? i.sum : (i.sum ? [i.sum] : []);
    if (sums.length) { out.totals = {}; sums.forEach(f => { out.totals[f] = r2(L.reduce((a, x) => a + num(getPath(x, f)), 0)); }); }
    if (i.groupBy) {
      const g = {}; L.forEach(x => { const k = String(getPath(x, i.groupBy) == null || getPath(x, i.groupBy) === '' ? '(blank)' : getPath(x, i.groupBy)).slice(0, 80); const a = g[k] || (g[k] = { count: 0 }); a.count++; sums.forEach(f => { a[f] = r2((a[f] || 0) + num(getPath(x, f))); }); });
      out.groups = Object.entries(g).map(([k, v]) => ({ key: k, ...v })).sort((a, b) => (sums[0] ? b[sums[0]] - a[sums[0]] : b.count - a.count)).slice(0, 60);
    }
    if (i.sortBy) { const f = i.sortBy, asc = !!i.asc; L = L.slice().sort((a, b) => { const x = getPath(a, f), y = getPath(b, f); const nx = num(x), ny = num(y); const c = (isFinite(nx) && isFinite(ny) && String(x).trim() !== '' && !/^\d{4}-/.test(String(x))) ? nx - ny : String(x || '').localeCompare(String(y || '')); return asc ? c : -c; }); }
    else L = L.slice().sort((a, b) => String(rowDate(b, i.dateField)).localeCompare(String(rowDate(a, i.dateField))) || num(b.createdAt) - num(a.createdAt));
    const lim = Math.min(80, Math.max(0, i.limit == null ? 25 : num(i.limit)));
    const fields = Array.isArray(i.fields) && i.fields.length ? i.fields : null;
    out.items = L.slice(0, lim).map(x => { if (!fields) return clip(x, 0); const o = { id: x.id }; fields.forEach(f => { o[f] = clip(getPath(x, f), 1); }); return o; });
    if (L.length > lim) out.more = L.length - lim;
    if (!L.length && S[col].length) out.hint = 'No match. Sample field names in ' + col + ': ' + Object.keys(S[col][0] || {}).slice(0, 40).join(', ');
    return out;
  }
  function toolSchema(i) {
    const col = String(i.collection || '');
    if (!Array.isArray(S[col])) return { collections: colList().map(c => ({ name: c, records: S[c].length })) };
    const keys = {}; S[col].slice(0, 200).forEach(x => Object.keys(x || {}).forEach(k => { if (!(k in keys)) { const v = x[k]; keys[k] = Array.isArray(v) ? 'list' : typeof v === 'object' && v ? 'object{' + Object.keys(v).slice(0, 12).join(',') + '}' : typeof v + (typeof v === 'string' && v.length < 40 && v ? ' e.g. ' + v : ''); } }));
    return { collection: col, records: S[col].length, fields: keys };
  }
  function cellTxt(v) { if (v == null) return ''; if (typeof v === 'number') return Math.round(v * 1000) / 1000; return String(v).replace(/<[^>]+>/g, '').slice(0, 120); }
  function toolRunReport(i) {
    if (!window.SJ_REPORTS) throw new Error('Report Centre not loaded');
    const list = window.SJ_REPORTS.list(); const id = String(i.id || '');
    const R = list.find(r => r.id === id) || list.find(r => nrm(r.t).includes(nrm(id)));
    if (!R) throw new Error('No report "' + id + '". Use one id from DATA.reportCatalogue.');
    let a, b, label;
    if (validD(i.from) || validD(i.to)) { a = validD(i.from) ? i.from : '2000-01-01'; b = validD(i.to) ? i.to : todayStr(); label = a + ' → ' + b; }
    else { const rr = rangeFor(i.period || 'month'); a = rr.a; b = rr.b; label = rr.label; }
    const x = window.SJ_REPORTS.build(R.id, a, b);
    if (!x) throw new Error('Report could not be built');
    const lim = Math.min(80, num(i.limit) || 40);
    return { report: R.id, title: R.t, period: label, from: a, to: b,
      summary: (x.summary || []).map(s => [cellTxt(s[0]), cellTxt(s[1])]),
      warn: x.warn ? cellTxt(x.warn) : undefined, note: x.note ? cellTxt(x.note) : undefined,
      sections: (x.sections || []).map(s => ({ title: s.title || '', columns: (s.cols || []).map(c => c.h), rows: (s.rows || []).slice(0, lim).map(r => Array.from(r).map(cellTxt)), totalRows: (s.rows || []).length, total: s.foot ? Array.from(s.foot).map(cellTxt) : undefined, note: s.note || undefined })) };
  }
  function screens() {
    const v = (typeof VIEWS !== 'undefined' ? VIEWS : []).map(x => [x[0], x[3] || x[1]]);
    Object.keys(VIEWDEF).forEach(k => { if (!v.some(x => x[0] === k)) v.push([k, k]); });
    return v;
  }
  function toolOpen(i) {
    if (i.reportId && window.SJ_REPORTS) { const R = window.SJ_REPORTS.list().find(r => r.id === i.reportId); if (!R) throw new Error('No report ' + i.reportId); setTimeout(() => window.SJ_REPORTS.open(R.id, i.period || ''), 600); return { ok: true, opened: 'report: ' + R.t }; }
    const s = nrm(i.screen); const hit = screens().find(x => x[0] === s) || screens().find(x => nrm(x[1]).includes(s) || s.includes(x[0]));
    if (!hit) throw new Error('Unknown screen. Screens: ' + screens().map(x => x[0]).join(', '));
    setTimeout(() => { if (typeof goTo === 'function') goTo(hit[0]); else location.hash = '#' + hit[0]; }, 600);
    return { ok: true, opened: hit[1] };
  }
  /* safe arithmetic parser (the page's security policy forbids eval) */
  function evalMath(src) {
    const s = String(src); let p = 0;
    const ws = () => { while (p < s.length && /\s/.test(s[p])) p++; };
    const numTok = () => { ws(); const m = /^\d+(?:\.\d+)?|^\.\d+/.exec(s.slice(p)); if (!m) throw new Error('Number expected at "' + s.slice(p, p + 8) + '"'); p += m[0].length; let v = parseFloat(m[0]); ws(); if (s[p] === '%') { p++; v /= 100; } return v; };
    const atom = () => { ws(); if (s[p] === '(') { p++; const v = expr(); ws(); if (s[p] !== ')') throw new Error('Missing )'); p++; ws(); if (s[p] === '%') { p++; return v / 100; } return v; } if (s[p] === '-') { p++; return -atom(); } if (s[p] === '+') { p++; return atom(); } return numTok(); };
    const pow = () => { const b = atom(); ws(); if (s[p] === '*' && s[p + 1] === '*') { p += 2; return Math.pow(b, unary()); } return b; };
    const unary = () => { ws(); if (s[p] === '-') { p++; return -unary(); } return pow(); };
    const term = () => { let v = unary(); for (;;) { ws(); if (s[p] === '*' && s[p + 1] !== '*') { p++; v *= unary(); } else if (s[p] === '/') { p++; const d = unary(); if (d === 0) throw new Error('Division by zero'); v /= d; } else return v; } };
    const expr = () => { let v = term(); for (;;) { ws(); if (s[p] === '+') { p++; v += term(); } else if (s[p] === '-') { p++; v -= term(); } else return v; } };
    const v = expr(); ws(); if (p < s.length) throw new Error('Unexpected "' + s.slice(p, p + 8) + '"'); return v;
  }
  function toolCalc(i) {
    const ex = String(i.expression || '').replace(/[₹,]/g, '').replace(/×/g, '*').replace(/÷/g, '/').replace(/\^/g, '**').replace(/(\d|\))\s*[xX]\s*(?=[\d(])/g, '$1*');
    if (!ex.trim()) throw new Error('Expression is empty');
    const v = evalMath(ex);
    if (typeof v !== 'number' || !isFinite(v)) throw new Error('Not a valid calculation');
    return { expression: i.expression, result: Math.round(v * 10000) / 10000, inr: typeof inr === 'function' ? inr(v) : undefined };
  }
  function toolInsights() {
    const t = todayStr(), out = [];
    try {
      const cust = S.invoices.filter(v => !isBuy(v.type));
      const days = n => S.invoices.filter(v => isSaleT(v.type) && v.date >= addDays(t, -n) && v.date < t);
      const avg30 = sum(days(30), v => v.totals && v.totals.grand) / 30, today = sum(S.invoices.filter(v => isSaleT(v.type) && v.date === t), v => v.totals && v.totals.grand);
      out.push({ k: 'salesToday', today: Math.round(today), avgPerDayLast30: Math.round(avg30) });
      const buckets = { '0-30': 0, '31-60': 0, '61-90': 0, '90+': 0 };
      cust.forEach(v => { const d = invDue(v); if (d <= 0.5) return; const age = Math.floor((Date.parse(t) - Date.parse(v.date)) / 864e5); buckets[age <= 30 ? '0-30' : age <= 60 ? '31-60' : age <= 90 ? '61-90' : '90+'] += d; });
      Object.keys(buckets).forEach(k => buckets[k] = Math.round(buckets[k])); out.push({ k: 'receivableAgeing', buckets });
      const sinceLast = S.customers.map(c => { const l = custInvoices(c.id).map(v => v.date).sort().pop(); return l ? { name: c.name, last: l, days: Math.floor((Date.parse(t) - Date.parse(l)) / 864e5) } : null; }).filter(x => x && x.days > 45).sort((a, b) => a.days - b.days).slice(0, 10);
      out.push({ k: 'customersNotBoughtFor45Days', list: sinceLast });
      const st = settings(); out.push({ k: 'ratesUpdatedToday', ok: st.ratesUpdated === t });
      if (typeof dailyTasks === 'function') out.push({ k: 'tasks', list: dailyTasks().slice(0, 12).map(x => x.text + (x.sub ? ' — ' + x.sub : '')) });
      if (Array.isArray(S.loans)) out.push({ k: 'loans', open: S.loans.filter(l => !l.deleted && l.status !== 'Closed').length });
    } catch (e) { out.push({ error: String(e.message || e) }); }
    return out;
  }
  const NEW_TOOLS = [
    ['query_data', 'Query ANY record type in the software (see DATA.collections): customers, suppliers, products (vault stock), invoices (all bills incl. bullion purchases — invoice.bullion), orders, jobs, expenses, banktx, schemes, loans, agents, influencers, payouts, meltLots, kachaRecs, attachments, approvals, leads, notes, audit, rateHistory, fixedAssets, etc. Filters: text (search anywhere), where {field: value | [values] | {gt,gte,lt,lte,ne,contains,in,exists}} (dot paths like "totals.grand" ok), from/to (YYYY-MM-DD on the record date, or dateField). Aggregate: sum (field or list of fields) and groupBy field. sortBy + asc, limit (default 25, max 80, 0 = only totals), fields (list) to return only some fields. Use describe_data first if unsure of field names.',
      { collection: { type: 'string' }, text: { type: 'string' }, where: { type: 'string', description: 'JSON text of field conditions, e.g. {"status":"Active","totals.grand":{"gt":50000},"type":["sale","estimate"]}' }, from: { type: 'string' }, to: { type: 'string' }, dateField: { type: 'string' }, sum: { type: 'array', items: { type: 'string' } }, groupBy: { type: 'string' }, sortBy: { type: 'string' }, asc: { type: 'boolean' }, limit: { type: 'number' }, fields: { type: 'array', items: { type: 'string' } } }, ['collection'], toolQuery, 'Records dekh raha hoon…'],
    ['describe_data', 'Field names (with examples) of one collection, or the list of all collections with record counts when collection is empty.', { collection: { type: 'string' } }, [], toolSchema, 'Data samajh raha hoon…'],
    ['run_report', 'Run any professional report from DATA.reportCatalogue for a period and get its summary, columns and rows (sales/purchase registers, day book, GST, CA pack sheets, stock, ageing, P&L, balance sheet, loans, EMI, bullion purchase, melting, agents, influencers, payouts…). period: today, yesterday, week, 7, month, lastmonth, 30, 90, fy, lastfy, 365, all — or exact from/to.',
      { id: { type: 'string', description: 'report id from DATA.reportCatalogue' }, period: { type: 'string' }, from: { type: 'string' }, to: { type: 'string' }, limit: { type: 'number' } }, ['id'], toolRunReport, 'Report chala raha hoon…'],
    ['calculate', 'Exact arithmetic. ALWAYS use it for totals, differences, %, interest, EMI, fine gold (net × tunch / 100), rate conversions. Supports + - * / ( ) ^ and 3% style percent.', { expression: { type: 'string' } }, ['expression'], toolCalc, 'Hisaab laga raha hoon…'],
    ['open_screen', 'Open a screen of the software for the owner (when they say kholo / dikhao / open / le chalo), or a report from the Report Centre (reportId + optional period).', { screen: { type: 'string', description: 'screen id: ' + 'see DATA.screens' }, reportId: { type: 'string' }, period: { type: 'string' } }, [], toolOpen, 'Screen khol raha hoon…'],
    ['business_insights', 'Jarvis health-check: today vs 30-day average sales, receivable ageing buckets, customers who stopped buying, whether rates are updated, today\'s tasks, open loans. Use for "kya dhyan dena hai", "business kaisa chal raha hai", morning plan.', {}, [], toolInsights, 'Business ki nabz dekh raha hoon…']
  ];
  const A0 = agentTools;
  agentTools = function () {
    const base = A0.apply(this, arguments);
    NEW_TOOLS.forEach(([name, description, props, req, fn, label]) => {
      if (base.some(t => t.name === name)) return;
      base.push({ name, description, inputSchema: { type: 'object', properties: props, required: req }, execute: async input => { if (typeof setChatStatus === 'function') setChatStatus(label); return fn(input || {}); } });
    });
    return base;
  };

  /* ---------------------------------------------------------------
     3. Smarter brain: extra knowledge + Jarvis rules
     --------------------------------------------------------------- */
  const D0 = agentData;
  agentData = function (compact) {
    const d = D0.apply(this, arguments);
    try {
      d.collections = Object.fromEntries(colList().map(c => [c, S[c].length]));
      if (window.SJ_REPORTS) d.reportCatalogue = window.SJ_REPORTS.list().map(r => r.id + ': ' + r.t);
      d.screens = screens().map(x => x[0] + ' (' + x[1] + ')');
      d.nowTime = new Date().toTimeString().slice(0, 5);
      d.weekday = new Date().toLocaleDateString('en-IN', { weekday: 'long' });
    } catch (e) { console.error(e); }
    return d;
  };
  const R0 = agentRules;
  agentRules = function (o) {
    return R0.apply(this, arguments) + `

JARVIS MODE — you are the owner's personal "Jarvis": a brilliant munim, CA, business analyst and operator in one. Calm, sharp, loyal, a little witty, always respectful (call the owner "${(VOICE && VOICE.name) || 'Karan'} ji" sometimes).
UNDERSTAND: work out what the owner really means — half sentences, Hinglish, spelling or voice-typing mistakes ("baalaji" = Balaji, "das gram" = 10 g, "pichle mahine" = last month, "kitna baki" = dues). If one sensible meaning exists, act on it. Ask only when it is truly ambiguous, and then offer the 2-3 likely options.
FACTS FIRST: never invent a number, name or record. Get every fact from DATA or the tools.${o && o.tools ? `
TOOLS — use them freely and chain them (2-6 calls is normal):
- query_data reaches EVERY record type (DATA.collections). Use where / from / to / sum / groupBy to compute exact answers (e.g. loans with status open and sum of principal; payouts groupBy influencerName; invoices where type=purchase and bullion exists).
- describe_data tells you field names when unsure.
- run_report runs any report in DATA.reportCatalogue (id: title) — best for registers, GST, CA, stock, ageing, P&L, loans, EMI, bullion, melting, agents.
- calculate for ALL arithmetic (totals, %, interest, EMI, fine = net × tunch ÷ 100, rate per gram = rate per 10 g ÷ 10). Quote its result, do not do maths in your head.
- open_screen when the owner says kholo / dikhao / open / le chalo (also for reports).
- business_insights for "business kaisa chal raha hai", morning plan, "kya dhyan dena hai".
- If a tool says no match, try a looser search (text, part of the name) before saying it is not there.` : ''}
ANSWER STYLE: lead with the direct answer and the key number in **bold** in the first line. Then the details as short "- " bullets, or a small markdown table (| col | col |) when comparing several rows. Use ### for a heading only in long reports. Indian formats: ₹1,23,456, lakh / crore, fine gold in grams with 3 decimals. Keep it tight — the owner is busy.
PROACTIVE: after the answer, add at most ONE line starting with "💡" with the most useful next insight, risk or action you noticed in the data (overdue money, a customer who stopped buying, stock running low, rates not updated, unusual drop). Skip it if nothing is genuinely useful. In [voice] replies keep "speak" short and do not read tables aloud.
LIMITS: you cannot browse the internet or see live market rates — only the rates saved in the app. Say so honestly if asked.`;
  };

  /* richer answer formatting: tables, headings, italics, code */
  const MD0 = mdLite;
  mdLite = function (t) {
    t = String(t == null ? '' : t);
    if (!/(^|\n)\s*\|.*\|\s*(\n|$)|(^|\n)#{1,4}\s|`|_[^_\s][^_]*_/.test(t)) return MD0(t);
    const inline = h => h.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>').replace(/(^|[\s(])_([^_]+)_(?=[\s).,!?]|$)/g, '$1<i>$2</i>');
    const lines = t.split('\n'); let out = '', buf = [];
    const flush = () => { if (buf.length) { out += MD0(buf.join('\n')).replace(/<code>/g, '<code>'); buf = []; } };
    for (let k = 0; k < lines.length; k++) {
      const l = lines[k];
      if (/^\s*\|.*\|\s*$/.test(l) && k + 1 < lines.length && /^\s*\|?\s*:?-{2,}/.test(lines[k + 1])) {
        flush(); const cells = s => s.trim().replace(/^\||\|$/g, '').split('|').map(c => inline(esc(c.trim())));
        const head = cells(l); k += 1; const body = [];
        while (k + 1 < lines.length && /^\s*\|.*\|\s*$/.test(lines[k + 1])) { k++; body.push(cells(lines[k])); }
        const isN = c => /^[-₹\s\d,.%+gk()]+$/.test(c.replace(/<[^>]+>/g, '')) && /\d/.test(c);
        out += `<div class="sjx-tw"><table class="sjx-t"><tr>${head.map(h => `<th>${h}</th>`).join('')}</tr>${body.map(r => `<tr>${r.map(c => `<td class="${isN(c) ? 'n' : ''}">${c}</td>`).join('')}</tr>`).join('')}</table></div>`;
        continue;
      }
      const h = /^\s*(#{1,4})\s+(.*)$/.exec(l);
      if (h) { flush(); out += `<div class="sjx-h">${inline(esc(h[2]))}</div>`; continue; }
      buf.push(l);
    }
    flush();
    return out.replace(/`([^`<]+)`/g, '<code>$1</code>').replace(/(^|[\s(>])_([^_<]+)_(?=[\s).,!?<]|$)/g, '$1<i>$2</i>');
  };

  /* smarter suggestions + greeting */
  try {
    SUGGESTIONS.splice(0, SUGGESTIONS.length, 'Business kaisa chal raha hai?', 'Aaj ka plan batao', 'Kiska payment sabse zyada baaki hai?', 'Is mahine bullion kitna kharida?', 'Loans ki agli EMI kab hai?', 'Bill banana hai');
  } catch (e) { /* older build */ }
  if (typeof greeting === 'function') {
    greeting = function () { const hi = VOICE.lang === 'hi-IN'; const nm = VOICE.name; const h = new Date().getHours(); const part = h < 12 ? 'Suprabhat' : h < 17 ? 'Namaste' : 'Shubh sandhya';
      return { text: `${part}${nm ? ' ' + nm + ' ji' : ''}! Shivaa AI haazir hai. Hisaab, report, party, stock, loan, bullion — kuch bhi poochiye, ya boliye "bill banao".`, speak: hi ? `${part}${nm ? ' ' + nm + ' जी' : ''}। शिवा AI हाज़िर है। बोलिए, क्या करना है?` : `${part}${nm ? ' ' + nm : ''}. Shivaa AI at your service. What do you need?` }; };
  }

  /* ---------------------------------------------------------------
     4. Jarvis button: top-bar ✦ (tap = AI, hold = talk) + Ctrl/⌘+J
     --------------------------------------------------------------- */
  const css = document.createElement('style');
  css.textContent = `[data-act="go-ai"].hdr-btn{position:relative;color:#f0cf74;box-shadow:0 0 0 1px rgba(240,207,116,.35),0 0 14px rgba(240,207,116,.25);animation:sjxPulse 3.4s ease-in-out infinite;touch-action:manipulation;-webkit-touch-callout:none;user-select:none}
    [data-act="go-ai"].sjx-live{box-shadow:0 0 0 3px rgba(240,207,116,.7),0 0 22px rgba(240,207,116,.6)}
    @keyframes sjxPulse{0%,100%{box-shadow:0 0 0 1px rgba(240,207,116,.35),0 0 10px rgba(240,207,116,.18)}50%{box-shadow:0 0 0 1px rgba(240,207,116,.55),0 0 18px rgba(240,207,116,.4)}}
    @media (prefers-reduced-motion:reduce){[data-act="go-ai"].hdr-btn{animation:none}}
    .sjx-tw{overflow-x:auto;margin:6px 0}.sjx-t{border-collapse:collapse;font-size:13px;min-width:60%}.sjx-t th,.sjx-t td{padding:4px 8px;border-bottom:1px solid var(--line,#3a2f1a);text-align:left;vertical-align:top}.sjx-t th{font-weight:600;opacity:.85}.sjx-t td.n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
    .sjx-h{font-weight:700;margin:8px 0 2px;color:var(--gold,#e6c25e)} .bub code{font-size:12px;padding:1px 5px;border-radius:5px;background:rgba(127,127,127,.15)}
    .sjx-timer{font-variant-numeric:tabular-nums;opacity:.8}`;
  document.head.appendChild(css);
  function openAI(voice) {
    const go = () => { const box = q$('#chat-q'); if (voice && typeof voiceStart === 'function') { if (!VOICE.on) voiceStart(); } else if (box) { try { box.focus({ preventScroll: true }); } catch (e) { box.focus(); } } };
    if ((location.hash || '').replace('#', '') === 'assistant') go(); else { if (typeof goTo === 'function') goTo('assistant'); else location.hash = '#assistant'; setTimeout(go, 500); }
  }
  /* the ✦ "Ask AI" button in the top bar (every screen, phone & computer): tap = open AI, press & hold = start talking */
  let lpTimer = null, lpFired = false;
  window.addEventListener('pointerdown', e => { const b = e.target.closest && e.target.closest('[data-act="go-ai"]'); if (!b) return; lpFired = false; clearTimeout(lpTimer); lpTimer = setTimeout(() => { lpFired = true; b.classList.add('sjx-live'); setTimeout(() => b.classList.remove('sjx-live'), 1200); openAI(true); }, 550); }, true);
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => window.addEventListener(ev, () => clearTimeout(lpTimer), true));
  window.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-act="go-ai"]'); if (b && lpFired) { e.preventDefault(); e.stopPropagation(); lpFired = false; } }, true);
  window.addEventListener('contextmenu', e => { if (e.target.closest && e.target.closest('[data-act="go-ai"]')) e.preventDefault(); }, true);
  function tagAiBtn() { document.querySelectorAll('[data-act="go-ai"]').forEach(b => { if (b.dataset.sjx) return; b.dataset.sjx = '1'; b.title = 'Shivaa AI — tap: poochiye · dabaye rakhiye: boliye (Ctrl+J)'; }); }
  document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && !e.shiftKey && !e.altKey && (e.key === 'j' || e.key === 'J')) { e.preventDefault(); openAI(false); } });
  setInterval(tagAiBtn, 1500); tagAiBtn();

  /* ---------------------------------------------------------------
     5. Setup card: provider, model, key test with a visible timer (never hangs)
     --------------------------------------------------------------- */
  /* ---------------------------------------------------------------
     6. v18 — more powers: WhatsApp drafts, charts, forecast, collection plan
     --------------------------------------------------------------- */
  const enc = x => encodeURIComponent(String(x == null ? '' : x)).replace(/\|/g, '%7C').replace(/\]/g, '%5D');
  function findParty(q) {
    const t = nrm(q), ph = cleanPhone(q);
    const all = S.customers.map(c => ({ c, kind: 'customer' })).concat((S.suppliers || []).map(c => ({ c, kind: 'supplier' })));
    let L = all.filter(x => x.c.id === q);
    if (!L.length && ph.length === 10) L = all.filter(x => cleanPhone(x.c.phone) === ph);
    if (!L.length && t) L = all.filter(x => nrm(x.c.name) === t);
    if (!L.length && t) L = all.filter(x => nrm(x.c.name).includes(t) || t.split(/\s+/).filter(w => w.length > 2).every(w => nrm(x.c.name + ' ' + (x.c.city || '') + ' ' + (x.c.shop || '')).includes(w)));
    return L;
  }
  function partyDue(c) { return r2(sum(custInvoices(c.id), v => invDue(v))); }
  function toolWhatsApp(i) {
    const L = findParty(i.party || '');
    if (!L.length) throw new Error('No party found for "' + i.party + '". Search with customer_profile / query_data first.');
    if (L.length > 1 && !L.some(x => nrm(x.c.name) === nrm(i.party))) return { needChoice: true, candidates: L.slice(0, 6).map(x => ({ id: x.c.id, name: x.c.name, city: x.c.city || '' })) };
    const p = (L.find(x => nrm(x.c.name) === nrm(i.party)) || L[0]).c;
    const msg = String(i.message || '').trim(); if (!msg) throw new Error('message is empty');
    const url = waUrl(p.phone, msg);
    if (!url) return { error: p.name + ' ka mobile number software mein nahi hai (ya galat hai). Party mein number daaliye.' };
    EXTRAS.push('[[wa|' + cleanPhone(p.phone) + '|' + enc(msg) + '|' + enc(p.name) + ']]');
    return { ok: true, to: p.name, note: 'A WhatsApp button with this exact message will appear under your reply automatically. Tell the owner to check and tap it. Do NOT repeat the full message.' };
  }
  function toolChart(i) {
    const labels = Array.isArray(i.labels) ? i.labels : [], vals = Array.isArray(i.values) ? i.values.map(num) : [];
    const n = Math.min(labels.length, vals.length, 24); if (n < 2) throw new Error('Need at least 2 labels with values');
    EXTRAS.push('[[chart|' + enc(i.title || '') + '|' + enc(i.unit || '') + '|' + labels.slice(0, n).map((l, k) => enc(l) + '=' + vals[k]).join(';') + ']]');
    return { ok: true, note: 'The chart will appear under your reply automatically. Do not draw it with text.' };
  }
  function toolForecast() {
    const t = todayStr(), ms = t.slice(0, 8) + '01';
    const daySales = d => sum(S.invoices.filter(v => isSaleT(v.type) && v.date === d), v => v.totals && v.totals.grand);
    const dim = new Date(+t.slice(0, 4), +t.slice(5, 7), 0).getDate(), dayNo = +t.slice(8, 10);
    const soFar = sum(S.invoices.filter(v => isSaleT(v.type) && v.date >= ms && v.date <= t), v => v.totals && v.totals.grand);
    const pts = []; for (let k = 89; k >= 1; k--) pts.push(daySales(addDays(t, -k)));
    const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0;
    const avg7 = avg(pts.slice(-7)), avg30 = avg(pts.slice(-30)), avg90 = avg(pts);
    const n = pts.length, xm = (n - 1) / 2, ym = avg90; let sxy = 0, sxx = 0; pts.forEach((y, x) => { sxy += (x - xm) * (y - ym); sxx += (x - xm) * (x - xm); });
    const slope = sxx ? sxy / sxx : 0;
    const daysLeft = dim - dayNo; const rate = avg30 * 0.6 + avg7 * 0.4;
    const proj = soFar + Math.max(0, rate) * daysLeft;
    const lmEnd = addDays(ms, -1), lmStart = lmEnd.slice(0, 8) + '01', lmSame = lmStart.slice(0, 8) + String(Math.min(dayNo, +lmEnd.slice(8, 10))).padStart(2, '0');
    const lastMonth = sum(S.invoices.filter(v => isSaleT(v.type) && v.date >= lmStart && v.date <= lmEnd), v => v.totals && v.totals.grand);
    const lastMonthSamePoint = sum(S.invoices.filter(v => isSaleT(v.type) && v.date >= lmStart && v.date <= lmSame), v => v.totals && v.totals.grand);
    const wd = [0, 0, 0, 0, 0, 0, 0], wc = [0, 0, 0, 0, 0, 0, 0]; pts.forEach((y, k) => { const d = new Date(addDays(t, -(89 - k))).getDay(); wd[d] += y; wc[d]++; });
    const names = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return { month: ms.slice(0, 7), salesSoFar: Math.round(soFar), dayOfMonth: dayNo, daysLeft, avgPerDay: { last7: Math.round(avg7), last30: Math.round(avg30), last90: Math.round(avg90) },
      projectedMonthTotal: Math.round(proj), lastMonthTotal: Math.round(lastMonth), lastMonthSamePoint: Math.round(lastMonthSamePoint),
      trendPerDay: Math.round(slope), trend: slope > avg90 * 0.01 ? 'up' : slope < -avg90 * 0.01 ? 'down' : 'flat',
      bestWeekday: wd.some(v => v > 0) ? names[wd.map((v, k) => wc[k] ? v / wc[k] : 0).reduce((b, v, k, a) => v > a[b] ? k : b, 0)] : null,
      dataNote: avg90 ? undefined : 'No sales in the last 90 days before today — projection is only today\'s sales.',
      method: 'Projection = sales so far + (0.6×30-day avg + 0.4×7-day avg) × days left. A rough guide, not a promise.' };
  }
  function toolCollect(i) {
    const t = todayStr(), lim = Math.min(25, num(i.limit) || 10);
    const L = S.customers.map(c => { const bills = custInvoices(c.id).filter(v => invDue(v) > 0.5); if (!bills.length) return null;
      const due = sum(bills, v => invDue(v)); const oldest = bills.map(v => v.date).sort()[0]; const age = Math.floor((Date.parse(t) - Date.parse(oldest)) / 864e5);
      const pays = custInvoices(c.id).flatMap(v => invPayments(v)).map(p => p.date).filter(Boolean).sort(); const lastPay = pays[pays.length - 1] || '';
      return { id: c.id, name: c.name, city: c.city || '', due: Math.round(due), bills: bills.length, oldestBill: oldest, ageDays: age, lastPayment: lastPay, hasPhone: cleanPhone(c.phone).length === 10, score: Math.round(due * (1 + age / 30)) }; }).filter(Boolean).sort((a, b) => b.score - a.score);
    return { totalDue: Math.round(sum(L, x => x.due)), parties: L.length, callFirst: L.slice(0, lim), tip: 'Priority = baaki × (1 + din/30). For reminders use whatsapp_draft (one per party, polite Hinglish, mention amount and oldest bill date).' };
  }
  NEW_TOOLS.push(
    ['whatsapp_draft', 'Prepare a WhatsApp message to a customer or supplier (payment reminder, thank-you, order ready, rate update, festival wish…). Finds the party and its number in the software; a ready "send" button appears under your reply — the owner taps it to send. Write the message in polite Hinglish, signed "— Shivaa Jewels". One call per party.',
      { party: { type: 'string', description: 'party name, phone or id' }, message: { type: 'string' } }, ['party', 'message'], toolWhatsApp, 'WhatsApp message bana raha hoon…'],
    ['make_chart', 'Show a bar chart under your reply (trends by month/day, comparisons of parties, products, categories). Use when 3+ numbers are compared.',
      { title: { type: 'string' }, unit: { type: 'string', description: 'e.g. ₹ or g' }, labels: { type: 'array', items: { type: 'string' } }, values: { type: 'array', items: { type: 'number' } } }, ['labels', 'values'], toolChart, 'Chart bana raha hoon…'],
    ['sales_forecast', 'Projection of this month\'s sales total, 7/30/90-day daily averages, trend (up/down), best weekday and last-month comparison. Use for "kitni sale hogi", "target poora hoga?", "trend kaisa hai".', {}, [], toolForecast, 'Aage ka andaaza laga raha hoon…'],
    ['collection_plan', 'Who to ask for money today: customers with dues ranked by amount × age, with oldest bill, last payment and whether a phone number exists.', { limit: { type: 'number' } }, [], toolCollect, 'Vasooli ki list bana raha hoon…']
  );
  const R1 = agentRules;
  agentRules = function (o) {
    return R1.apply(this, arguments) + (o && o.tools ? `
THINK LIKE AN EXPERT: for any non-trivial question, silently plan which facts you need, fetch them, then CROSS-CHECK (rows add up to the total, two sources agree, dates are inside the period). If something does not add up, say so plainly. Mention the period you used.
MORE TOOLS: whatsapp_draft when the owner says message / remind / bhejo / yaad dilao to a party (the button appears automatically — never print phone numbers or wa.me links yourself). make_chart when comparing 3+ numbers or showing a trend. sales_forecast for future / target questions. collection_plan for "paisa kisse maangu / vasooli".` : '');
  };
  /* render [[wa|…]] and [[chart|…]] inside answers */
  const MD1 = mdLite;
  mdLite = function (t) {
    t = String(t == null ? '' : t); const parts = [];
    t = t.replace(/\[\[(wa|chart)\|([^\]]*)\]\]/g, (m, k, body) => { parts.push([k, body.split('|')]); return '\n@@SJX' + (parts.length - 1) + '@@\n'; });
    let h = MD1(t);
    const dec = x => { try { return decodeURIComponent(x || ''); } catch (e) { return x || ''; } };
    return h.replace(/@@SJX(\d+)@@/g, (m, n) => {
      const [k, a] = parts[+n];
      if (k === 'wa') { const msg = dec(a[1]), name = dec(a[2]), url = waUrl(a[0], msg);
        return url ? `<div class="sjx-wa"><div class="sjx-wa-h">📲 WhatsApp → <b>${esc(name)}</b></div><div class="sjx-wa-m">${esc(msg).replace(/\n/g, '<br>')}</div><a class="btn sm green" href="${esc(url)}" target="_blank" rel="noopener">WhatsApp par bhejo ↗</a></div>` : ''; }
      const title = dec(a[0]), unit = dec(a[1]); const pts = String(a[2] || '').split(';').map(x => { const j = x.lastIndexOf('='); return [dec(x.slice(0, j)), num(x.slice(j + 1))]; }).filter(x => x[0] !== '');
      const mx = Math.max(1, ...pts.map(p => Math.abs(p[1])));
      const fmt = v => unit === '₹' || unit === 'Rs' || unit === 'INR' ? inr(v) : (Math.round(v * 1000) / 1000).toLocaleString('en-IN') + (unit ? ' ' + esc(unit) : '');
      return `<div class="sjx-ch">${title ? `<div class="sjx-ch-t">${esc(title)}</div>` : ''}${pts.map(p => `<div class="sjx-ch-r"><span class="sjx-ch-l" title="${esc(p[0])}">${esc(p[0])}</span><span class="sjx-ch-b"><i style="width:${Math.max(1.5, Math.abs(p[1]) / mx * 100).toFixed(1)}%"${p[1] < 0 ? ' class="neg"' : ''}></i></span><span class="sjx-ch-v">${fmt(p[1])}</span></div>`).join('')}</div>`;
    }).replace(/\[\[(?:wa|chart)\|.*?\]\](?!\])/g, '').replace(/<br>\s*(<div class="sjx-(?:wa|ch)")/g, '$1');
  };
  css.textContent += `
    .sjx-wa{border:1px solid rgba(37,211,102,.35);background:rgba(37,211,102,.06);border-radius:12px;padding:10px 12px;margin:8px 0;max-width:460px}
    .sjx-wa-h{font-size:12px;opacity:.85;margin-bottom:4px}.sjx-wa-m{font-size:13px;line-height:1.45;margin-bottom:8px;white-space:normal}
    .sjx-ch{margin:8px 0;padding:10px 12px;border:1px solid var(--line,#3a2f1a);border-radius:12px;max-width:520px}.sjx-ch-t{font-weight:600;font-size:13px;margin-bottom:6px}
    .sjx-ch-r{display:grid;grid-template-columns:minmax(60px,34%) 1fr auto;gap:8px;align-items:center;font-size:12px;margin:3px 0}
    .sjx-ch-l{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.9}.sjx-ch-b{height:10px;border-radius:6px;background:rgba(127,127,127,.15);overflow:hidden}
    .sjx-ch-b i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,#b8860b,#f0cf74)}.sjx-ch-b i.neg{background:linear-gradient(90deg,#8b2c2c,#e06c6c)}
    .sjx-ch-v{font-variant-numeric:tabular-nums;white-space:nowrap;text-align:right}`;

  /* ---------------------------------------------------------------
     7. Hands-free: say "Shivaa …" (or "Jarvis …") — this device only
     --------------------------------------------------------------- */
  const WAKE_KEY = 'sjx_wake';
  const wakeOn = () => { try { return localStorage.getItem(WAKE_KEY) === '1'; } catch (e) { return false; } };
  const WAKE_RE = /^(.*?)(?:\b(?:hey|hi|ok|okay|are|arre)\s+)?\b(shivaa?|shiva|shiv|jarvis|शिवा|शिव|जार्विस)\b[\s,.!?:-]*/i;
  const W = { sr: null, running: false, blockedUntil: 0 };
  function wakeStart() {
    const SR = typeof SRClass === 'function' ? SRClass() : (window.SpeechRecognition || window.webkitSpeechRecognition);
    if (!SR || W.running || !wakeOn() || (VOICE && VOICE.on) || document.hidden || Date.now() < W.blockedUntil || !window.SJ_USER && SITE) return;
    let sr; try { sr = new SR(); } catch (e) { return; }
    sr.lang = (VOICE && VOICE.lang) || 'hi-IN'; sr.continuous = true; sr.interimResults = false; sr.maxAlternatives = 1;
    sr.onresult = e => {
      for (let k = e.resultIndex; k < e.results.length; k++) {
        if (!e.results[k].isFinal) continue;
        const said = String(e.results[k][0].transcript || '').trim(); const m = WAKE_RE.exec(said); if (!m) continue;
        const rest = said.slice(m.index + m[0].length).trim();
        wakeStop(); W.blockedUntil = Date.now() + 1500;
        if (rest.length > 2) { const go = () => { if (typeof chatSend === 'function' && !CHAT.busy) chatSend(rest); }; if ((location.hash || '').replace('#', '') === 'assistant') go(); else { goTo('assistant'); setTimeout(go, 700); } }
        else openAI(true);
        return;
      }
    };
    sr.onerror = e => { if (e && (e.error === 'not-allowed' || e.error === 'service-not-allowed')) { W.blockedUntil = Date.now() + 864e5; toast('Mic ki ijaazat nahi mili — hands-free band', 'err'); } };
    sr.onend = () => { W.running = false; W.sr = null; };
    try { sr.start(); W.sr = sr; W.running = true; } catch (e) { W.running = false; }
    paintWake();
  }
  function wakeStop() { try { W.sr && W.sr.abort(); } catch (e) { /* */ } W.sr = null; W.running = false; paintWake(); }
  function paintWake() { document.querySelectorAll('[data-act="go-ai"]').forEach(b => b.classList.toggle('sjx-ear', !!(wakeOn() && W.running))); }
  setInterval(() => { if (!wakeOn()) { if (W.running) wakeStop(); return; } if (VOICE && VOICE.on) { if (W.running) wakeStop(); return; } wakeStart(); paintWake(); }, 1500);
  document.addEventListener('visibilitychange', () => { if (document.hidden) wakeStop(); });
  css.textContent += `[data-act="go-ai"].sjx-ear::after{content:"";position:absolute;top:4px;right:4px;width:7px;height:7px;border-radius:50%;background:#2ecc71;box-shadow:0 0 6px #2ecc71}`;
  window.SJX_WAKE = { on: wakeOn, set: v => { try { localStorage.setItem(WAKE_KEY, v ? '1' : '0'); } catch (e) { /* */ } if (v) { W.blockedUntil = 0; wakeStart(); } else wakeStop(); } };

  /* the chat may have been drawn before this file loaded (page opened on #assistant) — redraw it with the new formatter */
  setTimeout(() => { try { if (document.querySelector('.chat-log') && typeof renderChat === 'function') renderChat(); } catch (e) { console.error(e); } }, 0);

  if (!SITE) return;
  const GEM_DEF = [['auto', 'Auto — sabse achha chalu model (recommended)'], ['gemini-flash-latest', 'Gemini Flash (latest)'], ['gemini-3.8-flash', 'Gemini 3.8 Flash'], ['gemini-3.5-flash-lite', 'Gemini 3.5 Flash-Lite (zyada free sawal, thoda kam samajhdar)']];
  const CLA_DEF = [['claude-sonnet-5-5', 'Claude Sonnet 5.5 (recommended)'], ['claude-opus-5-5', 'Claude Opus 5.5 (sabse samajhdar, mehnga)'], ['claude-haiku-5-5', 'Claude Haiku 5.5 (sasta, tez)']];
  let lastStatus = null;
  function gemOptions(models) {
    if (!models || !models.length) return GEM_DEF;
    const score = n => (n === 'gemini-flash-latest' ? 1000 : 0) + (/pro/.test(n) ? 50 : 0) + (/preview|exp/.test(n) ? -200 : 0) + (/lite/.test(n) ? -20 : 0) + (parseFloat((/gemini-(\d+(?:\.\d+)?)/.exec(n) || [])[1]) || 0);
    const L = models.slice().sort((a, b) => score(b) - score(a)).slice(0, 14).map(n => [n, n.replace(/^gemini-/, 'Gemini ').replace(/-/g, ' ') + (/lite/.test(n) ? ' (zyada free sawal)' : /pro/.test(n) ? ' (free limit bahut kam)' : '')]);
    return [GEM_DEF[0]].concat(L);
  }
  const AI_HELP = { gemini: 'Gemini free key: aistudio.google.com par Google account se login → "Get API key" → "Create API key" → copy karke yahan paste. Model "Auto" rakhiye — software khud sabse achha chalu model chunega, aur limit khatam hone par apne-aap halke model par chala jayega. Dhyan: free plan mein Google sawal-jawab apne AI ke liye use kar sakta hai — isliye bhejne se pehle customers ke phone number aur PAN chhupa diye jaate hain.', claude: 'Claude key: platform.claude.com → Billing mein balance → Settings → API keys → Create key (sk-ant-… se shuru). Har sawal par thoda kharcha lagta hai.' };
  function fillModels(card, prov, models, sel) {
    const m = q$('.aik-model', card); if (!m) return;
    const L = prov === 'gemini' ? gemOptions(models) : CLA_DEF;
    m.innerHTML = opts(L, sel && L.some(x => x[0] === sel) ? sel : L[0][0]);
    const h = q$('.aik-help', card); if (h) h.textContent = AI_HELP[prov];
  }
  function aiCard() {
    setTimeout(aiStatusFill, 0);
    return `<div class="card" id="ai-card"><div class="card-h"><h3>🤖 AI Assistant — Shivaa AI (Jarvis)</h3></div><p class="small muted" style="margin-top:0">AI aapki apni API key se chalta hai — <b>Google Gemini (free)</b> ya <b>Claude</b>. Key sirf server par taale mein rehti hai, staff ke phone par nahi jaati. Key kabhi chat / WhatsApp par kisi ko mat bhejiye.</p><div class="aik-st small">Check ho raha hai…</div>
      ${role() === 'owner' ? `<div class="two" style="margin-top:10px">${F('AI company', `<select class="aik-prov">${opts([['gemini', 'Google Gemini — free key'], ['claude', 'Claude (Anthropic) — paid key']], 'gemini')}</select>`)}${F('Model', `<select class="aik-model">${opts(GEM_DEF, 'auto')}</select>`)}${F('API key', '<input type="password" class="aik-key" autocomplete="off" spellcheck="false" placeholder="key yahan paste kijiye">')}</div><div class="btns"><button type="button" class="btn primary" data-act="aikey-save">Save & test</button><button type="button" class="btn aik-mod" data-act="aikey-model" hidden>Sirf model badlo</button><button type="button" class="btn" data-act="aikey-clear">Key hatao</button></div>
      <p class="small muted aik-help"></p>` : '<p class="small muted">Key sirf Owner daal sakta hai.</p>'}
      <label class="small" style="display:flex;gap:8px;align-items:flex-start;margin-top:10px"><input type="checkbox" class="aik-wake" ${window.SJX_WAKE && window.SJX_WAKE.on() ? 'checked' : ''}><span><b>🎙 Hands-free:</b> "Shivaa…" ya "Jarvis…" bolte hi AI sun lega — jaise <i>"Shivaa, aaj ki bikri kitni hui?"</i>. Sirf is device par, jab software khula ho. Computer / tablet par sabse achha chalta hai (✦ button par hari bindi = sun raha hai).</span></label></div>`;
  }
  async function aiStatusFill() {
    const el = q$('#ai-card .aik-st'); if (!el) return; const card = el.closest('#ai-card');
    try {
      const r = await window.SJ_AI.status(); lastStatus = r;
      const p = q$('.aik-prov', card);
      if (p) { p.value = r.set ? r.provider : 'gemini'; fillModels(card, p.value, r.set ? r.models : [], r.set ? r.model : ''); const mb = q$('.aik-mod', card); if (mb) mb.hidden = !r.set; }
      el.innerHTML = r.set ? `<span class="green">✓ Chalu hai</span> · ${r.provider === 'gemini' ? 'Google Gemini' : 'Claude'} · model <b>${esc(r.model)}</b> · key ${esc(r.hint)} — <a href="#assistant">AI Assistant kholiye →</a>`
        : `<span class="red">✗ Abhi band hai</span> — API key daaliye.${r.curl ? '' : ' <span class="red">(Hosting par PHP curl band hai — hPanel → PHP extensions mein curl on kijiye.)</span>'}`;
    } catch (e) { el.innerHTML = '<span class="red">Status nahi mila: ' + esc(e.message || '') + '</span>'; }
  }
  { const V = VIEWDEF.setup; if (V) VIEWDEF.setup = { ...V, body() { return aiCard() + V.body.call(V); } }; }
  document.addEventListener('change', e => { if (e.target.classList && e.target.classList.contains('aik-wake')) { if (window.SJX_WAKE) window.SJX_WAKE.set(e.target.checked); toast(e.target.checked ? '🎙 Hands-free chalu — "Shivaa…" boliye' : 'Hands-free band'); } });
  document.addEventListener('change', e => { if (e.target.classList && e.target.classList.contains('aik-prov')) { const card = e.target.closest('#ai-card'); const same = lastStatus && lastStatus.set && lastStatus.provider === e.target.value; fillModels(card, e.target.value, same ? lastStatus.models : [], same ? lastStatus.model : ''); const mb = q$('.aik-mod', card); if (mb) mb.hidden = !same; } });
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act="aikey-save"],[data-act="aikey-clear"],[data-act="aikey-model"]'); if (!t) return;
    const card = t.closest('#ai-card'); if (!card) return; const st = q$('.aik-st', card);
    const btns = [...card.querySelectorAll('button')]; let tick = null;
    try {
      if (t.dataset.act === 'aikey-clear') { await window.SJ_AI.key('', ''); toast('AI key hata di'); aiStatusFill(); return; }
      const prov = q$('.aik-prov', card).value, model = q$('.aik-model', card).value;
      if (t.dataset.act === 'aikey-model') { btns.forEach(b => b.disabled = true); st.textContent = 'Model badal raha hoon…'; await window.SJ_AI.key('', model, prov, { modelOnly: true }); toast('✓ Model badal gaya'); aiStatusFill(); return; }
      const k = q$('.aik-key', card).value.replace(/\s+/g, '');
      if (!k) { toast('API key paste kijiye', 'err'); q$('.aik-key', card).focus(); return; }
      if (prov === 'claude' && !/^sk-ant-/.test(k)) { st.innerHTML = '<span class="red">Ye Claude key nahi lagti — Claude key "sk-ant-" se shuru hoti hai. Gemini key hai to upar "Google Gemini" chuniye.</span>'; return; }
      if (prov === 'gemini' && /^sk-ant-/.test(k)) { st.innerHTML = '<span class="red">Ye Claude ki key hai — upar AI company "Claude" chuniye.</span>'; return; }
      btns.forEach(b => b.disabled = true); const t0 = Date.now();
      const show = () => { st.innerHTML = `Key check ho rahi hai… <span class="sjx-timer">${Math.round((Date.now() - t0) / 1000)}s</span> <span class="muted">(zyada se zyada 1 minute)</span>`; };
      show(); tick = setInterval(show, 1000);
      const r = await window.SJ_AI.key(k, model, prov);
      q$('.aik-key', card).value = '';
      toast('✓ AI Assistant chalu ho gaya'); await aiStatusFill();
      if (r && r.model) st.innerHTML += '<br><span class="small muted">Model apne-aap chuna: <b>' + esc(r.model) + '</b></span>';
    } catch (err) {
      const m = (err && err.message) || 'Nahi hua';
      st.innerHTML = '<span class="red">✗ ' + esc(m) + '</span>' + (err && err.code === 'timeout' ? '<br><span class="small">Hosting ka server AI company tak nahi pahunch pa raha. hPanel → PHP Configuration mein <b>curl</b> on hai, ye check kijiye aur 2 minute baad dobara try kijiye.</span>' : '');
    } finally { if (tick) clearInterval(tick); btns.forEach(b => b.disabled = false); }
  });
})();
