/* =====================================================================
   ORDER ESTIMATES  (Parties → next to Deals Ledger)
   - Make an order estimate for a party: items, qty, melting/purity,
     weight range, design photos, order notes → PDF / WhatsApp
   - Record the result: Pending / Deal hui / Deal nahi hui
   - Deal hui → creates the party (if new) and one Deal per item in the
     Deals Ledger; later edits to the estimate update those deals
   ===================================================================== */
(() => {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof PARTY_TABS === 'undefined' || typeof S === 'undefined') return;

  const EST = 'estimates';
  const FOOTER = 'Weights are approximate and subject to final finishing. Thank you for your order.';
  // "Shivaa INC." logo used on the estimate PDFs (taken from Shivaa's own estimate format)
  const EST_LOGO = 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAQDAwMDAgQDAwMEBAQFBgoGBgUFBgwICQcKDgwPDg4MDQ0PERYTDxAVEQ0NExoTFRcYGRkZDxIbHRsYHRYYGRj/2wBDAQQEBAYFBgsGBgsYEA0QGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBgYGBj/wAARCAEhAoADASIAAhEBAxEB/8QAHQABAAEFAQEBAAAAAAAAAAAAAAgBBQYHCQQDAv/EAFkQAAEDAgMEBQYICQoCCQMFAAEAAgMEBQYHEQgSITETQVFh0xgiV3GBlBQXMkJSYoKRFRYjcqGio7GzJCczQ2NlkrK0wSbRJSg0NVNzhZXCN4OTVHR1pMP/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAQIDBAX/xAAmEQEAAgEEAQUBAAMBAAAAAAAAAQIRAxIhMVEEEzJBUiIjYXFC/9oADAMBAAIRAxEAPwCfyIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIqEgDUoKoo9ZnbW+CstsyKjCD7JdbzPRFra6ejdG1kDiA4sG8dXuAI1A005a6rfVsuFNdrNSXSif0lNVwsqIX6abzHtDmn7iFM1mOZRExL1oiKEiIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiArVia+0WGMHXTEdxeG0tupZKuUk6atY0uI9umiuqjjtoYz/ABf2fm4cp5S2qxDVspSBz6CP8pKf0Mb9pTWMzEImcRlAWtqbrjXHM9XOXTXS915e7mS6WeTl97/0LrxY7bFZsNW+zwf0VFTRUrNOxjA0fuXM/Zjwx+NW1HhiB8e9BQSvuk2o1AELd5uv2zGun45Lf1E8xXwpp+VURFztBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBFYMU41wpgq0m5YsxBb7PSjk+rmDC/ua3m49wBUa8ebceGLa6Sjy+w7U3yYEgVtwJpaf1tbxkcPWGq1aWt1CJmI7Sy3h2ry1tzt1th6W419NSR/SqJWxj73ELmZi3afzoxa+VsmLpLPSP1/k1mjFK0Ds3xq8+1ywqyYOzEzJr3S2Ww3/ABNK4+fU7kk7R+dK87o9pW0enmPlKnueIdRqrNLLWicW1eYGGISOYdc4dR+sv1TZn5b1p0pMfYZmPYy5wkn9ZQIs+xrnXcGsdVWmyWhpGv8ALK9hcPZEHfvVuxjsnZw4RtMlzdYaK+UkTS+V1om6eRgHMmNwa4j80FPap+jdbw6U0Nzt1zpvhFtr6asi106SnlbI372khekOB5FccrLfr5hu4tr8PXivtNUw8JqCd8Dh/hI+4qVuSe2Ndaa6UuG82po6qhkIjjv7WBkkB5Dp2t4OZy1eACOZB5iL6E15jlMakSnCi+cE8dRAyeF7ZIntDmPY4Oa4EaggjmCvosFxERAREQFzr2zMZ/jFtBNw9TzB9Lh6jbTENOo6eTSST2gGNv2V0Fvd2pLDhyvvdwkEdJQ00lVM49TGNLnfoC5B4ivtXijGF0xJcHE1Vzq5ayXXqL3l2nsBA9i6PT1zOWepPGEtNhDC+/csW40mYfybIbXA4jrJ6WTT7o/vU11pTZTwqcLbL9gMsRjqbrv3aYEcT0p8z9m2NbrWWpObTK1YxAiIqLCIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAioSBzKjjnXtY4Yy+NTh/B3QYixIzVjy1+tJRu/tHj5bh9Bp9ZCmtZtOIRM4byxXjPC+B8PSXzFl7pLVQs/rah+m+fosbze7uaCVDnNDbautcZrVlZa/wdBxb+GLjGHzO744eLWet+p7gozYzx3i3MLEr77i+91FzrDqGdIdI4Wn5sbB5rG9wHr1V5yyygxxmxfTQYUthdTRODam5VGrKam1+k/Ti76rdXdy6q6Na83ZTeZ4qxW93694mvcl4xDdqy63CU+dU1kplee4E8h3DQdy2/lnsr5nZhshuFXRDDNmk0cK26Mc2SRvbHB8o9xdujvUv8otmLAOWDKe51VM3EOIm6ONzroxuwu/sIuIZ6zq7v6lu7Qdirb1H1RMaflo3AGyflLgiOGorrScTXNmhNXeNJGB31YfkNHrBPet201LT0lMympYY4YGDdZFG0Na0dgA4BfZFzzaZ7aRGOhUI1VUPJQlzv2yMu7dg7OSjxDZqVlNR4igfUSxRtDWNqWOAkcAOW8HNce/ePWo4qZ+3tPCY8B0wcDMH10hb1hpEI1+8FQwXfozM0jLnv26KbG2OKrFOQLrHcJ3TVWHqo0LHvOpMBaHxAnuBc31NCkUog7BlLMzBuNaxzT0MtfTRMPUSyJxd/napfLj1IxeYbV6ERFRYREPJBHzbGxkMM7OlRZoJgysxBUMt7QOfRD8pKR9lob9tc98OWKqxRjK1Ybomk1FzrIqKMDtkeG6+wEn2KQG2pjM3/PSlwtTzF1Lh+jDHtB1HwibSR/tDREPvVt2OcI/jHtIQ3iaIPpbBSSVzi4cOld+SiHr857h+b3Ls042acyxtzZ0StdvprTZKO1UTNympIWU8TexjGhoH3AL1qgGjQFVcbYREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQFaMSYmsWEcOVN/wAS3Wmtttpm70tTUO3WjsA6yTyAGpPUFiebGceD8osLG5YiqTLWTNcKK2QEGercPoj5rR1vPAd50B5yZrZxYyzdxJ+EMR1nRUULiaO1U5Ip6UHsHzn9rzxPVoOC109Kb/8AFLXiG0c8drDEWPX1GHMDPqbFho6xyVAO5V1zeR3iP6Jh+iOJ6z1KN3ADqAC9drtdyvd5prRZ6Corq+qkEUFLTsL5JXHkGgc1PLILZQtmCxTYszEgprpiMaSQUB0kpreeYJ6pJR9L5LerU+cuqbV0oxDPE2lqHIrZMu2MhTYpzHiqrTh92kkFuGsdVXDmC7rijPb8ojloDqp22LD9lwzYaay4ftlNbbdTMDIaamjDGMHqHWesnietXEDQaKq473m88ta1wIiKiwiIgIeSLGcwsX0eAcsL3i+v0MVtpHztYf6yTkxnrc8tb7UxngQB2vMaDFe0jWWynlD6PD8Dbazd5dL8uY+vecG/YWhV6K+uq7pdqq53CYzVdVM+onkPN73uLnH7yVlOVmAq3MzNqzYOpGvEdXMHVUrR/Q07fOlf/h1A7yAvRiIpX/jmn+pT72SsJSYV2ZLTNUxmOpvMsl2ka4aENk0bH+zYw+1byXnoqOnt9ugoaOJsNNTxtiiiaNAxjQA1o7gAF6F58zmZl0RGIwIiKEi8d1uVJZ7FW3aukEdLRwPqJnn5rGNLnH7gV7FoHbAxoMLbONbaoJQysv8AM22RgHzujPnzH/A3d+2FNY3ThEzhz2xViGrxdjm8YpriTUXSslrHg/N33EhvsGg9inRsRYPNnyXuOLZ4i2e+1x6NxHOCDVjdO4vMhUBKenqK2tho6SMyVE8jYomNHFz3ENaPaSF12wDhanwTllYcJ0wAZbKGKmJHJzmtG+72u3j7V1+onFYqy04zOWSIiLjbCIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiagICJqFTUdoQVRU3m/SH3pvN+kPvQVRU3m9o+9ULgBrqEFSQOZWk8+dorD+UFrda6EQ3XFk8e9T27e8yAHlLORxa3rDflO6tBxFi2jNpKhywoZcLYVkgrcYTx8fnx21pHCSQdb9OLWe08NAeetxuNwvF3qbpdKyetrqqQzT1M7y+SV54lzieZW+lo7uZ6Z3vjiFwxXizEON8WVWJMUXSa43Kqdq+aU8GjqYxvJjB1NHAfevpg/BuI8e4vpcM4Wtslfcag8GN4Njb1ve7kxg63H9J4L1Zf5f4lzLxzS4VwtRierm8+SV+oipogfOlkd1NH3k8BqSumGT+TuF8oMFttNlj+EV8wDq+6StAlq3j/ACsHHdYOA7zqTvqasacYjtStdyw5G7PmG8nrL8Kf0V0xPUR7tXdXM0DAecUIPFjO/m7meoDcgAHUiLimZmcy2iMCIihIiIgImoHMqmo7QgqeAUKtt3M5ss1tyrtdSHdGW3G7Bh5H+oiP3mQj8xSlzNzAtWWeWV0xfdXNfHSR6Qwa6OqJncI4m97naeoanqXKTEV/umKcV3HEl7qPhFwuE76mok6i5x10HY0DQAdQAW+hTM5lnqWxwtoa5zg1oLieAAGpJ7h1rovsrZJTZZ4GkxLiGl6PE96Y0yxv+VR0/NkPc4nzn9+g+atWbJez4KqWkzXxtRfkWkS2Sgmb8sjlVPB6h8wH876KmwN0DQFTr6mf5hFK45VRNR2hNR2hc7URNR2hNR2hBQrnvtrY1/D2eVJhSmlLqXD9GGyNB4fCJtHv9oYIh7Sp+Xe6UVlsFbeLhKI6SjgfUzP+ixjS5x+4FchcVYhq8W44u+Ka8k1F0rJax4Pzd9xIb7BoPYt/T1zbLPUnjDaGyxgw4x2mLIZoi+js+9dqjhqPyWgjB9cjmfcV03HJRO2HMGC3ZcXzHFTEBPdqsUlO4jj0MGupHcZHO/wKWGo7Qq61t1k0jEKomo7Qmo7QslxE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaE1HaEBE1HaFTUdoQVRNQeRRAWkdqnGeJcC7Ps94wpdZbZcJq+Ck+FQgF7GP3i7dJB0J3dNeY6lu5Rx22jpsxtHbeaX90ivpxm0It01rhjKjasxTgu1Ymt2eLoqW5UkdZFHPdaoPa17Q4B2kRGuh6iVdDkfteN+TnjGf8A1ap8FSNydbu7P2Ch/clJ/Cas3Vp1JiVdsIcnJXbBbyzqjd/6tP4KfE7tjM+TnHE7/wBUk/3hUxkUe5PhOyEOPim2y28s24Hf+pu8FaxzPxVtHZR3OjteJ84HzV9UwytpaCsE0kcfIPeDGN0E6gdZ0PYpzZmY9teWmWF1xjdfPjo4vyUAOjqiZ3mxxjvc4gdw1PUuVGKsUXvGmMrhijENY6quVfKZZpDyHYxo6mtGjQOoALbSzfuOFLcdLdWVlXcbjPX19TNVVdRI6aaeZ5e+V7jq5zieJJPWrphDCV+xzjOhwthqhdV3KtfuRsHBrQOLnvPzWNHEnqH3KyAEkAAk8gANSV0k2YMk4cr8u23q9UrfxqvETZatzx51JEeLKcdmnN3a7hyaFtq6myFK1yzPJrJ7D+T2A47Pa2tqblOGyXG5OZo+ql0/VY3UhreodpJJ2OiLgmZmcy3iMCIihIiIgIiINfZyWnMu85bOpMqb5TWi/fCY3unnIbvwjXfY1xa4NJO6ddOQI4aqPP4gbbQH/wBQ6P8A9wj8FTHWkdpvNo5XZPTxWypDMQ3neorfofOiGn5Sf7DTw+s5qvS0/GIVtH2gfmdjrMi/XqfCuOsayYhbaKt7AIpWyU4mb5rnMLWtD9OLddO3Tmrrlrs+Zm5m4fdiTDFuoY7dHN0cdRcZuibO5p47gLTvtB4E8tdRx0KuWz5kRcc4sYGpuAnpcK0Eg+H1gOjp3c/g8Z+mR8p3zQdeZC6U2i1W+yWSltFqooaKhpImw09PC3dZGxo0DQOxdGpq7P5qzrXPMoiR5ebbEUTY48wKFjGjda1tdEA0dQAEPAL9/F/tt+kOj9/j8FTGRYe7PiGm1Dn4v9tv0h0fv8fgp8X+236Q6P3+PwVMZE92fEG1Dn4v9tv0h0fv8fgp8X+236Q6P3+PwVMZU5J7s+INrnnnN5S+B8BinzIzAjqLVeXOoTR09WyR043S5wIEbTu6DidesDrUcoYZaiqip4GOfLK9rGMbxLnE6AD2kBSN20saHEGe8GF6ebepMPUgic0HUfCJtJJPaG9EPYViOy9gr8dNpaxRzRGSitJddqnhqNItOjB9chj+4rqpOKbpZTzbDcOHsoNsLDGGaOw4fxjbrbbaRm5BSRV8e7ECS4j+iPWSeZ5q6fF/tt+kOj9/j8FTFA4cVVc3uz4hrtQ5+L/bb9IdH7/H4KfF/tt+kOj9/j8FTGRR7s+INqHPxf7bfpDo/f4/BT4v9tv0h0fv8fgqYyJ7s+INqHPxf7bfpDo/f4/BT4v9tv0h0fv8fgqYyJ7s+INqHPxf7bfpDo/f4/BT4v8Abb9IdH7/AB+CpjInuz4g2oc/F/tt+kOj9/j8FPi/22/SHR+/x+CpjInuz4g2oc/F/tt+kOj9/j8FPi/22/SHR+/x+CpjInuz4g2oc/F/tt+kOj9/j8FPi/22/SHR+/x+CpjInuz4g2oc/F/tt+kOj9/j8FPi/wBtv0h0fv8AH4KmMie7PiDahz8X+236Q6P3+PwU+L/bb9IdH7/H4KmMie7PiDahz8X+236Q6P3+PwU+L/bb9IdH7/H4KmMie7PiDahz8X+236Q6P3+PwU+L/bb9IdH7/H4KmMie7PiDahz8X+236Q6P3+PwU+L/AG2/SHR+/wAfgqYyJ7s+INqHPxf7bfpDo/f4/BT4v9tv0h0fv8fgqYyJ7s+INqHPxf7bfpDo/f4/BT4v9tv0h0fv8fgqYyJ7s+INqHPxf7bfpDo/f4/BT4v9tv0h0fv8fgqYyJ7s+INqHPxf7bfpDo/f4/BT4v8Abb9IdH7/AB+CpjInuz4g2oc/F/tt+kOj9/j8FPi/22/SHR+/x+CpjInuz4g2oc/F/tt+kOj9/j8FPi/22/SHR+/x+CpjInuz4g2oc/F/tt+kOj9/j8FPi/22/SHR+/x+CpjInuz4g2oc/F/tt+kOj9/j8FPi/wBtv0h0fv8AH4KmMie7PiDahz8X+236Q6P3+PwU+L/bb9IdH7/H4KmMie7PiDahz8X+236Q6P3+PwU+L/bb9IdH7/H4KmMie7PiDahz8X+236Q6P3+PwV+XYA22mtJOYdGAP7wj8FTIXyqOFO8/VP7lPuz4g2oz7HuYeO8dW/GEWNcRT3g2+qgbA6drd+Mva/fAc0DVvmN0HVx7VJ1RA2E+NvzBd219N/llUv1Gr8pK9CjbtunTZmi771TD9SVSSUatuE6bNFN33ynH7KZRp/KE26biyjbu5CYMH9yUf8FqzNYhlUN3IvBo/uSj/gtWXqtu5I6ERUPySoSgrtwZgvuGNbTlvRzH4NbIxcK5oPB08gIjafzY9T/9xRMWz9ouapn2p8cOqi4ubctxu99BsTA32aaLWC9DSjFYc1pzLeuydl7TY62gKerucLZrbYIvwnLG4atklDg2Fp7t4732F0oAAULdgl9L0+O4ju/CiKJw15ln5bXT26foU01ya85u2pGIERFkuIiICIiAiIg+c8zIIHzSyNjYxpc57joGgcST3aLn5c7Tifa32nquutPwmmwfQPFKy5OjJjpqRjubdeDppDvODerUa8GroM5ocNDoR2FeS3Wu3Wi3x0NqoKWhpY9dyClibFG3Xno1oACtS+3mO0TGVvwjhKw4JwdQ4Zw5QMordRM6OKJvM9rnH5zidSXHmSr4iKqRERAREQF4L3dqOw4cr73cJBHSUNPJVTPPUxjS5x+4L3qPO2RjT8WdnmWx08u5WYhqG0DQDx6EflJSPY1rftqaxunCJ4hz7xLf6zFWM7ria4EmqudXLWSa9Re4u09gIHsU2NhrBf4Oy8vmOamICa7VQo6Zzhx6CH5RHcZHO/wKC0UU1RURwU8ZkmleGRsHNzidGgeskBdcMtMIQ4Eykw9hKFoH4Ooo4ZCPnS6ayO9ry4+1dfqJxWKwy0+ZyytERcbYREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQF8arhSSH6jv3L7L4Vh0oZj/AGbv3FBEjYP42HHru2vpv8kil8og7BfHCuOH9tfTfwnKXy01fnKtehRn25Dps1UX/wDO0/8ABnUmFGXbnOmzdQN7b7D/AAJ1Gn84Tbpu/LBu7klg8f3JR/wGLK1i+Wo0yYwiOyy0f8BiyhVnsjoREUJQI21MtKy0ZjwZl0MDn2y8MZTVj2t4Q1TG7rdewPY0ad7D1lRYXYbE2GrLi3CtbhzENvir7bWxmKenkHBw7QeYIOhBHEEAhc2M88gsR5PYhfUsbNccLVEmlHdAz+jJ5RTacGyDqPJ3McdQOzQ1cxtljev3DybPuaYymznpL3WuebNWM+A3NrRqWwuIIkA6yxwDtOzeHWuoVDXUdyt8FfQVMVTS1EbZYZoXB7JGOGoc0jgQR1rjTyK3dkhtJ4qyjkjs1ZG+94Vc/V1vkfpJS6nUup3Hl2lh80/VJ1U62lu/qCl8cS6YIsOy/wA0MFZnWIXXB97hrWtA6emd5k9MeySM8W+vkeolZjqO1cUxjtrE5ERESIiICIiAiIgIiICIiAiIgE6DVc7ts7Gv4xZ+R4ap5t+kw7SNgcAdR8Il0kkPrDejb7CugF+vFFh7C9xvtxkDKSgppKqZ2vJjGlx/QFyExFfazE+LrpiS4uLqu5VUlZKSfnSOLtPZrp7F0enrm2WepOIw2bsxYM/HTaXsEE0PSUVrc67VPDUbsOhYD65DGF0+brujVRH2F8GCjwViHHdTFpLcaltvpnHn0UPF5HcXu0+wpcjgFTXtusmkYgREWS4iIgsmLsVWLBODa7FGJK5tFbKJnSTSkannoGtA4ucSQABxJIUNcXbdOIp7lJFgXCNvo6JpIZPd3OmmeO3cY5rW+rU+tbn2wcLYjxRs7Obh2lmrDb6+Kuq6WBpc98LWvBIaOLt0uDiB1AnqXN9pa6RrGuDnOO6ADqSewDtXTo6dbRmWd7THSbmRG03mvmdm3QYQuFhw9UUsgfUVlZTxSwOpoGDznAb7gSSWtGvW4KYSjVsg5SXDAmXtdirElukor3fXN3IJm7skFKziwOHNpc4lxHPTd148FJVY6mN38rVzjkREVFhERAREQERYRjTN7LbL6cQYvxjbbbUkailc8yT6HkeiYC7Tv0TEz0TOGbosQwLmhgLMikqJ8F4mo7r8GIE8ce9HJFryLo3gOAPbpodOay9MTHYIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiJqEBERAREQF5646W2c9kT/8pXoXkuZ3bNVu7IHn9UoImbBI/wCC8antuFOP2JUvlEPYKH/AmMj/AHlAP2Cl4tNX5yrXoUYdul2mzrbR/fkX8CZSeUXdus/9Xy1N7b0z+BMml84LdN95ccMncJjss1H/AAGLJ1jWXg3co8LDstFJ/AYslWc9rCIiAvHcrXb7xaqi2XWip62iqWGOamqIxJHI08w5p4EL2Ighhm9sWayT3zKSpazXV7rBWy6N9UEp5fmv4fWHJRBvlgveGb7NZcQ2mstdxhOklLVxGN479DzHeNQV2N0HYsXxtl3gzMSy/gvGGH6O6QAHo3St0lhPbHINHMPqK3przXtnbTienJmyX69YavcN5w/day13CH+jqaSUxvb3ajmO46g9ilhljtt11I2G15qWg1sY0b+GLYwNl9ckPJ3rYR+avpmLsO11P01wyyxE2qjGrha7w4Nf6mTtGh+00etRbxbgbF+BLr+DsYYduFnnJIaaqLRkmnWx41a8fmkrf/Hqqf1V1XwdmFg3MC0fhLB2IaG7QADfbBJ+Ui7nxnRzD3EBZODqNVxutV3utiu0V0stzrLbXRHWOppJnRSN9TmkH2KROX+2jmHhwRUWM6OmxVQt0BmOlPVtH57RuvP5zQe9Y29PMfFeNSPt0IRaiy+2ksp8w3RUtBiJlrucnK23fSmlJ7Gkncf9lxPctuBzTyKwmJjteJyqiIoSIiICIiAiIgIioSANSgjttl41/FvZ9fh+nl3avEVS2iAHPoG/lJT9wa37a52Na97wyNhe9x0a0DUuJ4Ae08FIjbLxqMS7QP4v00wfR4dpW0ugOo6eTSSU+sDo2/ZKwjZ1waMcbSOGrZNEJKOknNyqwRqOjg88A9xfuN9q7dKNlMsLc2w6MZS4OZgHJbDeEwwNloqFgqO+Z3nyn/G5yzRUA0CxvHWO8NZdYKq8UYprxSUNONABxkmefkxxt+c89Q9p0AJXHzMtumSE6Km92ArmbmhtO5l5h3mdlBeKvDVj3iILdbZjE4s6jLK3Rz3duhDewdZ1XQ4pxPbLk2423El4pKtp3hPDXSseD6w5bx6eZjMqTqQ7EA6jVFqHZpx7esxdny2XvEU5qbpBNNQ1FSQAZzG7RryBw3i0t179StvBYTGJw0jlQjUc9FYYcD4Np72bzT4UscVyLt81jKCJsuvbvhuuver4+WONhfI9rGjmXHQBVDgTooFQNAqoiAiIgIiICIvFdrlR2ax1l3uEwho6OB9RPIfmMY0ucfuBQaY2kc+YcosIMtllMU2LLmx3wON43m0sfI1Dx16Hg1vzndwK5vXC4V92u1TdLnWT1ldVSOmnqZnF8krydS5xPMq/5i45ueY+Zt2xldXO6WumLooieEEI4RxDua3T26nrWLkgAk8AOa9DS04pDnvbMpJbFFiutftBVV9pS9lvtlslbVvBIa8ykNjjPbxa532F0MHJaS2WsuDl9kFQSV1P0d3vZFzrd4eczfA6KM/ms04drnLdq49W262W1IxAiIs1hOpFprPnP2yZO4dEEAiuOJqxhNFbC7QNHLpptOLYx1Dm4jQdZExEzOIJnDYuLcb4UwJYHXrF18o7TRN4CSofoXn6LGjznu7mglRqxFt24Uo7hJBhrA91u0DTo2pq6llGHd4Zuvdp69CobYzxxinMDFMuIcW3ee410moaX8GQt1+RGwcGN7h7dTxW18P7LGOLjkpe8w748WUUtukr7fbJ4/y9UGN3yZBw6JpaHaA+ceGoA59MaNac3llvmem9cJbc+FbpeqehxZg+usNPK8MdXwVLaqOLU6bz27rXBo6yNdOeildDNHPAyaJ7XxvaHNe06hwPEEHrC4ycHM4cQR9/BT8uW0hYcp9mzA9LH0V8xTV2GkfDb2y6Njb0QAlmcNS1vDgPlO0OmgBKrq6OMbU0vntKNFz4t+2/mnTX1lXdLRhyrt4drLRxU8kLt3rDZN86HTXTUEaqflrrornZKO5QBwiqoWTsDuYa9ocNe/QrK+nana0WienrREJ0VFhWy/YhsmGLHNecQ3SjtlvgGslTVyiNje7U9Z6gOJWG5v5wYaygwU+83qT4RXTast9sjfpLVyAch9Fg4bz+Q7yQDzbzKzVxnmtiY3fFlyMkbCTTUEOraakaeqNmvPtcdXHrPUtdPSm//FLWwmDi3bkwJabk+lwphq6YjjYS01b5G0cL+9m8HPI7y0Kz2Tbxsc1zZFiHL2voaVztHVFFWtqXMHb0bms107itLZQbLuNM0LDLiOsmFgsr4Xuo56iPekrX7p3dxnDSPe01eefUDzWjHxyQzOilbuSMcWPHY4HQj7wt66WnPEKbrdy7GWO92zEeHKK/WWrjq7fXQtqKeeM8JGOGoPd6jxHJXBRGyuzxw3lFsP4Xrr3OK+6yurIrfaYZAJZ92pkHE/MY3hq4jhyAJOi1fJtu5tPvXwqK1YYZSb2oozTSnUdhk6TX26exYRo2nOF98R26EosYy7xfDj7K2xYxgpX0jbpSMqTTudvGNx4Obr1gEEA9aydZLiL8ySMijdJI4NY0alxOgA7SVi2DMxMJ5guusmEbq25U9rq/gU9TE09E6TcDyGOPywA4ecOGvLVBXMfEl1whldfMS2SxyXu4UFI6eCgj1JmcCPognQAlx046A6KyZJY9xBmTlJS4qxLho2GtmmljEADwyVjTo2VgeN4NPf1g9WivOLcxcIYHvdjt2Krsy2OvUz6ejmmBERkaGnde/kzXeGhOg71lbS08ip+kKoiKEiIiAvDeTu4erndlNIf1Cvcrdfzu4WuTuyllP6hUwIr7BY/m9xge26Q/6cKXKiRsGD+bbFru26xf6dqlur6vylWvQotbdh/mGsze29N/gSqUqivt2u0yPsbe28j+BIo0vnBbpIbAI3cqsNN7LVSj9ixZErBgcbuWWHR2Wym/gtV/VJWEREBERAREQF4btZrTfbVLbL1bKS40Uo0fTVcTZY3etrgQvciCMuYGxbl5iLpazBlVU4UrnauEUetRSOP/AJbjvN+y7TuUV8wNmvNnL3pamsw8672yPU/hGz61DA0dbmAb7Pa3TvXUJUI1Wtda1VJpEuMRA4tcAdDoQeo+pbPy+2gs08tzHBZcSS1ltZp/0ZdNamDTsbqd5n2XBdAcwMgMrMyBJPf8NQQXB4/7yt/8mqNe0ubwf9oFRUzB2JcZWQS12ALvBiSkHnCjqt2mqwOwH+jf97T3LojWpfiymyY6bay721cCYh6KgxzQzYVrnaN+E6moo3H88DeZ9oad6klartbL3aYrnZ7jS19HMN6OppZWyRvHc5pIK4/3ywXzDN6ktGIbRW2qvj+VTVkLonjv0PMd41CuuDMwsaZe3X8IYNxHW2mUnV8cL9YZfz4jqx3tCrb08TzWUxqT9uu/FVUNcttuGCR0NtzRsPQHg03e0tLmeuSAnUethP5qlbhbGWF8bWRl3wnfaG70Tv62klD9w9jhzae5wBXNalq9tImJX1FTXuVVVIiIgK2YivdFhvCVzxDcXhlJb6WSrmJOnmsaXH92iuajhtn41OHcgW4cp5dyrxFVNpdAePQR6SSn26Mb9pTWN0xCJnEZQAvt6rcSYouWIbi8uq7jVSVcxP0pHFxHs109imNsKYN3LXifH1REdZ5GWqlefos0klI9ZdGPsqFJJAJ01I46DrXTHBldhnZ32R7FPiyoFL8Ho2zTxNGstRVzayuiY35zy5xHcG6nQArr15xXbDKnM5bEx/j/AA1ltgeqxRiiuFPRwDdYxvnSTyH5McbfnPPZ1cSdACVzOzfzhxNnDjZ14vDzTW+Aubb7XG/WOlYf8zzw3n9fIcAAvnm5m7iXODHDr3fHmnooS5lvtkbtYqSMn9Z54bz+vuAAWf7NGQE2aeJhiXElNIzCFul0e06t/CEo49C0/QHzyPzRxJ0UpGlG6xNt04hp2qwdiOhwLS4xr7ZLSWasqPgtHUT+Yap4aXExNPFzQBxd8nq1KsXXopNba2J463N60YJod2Oiw/bm6wRgNYyWbR2gA4DSNkYA7Coy6PPCMbzzwaB1nqH3ralpmu6VLRicOk2x9bZLfsqWaaQafDaqrqh3tMzmg/cwLe0kkcUTpJHtYxoLnOcdAAOZJ7Fi+WmGWYOyfw1hhse46326GCQaaflAwF59ri4rUe17ma7BGSxw7bakx3fEhdRsLDo6OmA/Lv7tQQwfn9y4JjffEN+oRG2gs5bpmpmhXCkuVQML0ExgtlIx5bG9rToZ3NHNzyCQTyboBpx13TsKuxPWX3FVRPda+Ww0tNDAyllqHvhbUPcXataToCGN6vpKG/DlwA/cul2yhg04R2abNLPCY6y8ufdp94aHST+jB/8AttZ966NaIrTazpzbLeCIi5GwiKx4uxZY8EYOr8T4jrWUluoojJLI7mexrR85zjoAOslBgmeWeNjyWwUyvq4PwjeawPbb7a1+50paPOe93HdjbqNTpqSQBx5bCwxdJ75gmz3qphZDNXUMFVJEzXRjnxtcWjXqBK5WZtZl3bNfMuuxZd2GGJzeho6Pe3m0tONd2PXrPElx63E9Wi6a5RCsGQmCxcHl9T+BKTfceZPQt/20W2pp7Kx5UrbMszWltq29yWTZTxMYZCyStENAHDslla1w9rd4e1bpUe9s6WGPZcq2SvDXSXKjbG36ThJvafcCfYs6fKFrdOcp4nVbR2e8uTmbnzaLNUQmS10jvwjcdRw6CMg7h/PcWM9RPYtXKUOx3mhgHAt8vVjxVLHa6+8SRfBrtUO0hLWAgQPd/V+c4uDjwOuh00GvfqzMVnDCsc8p+NaGjRo0HYFVeanuFHV0nwqlqoJoNNelika5unbqDotf4wz8ykwPvx33G1tNU0f9jon/AAqfXs3I9dD69F58RM9N8tkE6LW2Z2eeXuU8DWYouxfcJBvR2uiaJalw+kW6gMb9ZxA7NVGDMTbJxbi2u/FvKKw1NtFS7ooqyWL4RXz68PyUTdWsPf5x9SuGU+zRUUUlTm1tA1JZFTNdcX22ul6V790bxlrHEnUDTXo9TqdNforX2tvN1d2eIbqxhtG2XDWzxSZkSWSvo6u7tLbNZ7mGxz1Tup7g1x0i00eTz3dOtwXObE2Jb3i/FlfibEde+tuddIZZ538PUAOTWgcA0cAAFlWcmaNxzazSq8SVAkgt8f8AJ7ZROPCmpmnzRpyDnfKd3nTkAtkbKuR4zHxqcW4joy/DFmmH5KRvm11SNCI+9jeDndvmt6yt6VjTrulnM7pw2TssbNzWQ0WaGP7eXSO0ns9rnZwYObamVp+cebGnkNHHiRpJvNaV1LkPjKaJhc9tkrNBz1/IuH+6zBrd3UDksUzKxbh3BWV15xBioRvtcFM5klO7TWqLhuiFo6y8nd07+wFcs3m1sy1iIiHI1nCNoHUAv05znEFznOIAAJOvADQBfud8T6mWSKBtNE57nNha4uETSdQ0E8SAOGp7FWopqikn6Cqglgl3Wv6OVha7RwDmnQ9RBBHaCF6LnfS3UL7neaO2RtLnVU8dOGjr33hv+67HUdMyjt8FJENGQxtjaO5o0H7lysyGsf4w7S2CraYy9gukdTIPqw6yn/IurLfkrk9TPMQ2044VWJ5jZgWHLTLyvxbiGbSmpm6RwsIElRKfkRM7XOP3DUngCspkkbFGXvcGtaCS5x0AHaSuZ20pnLJmvmg+ntdQ44YtDnQW9gOjZ3cn1BH1tNG9jQO0rLSpvtha1sQwDMXMPEWZ+YFXivEc+s8x3IadhPRUsQPmxRg9Q14nmSSTzW9Nl/Zy/HmqgzAxvROOGoJN6hopG6fhKRp+U4f+C0j7ZGnIHXXez5k1U5wZmso6tkkWHLduz3SoZw1br5sDT9J+hHc0OPYundDQ0lstlPb6CnjpqWnjbFDDE3dZGxo0a1o6gAAFvram2NlVKVzzL9FjKam3Yow1rGaNY0aAADgAFxtq5Xz3GonkGj5JXvcOwlxJ/euxF7vFtw/h2tvl5rI6OgooXVFRPIdGxsaNST/y61yNxndrXf8AMS+XuyWsWy3V1dLUU1GDr0MbnEgevjqRyBOg4BV9L9moshc5zWhziQ0aAE8hz0HZxJPtX5e7djc49QJX1lp6iBkL54JImzx9LEXtLRIzUjebrzGrXDUcNQexe/Dlpkv2M7RY4gS+vroKQAfXka3/AHXXM8MnVrKiziwZGYQs+7uuprRSsePr9E0u/SSsxXzgijp6aOCFobHG0Ma0dQA0A/QvovLdTQG2Di64Ya2c5rdapejqr7WR2sua4td0bg57wD9YM3T3OKzrJjKuy5TZZUthtbHvqpw2quFS9xJnqCxoc7Tk1oADQByAHWsb2o8vrlmFs+1tLY4XzXa2TsudLDH8uUxgh7G/W3HOIHWQB1rwZO7TGX2MsB2+HEeI7dYcRU8LYa2kuUwpxI9oDTJG5+gc13PTXUakEcNVpzNOFfvlf9oTKmzZpZR1sNYxzLpa4Jqy21DXHzJQzUscOTmvDQ0g+scQrdsq4xrsZ7M1lqrnM6ert7pLY+V7i5zxERuFxPXuOYD6lj2eu0lgix5d3GwYMv1FiHEtzgdRU0NrkFQ2AyDcMj3M1GoBO60Eku0GmmpWabOeX9flts+2bD93j6K5yb9bVxcD0Ukrt7oz3tbutPeCk5inJ/64bXREWawiIgK14lO7g27O7KOY/s3K6K0YqO7ga8nsoZz+zckCMWwaP5rcUu7brH/p2qWiidsHD+aTEzu27M/07FLFX1flKtehRT27z/Mxh9vbeD/AkUrFFDbwP8z+HG9t3d/p3pp/KC3SSeDRu5c2Adluph+yar4rNhIbuAbI3soKcfsmq8qsrCIigEREBERAREQEREBNB2IiDHsW4GwnjqzOtWLsP0N3pT8ltTGC6PvY75TD3tIUVMx9h2F4muOWF/MLtC4Wm7uLmnuZOBqO4PB9amYivW9q9SiaxPbkDi/A2LsBXs2jGGH6201WpDBUM8yXTrjeNWvHqJXnwzivEmDL/He8K3uttFez+vpZC0uH0XDk9vc4ELrhiLC+HsW2CayYls9HdLfMNH09VGHt9Y7D3jQhQizu2QLphqOqxPlgKi62lmsk1nkJfVUzeZMR5zMHZ8sfWXRTXi3FmU0mOYZzk5tm2+71FPh/NaGG11jiI475TjdppDyHTM/qifpDVvbuqW0M8NTTx1FPKyWKRoeyRhDmuaRqCCOBBHWuMvHrGh5cVvLIraSxLlPXwWW6unvGEXP0koXHWSkBPF9OTy7TGfNPHTQ8VGpofdU1v9S6WIrThvEdmxZhehxFh+4RV9trYhLBURcnNP6QQdQQeIIIKuy5Woucu2NjT8ZtoZ9jp5d+jw9TNogAdR079JJT6xqxv2V0ExPf6LC2DrpiO4PDaW3UktXKddPNY0u09Z009q5C3q71uIMSXC/XJ5fWXCpkq53HrfI4uP6Touj09f6yz1J4ejCzrUzHNmkvkvRWtldDJWP3S7SFrw5/Ac9QCNO9ZnnTnFfc4sfPu9cZKW0UznMtltJ82niPznacDI7QFx9g4Ba2WV5c5fYgzOzCosJYdiBqJzvzVDwejpYR8uV/cOHDrJAHNdUxEf1LKJmeGTZGZMXbOPMBtuj6WlsVEWyXS4NH9Gw8o2HkZH6EDsGrjy0PTiy2Sy4SwnSWSzUUFutdvgEUMMY0bGxo/T1kk8SSSeas+XGXuH8ssv6LCeHafcp4G70s7gOkqZTpvSvI5udp7BoBwCsG0Bit+Ddm7Ft5hkDKg0TqSnPX0kxETSPVv6+xcWpedSzasbYc1cyMVPxvm7iPFbySy43CWaIa66RB27GPYxrVc8l8M/jhtA4Rw+6PpIprlHLO3+yi/Kv/AFWH71ggAAAHIcApRbD2F/wlnJecUSxExWi3dDG7slndp/kY/wC9dd520ZV5lPrXzO9cxNpzHxx7tFXiWnn6S22g/gqj0OrSIyekcPzpN/j2ALoXmpi38RclsS4r3tJaCgkfDp1zEbsY/wAbmrko50j3l8ry+RxLnvJ1LnHmT6ysPTV5mzTUn6X3BOGajGmY9jwnTa790rYqUkfNY53nu9jd4+xdeKGjp7fbaego4xHT08TYYmDk1jQA0fcAoBbE2Djes76/Fc8W9T2GhPRuI4CefVjfaGCT7wugg5clX1Fs2waccKpqis+JsUWHB2F6rEOJLpT2620rd6WondoB2ADm5x6mjiTyWDR6bxebZYbFV3i8V0NDQUkbpp6md26yNg5klc5c785MR5/ZkUWGMK0lWbGyqEFptjBpJWTOO6JpB9I9QPBjddeJJXzz62gr7nNfm2OzwVVDheGYCktwGstbJro2SUN5uJ+TGNQNes8VIzZ0yIhyjwhU5lY4pWfjMaOSdsL+ItkAYXOb/wCa4Dzj1DzR169Faxpxut2zmd3EINYow7Jh7G90wqamOrnoal1DJLD8h8rfNeG9oD94Dt016111sNvFqwtbbY35NLSxQD7DA3/Zcn8FxT4xz0sEc2rprvfoHya8yZKgPdr95XXAclPqZ6hGn9hcBwXOfayzh+MLM78VbLV9Jh6wSPia5h1bU1XyZJO8N4sb9o9ak5tU5w/Frla6y2Wr3MSX1j6emLCN6mh5Sz9xAO636ztfmlc8sN4du+LcWW/DVgpHVVxr5mwU8Q6yesnqaACSeoAlNCn/ALk1J+obEyJyOuudWKqykZXSWqz0EW9V3IQ9LuyO+RG1pIBceJPHgBr1hbzn2CZQ4/BszgR/a2r/AJSqTWU2W9qyqyvt2ErXpK+JvS1dXu6GqqHfLkPrPADqaAOpZyqW1rZ4TFIxyhbSbCFexwjnzS6KDrbT21w4eoy6LLbDsMZdUBa6+YkxBdiOJjidHSRu9jWl36ylKir7t/K2yGG4Jyqy/wAuqcx4OwrQWx7m7r6lrS+d/wCdK4l59WuijTtsZqPpqKiyos1TuuqWtrbvuHlHrrFCfWQXkdjW9RUuL3d6KwYcr73cpRFR0NPJVTv7GMaXO/QFyPxriy4Y6zDvGL7mT8JudU6oLCdejaeDGDua0Nb7FfQrutmVbziMQ/WCMH3fH+YNqwhY496tuM4ia4jVsTeb5HfVa0Fx9XeuruCMH2bAWALXhOwwdHQ2+ERMJHnSO5ukd2uc4lx7yoz7E2V7bbhatzQutN/K7nvUls328WUzXefIPz3jT1M71LfUAqNe+6cJpXEPzLNFBC6WaRscbGlznvOgaANSSTyC5v7TueJzUxy2x4fqXOwpaJHCnc3gK2bk6c9rdNWs7tT85bD2p9pBl5bWZYYBrg+gBMN3ukDuFQQdDTxOHzNeD3fO+SOGuuJbM2zpLmPc4sa4wpHswlSyaw07wWm5yNPyR/YtPyj84+aOsi2nSKRvsi05nEL7subOAxRLT5j49t29Y4z0lsts7eFc4HhNI084geQ+eePyRx1ftPz01RtY4wdStDWMmgicBy3m08TXfpC6dwwQwUzIIYmRRMaGMjYN1rWjgAAOQA6lyYzZugvWfOM7oDq2e9VRae5shYP0NCto3m95mVbViIw29sU2I3PaMnu5b5lptU0oJHJ8jmxD9Beuh3IcVEPYQw/0GDsW4pfFxq62GhiefoxM33D75R9yl25zWtJcQABqSTpostec3lenSNu2Hms/BuVseDbPVmK8YiDopHMOjoaQcJXdxfqGDuL+xQAtdsrrzeqOz2qlfU11ZMynp4GDjJI52jWj2lZ1nlmDJmXnnfMSMlLqBsvwO3t14Np4iWtI/OO8/wC2t2bFGV7bxi6uzOutPvUlqJo7aHjg+pc38pIPzGEAd7z2Lor/AIqZ+1J/qUrMmssrflRlRb8L0ojkqwOnuFWwaGoqXAb7vUODW9jWhbALgOapwazgop7UW0jHhajq8uMC1wdfpmGK5XCF3C3sI4xsI/riDx+gD9LTTkrE3s1mYiGu9rrPaPE92flfhOtElnoZgbpUwu1bVVDTwhB62MPE9RePq8cS2bNnyozUxA3EmJqeWHB9FLo8cWm4yN/qWHnuD57h+aOOpFm2fsh7nnFi34TXCejwpQSD4fWt4Omdz6CI/TPW75oOvMhdKLPZ7Vh+wUlmstBDQ0FHEIaemhbusjY0aAALe94067Ks6xunMufe2dHbKPP22Wq10kNLDQ2CmhEMLQxjG9JLuNa0cAA3q71iGzJYfxg2qcJQObrHSVD7g/uEMbnD9bcHtXq2q7oLptY4oLXatpfg9GB2bkDNf0uK2RsK4e+F5o4lxLJHvMt9uZSscRyfNJqdO/di/StM7dJXuyeDfkhVRFxN1Dp1rTmO9mPKPMG/S3q6WGe33GZxfPU2qc05ncfnPaAWl3fpqevVXfOrKeqzcwpbrPS4urMNuo6z4WailY5zpB0bmbh0e3h52vPqWkH7F11iidI/PK+Na0bznOhkAAHMk9PwV6Y73YVn/jcGX+zhlTlvemXmx2KWqukR1hrrlMamSA6aaxg6NYe8DXvW2x6tFzFxRg6U5hQYGyozFxPmFeXPLZzRCSKnj04HSTpSHAHm/gwfSJU5tn3LvEuWWUDLDi28C5XWerkrZXNlfKId9rAIg951dpuc+A1J07TbUrjmZyis/WG1URFkuIiICsuMDu5fXx3Zb6g/snK9KxY1O7ltiB3Zbak/sXJHYjfsIN0ycxEe27j/AE8alaoq7CI/mTvzu28f/wCEalUr6nylWvQom7eJ0ypww3tuz/8ATvUslErbyP8ANlhRvbdZf9O5NL5wW6SfwwNME2cdlDB/Darsrbh0buEbWOykhH6jVclSVhERAREQEREBERAREQEREBERAVCNRoqogh7tZ7PlHPaKzNTBVA2GspwZr1RQN0bPH86pa0cnt5v0+UNTzB1hGuzNRDDU0stPURNlikYWPjeNQ5pGhBHYQuSmaOEm4EzlxLhKIEQW+vkjp97n0J8+P9RzR7F1+nvM/wAyx1K/bdWx9m7U4SzLZl9dqpxsl+k3aZr3ebTVmnmkdgk03T9bcPaugo46FcaaOuqbXcae50byyopJWVETgdC17HBzT94C7EWW4Nu2G7fdWgAVdNHUAD67A7/dU9RXE5hbTnKPm2njT8X8hocMU8u7VYhq2wOaDx6CLSST7yI2/aXPPnxUldtu+1Vw2gqGzSMeymtlpjMQPJzpXuc5w/wtb9lRrDXOcGtBJJAAA1JJ5D1rfQriil55eu02q5X2+0dms9FLW3CsmbBT00Q1dK9x0AH/AD6hqepdOMg8lrZk/l42jd0VTiCuDZbpWtGu8/ThEw/+GzUgdp1cefDXmypkAcC2SPH+L6HdxNXxfyWlmb51ugcORHVK8fK62jzfpKTq59bV3Ttjpelcch5KKu3RfTR5Q4ew+x2jrldeleO1kMZP+Z7FKpQZ28bg9+PMHWnf8yG31FSW9hfI1oP6hVNGM3ha/SI66DbEeGxasg6y/wAkZbLebnJI1xHyoogIm/rCQ+1c+Cd1pceQGq6v5H2H8WdnXBtmLdHRWqGSQaaefI3pHfrPK6PUziuGenHLVe21en2/Z1p7ZG9zTc7vBC8DkWMDpSD7WN+5c9V0T2zsK1uINngXS3wvmfY6+OvmawakQlro3u0+rvgnuBXOzRT6fG3CNTt0K2JLHBb9nmpvIjHwi6XWd7n6cS2INiaPYWuPtUk3HRpKgzsx7RWC8usorjhbHVwnpTSVjqm3iCmkmdOyUbz2DdGgLXgniRrv9y/WZ221dbpTTWnLCzy2qN/m/he4hr59P7OIatYe9xce4LC2ne154aRaIhJbNnPTBGUVoL75VfDLvIwupbNSuBqJewu6o2fXd7ATwXPrMPNHMLPXHVLFXiepL5uitlht7XOjic7gAxnN7z1vPH1DgvxgHK/MjPHGM89sjqa0yy79wv1xe4wxkniXyHUvd9Rup9QU/Mndn7BmT9uE9BD+E8QSM3Ki81TB0hB5tjbyiZ3Dieslafxpf7lXm/8AxgGztsv0WXzqbGWOYoK3FWm/T02ofDbdR1Hk+XTm/k3k3tOx9oy/Ow5svYyro5QySSgNHGe10zhFp+uVtIDgOCi/tx334BkhZ7Ex2j7pdmFwB5shY559m8WfoWNc3vGV8YhFvZmtYum1bg2Dd1ZBUyVRH/lwvcP0gLplf77a8MYVrsQXuqbS2+ggdUVEzuTWNGp9Z6gOs6Bc8djekNRtT0M+mopbbVy+rVrWf/JZ9tnZxG43hmU1hqv5JRvbUXh7HcJJvlRwepoIe4fSLR80rXVrN7xWFKziuUds1MxLnmlmjc8YXTeiZO7o6Wmc7UUtO3Xo4/YNSe1xcVMrZEySOEcK/GLiSk3L7d4R8Dhlb51HSO4gkHk+TgT1hu6OsrQuyzkkcyse/jPiCjLsLWWVrpGvHm1tSNHNh72t4Of3bo+cujbWhrdAAB3JrXiI2VKV+5V6kRFzNRERBHfbMxbLh3Z1fZ6WXcnv9ZHQO059CNZJPvDA37S5/wCGLDVYrxvaMM0RIqLpWxUbHD5pkeG73sBJ9imHt6tnNhwM8NPwcVVWHO6t8xx6a+wO/Sor5U4rtmB86MPYuvFPPUUVsqTUSRU4BkdpG8NDQSBrvEcyuzRjGnwxv8uXVi0Wu14TwjR2mhbFSWy2UrYIw4hrY4o26ak9XAaknvUL9ovardfI6vAmWFa5lteDDX3yIkOqRyMcB5hh46yc3cm6DidW5xbSONs3C60AGx4c3tG2qklLjPx4dO/gZDy80AN7ieK2bkJsj1t8dS4vzUpJKO2aiWmsT9WS1I5h0/Wxn1PlHr3RwNK6cU/q6ZtNuIYds67OFfmhcYcUYogmosHQP1HNj7k5vNkZ5iPqc8epvHUjojb7fRWq2U9uttLDS0lNG2KGCFoayNjRoGtA5ABfujo6ahoYqOkpoaenhYI4oYWhrI2gaBrQOAAHUF91jfUm85letcPPXVTaK2VFY8athidKfU0E/wCy431VS+tuFRWSOLn1Er5iT1lzi7/ddfsYOezL2+vj+W23VBb6+icuPEH/AGeL8xv7gt/Tfamq6W7ItpbbNlGwTADeuE1TWu0696ZzR+hgWQbRmLpcFbNuJ7tSydHWTUwoaZ3WJJ3CLUd4DnH2L77PFK2k2XcDQhugNqik/wAer/8A5LXm202oOzTCYGuMYvdKZiOpu7IBr9rcWMf1qc+V+queTI3PeyGFm89xDGN7SeAC61ZWYLpcu8n7BhKmjAdRUjRUOA4yTu86V59by79C5TYdraS24xtFyr2OfSUtdBUTsYNS5jJGucAOs6Aremc21hi3MSmqbDheKXDWHXkiTcl/ldWzskkHBjT1sb7XFdOtS15iI6Z0tEctxbRO1ZT2FtXgjLCujqLvxhrb1EQ+Oi6iyE8nS/W5N7zyjtkhkXiPOnFrqqeSoo8OQTE3G7v850jidTHGXfLlOvE8Q3XU8dActyG2Wb5mKabE2MmVFmwqSHxRablRcB9QH+jjP0zxPzR84dALFYbPhnDtJYrDbqa3W6kjEUFLTs3WRtHYO3rJPEniVna1dONtO1orNuZfDDGGLHg3ClFhvDdBFQ22jj6OGCMch1knm5xOpLjxJJJV46uKqqHl7VzNHJXN65m8Z/Y0uWuolvVVun6rZCxv6GhTF2FrO2lyZv8Aey3R9deDFr2tiiYB+l7lB7Fb3yY+vr5PluuVSXevpnroNsZ03QbLVDIP6+41kp//ACbv/wAV2a3GnDGnySBREXG2YjmJmThPK7CDsR4uuBpqYv6KGKNhfLUSaFwjjaObtAT1AAEkgKIdxzIxLtKXqe33XHVjy0y9jk3JqaouMbKutA6nNLgZDy4HSMfXIUsszsqcJZtWCis+L4619NR1PwqIUlQYXb+45nEjmNHHgtX+RbkiTqaS/f8Aub/+S0pNIjntWYmWRZd1WzxldhoWfCGMMJUjXAdPVPukL6ipcB8qSQnV3q4AdQC2nY8Q2LE1udcMPXigutI2QxGoop2zMDwAS3eaSNRqOHeFonyLckf/ANJfv/c3/wDJbXy1y0wvlVhCXDOEoquOgkqn1bhVTmZ3SPDQfOPVowcFW23uJTGWZIiKqRERAWP47O7ldiR3Za6o/sXrIFjmYJ3cpsTu7LTVn9g9THYj3sJD+Yq9u7by7+BEpTqLmwmP5gbu7tvT/wCBEpRq2p8pVr0KI+3of5usIDtuk3+ncpcKIm3of+AcHD+85z+wKnS+cFukrLGN3DNuHZSxf5AvevHaBu2CiHZTxj9UL2LNYREQEREBERAREQEREBERAREQEREFDpoSuYu1VPBUbW+LXQEENdTRuI+k2miB/Tw9i6YXO40dps9Xc7hM2GkpIX1E8rjwYxrS5xPqAK5EYzxLPjLMS+YrqW7sl0rpavd+i1ziWt9jd0exdHpo/qZZ6k8LH0b5vyMTd6R/mNaOsngB95XYrDVA+1YMtFsk136Wihpz62Rtb/suY2zxgh+PdorDtrkh6ShpJxcq3UatEUJD9D+c/cb9pdTG/J4p6m3MQjTYVjzKTLzMtsJxnhmluU0DSyGp3nRTRtPMNkYQ7Tu10VkwZs8ZQ4DvUV4sOD4PwjCd6KrrJpKp8R7WdISGnvA1W0UWG6cYy0xCmgA0VURQkXP7bnlc7P6xxE8GWCMj21E2v7l0BUBtuulLM6sN1mnCaybgPeyd+v8AnC20PmpqdIw0dMa25U1EDoaiZkIP5zg3/ddkKOmjo7fBSRNDY4Y2xtA5ANAA/cuQOEGCTMTD7HcjdKQH/wDOxdhBy9qv6nuFdJ+J4IammkgqImSxSNLHxvaHNe0jQgg8wR1KMuNdibL3EF0mr8LXe4YWfKS40sUbammaT9FjiHNHcHaDq0UnkWFbTXppMRPaFkWwTN04E+aDRFrxLLT52ndrLothYP2Lcq7BUx1WIJ7pieZjtejrJBDTn1xx6E+ouIUkUVp1bz9o2Q8lutVts9rgttqoKaho4G7kVNTRiOOMdjWjQBetEWawon7dWHLlcctsN4lpIXyUlprZY6stGvRtma0Neexu9GG6/WClgvPW0VLcaKairqeGpppmGOWCZgeyRpGha5p4EEdRVq22zlExmMOPljxFiDC90Nzw3erhaK3o3RGpoZ3Qv3DzbvNI4HQfcFsnKDInG+dOIhXtFRR2EzF1dfqoF2+ddXiLe4yynU9wJ849RnnR7O2SVDdvwlT5bWLp9d4CSIyRg90biWj2BbIpaOmoqaOmo4IqeCJu6yKJgYxg7ABwA7gt7eo/MM40/K0YPwfYcDYLoML4bohSW6ij3I2A6ucebnvPznOOpJ6yVfkRczUREQEREGKZhZd4XzOwXLhjFlC6oo3vErHxO3JYJBrpJG/5rhqR1ggkEEFRxl2DsLOrS+HMG+Mpt7XonUkLn6dm9wHt0UuUVq3tXqUTWJ7aey42acq8trhFdLdZ5bpdouLLjdnid8Z7WN0DGHvDde9bgAAVUUTMz2mIwIiKB4L3SGvw1cKFo1M9NLEPtMI/3XHAxmD8kecfmH2cP9l2dPJcjMz7A/DGcuLMPmMsFJdKlkbfqF5cz9VzV0+mnmYZavTpzkrF0OzpgWMji2w0f8FqyPFOF7HjPCNdhnEdAyutlbH0U0D+Go5ggjiHAgEEcQQCrHlE+J+QeCnQuDmGx0ehHX+Ras0XPPeWkdIlXDYQwhPcXyWzHd9o6Yu1bDNTxTuaOzf83X1kLPsA7JeUuCbhBc6mgq8R3GEh7Jrw8SRscPnCFoDNfzgVvdFadS0xjKNsPyGNa0NaAAOQC/WiIqLCoVVUPIoORGY1CbZnJiy2nXWnvNZFx7p3roTskRCPZLw2QPlvqnf/ANiT/koX7UFidYNqrFLNwtjrpYrjGdNA4SxtJI+0Hj1gqa2ye6N2yNhMRuBLRUh+nUfhMv8AtourWnOnEsqfKW6URFytWs86MI5k4wwrbqLLLGbcL18NZ01RUulfH0sXRubuasaT8otPsWlPiP2svT5H73P4aluitF5jiETXKJHxH7WXp8j97n8Nb1ycwvmBhLAE1rzIxYMS3h1bJMytEj36QlrA1mrgDwIceXWthIk3meJIjAiIqpEREBYzmKdMoMVHss9Z/AesmWMZkHTJvFp7LLWH9g9THY0NsKjTZ4uZ053uT+BCpQKMewuP+rjcT23yb+BApOK2p85Vr0KIW3qf+B8GDtuNQf2Kl6og7evHB+CW9tfU/wAFqnS+cFuktbcN200o7IWf5QvSvhRjS3QD+zb+4L7rNYREQEREBERAREQEREBE1HaqajtCCqLWmNM/spsBPkgv2MqF1YwcaGhJqp9ewsj13T+cQtA4q26mPqTQ5f4EmqZHu3Yp7vLul56tIItSf8SvXTtPUKzaITILgOatl6xHYMN291diC9UFrpmjUzVtQyFv3uIUNaOXbOzfDJGTzYQtMvKQsba2Bp7Bo6dw0Wq888rbZljTUlLiXMStxXjitImfTtBMVJD1ySPkc55LjwaPN10JPAcbxpRnEyibf6bJ2mdp614vsE+XuXVTJPbKggXK7AFjahgOvQxa8SwnTecdNdNBwJKiVzKdWpPDrJU09l3ZqNOKPMvMK3azECa02moZ/Rjm2olafndbGHl8o8dNOmdulVnzeVu2X8lM5sPXY40iraDCdBXwtjfBc6H4VU1cO9vAdHvNMQJ46lwPLgptRh7YmtkcHOA4uA01Pbp1KoAHUqrivabTmW1YwIiKqRERAUPdu/Dj5sN4SxZFES2lqZrfO8dQlaHs17tY3feFMJYrmNgS0ZkZaXbB94bpBXRaMmaNXQSjiyVve1wB7+I61alttolFozDk1Y6ptDim11rnbraetgmLuwNla4/oC7GRyMewOYdQRvA9oK5RY7yWzJy+v01rv2FrhNEHFsVfQ076imqG/Sa9oOmo+adCOsKU2zvnJnhdam1YLvmW9dd7dCGQOvtRHJQupYQAN6V0jd2UgDhpo53eeK6NeItEWiWdMxxKXSKg104qq5WoiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgdSihtMbMl9zAxc3HmABSy3WaJsVfbp5RD05YNGSxvPm727o0g6a6A681K9UIB5q1bTWcwiYy0RsyyZi2HL6PL3MPBdztMtmaWUNxkLHw1EG9qI95rjo9mpA6i3TsW+F+dADqGhfpRM5nJEYERFCRERATqREEdtpvZ7rs2qSgxHhWalixJb4jTmGpduR1kBO8GF/zXNJJBPA7xBI4FWrZbt2auW8FblvjzAlypbW6d9XQ3WN8U0ML3Ab8T3MefNcRvNIHMuB5hSdPPkqbrSdd3j2q++du1XbGcqjkqoBoNAiosIiICIiAiIgIiICxXM07uSuL3dlkrf4D1lSxLNI7uR2MT/clZ/AepjtEtKbDIA2bK4/37P/AAYFJhRp2HBps1Vnffag/soVJZW1PlJXoUQdvLjhvAre2vqf4bFL5RA27+NnwA3tr6n/ACx/81Ol84RbpLmk4UMI+o39wX2Xyp/+yRD6g/cvqs1hERAREQEREBFQuA7fYtSZk7R+V2Wr5aO43v8ACl2jH/ddq0nlB7HnXcj+0Qe5TETPSJnDbixfF+YmCcBW/wCGYwxLb7TGeLWVEv5ST8yMaud7AVBXMPbJzKxU6ajwo2DCNtdqA6nImq3N75nDRv2Wj1rCMCZJ5s5zXY3ikoqt9LO7WW/3qV4jd2kPdq+X1NB9YW0aHGbThTf9QkRjvbmtNKZKTLnC01weODbhdyYYvW2Jp33D1lq0k7Fe0ftDXCSgttTe7lROO6+C2j4FQRDse8FrT9pzipOZc7G2XOFWw1+LXyYtuTdHFtU3o6Rh7oQfO+2T6gpE0VBRW2hjorfSQUlLEN2OCCMRsYOwNAAATfSvwhO2Z7Q4y/2GowyKszJxOdTo51ssnmj1OncNT9lo9ak3grKbLvLymazCOFLdbpQNDVCPpKh/D50rtXn71kt4vVow/Zai73u5UtuoKdu/NU1UojjYO9xUMc7Nsior21GG8o3SUtOdY5cQysLZHjkfg7D8gfXdx7AOarG/UnB/NW3s/tpOxZV26awYfdT3XGMjNGU+u9FQgjhJPp19Yj5nr0HPnheLxdsSYjqr1eq6ouNzrpTLPUSnefK8+r2AAdgAC9uHsN4px7i5low9ba29XereZCyPV73EnjJI8ngNeb3HTvU9chtlmyZbmmxTi4095xUAHxjTep7ef7MH5bx/4hHD5oHM7xt0Y/2pzdgezZstOo56PMDM+3AVDSJrdY6huvRHm2Wdp+d1tjPLm7jwEyGgDXQ6oBoFVctrTacy1iIjoREVUiIiAiIgIiIKEanXUoG6HmT6yqogIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICw7Ng7uRGMz/clZ/BcsxWFZvu3cgcaH+5Kv+C5THcIlqHYgGmzPUd97qT+ziUk1G/YjGmzLIe281J/VjUkFbU+UlehRA26uNNl4ztrqn90Sl+tN595ERZ3UNji/GWSyzWqWV7XimE7JGyBocC3eaQ4bg0OvbwTTmItmUWjMNvwECnYNfmj9y+moUPvIeuPplufuT/HTyHrj6Zbn7k/x1O2v6Mz4TB1CahQ+8h64+mW5+5P8dPIeuPplufuT/HTbX9GZ8Jg6hNQofeQ9cfTLc/cn+OnkPXH0y3P3J/jptr+jM+EwdQtd5r50YLyhsLK3Eda6WtnBNJa6XR9RUkdYBOjW683u0A7zwUX8ebI9ywTlpfMWjNS7XH8F0UlX8EjpHtMu4NdNemOg7TodBqVEqaeeol6WonlmfppvyvLzp2anqWmnoxbmJVteY+m580tp/MnMmWaip65+G7E4kC3WyUtdI3+1mGjn+obre5YLl3ldjTNLEn4IwjaXVG6Qaisl/J09MD86STq9Q1ceoKx4borHccVUVFiS9yWS1SvLai4R0rqkwN0OjujaQXcdBw7dVt1mA8jqOi3qfaaqo2E7xhp7BVA69paHDit5xSMVZ99pP5V7IeAcEGC6YrDMWXpmjwaqPdpIXfUh+d636+oKRMccUcTY42NaxoDWtaNAB2AdQXK29w5a29jhZ81ca3uQcujtBpmH7UlTr+hYLJdbh0ruhutz6Pq6Spfrp36FZTo2vzMrxeI+nYO53W2WW2S3G7XGloKSJu9JUVUrY2MHaXOOgUZ8yttTB2H2y27L2iOJ7gNW/DJN6GijPaD8qX7IAP0lCWxYdxnjuubbsP2m9YhlB16OnZJUNYe0k6tb6yQt/YL2Jcw73EKnF95t2GIiNRA0fDaj7Qa4Mb/iJVfapT5SbpnqGlceZn4+zTvjarFl7qbgQ/8Ak9DCCynhJ5COFvDXq14uPaVtnKfZDxxjYwXbGXS4VsjtHBszAa2dv1Yz/Rg/Sfx+qVsaPYN6KVssOak0cjTq17LVuuHqIm1C9R2HrkTqc5bnr/8Asn+Or21a4xWcIis/aSeAMtMF5Z4cFmwhZYaGJ2hmnPnz1Dh86SQ8XH9A6gFl3BQ98h64+mW5+5P8dV8h64+mW5+5P8dYTFZ7s0zPhMHUJqFD7yHrj6Zbn7k/x08h64+mW5+5P8dNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CahQ+8h64+mW5+5P8AHTyHrj6Zbn7k/wAdNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CahQ+8h64+mW5+5P8dPIeuPplufuT/HTbX9GZ8Jg6hNQofeQ9cfTLc/cn+OnkPXH0y3P3J/jptr+jM+EwdQmoUPvIeuPplufuT/HTyHrj6Zbn7k/x021/RmfCYOoTUKH3kPXH0y3P3J/jp5D1x9Mtz9yf46ba/ozPhMHUJqFD7yHrj6Zbn7k/x08h64+mW5+5P8dNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CahQ+8h64+mW5+5P8AHTyHrj6Zbn7k/wAdNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CahQ+8h64+mW5+5P8dPIeuPplufuT/HTbX9GZ8Jg6hNQofeQ9cfTLc/cn+OnkPXH0y3P3J/jptr+jM+EwdQmoUPvIeuPplufuT/HTyHrj6Zbn7k/x021/RmfCYOoTUKH3kPXH0y3P3J/jp5D1x9Mtz9yf46ba/ozPhMHUJqFD7yHrj6Zbn7k/x08h64+mW5+5P8dNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CahQ+8h64+mW5+5P8AHTyHrj6Zbn7k/wAdNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CahQ+8h64+mW5+5P8dPIeuPplufuT/HTbX9GZ8Jg6hNQofeQ9cfTLc/cn+OnkPXH0y3P3J/jptr+jM+EwdQmoUPvIeuPplufuT/HTyHrj6Zbn7k/x021/RmfCYOoTUKH3kPXH0y3P3J/jp5D1x9Mtz9yf46ba/ozPhMHUJqFD7yHrj6Zbn7k/x08h64+mW5+5P8dNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CahQ+8h64+mW5+5P8AHTyHrj6Zbn7k/wAdNtf0ZnwmDqE1Ch95D1x9Mtz9yf46eQ9cfTLc/cn+Om2v6Mz4TB1CwfOV4bs9Y2OoH/QlX/Cco7eQ9cfTLc/cn+Ovy/Ybr5I3RvziuD2uGha6hcQR2EGdIrX9GZ8M32JwBsx+u8VX7mKRq17kzlfBlDlhDg+G7yXVzamWqkqnwiLec88g0E6AAAcythKt5zMzCY6ERFVJxVOKqiCnFOKqiCnFOKqiD5ywxTwPhnjZLHI0sex41a4HgQQeYUbsfbF2XWJ6qa4YVrKrCdXIS4w0zRPSE90TiCzj1NcB3KSqKa2mvSJiJ7QJrdhPMKOR3wDGeGqhmvm9MyeEn1gNcvJBsM5qPl3Z8R4SiZr8ps87z93RD966AotffurshDHD2wa3ebJizMJ7gDxhtNEG6j8+Qn/KtxYW2UclMMFkpwub1UsIImvE7qjj+ZwZ+qt2Iqzq2n7TFYh5Lda7baKBlDarfS0NKzg2ClibFG31NaAF6vUqos1lOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKcVVEFOKrxREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQf/Z';
  const UNITS = [['Pcs', 'Pc'], ['Pairs', 'Pair'], ['Sets', 'Set']];
  const STATUS = {
    Pending: { l: 'Pending', cls: 'upcoming', icon: '⏳' },
    Won: { l: 'Deal hui', cls: 'green', icon: '✓' },
    Lost: { l: 'Deal nahi hui', cls: 'red', icon: '✗' }
  };
  const CAT_GUESS = [[/bangle|kangan|chud/i, 'Bangles'], [/mangal/i, 'Mangalsutra'], [/bridal|dulhan/i, 'Bridal Sets'],
    [/necklace|haar|choker|set\b/i, 'Necklaces'], [/chain/i, 'Chains'], [/ear|jhumk|tops|stud|bali|kundal/i, 'Earrings'],
    [/pendant|locket/i, 'Pendants'], [/bracelet/i, 'Bracelets'], [/kada/i, 'Kada'], [/payal|anklet|pajeb/i, 'Payal / Anklets'],
    [/nose|nath|laung/i, 'Nose Pins'], [/coin|biscuit|sikka/i, 'Coins / Biscuits'], [/ring|anguthi|angoothi/i, 'Rings']];

  /* ---------- register the collection (works whether or not the store has started) ---------- */
  if (!COLS.includes(EST)) COLS.push(EST);
  if (!Array.isArray(S[EST])) S[EST] = [];
  if (typeof DB !== 'undefined' && DB) {
    try { DB.collection(EST).onSnapshot(snap => { S[EST] = snap.docs.map(d => ({ ...d.data(), id: d.id })); scheduleRender(); }); } catch (e) { console.error(e); }
  }

  /* ---------- tab next to Deals Ledger ---------- */
  const di = PARTY_TABS.findIndex(t => t[0] === 'deals');
  if (!PARTY_TABS.some(t => t[0] === 'estimates')) PARTY_TABS.splice(di >= 0 ? di + 1 : PARTY_TABS.length, 0, ['estimates', 'Order Estimates']);
  PT_VIEW.estimates = 'estimates';
  if (typeof VIEW_ALIAS !== 'undefined') { VIEW_ALIAS.estimates = ['parties', 'estimates']; VIEW_ALIAS['order-estimates'] = ['parties', 'estimates']; }
  if (!ui.eStatus) ui.eStatus = 'Pending';

  /* ---------- styles ---------- */
  const st = document.createElement('style');
  st.textContent = `
  .est-ph{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-top:10px}
  .est-ph .ph{position:relative;width:76px;height:76px;border-radius:12px;overflow:hidden;border:1px solid var(--gold-line);background:var(--card2)}
  .est-ph .ph img{width:100%;height:100%;object-fit:cover;display:block}
  .est-ph .ph button{position:absolute;top:3px;right:3px;width:22px;height:22px;border-radius:50%;border:0;background:rgba(0,0,0,.6);color:#fff;font-weight:800;cursor:pointer;line-height:22px;padding:0}
  .est-ph label.add{width:76px;height:76px;border-radius:12px;border:2px dashed var(--line2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;color:var(--muted);font-size:11px;font-weight:700;cursor:pointer;position:relative;text-align:center}
  .est-ph label.add input{position:absolute;inset:0;opacity:0;cursor:pointer}
  .est-ul{margin:0;padding-left:18px}.est-ul li{margin:4px 0}
  .est-hist{font-size:12px;color:var(--muted)}.est-hist div{padding:4px 0;border-bottom:1px dashed var(--line)}
  .est-row-btns{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
  .est-tot{display:flex;gap:14px;flex-wrap:wrap;font-size:13px;margin-top:6px}.est-tot b{color:var(--head)}
  .est-deals{display:flex;gap:4px;flex-wrap:wrap;margin-top:6px}
  .item .ig .f.tot input{border-style:dashed}
  `;
  document.head.appendChild(st);

  /* ---------- helpers ---------- */
  const estList = () => S[EST].filter(x => !(typeof multiFirm === 'function' && multiFirm()) || (x.firmId || 'main') === activeFirm());
  const findEst = id => S[EST].find(x => x.id === id);
  const partyCol = type => (type === 'purchase' ? 'suppliers' : 'customers');
  const partiesOf = type => S[partyCol(type)] || [];
  function findParty(type, name, id) {
    const L = partiesOf(type);
    return (id && L.find(p => p.id === id)) || L.find(p => norm(p.name) === norm(name)) || null;
  }
  const defMelt = p => (p === '22K' ? '92' : String((PUR[p] || {}).t || ''));
  const guessCat = n => { const g = CAT_GUESS.find(([re]) => re.test(String(n || ''))); return g ? g[1] : ''; };
  const unitOf = it => UNITS.find(u => u[0] === it.unit) || UNITS[0];
  const unitLabel = (it, n) => (num(n) === 1 ? unitOf(it)[1] : unitOf(it)[0]);
  const qtyTxt = it => { const q = num(it.qty) || 1; return q + ' ' + unitLabel(it, q); };
  const fmtW = n => String(+num(n).toFixed(3));
  function wRange(a, b) {
    a = num(a); b = num(b);
    if (!a && !b) return null;
    if (!a) a = b; if (!b) b = a;
    if (b < a) { const t = a; a = b; b = t; }
    return [r3(a), r3(b)];
  }
  const rangeTxt = r => (!r ? '' : (r[0] === r[1] ? fmtW(r[0]) : fmtW(r[0]) + ' – ' + fmtW(r[1])) + ' gm');
  function itemTotal(it) {
    if (it.totalManual) { const r = wRange(it.totMin, it.totMax); if (r) return r; }
    const p = wRange(it.wMin, it.wMax); const q = num(it.qty) || 1;
    return p ? [r3(p[0] * q), r3(p[1] * q)] : null;
  }
  function sumRanges(list) {
    let a = 0, b = 0, any = false;
    list.forEach(r => { if (r) { a += r[0]; b += r[1]; any = true; } });
    return any ? [r3(a), r3(b)] : null;
  }
  const estTotal = e => sumRanges((e.items || []).map(itemTotal));
  function perTxt(it) {
    const p = wRange(it.wMin, it.wMax); if (!p) return '—';
    const q = num(it.qty) || 1;
    return rangeTxt(p) + (q === 1 ? (it.unit === 'Sets' ? ' (full set)' : '') : ' per ' + unitOf(it)[1].toLowerCase());
  }
  const meltTxt = it => (it.melting ? `${it.melting} (${it.purity})` : (it.purity || ''));
  const longDate = s => (s ? parseD(s).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : '');
  const addHist = (e, t) => { e.history = [...(e.history || []), { at: Date.now(), t }].slice(-40); };
  const blankItem = () => ({ id: uid('ei'), name: '', desc: '', category: '', qty: 1, unit: 'Pcs', purity: '22K', melting: '92', wMin: '', wMax: '', totMin: '', totMax: '', totalManual: false, wastage: '', labour: '', photos: [] });

  function autoNotes(e) {
    const its = (e.items || []).filter(i => i.name);
    const L = [];
    if (its.some(i => (i.photos || []).length)) L.push('Design as per reference photo');
    const purs = [...new Set(its.map(meltTxt).filter(Boolean))];
    if (purs.length === 1 && its[0]) {
      const it = its[0]; const gold = metalOf(it.purity) !== 'silver';
      L.push(`Purity: ${it.melting ? it.melting + ' melting (' + it.purity + (gold ? ' gold' : '') + ')' : it.purity}${its.length > 1 ? ' for all items' : ''}`);
    }
    its.forEach(it => {
      const w = perTxt(it);
      if (its.length > 1 || purs.length !== 1) L.push(`${it.name}${it.desc ? ' (' + it.desc + ')' : ''}: ${qtyTxt(it)}${w !== '—' ? ', ' + w : ''}${purs.length !== 1 ? ', ' + meltTxt(it) : ''}`);
      else if (w !== '—') L.push(`Weight approx. ${w}`);
    });
    const t = estTotal(e);
    if (t) L.push('Total order weight: ' + rangeTxt(t));
    if (e.deliveryDate) L.push('Delivery on or before ' + longDate(e.deliveryDate));
    return L.join('\n');
  }
  const noteLines = t => String(t || '').split('\n').map(s => s.replace(/^[\s•\-*]+/, '').trim()).filter(Boolean);
  const notesOf = e => [...(e.autoNotes === false ? [] : noteLines(autoNotes(e))), ...noteLines(e.notes)];

  function cleanItem(it) {
    const nz = v => (v === '' || v == null ? '' : num(v));
    return {
      id: it.id || uid('ei'), name: String(it.name || '').trim(), desc: String(it.desc || '').trim(),
      category: CATEGORIES.includes(it.category) ? it.category : '', catManual: !!it.catManual,
      qty: Math.max(1, Math.round(num(it.qty) || 1)), unit: unitOf(it)[0], purity: PUR[it.purity] ? it.purity : '22K',
      melting: String(it.melting ?? '').trim(), meltManual: !!it.meltManual,
      wMin: nz(it.wMin), wMax: nz(it.wMax), totMin: nz(it.totMin), totMax: nz(it.totMax), totalManual: !!it.totalManual && !!(num(it.totMin) || num(it.totMax)),
      wastage: nz(it.wastage), labour: nz(it.labour), photos: (it.photos || []).filter(p => p && p.src).map(p => ({ src: p.src })),
      ...(it.dealId ? { dealId: it.dealId } : {})
    };
  }

  /* ---------- deals ledger sync ---------- */
  function dealNote(e, it) {
    const t = itemTotal(it);
    return `Order estimate ${e.no}${num(e.rev) > 1 ? ' (Rev ' + e.rev + ')' : ''}: ${qtyTxt(it)} · ${meltTxt(it)} · ${perTxt(it)}${t ? ' · total ' + rangeTxt(t) : ''}${it.desc ? ' · ' + it.desc : ''}`;
  }
  function dealFrom(e, it, o, party) {
    const t = itemTotal(it);
    const p = party || findParty(e.type, e.partyName, e.partyId) || {};
    const cat = CATEGORIES.includes(it.category) ? it.category : (guessCat(it.name) || 'Others');
    const purity = it.purity || '22K';
    const rule = !o && typeof findRule === 'function' ? findRule(p, cat, purity, '') : null;
    const base = o || {
      status: 'New', priority: 'Normal', creditDays: num(p.creditDays) || 30,
      pos: String(settings().gstin || '').slice(0, 2) || '08', rate: '', makingChg: '', gross: '', stone: '', receivedWt: '', completedDate: '',
      createdAt: Date.now()
    };
    const pick = (v, prevV, ruleV) => (v === '' || v == null ? (o ? prevV : (ruleV === '' || ruleV == null ? '' : num(ruleV))) : num(v));
    return {
      ...base,
      id: o ? o.id : (it.dealId || uid('o')),
      no: o ? o.no : nextNo('orders', e.type === 'purchase' ? 'PO-' : 'SO-'),
      type: e.type, partyId: p.id || e.partyId || '', partyName: p.name || e.partyName,
      ref: `${e.no} · ${it.name}`.slice(0, 120), category: cat, purity,
      making: [it.name, it.desc].filter(Boolean).join(' — ').slice(0, 120),
      pcs: Math.max(1, Math.round(num(it.qty) || 1)),
      weight: t ? r3((t[0] + t[1]) / 2) : (o ? o.weight : ''),
      wastage: pick(it.wastage, o && o.wastage, rule && rule.wastage),
      labour: pick(it.labour, o && o.labour, rule && rule.labour),
      orderDate: e.date || todayStr(), dueDate: e.deliveryDate || '',
      notes: dealNote(e, it), estimateId: e.id, estimateItemId: it.id, updatedAt: Date.now()
    };
  }
  const DEAL_KEYS = ['type', 'partyId', 'ref', 'category', 'purity', 'making', 'pcs', 'weight', 'wastage', 'labour', 'orderDate', 'dueDate', 'notes'];
  const dealDiffers = (o, n) => DEAL_KEYS.some(k => String(o[k] ?? '') !== String(n[k] ?? ''));

  function planDeals(e, prev) {
    const wasWon = !!(prev && prev.status === 'Won'), isWon = e.status === 'Won';
    const plan = { create: [], update: [], reopen: [], cancel: [], done: [], needParty: false };
    const ordersById = id => (id ? S.orders.find(x => x.id === id) : null);
    if (isWon) {
      e.items.forEach(it => {
        const o = ordersById(it.dealId);
        if (!o) plan.create.push(it);
        else if (o.status === 'Completed') plan.done.push(o);
        else if (o.status === 'Cancelled') plan.reopen.push([it, o]);
        else if (dealDiffers(o, dealFrom(e, it, o))) plan.update.push([it, o]);
      });
      plan.needParty = !findParty(e.type, e.partyName, e.partyId);
    }
    if (prev) {
      (prev.items || []).forEach(pi => {
        if (!pi.dealId) return;
        const stillThere = isWon && e.items.some(x => x.dealId === pi.dealId);
        const o = ordersById(pi.dealId);
        if (!stillThere && o && ORD_OPEN(o) && !plan.cancel.includes(o)) plan.cancel.push(o);
      });
    }
    plan.needed = isWon ? (plan.create.length + plan.update.length + plan.reopen.length + plan.cancel.length > 0 || plan.needParty) : (wasWon && plan.cancel.length > 0);
    return plan;
  }

  async function applySync(e, plan, pf) {
    let party = findParty(e.type, e.partyName, e.partyId);
    if (e.status === 'Won' && plan.needParty) {
      const r = (e.type === 'purchase' ? buildSupplier : buildCustomer)({ name: e.partyName, phone: pf.pphone, city: pf.pcity || e.partyCity || '' }, null);
      if (r.err) { toast(r.err, 'err'); return false; }
      if (!await save(partyCol(e.type), r.obj)) return false;
      party = r.obj;
    }
    if (party) { e.partyId = party.id; e.partyName = party.name; if (!e.partyPhone) e.partyPhone = party.phone || ''; if (!e.partyCity) e.partyCity = party.city || ''; }
    plan.create.forEach(it => { if (!it.dealId) it.dealId = uid('o'); });
    e.dealIds = e.items.map(i => i.dealId).filter(Boolean);
    const nU = plan.update.length + plan.reopen.length;
    addHist(e, e.status === 'Won'
      ? `Deals Ledger sync: ${plan.create.length} naye${nU ? ', ' + nU + ' update' : ''}${plan.cancel.length ? ', ' + plan.cancel.length + ' cancel' : ''}`
      : `${plan.cancel.length} linked deal cancel kiye`);
    e.updatedAt = Date.now();
    if (!await save(EST, e)) return false;           // estimate first, so a retry never makes duplicate deals
    let fail = 0; const made = [];
    for (const it of plan.create) { const o = dealFrom(e, it, null, party); if (await save('orders', o)) made.push(o.no); else fail++; }
    for (const [it, o] of plan.update) { if (!await save('orders', dealFrom(e, it, o, party))) fail++; }
    for (const [it, o] of plan.reopen) { if (!await save('orders', { ...dealFrom(e, it, o, party), status: 'New', completedDate: '' })) fail++; }
    for (const o of plan.cancel) {
      if (!await save('orders', { ...o, status: 'Cancelled', notes: (o.notes ? o.notes + '\n' : '') + `Order estimate ${e.no} se cancel (${fmtD(todayStr())})`, updatedAt: Date.now() })) fail++;
    }
    if (fail) toast(fail + ' deal sync nahi hue — estimate dobara save karke try kijiye', 'err');
    else if (e.status === 'Won') toast(made.length ? `Deal pakki ✓ — ${made.join(', ')} Deals Ledger mein` : 'Deals Ledger update ho gaya');
    else toast('Linked deals cancel ho gaye');
    return true;
  }

  function openSyncDialog(e, prev, plan, editorOv) {
    const isWon = e.status === 'Won', wasWon = !!(prev && prev.status === 'Won');
    const ul = (title, rows) => (rows.length ? `<section class="sec"><h4>${title} (${rows.length})</h4><ul class="est-ul">${rows.map(r => `<li>${r}</li>`).join('')}</ul></section>` : '');
    const kind = isWon ? (wasWon ? 'Estimate badla — linked deals update karein' : 'Deal hui — Deals Ledger mein daalein') : 'Is estimate ke deals ka kya karein?';
    const ov = openModal(`<form data-form="estsync" novalidate>${mHead(kind, esc(e.no + ' · ' + e.partyName))}<div class="m-body">
      ${plan.needParty ? `<section class="sec"><h4>Nayi party</h4><p class="small muted" style="margin:0 0 10px">“${esc(e.partyName)}” abhi aapki ${e.type === 'purchase' ? 'supplier' : 'customer'} list mein nahi hai — naya ${e.type === 'purchase' ? 'supplier' : 'customer'} ban jayega.</p><div class="fg">${fld('Naam', 'pname', e.partyName, { ro: 1 })}${fld('Phone (10 digit)', 'pphone', e.partyPhone, { im: 'tel', max: 10, req: 1 })}${fld('City', 'pcity', e.partyCity)}</div></section>` : ''}
      ${ul('Naye deals banenge', plan.create.map(it => `<b>${esc(it.name)}</b> · ${esc(qtyTxt(it))} · ${esc(meltTxt(it))} · ${esc(rangeTxt(itemTotal(it)) || 'weight baad mein')}`))}
      ${ul('Deals update honge', plan.update.map(([it, o]) => `<b>${esc(o.no)}</b> · ${esc(it.name)}`))}
      ${ul('Cancelled deals wapas khulenge', plan.reopen.map(([it, o]) => `<b>${esc(o.no)}</b> · ${esc(it.name)}`))}
      ${ul('Deals cancel honge', plan.cancel.map(o => `<b>${esc(o.no)}</b> · ${esc(o.making || o.category || '')}`))}
      ${ul('Complete ho chuke — inhe nahi badlenge', plan.done.map(o => `<b>${esc(o.no)}</b> · ${esc(o.making || o.category || '')}`))}
      ${isWon ? `<p class="small muted" style="margin:0">Deal ka weight = estimate ke total weight ka average · rate = us din ka rate · party ke wastage rule apne aap lagenge. Baad mein Deals Ledger mein badal sakte hain.</p>` : ''}
    </div><div class="m-foot"><button type="button" class="btn" data-act="close">Wapas</button><button type="button" class="btn" data-act="est-sync-skip">${isWon ? 'Abhi sync mat karo' : 'Deals rehne do'}</button><button type="submit" class="btn gold">${isWon ? '✓ Sync karo' : 'Deals cancel karo'}</button></div></form>`);
    ov._e = e; ov._plan = plan; ov._editor = editorOv;
    return ov;
  }

  /* ---------- PDF ---------- */
  async function estimatePdf(e, o) {
    // v27: the Signature design (sj-estx.js) — the plain layout below is the fallback
    if (window.SJ_ESTX && (!window.SJ_BILLX || SJ_BILLX.styleNow() === 'signature')) { try { return await window.SJ_ESTX(e, o); } catch (er) { console.error(er); toast('Naya estimate design nahi bana (' + String(er && er.message || er).slice(0, 60) + ') — saada design bhej rahe hain', 'err'); } }
    const s = settings(); const pdf = new Pdf(210, 297);
    const M = 12, W = 186, R = M + W;
    const NAVY = '#2b3242', GOLD = '#c9a15a', CREAM = '#f5f1e8', MUT = '#7a7a7a', INK = '#222222';
    const logo = await loadJpeg(EST_LOGO || s.logo, 700);
    let y = 14;
    if (logo) { const h = 24, w = Math.min(80, h * logo.w / logo.h); pdf.image(logo, M, y, w, h); }
    else {
      pdf.fill(NAVY).font(true, 21).text(s.firm || 'Shivaa Jewels', M, y + 12, { maxW: 96 });
      if (s.tagline) pdf.fill(MUT).font(false, 8).text(s.tagline, M, y + 18, { maxW: 96 });
    }
    pdf.fill(NAVY).font(true, 19).text('ORDER ESTIMATE', R, y + 7, { align: 'right' });
    pdf.fill('#555555').font(false, 8.6);
    const legal = s.legal ? (s.firm && s.legal.indexOf(s.firm) < 0 ? `${s.legal} (${s.firm})` : s.legal) : s.firm;
    let ry = y + 13;
    [legal, s.gstin ? 'GSTIN: ' + s.gstin : '', ...(s.address ? pdf.wrap(s.address, 112).slice(0, 2) : []), s.phone ? 'Ph: ' + s.phone : '']
      .filter(Boolean).forEach(t => { pdf.text(t, R, ry, { align: 'right', maxW: 114 }); ry += 4.2; });
    y = Math.max(y + 28, ry + 1);
    pdf.stroke(GOLD).lw(0.6).line(M, y, R, y);
    y += 9;

    const meta = [[e.type === 'purchase' ? 'SUPPLIER' : 'PARTY NAME', e.partyName || '', M, 80, 12.5],
      ['ESTIMATE NO.', (e.no || 'Draft') + (num(e.rev) > 1 ? '  (Rev ' + e.rev + ')' : ''), M + 84, 34, 10],
      ['ORDER DATE', longDate(e.date), M + 120, 33, 10],
      ['DELIVERY DATE', e.deliveryDate ? longDate(e.deliveryDate) : '—', M + 154, 32, 10]];
    meta.forEach(([l, v, x, w, sz]) => { pdf.fill(MUT).font(false, 7.2).text(l, x, y); pdf.fill(INK).font(true, sz).text(v, x, y + 5.8, { maxW: w }); });
    const sub = [e.partyCity, e.partyPhone ? 'Ph: ' + e.partyPhone : ''].filter(Boolean).join('  ·  ');
    if (sub) pdf.fill(MUT).font(false, 8).text(sub, M, y + 10.6, { maxW: 80 });
    y += 18;

    const cols = [{ h: '#', w: 9 }, { h: 'Item Description', w: 63 }, { h: 'Qty', w: 20 }, { h: 'Melting / Purity', w: 27 }, { h: 'Weight', w: 35 }, { h: 'Total Weight', w: 32 }];
    const head = () => {
      pdf.fill(NAVY).rect(M, y, W, 11, 'f'); pdf.fill('#ffffff').font(true, 8.6);
      let x = M; cols.forEach(c => { pdf.text(c.h, x + 2.5, y + 6.9, { maxW: c.w - 3 }); x += c.w; }); y += 11;
    };
    head();
    const LH = 4.3;
    e.items.forEach((it, i) => {
      pdf.font(true, 9.2); const tl = pdf.wrap(it.name, cols[1].w - 5);
      pdf.font(false, 8.4); const dl = it.desc ? pdf.wrap(it.desc, cols[1].w - 5) : [];
      pdf.font(false, 8.8); const wl = pdf.wrap(perTxt(it), cols[4].w - 4);
      const lines = Math.max(tl.length + dl.length, wl.length, 1);
      const rh = Math.max(13, 5 + lines * LH);
      if (y + rh > pdf.H - 30) { pdf.addPage(); y = 16; head(); }
      if (i % 2 === 0) pdf.fill(CREAM).rect(M, y, W, rh, 'f');
      const mid = y + rh / 2 + 1.4;
      let x = M;
      pdf.fill(INK).font(false, 9).text(String(i + 1), x + 3, mid); x += cols[0].w;
      let ty = y + (rh - (tl.length + dl.length) * LH) / 2 + 3.3;
      pdf.fill(INK).font(true, 9.2); tl.forEach(l => { pdf.text(l, x + 2.5, ty); ty += LH; });
      pdf.fill('#444444').font(false, 8.4); dl.forEach(l => { pdf.text(l, x + 2.5, ty); ty += LH; });
      x += cols[1].w;
      pdf.fill(INK).font(false, 9).text(qtyTxt(it), x + 2.5, mid, { maxW: cols[2].w - 3 }); x += cols[2].w;
      pdf.text(meltTxt(it), x + 2.5, mid, { maxW: cols[3].w - 3 }); x += cols[3].w;
      let wy = y + (rh - wl.length * LH) / 2 + 3.3; pdf.font(false, 8.8); wl.forEach(l => { pdf.text(l, x + 2.5, wy); wy += LH; }); x += cols[4].w;
      pdf.font(true, 9.4).text(rangeTxt(itemTotal(it)) || '—', x + 2.5, mid, { maxW: cols[5].w - 3 });
      y += rh; pdf.stroke(GOLD).lw(0.3).line(M, y, R, y);
    });
    if (e.items.length > 1) {
      const t = estTotal(e);
      if (t) { y += 6; pdf.fill(MUT).font(false, 8.4).text('Total order weight (approx.)', R - 36, y, { align: 'right' }); pdf.fill(NAVY).font(true, 10).text(rangeTxt(t), R - 2.5, y, { align: 'right' }); y += 2; }
    }
    y += 10;

    const photos = [];
    for (const it of e.items) {
      const n = (it.photos || []).length;
      for (let k = 0; k < n; k++) {
        const img = await loadJpeg(it.photos[k].src, 1100);
        if (img) photos.push({ img, cap: it.name + (num(it.qty) > 1 ? ` (${qtyTxt(it).toLowerCase()})` : '') + (n > 1 ? ` – ${k + 1}` : '') });
      }
    }
    const notes = notesOf(e);
    const bottomLimit = pdf.H - 44;
    const need = h => { if (y + h > bottomLimit) { pdf.addPage(); y = 16; } };
    const frame = (p, x, yy, mw, mh) => {
      let w = mw, h = w * p.img.h / p.img.w; if (h > mh) { h = mh; w = h * p.img.w / p.img.h; }
      pdf.image(p.img, x, yy, w, h); pdf.stroke(GOLD).lw(0.4).rect(x, yy, w, h);
      pdf.fill(INK).font(true, 8.2).text(p.cap, x, yy + h + 4.6, { maxW: mw });
      return h + 7;
    };
    const drawNotes = (x, w, yy) => {
      pdf.fill(NAVY).font(true, 9.6).text('ORDER NOTES', x, yy); yy += 6.5;
      pdf.fill('#333333').font(false, 8.9);
      notes.forEach(n => {
        pdf.wrap(n, w - 4).forEach((l, li) => {
          if (yy > pdf.H - 22) { pdf.addPage(); yy = 18; pdf.fill('#333333').font(false, 8.9); }
          if (li === 0) pdf.fill('#333333').rect(x, yy - 2.1, 1.1, 1.1, 'f');
          pdf.text(l, x + 3.2, yy); yy += 4.6;
        });
      });
      return yy;
    };
    if (photos.length === 1) {
      const p = photos[0]; let w = 104, h = w * p.img.h / p.img.w; if (h > 82) { h = 82; w = h * p.img.w / p.img.h; }
      need(h + 16);
      pdf.fill(NAVY).font(true, 9.6).text('DESIGN REFERENCE', M, y); const y0 = y + 4;
      const used = frame(p, M, y0, 104, 82);
      const pages = pdf.pages.length;
      const ny = notes.length ? drawNotes(M + 112, W - 112, y0 + 6) : y0;
      y = (pdf.pages.length > pages ? ny : Math.max(y0 + used, ny)) + 4;
    } else {
      if (photos.length) {
        need(60);
        pdf.fill(NAVY).font(true, 9.6).text('DESIGN REFERENCE', M, y); y += 4;
        const cw = (W - 6) / 2;
        // shrink the photos a little when that keeps notes + signature on this page
        pdf.font(false, 8.9);
        const notesH = notes.length ? 12 + notes.reduce((a, n) => a + pdf.wrap(n, W - 4).length, 0) * 4.6 : 0;
        const rows = Math.ceil(photos.length / 2);
        let maxH = Math.min(86, (pdf.H - 56 - y - notesH) / rows - 10);
        if (maxH < 52) maxH = 86;
        for (let i = 0; i < photos.length; i += 2) {
          const row = photos.slice(i, i + 2);
          const hs = row.map(p => Math.min(maxH, cw * p.img.h / p.img.w));
          need(Math.max(...hs) + 9);
          const used = row.map((p, k) => frame(p, M + k * (cw + 6), y, cw, maxH));
          y += Math.max(...used) + 3;
        }
        y += 3;
      }
      if (notes.length) { need(20); y = drawNotes(M, W, y + 2) + 2; }
    }

    let sy = Math.max(y + 18, pdf.H - 40);
    if (sy > pdf.H - 34) { pdf.addPage(); sy = 60; }
    pdf.stroke('#9a9a9a').lw(0.3).line(M, sy, M + 62, sy).line(R - 62, sy, R, sy);
    pdf.fill('#444444').font(false, 8.6).text(e.type === 'purchase' ? 'Supplier Signature' : 'Party Signature', M, sy + 5);
    pdf.text('For ' + (s.firm || 'Shivaa Jewels'), R, sy + 5, { align: 'right' });

    const n = pdf.pages.length; const foot = e.footer == null ? FOOTER : e.footer;
    for (let i = 0; i < n; i++) {
      pdf.onPage(i);
      const fy = pdf.H - 10;
      pdf.stroke(GOLD).lw(0.4).line(M, fy - 7.5, R, fy - 7.5);
      if (logo) { const h = 6.5, w = h * logo.w / logo.h; pdf.image(logo, M, fy - 5, w, h); }
      if (foot) pdf.fill(MUT).font(false, 8).text(foot, R, fy, { align: 'right', maxW: W - 40 });
      if (n > 1) pdf.fill(MUT).font(false, 7).text(`Page ${i + 1} of ${n}`, R, fy + 4.5, { align: 'right' });
    }
    return pdf.blob();
  }
  const pdfName = e => safeName(`Estimate_${e.no || 'Draft'}_${e.partyName || ''}`) + '.pdf';

  function estMsg(e) {
    const s = settings();
    const lines = e.items.map((it, i) => `${i + 1}. ${it.name}${it.desc ? ' (' + it.desc + ')' : ''} — ${qtyTxt(it)} · ${meltTxt(it)}${itemTotal(it) ? ' · ' + rangeTxt(itemTotal(it)) : ''}`);
    const t = estTotal(e);
    return `Namaste ${e.partyName} ji,\n${s.firm} — Order Estimate ${e.no}\nOrder date: ${fmtD(e.date)}${e.deliveryDate ? '\nDelivery: ' + fmtD(e.deliveryDate) : ''}\n\n${lines.join('\n')}${t && e.items.length > 1 ? '\nTotal approx.: ' + rangeTxt(t) : ''}\n\nKripya confirm kijiye. Dhanyavaad!`;
  }
  function followMsg(e) {
    return `Namaste ${e.partyName} ji,\n${settings().firm} se — aapke order estimate ${e.no} (${e.items.map(i => i.name).join(', ')}) ke baare mein. Kya order confirm karein?${e.deliveryDate ? ' Delivery ' + fmtD(e.deliveryDate) + ' tak ho jayegi.' : ''}\nDhanyavaad!`;
  }
  const waUrl = (e, msg) => { const ph = cleanPhone(e.partyPhone || (findParty(e.type, e.partyName, e.partyId) || {}).phone); return ph.length === 10 ? 'https://wa.me/91' + ph + '?text=' + encodeURIComponent(msg) : 'https://wa.me/?text=' + encodeURIComponent(msg); };

  async function shareEstimate(e) {
    toast('PDF ban raha hai…');
    const blob = await estimatePdf(e); const name = pdfName(e); const msg = estMsg(e);
    try {
      const f = new File([blob], name, { type: 'application/pdf' });
      if (navigator.canShare && navigator.canShare({ files: [f] })) { await navigator.share({ files: [f], title: 'Order Estimate ' + e.no, text: msg }); return; }
    } catch (err) { if (err && err.name === 'AbortError') return; }
    await offerDownload(name, blob);
    openModal(`${mHead('WhatsApp par bhejiye', esc(e.no + ' · ' + e.partyName))}<div class="m-body"><p style="margin:0 0 10px">PDF download ho gaya (<b>${esc(name)}</b>). WhatsApp kholkar message bhejiye aur PDF attach kar dijiye.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Close</button><a class="btn green" href="${esc(waUrl(e, msg))}" target="_blank" rel="noopener" data-act="close">WhatsApp kholiye</a></div>`, { small: true });
  }

  /* ---------- list ---------- */
  const statusPill = e => { const s = STATUS[e.status] || STATUS.Pending; return `<span class="pill ${s.cls}">${s.icon} ${s.l}</span>`; };
  function linkedDeals(e) {
    return (e.items || []).map(i => i.dealId && S.orders.find(o => o.id === i.dealId)).filter(Boolean);
  }
  function estRow(e) {
    const t = todayStr(); const tot = estTotal(e); const nPh = sum(e.items || [], i => (i.photos || []).length);
    const late = e.status === 'Pending' && e.deliveryDate && e.deliveryDate < t;
    const deals = linkedDeals(e);
    const right = e.status === 'Pending'
      ? `<div class="small muted">${daysBetween(e.date || t, t)} din se jawab baaki</div>${e.deliveryDate ? `<div class="small ${late ? 'red' : 'muted'}">Delivery ${fmtD(e.deliveryDate)}</div>` : ''}`
      : `<div class="small muted">${e.decidedDate ? fmtD(e.decidedDate) : ''}</div>`;
    const btns = [`<button type="button" class="btn sm" data-act="est-pdf" data-id="${esc(e.id)}">${ic('dl', 14)} PDF</button>`,
      `<button type="button" class="btn sm" data-act="est-share" data-id="${esc(e.id)}">Share / WhatsApp</button>`];
    if (e.status === 'Pending') btns.push(`<button type="button" class="btn sm green" data-act="est-won" data-id="${esc(e.id)}">✓ Deal hui</button>`, `<button type="button" class="btn sm danger" data-act="est-lost" data-id="${esc(e.id)}">✗ Nahi hui</button>`, `<a class="btn sm" data-act="est-link" href="${esc(waUrl(e, followMsg(e)))}" target="_blank" rel="noopener">Follow-up</a>`);
    return `<div class="row" data-act="est-edit" data-id="${esc(e.id)}"><div style="min-width:0;flex:1">
      <b class="mono">${esc(e.no)}</b>${num(e.rev) > 1 ? ` <span class="pill">Rev ${num(e.rev)}</span>` : ''} <span class="pill ${e.type === 'purchase' ? 'purchase' : 'sale'}">${e.type === 'purchase' ? 'Purchase' : 'Sale'}</span>
      <div class="small"><b>${esc(e.partyName)}</b>${e.partyCity ? ' · ' + esc(e.partyCity) : ''} · ${esc((e.items || []).map(i => i.name + ' ×' + (num(i.qty) || 1)).join(', '))}</div>
      <div class="small muted">Order ${fmtD(e.date)}${tot ? ' · ' + esc(rangeTxt(tot)) : ''} · ${esc([...new Set((e.items || []).map(meltTxt))].join(', '))}${nPh ? ' · ' + nPh + ' photo' + (nPh > 1 ? 's' : '') : ''}${e.status === 'Lost' && e.lostReason ? ' · ' + esc(e.lostReason) : ''}</div>
      ${deals.length ? `<div class="est-deals">${deals.map(o => `<button type="button" class="chip" data-act="ord-edit" data-id="${esc(o.id)}">${esc(o.no)} · ${esc(o.status)}</button>`).join('')}</div>` : ''}
      <div class="est-row-btns">${btns.join('')}</div></div>
      <div class="right">${statusPill(e)}${right}</div></div>`;
  }
  VIEWDEF.estimates = {
    shell: () => `<div class="tcard"><div class="tcard-h"><div><h3>Order Estimates</h3><div class="small muted">Party ko design, purity aur weight ka estimate PDF bhejiye. Deal hui to ek click mein Deals Ledger mein chala jayega — baad mein estimate badlenge to deal bhi update hogi.</div></div><button class="btn gold" data-act="est-new">${ic('plus', 16)} New Estimate</button></div></div>
      <div class="toolbar">${searchBox('estimates', 'Search estimate no, party, item...')}${seg('eStatus', [['Pending', '⏳ Pending'], ['Won', '✓ Deal hui'], ['Lost', '✗ Nahi hui'], ['all', 'All']])}</div><div id="vbody"></div>`,
    body() {
      const all = estList();
      if (!all.length) return emptyBox('Abhi koi order estimate nahi hai. Party ko design, purity aur weight ka estimate banakar bhejiye — deal hone par ek click mein Deals Ledger mein chala jayega.', `<button class="btn gold" data-act="est-new">${ic('plus', 16)} New Estimate</button>`);
      const t = todayStr(), ym = monthKey(t), q = norm(ui.q.estimates);
      const pend = all.filter(x => x.status === 'Pending');
      const wonM = all.filter(x => x.status === 'Won' && monthKey(x.decidedDate) === ym);
      const lostM = all.filter(x => x.status === 'Lost' && monthKey(x.decidedDate) === ym);
      const d90 = addDays(t, -90); const dec = all.filter(x => x.status !== 'Pending' && (x.decidedDate || '') >= d90);
      const conv = dec.length ? Math.round(100 * dec.filter(x => x.status === 'Won').length / dec.length) : null;
      const oldest = pend.length ? Math.max(...pend.map(x => daysBetween(x.date || t, t))) : 0;
      const k = `<div class="kpis">${kpi('Pending', pend.length, pend.length ? 'Sabse purana ' + oldest + ' din' : 'Sab ka jawab aa gaya')}${kpi('Deal hui · is mahine', wonM.length, wonM.length ? rangeTxt(sumRanges(wonM.map(estTotal))) || '' : '—')}${kpi('Nahi hui · is mahine', lostM.length, '')}${kpi('Conversion · 90 din', conv == null ? '—' : conv + '%', dec.length ? dec.length + ' faisle' : 'Abhi data nahi')}</div>`;
      const list = all.filter(x => (ui.eStatus === 'all' || x.status === ui.eStatus) &&
        (!q || [x.no, x.partyName, x.partyCity, x.partyPhone, ...(x.items || []).map(i => i.name + ' ' + (i.desc || ''))].some(v => norm(v).includes(q))));
      list.sort((a, b) => (ui.eStatus === 'Pending'
        ? String(a.deliveryDate || '9999').localeCompare(String(b.deliveryDate || '9999'))
        : num(b.updatedAt) - num(a.updatedAt)));
      return k + (list.length ? `<div class="tcard">${list.map(estRow).join('')}</div>` : emptyBox('Is filter mein koi estimate nahi.'));
    }
  };

  // Deals Ledger: reminder of estimates waiting for an answer
  if (VIEWDEF.orders && typeof VIEWDEF.orders.body === 'function') {
    const ordBody = VIEWDEF.orders.body;
    VIEWDEF.orders.body = function () {
      const p = estList().filter(x => x.status === 'Pending').length;
      const b = p ? `<div class="banner"><span>📝 <b>${p}</b> order estimate${p > 1 ? 's' : ''} ka jawab baaki — deal hui ya nahi, update kijiye.</span><button class="btn sm primary" data-act="seg" data-k="pTab" data-v="estimates">Order Estimates</button></div>` : '';
      return b + ordBody.apply(this, arguments);
    };
  }

  /* ---------- editor ---------- */
  const partyOptions = type => partiesOf(type).slice().sort((a, b) => a.name.localeCompare(b.name)).map(p => `<option value="${esc(p.name)}">${esc([p.city, p.phone].filter(Boolean).join(' · '))}</option>`).join('');
  const statusSegs = v => Object.entries(STATUS).map(([k, s]) => `<button type="button" data-act="est-status" data-v="${k}" class="${(v || 'Pending') === k ? 'on' : ''}">${s.icon} ${s.l}</button>`).join('');

  function itemHTML(it, i, n) {
    const tot = itemTotal(it);
    const autoT = !it.totalManual;
    const tv = k => (autoT ? (tot ? (k === 'totMin' ? tot[0] : (tot[0] === tot[1] ? '' : tot[1])) : '') : it[k]);
    const inp = (label, f, v, o = {}) => `<label class="f${o.span ? ' span2' : ''}${o.cls ? ' ' + o.cls : ''}"><span>${label}${o.tag ? ` <em class="tag${it.totalManual ? ' manual' : ''}" data-o="tt${i}">${it.totalManual ? 'manual' : 'auto'}</em>` : ''}</span><input data-ef="${f}" value="${esc(v ?? '')}"${o.type ? ` type="${o.type}" step="any" inputmode="decimal"` : ''}${o.ph ? ` placeholder="${esc(o.ph)}"` : ''} autocomplete="off"></label>`;
    const sel = (label, f, arr, v, ph) => `<label class="f"><span>${label}</span><select data-ef="${f}">${opts(arr, v, ph)}</select></label>`;
    const photos = (it.photos || []).map((p, k) => `<div class="ph"><img src="${esc(p.src)}" alt=""><button type="button" data-act="est-photo-del" data-i="${i}" data-p="${k}" aria-label="Remove photo">×</button></div>`).join('');
    return `<div class="item" data-i="${i}"><div class="item-h"><b>Item ${i + 1}</b><span class="small muted" data-o="isum${i}">${esc(itemSum(it))}</span>${n > 1 ? `<button type="button" class="icon-btn sm danger" data-act="est-item-del" data-i="${i}" title="Remove item">${ic('trash', 14)}</button>` : ''}</div>
      <div class="ig">
        ${inp('Item name *', 'name', it.name, { span: 1, ph: 'e.g. Necklace Set' })}
        ${inp('Description', 'desc', it.desc, { span: 1, ph: 'e.g. Necklace + Ring + Earrings' })}
        ${sel('Category', 'category', CATEGORIES, it.category, 'Auto')}
        ${inp('Qty', 'qty', it.qty, { type: 'number' })}
        ${sel('Unit', 'unit', UNITS.map(u => [u[0], u[0]]), it.unit)}
        ${sel('Purity', 'purity', PURITIES.map(p => p.k), it.purity)}
        ${inp('Melting', 'melting', it.melting, { ph: 'e.g. 92' })}
        ${inp('Weight per unit (g)', 'wMin', it.wMin, { type: 'number', ph: 'e.g. 8' })}
        ${inp('…up to (g, optional)', 'wMax', it.wMax, { type: 'number', ph: 'e.g. 9' })}
        ${inp('Total weight (g)', 'totMin', tv('totMin'), { type: 'number', tag: 1, cls: 'tot' })}
        ${inp('…up to (g)', 'totMax', tv('totMax'), { type: 'number', cls: 'tot' })}
        ${inp('Wastage % · deal ke liye', 'wastage', it.wastage, { type: 'number', ph: 'optional' })}
        ${inp('Labour ₹/g · deal ke liye', 'labour', it.labour, { type: 'number', ph: 'optional' })}
      </div>
      <div class="est-ph">${photos}<label class="add">${ic('camera', 22)}<span>Design photo</span><input type="file" accept="image/*" multiple data-estfile="${i}"></label></div></div>`;
  }
  const itemSum = it => [qtyTxt(it), meltTxt(it), rangeTxt(itemTotal(it))].filter(Boolean).join(' · ');
  function renderItems(ov) {
    const e = ov._e; $('#est-items', ov).innerHTML = e.items.map((it, i) => itemHTML(it, i, e.items.length)).join('');
    refreshTotals(ov);
  }
  function refreshAuto(ov) {
    const el = ov.querySelector('[data-o="eauto"]'); if (!el) return;
    const f = $('form', ov); const on = f.querySelector('[name="autoNotes"]').checked;
    const lines = on ? noteLines(autoNotes(collect(ov))) : [];
    el.innerHTML = on ? (lines.length ? lines.map(l => `<li>${esc(l)}</li>`).join('') : '<li>Items bharne par yahan notes dikhenge</li>') : '';
    el.hidden = !on;
  }
  function refreshTotals(ov) {
    refreshAuto(ov);
    const e = ov._e; const t = estTotal(e); const el = ov.querySelector('[data-o="etot"]'); if (!el) return;
    el.innerHTML = `<span>Items <b>${e.items.filter(i => i.name).length}</b></span><span>Total weight <b>${esc(rangeTxt(t) || '—')}</b></span><span>Photos <b>${sum(e.items, i => (i.photos || []).length)}</b></span>`;
  }
  function partyHint(ov) {
    const f = $('form', ov); const g = k => f.querySelector(`[name="${k}"]`);
    const p = findParty(g('type').value, g('partyName').value, ov._e.partyId && norm(ov._e.partyName) === norm(g('partyName').value) ? ov._e.partyId : '');
    const el = ov.querySelector('[data-o="eparty"]');
    if (!g('partyName').value.trim()) { el.textContent = ''; return; }
    el.innerHTML = p ? `✓ Purani party: <b>${esc(p.name)}</b>${p.phone ? ' · ' + esc(p.phone) : ''}${p.city ? ' · ' + esc(p.city) : ''}` : `Nayi party — deal hone par naya ${g('type').value === 'purchase' ? 'supplier' : 'customer'} ban jayega`;
    if (p) { if (!g('partyPhone').value && p.phone) g('partyPhone').value = p.phone; if (!g('partyCity').value && p.city) g('partyCity').value = p.city; }
  }
  function collect(ov) {
    const f = $('form', ov); const d = formObj(f); const prev = ov._prev; const e0 = ov._e;
    const items = e0.items.map(cleanItem).filter(it => it.name);
    const party = findParty(d.type, d.partyName, prev && norm(prev.partyName) === norm(d.partyName) ? prev.partyId : '');
    return {
      ...(prev || {}), type: d.type === 'purchase' ? 'purchase' : 'sale',
      partyName: String(d.partyName || '').trim(), partyId: party ? party.id : '',
      partyPhone: cleanPhone(d.partyPhone) || (party && party.phone) || '', partyCity: d.partyCity || (party && party.city) || '',
      date: d.date || todayStr(), deliveryDate: d.deliveryDate || '', notes: d.notes || '', autoNotes: d.autoNotes !== false, footer: d.footer ?? FOOTER,
      items, status: STATUS[d.status] ? d.status : 'Pending', lostReason: d.status === 'Lost' ? (d.lostReason || '') : '',
      id: prev ? prev.id : (e0.id || uid('est')), no: prev ? prev.no : nextNo(EST, 'OE-'),
      firmId: prev ? (prev.firmId || activeFirm()) : activeFirm(), rev: prev ? num(prev.rev) || 1 : 1,
      createdAt: prev ? prev.createdAt : Date.now(), updatedAt: Date.now()
    };
  }
  const contentKey = x => JSON.stringify([x.type, x.partyName, x.partyPhone, x.partyCity, x.date, x.deliveryDate, x.notes, x.autoNotes !== false, x.footer,
    (x.items || []).map(i => [i.name, i.desc, i.category, i.qty, i.unit, i.purity, i.melting, i.wMin, i.wMax, i.totMin, i.totMax, i.totalManual, i.wastage, i.labour, (i.photos || []).map(p => p.src.length + p.src.slice(-24))])]);

  function openEstimate(id, preset) {
    const prev = id ? findEst(id) : null;
    const e = prev ? clone(prev) : { type: 'sale', date: todayStr(), deliveryDate: addDays(todayStr(), 7), status: 'Pending', notes: '', footer: FOOTER, items: [blankItem()], ...(preset || {}) };
    if (!e.items || !e.items.length) e.items = [blankItem()];
    const deals = prev ? linkedDeals(prev) : [];
    const hist = prev && (prev.history || []).length ? `<section class="sec"><h4>History</h4><div class="est-hist">${prev.history.slice().reverse().slice(0, 12).map(h => `<div>${esc(new Date(h.at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }))} — ${esc(h.t)}</div>`).join('')}</div></section>` : '';
    const ov = openModal(`<form data-form="estimate" data-id="${prev ? esc(prev.id) : ''}" novalidate>${mHead(prev ? 'Order Estimate ' + esc(prev.no) + (num(prev.rev) > 1 ? ' · Rev ' + num(prev.rev) : '') : 'New Order Estimate', prev ? `${STATUS[prev.status] ? STATUS[prev.status].l : ''} · banaya ${fmtD(tsDate(prev.createdAt))}${prev.updatedAt ? ' · last change ' + fmtD(tsDate(prev.updatedAt)) : ''}` : 'Party ko design, purity aur weight ka estimate — deal hone par Deals Ledger mein chala jayega')}
      <div class="m-body">
       <section class="sec"><h4><span>1</span> Party & Dates</h4><div class="fg">
        ${selFld('Deal Type', 'type', [['sale', 'Sale — party humse order de rahi hai'], ['purchase', 'Purchase — hum supplier ko order de rahe hain']], e.type, { wm: 1 })}
        <label class="f wide-m"><span><span data-o="eplabel">${e.type === 'purchase' ? 'Supplier' : 'Party / Customer'}</span> <b class="req">*</b></span><input name="partyName" list="est-plist" value="${esc(e.partyName || '')}" placeholder="Naam likhiye ya list se chuniye" autocomplete="off"></label>
        ${fld('Phone', 'partyPhone', e.partyPhone, { im: 'tel', max: 10 })}
        ${fld('City', 'partyCity', e.partyCity)}
        ${fld('Order Date', 'date', e.date, { type: 'date' })}
        ${fld('Delivery Date', 'deliveryDate', e.deliveryDate, { type: 'date' })}
       </div><datalist id="est-plist">${partyOptions(e.type)}</datalist><div class="small muted" data-o="eparty" style="margin-top:8px"></div></section>
       <section class="sec"><div class="sec-h"><h4><span>2</span> Items</h4><button type="button" class="btn sm" data-act="est-item-add">${ic('plus', 14)} Add item</button></div>
        <div id="est-items"></div><div class="est-tot" data-o="etot"></div></section>
       <section class="sec"><h4><span>3</span> Order Notes</h4>
        <label class="chk" style="margin:0 0 8px"><input type="checkbox" name="autoNotes"${e.autoNotes === false ? '' : ' checked'}> Auto notes — purity, weight aur delivery items se apne aap (estimate badalne par khud update)</label>
        <ul class="est-ul small muted" data-o="eauto" style="margin:0 0 12px"></ul><div class="fg">
        ${areaFld('Aur notes (optional) — har line ek point', 'notes', e.notes, { rows: 3, ph: 'e.g. Hallmark ke saath · Advance ₹10,000 mila' })}
        ${fld('PDF ke neeche ki line', 'footer', e.footer == null ? FOOTER : e.footer, { full: 1 })}
       </div></section>
       <section class="sec"><h4><span>4</span> Deal hui ya nahi?</h4>
        <div class="seg full" data-o="estat">${statusSegs(e.status)}</div><input type="hidden" name="status" value="${esc(e.status || 'Pending')}">
        <div class="fg" data-o="elost" style="margin-top:10px"${e.status === 'Lost' ? '' : ' hidden'}>${fld('Kyon nahi hui? (optional)', 'lostReason', e.lostReason, { full: 1, ph: 'Rate zyada laga, design pasand nahi aaya…' })}</div>
        <p class="small muted" style="margin:10px 0 0">“Deal hui” karke save karne par har item ka ek deal Deals Ledger mein ban jayega (nayi party ho to wo bhi). Deal hone ke baad bhi estimate badal sakte hain — linked deals update ho jayenge.</p>
        ${deals.length ? `<div class="est-deals" style="margin-top:10px"><span class="small muted" style="margin-right:4px">Linked deals:</span>${deals.map(o => `<button type="button" class="chip" data-act="ord-edit" data-id="${esc(o.id)}">${esc(o.no)} · ${esc(o.status)}</button>`).join('')}</div>` : ''}
       </section>${hist}
      </div>
      <div class="m-foot">${prev ? `<button type="button" class="btn danger" data-act="est-del" data-id="${esc(prev.id)}">Delete</button><button type="button" class="btn" data-act="est-dup">Copy as new</button>` : ''}<button type="button" class="btn" data-act="close">Cancel</button><button type="button" class="btn" data-act="est-pdf-form">${ic('dl', 16)} PDF</button><button type="submit" class="btn gold">${prev ? 'Save changes' : 'Save Estimate'}</button></div></form>`, { wide: true });
    ov._e = e; ov._prev = prev;
    renderItems(ov); partyHint(ov);
    return ov;
  }

  async function finishSave(obj, prev, editorOv) {
    const plan = planDeals(obj, prev);
    if (plan.needed) { openSyncDialog(obj, prev, plan, editorOv); return; }
    if (await save(EST, obj)) { if (editorOv) closeModal(editorOv); toast('Estimate ' + obj.no + ' saved'); }
  }
  function withStatusHistory(obj, prev) {
    if (!prev) addHist(obj, 'Estimate banaya');
    const prevStatus = prev ? prev.status || 'Pending' : 'Pending';
    if (obj.status !== prevStatus) {
      obj.decidedDate = obj.status === 'Pending' ? '' : todayStr();
      addHist(obj, obj.status === 'Won' ? 'Deal hui ✓' : obj.status === 'Lost' ? 'Deal nahi hui' + (obj.lostReason ? ' — ' + obj.lostReason : '') : 'Wapas Pending');
    }
    return obj;
  }

  async function submitEstimate(form) {
    const ov = form.closest('.overlay'); const prev = ov._prev;
    const obj = collect(ov);
    if (!obj.partyName) return toast('Party ka naam likhiye', 'err');
    if (!obj.items.length) return toast('Kam se kam ek item ka naam likhiye', 'err');
    const ph = cleanPhone(formObj(form).partyPhone); if (ph && ph.length !== 10) return toast('Phone 10 digit ka hona chahiye', 'err');
    if (obj.deliveryDate && obj.date && obj.deliveryDate < obj.date) return toast('Delivery date order date se pehle hai', 'err');
    const size = JSON.stringify(obj).length;
    if (size > 3000000) return toast('Photos bahut zyada hain — kuch photos hataiye (' + (size / 1e6).toFixed(1) + ' MB)', 'err');
    if (prev && contentKey(prev) !== contentKey(obj)) { obj.rev = (num(prev.rev) || 1) + 1; addHist(obj, 'Estimate badla (Rev ' + obj.rev + ')'); }
    withStatusHistory(obj, prev);
    await finishSave(obj, prev, ov);
  }

  async function quickStatus(e, status, reason) {
    const obj = clone(e); obj.status = status; obj.lostReason = status === 'Lost' ? (reason || '') : ''; obj.updatedAt = Date.now();
    withStatusHistory(obj, e);
    await finishSave(obj, e, null);
  }

  /* ---------- events ---------- */
  SUBMIT2.estimate = submitEstimate;
  SUBMIT2.estsync = async form => {
    const ov = form.closest('.overlay'); const pf = formObj(form);
    if (ov._plan.needParty && ov._e.status === 'Won' && cleanPhone(pf.pphone).length !== 10) return toast('Nayi party ke liye 10 digit phone number daaliye', 'err');
    const btn = form.querySelector('button[type=submit]'); if (btn) btn.disabled = true;
    try {
      if (await applySync(ov._e, ov._plan, pf)) { const ed = ov._editor; closeModal(ov); if (ed && ed.isConnected) closeModal(ed); }
    } finally { if (btn) btn.disabled = false; }
  };
  SUBMIT2.estlost = async form => {
    const ov = form.closest('.overlay'); const e = findEst(ov._id); if (!e) return closeModal(ov);
    const d = formObj(form); closeModal(ov); await quickStatus(e, 'Lost', d.reason);
  };

  const ACT = {
    'est-new': () => openEstimate(null),
    'est-edit': t => openEstimate(t.dataset.id),
    'est-item-add': (t, ov) => { ov._e.items.push(blankItem()); renderItems(ov); const last = ov.querySelector('#est-items .item:last-child [data-ef="name"]'); if (last) last.focus(); },
    'est-item-del': (t, ov) => { const i = +t.dataset.i; ov._e.items.splice(i, 1); if (!ov._e.items.length) ov._e.items.push(blankItem()); renderItems(ov); },
    'est-photo-del': (t, ov) => { const it = ov._e.items[+t.dataset.i]; if (it) { it.photos.splice(+t.dataset.p, 1); renderItems(ov); } },
    'est-status': (t, ov) => {
      const v = t.dataset.v; const f = $('form', ov); f.querySelector('[name="status"]').value = v;
      ov.querySelectorAll('[data-o="estat"] button').forEach(b => b.classList.toggle('on', b.dataset.v === v));
      const lost = ov.querySelector('[data-o="elost"]'); if (lost) lost.hidden = v !== 'Lost';
    },
    'est-pdf-form': async (t, ov) => {
      const e = collect(ov); if (!e.partyName || !e.items.length) return toast('Party aur kam se kam ek item bhariye', 'err');
      if (ov._prev && contentKey(ov._prev) !== contentKey(e)) e.rev = (num(ov._prev.rev) || 1) + 1;
      toast('PDF ban raha hai…'); await offerDownload(pdfName(e), await estimatePdf(e));
    },
    'est-dup': (t, ov) => {
      const e = collect(ov); closeModal(ov);
      const items = e.items.map(it => { const c = { ...it, id: uid('ei') }; delete c.dealId; return c; });
      openEstimate(null, { type: e.type, partyName: '', partyPhone: '', partyCity: '', date: todayStr(), deliveryDate: addDays(todayStr(), 7), notes: e.notes, autoNotes: e.autoNotes, footer: e.footer, items });
      toast('Copy ban gayi — party ka naam badaliye');
    },
    'est-del': (t, ov) => {
      const e = findEst(t.dataset.id); if (!e) return;
      const open = linkedDeals(e).filter(ORD_OPEN).length;
      confirmBox(`Estimate <b>${esc(e.no)}</b> (${esc(e.partyName)}) delete karein?${open ? `<br><br>Iske ${open} deal Deals Ledger mein rahenge.` : ''}<br><span class="small muted">Recycle bin mein 30 din tak rahega.</span>`, async () => { if (await removeDoc(EST, e.id)) { closeModal(ov); toast('Estimate deleted'); } });
    },
    'est-pdf': async t => { const e = findEst(t.dataset.id); if (!e) return; toast('PDF ban raha hai…'); await offerDownload(pdfName(e), await estimatePdf(e)); },
    'est-share': async t => { const e = findEst(t.dataset.id); if (e) await shareEstimate(e); },
    'est-won': async t => { const e = findEst(t.dataset.id); if (e) await quickStatus(e, 'Won'); },
    'est-lost': t => {
      const e = findEst(t.dataset.id); if (!e) return;
      const ov = openModal(`<form data-form="estlost" novalidate>${mHead('Deal nahi hui', esc(e.no + ' · ' + e.partyName))}<div class="m-body"><div class="fg">${fld('Kyon? (optional)', 'reason', '', { full: 1, ph: 'Rate zyada laga, design pasand nahi aaya…' })}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button type="submit" class="btn primary">Save</button></div></form>`, { small: true });
      ov._id = e.id;
    },
    'est-sync-skip': async (t, ov) => {
      const e = ov._e; const ed = ov._editor;
      if (await save(EST, e)) { closeModal(ov); if (ed && ed.isConnected) closeModal(ed); toast('Estimate saved' + (e.status === 'Won' ? ' — deals baad mein sync kar sakte hain' : '')); }
    }
  };
  document.addEventListener('click', async ev => {
    const t = ev.target.closest('[data-act]'); if (!t) return;
    const h = ACT[t.dataset.act]; if (!h) return;
    if (t.tagName === 'BUTTON' && t.disabled) return;
    try { await h(t, t.closest('.overlay'), ev); } catch (err) { console.error(err); toast('Something went wrong — please try again', 'err'); }
  });


  document.addEventListener('input', ev => {
    const t = ev.target; const form = t.closest && t.closest('form[data-form="estimate"]'); if (!form) return;
    const ov = form.closest('.overlay'); if (!ov || !ov._e) return;
    if (t.dataset.ef !== undefined) {
      const box = t.closest('.item'); const i = +box.dataset.i; const it = ov._e.items[i]; if (!it) return;
      const f = t.dataset.ef; it[f] = t.value;
      const q = k => box.querySelector(`[data-ef="${k}"]`);
      if (f === 'name' && !it.catManual) { it.category = guessCat(t.value); q('category').value = it.category; }
      if (f === 'category') it.catManual = !!t.value;
      if (f === 'purity' && !it.meltManual) { it.melting = defMelt(it.purity); q('melting').value = it.melting; }
      if (f === 'melting') it.meltManual = true;
      if (f === 'totMin' || f === 'totMax') {
        it.totalManual = !!(String(q('totMin').value).trim() || String(q('totMax').value).trim());
        it.totMin = q('totMin').value; it.totMax = q('totMax').value;
        const tag = ov.querySelector(`[data-o="tt${i}"]`); if (tag) { tag.textContent = it.totalManual ? 'manual' : 'auto'; tag.className = 'tag' + (it.totalManual ? ' manual' : ''); }
      }
      if (['wMin', 'wMax', 'qty', 'unit'].includes(f) && !it.totalManual) {
        const tot = itemTotal(it); q('totMin').value = tot ? tot[0] : ''; q('totMax').value = tot && tot[0] !== tot[1] ? tot[1] : '';
      }
      const sumEl = ov.querySelector(`[data-o="isum${i}"]`); if (sumEl) sumEl.textContent = itemSum(it);
      refreshTotals(ov);
      return;
    }
    if (t.name === 'type') {
      ov.querySelector('[data-o="eplabel"]').textContent = t.value === 'purchase' ? 'Supplier' : 'Party / Customer';
      $('#est-plist', ov).innerHTML = partyOptions(t.value); partyHint(ov);
    }
    if (t.name === 'partyName') partyHint(ov);
    if (['date', 'deliveryDate', 'autoNotes'].includes(t.name)) refreshAuto(ov);
  });
  document.addEventListener('keydown', ev => {
    const t = ev.target;
    if (ev.key === 'Enter' && t.tagName === 'INPUT' && t.closest && t.closest('form[data-form="estimate"]')) ev.preventDefault();
  });
  // photos — capture phase, so the files are read before the app's own file handler clears the input
  document.addEventListener('change', async ev => {
    const t = ev.target; if (!t || t.type !== 'file' || t.dataset.estfile === undefined) return;
    const files = Array.from(t.files || []); const ov = t.closest('.overlay'); const it = ov && ov._e && ov._e.items[+t.dataset.estfile];
    if (!it || !files.length) return;
    const room = Math.max(0, 6 - (it.photos || []).length);
    if (!room) return toast('Ek item mein 6 photos tak', 'err');
    toast('Photo add ho rahi hai…');
    try {
      for (const f of files.slice(0, room)) { const src = await shrinkImage(f, 1000, 'image/jpeg', 0.72); (it.photos = it.photos || []).push({ src }); }
      renderItems(ov);
      if (files.length > room) toast('Ek item mein 6 photos tak — baaki chhod di', 'err');
    } catch (err) { console.error(err); toast('Photo nahi padh paye', 'err'); }
  }, true);

  /* ---------- morning briefing data ---------- */
  if (typeof buildSummary === 'function') {
    const bs = buildSummary;
    buildSummary = function () {
      const s = bs.apply(this, arguments);
      try {
        const L = estList(); const ym = monthKey(todayStr());
        s.estimates = {
          pending: L.filter(x => x.status === 'Pending').sort((a, b) => String(a.date).localeCompare(String(b.date))).slice(0, 15)
            .map(x => ({ no: x.no, party: x.partyName, date: x.date, delivery: x.deliveryDate || null, items: (x.items || []).map(i => i.name).join(', ') })),
          wonThisMonth: L.filter(x => x.status === 'Won' && monthKey(x.decidedDate) === ym).length,
          lostThisMonth: L.filter(x => x.status === 'Lost' && monthKey(x.decidedDate) === ym).length
        };
      } catch (e) { console.error(e); }
      return s;
    };
  }

  window.SJ_ESTIMATES = { estimatePdf, autoNotes, planDeals, openEstimate, help: { perTxt, itemTotal, estTotal, rangeTxt, notesOf, qtyTxt, meltTxt, longDate, wRange, FOOTER: () => FOOTER, LOGO: () => (typeof EST_LOGO !== 'undefined' ? EST_LOGO : '') } };
})();
