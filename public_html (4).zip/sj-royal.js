/* =====================================================================
   ROYAL — small animations for the black & gold theme
   - gold ripple on buttons, gold progress line when changing screens,
     numbers count up when a screen opens, screens rise in softly,
     a gold spotlight follows the mouse over cards, gold dust drifts
     behind the app
   - switched off automatically when the phone asks for reduced motion
   ===================================================================== */
(() => {
  'use strict';
  if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const dark = () => document.documentElement.dataset.theme !== 'light';
  const ready = fn => (document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', fn, { once: true }) : fn());

  // gold ripple where the finger / mouse touches a button
  document.addEventListener('pointerdown', e => {
    const b = e.target.closest && e.target.closest('.btn, .sjw-btn');
    if (!b || b.disabled || !dark()) return;
    const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2.4;
    if (getComputedStyle(b).position === 'static') b.classList.add('royal-ripple-host'); else b.style.overflow = 'hidden';
    const s = document.createElement('span');
    s.className = 'royal-ripple';
    s.style.width = s.style.height = d + 'px';
    s.style.left = (e.clientX - r.left - d / 2) + 'px';
    s.style.top = (e.clientY - r.top - d / 2) + 'px';
    b.appendChild(s);
    setTimeout(() => s.remove(), 650);
  }, { passive: true });

  // thin gold line across the top when a new screen opens
  window.addEventListener('hashchange', () => {
    if (!dark()) return;
    const bar = document.createElement('div'); bar.className = 'royal-bar';
    document.body.appendChild(bar); setTimeout(() => bar.remove(), 800);
  });

  // numbers count up when a screen opens
  function countUp(root) {
    root.querySelectorAll('.kpi .v, .stat .v, .adv-pc .v, .flow-tot .v, .aud-big b, .mx .v, .pl-t .v').forEach(el => {
      if (el.children.length || el.dataset.counted === el.textContent) return;
      const txt = el.textContent, m = txt.match(/-?\d[\d,]*(\.\d+)?/);
      if (!m) return;
      const val = parseFloat(m[0].replace(/,/g, ''));
      if (!isFinite(val) || Math.abs(val) < 2) return;
      const dec = m[1] ? m[1].length - 1 : 0, indian = m[0].indexOf(',') >= 0;
      const pre = txt.slice(0, m.index), post = txt.slice(m.index + m[0].length);
      const fmt = v => { let s = Math.abs(v).toFixed(dec); if (indian) { const p = s.split('.'); s = Number(p[0]).toLocaleString('en-IN') + (p[1] ? '.' + p[1] : ''); } return (v < 0 ? '-' : '') + s; };
      el.dataset.counted = txt;
      const t0 = performance.now(), dur = 800;
      const step = now => {
        if (!el.isConnected || el.dataset.counted !== txt) return;
        const p = Math.min(1, (now - t0) / dur), k = 1 - Math.pow(1 - p, 3);
        el.textContent = p < 1 ? pre + fmt(val * k) + post : txt;
        if (p < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    });
  }
  // soft gold spotlight that follows the mouse over cards
  let hot = null;
  document.addEventListener('pointermove', e => {
    if (e.pointerType && e.pointerType !== 'mouse') return;
    const c = dark() && e.target.closest ? e.target.closest('.card, .kpi, .stat, .mx') : null;
    if (c !== hot) { if (hot) hot.classList.remove('sj-hot'); hot = c; if (c) c.classList.add('sj-hot'); }
    if (c) { const r = c.getBoundingClientRect(); c.style.setProperty('--mx', (e.clientX - r.left).toFixed(0) + 'px'); c.style.setProperty('--my', (e.clientY - r.top).toFixed(0) + 'px'); }
  }, { passive: true });

  // slow gold dust drifting up behind everything (dark theme only, paused when the tab is hidden)
  function goldDust() {
    const cv = document.createElement('canvas'); cv.id = 'sj-fx'; cv.setAttribute('aria-hidden', 'true'); document.body.appendChild(cv);
    const x = cv.getContext('2d'); if (!x) return; let W = 0, H = 0, P = [], raf = 0, last = 0;
    const dpr = Math.min(1.5, window.devicePixelRatio || 1);
    const mk = init => ({ x: Math.random() * W, y: init ? Math.random() * H : H + 8, r: 0.5 + Math.random() * 1.7, vy: 0.08 + Math.random() * 0.26, ph: Math.random() * 6.28, sp: 0.4 + Math.random() * 0.9, a: 0.18 + Math.random() * 0.5 });
    const size = () => { W = window.innerWidth; H = window.innerHeight; cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); x.setTransform(dpr, 0, 0, dpr, 0, 0); const n = W < 700 ? 16 : 34; P = Array.from({ length: n }, () => mk(true)); };
    const tick = t => {
      raf = requestAnimationFrame(tick); if (t - last < 33 || document.documentElement.classList.contains('tv-on')) return; const dt = Math.min(3, (t - last) / 16.7); last = t;
      x.clearRect(0, 0, W, H);
      for (const p of P) {
        p.y -= p.vy * dt; p.ph += 0.012 * p.sp * dt; p.x += Math.sin(p.ph) * 0.18 * dt; if (p.y < -8) Object.assign(p, mk(false));
        const tw = 0.55 + 0.45 * Math.sin(p.ph * 2.3); x.globalAlpha = p.a * tw;
        const g = x.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 4); g.addColorStop(0, 'rgba(255,236,179,1)'); g.addColorStop(0.35, 'rgba(230,194,94,.55)'); g.addColorStop(1, 'rgba(230,194,94,0)');
        x.fillStyle = g; x.beginPath(); x.arc(p.x, p.y, p.r * 4, 0, 6.2832); x.fill();
      }
      x.globalAlpha = 1;
    };
    const run = () => { cancelAnimationFrame(raf); raf = 0; if (!document.hidden && dark()) { last = performance.now(); raf = requestAnimationFrame(tick); } else x.clearRect(0, 0, W, H); };
    size(); run();
    let rz = 0; window.addEventListener('resize', () => { clearTimeout(rz); rz = setTimeout(() => { size(); run(); }, 200); });
    document.addEventListener('visibilitychange', run);
    new MutationObserver(run).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
  }

  ready(() => {
    try { goldDust(); } catch (e) { /* decoration only */ }
    if (typeof renderView !== 'function') return;
    const rv = renderView; let timer = null, enterT = null, firstData = false;
    window.renderView = function (full) {
      const root = document.getElementById('view'); const before = root && root.dataset.v;
      const r = rv.apply(this, arguments);
      const loaded = typeof MODE !== 'undefined' && MODE === 'cloud';
      if (root && (full || before !== root.dataset.v || (loaded && !firstData))) {
        // the new screen rises in softly
        root.classList.remove('sj-enter'); void root.offsetWidth; root.classList.add('sj-enter');
        clearTimeout(enterT); enterT = setTimeout(() => root.classList.remove('sj-enter'), 950);
        if (dark()) { if (loaded) firstData = true; clearTimeout(timer); timer = setTimeout(() => countUp(root), 40); }
      }
      return r;
    };
  });
})();
