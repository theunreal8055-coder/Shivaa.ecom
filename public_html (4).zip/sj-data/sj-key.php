<?php
// Shivaa Jewels — data encryption key. Is file ko KABHI delete ya badaliye mat.
// Iske bina aapka data nahi khulega. Backup mein poora sj-data folder rakhiye.
if (!defined('SJ')) { http_response_code(404); exit; }
return '3JcLlkRpIfHycDPSWLxJVgCvxF1esDVCL4diSkF6sj0=';
