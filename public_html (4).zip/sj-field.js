/* =====================================================================
   Shivaa Jewels — FIELD (dukaan-dukaan maal) · v41
   SUBAH   Delivery challan: staff, saathi, gaadi, kin dukanon par (kram se),
           kaunsa maal (RFID / QR scan + kaanta), seal no. → staff apne phone
           par PIN se "maal liya" karta hai → maal uski custody mein.
   DUKAAN  5 band-darwaze wale kadam — ek poora hue bina agla nahi khulta:
           1 Pahunchna (GPS — dukaan se kitni door)  2 Entry scan + seal
           3 Dukaandar ki pasand (bechna / approval) + dukaandar ki pushti
             (unke WhatsApp par link ya yahin signature)  4 Exit scan + kaanta
           5 Naya seal → agli dukaan. Gadbad = ruk jao + Manager ki manzoori.
   SHAAM   Wapsi scan + kaanta → hisaab: diya − becha − approval = wapas
           → parchi (image / WhatsApp). Kam = staff ke khaate, alert, aur
           band sirf Manager kar sakta hai.
   Plus    🆘 Panic button, phone location (app khuli ho tab), kram badlo.
   Server (sj-sec.php) checks who may change a challan and raises alerts.
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined' || !window.SJ_SCAN) return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { role: 'owner', name: 'Owner', id: 'u_owner', uname: 'owner' };
  const boss = () => !SITE || ['owner', 'manager'].includes(me().role);
  const pol = () => (window.SJ_SEC && SJ_SEC.policy) || {};
  const q$ = (s, r) => (r || document).querySelector(s);
  const API = (a, b, ms) => window.SJ_API_CALL(a, b || {}, ms);
  ['challans', 'fieldConfirms'].forEach(c => { if (!COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const ST = { draft: ['', 'Draft'], issued: ['gold', 'Staff ke accept ka intezaar'], out: ['sky', 'Field mein'], returned: ['red', 'Wapas — kam maal'], closed: ['green', 'Band'] };
  const tm = ms => ms ? new Date(ms).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';
  const prod = id => S.products.find(p => p.id === id);
  const chOf = id => S.challans.find(c => c.id === id);
  const valOf = p => { try { return r2(prodValue(p)); } catch (e) { return 0; } };

  /* bag = what should be with the staff right now */
  function bag(c) {
    const gone = new Set(); (c.visits || []).forEach(v => (v.done || v.exit) && (v.sel || []).forEach(s => gone.add(s.id)));
    return (c.items || []).filter(i => !gone.has(i.id));
  }
  function bagBefore(c, v) {   // bag at the start of visit v
    const gone = new Set(); for (const x of c.visits || []) { if (x.id === v.id) break; (x.sel || []).forEach(s => gone.add(s.id)); }
    return (c.items || []).filter(i => !gone.has(i.id));
  }
  const curVisit = c => (c.visits || []).find(v => !v.done);
  const probTxt = e => [e.missing.length ? `${e.missing.length} piece nahi mile` : '', e.wBad ? `kaante ka weight ${num(e.wDiff) > 0 ? '+' : ''}${num(e.wDiff).toFixed(3)} g alag` : ''].filter(Boolean).join(' · ');
  const lastSeal = c => { const vs = (c.visits || []).filter(v => v.sealOut); return vs.length ? vs[vs.length - 1].sealOut : (c.issue && c.issue.seal) || ''; };
  const myActive = () => S.challans.filter(c => ['issued', 'out'].includes(c.status) && (c.staffUid === me().id || c.staff2Uid === me().id)).sort((a, b) => b.createdAt - a.createdAt);
  async function put(c, quiet) { c = { ...c, updatedAt: Date.now() }; const ok = await save('challans', c, { quiet }); return ok ? c : null; }

  /* ---------------- v42 helpers: offline codes, photo proof, udhaar ---------------- */
  ['fieldCodes', 'fieldPhotos'].forEach(c => { if (!COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const online = () => !(window.SJ_OFFLINE && SJ_OFFLINE.on && SJ_OFFLINE.on());
  async function pbk(code, salt, iter) {
    const enc = new TextEncoder(); const k = await crypto.subtle.importKey('raw', enc.encode(String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '')), 'PBKDF2', false, ['deriveBits']);
    const b = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: iter }, k, 256);
    return Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join('');
  }
  const CODE_A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  const newCode = () => Array.from(crypto.getRandomValues(new Uint8Array(8))).map(x => CODE_A[x % CODE_A.length]).join('');
  const fmtCode = x => String(x).replace(/(.{4})(.{4})/, '$1 $2');
  function credit(pid) { const c = S.customers.find(x => x.id === pid) || {}; const lim = num(c.creditLimit); let bal = 0; try { bal = r2(partyDue(pid, 'customer')); } catch (e) { /* no dues fn */ } return { lim, bal, pct: lim > 0 ? bal / lim : 0 }; }
  const creditTxt = cr => cr.lim > 0 ? `Baaki ${inr(cr.bal)} / seema ${inr(cr.lim)}` : cr.bal > 0.5 ? `Baaki ${inr(cr.bal)} (seema tay nahi)` : 'Koi baaki nahi';
  async function codeOk(c, label) {
    if (!(c.codeH || []).length) { toast('Is challan mein offline code nahi hain — net chalu karke manzoori maangiye', 'err'); return null; }
    const code = await SJ_ASK('🔑 Manager ka offline code', 'Manager phone par 8 akshar ka code batayenge', { sub: label, mono: true, ph: 'XXXX XXXX' });
    if (!code) return null;
    const h = await pbk(code, 'sjfc|' + c.id, 20000); const i = c.codeH.indexOf(h);
    if (i < 0) { toast('Code galat hai', 'err'); return null; }
    if ((c.codeUsed || []).includes(i)) { toast('Ye code pehle use ho chuka — doosra code lijiye', 'err'); return null; }
    return i;
  }
  /* manager approval: online → request; offline / no answer → one-time code */
  async function manzoori(c, kind, ref, val, title, text, label) {
    if (boss()) return { by: me().name };
    if (online() && window.SJ_GUARD) { const a = await SJ_GUARD.ask(kind, ref, val, title, text); if (a) return { by: a.decidedBy || 'Manager' }; }
    if (!(c.codeH || []).length) return null;
    if (online() && !await SJ_CONFIRM('Manzoori nahi mili. Manager ne phone par offline code diya hai?', '🔑 Code daalo')) return null;
    const i = await codeOk(c, label || title); if (i === null) return null;
    return { by: 'Offline code #' + (i + 1), code: i };
  }
  async function stampImg(file, lines) {
    const url = URL.createObjectURL(file);
    try {
      const im = await new Promise((ok, no) => { const i = new Image(); i.onload = () => ok(i); i.onerror = no; i.src = url; });
      const s = Math.min(1, 720 / Math.max(im.naturalWidth, im.naturalHeight)); const w = Math.max(1, Math.round(im.naturalWidth * s)), h = Math.max(1, Math.round(im.naturalHeight * s));
      const cv = document.createElement('canvas'); cv.width = w; cv.height = h; const x = cv.getContext('2d'); x.drawImage(im, 0, 0, w, h);
      const fs = Math.max(12, Math.round(w / 38)); const bh = Math.round(fs * (lines.length + 0.9));
      x.fillStyle = 'rgba(0,0,0,.66)'; x.fillRect(0, h - bh, w, bh); x.fillStyle = '#f3d77a'; x.font = `600 ${fs}px system-ui, sans-serif`;
      lines.forEach((t, i) => x.fillText(String(t).slice(0, 90), Math.round(fs * 0.6), Math.round(h - bh + fs * (i + 1.15))));
      return cv.toDataURL('image/jpeg', 0.6);
    } finally { URL.revokeObjectURL(url); }
  }
  function snap(title, sub, stamp) {
    return new Promise(res => {
      const el = openModal(`${mHead('📷 ' + esc(title), esc(sub || ''))}<div class="m-body"><p class="small muted" style="margin-top:0">Photo par time, dukaan aur staff ka naam apne aap chhap jayega. Ye photo mitaayi nahi ja sakti.</p><label class="btn gold fd-big fd-cam">📷 Photo kheecho<input type="file" accept="image/*" capture="environment" data-o="cam"></label><div class="fd-ph" data-o="pv"></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button type="button" class="btn gold" data-o="ok" disabled>✓ Aage</button></div>`);
      let out = null; const inp = q$('[data-o="cam"]', el);
      const onChg = async ev => { if (ev.target !== inp) return; ev.stopPropagation(); const f = inp.files && inp.files[0]; if (!f) return; try { out = await stampImg(f, stamp); q$('[data-o="pv"]', el).innerHTML = `<img src="${out}" alt="Saboot photo">`; q$('[data-o="ok"]', el).disabled = false; } catch (e) { toast('Photo nahi khuli — dobara kheechiye', 'err'); } };
      window.addEventListener('change', onChg, true);
      q$('[data-o="ok"]', el).onclick = () => { res(out); closeModal(el); };
      new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); window.removeEventListener('change', onChg, true); res(null); } }).observe(q$('#modal-root'), { childList: true });
    });
  }
  async function proofPhoto(c, v, kind) {
    if (pol().fieldPhoto === false) return '';
    const img = await snap(kind === 'in' ? 'Entry photo — band bag aur seal' : 'Exit photo — saara maal tray mein', v.party,
      [`${settings().firm || 'Shivaa Jewels'} · ${kind === 'in' ? 'ENTRY' : 'EXIT'} · ${c.no}`, `${v.party} · ${c.staff}`, `${new Date().toLocaleString('en-IN')}${v.lat ? ` · ${v.lat},${v.lon}` : ''}`]);
    if (!img) return null;
    const id = (v.id + '-' + kind).replace(/[^A-Za-z0-9_-]/g, '');
    if (!await save('fieldPhotos', { id, cid: c.id, vid: v.id, kind, party: v.party, staff: c.staff, at: Date.now(), img }, { quiet: true })) return null;
    return id;
  }
  const photos = v => (S.fieldPhotos || []).filter(p => p.vid === v.id);
  function showPhoto(id) { const p = (S.fieldPhotos || []).find(x => x.id === id); if (!p) return toast('Photo abhi is device par nahi aayi (sync hone dijiye)', 'err'); openModal(`${mHead('📷 ' + esc(p.party), (p.kind === 'in' ? 'Entry' : 'Exit') + ' · ' + esc(p.staff) + ' · ' + esc(new Date(p.at).toLocaleString('en-IN')))}<div class="m-body"><img class="fd-parchi" src="${esc(p.img)}" alt="Saboot photo"></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`, { wide: true }); }

  /* ---------------- GPS helpers ---------------- */
  function here(timeout) {
    return new Promise(res => { if (!navigator.geolocation) return res(null);
      navigator.geolocation.getCurrentPosition(p => res({ lat: +p.coords.latitude.toFixed(6), lon: +p.coords.longitude.toFixed(6), acc: Math.round(p.coords.accuracy || 0) }), () => res(null), { enableHighAccuracy: true, timeout: timeout || 15000, maximumAge: 30000 }); });
  }
  function dist(a, b) { const R = 6371000, t = x => x * Math.PI / 180; const dl = t(b.lat - a.lat), dn = t(b.lon - a.lon); const h = Math.sin(dl / 2) ** 2 + Math.cos(t(a.lat)) * Math.cos(t(b.lat)) * Math.sin(dn / 2) ** 2; return Math.round(2 * R * Math.asin(Math.sqrt(h))); }
  let watch = null, lastPush = 0;
  function trackMe(on) {   // while a challan is out and the app is open (for all-day tracking use Traccar Client — see Gaadiyan & GPS)
    if (!SITE || !navigator.geolocation) return;
    if (on && watch === null) watch = navigator.geolocation.watchPosition(p => { if (Date.now() - lastPush < 55000) return; lastPush = Date.now(); API('loc_push', { lat: p.coords.latitude, lon: p.coords.longitude, acc: p.coords.accuracy, spd: p.coords.speed }).catch(() => null); }, () => null, { enableHighAccuracy: true, maximumAge: 30000 });
    if (!on && watch !== null) { navigator.geolocation.clearWatch(watch); watch = null; }
  }
  setInterval(() => trackMe(myActive().some(c => c.status === 'out')), 20000);

  /* ---------------- PIN (the staff accepts the bag on their own phone) ---------------- */
  function pinBox(title, sub) {
    return new Promise(res => { const el = openModal(`<form novalidate>${mHead(esc(title), esc(sub || ''))}<div class="m-body"><label class="f"><span>Apna PIN</span><input name="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="off" required></label><div class="red small" data-e></div><p class="small muted">PIN nahi bana? Setup → 🛡 Suraksha → "Mera PIN banao".</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Pakka</button></div></form>`);
      let ok = false; setTimeout(() => q$('[name=pin]', el).focus(), 50);
      q$('form', el).onsubmit = async ev => { ev.preventDefault(); try { await API('pin_check', { pin: ev.target.pin.value }); ok = true; closeModal(el); } catch (e) { q$('[data-e]', el).textContent = e.message || 'PIN galat'; ev.target.pin.value = ''; } };
      new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); res(ok); } }).observe(q$('#modal-root'), { childList: true }); });
  }

  /* ================= SUBAH: challan banao ================= */
  async function newChallan(id) {
    if (!boss()) return toast('Challan Owner / Manager banate hain', 'err');
    let users = []; if (SITE) { try { users = (await API('uext_list')).users.filter(u => u.active && u.role !== 'viewer'); } catch (e) { return toast(e.message, 'err'); } } else users = [{ id: 'u_owner', name: 'Owner', field: true }];
    const c = id ? chOf(id) : null; if (c && c.status !== 'draft') return openChallan(c.id);
    const v = c || { id: uid('dc'), no: nextNo('challans', 'DC-'), date: todayStr(), status: 'draft', route: [], items: [], createdAt: Date.now() };
    let cars = []; if (SITE && me().role === 'owner') { try { const g = await API('gps_cfg', {}); cars = Object.entries(g.devices || {}).filter(([, d]) => d.kind === 'car').map(([k, d]) => ({ id: k, name: d.name })); } catch (e) { /* none */ } }
    const uOpt = (sel, blank) => `${blank ? '<option value="">— koi nahi —</option>' : ''}${users.slice().sort((a, b) => (b.field ? 1 : 0) - (a.field ? 1 : 0)).map(u => `<option value="${esc(u.id)}"${sel === u.id ? ' selected' : ''}>${esc(u.name)}${u.field ? ' · field' : ''}</option>`).join('')}`;
    const el = openModal(`<form data-fd="ch" novalidate>${mHead('🚚 Delivery challan ' + esc(v.no), 'Subah — staff, gaadi, dukaan aur maal')}<div class="m-body">
      <div class="fg">${fld('Tareekh', 'date', v.date, { type: 'date' })}
      <label class="f"><span>Staff (zimmedar) <b class="req">*</b></span><select name="staffUid">${uOpt(v.staffUid)}</select></label>
      <label class="f"><span>Saathi staff</span><select name="staff2Uid">${uOpt(v.staff2Uid, 1)}</select></label>
      <label class="f"><span>Gaadi</span>${cars.length ? `<select name="carDev"><option value="">—</option>${cars.map(x => `<option value="${esc(x.id)}"${v.carDev === x.id ? ' selected' : ''}>${esc(x.name)}</option>`).join('')}</select>` : `<input name="car" value="${esc(v.car || '')}" placeholder="RJ-xx-xx-xxxx">`}</label>
      ${fld('Bag ka seal no.', 'seal', (v.issue && v.issue.seal) || '', { ph: 'numbered seal / tag' })}</div>
      <h4 class="fd-h">🏪 Kin dukanon par jaana hai (kram se)</h4><div class="fd-route" data-o="route"></div>
      <div class="fd-add"><input data-o="pq" placeholder="Dukaan / party ka naam ya shehar likhiye" autocomplete="off"><div data-o="pdd" class="dd"></div></div>
      <div class="btns"><button type="button" class="btn sm" data-act="fd-shuffle">🔀 Kram badlo (roz alag)</button></div>
      <h4 class="fd-h">💍 Maal</h4><div data-o="items"></div>
      <div class="btns"><button type="button" class="btn" data-act="fd-suggest">🤖 AI sujhav — kis dukaan ke liye kya</button><button type="button" class="btn gold" data-act="fd-scan-items">📶 Maal scan karo</button></div>
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><button type="button" class="btn" data-act="fd-draft">Draft save</button><button class="btn gold">✓ Issue karo</button></div></form>`, { wide: true });
    el.classList.add('fd-ov'); el._ch = JSON.parse(JSON.stringify(v)); el._users = users; el._cars = cars;
    paintDraft(el);
    const pq = q$('[data-o="pq"]', el), pdd = q$('[data-o="pdd"]', el);
    pq.addEventListener('input', () => { const qq = norm(pq.value); if (!qq) { pdd.innerHTML = ''; return; } const used = new Set(el._ch.route.map(r => r.partyId));
      const R = S.customers.filter(c2 => !used.has(c2.id) && [c2.name, c2.city, c2.phone].some(x => norm(x).includes(qq))).slice(0, 8);
      pdd.innerHTML = R.map(c2 => `<button type="button" class="dd-item" data-act="fd-route-add" data-id="${esc(c2.id)}"><span><b>${esc(c2.name)}</b> <span class="small muted">${esc(c2.city || '')}</span></span>${c2.geo ? '<span class="small">📍</span>' : ''}</button>`).join('') || '<div class="dd-empty small muted">Koi party nahi mili</div>'; });
    q$('form', el).onsubmit = ev => { ev.preventDefault(); issue(el); };
  }
  function draftFromForm(el) {
    const f = formObj(q$('form', el)); const c = el._ch; const u = id => el._users.find(x => x.id === id);
    c.date = f.date || todayStr(); c.staffUid = f.staffUid || ''; c.staff = (u(c.staffUid) || {}).name || ''; c.staff2Uid = f.staff2Uid || ''; c.staff2 = (u(c.staff2Uid) || {}).name || '';
    if (f.carDev !== undefined) { c.carDev = f.carDev; c.car = ((el._cars || []).find(x => x.id === f.carDev) || {}).name || ''; } else c.car = f.car || '';
    c.issue = { ...(c.issue || {}), seal: String(f.seal || '').trim() }; c.issuedByUid = me().id; c.issuedBy = me().name;
    c.pcs = c.items.length; c.gross = r3(sum(c.items, i => i.gross)); c.value = Math.round(sum(c.items, i => i.value));
    return c;
  }
  function paintDraft(el) {
    const c = el._ch;
    q$('[data-o="route"]', el).innerHTML = c.route.length ? c.route.map((r, i) => `<div class="fd-stop"><span class="fd-n">${i + 1}</span><div><b>${esc(r.name)}</b><div class="small muted">${esc(r.city || '')}${r.geo ? ' · 📍 jagah pata hai' : ' · 📍 pehli visit par jagah judegi'}</div>${(cr => `<div class="small ${cr.lim > 0 && cr.pct >= 1 ? 'red' : cr.lim > 0 && cr.pct >= 0.8 ? 'amber-t' : 'muted'}">💳 ${esc(creditTxt(cr))}${cr.lim > 0 && cr.pct >= 1 ? ' — <b>seema paar</b>' : cr.lim > 0 && cr.pct >= 0.8 ? ' — seema ke kareeb' : ''}</div>`)(credit(r.partyId))}</div><div class="btns"><button type="button" class="btn sm" data-act="fd-up" data-i="${i}" ${i ? '' : 'disabled'}>↑</button><button type="button" class="btn sm danger" data-act="fd-route-del" data-i="${i}">✕</button></div></div>`).join('') : '<div class="small muted">Abhi koi dukaan nahi jodi</div>';
    const it = c.items;
    q$('[data-o="items"]', el).innerHTML = it.length ? `<div class="fd-sum"><div><span>Piece</span><b>${it.length}</b></div><div><span>Kul wazan</span><b>${g3(sum(it, i => i.gross))}</b></div><div><span>Keemat (aaj ka bhaav)</span><b>${inr(sum(it, i => i.value))}</b></div><div><span>Kaanta</span><b>${c.issue && c.issue.weight != null ? g3(c.issue.weight) + (c.issue.wBad ? ' ✗' : ' ✓') : '—'}</b></div></div><div class="fd-items">${it.map(i => `<span class="fd-chip">#${esc(i.sku)} · ${esc(i.name)} · ${g3(i.gross)}</span>`).join('')}</div>` : '<div class="small muted">Abhi koi maal nahi</div>';
    const p = pol(), v = sum(it, i => i.value), warn = [];
    if (num(p.fieldTwo) > 0 && v > num(p.fieldTwo)) warn.push(`${inr(v)} ka maal — saathi staff zaroori (seema ${inr(p.fieldTwo)})`);
    if (num(p.fieldMax) > 0 && v > num(p.fieldMax)) warn.push(`Ek challan ki seema ${inr(p.fieldMax)} se zyada — sirf Owner bhej sakta hai`);
    let w = q$('.fd-warn', el); if (!w) { w = document.createElement('div'); w.className = 'warn-box small fd-warn'; q$('[data-o="items"]', el).after(w); } w.style.display = warn.length ? 'block' : 'none'; w.innerHTML = warn.map(esc).join('<br>');
  }
  async function scanItems(el) {
    const c = el._ch; const pool = S.products.filter(p => p.status === 'In Stock' && (!p.custody || p.custody === c.no) && !p.floorTx).map(p => p.id);
    const r = await SJ_SCAN.session({ title: 'Challan ' + c.no + ' ka maal', sub: 'Jo maal staff ko de rahe hain, sab scan kijiye', pool, poolWhy: 'Stock mein nahi (bika / approval / doosre challan mein)', preset: c.items.map(i => i.id), weight: true, weightRequired: false, doneLabel: 'Maal pakka' });
    if (!r) return;
    c.items = r.seen.map(id => { const p = prod(id); return { id, sku: p.sku, name: `${p.category || ''} ${p.purity || ''}`.trim(), purity: p.purity, gross: num(p.gross), net: num(p.net), value: valOf(p), floor: p.floor || '' }; });
    c.issue = { ...(c.issue || {}), weight: r.weight, wDiff: r.wDiff, wBad: r.wBad };
    paintDraft(el);
  }
  async function issue(el) {
    const c = draftFromForm(el), p = pol();
    if (!c.staffUid) return toast('Staff chuniye', 'err');
    if (c.staff2Uid && c.staff2Uid === c.staffUid) return toast('Saathi staff alag hona chahiye', 'err');
    if (!c.route.length) return toast('Kam se kam ek dukaan jodiye', 'err');
    if (!c.items.length) return toast('Maal scan kijiye', 'err');
    if (!c.issue.seal) return toast('Bag ka seal number likhiye', 'err');
    if (c.issue.weight == null) return toast('Kaante par kul weight daaliye (Maal scan karo → weight)', 'err');
    if (c.issue.wBad) return toast('Kaante ka weight scan kiye maal se nahi mil raha — dobara tolein', 'err');
    if (num(p.fieldTwo) > 0 && c.value > num(p.fieldTwo) && !c.staff2Uid) return toast('Itne maal ke saath saathi staff zaroori hai', 'err');
    const clash = c.items.filter(i => { const x = prod(i.id); return !x || x.status !== 'In Stock' || (x.custody && x.custody !== c.no); });
    if (clash.length) return toast(`${clash.length} piece ab stock mein nahi — dobara scan kijiye`, 'err');
    const over = c.route.map(r => ({ r, cr: credit(r.partyId) })).filter(x => x.cr.lim > 0 && x.cr.pct >= 1);
    if (over.length && p.creditBlock !== false) {
      const L = over.map(x => `${x.r.name}: ${creditTxt(x.cr)}`).join('\n');
      if (SITE && me().role !== 'owner') return toast(`Udhaar seema paar — ${over.map(x => x.r.name).join(', ')}. In dukanon ke liye sirf Owner chhoot de sakta hai (ya route se hataiye).`, 'err');
      if (!await SJ_CONFIRM(`Ye dukaanein udhaar seema paar kar chuki hain:\n${L}\n\nPhir bhi maal bhejein?`, 'Haan, chhoot do')) return;
      if (SITE && !await pinBox('Udhaar seema ki chhoot', 'Owner ka PIN')) return;
      c.creditOk = { by: me().name, at: Date.now(), shops: over.map(x => x.r.name) };
    }
    c.status = 'issued'; c.issue.at = Date.now(); c.issue.by = me().name;
    if (crypto && crypto.subtle) { try { const codes = Array.from({ length: 8 }, newCode); c.codeH = await Promise.all(codes.map(x => pbk(x, 'sjfc|' + c.id, 20000))); c.codeUsed = []; await save('fieldCodes', { id: c.id, no: c.no, codes, at: Date.now() }, { quiet: true }); } catch (e) { console.warn('[field] codes', e); } }
    const ok = await put(c); if (!ok) { c.status = 'draft'; return; }
    for (const i of c.items) { const x = prod(i.id); if (x) await save('products', { ...x, custody: c.no, custodyStaff: c.staff, updatedAt: Date.now() }, { quiet: true }); }
    closeModal(el); toast(`✓ ${c.no} issue — ab ${c.staff} apne phone par PIN se maal accept karein`);
    parchi(ok, 'issue'); renderView(true);
  }
  async function saveDraft(el) { const c = draftFromForm(el); c.status = 'draft'; if (await put(c)) { toast('Draft save'); closeModal(el); renderView(true); } }
  async function accept(id) {
    const c = chOf(id); if (!c || c.status !== 'issued') return;
    if (SITE && c.staffUid !== me().id) return toast('Ye challan ' + c.staff + ' ko accept karna hai', 'err');
    if (SITE && !await pinBox('Maal accept karo · ' + c.no, `${c.items.length} piece · ${g3(c.gross)} · ${inr(c.value)} — accept karte hi zimmedari aapki`)) return;
    const pos = await here(8000);
    const n = await put({ ...c, status: 'out', accept: { by: me().name, at: Date.now(), method: SITE ? 'pin' : 'local', lat: pos && pos.lat, lon: pos && pos.lon } });
    if (n) { toast('✓ Maal aapki custody mein — shubh yatra'); trackMe(true); renderView(true); }
  }

  /* ================= DUKAAN: 5 kadam ================= */
  async function startVisit(cid, pid) {
    const c = chOf(cid); if (!c || c.status !== 'out') return;
    const open = curVisit(c); if (open) return visitScreen(c.id, open.id);
    const r = c.route.find(x => x.partyId === pid) || null;
    const party = r ? S.customers.find(x => x.id === pid) : null;
    const v = { id: uid('vs').replace(/[^A-Za-z0-9_-]/g, ''), partyId: pid || '', party: r ? r.name : 'Dukaan', step: 1, startedAt: Date.now() };
    if (!r) { if (!boss()) { const a = await manzoori(c, 'field', c.id + '|newshop', '1', 'Nayi dukaan · ' + c.no, `${c.staff} challan se baahar ki dukaan par jaana chahte hain`); if (!a) return; if (a.code != null) { const c0 = chOf(cid); await put({ ...c0, codeUsed: [...(c0.codeUsed || []), a.code], newShopBy: a.by }, true); } } }
    const pos = await here(); const rad = num(pol().radius) || 200;
    if (pos) { v.lat = pos.lat; v.lon = pos.lon; v.acc = pos.acc;
      const g = party && party.geo; if (g && g.lat) { v.dist = dist(pos, g); if (v.dist > rad + Math.min(pos.acc || 0, 150)) v.far = v.dist; }
      else if (party && pos.acc && pos.acc <= 120) { await save('customers', { ...party, geo: { lat: pos.lat, lon: pos.lon, acc: pos.acc, by: me().name, at: Date.now() }, updatedAt: Date.now() }, { quiet: true }); v.geoLearned = true; } }
    else v.noGps = true;
    v.at = Date.now(); v.step = 2;
    const n = await put({ ...c, visits: [...(c.visits || []), v] }); if (!n) return;
    if (v.far) toast(`⚠ Aap dukaan se ${v.far} m door hain — ye record ho gaya`, 'err'); if (v.noGps) toast('Location nahi mili — phone ki location chalu kijiye', 'err');
    visitScreen(c.id, v.id);
  }
  const STEPS = ['Pahunchna', 'Entry scan', 'Pasand', 'Exit scan', 'Seal'];
  function visitScreen(cid, vid) {
    const c = chOf(cid); const v = c && (c.visits || []).find(x => x.id === vid); if (!v) return;
    const b0 = bagBefore(c, v), sel = v.sel || [], conf = (S.fieldConfirms || []).find(x => x.id === v.id);
    const html = `${mHead('🏪 ' + esc(v.party), esc(c.no) + ' · ' + esc(c.staff))}<div class="m-body">
      <ol class="fd-steps">${STEPS.map((s, i) => `<li class="${v.step > i + 1 || v.done ? 'ok' : v.step === i + 1 ? 'on' : ''}"><i>${v.step > i + 1 || v.done ? '✓' : i + 1}</i><span>${s}</span></li>`).join('')}</ol>
      <div class="fd-vk"><div><span>Bag mein (aane par)</span><b>${b0.length} pcs</b><small>${g3(sum(b0, i => i.gross))}</small></div><div><span>Pahunche</span><b>${tm(v.at)}</b><small>${v.far ? `<b class="red">${v.far} m door</b>` : v.dist != null ? v.dist + ' m' : v.noGps ? 'GPS nahi' : v.geoLearned ? 'jagah judi' : ''}</small></div><div><span>Pasand</span><b>${sel.length} pcs</b><small>${g3(sum(sel, s => s.gross))}</small></div></div>
      ${stepBody(c, v, conf)}</div><div class="m-foot"><button type="button" class="btn" data-act="close">Baad mein</button>${v.done ? '' : `<button type="button" class="btn danger" data-act="fd-panic" data-id="${esc(c.id)}">🆘</button>`}</div>`;
    const ov = q$('.fd-visit-ov'); if (ov) { ov.querySelector('.sheet').innerHTML = html; ov.dataset.c = cid; ov.dataset.v = vid; } else { const el = openModal(html, { wide: true }); el.classList.add('fd-visit-ov'); el.dataset.c = cid; el.dataset.v = vid; }
  }
  function stepBody(c, v, conf) {
    const go = (act, label, cls) => `<button type="button" class="btn ${cls || 'gold'} fd-big" data-act="${act}" data-c="${esc(c.id)}" data-v="${esc(v.id)}">${label}</button>`;
    if (v.done) return `<div class="fd-done">✓ Visit poori · nikle ${tm(v.leftAt)} · seal ${esc(v.sealOut || '')}${v.memoNo ? ` · memo <b>${esc(v.memoNo)}</b>` : ''}</div>${billBtn(c, v)}`;
    if (v.step === 2) return `<p>Bag <b>kholne se pehle</b> poora bag scan kijiye aur seal ka number dekhiye.</p><p class="small muted">Pichla seal: <b class="mono">${esc(lastSeal(c) || '—')}</b></p>${v.entry && (v.entry.missing.length || v.entry.wBad) && !v.override ? `<div class="warn-box">Entry mein gadbad: ${probTxt(v.entry)}. Dobara scan kijiye ya Manager se manzoori lijiye.</div>${go('fd-override', 'Manager se manzoori maango', '')}` : ''}${go('fd-entry', '📶 Entry scan karo')}`;
    if (v.step === 3) {
      const sel = v.sel || [];
      return `<p>Dukaandar jo pasand kare, sirf wahi piece scan kijiye. Phir har piece par <b>Bechna</b> ya <b>Approval</b> chuniye.</p>
        ${sel.length ? `<div class="fd-sel">${sel.map((s, i) => `<div class="fd-sr"><span><b class="mono">#${esc(s.sku)}</b> ${esc(s.name)} · ${g3(s.gross)}</span><span class="seg-mini"><button type="button" class="${s.mode === 'sale' ? 'on' : ''}" data-act="fd-mode" data-c="${esc(c.id)}" data-v="${esc(v.id)}" data-i="${i}" data-m="sale">Becha</button><button type="button" class="${s.mode !== 'sale' ? 'on' : ''}" data-act="fd-mode" data-c="${esc(c.id)}" data-v="${esc(v.id)}" data-i="${i}" data-m="approval">Approval</button></span></div>`).join('')}</div>` : ''}
        <div class="btns">${go('fd-pick', sel.length ? '📶 Aur scan karo' : '📶 Pasand scan karo', '')}</div>
        ${sel.length ? `<h4 class="fd-h">Dukaandar ki pushti</h4>${conf ? `<div class="fd-done">✓ Dukaandar ne link se pushti ki · ${tm(conf.at)}${conf.name ? ' · ' + esc(conf.name) : ''}</div>` : v.confirm && v.confirm.method === 'code' ? `<div class="fd-done">✓ Dukaandar ke code se pushti · ${tm(v.confirm.at)}</div>` : v.confirm && v.confirm.sign ? `<div class="fd-done">✓ Signature liya · ${tm(v.confirm.at)}</div>` : `<div class="btns">${go('fd-link', '📲 Dukaandar ko WhatsApp link', '')}${v.confH ? go('fd-ccode', '🔢 Dukaandar ka code daalo', '') : ''}${go('fd-sign', '✍ Yahin signature', '')}</div>${v.linkSentAt ? '<p class="small muted">Link bhej diya. Dukaandar "Haan" dabayenge to yahan apne aap ✓ aayega. Aapke phone mein net na ho to dukaandar link par dikha 8 akshar ka code bata denge.</p>' : ''}`}` : ''}
        <div class="btns" style="margin-top:12px">${go('fd-sel-done', sel.length ? '✓ Pasand pakki — aage' : 'Kuch nahi liya — aage', sel.length && !(conf || (v.confirm && (v.confirm.sign || v.confirm.method === 'code'))) ? 'gold dis' : 'gold')}</div>`;
    }
    if (v.step === 4) return `${billBtn(c, v)}<p>Ab bag mein <b>${bag({ ...c, visits: c.visits.map(x => x.id === v.id ? { ...x, done: true } : x) }).length} piece</b> hone chahiye. Poora bag scan kijiye aur kaante par tol kijiye.</p>${v.exit && (v.exit.missing.length || v.exit.wBad) && !v.override2 ? `<div class="warn-box">Exit mein gadbad: ${probTxt(v.exit)}. Aap dukaan se nahi nikal sakte — dobara scan kijiye ya Manager se manzoori lijiye.</div>${go('fd-override2', 'Manager se manzoori maango', '')}` : ''}${go('fd-exit', '📶 Exit scan + kaanta')}`;
    if (v.step === 5) return `<p>Bag band karke <b>naya seal</b> lagaiye aur uska number likhiye.</p><label class="f"><span>Naya seal no.</span><input data-o="seal" class="mono" autocomplete="off" placeholder="seal / tag no."></label>${go('fd-seal', '✓ Seal lagaya — visit band')}`;
    return '';
  }
  async function stepEntry(cid, vid) {
    let c = chOf(cid); const v = c.visits.find(x => x.id === vid); const b0 = bagBefore(c, v);
    const phIn = v.photoIn || await proofPhoto(c, v, 'in'); if (phIn === null) return toast('Entry photo zaroori hai — bina photo aage nahi badh sakte', 'err');
    if (phIn && !v.photoIn) { c = chOf(cid); await put({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, photoIn: phIn } : x) }, true); }
    const sealSeen = await SJ_ASK('Bag ka seal', 'Bag par laga seal number', { sub: 'Bag kholne se pehle seal dekhiye', ph: 'pichla: ' + (lastSeal(c) || '—'), mono: true });
    if (sealSeen === null) return;
    const r = await SJ_SCAN.session({ title: 'Entry scan · ' + v.party, sub: 'Bag kholne se pehle — saara maal', expected: b0.map(i => i.id), weight: true });
    if (!r) return; c = chOf(cid);
    const sealBad = !!lastSeal(c) && String(sealSeen).trim().toUpperCase() !== String(lastSeal(c)).trim().toUpperCase();
    const entry = { at: Date.now(), missing: r.missing, extra: r.extra, weight: r.weight, wDiff: r.wDiff, wBad: r.wBad };
    const ok = !r.missing.length && !r.wBad;
    const n = await put({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, entry, sealIn: String(sealSeen).trim(), sealBad: sealBad || undefined, step: ok ? 3 : 2 } : x) });
    if (n && sealBad) toast('⚠ Seal ka number nahi mila — Owner ko alert gaya', 'err');
    if (n && !ok) toast('⚠ Entry mein gadbad — Owner / Manager ko alert gaya', 'err');
    visitScreen(cid, vid);
  }
  async function override(cid, vid, which) {
    const c = chOf(cid); const v = c.visits.find(x => x.id === vid); const e = which === 2 ? v.exit : v.entry;
    const why = await SJ_ASK('Kya hua?', 'Wajah (Manager ko dikhegi)', { area: true }); if (!why) return;
    const a = await manzoori(c, 'field', vid + '|' + which, String(e.missing.length), `${which === 2 ? 'Exit' : 'Entry'} gadbad · ${v.party}`, `${c.staff}: ${e.missing.length} piece nahi mile${e.wBad ? ', weight fark ' + num(e.wDiff).toFixed(3) + ' g' : ''} — "${why}"`);
    if (!a) return; const by = a.by;
    const c2 = chOf(cid);
    // pieces that are really gone stay "gayab" in the bag until the evening tally
    await put({ ...c2, codeUsed: a.code != null ? [...(c2.codeUsed || []), a.code] : c2.codeUsed, visits: c2.visits.map(x => x.id === vid ? { ...x, [which === 2 ? 'override2' : 'override']: { by, why, at: Date.now(), offline: a.code != null || undefined }, step: which === 2 ? 5 : 3 } : x) });
    visitScreen(cid, vid);
  }
  async function stepPick(cid, vid) {
    const c = chOf(cid); const v = c.visits.find(x => x.id === vid); const b0 = bagBefore(c, v);
    const r = await SJ_SCAN.session({ title: 'Dukaandar ki pasand · ' + v.party, pool: b0.map(i => i.id), poolWhy: 'Ye piece aapke bag mein nahi', preset: (v.sel || []).map(s => s.id), doneLabel: 'Pasand pakki' });
    if (!r) return; const c2 = chOf(cid); const old = new Map(((c2.visits.find(x => x.id === vid) || {}).sel || []).map(s => [s.id, s]));
    const sel = r.seen.map(id => old.get(id) || (i => ({ id, sku: i.sku, name: i.name, purity: i.purity, gross: i.gross, net: i.net, value: i.value, mode: 'approval' }))(c2.items.find(i => i.id === id)));
    await put({ ...c2, visits: c2.visits.map(x => x.id === vid ? { ...x, sel, confirm: undefined } : x) });
    visitScreen(cid, vid);
  }
  async function setMode(t) { const c = chOf(t.dataset.c); const vid = t.dataset.v; await put({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, sel: x.sel.map((s, i) => i === +t.dataset.i ? { ...s, mode: t.dataset.m } : s) } : x) }, true); visitScreen(c.id, vid); }
  async function sendLink(cid, vid) {
    const c = chOf(cid); const v = c.visits.find(x => x.id === vid); const party = S.customers.find(x => x.id === v.partyId) || {};
    let k = '', confH = v.confH || ''; try { k = (await API('confirm_tok', { c: c.id, v: v.id })).k; if (!confH) confH = (await API('conf_hash', { v: v.id })).h || ''; } catch (e) { return toast(e.message, 'err'); }
    const url = location.origin + location.pathname.replace(/[^/]*$/, '') + `sj-api.php?a=confirm&c=${encodeURIComponent(c.id)}&v=${encodeURIComponent(v.id)}&k=${k}`;
    const sel = v.sel || [];
    const text = `${settings().firm || 'Shivaa Jewels'}\nNamaste ${v.party} ji,\nAapne ${sel.length} piece (${g3(sum(sel, s => s.net))}) liye: ${sel.filter(s => s.mode === 'sale').length} kharide, ${sel.filter(s => s.mode !== 'sale').length} approval par.\nKripya is link par list dekh kar pushti kijiye:\n${url}`;
    const wa = (typeof waUrl === 'function' && waUrl(party.phone, text)) || 'https://wa.me/?text=' + encodeURIComponent(text);
    window.open(wa, '_blank', 'noopener'); toast('Link bheja — dukaandar ke pushti karte hi yahan ✓ aa jayega (net chahiye)');
    const c3 = chOf(cid); await put({ ...c3, visits: c3.visits.map(x => x.id === vid ? { ...x, linkSentAt: Date.now(), confH: confH || undefined } : x) }, true); visitScreen(cid, vid);
  }
  function signPad(cid, vid) {
    const el = openModal(`${mHead('✍ Dukaandar ka signature', 'Ungli se sign karwaiye')}<div class="m-body"><canvas class="fd-pad" width="900" height="360"></canvas><label class="f"><span>Dukaandar ka naam</span><input data-o="nm" autocomplete="off"></label></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button type="button" class="btn" data-fd-clear>Mitao</button><button type="button" class="btn gold" data-fd-ok>Pakka</button></div>`);
    const cv = q$('canvas', el), x = cv.getContext('2d'); x.lineWidth = 5; x.lineCap = 'round'; x.strokeStyle = '#111'; x.fillStyle = '#fff'; x.fillRect(0, 0, cv.width, cv.height); let down = false, n = 0;
    const pt = e => { const r = cv.getBoundingClientRect(); return [(e.clientX - r.left) * cv.width / r.width, (e.clientY - r.top) * cv.height / r.height]; };
    cv.addEventListener('pointerdown', e => { down = true; cv.setPointerCapture(e.pointerId); const [a, b] = pt(e); x.beginPath(); x.moveTo(a, b); });
    cv.addEventListener('pointermove', e => { if (!down) return; const [a, b] = pt(e); x.lineTo(a, b); x.stroke(); n++; });
    cv.addEventListener('pointerup', () => { down = false; });
    q$('[data-fd-clear]', el).onclick = () => { x.fillRect(0, 0, cv.width, cv.height); n = 0; };
    q$('[data-fd-ok]', el).onclick = async () => {
      if (n < 15) return toast('Signature poora karwaiye', 'err');
      const sm = document.createElement('canvas'); sm.width = 450; sm.height = 180; sm.getContext('2d').drawImage(cv, 0, 0, 450, 180);
      const c = chOf(cid); await put({ ...c, visits: c.visits.map(v => v.id === vid ? { ...v, confirm: { method: 'sign', at: Date.now(), name: q$('[data-o="nm"]', el).value.trim().slice(0, 60), sign: sm.toDataURL('image/jpeg', 0.6) } } : v) });
      closeModal(el); visitScreen(cid, vid);
    };
  }
  async function selDone(cid, vid) {
    let c = chOf(cid); const v = c.visits.find(x => x.id === vid); const sel = v.sel || [];
    const conf = (S.fieldConfirms || []).find(x => x.id === v.id);
    if (sel.length && !conf && !(v.confirm && (v.confirm.sign || v.confirm.method === 'code'))) return toast('Pehle dukaandar ki pushti lijiye (link, code ya signature)', 'err');
    let memoNo = v.memoNo || '';
    if (sel.length && !memoNo) {
      const party = S.customers.find(x => x.id === v.partyId); if (!party) return toast('Party nahi mili — memo nahi bana', 'err');
      const days = num((settings().pro || {}).fieldReturnDays) || 7;
      const lines = sel.map(s => { const p = prod(s.id) || {}; return { id: uid('al'), productId: s.id, sku: s.sku, huid: p.huid || '', category: p.category || s.name, purity: p.purity || s.purity, making: p.making || '', pcs: num(p.pcs) || 1, gross: s.gross, net: s.net, status: s.mode === 'sale' ? 'sold' : 'out' }; });
      const ap = { id: uid('ap'), no: nextNo('approvals', 'AP-'), date: todayStr(), returnBy: addDays(todayStr(), days), partyId: party.id, partyName: party.name, partyPhone: party.phone || '', partyCity: party.city || '', notes: `Field: challan ${c.no} · ${c.staff}`, lines, challan: c.no, createdAt: Date.now(), updatedAt: Date.now() };
      if (!await save('approvals', ap)) return;
      for (const l of lines) { const p = prod(l.productId); if (!p) continue; const q = { ...p, status: 'On Approval', approvalNo: ap.no, approvalParty: party.name, updatedAt: Date.now() }; delete q.custody; delete q.custodyStaff; await save('products', q, { quiet: true }); }
      memoNo = ap.no;
    }
    c = chOf(cid);
    await put({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, memoNo: memoNo || undefined, selAt: Date.now(), step: 4 } : x) });
    if (memoNo) toast(`✓ Memo ${memoNo} bana${sel.some(s => s.mode === 'sale') ? ' — "🧾 Abhi bill banao" se becha maal ka bill yahin banaiye' : ''}`);
    visitScreen(cid, vid);
  }
  async function stepExit(cid, vid) {
    let c = chOf(cid); const v = c.visits.find(x => x.id === vid);
    const phOut = v.photoOut || await proofPhoto(c, v, 'out'); if (phOut === null) return toast('Exit photo zaroori hai — bina photo dukaan se nahi nikal sakte', 'err');
    if (phOut && !v.photoOut) { c = chOf(cid); await put({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, photoOut: phOut } : x) }, true); }
    const after = bag({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, done: true } : x) });
    const r = await SJ_SCAN.session({ title: 'Exit scan · ' + v.party, sub: 'Dukaan se nikalne se pehle — poora bag + kaanta', expected: after.map(i => i.id), weight: true, weightRequired: true });
    if (!r) return; c = chOf(cid);
    const exit = { at: Date.now(), missing: r.missing, extra: r.extra, weight: r.weight, wDiff: r.wDiff, wBad: r.wBad };
    const ok = !r.missing.length && !r.wBad;
    await put({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, exit, step: ok ? 5 : 4 } : x) });
    if (!ok) toast('⚠ Exit mein gadbad — aap nikal nahi sakte. Owner / Manager ko alert gaya', 'err');
    visitScreen(cid, vid);
  }
  async function stepSeal(cid, vid) {
    const ov = q$('.fd-visit-ov'); const s = String((q$('[data-o="seal"]', ov) || {}).value || '').trim();
    if (!s) return toast('Naye seal ka number likhiye', 'err');
    const c = chOf(cid); if (s.toUpperCase() === String(lastSeal(c)).toUpperCase()) return toast('Ye purana seal hai — naya seal lagaiye', 'err');
    await put({ ...c, visits: c.visits.map(x => x.id === vid ? { ...x, sealOut: s, done: true, leftAt: Date.now(), step: 6 } : x) });
    toast('✓ Visit band — agli dukaan'); const el = q$('.fd-visit-ov'); if (el) closeModal(el); renderView(true);
  }
  async function panic(cid) {
    const ok = await SJ_CONFIRM('🆘 PANIC — Owner aur Manager ko turant alert + aapki location jayegi. Bhejein?', '🆘 Alert bhejo');
    if (!ok) return; const pos = await here(6000); const c = chOf(cid); if (!c) return;
    await put({ ...c, panic: [...(c.panic || []), { at: Date.now(), by: me().name, lat: pos && pos.lat, lon: pos && pos.lon }] });
    if (pos) API('loc_push', pos).catch(() => null);
    toast('🆘 Alert chala gaya. Surakshit jagah jaiye, 100 / 112 par call kijiye.', 'err');
  }

  /* ================= SHAAM: wapsi ================= */
  async function receive(cid) {
    if (!boss()) return toast('Wapsi Owner / Manager lete hain', 'err');
    const c = chOf(cid); if (!c || c.status !== 'out') return;
    if (curVisit(c)) { if (!await SJ_CONFIRM(`${esc(c.staff)} ka ek visit (${esc(curVisit(c).party)}) abhi khula hai. Phir bhi wapsi lein?`, 'Wapsi lo')) return; }
    const b = bag(c);
    const r = await SJ_SCAN.session({ title: 'Shaam ki wapsi · ' + c.no, sub: `${c.staff} ka bag — saara bacha maal`, expected: b.map(i => i.id), weight: true, weightRequired: true, doneLabel: 'Wapsi pakki' });
    if (!r) return;
    const miss = b.filter(i => r.missing.includes(i.id));
    const ret = { at: Date.now(), by: me().name, weight: r.weight, wDiff: r.wDiff, wBad: r.wBad, back: r.seen.length, missing: miss.map(i => i.id), short: miss.length, shortWt: r3(sum(miss, i => i.gross)), shortVal: Math.round(sum(miss, i => i.value)), no: 'WR-' + c.no.replace(/^DC-/, '') };
    if (!miss.length && r.wBad) { ret.short = 0; ret.wOnly = true; }
    const cur = chOf(cid);
    const n = await put({ ...cur, status: miss.length ? 'returned' : 'closed', ret });
    if (!n) return;
    for (const i of b) { const p = prod(i.id); if (!p) continue; const q = { ...p, updatedAt: Date.now() };
      if (r.seen.includes(i.id)) { delete q.custody; delete q.custodyStaff; } else { q.custody = c.no + ' (KAM)'; }
      await save('products', q, { quiet: true }); }
    toast(miss.length ? `⚠ ${miss.length} piece kam — ${c.staff} ke khaate mein, Owner ko alert` : '✓ Saara maal wapas — challan band'); parchi(n, 'return'); renderView(true);
  }
  async function waive(cid) {
    const c = chOf(cid); if (!c || c.status !== 'returned') return; if (!boss()) return;
    const why = await SJ_ASK('Fark band karo · ' + c.no, 'Wajah', { sub: `${c.ret.short} piece (${g3(c.ret.shortWt)}, ${inr(c.ret.shortVal)}) kam`, area: true, ph: 'jaise: staff se ₹… vasool / piece mil gaya' }); if (!why) return;
    const found = await SJ_CONFIRM('Kya ye piece MIL gaye hain? <b>Haan</b> = wapas stock mein. <b>Nahi</b> = gum / vasool — stock se hatao (Lost).', 'Haan, mil gaye');
    if (!await put({ ...c, status: 'closed', diffOk: why.slice(0, 200), diffOkBy: me().name, diffOkAt: Date.now(), diffFound: found })) return;
    for (const id of c.ret.missing) { const p = prod(id); if (!p) continue; const q = { ...p, updatedAt: Date.now() }; delete q.custody; delete q.custodyStaff; if (!found) { q.status = 'Lost'; q.lostNote = `Challan ${c.no} · ${c.staff} · ${why.slice(0, 80)}`; } await save('products', q, { quiet: true }); }
    toast('✓ Challan band'); renderView(true);
  }

  /* ================= parchi (image) ================= */
  async function parchi(c, kind) {
    try {
      const W = 1080, cv = document.createElement('canvas'), x = cv.getContext('2d'); const rows = kind === 'return' ? (c.items || []) : (c.items || []);
      cv.width = W; cv.height = 2400; x.fillStyle = '#fff'; x.fillRect(0, 0, W, 2400);
      const T = (s, X, Y, z, w, col, a) => { x.font = `${w || 400} ${z}px 'SJ Poppins','Segoe UI',system-ui,sans-serif`; x.fillStyle = col || '#1b1408'; x.textAlign = a || 'left'; x.fillText(String(s), X, Y); };
      x.fillStyle = '#1b1408'; x.fillRect(0, 0, W, 170); T(settings().firm || 'Shivaa Jewels', 60, 80, 46, 700, '#e7c35f'); T(kind === 'return' ? 'WAPSI PARCHI (Return receipt)' : 'DELIVERY CHALLAN (Custody)', 60, 130, 26, 600, '#fff');
      T(c.no, W - 60, 80, 34, 700, '#e7c35f', 'right'); T(fmtD(c.date), W - 60, 130, 24, 400, '#fff', 'right');
      let y = 230; const kv = (k, v) => { T(k, 60, y, 24, 400, '#6b5b3a'); T(v, 380, y, 26, 600); y += 44; };
      kv('Staff', c.staff + (c.staff2 ? ' + ' + c.staff2 : '')); if (c.car) kv('Gaadi', c.car); kv('Dukaan', (c.route || []).map(r => r.name).join(', ').slice(0, 60)); kv('Seal', (c.issue && c.issue.seal) || '—');
      if (kind === 'return') { const r = c.ret; kv('Wapas', `${r.back} pcs · kaanta ${g3(r.weight)}`); const sold = (c.visits || []).reduce((n, v) => n + (v.sel || []).length, 0); kv('Dukanon par', `${sold} pcs (memo / bill)`); kv('Kam', r.short ? `${r.short} pcs · ${g3(r.shortWt)} · ${inr(r.shortVal)}` : 'Kuch nahi ✓'); }
      else kv('Kul', `${c.items.length} pcs · ${g3(c.gross)} · ${inr(c.value)}`);
      y += 10; x.fillStyle = '#e7dcc0'; x.fillRect(60, y, W - 120, 2); y += 40;
      const list = kind === 'return' ? (c.ret.missing || []).map(id => c.items.find(i => i.id === id)).filter(Boolean) : rows;
      if (kind === 'return') T(c.ret.short ? 'Kam piece:' : 'Saara maal wapas mila.', 60, y, 26, 700, c.ret.short ? '#b91c1c' : '#15803d'), y += 44;
      list.slice(0, 40).forEach((i, n) => { T(`${n + 1}. #${i.sku}  ${i.name}`, 60, y, 23); T(g3(i.gross), W - 60, y, 23, 600, '#1b1408', 'right'); y += 38; });
      if (list.length > 40) { T(`+ ${list.length - 40} aur`, 60, y, 22, 400, '#6b5b3a'); y += 38; }
      y += 40; T(kind === 'return' ? `Liya: ${c.ret.by} · ${new Date(c.ret.at).toLocaleString('en-IN')}` : `Diya: ${c.issue.by} · ${new Date(c.issue.at).toLocaleString('en-IN')}`, 60, y, 22, 400, '#6b5b3a'); y += 36;
      T(kind === 'return' ? 'Staff ke hastakshar: ____________________' : 'Staff ne PIN se accept kiya — maal ki zimmedari staff ki hai.', 60, y, 22, 400, '#6b5b3a'); y += 50;
      const out = document.createElement('canvas'); out.width = W; out.height = y + 20; out.getContext('2d').drawImage(cv, 0, 0);
      const blob = await new Promise(r => out.toBlob(r, 'image/png')); const name = `${kind === 'return' ? 'wapsi' : 'challan'}-${c.no}.png`;
      const file = new File([blob], name, { type: 'image/png' });
      const txt = kind === 'return' ? `${settings().firm || ''} — Wapsi parchi ${c.no}\n${c.staff}: wapas ${c.ret.back} pcs${c.ret.short ? ` · KAM ${c.ret.short} pcs (${g3(c.ret.shortWt)})` : ' · sab mila ✓'}` : `${settings().firm || ''} — Delivery challan ${c.no}\n${c.staff}: ${c.items.length} pcs · ${g3(c.gross)} · ${inr(c.value)}\nDukaan: ${(c.route || []).map(r => r.name).join(', ')}`;
      const el = openModal(`${mHead(kind === 'return' ? '🧾 Wapsi parchi' : '🧾 Delivery challan', esc(c.no))}<div class="m-body"><img class="fd-parchi" src="${URL.createObjectURL(blob)}" alt="parchi"></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><button type="button" class="btn" data-fd-dl>Image save</button><button type="button" class="btn green" data-fd-sh>WhatsApp</button></div>`, { wide: true });
      q$('[data-fd-dl]', el).onclick = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove(); };
      q$('[data-fd-sh]', el).onclick = async () => { try { if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ files: [file], text: txt }); return; } } catch (e) { if (e && e.name === 'AbortError') return; } window.open('https://wa.me/?text=' + encodeURIComponent(txt), '_blank', 'noopener'); };
    } catch (e) { console.error(e); }
  }

  /* ================= views ================= */

  /* ================= v42: dukaandar ka code, dukaan par bill, offline codes ================= */
  async function codeConfirm(cid, vid) {
    const c = chOf(cid); const v = c && c.visits.find(x => x.id === vid); if (!v || !v.confH) return;
    const code = await SJ_ASK('🔢 Dukaandar ka pushti code', 'Dukaandar ke link par dikha 8 akshar ka code', { sub: 'Dukaandar ke "Haan" dabane ke baad link par code dikhta hai', mono: true, ph: 'XXXX XXXX' });
    if (!code) return;
    if (await pbk(code, 'sjfc|' + vid, 10000) !== v.confH) return toast('Code galat hai — dukaandar se dobara poochhiye', 'err');
    const c2 = chOf(cid); await put({ ...c2, visits: c2.visits.map(x => x.id === vid ? { ...x, confirm: { method: 'code', at: Date.now() } } : x) });
    toast('✓ Dukaandar ki pushti ho gayi'); visitScreen(cid, vid);
  }
  function apOf(v) { return v.memoNo ? (S.approvals || []).find(a => a.no === v.memoNo) : null; }
  function billBtn(c, v) {
    const a = apOf(v); if (!a) return '';
    const left = (a.lines || []).filter(l => l.status === 'sold' && !l.soldInv), done = (a.lines || []).filter(l => l.soldInv);
    if (!left.length) return done.length ? `<div class="fd-done">🧾 Bill bana: ${esc([...new Set(done.map(l => l.soldInv))].join(', '))}</div>` : '';
    return `<div class="fd-billbox"><span>🧾 <b>${left.length} piece becha</b> (${g3(sum(left, l => l.net))}) — bill abhi bana dijiye</span><button type="button" class="btn sm gold" data-act="fd-bill" data-c="${esc(c.id)}" data-v="${esc(v.id)}">Abhi bill banao</button></div>`;
  }
  async function billNow(cid, vid) {
    const c = chOf(cid); const v = c && c.visits.find(x => x.id === vid); const a = v && apOf(v); if (!a) return;
    if (typeof billApproval !== 'function') return toast('Bill ka form nahi mila', 'err');
    const el = openModal(`${mHead('🧾 Becha maal ka bill', esc(a.no) + ' · ' + esc(a.partyName))}<div class="m-body"><p style="margin:0">Kaunsa bill banana hai?</p></div><div class="m-foot"><button type="button" class="btn" data-o="t" data-ty="estimate">Kacha (Estimate)</button><button type="button" class="btn gold" data-o="t" data-ty="sale">Pakka (GST Sale)</button></div>`, { small: true });
    el.querySelectorAll('[data-o="t"]').forEach(b => b.onclick = () => { closeModal(el); const ov = q$('.fd-visit-ov'); if (ov) closeModal(ov); billApproval(S.approvals.find(x => x.id === a.id) || a, b.dataset.ty); });
  }
  function showCodes(id) {
    const fc = (S.fieldCodes || []).find(x => x.id === id), c = chOf(id); if (!fc || !c) return;
    const used = new Set(c.codeUsed || []);
    openModal(`${mHead('🔑 Offline manzoori codes', esc(c.no) + ' · ' + esc(c.staff))}<div class="m-body"><p class="small" style="margin-top:0">Staff ke phone mein net na ho aur gadbad par aage badhna ho, to phone par <b>ek code</b> bataiye. Har code sirf <b>ek baar</b> chalta hai, aur har istemaal ka alert aapko aata hai. Ye codes staff ke phone par nahi jaate.</p>
      <div class="fd-codes">${fc.codes.map((x, i) => `<div class="${used.has(i) ? 'used' : ''}"><span>#${i + 1}</span><b class="mono">${esc(fmtCode(x))}</b><small>${used.has(i) ? 'use ho gaya' : 'baaki'}</small></div>`).join('')}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`);
  }

  /* ================= v42: AI challan sujhav ================= */
  function shopProfile(pid, since) {
    const prof = new Map(), ws = []; let n = 0;
    const addP = (cat, pur, net, w) => { const k = norm(cat); if (!k) return; const x = prof.get(k) || { cat: String(cat).trim(), w: 0, pur: new Map(), n: 0 }; x.w += w; x.n++; if (pur) x.pur.set(pur, (x.pur.get(pur) || 0) + Math.max(0, w)); prof.set(k, x); if (net > 0 && w > 0) ws.push(net); n++; };
    S.invoices.filter(v => v.partyId === pid && isSaleT(v.type) && !v.deleted && v.date >= since).forEach(v => (v.items || []).forEach(it => addP(it.category || it.name, it.purity, num(it.net) || num(it.gross) - num(it.less), 1)));
    (S.approvals || []).filter(a => a.partyId === pid && a.date >= since).forEach(a => (a.lines || []).forEach(l => addP(l.category, l.purity, num(l.net), l.status === 'sold' ? 2 : l.status === 'returned' ? -0.6 : 0.2)));
    ws.sort((a, b) => a - b); const med = ws.length ? ws[Math.floor(ws.length / 2)] : 0;
    return { prof, med, n };
  }
  function suggest(el) {
    const c = el._ch; if (!c.route.length) return toast('Pehle dukaanein jodiye', 'err');
    const since = addDays(todayStr(), -180), taken = new Set(c.items.map(i => i.id)), used = new Set();
    const pool = S.products.filter(p => p.status === 'In Stock' && !p.custody && !p.floorTx && !taken.has(p.id));
    if (!pool.length) return toast('Stock mein bhejne layak maal nahi', 'err');
    const shopWide = new Map(); S.invoices.filter(v => isSaleT(v.type) && !v.deleted && v.date >= addDays(todayStr(), -90)).forEach(v => (v.items || []).forEach(it => { const k = norm(it.category || it.name); if (k) shopWide.set(k, (shopWide.get(k) || 0) + 1); }));
    const per = num((settings().pro || {}).fieldSugN) || 8;
    const out = c.route.map(r => {
      const P = shopProfile(r.partyId, since); const fresh = !P.n;
      const scored = pool.filter(p => !used.has(p.id)).map(p => {
        const k = norm(p.category); const x = P.prof.get(k); let s = 0, why = [];
        if (x && x.w > 0) { s += 10 * Math.min(1, x.w / 6); why.push(`${x.cat} ${Math.round(x.w)}× liya`); if (x.pur.get(p.purity)) { s += 3; } }
        else if (x && x.w <= 0) s -= 6;
        else if (fresh && shopWide.get(k)) { s += 4 * Math.min(1, shopWide.get(k) / 10); why.push('dukaan par sabse zyada bikta'); }
        if (P.med > 0) { const r2_ = num(p.net) / P.med; if (r2_ > 0.6 && r2_ < 1.6) { s += 2; why.push('wazan theek'); } else if (r2_ > 2.5) s -= 2; }
        const age = p.createdAt ? (Date.now() - num(p.createdAt)) / 864e5 : 0; if (age > 90) { s += Math.min(3, age / 90); why.push(Math.round(age) + ' din purana'); }
        return { p, s, why };
      }).filter(x => x.s > 1.5).sort((a, b) => b.s - a.s).slice(0, per);
      scored.forEach(x => used.add(x.p.id));
      return { r, list: scored, fresh };
    });
    const body = out.map(o => `<div class="card fd-sug"><div class="card-h"><h3>🏪 ${esc(o.r.name)}</h3><span class="small muted">${o.fresh ? 'nayi dukaan — dukaan ki best-seller list' : 'pichhle 6 mahine ki bikri / approval se'}</span></div>${o.list.length ? o.list.map(x => `<label class="chk fd-sr"><input type="checkbox" data-sug="${esc(x.p.id)}" checked> <span><b class="mono">#${esc(x.p.sku)}</b> ${esc(x.p.category || '')} ${esc(x.p.purity || '')} · ${g3(x.p.gross)}<br><small class="muted">${esc(x.why.join(' · ') || 'stock')}</small></span></label>`).join('') : '<div class="small muted">Is dukaan ke liye koi sahi piece nahi mila</div>'}</div>`).join('');
    const m = openModal(`${mHead('🤖 AI challan sujhav', 'Jo design jahan bikta hai, wahi le jaiye — wapsi kam, bikri zyada')}<div class="m-body">${body}<p class="small muted">Ye sujhav pichhli bikri, approval ki wapsi, wazan aur stock ki umar se bane hain. Chune hue piece challan mein jud jayenge — phir "📶 Maal scan karo" se scan aur kaanta kijiye.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><button type="button" class="btn gold" data-act="fd-sug-add">Chune hue jodo</button></div>`, { wide: true });
    m._target = el;
  }
  function sugAdd(m) {
    const el = m && m._target; if (!el) return; const c = el._ch;
    const ids = [...m.querySelectorAll('[data-sug]:checked')].map(i => i.dataset.sug); const have = new Set(c.items.map(i => i.id)); let n = 0;
    ids.forEach(id => { if (have.has(id)) return; const p = prod(id); if (!p) return; c.items.push({ id, sku: p.sku, name: `${p.category || ''} ${p.purity || ''}`.trim(), purity: p.purity, gross: num(p.gross), net: num(p.net), value: valOf(p), floor: p.floor || '' }); n++; });
    if (n) c.issue = { ...(c.issue || {}), weight: null, wDiff: null, wBad: false };
    closeModal(m); paintDraft(el); toast(n ? `✓ ${n} piece jode — ab "📶 Maal scan karo" se scan + kaanta kijiye` : 'Kuch nahi joda');
  }

  /* ================= v42: staff aur dukaandar ka score ================= */
  function scoreBody() {
    const D = ui.fdScoreD || 30, since = addDays(todayStr(), -D);
    const CH = S.challans.filter(c => (c.date || '') >= since && c.status !== 'draft');
    const st = new Map(), sh = new Map();
    CH.forEach(c => {
      const x = st.get(c.staffUid || c.staff) || { name: c.staff, ch: 0, vis: 0, mins: 0, minsN: 0, sale: 0, saleV: 0, appr: 0, short: 0, shortV: 0, bad: 0, panic: 0, days: new Set() };
      x.ch++; x.days.add(c.date); x.panic += (c.panic || []).length;
      if (c.ret && c.ret.short) { x.short += num(c.ret.short); x.shortV += num(c.ret.shortVal); }
      (c.visits || []).forEach(v => {
        x.vis++; if (v.leftAt && v.at) { x.mins += (v.leftAt - v.at) / 60000; x.minsN++; }
        if (v.far || v.sealBad || (v.entry && v.entry.missing && v.entry.missing.length) || (v.exit && v.exit.missing && v.exit.missing.length)) x.bad++;
        (v.sel || []).forEach(s2 => { if (s2.mode === 'sale') { x.sale++; x.saleV += num(s2.value); } else x.appr++; });
        if (v.partyId) { const y = sh.get(v.partyId) || { name: v.party, vis: 0, pcs: 0, saleV: 0 }; y.vis++; y.pcs += (v.sel || []).length; y.saleV += sum((v.sel || []).filter(s2 => s2.mode === 'sale'), s2 => s2.value); sh.set(v.partyId, y); }
      });
      st.set(c.staffUid || c.staff, x);
    });
    const S1 = [...st.values()].map(x => ({ ...x, score: Math.max(0, Math.round(50 + Math.min(30, x.saleV / 50000) + Math.min(10, x.vis / 5) - x.bad * 5 - x.short * 8 - (x.minsN && x.mins / x.minsN > 60 ? 5 : 0))) })).sort((a, b) => b.score - a.score);
    // retailers: approvals (kept vs returned), dues, payment speed
    const R = S.customers.filter(cu => sh.has(cu.id) || (S.approvals || []).some(a => a.partyId === cu.id && a.date >= since)).map(cu => {
      const y = sh.get(cu.id) || { name: cu.name, vis: 0, pcs: 0, saleV: 0 };
      const L = (S.approvals || []).filter(a => a.partyId === cu.id && a.date >= addDays(todayStr(), -180)).flatMap(a => a.lines || []);
      const kept = L.filter(l => l.status === 'sold').length, ret = L.filter(l => l.status === 'returned').length;
      const bills = S.invoices.filter(v => v.partyId === cu.id && isSaleT(v.type) && !v.deleted && v.date >= addDays(todayStr(), -365));
      const pd = []; bills.forEach(v => { const ps = (v.payments || []).filter(p => p.date); if (ps.length && invDue(v) <= 0.5) pd.push(Math.max(0, daysBetween(v.date, ps.map(p => p.date).sort().pop()))); });
      const payDays = pd.length ? Math.round(pd.reduce((a, b) => a + b, 0) / pd.length) : null;
      const cr = credit(cu.id); const keepPct = kept + ret ? Math.round(kept / (kept + ret) * 100) : null;
      let sc = 50 + (keepPct != null ? (keepPct - 50) / 2 : 0) + Math.min(20, sum(bills, invPayable) / 100000) - (payDays != null ? Math.min(25, payDays / 3) : 5) - (cr.lim > 0 && cr.pct >= 1 ? 20 : 0);
      sc = Math.max(0, Math.min(100, Math.round(sc)));
      return { cu, y, kept, ret, keepPct, payDays, cr, sc, grade: sc >= 70 ? 'A' : sc >= 50 ? 'B' : 'C' };
    }).sort((a, b) => b.sc - a.sc);
    const seg = `<div class="seg-mini" style="margin-bottom:10px">${[7, 30, 90].map(d => `<button type="button" class="${D === d ? 'on' : ''}" data-act="fd-score-d" data-d="${d}">${d} din</button>`).join('')}</div>`;
    const t1 = S1.length ? `<div class="tw"><table class="tbl"><thead><tr><th>Staff</th><th class="r">Score</th><th class="r">Challan</th><th class="r">Dukaan</th><th class="r">Becha</th><th class="r">Approval</th><th class="r">Avg samay</th><th class="r">Gadbad</th><th class="r">Kam maal</th></tr></thead><tbody>${S1.map(x => `<tr><td><b>${esc(x.name || '—')}</b><div class="small muted">${x.days.size} din</div></td><td class="r"><b class="${x.score >= 70 ? 'green' : x.score >= 50 ? '' : 'red'}">${x.score}</b></td><td class="r">${x.ch}</td><td class="r">${x.vis}</td><td class="r">${x.sale} pcs<div class="small muted">${compactInr(x.saleV)}</div></td><td class="r">${x.appr}</td><td class="r">${x.minsN ? Math.round(x.mins / x.minsN) + ' min' : '—'}</td><td class="r ${x.bad ? 'red' : ''}">${x.bad}</td><td class="r ${x.short ? 'red' : ''}">${x.short ? x.short + ' pcs · ' + compactInr(x.shortV) : '0'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="small muted">Is samay mein koi challan nahi</div>';
    const t2 = R.length ? `<div class="tw"><table class="tbl"><thead><tr><th>Dukaan</th><th class="r">Grade</th><th class="r">Visit</th><th class="r">Rakha / lautaya</th><th class="r">Bhugtan</th><th class="r">Baaki</th><th>Sujhav</th></tr></thead><tbody>${R.slice(0, 80).map(x => `<tr><td><b>${esc(x.cu.name)}</b><div class="small muted">${esc(x.cu.city || '')}</div></td><td class="r"><span class="pill ${x.grade === 'A' ? 'green' : x.grade === 'B' ? 'gold' : 'red'}">${x.grade} · ${x.sc}</span></td><td class="r">${x.y.vis}</td><td class="r">${x.kept} / ${x.ret}${x.keepPct != null ? `<div class="small muted">${x.keepPct}% rakha</div>` : ''}</td><td class="r">${x.payDays != null ? x.payDays + ' din' : '—'}</td><td class="r ${x.cr.lim > 0 && x.cr.pct >= 1 ? 'red' : ''}">${inr(x.cr.bal)}${x.cr.lim > 0 ? `<div class="small muted">seema ${compactInr(x.cr.lim)}</div>` : ''}</td><td class="small">${x.grade === 'A' ? 'Zyada aur naya maal bhejiye' : x.grade === 'B' ? 'Normal' : x.cr.lim > 0 && x.cr.pct >= 1 ? 'Pehle baaki vasool' : 'Kam maal, sirf chalne wale design'}</td></tr>`).join('')}</tbody></table></div>` : '<div class="small muted">Abhi data nahi</div>';
    return `${seg}<div class="card"><div class="card-h"><h3>🧑‍💼 Staff scorecard</h3><span class="small muted">bikri, visit, samay, gadbad, kam maal</span></div>${t1}</div><div class="card"><div class="card-h"><h3>🏪 Dukaandar ranking</h3><span class="small muted">rakha vs lautaya (6 mahine), bhugtan ki raftaar, baaki</span></div>${t2}</div>`;
  }

  function openChallan(id) {
    const c = chOf(id); if (!c) return; const b = bag(c);
    const vis = (c.visits || []).map(v => `<div class="fd-vrow ${v.entry && v.entry.missing.length || v.exit && v.exit.missing.length || v.far || v.sealBad ? 'bad' : ''}"><div><b>${esc(v.party)}</b> <span class="small muted">${tm(v.at)}–${tm(v.leftAt)}</span>${v.far ? ` <span class="pill red">${v.far} m door</span>` : ''}${v.sealBad ? ' <span class="pill red">seal</span>' : ''}${v.entry && v.entry.missing.length ? ` <span class="pill red">entry ${v.entry.missing.length} kam</span>` : ''}${v.exit && v.exit.missing.length ? ` <span class="pill red">exit ${v.exit.missing.length} kam</span>` : ''}${v.override || v.override2 ? ' <span class="pill gold">manzoori</span>' : ''}</div><div class="small">${(v.sel || []).length} pcs pasand${v.memoNo ? ' · memo ' + esc(v.memoNo) : ''}${(S.fieldConfirms || []).some(x => x.id === v.id) ? ' · ✓ dukaandar pushti' : v.confirm && v.confirm.method === 'code' ? ' · 🔢 code pushti' : v.confirm && v.confirm.sign ? ' · ✍ sign' : ''}${v.override && v.override.offline || v.override2 && v.override2.offline ? ' · <b class="amber-t">🔑 offline code</b>' : ''}</div>${photos(v).length ? `<div class="fd-thumbs">${photos(v).map(p => `<button type="button" class="fd-th" data-act="fd-photo" data-id="${esc(p.id)}"><img src="${esc(p.img)}" alt=""><span>${p.kind === 'in' ? 'Entry' : 'Exit'}</span></button>`).join('')}</div>` : v.photoIn || v.photoOut ? '<div class="small muted">📷 photo sync ho rahi hai…</div>' : ''}</div>`).join('');
    openModal(`${mHead('🚚 ' + esc(c.no) + ' · ' + esc(c.staff), `${fmtD(c.date)} · ${ST[c.status][1]}`)}<div class="m-body">
      <div class="fd-sum"><div><span>Diya</span><b>${c.items.length} pcs</b><small>${g3(c.gross)}</small></div><div><span>Bag mein abhi</span><b>${b.length} pcs</b><small>${g3(sum(b, i => i.gross))}</small></div><div><span>Dukanon par</span><b>${c.items.length - b.length} pcs</b><small>${(c.visits || []).filter(v => v.done).length}/${c.route.length} dukaan</small></div><div><span>Keemat</span><b>${inr(c.value)}</b><small>${c.car ? esc(c.car) : ''}</small></div></div>
      ${(c.panic || []).length ? `<div class="warn-box">🆘 PANIC: ${(c.panic || []).map(p => `${tm(p.at)}${p.lat ? ` · <a href="https://maps.google.com/?q=${p.lat},${p.lon}" target="_blank" rel="noopener">location</a>` : ''}`).join(', ')}</div>` : ''}
      ${c.ret ? `<div class="${c.ret.short ? 'warn-box' : 'fd-done'}">Wapsi ${tm(c.ret.at)} · ${c.ret.back} pcs · kaanta ${g3(c.ret.weight)}${c.ret.short ? ` · <b>${c.ret.short} kam (${g3(c.ret.shortWt)}, ${inr(c.ret.shortVal)})</b>` : ' ✓'}${c.diffOk ? ` · band: ${esc(c.diffOkBy)} — ${esc(c.diffOk)}` : ''}</div>` : ''}
      <h4 class="fd-h">Visits</h4>${vis || '<div class="small muted">Abhi koi visit nahi</div>'}
      <h4 class="fd-h">Route</h4><div class="small">${c.route.map((r, i) => `${i + 1}. ${esc(r.name)}`).join(' · ')}</div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button>${boss() && (S.fieldCodes || []).some(x => x.id === c.id) && ['issued', 'out'].includes(c.status) ? `<button type="button" class="btn" data-act="fd-codes" data-id="${esc(c.id)}">🔑 Offline codes</button>` : ''}<button type="button" class="btn" data-act="fd-parchi" data-id="${esc(c.id)}" data-k="issue">Challan parchi</button>${c.ret ? `<button type="button" class="btn" data-act="fd-parchi" data-id="${esc(c.id)}" data-k="return">Wapsi parchi</button>` : ''}${c.status === 'out' && boss() ? `<button type="button" class="btn gold" data-act="fd-ret" data-id="${esc(c.id)}">Shaam ki wapsi</button>` : ''}${c.status === 'returned' && boss() ? `<button type="button" class="btn gold" data-act="fd-waive" data-id="${esc(c.id)}">Fark band karo</button>` : ''}</div>`, { wide: true });
  }
  function staffHome() {   // the field staff's own screen
    const L = myActive();
    if (!L.length) return emptyBox('Aaj aapke naam koi challan nahi. Owner / Manager challan issue karenge to yahan dikhega.');
    return L.map(c => {
      if (c.status === 'issued') return `<div class="card fd-me"><div class="card-h"><h3>📥 ${esc(c.no)} — maal accept karo</h3></div><div class="fd-sum"><div><span>Piece</span><b>${c.items.length}</b></div><div><span>Wazan</span><b>${g3(c.gross)}</b></div><div><span>Keemat</span><b>${inr(c.value)}</b></div><div><span>Seal</span><b class="mono">${esc((c.issue && c.issue.seal) || '')}</b></div></div><p class="small">Maal gin kar dekh lijiye. PIN dalte hi ye maal aapki zimmedari mein aa jayega.</p><button type="button" class="btn gold fd-big" data-act="fd-accept" data-id="${esc(c.id)}">✓ Maal mil gaya — PIN se accept</button></div>`;
      const open = curVisit(c), b = bag(c), doneIds = new Set((c.visits || []).filter(v => v.done).map(v => v.partyId));
      return `<div class="card fd-me"><div class="card-h"><h3>🚚 ${esc(c.no)}</h3><span class="pill sky">Field mein</span></div>
        <div class="fd-sum"><div><span>Bag mein</span><b>${b.length} pcs</b><small>${g3(sum(b, i => i.gross))}</small></div><div><span>Dukaan</span><b>${doneIds.size}/${c.route.length}</b></div><div><span>Seal</span><b class="mono">${esc(lastSeal(c))}</b></div></div>
        ${open ? `<button type="button" class="btn gold fd-big" data-act="fd-visit" data-c="${esc(c.id)}" data-v="${esc(open.id)}">▶ ${esc(open.party)} — kadam ${Math.min(5, open.step)} jaari rakho</button>` : ''}
        <div class="fd-route">${c.route.map((r, i) => `<div class="fd-stop ${doneIds.has(r.partyId) ? 'ok' : ''}"><span class="fd-n">${doneIds.has(r.partyId) ? '✓' : i + 1}</span><div><b>${esc(r.name)}</b><div class="small muted">${esc(r.city || '')}</div></div>${!open && !doneIds.has(r.partyId) ? `<button type="button" class="btn sm gold" data-act="fd-start" data-c="${esc(c.id)}" data-p="${esc(r.partyId)}">📍 Pahunch gaya</button>` : ''}</div>`).join('')}</div>
        <div class="fd-panic"><button type="button" class="btn danger" data-act="fd-panic" data-id="${esc(c.id)}">🆘 Panic</button><span class="small muted">Khatra ho to dabaiye — Owner ko turant location jayegi</span></div></div>`;
    }).join('');
  }
  function listBody(all) {
    const t = todayStr();
    const L = S.challans.filter(c => all || c.date === t || ['issued', 'out', 'returned'].includes(c.status)).sort((a, b) => (b.date || '').localeCompare(a.date || '') || b.createdAt - a.createdAt).slice(0, 300);
    const out = S.challans.filter(c => c.status === 'out'), outV = sum(out, c => sum(bag(c), i => i.value));
    const k = `<div class="stats">${stat('Field mein abhi', out.length + ' challan', `${new Set(out.map(c => c.staffUid)).size} staff`, 'truck', 'sky')}${stat('Bahar maal', compactInr(outV), g3(sum(out, c => sum(bag(c), i => i.gross))), 'coin', 'gold')}${stat('Aaj dukanon par', sum(S.challans.filter(c => c.date === t), c => (c.visits || []).reduce((n, v) => n + (v.sel || []).length, 0)) + ' pcs', 'memo / bill', 'trend', 'sky')}${stat('Kam maal (khula)', S.challans.filter(c => c.status === 'returned').length + ' challan', 'Manager ko band karna hai', 'box', '')}</div>`;
    if (!L.length) return k + emptyBox('Abhi koi challan nahi. Subah staff ko maal dene ke liye "Naya challan" banaiye.', boss() ? '<button type="button" class="btn gold" data-act="fd-new">+ Naya challan</button>' : '');
    return k + `<div class="fd-list">${L.map(c => { const b = bag(c); const bad = (c.visits || []).some(v => v.far || v.sealBad || (v.entry && v.entry.missing.length) || (v.exit && v.exit.missing.length)) || (c.panic || []).length || c.status === 'returned'; const ov = curVisit(c);
      return `<div class="card fd-c ${bad ? 'red' : c.status === 'out' ? (ov ? 'amber' : 'green') : ''}" data-act="${c.status === 'draft' ? 'fd-edit' : 'fd-open'}" data-id="${esc(c.id)}" role="button" tabindex="0"><div class="fd-ch"><b>${esc(c.no)}</b><span class="pill ${ST[c.status][0]}">${ST[c.status][1]}</span></div><div><b>${esc(c.staff || '—')}</b>${c.staff2 ? ' + ' + esc(c.staff2) : ''} <span class="small muted">${esc(fmtD(c.date))}${c.car ? ' · ' + esc(c.car) : ''}</span></div>
        <div class="fd-mini"><span>${c.items.length} diya</span><span>${b.length} bag mein</span><span>${(c.visits || []).filter(v => v.done).length}/${c.route.length} dukaan</span><span>${inr(c.value)}</span></div>${ov ? `<div class="small">▶ Abhi: <b>${esc(ov.party)}</b> (kadam ${Math.min(5, ov.step)})</div>` : ''}${(c.panic || []).length ? '<div class="small red"><b>🆘 PANIC</b></div>' : ''}</div>`; }).join('')}</div>`;
  }
  Object.assign(ICON, { field: '<path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>', truck: '<path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>' });
  if (!VIEWS.some(v => v[0] === 'field')) { const i = VIEWS.findIndex(v => v[0] === 'floors' || v[0] === 'vault'); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, ['field', 'Field', 'field', 'Field · Challan']); }
  VIEWDEF.field = {
    shell: () => { const tabs = boss() ? [['today', '🚚 Challan'], ['all', '📜 Saare'], ['me', '🧭 Mera challan'], ['score', '📈 Score'], ...(window.SJ_CONTROL ? SJ_CONTROL.tabs() : [])] : [['me', '🧭 Mera challan']];
      const t = ui.fdTab || (boss() ? 'today' : 'me');
      return `<div class="rep-tabs">${tabs.map(([k, l]) => `<button type="button" data-act="seg" data-k="fdTab" data-v="${k}" class="${t === k ? 'on' : ''}">${l}</button>`).join('')}</div>${boss() && ['today', 'all'].includes(t) ? '<div class="toolbar"><button type="button" class="btn gold" data-act="fd-new">+ Naya challan</button></div>' : ''}<div id="vbody"></div>`; },
    body() { const t = ui.fdTab || (boss() ? 'today' : 'me'); if (t === 'me' || !boss()) return staffHome(); if (t === 'all') return listBody(true); if (t === 'score') return scoreBody(); if (window.SJ_CONTROL && SJ_CONTROL.body(t) !== null) return SJ_CONTROL.body(t); return listBody(false); }
  };
  // counter sale of a piece that is out with a field staff → stop
  if (typeof addFromProduct === 'function') { const AF = addFromProduct; addFromProduct = function (p) { if (p && p.custody) { toast(`#${p.sku} abhi field mein hai (${p.custody}${p.custodyStaff ? ' · ' + p.custodyStaff : ''}) — pehle wapsi lijiye`, 'err'); return; } return AF.apply(this, arguments); }; }
  // dashboard: staff with an active challan see it first
  { const D = VIEWDEF.dashboard; if (D && D.body) VIEWDEF.dashboard = { ...D, body() { let x = ''; try { const L = SITE ? myActive() : []; if (L.length) { const c = L[0]; x = `<div class="card fd-dash" data-act="go-field" role="button" tabindex="0"><b>🚚 ${esc(c.no)} — ${c.status === 'issued' ? 'maal accept karna hai' : 'field mein'}</b><span>${bag(c).length} pcs bag mein · kholiye</span></div>`; } } catch (e) { console.error(e); } return x + D.body.apply(D, arguments); } }; }

  const ACT = {
    'fd-new': () => newChallan(), 'fd-edit': t => newChallan(t.dataset.id), 'fd-open': t => openChallan(t.dataset.id),
    'fd-route-add': t => { const el = t.closest('.overlay'); const p = S.customers.find(x => x.id === t.dataset.id); if (!p) return; el._ch.route.push({ partyId: p.id, name: p.name, city: p.city || '', phone: p.phone || '', geo: p.geo ? 1 : 0 }); q$('[data-o="pq"]', el).value = ''; q$('[data-o="pdd"]', el).innerHTML = ''; paintDraft(el); },
    'fd-route-del': t => { const el = t.closest('.overlay'); el._ch.route.splice(+t.dataset.i, 1); paintDraft(el); },
    'fd-up': t => { const el = t.closest('.overlay'); const i = +t.dataset.i; const r = el._ch.route; [r[i - 1], r[i]] = [r[i], r[i - 1]]; paintDraft(el); },
    'fd-shuffle': t => { const el = t.closest('.overlay'); const r = el._ch.route; for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } paintDraft(el); toast('Kram badal diya — roz alag kram se koi pattern nahi pakad payega'); },
    'fd-scan-items': t => scanItems(t.closest('.overlay')), 'fd-draft': t => saveDraft(t.closest('.overlay')),
    'fd-suggest': t => suggest(t.closest('.overlay')), 'fd-sug-add': t => sugAdd(t.closest('.overlay')), 'fd-photo': t => showPhoto(t.dataset.id), 'fd-codes': t => showCodes(t.dataset.id),
    'fd-ccode': t => codeConfirm(t.dataset.c, t.dataset.v), 'fd-bill': t => billNow(t.dataset.c, t.dataset.v), 'fd-score-d': t => { ui.fdScoreD = +t.dataset.d; renderView(true); },
    'fd-accept': t => accept(t.dataset.id), 'fd-start': t => startVisit(t.dataset.c, t.dataset.p), 'fd-visit': t => visitScreen(t.dataset.c, t.dataset.v),
    'fd-entry': t => stepEntry(t.dataset.c, t.dataset.v), 'fd-override': t => override(t.dataset.c, t.dataset.v, 1), 'fd-override2': t => override(t.dataset.c, t.dataset.v, 2),
    'fd-pick': t => stepPick(t.dataset.c, t.dataset.v), 'fd-mode': t => setMode(t), 'fd-link': t => sendLink(t.dataset.c, t.dataset.v), 'fd-sign': t => signPad(t.dataset.c, t.dataset.v),
    'fd-sel-done': t => selDone(t.dataset.c, t.dataset.v), 'fd-exit': t => stepExit(t.dataset.c, t.dataset.v), 'fd-seal': t => stepSeal(t.dataset.c, t.dataset.v),
    'fd-panic': t => panic(t.dataset.id || (t.closest('.overlay') || {}).dataset && t.closest('.overlay').dataset.c), 'fd-ret': t => { const ov = t.closest('.overlay'); if (ov) closeModal(ov); receive(t.dataset.id); }, 'fd-waive': t => { const ov = t.closest('.overlay'); if (ov) closeModal(ov); waive(t.dataset.id); },
    'fd-parchi': t => { const c = chOf(t.dataset.id); if (c) parchi(c, t.dataset.k); }, 'go-field': () => { ui.fdTab = 'me'; location.hash = '#field'; }
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="fd-"],[data-act="go-field"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);
  // a confirm arriving from the retailer refreshes the open visit
  let lastConf = 0; setInterval(() => { const n = (S.fieldConfirms || []).length; if (n !== lastConf) { lastConf = n; const ov = q$('.fd-visit-ov'); if (ov && ov.dataset.c) visitScreen(ov.dataset.c, ov.dataset.v); } }, 1500);

  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    agentTools = function () { const L = T0.apply(this, arguments); if (!L.some(x => x.name === 'field_challans')) L.push({ name: 'field_challans', description: 'Field delivery challans (staff taking stock shop to shop): who is out, bag pieces / value, shops visited, entry / exit scan problems, panic, evening return shortfalls.', inputSchema: { type: 'object', properties: { onlyOpen: { type: 'boolean' } } },
      execute: async a => S.challans.filter(c => !(a && a.onlyOpen) || ['issued', 'out', 'returned'].includes(c.status)).slice(-30).map(c => ({ no: c.no, date: c.date, staff: c.staff, status: c.status, given: c.items.length, inBag: bag(c).length, value: c.value, shops: (c.visits || []).map(v => ({ party: v.party, picked: (v.sel || []).length, problems: [v.far && 'far ' + v.far + 'm', v.sealBad && 'seal', v.entry && v.entry.missing.length && 'entry missing ' + v.entry.missing.length, v.exit && v.exit.missing.length && 'exit missing ' + v.exit.missing.length].filter(Boolean) })), panic: (c.panic || []).length, short: c.ret ? c.ret.short : null })) });
      return L; };
    if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { return R0.apply(this, arguments) + '\nFIELD: field_challans for "kaun bahar hai / kitna maal bahar / kis dukaan par gadbad" questions. Screen "field".'; }; }
  }
  window.SJ_FIELD = { bag, chOf, openChallan, receive, newChallan, myActive, curVisit, dist, codeOk, credit, shopProfile };

  const st = document.createElement('style');
  st.textContent = `.fd-h{margin:14px 0 8px;font-size:13px;color:var(--gold)}.fd-route{display:flex;flex-direction:column;gap:6px;margin-bottom:8px}.fd-stop{display:flex;align-items:center;gap:10px;border:1px solid var(--line);border-radius:12px;padding:8px 10px}.fd-stop>div:nth-child(2){flex:1;min-width:0}.fd-stop.ok{opacity:.65}.fd-n{flex:none;display:grid;place-items:center;width:28px;height:28px;border-radius:50%;background:var(--gold-soft,rgba(212,175,55,.15));color:var(--gold);font-weight:800}
    .fd-add{position:relative;margin-bottom:8px}.fd-add input{width:100%}.fd-add .dd{position:static}
    .fd-sum,.fd-vk{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px;margin-bottom:10px}.fd-sum div,.fd-vk div{border:1px solid var(--line);border-radius:12px;padding:8px 10px;min-width:0}.fd-sum span,.fd-sum small,.fd-vk span,.fd-vk small{display:block;font-size:11.5px;color:var(--muted)}.fd-sum b,.fd-vk b{font-size:16px}
    .fd-items{display:flex;flex-wrap:wrap;gap:6px;max-height:160px;overflow:auto}.fd-chip{font-size:12px;border:1px solid var(--line);border-radius:10px;padding:3px 8px}
    .fd-steps{display:flex;gap:4px;list-style:none;padding:0;margin:0 0 12px}.fd-steps li{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:11.5px;color:var(--muted);text-align:center}.fd-steps i{display:grid;place-items:center;width:30px;height:30px;border-radius:50%;border:2px solid var(--line);font-style:normal;font-weight:800}.fd-steps li.on i{border-color:var(--gold);color:var(--gold)}.fd-steps li.on{color:var(--ink);font-weight:700}.fd-steps li.ok i{background:#16a34a;border-color:#16a34a;color:#fff}
    .fd-big{width:100%;padding:14px!important;font-size:15px!important;margin-top:8px}.fd-big.dis{opacity:.5}.fd-done{border:1px solid rgba(34,197,94,.45);background:rgba(34,197,94,.08);border-radius:12px;padding:10px 12px;font-size:13.5px;margin:6px 0}
    .fd-sel{display:flex;flex-direction:column;gap:6px;margin:8px 0}.fd-sr{display:flex;justify-content:space-between;align-items:center;gap:8px;border:1px solid var(--line);border-radius:10px;padding:6px 8px;font-size:13px;flex-wrap:wrap}.seg-mini{display:inline-flex;border:1px solid var(--line);border-radius:10px;overflow:hidden}.seg-mini button{border:0;background:transparent;color:var(--muted);padding:6px 10px;font:600 12px inherit;cursor:pointer}.seg-mini button.on{background:var(--gold);color:var(--gold-ink,#1b1206)}
    .fd-pad{width:100%;height:auto;aspect-ratio:5/2;background:#fff;border-radius:12px;touch-action:none;display:block}
    .fd-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));gap:12px}.fd-c{margin:0;cursor:pointer;display:flex;flex-direction:column;gap:6px;border-left:4px solid var(--line)}.fd-c.green{border-left-color:#22c55e}.fd-c.amber{border-left-color:#f59e0b}.fd-c.red{border-left-color:#ef4444}.fd-ch{display:flex;justify-content:space-between;align-items:center;gap:8px}.fd-mini{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:12px;color:var(--muted)}
    .fd-vrow{border:1px solid var(--line);border-radius:12px;padding:8px 10px;margin-bottom:6px;display:flex;flex-direction:column;gap:3px}.fd-vrow.bad{border-color:rgba(239,68,68,.55);background:rgba(239,68,68,.05)}
    .fd-me .fd-big{margin-bottom:10px}.fd-panic{display:flex;align-items:center;gap:10px;margin-top:12px;padding-top:10px;border-top:1px dashed var(--line)}.fd-parchi{display:block;max-width:100%;max-height:70vh;margin:0 auto;border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.35)}
    @media(max-width:560px){.fd-steps li{font-size:10px}.fd-steps i{width:26px;height:26px}}
    .fd-cam{position:relative;overflow:hidden}.fd-cam input{position:absolute;inset:0;opacity:0;cursor:pointer;width:100%}.fd-ph img{display:block;max-width:100%;max-height:50vh;margin:10px auto 0;border-radius:12px}
    .fd-thumbs{display:flex;gap:8px;flex-wrap:wrap;margin-top:4px}.fd-th{border:1px solid var(--line);border-radius:10px;padding:0;background:none;cursor:pointer;overflow:hidden;width:84px;color:var(--muted);font-size:11px}.fd-th img{display:block;width:84px;height:60px;object-fit:cover}
    .fd-billbox{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;border:1px solid var(--gold-line,rgba(212,175,55,.5));background:rgba(212,175,55,.07);border-radius:12px;padding:10px 12px;margin:0 0 10px;font-size:13.5px}
    .fd-codes{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}.fd-codes div{border:1px solid var(--line);border-radius:12px;padding:8px 10px;display:flex;flex-direction:column}.fd-codes b{font-size:18px;letter-spacing:2px}.fd-codes span,.fd-codes small{font-size:11px;color:var(--muted)}.fd-codes .used{opacity:.45;text-decoration:line-through}
    .fd-sug{margin:0 0 10px}.fd-sug .fd-sr{justify-content:flex-start;align-items:flex-start;margin:4px 0}.amber-t{color:#f59e0b}
    .fd-dash{display:flex;flex-direction:column;gap:2px;cursor:pointer;border-color:var(--gold-line,rgba(212,175,55,.5));padding:14px 16px}.fd-dash span{font-size:12.5px;color:var(--muted)}`;
  document.head.appendChild(st);
})();
