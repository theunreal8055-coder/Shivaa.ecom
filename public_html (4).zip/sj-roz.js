/* =====================================================================
   Shivaa Jewels — ROZ KI REPORT (daily report card) · v40
   One tap → a clean report image + WhatsApp text for any day:
   bikri, cash / UPI, sona-chandi, udhaar, kal ke kaam, stock, bhaav.
   • Dashboard card (Owner / Manager)      • "Close the day" card button
   • Gentle nudge: evening (aaj ki) / morning (kal ki) — once a day
   • Jarvis tool: daily_report
   Built on the software's own day-closing numbers (dayClosing) so the
   report always matches Accounts → Close the day.
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined' || typeof dayClosing !== 'function') return;
  const SITE = !!window.SJ_AI;
  const role = () => (window.SJ_USER || { role: 'owner' }).role || 'owner';
  const boss = () => !SITE || role() === 'owner' || role() === 'manager';
  const q$ = (s, r) => (r || document).querySelector(s);
  const LS = 'sj-roz';
  const lsGet = () => { try { return JSON.parse(localStorage.getItem(LS) || '{}') || {}; } catch (e) { return {}; } };
  const lsSet = o => { try { localStorage.setItem(LS, JSON.stringify(o)); } catch (e) { /* private mode */ } };
  const cfg = () => { const p = settings().pro || {}; return { phone: p.rozPhone || '', auto: p.rozAuto !== false, names: p.rozNames !== false }; };
  const dayName = d => new Date(d + 'T12:00:00').toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const kg = g => (num(g) >= 1000 ? (num(g) / 1000).toFixed(3) + ' kg' : num(g).toFixed(3) + ' g');

  /* ---------------- numbers ---------------- */
  function salesOn(d) { const c = dayClosing(d); return num((c.bills.sell_pakka || {}).value) + num((c.bills.sell_kacha || {}).value); }
  function data(d) {
    const s = settings(), c = dayClosing(d), b = k => c.bills[k] || { n: 0, value: 0 };
    const sales = b('sell_pakka').value + b('sell_kacha').value, bills = b('sell_pakka').n + b('sell_kacha').n;
    const buys = b('buy_pakka').value + b('buy_kacha').value, buyN = b('buy_pakka').n + b('buy_kacha').n;
    let avg = 0, nd = 0; for (let i = 1; i <= 7; i++) { const x = salesOn(addDays(d, -i)); avg += x; nd++; } avg = nd ? avg / nd : 0;
    const bankIn = sum(Object.values(c.byMode), r => r.in), bankOut = sum(Object.values(c.byMode), r => r.out);
    const exp = sum(S.expenses.filter(e => e.date === d), e => e.amount);
    const todaySales = S.invoices.filter(v => v.date === d && isSaleT(v.type) && !v.deleted);
    const newDue = sum(todaySales, v => Math.max(0, invDue(v)));
    const recv = sum(S.invoices.filter(v => !isBuy(v.type) && !v.deleted), v => Math.max(0, invDue(v)));
    const over = S.customers.map(cu => { const { over } = customerDues(cu); const due = sum(over, invDue); return due > 0.5 ? { name: cu.name, due, since: over.map(invDueDate).sort()[0] } : null; })
      .filter(Boolean).sort((a, b2) => b2.due - a.due);
    const nx = addDays(d, 1);
    const orders = (S.orders || []).filter(o => ORD_OPEN(o) && o.dueDate && o.dueDate <= nx).sort((a, b2) => String(a.dueDate).localeCompare(String(b2.dueDate)));
    const jobs = (S.jobs || []).filter(j => j.status === 'Issued' && j.dueDate && j.dueDate <= nx);
    const v = vaultSummary();
    const vis = (s.pro || {}).vision || {}; const vDate = vis.on === false ? '' : (vis.date || '2027-10-27');
    const left = vDate ? daysBetween(todayStr(), vDate) : null;
    return { d, firm: s.firm || 'Shivaa Jewels', c, sales, bills, buys, buyN, avg, bankIn, bankOut, exp, newDue, recv, over, orders, jobs, v,
      g24: num(s.gold24), s999: num(s.silver999), vis: vDate && left > 0 ? { title: !vis.title || /naya showroom/i.test(vis.title) ? "Shivaa's Showroom" : vis.title, left, date: vDate } : null,
      active: bills + buyN + c.ent.length > 0 };
  }
  const pct = r => (r.avg > 0 && r.sales > 0 ? Math.round((r.sales - r.avg) / r.avg * 100) : null);

  function text(r) {
    const c = r.c, p = pct(r), nm = cfg().names;
    const L = [`*${r.firm} — Roz ki report*`, `📅 ${dayName(r.d)}`, '',
      `💰 *Bikri: ${inr(r.sales)}* (${r.bills} bill)${p === null ? '' : ` · 7 din ki average se ${p >= 0 ? '▲' : '▼'} ${Math.abs(p)}%`}`,
      r.buyN ? `🛒 Kharid: ${inr(r.buys)} (${r.buyN} bill)` : '',
      `🟡 Sona bika: ${g3(c.gold.soldNet)} (fine ${g3(c.gold.soldFine)})${c.gold.oldIn > 0 ? ` · purana sona aaya ${g3(c.gold.oldIn)}` : ''}`,
      `⚪ Chandi biki: ${kg(c.silver.soldNet)}`, '',
      `💵 Cash aaya ${inr(c.cashIn)} · gaya ${inr(c.cashOut)}`, `🧾 Galle mein hona chahiye: *${inr(c.expected)}*`,
      r.bankIn || r.bankOut ? `🏦 UPI / Bank aaya ${inr(r.bankIn)}${r.bankOut ? ` · gaya ${inr(r.bankOut)}` : ''}` : '',
      r.exp ? `📤 Kharche: ${inr(r.exp)}` : '', '',
      `📒 Naya udhaar: ${inr(r.newDue)} · Kul baaki: *${inr(r.recv)}*`,
      ...(nm ? r.over.slice(0, 3).map((o, i) => `   ${i + 1}. ${o.name} — ${inr(o.due)} (due ${fmtD(o.since)})`) : []),
      r.orders.length || r.jobs.length ? '' : null,
      r.orders.length ? `📦 Kal tak dene wale order: ${r.orders.length}${nm ? ' — ' + r.orders.slice(0, 3).map(o => `${o.no}${o.partyName ? ' ' + o.partyName : ''}`).join(', ') : ''}` : '',
      r.jobs.length ? `🔨 Karigar se aane wala kaam: ${r.jobs.length}` : '', '',
      `📊 Stock: Sona ${g3(r.v.goldNet)} · Chandi ${kg(r.v.silverNet)}`,
      r.g24 || r.s999 ? `📈 Bhaav: Sona 24K ${r.g24 ? inr(r.g24) + '/10g' : '—'} · Chandi ${r.s999 ? inr(r.s999) + '/kg' : '—'}` : '',
      ...(c.warn.length ? ['', '⚠ ' + c.warn[0]] : []),
      r.vis ? `\n🏛️ ${r.vis.title} — ${r.vis.left} din baaki` : ''];
    return L.filter(x => x !== '' && x !== null).join('\n').replace(/\n{3,}/g, '\n\n');
  }

  /* ---------------- report image ---------------- */
  let fontsP = null;
  function fonts() {
    if (fontsP) return fontsP;
    const L = [['SJ Lora', 'fonts/Lora-Variable.ttf', { weight: '400 700' }], ['SJ Poppins', 'fonts/Poppins-Regular.ttf', { weight: '400' }], ['SJ Poppins', 'fonts/Poppins-Medium.ttf', { weight: '500' }], ['SJ Poppins', 'fonts/Poppins-Bold.ttf', { weight: '700' }]];
    fontsP = Promise.all(L.map(([f, u, d]) => { try { return new FontFace(f, `url(${u})`, d).load().then(x => { document.fonts.add(x); }).catch(() => null); } catch (e) { return null; } }));
    return Promise.race([fontsP, new Promise(r => setTimeout(r, 4000))]);
  }
  const SER = "'SJ Lora', Georgia, serif", SAN = "'SJ Poppins', 'Segoe UI', system-ui, sans-serif";
  const GOLD = '#e2bd62', INK = '#f7eed6', MUT = '#b7a682', GRN = '#56d68e', RED = '#ff8a7a', CARD = 'rgba(255,255,255,0.045)', LINE = 'rgba(226,189,98,0.28)';
  function rr(x, X, Y, w, h, r) { x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + w, Y, X + w, Y + h, r); x.arcTo(X + w, Y + h, X, Y + h, r); x.arcTo(X, Y + h, X, Y, r); x.arcTo(X, Y, X + w, Y, r); x.closePath(); }
  function T(x, s, X, Y, o) { o = o || {}; x.font = `${o.w || 400} ${o.z || 28}px ${o.f || SAN}`; x.fillStyle = o.c || INK; x.textAlign = o.a || 'left'; x.textBaseline = 'alphabetic';
    let z = o.z || 28; if (o.max) while (z > (o.min || 16) && x.measureText(s).width > o.max) { z--; x.font = `${o.w || 400} ${z}px ${o.f || SAN}`; }
    x.fillText(s, X, Y); return x.measureText(s).width; }
  function box(x, X, Y, w, h) { rr(x, X, Y, w, h, 22); x.fillStyle = CARD; x.fill(); x.lineWidth = 1.5; x.strokeStyle = LINE; x.stroke(); }
  function head(x, s, Y) { T(x, s.toUpperCase(), 64, Y, { w: 700, z: 22, c: GOLD }); x.fillStyle = LINE; x.fillRect(64 + x.measureText(s.toUpperCase()).width + 18, Y - 8, 1016 - 64 - x.measureText(s.toUpperCase()).width - 18, 1.5); }
  function tile(x, X, Y, w, h, label, val, sub, col) {
    box(x, X, Y, w, h); T(x, label, X + 24, Y + 42, { z: 22, c: MUT, max: w - 48 }); T(x, val, X + 24, Y + 92, { w: 700, z: 38, c: col || INK, max: w - 48, min: 22 });
    if (sub) T(x, sub, X + 24, Y + h - 22, { z: 20, c: MUT, max: w - 48, min: 14 });
  }
  async function draw(r) {
    await fonts();
    const W = 1080, cv = document.createElement('canvas'); cv.width = W; cv.height = 2600; const x = cv.getContext('2d');
    const c = r.c, p = pct(r), nm = cfg().names;
    // background
    const bg = x.createLinearGradient(0, 0, 0, 2600); bg.addColorStop(0, '#17110a'); bg.addColorStop(0.5, '#100c07'); bg.addColorStop(1, '#0b0805'); x.fillStyle = bg; x.fillRect(0, 0, W, 2600);
    const glow = x.createRadialGradient(W * 0.85, 0, 10, W * 0.85, 0, 700); glow.addColorStop(0, 'rgba(226,189,98,0.20)'); glow.addColorStop(1, 'rgba(226,189,98,0)'); x.fillStyle = glow; x.fillRect(0, 0, W, 800);
    // header
    T(x, r.firm, 64, 112, { w: 700, z: 56, f: SER, c: GOLD, max: 760 });
    T(x, 'Roz ki report', 64, 160, { w: 500, z: 28, c: INK });
    T(x, dayName(r.d), 64, 200, { z: 24, c: MUT, max: 700 });
    if (r.g24 || r.s999) { const t1 = r.g24 ? 'Sona 24K ' + inr(r.g24) + '/10g' : '', t2 = r.s999 ? 'Chandi ' + inr(r.s999) + '/kg' : '';
      [t1, t2].filter(Boolean).forEach((t, i) => { x.font = `500 20px ${SAN}`; const w = x.measureText(t).width + 32; rr(x, W - 64 - w, 70 + i * 50, w, 40, 20); x.fillStyle = 'rgba(226,189,98,0.12)'; x.fill(); x.strokeStyle = LINE; x.stroke(); T(x, t, W - 64 - w / 2, 97 + i * 50, { w: 500, z: 20, c: GOLD, a: 'center' }); }); }
    let y = 240;
    // hero: sales
    rr(x, 48, y, W - 96, 210, 28); const hg = x.createLinearGradient(48, y, W - 48, y + 210); hg.addColorStop(0, 'rgba(226,189,98,0.24)'); hg.addColorStop(1, 'rgba(226,189,98,0.06)'); x.fillStyle = hg; x.fill(); x.lineWidth = 2; x.strokeStyle = 'rgba(226,189,98,0.55)'; x.stroke();
    T(x, r.d === todayStr() ? 'Aaj ki bikri' : 'Din ki bikri', 84, y + 56, { z: 26, c: MUT });
    T(x, inr(r.sales), 84, y + 140, { w: 700, z: 84, f: SER, c: '#fff4d0', max: 620, min: 44 });
    T(x, `${r.bills} bill${r.bills === 1 ? '' : 's'}${r.buyN ? ` · kharid ${inr(r.buys)}` : ''}`, 84, y + 186, { z: 24, c: MUT, max: 600 });
    if (p !== null) { const up = p >= 0; T(x, `${up ? '▲' : '▼'} ${Math.abs(p)}%`, W - 84, y + 120, { w: 700, z: 48, c: up ? GRN : RED, a: 'right' }); T(x, '7 din ki average se', W - 84, y + 160, { z: 20, c: MUT, a: 'right' }); T(x, 'avg ' + compactInr(r.avg), W - 84, y + 188, { z: 20, c: MUT, a: 'right' }); }
    y += 250;
    // money
    head(x, 'Paisa', y); y += 24; const tw = (W - 96 - 24) / 2;
    tile(x, 48, y, tw, 150, 'Cash aaya', inr(c.cashIn), '', GRN); tile(x, 48 + tw + 24, y, tw, 150, 'Cash gaya', inr(c.cashOut), r.exp ? 'kharche ' + inr(r.exp) : '', RED); y += 174;
    tile(x, 48, y, tw, 150, 'Galle mein hona chahiye', inr(c.expected), 'opening ' + inr(c.opening)); tile(x, 48 + tw + 24, y, tw, 150, 'UPI / Bank aaya', inr(r.bankIn), r.bankOut ? 'gaya ' + inr(r.bankOut) : ''); y += 200;
    // metal
    head(x, 'Sona · Chandi', y); y += 24;
    tile(x, 48, y, tw, 150, 'Sona bika', g3(c.gold.soldNet), 'fine ' + g3(c.gold.soldFine) + (c.gold.oldIn > 0 ? ' · purana aaya ' + g3(c.gold.oldIn) : ''), GOLD);
    tile(x, 48 + tw + 24, y, tw, 150, 'Chandi biki', kg(c.silver.soldNet), c.silver.boughtNet > 0 ? 'kharidi ' + kg(c.silver.boughtNet) : '', '#e6e9ef'); y += 200;
    // udhaar
    head(x, 'Udhaar', y); y += 24;
    const ov = nm ? r.over.slice(0, 3) : []; const uh = 130 + (ov.length ? 44 + ov.length * 44 : 0);
    box(x, 48, y, W - 96, uh);
    T(x, r.d === todayStr() ? 'Aaj naya udhaar' : 'Us din naya udhaar', 84, y + 46, { z: 22, c: MUT }); T(x, inr(r.newDue), 84, y + 96, { w: 700, z: 38 });
    T(x, 'Kul baaki (sab grahak)', W - 84, y + 46, { z: 22, c: MUT, a: 'right' }); T(x, inr(r.recv), W - 84, y + 96, { w: 700, z: 38, c: GOLD, a: 'right' });
    if (ov.length) { let yy = y + 150; T(x, 'Sabse purana baaki:', 84, yy, { w: 500, z: 20, c: MUT }); yy += 40;
      ov.forEach((o, i) => { T(x, `${i + 1}. ${o.name}`, 84, yy, { z: 24, max: 560 }); T(x, inr(o.due), W - 84, yy, { w: 700, z: 24, c: RED, a: 'right' }); T(x, 'due ' + fmtD(o.since), W - 300, yy, { z: 18, c: MUT, a: 'right' }); yy += 44; }); }
    y += uh + 50;
    // tomorrow
    if (r.orders.length || r.jobs.length) {
      head(x, 'Kal ke kaam', y); y += 24;
      const lines = [...r.orders.slice(0, 3).map(o => `📦 ${o.no}${nm && o.partyName ? ' · ' + o.partyName : ''}${o.category ? ' · ' + o.category : ''}  (${fmtD(o.dueDate)})`), r.orders.length > 3 ? `   + ${r.orders.length - 3} aur order` : '', r.jobs.length ? `🔨 Karigar se ${r.jobs.length} kaam aana hai` : ''].filter(Boolean);
      const h = 36 + lines.length * 46; box(x, 48, y, W - 96, h); lines.forEach((l, i) => T(x, l, 84, y + 58 + i * 46, { z: 24, max: W - 168 })); y += h + 50;
    }
    // stock
    head(x, 'Stock (dukaan mein)', y); y += 24; const t3 = (W - 96 - 48) / 3;
    tile(x, 48, y, t3, 140, 'Sona', g3(r.v.goldNet), r.v.goldPcs + ' pcs', GOLD); tile(x, 48 + t3 + 24, y, t3, 140, 'Chandi', kg(r.v.silverNet), r.v.silverPcs + ' pcs'); tile(x, 48 + (t3 + 24) * 2, y, t3, 140, 'Keemat', compactInr(r.v.value), 'aaj ke bhaav se'); y += 180;
    if (c.warn.length) { const ls = []; x.font = `400 21px ${SAN}`; let line = ''; ('⚠ ' + c.warn[0]).split(' ').forEach(wd => { const t = line ? line + ' ' + wd : wd; if (x.measureText(t).width > W - 168) { ls.push(line); line = wd; } else line = t; }); if (line) ls.push(line);
      const h = 30 + ls.length * 32; rr(x, 48, y, W - 96, h, 18); x.fillStyle = 'rgba(255,138,122,0.12)'; x.fill(); ls.forEach((l, i) => T(x, l, 72, y + 44 + i * 32, { z: 21, c: RED })); y += h + 30; }
    // footer
    y += 10; x.fillStyle = LINE; x.fillRect(64, y, W - 128, 1.5); y += 56;
    if (r.vis) { T(x, `🏛️ ${r.vis.title}`, 64, y, { w: 700, z: 28, f: SER, c: GOLD, max: 700 }); T(x, `${r.vis.left} din baaki`, W - 64, y, { w: 700, z: 28, c: GOLD, a: 'right' }); y += 40; }
    T(x, 'Shivaa Jewels software · ' + new Date().toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }), 64, y, { z: 18, c: MUT }); y += 40;
    const out = document.createElement('canvas'); out.width = W; out.height = Math.min(2600, y); out.getContext('2d').drawImage(cv, 0, 0);
    return out;
  }
  const toBlob = cv => new Promise(res => cv.toBlob(b => res(b), 'image/png'));

  /* ---------------- modal ---------------- */
  let cur = null;   // {d, r, blob, url}
  async function open(d) {
    if (typeof notReady === 'function' && notReady()) return;
    d = d || todayStr();
    const k = cfg();
    const ov = openModal(`${mHead('📊 Roz ki report', 'Bikri, paisa, sona-chandi, udhaar — ek nazar mein')}<div class="m-body">
      <div class="roz-bar"><input type="date" class="roz-date" value="${esc(d)}" max="${esc(todayStr())}" aria-label="Report ki tareekh"><button type="button" class="btn sm" data-act="roz-day" data-d="${esc(todayStr())}">Aaj</button><button type="button" class="btn sm" data-act="roz-day" data-d="${esc(addDays(todayStr(), -1))}">Kal</button></div>
      <div class="roz-prev"><div class="roz-wait">Report ban rahi hai…</div></div>
      ${boss() ? `<details class="roz-set"><summary>⚙ WhatsApp number &amp; yaad dilana</summary><div class="fg" style="margin-top:10px">
        <label class="f"><span>Report kis WhatsApp number par</span><input class="roz-ph" inputmode="tel" maxlength="14" placeholder="10 ank — jaise 98xxxxxx10" value="${esc(k.phone)}"></label>
        <label class="chk"><input type="checkbox" class="roz-auto" ${k.auto ? 'checked' : ''}> Shaam ko (aaj ki) aur subah (kal ki) yaad dilao</label>
        <label class="chk"><input type="checkbox" class="roz-names" ${k.names ? 'checked' : ''}> Udhaar / order mein grahak ke naam dikhao</label>
        <div class="btns"><button type="button" class="btn sm gold" data-act="roz-save">Save</button></div></div></details>` : ''}
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><button type="button" class="btn" data-act="roz-copy">Text copy</button><button type="button" class="btn" data-act="roz-dl">Image save</button><button type="button" class="btn green" data-act="roz-send">WhatsApp par bhejo</button></div>`, { wide: true });
    ov.classList.add('roz-ov');
    await build(ov, d);
  }
  async function build(ov, d) {
    const pv = q$('.roz-prev', ov); if (!pv) return;
    pv.innerHTML = '<div class="roz-wait">Report ban rahi hai…</div>';
    try {
      const r = data(d); const cv = await draw(r); const blob = await toBlob(cv);
      if (cur && cur.url) URL.revokeObjectURL(cur.url);
      cur = { d, r, blob, url: URL.createObjectURL(blob) };
      pv.innerHTML = `<img src="${cur.url}" alt="Roz ki report — ${esc(fmtD(d))}">${r.active ? '' : '<div class="roz-note">Is din koi bill ya len-den nahi mila.</div>'}`;
    } catch (e) { console.error(e); pv.innerHTML = '<div class="roz-wait">Report nahi ban payi — dobara try kijiye.</div>'; }
  }
  function markSent(d) { const o = lsGet(); o.sent = o.sent || {}; o.sent[d] = Date.now(); const keys = Object.keys(o.sent).sort(); while (keys.length > 40) delete o.sent[keys.shift()]; lsSet(o); hideNudge(); }
  async function send() {
    if (!cur) return;
    const t = text(cur.r), name = `roz-report-${cur.d}.png`;
    try {
      const file = new File([cur.blob], name, { type: 'image/png' });
      if (navigator.canShare && navigator.canShare({ files: [file] })) {
        try { await navigator.share({ files: [file], text: t, title: 'Roz ki report' }); markSent(cur.d); return; }
        catch (e) { if (e && e.name === 'AbortError') return; }
      }
    } catch (e) { /* File not supported → fallback */ }
    saveImg();
    const ph = cfg().phone; const url = (ph && typeof waUrl === 'function' && waUrl(ph, t)) || 'https://wa.me/?text=' + encodeURIComponent(t);
    window.open(url, '_blank', 'noopener');
    toast('Image save ho gayi — WhatsApp mein text ke saath image bhi attach kar dijiye');
    markSent(cur.d);
  }
  function saveImg() { if (!cur) return; const a = document.createElement('a'); a.href = cur.url; a.download = `roz-report-${cur.d}.png`; document.body.appendChild(a); a.click(); a.remove(); }
  async function copy() {
    if (!cur) return; const t = text(cur.r);
    try { await navigator.clipboard.writeText(t); toast('Text copy ho gaya'); }
    catch (e) { const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); toast('Text copy ho gaya'); } catch (e2) { toast('Copy nahi hua', 'err'); } ta.remove(); }
  }
  async function saveCfg(ov) {
    const ph = cleanPhone(q$('.roz-ph', ov).value);
    if (ph && ph.length !== 10) return toast('WhatsApp number 10 ank ka daaliye', 'err');
    const pro = { ...((S.settings || {}).pro || {}), rozPhone: ph, rozAuto: q$('.roz-auto', ov).checked, rozNames: q$('.roz-names', ov).checked };
    if (await saveSettings({ ...S.settings, pro })) { toast('✓ Report settings save'); if (cur) build(ov, cur.d); }
  }

  /* ---------------- gentle nudge (once a day) ---------------- */
  let nudgeEl = null;
  function hideNudge() { if (nudgeEl) { nudgeEl.remove(); nudgeEl = null; } }
  function nudge() {
    try {
      if (!boss() || !cfg().auto || nudgeEl || document.querySelector('#modal-root .overlay')) return;
      if (typeof MODE !== 'undefined' && MODE === 'connecting') return;
      const t = todayStr(), h = new Date().getHours(), o = lsGet(); o.sent = o.sent || {};
      let d = null, msg = '';
      if (h >= 19 && !o.sent[t] && o.nudged !== t + 'e') { d = t; msg = 'Aaj ki din-band report taiyaar hai'; o.nudged = t + 'e'; }
      else if (h >= 8 && h < 12 && o.nudged !== t + 'm' && o.nudged !== t + 'e') { const y = addDays(t, -1); if (!o.sent[y]) { d = y; msg = 'Kal ki report dekh lijiye'; o.nudged = t + 'm'; } }
      if (!d || !data(d).active) return;
      lsSet(o);
      nudgeEl = document.createElement('div'); nudgeEl.className = 'roz-nudge'; nudgeEl.setAttribute('role', 'status');
      nudgeEl.innerHTML = `<b>📊 ${esc(msg)}</b><span>${esc(dayName(d))}</span><div><button type="button" class="btn sm gold" data-act="roz-open" data-d="${esc(d)}">Dekho &amp; bhejo</button><button type="button" class="btn sm" data-act="roz-later">Baad mein</button></div>`;
      document.body.appendChild(nudgeEl);
    } catch (e) { console.error(e); }
  }
  setTimeout(nudge, 9000); setInterval(nudge, 10 * 60 * 1000);

  /* ---------------- clicks ---------------- */
  const ACT = {
    'roz-open': b => { hideNudge(); open(b.dataset.d); },
    'roz-day': b => { const ov = b.closest('.overlay'); const i = q$('.roz-date', ov); i.value = b.dataset.d; build(ov, b.dataset.d); },
    'roz-send': () => send(), 'roz-dl': () => saveImg(), 'roz-copy': () => copy(),
    'roz-save': b => saveCfg(b.closest('.overlay')),
    'roz-later': () => hideNudge()
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="roz-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);
  document.addEventListener('change', e => { const i = e.target; if (!i.classList || !i.classList.contains('roz-date')) return; e.stopPropagation(); if (/^\d{4}-\d{2}-\d{2}$/.test(i.value)) build(i.closest('.overlay'), i.value > todayStr() ? todayStr() : i.value); }, true);

  /* ---------------- where it shows ---------------- */
  { const D = VIEWDEF.dashboard; if (D && D.body) VIEWDEF.dashboard = { ...D, body() { let x = ''; try { if (boss()) { const t = todayStr(), r = data(t); x = `<div class="card roz-dash"><div class="roz-dl"><b>📊 Roz ki report</b><span>Aaj ${esc(inr(r.sales))} · ${r.bills} bill · galle mein ${esc(inr(r.c.expected))}</span></div><div class="btns"><button type="button" class="btn sm gold" data-act="roz-open" data-d="${esc(t)}">Aaj ki</button><button type="button" class="btn sm" data-act="roz-open" data-d="${esc(addDays(t, -1))}">Kal ki</button></div></div>`; } } catch (e) { console.error(e); } return x + D.body.apply(D, arguments); } }; }
  if (typeof closingBody === 'function') { const CB = closingBody; closingBody = function () { const h = CB.apply(this, arguments); try { if (!boss()) return h; const d = typeof clDate === 'function' ? clDate() : todayStr(); return h.replace('<button class="btn sm" data-act="cl-pdf">', `<button class="btn sm gold" data-act="roz-open" data-d="${esc(d)}">📊 Report card</button><button class="btn sm" data-act="cl-pdf">`); } catch (e) { return h; } }; }

  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    agentTools = function () {
      const L = T0.apply(this, arguments);
      if (!L.some(x => x.name === 'daily_report')) L.push({ name: 'daily_report', description: 'Roz ki report for one day: sales (bills, ₹, vs 7-day average), purchases, cash in/out, expected cash in drawer, UPI/bank, gold/silver sold, new udhaar, total receivable, oldest dues, orders / karigar jobs due by next day, stock, rates. Use for "aaj kaisa raha", "kal ki report", "din band", "galle mein kitna hona chahiye".', inputSchema: { type: 'object', properties: { date: { type: 'string', description: 'YYYY-MM-DD (default today)' } } },
        execute: async a => { const d = a && /^\d{4}-\d{2}-\d{2}$/.test(a.date || '') ? a.date : todayStr(); const r = data(d); return { date: d, text: text(r), sales: Math.round(r.sales), bills: r.bills, avg7: Math.round(r.avg), cashIn: r.c.cashIn, cashOut: r.c.cashOut, expectedCash: r.c.expected, upiBankIn: r2(r.bankIn), newUdhaar: Math.round(r.newDue), receivable: Math.round(r.recv), screen: 'Dashboard → Roz ki report (image + WhatsApp)' }; } });
      return L;
    };
    if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { return R0.apply(this, arguments) + '\nROZ KI REPORT: daily_report for any "aaj / kal kaisa raha", "din band", "report bhejo" question; tell the owner the image + WhatsApp button is on the Dashboard ("Roz ki report").'; }; }
  }
  window.SJ_ROZ = { open, data, text, draw, nudge };

  const st = document.createElement('style');
  st.textContent = `.roz-dash{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;padding:14px 16px}.roz-dl{display:flex;flex-direction:column;gap:2px;min-width:0}.roz-dl span{font-size:12.5px;color:var(--muted)}.roz-dash .btns{margin:0}
    .roz-bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px}.roz-bar input{max-width:180px}
    .roz-prev{display:flex;flex-direction:column;align-items:center;gap:8px;background:#0b0805;border:1px solid var(--line);border-radius:16px;padding:12px;min-height:220px;justify-content:center}
    .roz-prev img{display:block;max-width:100%;max-height:68vh;width:auto;height:auto;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.45)}.roz-wait,.roz-note{color:var(--muted);font-size:13px}
    .roz-set{margin-top:12px;border:1px solid var(--line);border-radius:14px;padding:10px 12px}.roz-set summary{cursor:pointer;font-weight:700;font-size:13px}
    .roz-ov .m-foot{flex-wrap:wrap}
    .roz-nudge{position:fixed;right:16px;bottom:calc(96px + env(safe-area-inset-bottom));z-index:90;max-width:340px;background:var(--card,#16110a);color:var(--ink);border:1px solid var(--gold-line,rgba(226,189,98,.45));border-radius:18px;padding:14px 16px;box-shadow:0 14px 34px rgba(0,0,0,.45);display:flex;flex-direction:column;gap:4px;animation:rozIn .35s ease both}
    .roz-nudge span{font-size:12.5px;color:var(--muted)}.roz-nudge div{display:flex;gap:8px;margin-top:8px}@keyframes rozIn{from{opacity:0;transform:translateY(16px)}}
    @media(max-width:640px){.roz-nudge{left:12px;right:12px;max-width:none;bottom:calc(76px + env(safe-area-inset-bottom))}}
    html.sj-offline .roz-nudge,body:has(#modal-root .overlay) .roz-nudge{display:none}`;
  document.head.appendChild(st);
})();
