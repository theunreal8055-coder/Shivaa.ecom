/* =====================================================================
   Shivaa Jewels — 3 FLOORS · v41
   • Har device / login ka floor (Ground · Silver, 1st · Gold, 2nd · Wedding
     Planner — names editable). Har naya bill aur naya stock piece apne aap
     us floor ka maana jata hai (bill par floor + counter likha jata hai).
   • Floor transfer parchi: bhejne wala scan karke bhejta hai, lene wala
     floor scan karke leta hai — kam mila to server alert.
   • Floor ka stock milaan (RFID / QR + kaanta) — kam mila to alert.
   • Floor-wise bikri, stock aur raaste mein maal.
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { role: 'owner', name: 'Owner' };
  const boss = () => !SITE || ['owner', 'manager'].includes(me().role);
  const q$ = (s, r) => (r || document).querySelector(s);
  ['floorTx', 'audits'].forEach(c => { if (!COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const DEF = [{ id: 'G', name: 'Ground · Silver' }, { id: '1', name: '1st · Gold' }, { id: '2', name: '2nd · Wedding Planner' }];
  const list = () => { const f = (settings().pro || {}).floors; return Array.isArray(f) && f.length ? f : DEF; };
  const fName = id => (list().find(f => f.id === id) || {}).name || (id ? 'Floor ' + id : '—');
  const fixed = () => (window.SJ_SEC && SJ_SEC.me && SJ_SEC.me.floor) || '';
  function cur() { const f = fixed(); if (f) return f; try { return localStorage.getItem('sj-floor') || ''; } catch (e) { return ''; } }
  const counter = () => { try { return localStorage.getItem('sj-counter') || ''; } catch (e) { return ''; } };
  const inStock = p => p.status === 'In Stock' && !p.custody && !p.floorTx;
  const fStock = (f, all) => S.products.filter(p => (all ? p.status === 'In Stock' || p.status === 'On Approval' : inStock(p)) && (p.floor || '') === f);

  /* new bills and new stock pieces carry this device's floor */
  if (typeof save === 'function') {
    const SV = save;
    save = function (col, obj, o) {
      try {
        const f = cur();
        if (f && obj && !obj.floor) {
          if (col === 'invoices' && !(rawOf('invoices') || []).some(x => x.id === obj.id)) obj = { ...obj, floor: f, counter: counter() || undefined, byName: me().name };
          else if (col === 'products' && !(rawOf('products') || []).some(x => x.id === obj.id)) obj = { ...obj, floor: f };
        }
      } catch (e) { console.error(e); }
      return SV.call(this, col, obj, o);
    };
  }

  /* header chip: which floor is this device */
  let chip = null;
  function paintChip() {
    if (!chip) { chip = document.createElement('button'); chip.type = 'button'; chip.className = 'fl-chip'; chip.dataset.act = 'fl-pick'; document.body.appendChild(chip); }
    const f = cur(); chip.innerHTML = `🏬 <b>${esc(f ? fName(f) : 'Floor chuniye')}</b>${fixed() ? ' 🔒' : ''}`; chip.classList.toggle('need', !f);
    chip.style.display = (window.SJ_USER || !SITE) && document.body.classList.contains('fl-show') ? 'flex' : 'none';
  }
  function pickFloor() {
    if (fixed()) return toast('Aapka floor Owner ne tay kiya hai: ' + fName(fixed()));
    const el = openModal(`${mHead('🏬 Ye device kis floor par hai?', 'Is device se bane bill aur naya stock is floor ke maane jayenge')}<div class="m-body"><div class="fl-pick">${list().map(f => `<button type="button" class="fl-opt ${cur() === f.id ? 'on' : ''}" data-act="fl-set" data-id="${esc(f.id)}"><b>${esc(f.name)}</b></button>`).join('')}</div>
      <label class="f" style="margin-top:12px"><span>Counter ka naam (optional)</span><input class="fl-ctr" value="${esc(counter())}" placeholder="jaise Counter 2"></label></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`);
    q$('.fl-ctr', el).addEventListener('change', e => { try { localStorage.setItem('sj-counter', e.target.value.trim().slice(0, 30)); } catch (er) { /* */ } });
  }

  /* ---------------- floor transfer ---------------- */
  async function newTransfer() {
    const from = cur(); if (!from) { pickFloor(); return toast('Pehle is device ka floor chuniye', 'err'); }
    const to = await choose('Kis floor ko bhejna hai?', list().filter(f => f.id !== from)); if (!to) return;
    const pool = fStock(from).map(p => p.id);
    const r = await SJ_SCAN.session({ title: `Floor transfer: ${fName(from)} → ${fName(to)}`, sub: 'Bhejne wale piece scan kijiye', pool, poolWhy: 'Is floor ke stock mein nahi (ya bika / bahar hai)', weight: true, doneLabel: 'Bhejo' });
    if (!r || !r.seen.length) return;
    const items = r.seen.map(id => { const p = S.products.find(x => x.id === id); return { id, sku: p.sku, name: (p.category || '') + ' ' + (p.purity || ''), gross: num(p.gross), net: num(p.net) }; });
    const tx = { id: uid('ft'), no: nextNo('floorTx', 'FT-'), date: todayStr(), from, to, items, gross: r3(sum(items, i => i.gross)), weight: r.weight, status: 'sent', sentBy: me().name, sentAt: Date.now(), createdAt: Date.now() };
    if (!await save('floorTx', tx)) return;
    for (const it of items) { const p = S.products.find(x => x.id === it.id); if (p) await save('products', { ...p, floorTx: tx.no, updatedAt: Date.now() }, { quiet: true }); }
    toast(`✓ ${tx.no}: ${items.length} piece ${fName(to)} ko bheje`); renderView(true);
  }
  async function receive(id) {
    const tx = S.floorTx.find(x => x.id === id); if (!tx || tx.status !== 'sent') return;
    if (SITE && cur() !== tx.to && !boss()) return toast('Ye maal ' + fName(tx.to) + ' wale lenge', 'err');
    const r = await SJ_SCAN.session({ title: `Maal lo: ${tx.no} (${fName(tx.from)} se)`, expected: tx.items.map(i => i.id), weight: true, doneLabel: 'Maal mil gaya' });
    if (!r) return;
    const got = new Set(r.seen); const missing = tx.items.filter(i => !got.has(i.id));
    const nt = { ...tx, status: 'received', recBy: me().name, recAt: Date.now(), recWeight: r.weight, wDiff: r.wDiff, missing: missing.map(i => i.id), short: missing.length, updatedAt: Date.now() };
    if (!await save('floorTx', nt)) return;
    for (const it of tx.items) { const p = S.products.find(x => x.id === it.id); if (!p) continue; const q = { ...p, updatedAt: Date.now() }; delete q.floorTx; if (got.has(it.id)) q.floor = tx.to; else q.floorTx = tx.no + ' (KAM)'; await save('products', q, { quiet: true }); }
    toast(missing.length ? `⚠ ${missing.length} piece kam mile — Owner ko alert gaya` : `✓ ${tx.no} ke saare piece mil gaye`, missing.length ? 'err' : undefined); renderView(true);
  }
  /* ---------------- floor stock tally ---------------- */
  async function tally(floor) {
    floor = floor || cur(); if (!floor) { pickFloor(); return; }
    const exp = fStock(floor).map(p => p.id); if (!exp.length) return toast('Is floor par koi stock piece nahi (pehle piece ka floor set kijiye)', 'err');
    const r = await SJ_SCAN.session({ title: 'Stock milaan · ' + fName(floor), expected: exp, weight: true, note: 'Bechne / bahar gaye piece is list mein nahi hain.' });
    if (!r) return;
    const a = { id: uid('au'), title: 'Floor ' + fName(floor), floor, date: todayStr(), at: Date.now(), by: me().name, expected: exp.length, seen: r.seen.length, missing: r.missing, extra: r.extra, weight: r.weight, wDiff: r.wDiff, createdAt: Date.now() };
    if (await save('audits', a)) toast(r.missing.length ? `⚠ ${r.missing.length} piece nahi mile — record ho gaya` : '✓ Floor ka poora stock mil gaya'); renderView(true);
  }
  async function setFloorBulk() {
    const to = await choose('Scan kiye piece kis floor ke hain?', list()); if (!to) return;
    const r = await SJ_SCAN.session({ title: 'Piece ka floor set karo → ' + fName(to), accept: p => p.status === 'Sold' ? 'Ye piece bik chuka' : null, doneLabel: 'Floor set karo' });
    if (!r || !r.seen.length) return; let n = 0;
    for (const id of r.seen) { const p = S.products.find(x => x.id === id); if (p && p.floor !== to && await save('products', { ...p, floor: to, updatedAt: Date.now() }, { quiet: true })) n++; }
    toast(`✓ ${n} piece ${fName(to)} par`); renderView(true);
  }
  function choose(title, opts) {
    return new Promise(res => { const el = openModal(`${mHead(esc(title), '')}<div class="m-body"><div class="fl-pick">${opts.map(f => `<button type="button" class="fl-opt" data-fl-c="${esc(f.id)}"><b>${esc(f.name)}</b></button>`).join('')}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button></div>`);
      let v = null; el.addEventListener('click', e => { const b = e.target.closest('[data-fl-c]'); if (b) { v = b.dataset.flC; closeModal(el); } });
      new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); res(v); } }).observe(q$('#modal-root'), { childList: true }); });
  }

  /* ---------------- view ---------------- */
  Object.assign(ICON, { floors: '<path d="M3 21h18M5 21V7l7-4 7 4v14"/><path d="M9 21v-4h6v4M9 9h6M9 13h6"/>' });
  if (!VIEWS.some(v => v[0] === 'floors')) { const i = VIEWS.findIndex(v => v[0] === 'vault' || v[0] === 'stock'); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, ['floors', 'Floors', 'floors', '3 Floors']); }
  VIEWDEF.floors = {
    shell: () => `<div class="rep-tabs">${[['live', '🏬 Teeno floor'], ['tx', '🔁 Transfer parchi'], ['tally', '📋 Stock milaan'], ['cfg', '⚙ Floor ke naam']].map(([k, l]) => `<button type="button" data-act="seg" data-k="flTab" data-v="${k}" class="${(ui.flTab || 'live') === k ? 'on' : ''}">${l}</button>`).join('')}</div>
      <div class="toolbar"><button type="button" class="btn" data-act="fl-pick">🏬 Ye device: <b>${esc(cur() ? fName(cur()) : 'chuniye')}</b></button><button type="button" class="btn gold" data-act="fl-tx">🔁 Doosre floor bhejo</button><button type="button" class="btn" data-act="fl-tally">📋 Is floor ka milaan</button>${boss() ? '<button type="button" class="btn" data-act="fl-bulk">🏷 Piece ka floor set karo</button><button type="button" class="btn" data-act="scn-bind">📶 RFID tag jodo</button>' : ''}</div><div id="vbody"></div>`,
    body() {
      const t = ui.flTab || 'live';
      if (t === 'cfg') return cfgBody();
      if (t === 'tx') return txBody();
      if (t === 'tally') return tallyBody();
      const day = todayStr(), mk = monthKey(day);
      const cards = list().map(f => {
        const st = fStock(f.id), ap = S.products.filter(p => p.floor === f.id && p.status === 'On Approval');
        const bills = S.invoices.filter(v => v.floor === f.id && isSaleT(v.type));
        const td = bills.filter(v => v.date === day), mo = bills.filter(v => monthKey(v.date) === mk);
        const inc = S.floorTx.filter(x => x.to === f.id && x.status === 'sent');
        const lastA = S.audits.filter(a => a.floor === f.id).sort((a, b) => b.at - a.at)[0];
        return `<div class="card fl-card ${cur() === f.id ? 'me' : ''}"><div class="card-h"><h3>${esc(f.name)}</h3>${cur() === f.id ? '<span class="pill gold">ye device</span>' : ''}</div>
          <div class="fl-k"><div><span>Aaj bikri</span><b>${inr(sum(td, invPayable))}</b><small>${td.length} bill</small></div><div><span>Is mahine</span><b>${compactInr(sum(mo, invPayable))}</b><small>${mo.length} bill</small></div><div><span>Stock</span><b>${st.length} pcs</b><small>${g3(sum(st, p => p.gross))}</small></div><div><span>Keemat</span><b>${compactInr(sum(st, prodValue))}</b><small>approval par ${ap.length}</small></div></div>
          ${inc.length ? `<div class="fl-inc">📥 ${inc.length} parchi aane wali: ${inc.map(x => `<button type="button" class="btn sm gold" data-act="fl-rec" data-id="${esc(x.id)}">${esc(x.no)} · ${x.items.length} pcs</button>`).join(' ')}</div>` : ''}
          <div class="small muted">Aakhri milaan: ${lastA ? `${esc(fmtD(lastA.date))} · ${lastA.missing.length ? '<b class="red">' + lastA.missing.length + ' kam</b>' : '<b class="green">sab mila</b>'} · ${esc(lastA.by || '')}` : 'abhi tak nahi'}</div></div>`;
      }).join('');
      const noF = S.products.filter(p => inStock(p) && !p.floor).length;
      const transit = S.floorTx.filter(x => x.status === 'sent');
      return `<div class="fl-grid">${cards}</div>${noF ? `<div class="warn-box small">${noF} stock piece kisi floor par set nahi hain — "🏷 Piece ka floor set karo" se scan karke set kijiye (naya stock apne aap device ke floor par aata hai).</div>` : ''}
        ${transit.length ? `<div class="card"><h3>🚚 Raaste mein (bheja, abhi liya nahi)</h3>${transit.map(x => `<div class="fl-row"><span><b>${esc(x.no)}</b> · ${esc(fName(x.from))} → ${esc(fName(x.to))} · ${x.items.length} pcs · ${g3(x.gross)}</span><span class="small muted">${esc(x.sentBy)} · ${esc(new Date(x.sentAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }))}</span></div>`).join('')}</div>` : ''}`;
    }
  };
  function txBody() {
    const L = S.floorTx.slice().sort((a, b) => b.createdAt - a.createdAt).slice(0, 200);
    if (!L.length) return emptyBox('Abhi koi floor transfer nahi. Ek floor se doosre floor maal bhejne ke liye "🔁 Doosre floor bhejo" dabaiye.');
    return `<div class="card"><div class="tw"><table class="tbl"><thead><tr><th>Parchi</th><th>Kahan se → kahan</th><th class="r">Piece</th><th class="r">Wazan</th><th>Bheja</th><th>Liya</th><th></th></tr></thead><tbody>${L.map(x => `<tr><td><b>${esc(x.no)}</b><div class="small muted">${esc(fmtD(x.date))}</div></td><td>${esc(fName(x.from))} → ${esc(fName(x.to))}</td><td class="r">${x.items.length}</td><td class="r">${g3(x.gross)}</td><td class="small">${esc(x.sentBy || '')}</td><td class="small">${x.status === 'received' ? esc(x.recBy || '') + (x.short ? ` <b class="red">${x.short} kam</b>` : ' ✓') : '<span class="pill gold">raaste mein</span>'}</td><td>${x.status === 'sent' ? `<button type="button" class="btn sm gold" data-act="fl-rec" data-id="${esc(x.id)}">Maal lo</button>` : ''}</td></tr>`).join('')}</tbody></table></div></div>`;
  }
  function tallyBody() {
    const L = S.audits.slice().sort((a, b) => b.at - a.at).slice(0, 200);
    return `<div class="btns" style="margin-bottom:12px">${list().map(f => `<button type="button" class="btn" data-act="fl-tally" data-f="${esc(f.id)}">📋 ${esc(f.name)} ka milaan</button>`).join('')}</div>` + (L.length ? `<div class="card"><div class="tw"><table class="tbl"><thead><tr><th>Kab</th><th>Kya</th><th class="r">Hona tha</th><th class="r">Mila</th><th class="r">Kam</th><th class="r">Wazan fark</th><th>Kisne</th></tr></thead><tbody>${L.map(a => `<tr><td>${esc(fmtD(a.date))}</td><td>${esc(a.title)}</td><td class="r">${a.expected}</td><td class="r">${a.seen}</td><td class="r">${a.missing.length ? `<b class="red">${a.missing.length}</b>` : '0'}</td><td class="r">${a.wDiff == null ? '—' : num(a.wDiff).toFixed(3) + ' g'}</td><td class="small">${esc(a.by || '')}</td></tr>${a.missing.length ? `<tr class="fl-miss"><td colspan="7" class="small">Nahi mile: ${a.missing.slice(0, 30).map(id => { const p = S.products.find(x => x.id === id); return p ? '#' + esc(p.sku) : '?'; }).join(', ')}</td></tr>` : ''}`).join('')}</tbody></table></div></div>` : emptyBox('Abhi tak koi milaan nahi hua.'));
  }
  function cfgBody() {
    if (!boss()) return emptyBox('Floor ke naam Owner / Manager badalte hain.');
    return `<form class="card" data-fl="cfg" novalidate><h3>Floor ke naam</h3><p class="small muted">Kram: neeche se upar. ID mat badaliye (purana data usi se juda hai).</p>${list().map((f, i) => `<div class="fg fl-cfg"><label class="f"><span>ID</span><input name="id${i}" value="${esc(f.id)}" maxlength="4" readonly></label><label class="f"><span>Naam</span><input name="n${i}" value="${esc(f.name)}" maxlength="40"></label></div>`).join('')}<div class="btns"><button class="btn gold">Save</button></div></form>`;
  }
  document.addEventListener('submit', async e => {
    const f = e.target.closest && e.target.closest('form[data-fl="cfg"]'); if (!f) return; e.preventDefault(); e.stopPropagation(); const d = formObj(f);
    const floors = list().map((x, i) => ({ id: x.id, name: String(d['n' + i] || x.name).trim().slice(0, 40) || x.name }));
    if (await saveSettings({ ...S.settings, pro: { ...((S.settings || {}).pro || {}), floors } })) { toast('✓ Floor ke naam save'); paintChip(); renderView(true); }
  }, true);

  const ACT = { 'fl-pick': () => pickFloor(), 'fl-set': t => { try { localStorage.setItem('sj-floor', t.dataset.id); } catch (e) { /* */ } closeModal(t.closest('.overlay')); paintChip(); toast('✓ Ye device: ' + fName(t.dataset.id)); renderView(true); },
    'fl-tx': () => newTransfer(), 'fl-rec': t => receive(t.dataset.id), 'fl-tally': t => tally(t.dataset.f), 'fl-bulk': () => setFloorBulk() };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="fl-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);
  // the chip shows on bill / stock screens only, so it never covers anything else
  setInterval(() => { const v = typeof view !== 'undefined' ? view : ''; document.body.classList.toggle('fl-show', ['dashboard', 'invoices', 'pakka', 'metal', 'vault', 'floors'].includes(v)); paintChip(); }, 1200);
  window.addEventListener('sj-sec', paintChip);
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    agentTools = function () { const L = T0.apply(this, arguments); if (!L.some(x => x.name === 'floors_summary')) L.push({ name: 'floors_summary', description: 'Floor-wise (3 floors) sales today / this month, stock pieces / weight / value, pending floor transfers, last stock tally result.', inputSchema: { type: 'object', properties: {} },
      execute: async () => { const d = todayStr(), mk = monthKey(d); return list().map(f => { const b = S.invoices.filter(v => v.floor === f.id && isSaleT(v.type)); const st = fStock(f.id); const la = S.audits.filter(a => a.floor === f.id).sort((x, y) => y.at - x.at)[0]; return { floor: f.name, todaySales: Math.round(sum(b.filter(v => v.date === d), invPayable)), monthSales: Math.round(sum(b.filter(v => monthKey(v.date) === mk), invPayable)), stockPcs: st.length, stockGross_g: r3(sum(st, p => p.gross)), incomingTransfers: S.floorTx.filter(x => x.to === f.id && x.status === 'sent').length, lastTally: la ? { date: la.date, missing: la.missing.length } : null }; }); } });
      return L; };
  }
  window.SJ_FLOORS = { list, name: fName, cur, stock: fStock, tally, inStock };

  const st = document.createElement('style');
  st.textContent = `.fl-chip{position:fixed;right:16px;bottom:calc(52px + env(safe-area-inset-bottom));z-index:94;display:none;align-items:center;gap:6px;padding:7px 12px;border-radius:999px;border:1px solid var(--line);background:var(--card);color:var(--ink);font:600 12px system-ui;box-shadow:0 6px 16px rgba(0,0,0,.3);cursor:pointer}.fl-chip.need{border-color:#f59e0b;color:#f59e0b}
    .fl-pick{display:grid;gap:8px}.fl-opt{display:block;text-align:left;padding:14px 16px;border-radius:14px;border:1px solid var(--line);background:var(--card2,transparent);color:var(--ink);font:inherit;cursor:pointer}.fl-opt.on{border-color:var(--gold);background:var(--gold-soft,rgba(212,175,55,.1))}
    .fl-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:14px;margin-bottom:14px}.fl-card{margin:0}.fl-card.me{border-color:var(--gold-line,rgba(212,175,55,.5))}
    .fl-k{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-bottom:10px}.fl-k div{border:1px solid var(--line);border-radius:12px;padding:8px 10px;min-width:0}.fl-k span,.fl-k small{display:block;font-size:11.5px;color:var(--muted)}.fl-k b{font-size:17px}
    .fl-inc{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-bottom:8px;font-size:13px}.fl-row{display:flex;justify-content:space-between;gap:10px;padding:8px 0;border-bottom:1px solid var(--line);font-size:13px;flex-wrap:wrap}.fl-cfg{grid-template-columns:90px 1fr!important}.fl-miss td{background:rgba(239,68,68,.06)}
    @media(max-width:640px){.fl-chip{bottom:calc(84px + env(safe-area-inset-bottom));right:12px}}`;
  document.head.appendChild(st);
})();
