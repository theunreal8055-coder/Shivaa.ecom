/* =====================================================================
   Shivaa Jewels — OFFLINE helpers (UI side) · v40
   The offline engine itself lives in sj-api.js (device copy + outbox).
   This file adds:
   • Setup card "Internet na ho tab bhi" — status, pending entries, wipe copy
   • Bill-number check: two devices billing offline can pick the same
     number. After entries reach the server, duplicates are shown to the
     Owner / Manager with a one-tap "naya number do" fix.
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const OFF = window.SJ_OFFLINE; if (!OFF) return;            // local / Claude mode: nothing to do
  const role = () => (window.SJ_USER || { role: 'owner' }).role || 'owner';
  const boss = () => role() === 'owner' || role() === 'manager';
  const q$ = (s, r) => (r || document).querySelector(s);

  /* ---------------- duplicate bill numbers ---------------- */
  function dups() {
    const g = new Map();
    (typeof rawOf === 'function' ? rawOf('invoices') : S.invoices).forEach(v => {
      if (!v || !v.no || v.deleted) return; const k = (v.firmId || 'main') + '|' + v.no; const a = g.get(k); if (a) a.push(v); else g.set(k, [v]);
    });
    const out = [];
    g.forEach(list => { if (list.length < 2) return; list.sort((a, b) => num(a.createdAt) - num(b.createdAt) || String(a.id).localeCompare(String(b.id))); out.push(list); });
    return out;
  }
  let shownFor = '';
  function check(force) {
    try {
      if (!boss() || (typeof MODE !== 'undefined' && MODE === 'connecting')) return;
      const D = dups(); if (!D.length) return;
      const sig = D.map(l => l.map(v => v.id).join(',')).join(';');
      if (!force && sig === shownFor) return;
      if (q$('.ofl-dup')) return;
      if (q$('#modal-root .overlay')) { setTimeout(() => check(force), 30000); return; }   // never on top of a bill being made
      shownFor = sig;
      const af = typeof activeFirm === 'function' ? activeFirm() : 'main';
      const rows = D.map(list => list.slice(1).map(v => `<div class="ofl-row"><div><b>${esc(v.no)}</b> · ${esc(v.partyName || '')} · ${esc(fmtD(v.date))} · ${esc(inr(v.totals && v.totals.grand))}<div class="small muted">Pehla ${esc(list[0].no)}: ${esc(list[0].partyName || '')} · ${esc(inr(list[0].totals && list[0].totals.grand))}</div></div>${(v.firmId || 'main') === af ? `<button type="button" class="btn sm gold" data-act="ofl-renum" data-id="${esc(v.id)}">Naya number do</button>` : '<span class="small muted">doosri firm — wahan jaa kar theek karein</span>'}</div>`).join('')).join('');
      const ov = openModal(`${mHead('⚠ Ek hi bill number do baar', 'Internet ke bina do jagah bill banne se aisa hota hai')}<div class="m-body"><p class="small" style="margin-top:0">GST ke hisaab se har bill ka number alag hona chahiye. Neeche wale (baad mein bane) bill ko naya number de dijiye. Agar ye bill grahak ko de diya gaya hai to unhe naya print bhi de dijiye.</p><div class="card ofl-dup" style="margin:0">${rows}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Baad mein</button></div>`, { wide: true });
      ov.classList.add('ofl-ov');
    } catch (e) { console.error(e); }
  }
  async function renum(b) {
    const v = (typeof rawOf === 'function' ? rawOf('invoices') : S.invoices).find(x => x.id === b.dataset.id); if (!v) return;
    const no = nextInvNo(v.type, v.date); if (!no || no === v.no) return toast('Naya number nahi mila', 'err');
    b.disabled = true; const ov = b.closest('.overlay');
    if (await save('invoices', { ...v, no, renumberedFrom: v.no, renumberedAt: Date.now() })) {
      toast(`✓ ${v.no} → ${no}`); const row = b.closest('.ofl-row'); if (row) row.innerHTML = `<div><b>${esc(no)}</b> · ${esc(v.partyName || '')} <span class="pill green">theek</span></div>`;
      shownFor = ''; if (!dups().length) setTimeout(() => { if (ov && ov.isConnected) closeModal(ov); }, 900);
    } else b.disabled = false;
  }
  window.addEventListener('sj-outbox-sent', () => setTimeout(() => check(true), 2500));
  setTimeout(() => check(false), 12000);

  /* ---------------- Setup card ---------------- */
  function card() {
    const n = OFF.pending(), on = OFF.on(), ok = OFF.ok();
    return `<div class="card" id="ofl-card"><div class="card-h"><h3>📴 Internet na ho tab bhi</h3><span class="pill ${!ok ? '' : on ? 'gold' : 'green'}">${!ok ? 'Is browser mein band' : on ? 'Abhi offline' : 'Online'}</span></div>
      <p class="small muted" style="margin-top:0">${ok ? 'Internet chala jaaye to bhi bill, rasid, stock entry chalti rahegi — entries is device par surakshit rehti hain aur net aate hi apne aap server par chali jaati hain. Software band karke dobara kholne par bhi data dikhega.' : 'Is browser mein offline copy nahi ban sakti (private / incognito mode?). Normal mode mein kholiye.'}</p>
      ${ok ? `<div class="ofl-st"><div><span>Server par jaana baaki</span><b>${n} entr${n === 1 ? 'y' : 'iyan'}</b></div><div><span>Bill number check</span><b>${dups().length ? dups().length + ' gadbad' : 'sab theek'}</b></div></div>
      <div class="btns"><button type="button" class="btn sm" data-act="ofl-check">Bill number check karo</button><button type="button" class="btn sm danger" data-act="ofl-wipe">Is device ki copy mitao</button></div>
      <p class="small muted" style="margin:10px 0 0">Do phone ek saath bina internet ke bill banayein to ek hi number aa sakta hai — software net aate hi bata dega. Logout karne par is device ki copy apne aap mit jaati hai.</p>` : ''}</div>`;
  }
  { const SU = VIEWDEF.setup; if (SU && SU.body) VIEWDEF.setup = { ...SU, body() { const h = SU.body.apply(SU, arguments); let x = ''; try { x = card(); } catch (e) { console.error(e); } return x + h; } }; }
  window.addEventListener('online', () => { const c = q$('#ofl-card'); if (c) c.outerHTML = card(); });

  const ACT = {
    'ofl-renum': b => renum(b),
    'ofl-check': () => { if (!dups().length) toast('✓ Koi bill number do baar nahi hai'); else check(true); },
    'ofl-wipe': () => {
      const n = OFF.pending();
      confirmBox(n ? `${n} entries abhi server par nahi gayi hain — copy mitane se ye kho jayengi. Pakka?` : 'Is device ki offline copy mitayein? (Server ka data surakshit rahega; agli baar internet se dobara aa jayega.)', async () => {
        try { await OFF.wipe(); toast('Copy mita di — page dobara khul raha hai'); setTimeout(() => location.reload(), 900); }
        catch (e) { toast('Copy nahi miti', 'err'); }
      });
    }
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="ofl-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);

  const st = document.createElement('style');
  st.textContent = `.ofl-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--line)}.ofl-row:last-child{border-bottom:0}.ofl-row>div{min-width:0}
    .ofl-st{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-bottom:10px}.ofl-st div{border:1px solid var(--line);border-radius:12px;padding:8px 10px}.ofl-st span{display:block;font-size:11.5px;color:var(--muted)}.ofl-st b{font-size:15px}
    @media(max-width:560px){.ofl-row{flex-direction:column;align-items:stretch}}`;
  document.head.appendChild(st);
})();
