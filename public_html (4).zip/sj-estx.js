/* =====================================================================
   Shivaa Jewels — "Signature" ORDER ESTIMATE (v27)
   Same look as the Signature bill: black-gold header, ivory page, gold frame,
   big design photos, weight ranges, delivery countdown, order journey,
   confirmation box with WhatsApp "CONFIRM" QR. A4 at 300/360 DPI.
   Uses the drawing kit from sj-billx.js and the numbers from sj-estimates.js.
   ===================================================================== */
(function () {
  'use strict';
  if (!window.SJ_BILLX || !SJ_BILLX.kit) return;
  const K = SJ_BILLX.kit; const { PX, PY, M, CW, SERIF, HIN, C, font, grad, rr, fit, T, wrap, jpeg, qrDraw, sheen, goldLogo, loadImg, shrink, DPI_K } = K;
  const HDR = 560, CONT = 250, BOTTOM = PY - 120;

  async function estimateSignaturePdf(e, o) {
    o = o || {};
    const H = (window.SJ_ESTIMATES || {}).help; if (!H) throw new Error('estimate helpers missing');
    await SJ_BILLX.loadFonts();
    const s = settings(); const buy = e.type === 'purchase';
    const firm = s.firm || 'Shivaa Jewels';
    const legal = typeof BILL_MAIN !== 'undefined' && BILL_MAIN && BILL_MAIN.name ? BILL_MAIN.name : (s.legal || firm);
    const own = typeof SJ_LOGO !== 'undefined';
    const logo = own ? await goldLogo(SJ_LOGO, 900) : await loadImg(s.logo);
    const items = (e.items || []).filter(it => it && (it.name || (it.photos || []).length));
    const pics = await Promise.all(items.map(it => Promise.all((it.photos || []).map(p => loadImg(p.src)))));
    const anyPhoto = pics.some(a => a.some(Boolean));
    const total = H.estTotal(e);
    // the cards already show purity, weights, totals and delivery — keep only what they don't say
    const notes = [...(items.some(it => (it.photos || []).length) ? ['Design as per reference photo'] : []), ...String(e.notes || '').split('\n').map(z => z.replace(/^[\s•\-*]+/, '').trim()).filter(Boolean)];
    const shopPh = String((typeof BILL_MAIN !== 'undefined' && BILL_MAIN && BILL_MAIN.phone) || s.phone || '').replace(/\D/g, '').slice(-10);
    const daysLeft = e.deliveryDate ? Math.round((parseD(e.deliveryDate) - parseD(todayStr())) / 86400000) : null;
    const revTxt = num(e.rev) > 1 ? 'REV ' + e.rev : '';

    /* ---------- measure blocks, then flow them onto pages ---------- */
    const meas = document.createElement('canvas').getContext('2d');
    const blocks = [];
    const TXT_W = CW - (anyPhoto ? 330 : 120) - 760;    // name/desc column width in an item card
    items.forEach((it, i) => {
      const dl = it.desc ? wrap(meas, it.desc, TXT_W, 400, 28).slice(0, 3) : [];
      const h = Math.max(anyPhoto ? 330 : 230, 150 + dl.length * 38 + 70);
      blocks.push({ kind: 'item', h: h + 22, draw: (x, y) => itemCard(x, y, it, i, h, dl) });
    });
    if (items.length > 1 && total) blocks.push({ kind: 'sum', h: 140, draw: (x, y) => sumBar(x, y) });
    // design gallery: every photo, large
    const gal = []; items.forEach((it, i) => pics[i].forEach((im, k) => { if (im) gal.push({ im, cap: `${i + 1}. ${it.name || 'Design'}${pics[i].length > 1 ? ' — ' + (k + 1) : ''}`, sub: [H.meltTxt(it), H.qtyTxt(it)].filter(Boolean).join(' · ') }); }));
    const noteLines = []; notes.forEach(n => wrap(meas, n, (gal.length === 1 ? CW - 1180 : CW) - 120, 400, 30).forEach((l, k) => noteLines.push([l, k === 0])));
    if (gal.length === 1) {
      const g = gal[0]; const iw = 1050, ih = Math.min(980, iw * g.im.naturalHeight / g.im.naturalWidth);
      blocks.push({ kind: 'gal1', h: Math.max(ih + 190, 150 + noteLines.length * 44 + 60), draw: (x, y) => { galleryTitle(x, y); photoCell(x, M, y + 80, iw, ih, g); if (noteLines.length) notesBox(x, M + 1130, y + 80, CW - 1130, noteLines); } });
    } else {
      if (gal.length) {
        blocks.push({ kind: 'galT', h: 80, draw: (x, y) => galleryTitle(x, y), keepNext: true });
        const per = gal.length === 2 || gal.length === 4 ? 2 : 3, cw = (CW - 50 * (per - 1)) / per;
        for (let i = 0; i < gal.length; i += per) {
          const row = gal.slice(i, i + per); const ch = Math.min(per === 2 ? 760 : 600, Math.max(...row.map(g => cw * g.im.naturalHeight / g.im.naturalWidth)));
          blocks.push({ kind: 'gal', h: ch + 130, draw: (x, y) => row.forEach((g, k) => photoCell(x, M + k * (cw + 50) + (CW - row.length * cw - (row.length - 1) * 50) / 2, y, cw, ch, g)) });
        }
      }
      if (noteLines.length) { const per = 26; for (let i = 0; i < noteLines.length; i += per) { const part = noteLines.slice(i, i + per); blocks.push({ kind: 'notes', h: 110 + part.length * 44 + 30, draw: (x, y) => notesBox(x, M, y, CW, part, i > 0) }); } }
    }
    if (!buy) blocks.push({ kind: 'journey', h: 300, draw: (x, y) => journey(x, y) });
    blocks.push({ kind: 'sign', h: 420, draw: (x, y) => signBox(x, y) });

    const TOP1 = HDR + 23 + 50 + 330 + 50, TOP2 = CONT + 40;
    const pages = [[]]; { let y = TOP1; blocks.forEach((b, bi) => { const need = b.h + (b.keepNext && blocks[bi + 1] ? blocks[bi + 1].h : 0); if (y + need > BOTTOM - 30 && pages[pages.length - 1].length) { pages.push([]); y = TOP2; } pages[pages.length - 1].push(b); y += b.h; }); }
    const nP = pages.length;

    const pdf = new Pdf(210, 297); pdf.pages.length = 0;
    for (let pi = 0; pi < nP; pi++) {
      const k = o.lite || o.preview ? 1 : DPI_K(); const cv = document.createElement('canvas'); cv.width = Math.round(PX * k); cv.height = Math.round(PY * k); const x = cv.getContext('2d'); x.scale(k, k); x.imageSmoothingQuality = 'high';
      x.fillStyle = C.ivory; x.fillRect(0, 0, PX, PY); frame(x, pi);
      let y = pi === 0 ? header(x) : contHeader(x, pi);
      if (pi === 0) y = infoCards(x, y + 50) + 50; else y = TOP2;
      pages[pi].forEach(b => { b.draw(x, y); y += b.h; });
      if (pi < nP - 1) T(x, 'Continued on next page …', PX - M, Math.min(y + 50, BOTTOM - 10), { align: 'right', size: 28, w: 500, color: C.goldT });
      bottomStrip(x, pi);
      if (o.preview) { o.pages = o.pages || []; o.pages.push(shrink(cv, 0.5).toDataURL('image/jpeg', 0.85)); continue; }
      pdf.addPage(); pdf.image(o.lite ? jpeg(shrink(cv, 0.5), 0.8) : jpeg(cv, 0.97), 0, 0, 210, 297);
    }
    if (o.preview) return null;
    return pdf.blob();

    /* ===================== sections ===================== */
    function grain(x) { const t = document.createElement('canvas'); t.width = 256; t.height = 256; const g = t.getContext('2d'); const im = g.createImageData(256, 256); for (let q = 0; q < im.data.length; q += 4) { const v = 120 + Math.random() * 120; im.data[q] = v; im.data[q + 1] = v * 0.94; im.data[q + 2] = v * 0.82; im.data[q + 3] = 10; } g.putImageData(im, 0, 0); x.save(); x.fillStyle = x.createPattern(t, 'repeat'); x.fillRect(0, 0, PX, PY); x.restore(); }
    function mandala(x, cx, cy, R) { x.save(); x.globalAlpha = 0.05; x.strokeStyle = '#a07a22'; x.fillStyle = '#a07a22'; x.lineWidth = 3; for (let ring = 0; ring < 5; ring++) { const r = R * (0.25 + ring * 0.18), n = 8 + ring * 8; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI * 2); x.stroke(); for (let q = 0; q < n; q++) { const a = q / n * Math.PI * 2; x.save(); x.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r); x.rotate(a); x.beginPath(); x.ellipse(0, 0, R * 0.075, R * 0.025, 0, 0, Math.PI * 2); x.stroke(); x.restore(); } } x.restore(); }
    function frame(x, pi) {
      grain(x); mandala(x, PX / 2, pi === 0 ? 1950 : 1600, 900);
      const top = (pi === 0 ? HDR : CONT) + 44, bot = PY - 92 - 22, l = 52, r = PX - 52;
      x.strokeStyle = '#d6b871'; x.lineWidth = 3; x.strokeRect(l, top, r - l, bot - top); x.strokeStyle = '#ead7a6'; x.lineWidth = 1.5; x.strokeRect(l + 12, top + 12, r - l - 24, bot - top - 24);
      [[l, top], [r, top], [l, bot], [r, bot]].forEach(([cx, cy]) => { x.save(); x.translate(cx, cy); x.rotate(Math.PI / 4); x.fillStyle = grad(x, -16, -16, 16, 16); x.fillRect(-15, -15, 30, 30); x.fillStyle = C.ivory; x.fillRect(-6, -6, 12, 12); x.restore(); });
    }
    function divider(x, yy) {
      x.fillStyle = grad(x, 0, 0, PX, 0); x.fillRect(0, yy, PX, 12); x.fillStyle = '#f6dc8c'; x.fillRect(0, yy + 18, PX, 3);
      const cx = PX / 2; x.save(); x.translate(cx, yy + 6); x.rotate(Math.PI / 4); x.fillStyle = '#0d0b07'; x.fillRect(-30, -30, 60, 60); x.fillStyle = grad(x, -24, -24, 24, 24); x.fillRect(-22, -22, 44, 44); x.fillStyle = '#0d0b07'; x.fillRect(-8, -8, 16, 16); x.restore();
    }
    function chip(x, txt, X, Y, o2) { o2 = o2 || {}; font(x, 700, o2.size || 24); const w = x.measureText(txt).width + (o2.pad || 50); rr(x, X - (o2.right ? w : 0), Y, w, o2.h || 52, (o2.h || 52) / 2); x.fillStyle = o2.bg || '#1f180c'; x.fill(); if (o2.stroke !== false) { x.lineWidth = 2.5; x.strokeStyle = o2.line || '#c9a046'; x.stroke(); } T(x, txt, X - (o2.right ? w : 0) + w / 2, Y + (o2.h || 52) / 2 + (o2.size || 24) * 0.36, { align: 'center', size: o2.size || 24, w: 700, color: o2.fg || '#f2d68a', ls: o2.ls == null ? 2 : o2.ls }); return w; }
    function header(x) {
      const g = x.createLinearGradient(0, 0, PX, HDR); g.addColorStop(0, '#07060a'); g.addColorStop(0.55, '#15100a'); g.addColorStop(1, '#2a1d0c'); x.fillStyle = g; x.fillRect(0, 0, PX, HDR);
      x.save(); x.globalAlpha = 0.07; x.strokeStyle = '#f2d68a'; x.lineWidth = 1.4; for (let q = -HDR; q < PX; q += 26) { x.beginPath(); x.moveTo(q, HDR); x.lineTo(q + HDR * 0.6, 0); x.stroke(); } x.restore();
      { const rg = x.createRadialGradient(M + 280, HDR / 2, 20, M + 280, HDR / 2, 420); rg.addColorStop(0, 'rgba(242,214,138,0.22)'); rg.addColorStop(1, 'rgba(242,214,138,0)'); x.fillStyle = rg; x.fillRect(0, 0, 900, HDR); }
      divider(x, HDR);
      let nx = M; if (logo) { const lw = 520, lh = Math.min(lw * logo.height / logo.width, 330); x.drawImage(logo, M, (HDR - lh) / 2, lw * (lh / (lw * logo.height / logo.width)), lh); nx = M + lw + 70; x.fillStyle = grad(x, 0, 110, 0, HDR - 110); x.fillRect(nx - 36, 110, 3, HDR - 220); }
      const rw = 760, lim = PX - M - rw - nx - 90;
      fit(x, legal, lim, 700, 72, SERIF, 46); x.textAlign = 'left'; x.save(); x.shadowColor = 'rgba(0,0,0,0.55)'; x.shadowBlur = 10; x.shadowOffsetY = 4; x.fillStyle = sheen(x, nx, 110, nx + lim * 0.7, 200); x.fillText(legal, nx, 180); x.restore();
      let yy = 180; const tag = (typeof BILL_MAIN !== 'undefined' && BILL_MAIN && BILL_MAIN.tagline) || s.tagline; if (tag) { yy += 58; T(x, String(tag).toUpperCase(), nx, yy, { size: 26, w: 500, color: '#e3d3a6', maxW: lim, ls: 4 }); }
      const addr = (typeof BILL_MAIN !== 'undefined' && BILL_MAIN && BILL_MAIN.address) || s.address || ''; wrap(x, addr, lim, 400, 28).slice(0, 2).forEach(l => { yy += 44; T(x, l, nx, yy, { size: 28, color: '#d8ccb0', maxW: lim }); });
      const ph = (typeof BILL_MAIN !== 'undefined' && BILL_MAIN && BILL_MAIN.phone) || s.phone; if (ph) { yy += 46; T(x, '☎ ' + ph, nx, yy, { size: 28, color: '#d8ccb0', maxW: lim }); }
      if (s.gstin) { yy += 50; T(x, 'GSTIN  ' + s.gstin, nx, yy, { size: 28, w: 700, color: '#f2d68a', maxW: lim }); }
      const R = PX - M; font(x, 700, 92, SERIF); const t1 = 'ORDER'; const t2 = 'ESTIMATE';
      x.textAlign = 'right'; x.save(); x.shadowColor = 'rgba(0,0,0,0.6)'; x.shadowBlur = 12; x.shadowOffsetY = 5; fit(x, t1 + ' ' + t2, rw, 700, 86, SERIF, 60); x.fillStyle = sheen(x, R - rw, 100, R, 200); x.fillText(t1 + ' ' + t2, R, 185); x.restore();
      T(x, buy ? 'Purchase order · for supplier' : 'Design · Purity · Weight — for your approval', R, 236, { align: 'right', size: 27, color: '#d8ccb0', maxW: rw });
      let cx = R; [revTxt, buy ? 'SUPPLIER' : 'CUSTOMER ORDER'].filter(Boolean).forEach(c => { cx -= chip(x, c, cx, 268, { right: true, size: 24 }) + 16; });
      T(x, 'ESTIMATE NO.', R, 390, { align: 'right', size: 24, color: '#bfb08c', ls: 3 });
      T(x, String(e.no || 'Draft'), R, 452, { align: 'right', size: 56, w: 700, color: '#ffffff', maxW: rw });
      T(x, H.longDate(e.date), R, 506, { align: 'right', size: 29, color: '#e3d3a6' });
      return HDR + 21;
    }
    function contHeader(x, pi) {
      const g = x.createLinearGradient(0, 0, PX, 0); g.addColorStop(0, '#07060a'); g.addColorStop(1, '#2a1d0c'); x.fillStyle = g; x.fillRect(0, 0, PX, CONT); divider(x, CONT);
      x.fillStyle = grad(x, M, 0, M + 1200, 0); fit(x, legal, 1300, 700, 60, SERIF); x.textAlign = 'left'; x.fillText(legal, M, 150);
      T(x, `ORDER ESTIMATE  ·  ${e.no || 'Draft'}  ·  page ${pi + 1}`, PX - M, 150, { align: 'right', size: 32, color: '#e3d3a6' }); return CONT + 10;
    }
    function infoCards(x, top) {
      const h = 330, lw = 1000, gap = 36, w2 = (CW - lw - 2 * gap) / 2;
      // party
      rr(x, M, top, lw, h, 26); x.fillStyle = C.cream; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke(); x.fillStyle = grad(x, 0, top, 0, top + h); x.fillRect(M, top + 30, 9, h - 60);
      T(x, buy ? 'SUPPLIER' : 'ORDER FOR', M + 50, top + 64, { size: 24, w: 700, color: C.goldT, ls: 3 });
      T(x, e.partyName || '—', M + 50, top + 136, { size: 56, w: 700, fam: SERIF, maxW: lw - 100 });
      let yy = top + 136; [e.partyCity, e.partyPhone ? 'Mobile  ' + e.partyPhone : ''].filter(Boolean).forEach(l => { yy += 50; T(x, l, M + 50, yy, { size: 30, color: '#3d362a', maxW: lw - 100 }); });
      // delivery
      const X2 = M + lw + gap; rr(x, X2, top, w2, h, 26); x.fillStyle = '#ffffff'; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      T(x, 'DELIVERY', X2 + 44, top + 64, { size: 24, w: 700, color: C.goldT, ls: 3 });
      if (e.deliveryDate) {
        const d = parseD(e.deliveryDate); T(x, String(d.getDate()), X2 + 44, top + 196, { size: 120, w: 700, fam: SERIF, color: C.ink });
        font(x, 700, 120, SERIF); const dw = x.measureText(String(d.getDate())).width;
        T(x, d.toLocaleDateString('en-IN', { month: 'long' }).toUpperCase(), X2 + 64 + dw, top + 140, { size: 32, w: 700, color: C.ink, maxW: w2 - dw - 100 });
        T(x, String(d.getFullYear()) + ' · ' + d.toLocaleDateString('en-IN', { weekday: 'long' }), X2 + 64 + dw, top + 190, { size: 26, color: C.mut, maxW: w2 - dw - 100 });
        if (daysLeft != null) { const txt = daysLeft > 1 ? daysLeft + ' DIN BAAKI' : daysLeft === 1 ? 'KAL' : daysLeft === 0 ? 'AAJ' : 'DATE NIKAL GAYI'; chip(x, txt, X2 + 44, top + 238, { size: 22, bg: daysLeft < 0 ? C.red : '#1f180c', fg: daysLeft < 0 ? '#fff' : '#f2d68a', line: daysLeft < 0 ? C.red : '#c9a046' }); }
      } else { T(x, 'Tay hona baaki', X2 + 44, top + 170, { size: 40, w: 700, fam: SERIF, color: C.mut }); T(x, 'Confirm ke baad batayenge', X2 + 44, top + 220, { size: 26, color: C.mut, maxW: w2 - 80 }); }
      // total weight hero (dark)
      const X3 = X2 + w2 + gap; rr(x, X3, top, w2, h, 26); const g = x.createLinearGradient(X3, top, X3 + w2, top + h); g.addColorStop(0, '#120d06'); g.addColorStop(1, '#2b1c09'); x.fillStyle = g; x.fill(); x.lineWidth = 3; x.strokeStyle = '#c9a046'; x.stroke();
      T(x, 'TOTAL ORDER WEIGHT', X3 + 44, top + 64, { size: 24, w: 700, color: '#d9b45a', ls: 3, maxW: w2 - 80 });
      const tw = total ? (total[0] === total[1] ? fmtW(total[0]) : fmtW(total[0]) + ' – ' + fmtW(total[1])) : '—';
      x.save(); fit(x, tw, w2 - 88, 700, 84, SERIF, 44); x.textAlign = 'left'; x.fillStyle = sheen(x, X3 + 44, top + 110, X3 + w2, top + 200); x.fillText(tw, X3 + 44, top + 186); x.restore();
      T(x, total ? 'grams (approx.)' : '', X3 + 44, top + 236, { size: 27, color: '#e9d7a5' });
      const pcs = items.reduce((a, it) => a + (num(it.qty) || 1), 0); T(x, `${items.length} design${items.length > 1 ? 's' : ''} · ${pcs} ${pcs > 1 ? 'pieces' : 'piece'}`, X3 + 44, top + 290, { size: 25, color: '#cdbb8f', maxW: w2 - 80 });
      return top + h;
    }
    function fmtW(n) { return String(+num(n).toFixed(3)); }
    function itemCard(x, y, it, i, h, dl) {
      const X = M, W = CW;
      x.save(); x.shadowColor = 'rgba(90,60,10,0.12)'; x.shadowBlur = 22; x.shadowOffsetY = 6; rr(x, X, y, W, h, 26); x.fillStyle = '#ffffff'; x.fill(); x.restore();
      rr(x, X, y, W, h, 26); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      // number medallion
      x.beginPath(); x.arc(X + 62, y + 66, 38, 0, Math.PI * 2); x.fillStyle = grad(x, X + 24, y + 28, X + 100, y + 104); x.fill(); T(x, String(i + 1), X + 62, y + 82, { align: 'center', size: 40, w: 700, fam: SERIF, color: '#1b1206' });
      let tx = X + 130;
      if (anyPhoto) {
        const sz = h - 60, px = X + 130, py = y + 30, im = pics[i].find(Boolean);
        x.save(); x.shadowColor = 'rgba(80,55,10,0.28)'; x.shadowBlur = 18; x.shadowOffsetY = 6; rr(x, px, py, sz, sz, 22); x.fillStyle = '#fff'; x.fill(); x.restore();
        x.save(); rr(x, px, py, sz, sz, 22); x.clip(); if (im) { const k = Math.max(sz / im.naturalWidth, sz / im.naturalHeight); const dw = im.naturalWidth * k, dh = im.naturalHeight * k; x.drawImage(im, px + (sz - dw) / 2, py + (sz - dh) / 2, dw, dh); } else { x.fillStyle = '#f3ead2'; x.fillRect(px, py, sz, sz); T(x, (String(it.name || 'S')[0] || 'S').toUpperCase(), px + sz / 2, py + sz / 2 + 40, { align: 'center', size: 110, w: 700, fam: SERIF, color: '#d9c38c' }); } x.restore();
        rr(x, px, py, sz, sz, 22); x.lineWidth = 4; x.strokeStyle = '#d4b062'; x.stroke();
        const more = pics[i].filter(Boolean).length - 1; if (more > 0) chip(x, '+' + more + ' photo', px + sz - 14, py + sz - 66, { right: true, size: 20, h: 46, pad: 30, ls: 0 });
        tx = px + sz + 50;
      }
      T(x, it.name || 'Design', tx, y + 92, { size: 50, w: 700, fam: SERIF, maxW: TXT_W });
      let ly = y + 92; dl.forEach(l => { ly += 40; T(x, l, tx, ly, { size: 28, color: C.mut, maxW: TXT_W }); });
      // chips: purity / qty / category
      let cxp = tx; const cy = Math.max(ly + 30, y + h - 96);
      [[H.meltTxt(it) ? (it.melting ? it.melting + ' melting · ' + it.purity : it.purity) : '', 'gold'], [H.qtyTxt(it), 'light'], [it.category || '', 'light']].filter(c => c[0]).forEach(([lb, kd]) => {
        font(x, 700, 24); const w = x.measureText(lb).width + 44; if (cxp + w > tx + TXT_W) return; rr(x, cxp, cy, w, 52, 26);
        x.fillStyle = kd === 'gold' ? grad(x, cxp, cy, cxp + w, cy + 52) : '#f6efdc'; x.fill(); if (kd !== 'gold') { x.lineWidth = 2; x.strokeStyle = C.line; x.stroke(); }
        T(x, lb, cxp + w / 2, cy + 35, { align: 'center', size: 24, w: 700, color: kd === 'gold' ? '#1b1206' : '#5a4512', ls: 0.5 }); cxp += w + 14;
      });
      // weight columns
      const R = X + W - 50, c2 = R - 360;
      x.strokeStyle = '#efe5cd'; x.lineWidth = 2; x.beginPath(); x.moveTo(c2 - 360, y + 34); x.lineTo(c2 - 360, y + h - 34); x.moveTo(c2 - 10, y + 34); x.lineTo(c2 - 10, y + h - 34); x.stroke();
      const per = H.perTxt(it), tot = H.itemTotal(it); const mid = y + h / 2;
      T(x, (num(it.qty) || 1) > 1 ? 'WEIGHT / ' + String(H.qtyTxt(it).split(' ').pop() || 'PC').replace(/s$/i, '').toUpperCase() : 'WEIGHT', c2 - 40, mid - 40, { align: 'right', size: 22, w: 700, color: C.goldT, ls: 2, maxW: 300 });
      const pr = H.wRange(it.wMin, it.wMax); T(x, pr ? (pr[0] === pr[1] ? fmtW(pr[0]) : fmtW(pr[0]) + ' – ' + fmtW(pr[1])) + ' g' : '—', c2 - 40, mid + 18, { align: 'right', size: 38, w: 600, maxW: 310 });
      if (/full set/.test(per)) T(x, 'full set', c2 - 40, mid + 58, { align: 'right', size: 22, color: C.mut });
      T(x, 'TOTAL', R, mid - 40, { align: 'right', size: 22, w: 700, color: C.goldT, ls: 2 });
      const tt = tot ? (tot[0] === tot[1] ? fmtW(tot[0]) : fmtW(tot[0]) + ' – ' + fmtW(tot[1])) : '—'; T(x, tt, R, mid + 24, { align: 'right', size: 50, w: 700, fam: SERIF, maxW: 340, min: 28 });
      if (tot) T(x, 'grams', R, mid + 64, { align: 'right', size: 22, color: C.mut });
    }
    function sumBar(x, y) {
      const h = 100; rr(x, M, y + 10, CW, h, 22); x.fillStyle = '#0d0b07'; x.fill(); x.fillStyle = grad(x, M, 0, M + CW, 0); x.fillRect(M + 24, y + 10 + h - 6, CW - 48, 4);
      T(x, 'TOTAL ORDER WEIGHT (APPROX.)', M + 50, y + 74, { size: 26, w: 700, color: '#f2d68a', ls: 3 });
      const tw = (total[0] === total[1] ? fmtW(total[0]) : fmtW(total[0]) + ' – ' + fmtW(total[1])) + ' g'; x.save(); font(x, 700, 50, SERIF); x.textAlign = 'right'; x.fillStyle = sheen(x, M + CW - 700, y + 30, M + CW, y + 100); x.fillText(tw, M + CW - 50, y + 80); x.restore();
    }
    function galleryTitle(x, y) { T(x, 'DESIGN REFERENCE', M, y + 50, { size: 26, w: 700, color: C.goldT, ls: 4 }); x.fillStyle = grad(x, M + 360, 0, M + CW, 0); x.fillRect(M + 360, y + 41, CW - 360, 3); }
    function photoCell(x, X, Y, w, hMax, g) {
      let iw = w, ih = iw * g.im.naturalHeight / g.im.naturalWidth; if (ih > hMax) { ih = hMax; iw = ih * g.im.naturalWidth / g.im.naturalHeight; }
      const px = X + (w - iw) / 2; x.save(); x.shadowColor = 'rgba(80,55,10,0.25)'; x.shadowBlur = 24; x.shadowOffsetY = 8; rr(x, px - 14, Y - 14, iw + 28, ih + 28, 24); x.fillStyle = '#fff'; x.fill(); x.restore();
      x.save(); rr(x, px, Y, iw, ih, 16); x.clip(); x.drawImage(g.im, px, Y, iw, ih); x.restore(); rr(x, px - 14, Y - 14, iw + 28, ih + 28, 24); x.lineWidth = 3; x.strokeStyle = '#d4b062'; x.stroke();
      T(x, g.cap, X + w / 2, Y + ih + 62, { align: 'center', size: 30, w: 700, fam: SERIF, maxW: w - 20 }); if (g.sub) T(x, g.sub, X + w / 2, Y + ih + 100, { align: 'center', size: 24, color: C.mut, maxW: w - 20 });
    }
    function notesBox(x, X, Y, W, lines, cont) {
      const h = 90 + lines.length * 44 + 20; rr(x, X, Y, W, h, 24); x.fillStyle = C.cream; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      T(x, cont ? 'ORDER NOTES (contd.)' : 'ORDER NOTES', X + 44, Y + 62, { size: 24, w: 700, color: C.goldT, ls: 3 });
      let yy = Y + 66; lines.forEach(([l, first]) => { yy += 44; if (first) { x.save(); x.translate(X + 54, yy - 10); x.rotate(Math.PI / 4); x.fillStyle = grad(x, -7, -7, 7, 7); x.fillRect(-7, -7, 14, 14); x.restore(); } T(x, l, X + 84, yy, { size: 30, color: '#2f291f', maxW: W - 120 }); });
    }
    function journey(x, y) {
      const steps = [['Estimate', 'Design, purity, weight'], ['Confirm', 'Aapki haan + advance'], ['Karigar', 'Haath se banai'], ['Hallmark', 'BIS HUID jaanch'], ['Delivery', e.deliveryDate ? H.longDate(e.deliveryDate) : 'Tay tareekh par']];
      T(x, 'AAPKE ORDER KA SAFAR', M, y + 44, { size: 24, w: 700, color: C.goldT, ls: 4 });
      const y0 = y + 140, step = CW / steps.length; x.strokeStyle = '#e2cf9c'; x.lineWidth = 4; x.setLineDash([14, 12]); x.beginPath(); x.moveTo(M + step / 2, y0); x.lineTo(M + CW - step / 2, y0); x.stroke(); x.setLineDash([]);
      steps.forEach(([h, d], i) => { const cx = M + step * i + step / 2, on = i === 0; x.beginPath(); x.arc(cx, y0, 44, 0, Math.PI * 2); x.fillStyle = on ? grad(x, cx - 44, y0 - 44, cx + 44, y0 + 44) : '#ffffff'; x.fill(); x.lineWidth = 3; x.strokeStyle = '#c9a046'; x.stroke(); T(x, String(i + 1), cx, y0 + 16, { align: 'center', size: 40, w: 700, fam: SERIF, color: on ? '#1b1206' : C.goldT }); T(x, h, cx, y0 + 96, { align: 'center', size: 30, w: 700, maxW: step - 30 }); T(x, d, cx, y0 + 134, { align: 'center', size: 23, color: C.mut, maxW: step - 30 }); });
    }
    function signBox(x, y) {
      const h = 360, Y = y + 30; rr(x, M, Y, CW, h, 28); x.fillStyle = '#ffffff'; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      const qs = 210, qx = M + 60, qy = Y + 60;
      const q = shopPh.length === 10 ? `https://wa.me/91${shopPh}?text=${encodeURIComponent(`Namaste! Order estimate ${e.no || ''} CONFIRM — ${e.partyName || ''}`)}` : `Order ${e.no || ''} CONFIRM`;
      rr(x, qx - 12, qy - 12, qs + 24, qs + 24, 16); x.fillStyle = '#fff'; x.fill(); x.lineWidth = 2; x.strokeStyle = C.line; x.stroke(); qrDraw(x, q, qx, qy, qs, '#1a1206');
      T(x, 'Scan · WhatsApp CONFIRM', qx + qs / 2, qy + qs + 48, { align: 'center', size: 20, w: 700, color: C.goldT, maxW: qs + 60 });
      const tx = qx + qs + 70, tw = 900;
      T(x, buy ? 'SUPPLIER CONFIRMATION' : 'ORDER CONFIRMATION', tx, Y + 88, { size: 26, w: 700, color: C.goldT, ls: 3 });
      wrap(x, buy ? 'Upar likhe design, purity aur wazan ke hisaab se maal bhejne ke liye sign karein ya QR scan karke WhatsApp par CONFIRM bhejein.' : 'Design, purity aur wazan theek hai to neeche sign kijiye — ya QR scan karke WhatsApp par CONFIRM bhej dijiye. Confirm hote hi karigar kaam shuru karega.', tw, 400, 28).slice(0, 3).forEach((l, k) => T(x, l, tx, Y + 140 + k * 40, { size: 28, color: '#3d362a' }));
      T(x, 'Final rate, making aur keemat delivery ke din ke bhav se bill mein.', tx, Y + 280, { size: 23, color: C.mut, maxW: tw });
      const R = M + CW - 60, sw = 460; x.strokeStyle = '#8f8778'; x.lineWidth = 2; x.beginPath(); x.moveTo(R - sw, Y + 250); x.lineTo(R, Y + 250); x.moveTo(R - sw * 2 - 60, Y + 250); x.lineTo(R - sw - 60, Y + 250); x.stroke();
      T(x, buy ? 'Supplier Signature' : 'Party Signature', R - sw * 1.5 - 60, Y + 292, { align: 'center', size: 24, color: C.mut }); T(x, 'For ' + legal, R - sw / 2, Y + 292, { align: 'center', size: 24, w: 700, color: C.goldT, maxW: sw + 40 });
      T(x, 'Authorised Signatory', R - sw / 2, Y + 328, { align: 'center', size: 20, color: C.mut });
    }
    function bottomStrip(x, pi) {
      const y = PY - 92; x.fillStyle = '#0d0b07'; x.fillRect(0, y, PX, 92); x.fillStyle = grad(x, 0, 0, PX, 0); x.fillRect(0, y, PX, 5);
      const foot = e.footer == null ? H.FOOTER() : e.footer;
      T(x, foot || ('Thank you for your order · ' + firm), PX / 2, y + 58, { align: 'center', size: 25, fam: HIN, color: '#f2d68a', maxW: PX - 2 * M - 700 });
      T(x, 'Order estimate · weights approx.', M, y + 58, { size: 21, color: '#a89a78' }); T(x, `Page ${pi + 1} of ${nP}`, PX - M, y + 58, { align: 'right', size: 21, color: '#a89a78' });
    }
  }
  window.SJ_ESTX = estimateSignaturePdf;
})();
