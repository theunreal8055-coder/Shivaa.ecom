/* =====================================================================
   SJ CHARTS — small interactive SVG charts for the app (no library)
   line / area · bars (grouped / stacked) · horizontal bars · donut ·
   ring · sparkline · calendar heat-map
   - hover / touch: crosshair + tooltip on lines, per-mark tooltip on bars
   - legend buttons hide / show a series
   - colours come from CSS variables --v1 … --v6 (dark + light themes)
   ===================================================================== */
(() => {
  'use strict';
  const E = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const N = v => { const n = typeof v === 'number' ? v : parseFloat(v); return isFinite(n) ? n : 0; };
  const PAL = ['var(--v1)', 'var(--v2)', 'var(--v3)', 'var(--v4)', 'var(--v5)', 'var(--v6)'];
  const OTHER = 'var(--v0)';
  const small = () => window.innerWidth < 600;
  const f1 = n => (Math.round(n * 10) / 10).toString();
  const compact = v => { v = N(v); const a = Math.abs(v); return (v < 0 ? '-' : '') + (a >= 1e7 ? f1(a / 1e7) + 'Cr' : a >= 1e5 ? f1(a / 1e5) + 'L' : a >= 1e3 ? f1(a / 1e3) + 'K' : a >= 10 ? String(Math.round(a)) : f1(a)); };
  function niceMax(m) { if (!(m > 0)) return 1; const p = Math.pow(10, Math.floor(Math.log10(m))); const f = m / p; return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * p; }
  const SJC = { animate: false, PAL, OTHER, compact };
  const anim = () => (SJC.animate ? ' sjc-in' : '');

  const legend = series => series.length < 2 ? '' : `<div class="sjc-leg">${series.map((s, i) => `<button type="button" class="sjc-lg" data-sjl="${i}"><i class="${s.dash ? 'dash' : ''}" style="background:${s.c}"></i>${E(s.l)}</button>`).join('')}</div>`;

  /* ---------- shared frame for line / bar charts ---------- */
  function frame(rows, series, o) {
    const W = small() ? 360 : (o.wide ? 940 : 680), H = o.h || (small() ? 190 : (o.wide ? 240 : 220)), L = 44, R = 12, T = 12, B = 24;
    const n = rows.length; let hi = 0, lo = 0;
    rows.forEach(r => { if (o.stacked) { let p = 0, q = 0; series.forEach(s => { const v = N(r[s.k]); if (v >= 0) p += v; else q += v; }); hi = Math.max(hi, p); lo = Math.min(lo, q); } else series.forEach(s => { const v = N(r[s.k]); hi = Math.max(hi, v); lo = Math.min(lo, v); }); });
    if (o.max) hi = Math.max(hi, o.max);
    if (o.zoom) { let mn = Infinity; rows.forEach(r => series.forEach(s => { if (r[s.k] != null && r[s.k] !== '') mn = Math.min(mn, N(r[s.k])); })); if (!isFinite(mn)) mn = 0; const pad = Math.max((hi - mn) * 0.18, Math.abs(hi) * 0.004, 1e-9); lo = mn - pad; hi = hi + pad; }
    else { hi = o.top ? Math.max(hi, o.top) : niceMax(hi); lo = lo < 0 ? -niceMax(-lo) : 0; }
    const ph = H - T - B, pw = W - L - R, y = v => T + ph * (1 - (v - lo) / (hi - lo || 1));
    const ax = o.axis || compact; const ticks = o.zoom ? [lo, (lo + hi) / 2, hi] : lo < 0 ? [lo, 0, hi] : [0, hi / 2, hi];
    const grid = ticks.map(t => `<line class="sjc-grid${t === 0 || (o.zoom && t === lo) ? ' base' : ''}" x1="${L}" x2="${W - R}" y1="${y(t).toFixed(1)}" y2="${y(t).toFixed(1)}"/><text class="sjc-ax" x="${L - 5}" y="${(y(t) + 3.5).toFixed(1)}" text-anchor="end">${E(ax(t))}</text>`).join('');
    const step = Math.max(1, Math.ceil(n / (small() ? 5 : 10)));
    return { W, H, L, R, T, B, n, hi, lo, ph, pw, y, grid, step };
  }

  /* ---------- line / area ---------- */
  SJC.line = function (rows, series, o = {}) {
    if (!rows || !rows.length) return '';
    const fmt = o.fmt || compact; const F = frame(rows, series, o); const { W, H, L, n, y } = F;
    const dx = n > 1 ? F.pw / (n - 1) : 0, x = i => L + (n > 1 ? i * dx : F.pw / 2);
    const xl = rows.map((r, i) => (i % F.step === 0 || i === n - 1) && !(i === n - 1 && (n - 1) % F.step !== 0 && (n - 1) % F.step < F.step / 2) ? `<text class="sjc-ax" x="${x(i).toFixed(1)}" y="${H - 7}" text-anchor="${i === 0 ? 'start' : i === n - 1 ? 'end' : 'middle'}">${E(r.lab)}</text>` : '').join('');
    const gid = 'sjg' + Math.random().toString(36).slice(2, 8);
    const val = (r, s) => r[s.k] == null || r[s.k] === '' ? null : N(r[s.k]);
    const paths = series.map((s, si) => {
      const pts = rows.map((r, i) => { const v = val(r, s); return v == null ? null : [x(i), y(v)]; });
      let d = '', pen = false; pts.forEach(p => { if (!p) { pen = false; return; } d += (pen ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1); pen = true; });
      const real = pts.filter(Boolean); if (!real.length) return `<g data-s="${si}"><circle class="sjc-dot" r="4.5" cx="0" cy="0" style="fill:${s.c};opacity:0"/></g>`;
      const area = s.area && real.length > 1 ? `<path class="sjc-area" d="${d}L${real[real.length - 1][0].toFixed(1)} ${y(o.zoom ? F.lo : Math.max(0, F.lo)).toFixed(1)}L${real[0][0].toFixed(1)} ${y(o.zoom ? F.lo : Math.max(0, F.lo)).toFixed(1)}Z" fill="url(#${gid}${si})"/><defs><linearGradient id="${gid}${si}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${s.c}" stop-opacity=".34"/><stop offset="1" stop-color="${s.c}" stop-opacity="0"/></linearGradient></defs>` : '';
      const last = real[real.length - 1];
      return `<g data-s="${si}">${area}<path class="sjc-line${s.dash ? ' dash' : ''}"${s.dash ? '' : ' pathLength="1"'} d="${d}" style="stroke:${s.c}"/>${s.dash ? '' : `<circle class="sjc-end" cx="${last[0].toFixed(1)}" cy="${last[1].toFixed(1)}" r="3.5" style="fill:${s.c}"/>`}<circle class="sjc-dot" r="4.5" cx="0" cy="0" style="fill:${s.c};opacity:0"/></g>`;
    }).join('');
    const data = { W, x0: L, dx, n, labs: rows.map(r => r.tip || r.lab), s: series.map(s => ({ l: s.l, c: s.c, dash: !!s.dash, v: rows.map(r => val(r, s) == null ? '—' : fmt(val(r, s))), y: rows.map(r => val(r, s) == null ? null : +y(val(r, s)).toFixed(1)) })) };
    return `<div class="sjc${anim()}">${legend(series)}<div class="sjc-x" data-sjc="${E(JSON.stringify(data))}"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${E(o.label || series.map(s => s.l).join(', '))}">${F.grid}${xl}${paths}<line class="sjc-cross" x1="0" x2="0" y1="${F.T}" y2="${H - F.B}" style="opacity:0"/></svg></div></div>`;
  };

  /* ---------- vertical bars (grouped or stacked) ---------- */
  SJC.bars = function (rows, series, o = {}) {
    if (!rows || !rows.length) return '';
    const fmt = o.fmt || compact; const F = frame(rows, series, o); const { W, H, L, n, y } = F;
    const gw = F.pw / n, k = o.stacked ? 1 : series.length, bw = Math.max(2, Math.min(o.stacked ? 34 : 24, (gw - 4) / k));
    const y0 = y(0);
    let marks = '';
    rows.forEach((r, i) => {
      let accP = 0, accN = 0; const lab = r.tip || r.lab;
      series.forEach((s, si) => {
        const v = N(r[s.k]); if (!v) return;
        let a, b, bx;
        if (o.stacked) { if (v >= 0) { a = y(accP + v); b = y(accP); accP += v; } else { a = y(accN); b = y(accN + v); accN += v; } bx = L + i * gw + (gw - bw) / 2; }
        else { a = v >= 0 ? y(v) : y0; b = v >= 0 ? y0 : y(v); bx = L + i * gw + (gw - bw * k) / 2 + si * bw; }
        const h = Math.max(1.5, b - a - (o.stacked ? 2 : 0)), w = Math.max(1.5, bw - 2);
        marks += `<rect data-s="${si}" class="sjc-bar" x="${(bx + 1).toFixed(1)}" y="${a.toFixed(1)}" width="${w.toFixed(1)}" height="${h.toFixed(1)}" rx="${Math.min(3, w / 2).toFixed(1)}" style="fill:${s.c};transform-origin:0 ${y0.toFixed(1)}px" data-tip="${E(lab + '\n' + s.l + ': ' + fmt(v))}"/>`;
      });
      if (i % F.step === 0) marks += `<text class="sjc-ax" x="${(L + i * gw + gw / 2).toFixed(1)}" y="${H - 7}" text-anchor="middle">${E(r.lab)}</text>`;
    });
    return `<div class="sjc${anim()}">${legend(series)}<div class="sjc-b"><svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${E(o.label || series.map(s => s.l).join(', '))}">${F.grid}${marks}</svg></div></div>`;
  };

  /* ---------- horizontal bars (ranked list) ---------- */
  SJC.hbar = function (items, o = {}) {
    items = (items || []).filter(x => x && isFinite(N(x.v)));
    if (!items.length) return '';
    const fmt = o.fmt || compact; const max = Math.max(1e-9, o.max || 0, ...items.map(x => Math.abs(N(x.v))));
    return `<div class="sjc sjc-hbars${anim()}">${items.map((x, i) => { const w = N(x.v) ? Math.max(1.5, Math.abs(N(x.v)) / max * 100) : 0; const c = x.c || o.c || PAL[0];
      return `<${x.attrs ? 'button type="button"' : 'div'} class="sjc-hb${N(x.v) < 0 ? ' neg' : ''}" ${x.attrs || ''} data-tip="${E(x.l + '\n' + (x.tip || fmt(N(x.v))))}"><span class="l">${o.rank ? `<em>${i + 1}</em>` : ''}${E(x.l)}${x.sub ? `<small>${E(x.sub)}</small>` : ''}</span><span class="tr"><i style="width:${w.toFixed(1)}%;background:${N(x.v) < 0 ? 'var(--v-bad)' : c}"></i></span><span class="v">${E(fmt(N(x.v)))}</span></${x.attrs ? 'button' : 'div'}>`; }).join('')}</div>`;
  };

  /* ---------- donut ---------- */
  SJC.donut = function (items, o = {}) {
    items = (items || []).filter(x => N(x.v) > 0).sort((a, b) => N(b.v) - N(a.v));
    if (!items.length) return '';
    const fmt = o.fmt || compact; const cap = o.cap || 5;
    if (items.length > cap + 1) { const rest = items.slice(cap); items = items.slice(0, cap).concat([{ l: `Other (${rest.length})`, v: rest.reduce((a, x) => a + N(x.v), 0), c: OTHER }]); }
    const tot = items.reduce((a, x) => a + N(x.v), 0); const R = 52, C = 2 * Math.PI * R, gap = items.length > 1 ? 2.2 : 0; let off = 0;
    const segs = items.map((x, i) => { const frac = N(x.v) / tot, len = Math.max(0.5, frac * C - gap); const c = x.c || PAL[i % PAL.length]; x._c = c;
      const el = `<circle class="sjc-seg" cx="70" cy="70" r="${R}" fill="none" style="stroke:${c};--len:${len.toFixed(2)};--i:${i}" stroke-width="17" stroke-dasharray="${len.toFixed(2)} ${(C - len).toFixed(2)}" stroke-dashoffset="${(-off).toFixed(2)}" transform="rotate(-90 70 70)" data-tip="${E(x.l + '\n' + fmt(N(x.v)) + ' · ' + f1(frac * 100) + '%')}"/>`; off += frac * C; return el; }).join('');
    const ct = o.center || {};
    return `<div class="sjc sjc-donut${anim()}"><svg viewBox="0 0 140 140" role="img" aria-label="${E(o.label || 'Share')}"><circle cx="70" cy="70" r="${R}" fill="none" style="stroke:var(--track)" stroke-width="17" opacity=".5"/>${segs}<text class="sjc-ct" x="70" y="${ct.s ? 68 : 74}" text-anchor="middle">${E(ct.t != null ? ct.t : fmt(tot))}</text>${ct.s ? `<text class="sjc-cs" x="70" y="84" text-anchor="middle">${E(ct.s)}</text>` : ''}</svg>
      <div class="sjc-dl">${items.map(x => `<div class="sjc-di" data-tip="${E(x.l + '\n' + fmt(N(x.v)))}"><i style="background:${x._c}"></i><span class="l">${E(x.l)}</span><b>${E(fmt(N(x.v)))}</b><em>${f1(N(x.v) / tot * 100)}%</em></div>`).join('')}</div></div>`;
  };

  /* ---------- progress ring ---------- */
  SJC.ring = function (pct, o = {}) {
    pct = Math.max(0, Math.min(100, N(pct))); const R = o.r || 54, sw = o.sw || 12, S = (R + sw) * 2, C = 2 * Math.PI * R, c = o.c || PAL[0]; const id = 'sjr' + Math.random().toString(36).slice(2, 8);
    return `<svg class="sjc-ring${anim()}" viewBox="0 0 ${S} ${S}" role="img" aria-label="${E((o.label || '') + ' ' + Math.round(pct) + '%')}"><defs><linearGradient id="${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${o.c2 || c}"/><stop offset="1" stop-color="${c}"/></linearGradient></defs><circle cx="${S / 2}" cy="${S / 2}" r="${R}" fill="none" style="stroke:var(--track)" stroke-width="${sw}"/><circle class="sjc-rv" cx="${S / 2}" cy="${S / 2}" r="${R}" fill="none" stroke="url(#${id})" stroke-width="${sw}" stroke-linecap="round" stroke-dasharray="${C.toFixed(1)}" stroke-dashoffset="${(C * (1 - pct / 100)).toFixed(1)}" style="--c:${C.toFixed(1)}" transform="rotate(-90 ${S / 2} ${S / 2})"/><text class="sjc-ct" x="${S / 2}" y="${S / 2 + (o.sub ? 0 : 7)}" text-anchor="middle" style="font-size:${o.fs || 24}px">${E(o.text != null ? o.text : (pct >= 10 ? Math.round(pct) : f1(pct)) + '%')}</text>${o.sub ? `<text class="sjc-cs" x="${S / 2}" y="${S / 2 + 18}" text-anchor="middle">${E(o.sub)}</text>` : ''}</svg>`;
  };

  /* ---------- sparkline ---------- */
  SJC.spark = function (vals, c) {
    vals = (vals || []).map(N); if (vals.length < 2) return '';
    const W = 120, H = 32, mx = Math.max(...vals), mn = Math.min(...vals), sp = mx - mn || 1;
    const pts = vals.map((v, i) => [(i / (vals.length - 1)) * (W - 4) + 2, H - 3 - (v - mn) / sp * (H - 6)]);
    const d = pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('');
    return `<svg class="sjc-spark" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true"><path d="${d}" fill="none" style="stroke:${c || PAL[0]}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>`;
  };

  /* ---------- calendar heat-map (one cell per day) ---------- */
  SJC.heat = function (days, o = {}) {
    // days: [{d:'YYYY-MM-DD', v:number}] in date order
    if (!days || !days.length) return '';
    const fmt = o.fmt || (v => String(v)); const mx = Math.max(1, ...days.map(x => N(x.v))); const cs = o.cs || 13, gp = 3;
    const first = new Date(days[0].d + 'T00:00:00'); const lead = (first.getDay() + 6) % 7; const cols = Math.ceil((lead + days.length) / 7);
    const W = cols * (cs + gp) + 26, H = 7 * (cs + gp) + 16; const c = o.c || PAL[0]; let cells = '', months = '', lastM = '';
    days.forEach((x, i) => { const k = lead + i, col = Math.floor(k / 7), row = k % 7; const v = N(x.v); const lvl = v <= 0 ? 0 : Math.min(4, Math.ceil(v / mx * 4));
      const xx = 26 + col * (cs + gp), yy = 14 + row * (cs + gp); const m = x.d.slice(5, 7);
      if (m !== lastM && row < 4) { lastM = m; months += `<text class="sjc-ax" x="${xx}" y="9">${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][+m - 1]}</text>`; }
      cells += `<rect class="sjc-hc${x.today ? ' today' : ''}" x="${xx}" y="${yy}" width="${cs}" height="${cs}" rx="3" style="fill:${lvl ? c : 'var(--track)'};opacity:${lvl ? (0.28 + lvl * 0.18).toFixed(2) : 1}" data-tip="${E(x.d.split('-').reverse().join('-') + '\n' + fmt(v))}"/>`; });
    const dl = ['M', '', 'W', '', 'F', '', 'S'].map((t, i) => t ? `<text class="sjc-ax" x="0" y="${14 + i * (cs + gp) + 10}">${t}</text>` : '').join('');
    return `<div class="sjc sjc-heat${anim()}"><div class="sjc-hs"><svg viewBox="0 0 ${W} ${H}" style="width:${W}px;max-width:none" role="img" aria-label="${E(o.label || 'Daily activity')}">${months}${dl}${cells}</svg></div></div>`;
  };

  /* ---------- hover layer for line charts ---------- */
  let tip = null, cur = null;
  const tipEl = () => { if (!tip) { tip = document.createElement('div'); tip.className = 'sjc-tip'; tip.setAttribute('role', 'status'); document.body.appendChild(tip); } return tip; };
  function hide() { if (tip) tip.classList.remove('on'); if (cur) { const c = cur.querySelector('.sjc-cross'); if (c) c.style.opacity = 0; cur.querySelectorAll('.sjc-dot').forEach(d => { d.style.opacity = 0; }); cur = null; } }
  function move(e) {
    const host = e.target && e.target.closest ? e.target.closest('.sjc-x') : null;
    if (!host) { if (cur) hide(); return; }
    let d = host._d; if (!d) { try { d = host._d = JSON.parse(host.dataset.sjc); } catch (er) { return; } }
    const svg = host.querySelector('svg'); if (!svg) return; const r = svg.getBoundingClientRect(); if (!r.width) return;
    if (cur && cur !== host) hide(); cur = host;
    const px = (e.clientX - r.left) / r.width * d.W; let i = d.dx ? Math.round((px - d.x0) / d.dx) : 0; i = Math.max(0, Math.min(d.n - 1, i));
    const cx = d.x0 + (d.n > 1 ? i * d.dx : (d.W - d.x0 - 12) / 2);
    const cross = host.querySelector('.sjc-cross'); if (cross) { cross.setAttribute('x1', cx); cross.setAttribute('x2', cx); cross.style.opacity = 1; }
    const off = host.parentElement ? host.parentElement.dataset.off || '' : '';
    host.querySelectorAll('g[data-s]').forEach(g => { const si = +g.dataset.s, s = d.s[si], dot = g.querySelector('.sjc-dot'); if (dot && s) { const yy = s.y[i]; if (yy == null) dot.style.opacity = 0; else { dot.setAttribute('cx', cx); dot.setAttribute('cy', yy); dot.style.opacity = 1; } } });
    const t = tipEl(); t.textContent = '';
    const h = document.createElement('div'); h.className = 'h'; h.textContent = d.labs[i]; t.appendChild(h);
    d.s.forEach((s, si) => { if (off.indexOf(',' + si + ',') >= 0 || s.v[i] === '—') return; const row = document.createElement('div'); row.className = 'r'; const k = document.createElement('i'); k.style.background = s.c; if (s.dash) k.className = 'dash'; const b = document.createElement('b'); b.textContent = s.v[i]; const l = document.createElement('span'); l.textContent = s.l; row.appendChild(k); row.appendChild(b); row.appendChild(l); t.appendChild(row); });
    t.classList.add('on'); const w = t.offsetWidth, hh = t.offsetHeight; let x = e.clientX + 14; if (x + w > innerWidth - 6) x = e.clientX - w - 14; t.style.left = Math.max(6, x) + 'px'; t.style.top = Math.max(6, Math.min(innerHeight - hh - 6, e.clientY - hh - 10)) + 'px';
  }
  document.addEventListener('pointermove', move, { passive: true });
  document.addEventListener('pointerdown', e => { move(e); if (e.pointerType !== 'mouse' && cur) { clearTimeout(SJC._t); SJC._t = setTimeout(hide, 3200); } }, { passive: true });
  window.addEventListener('scroll', hide, { passive: true, capture: true });
  window.addEventListener('hashchange', hide);

  /* legend buttons hide / show a series */
  document.addEventListener('click', e => {
    const b = e.target.closest && e.target.closest('.sjc-lg'); if (!b) return;
    const box = b.closest('.sjc'); if (!box) return; const i = b.dataset.sjl; const on = b.classList.toggle('off');
    box.querySelectorAll('[data-s="' + i + '"]').forEach(el => { el.style.display = on ? 'none' : ''; });
    let off = box.dataset.off || ','; off = on ? off + i + ',' : off.replace(',' + i + ',', ','); box.dataset.off = off;
    const x = box.querySelector('.sjc-x'); if (x) x.parentElement.dataset.off = off;
  });

  /* charts animate only when a screen (or tab / filter) opens, not on every background refresh */
  if (typeof renderView === 'function' && typeof ui !== 'undefined') {
    const rv = renderView; let last = '';
    renderView = function (full) {
      let key = ''; try { key = [typeof view !== 'undefined' ? view : '', typeof MODE !== 'undefined' ? MODE : '', ui.rTab, ui.vTab, ui.pTab, ui.chan, ui.rp, ui.csMetal, ui.csP, ui.rpBook].join('|'); } catch (e) { /* ignore */ }
      SJC.animate = !!full || key !== last; last = key;
      try { return rv.apply(this, arguments); } finally { SJC.animate = false; }
    };
  }
  window.SJC = SJC;
})();
