# Shivaa Jewels software - handover report

Owner: Karan Soni, Shivaa Jewels, Jayal, Nagaur
Date: 11 November 2026

Use this file and the latest zip (shivaa-jewels-website.zip) to start the next chat. The sandbox files do not carry over.

## 1. What is built

The software is a self-hosted jewellery app: a vanilla-JS single-page app (index.html) plus a PHP backend (sj-api.php, SQLite by default or MySQL). It is installed by extracting the zip into public_html.

- **Logo:** Shivaa INC. is the default logo everywhere: sidebar, login, bill, rate card, tag, estimate PDF and browser icon.
- **Wholesale / Retail:** a Sector bar (All / Wholesale / Retail) on Dashboard, Invoices, Pakka/Kacha, Metal, Parties, Estimates, CRM, Ledger and Reports. GST reports are never split.
- **Category stock and profit:** separate stock per category and purity, valued at today's rate, with purchase and sale wastage and profit in fine grams and rupees. Checked with the owner's example: 2% bought, 5% sold, 500 g Silver 58 gives 15 g fine.
- **Gold and silver stock:** Vault stock tab has Gold and Silver tiles, a Gold / Silver / Dono filter, "Gold piece add" and "Silver piece add" buttons, and a metal picker in the Add Piece form (the purity list follows the metal).
- **GST bill:** Royal (black and gold) design in the PDF and on screen, with Ivory and Classic options. The PDF is A4 (210 x 297 mm).
- **Rate card:** Hindi PNG image, Post 4:5 and Status 9:16, with the booking call line (+91 89050 05921) and the shivaa.in line. Downloadable and shareable.
- **Analytics report:** interactive charts, Gold/Silver x Wholesale/Retail matrix, wastage profit trend, category donut, top parties, receivable ageing, calendar heat-map, rate history.
- **Target page:** 700 B2B + 1100 retail goal with progress, required pace, projection and milestones.
- **Automation:** daily stock snapshot, and alerts for old rates, tags pending, RFID untagged, low stock, dead stock, loss lines and unset wastage.
- **Edit and delete:** Setup -> "Sab entries - edit / delete" covers bills, payments, parties, pieces, expenses, estimates, rate history and day closings. Delete is limited to Owner and Manager on the server.
- **RFID:** UHF reader support (keyboard wedge). SKU to EPC encoding (ASCII hex padded to 24 hex). Print-time encoding for ZPL printers (^RFW) and an editable TSPL template. Auto-link after print.
- **Report Centre (new, this round):** Reports → "📚 Report Centre" holds 72 entries in 8 groups: sales, stock, metal & karigar, profit, parties, GST & tax, cash & growth, and CA / audit. 66 are built-in reports and 6 open existing screens. Each report has a period or as-on filter, honours the Sector bar and Pakka/Kacha, opens bills on click, and exports to Excel (.xlsx), CSV and PDF. The CA reports are trial balance, P&L with trading account, balance sheet (checked to balance), capital, loans, Form 3CD clause 35 stock quantities, stock valuation at the lower of cost or market, 40A(3), 269ST/PAN, 269SS, SFT 61A, TDS 194Q, advance tax, GSTR-9 month data, turnover reconciliation, bank stock statement, balance confirmation letters (PDF), salary, a fixed asset register with IT Act WDV depreciation (new collection `fixedAssets`), and a voucher register. "CA Pack" writes one workbook with 31 sheets for a chosen FY.
- **Fresh start / reset (new):** Setup → "Sab data mitao" is owner-only. It needs the owner password and the word DELETE. The server (`a=wipe`) first copies sj_docs to `sj_docs_bak_<UTC time>` and keeps the 3 newest copies. It then marks every record deleted with new sequence numbers, so all devices drop them on sync, and clears sj_history. It writes one audit line and sets an `epoch` that makes other open devices reload. Optionally it keeps settings, with opening balances and GST-filed marks cleared, and the customer/supplier list. Logins stay.
- **Installable app (PWA, new):** manifest.json, sw.js and 4 icons (192, 512, maskable 512, apple 180) were generated in gold on black from the logo. sj-pwa.js shows an install banner as soon as Chrome, Edge or Samsung fires `beforeinstallprompt`. "Baad mein" snoozes it for 2 days. iPhone Safari shows the Share → Add to Home Screen steps instead, and Setup has a "📲 App install" card. The service worker serves app files network-first, keeping a cache only for offline start. It never caches sj-api.php or sj-data. It updates itself, so a new zip no longer needs Ctrl+Shift+R. Chrome's installability check (CDP) reports no errors. Browsers always need one user tap to install.
- **Shivaa B2B parties (new):** the owner confirmed that every number is a B2B shop. All 188 WhatsApp numbers are B2B customers, as 170 parties: one party per shop, with extra numbers in Contact and `phones[]` and the role in `notes`. The list lives in `sj-data/sj-b2b-seed.php`, which shows nothing when opened directly, and `a=seed` serves it to an owner or manager. The server adds missing parties itself during the first `sync` (since=0) after an owner or manager logs in (`sj_seed_parties`, meta key `b2b_seed`). It uses fixed ids `c_b2b_<phone>` and skips any phone already present. The client-side import stays as a backup. The list version is `b2b-2026-11b`. When the version changes, auto-made `s_b2b_` suppliers that have no bills or jobs are removed. Setup has a "Check karo" button. A reset that clears parties also clears `b2bSeed`, so the list comes back.
- **Bullion purchase entry (new):** Bullion tab → "Bullion kharida" opens a form with date-time, supplier (new ones are created as Distributor), metal, form, weight, purity, rate per 10 g or per kg, Pakka/Kacha and several payments, each with its bank account and UTR. It creates a proper purchase bill (`v.bullion`) and, if ticked, a Vault product. A "Hisaab" view shows the payment timeline, with account-wise and supplier-wise totals and the report `bn_paylog`. More reports: `bn_summary` (month-wise), `bn_supplier` (bullion supplier ledger), `bn_stock`, `bn_kacha`, `bn_files` (attachments register) and `nw_payouts`. The Bullion screen has a "Reports:" link bar. The Report Centre now has 91 entries.
- **Business module (sj-biz.js, new):** this file adds four screens (Party 360, Loans & EMI, Bullion & Melting, Agents & Influencers) and 7 collections: agents, influencers, payouts, loans, meltLots, attachments, kachaRecs.
  - *Agents:* commission is % of the bill's taxable value (or its grand total). The agent and the % are stamped on the bill at save, so changing a party's agent later does not move old commission.
  - *Referral code:* a box is injected into the sale and estimate bill form. It puts customer% of making (labourAmt) into the flat discount and stores `v.ref` with the code, making, discount and payout. It hooks `persistInvoice`, which also stamps `agentId`/`agentPct`/`rm`.
  - *Loans:* EMI (reducing balance), interest-only, simple or none, with a schedule, a payment split and reminders on the dashboard.
  - *Melting lots:* select old-gold sources, then record sent and received. Loss and gram fees go into `metalEvents`.
  - *Books:* `deKey`/`deBuild` are wrapped to post loans, interest, payouts and refinery fees, and `moneyLines` is wrapped for the cash book.
  - *Attachments:* `a=file_put`/`a=file_get` store files AES-encrypted in sj-data/files (6 MB max, images compressed to 1800 px JPEG).
  - *Reports:* three new groups in the Report Centre (via `SJ_REPORTS.add`) and 6 more sheets in the CA Pack.
- **AI Assistant on the website (new):** the site's own window.claude has no `sample` capability. sj-biz.js now overrides `getSample`/`getLimits` (no tools) with a shim that posts to `a=ai`. `sj_ai_call` sends the request to the Claude Messages API with header `anthropic-version: 2026-10-21` (no temperature), model `claude-sonnet-5-5`, and `claude-haiku-5-5` for voice. The owner saves the key through `a=ai_key`, which tests it before saving and stores it encrypted in sj_meta. `a=ai_status` reports the state. The URL, model and version can be overridden in sj-config (`ai_url`, `ai_model`, `ai_model_quick`, `ai_version`). **Gemini (v16):** the owner can now choose provider Gemini (free key from aistudio.google.com) or Claude. Meta `ai_provider` stores the choice. Gemini uses `generateContent` with the `x-goog-api-key` header, `responseMimeType: application/json`, and default model `gemini-flash-lite-latest`; the URL can be overridden with `ai_url_gemini`. Because the Gemini free tier may use prompts for training, `sj_ai_mask` replaces phone numbers and PAN with placeholders before anything is sent. It was tested against a local mock, not the real API, because the sandbox has no network to api.anthropic.com. Each request is about 60 KB of business data.
- **Security (unchanged):** AES-256-GCM at rest, roles owner / manager / staff / viewer, write-once audit trail, HTTPS-only login, login throttling.

## 2. Testing

Earlier rounds: pro, pro2, silver, onscreen bill, roles, e2e, estimates, stock and packet passed. The old test scripts did not carry over to this chat.

This round (headless Chromium against the PHP built-in server on SQLite, with seeded data covering sales, estimates, metal, purchase, old gold, payments with cash over ₹2 lakh, expenses, bank/cash entries, karigar jobs, scheme, credit note, approval, hallmark and fixed assets):
- All 72 entries open without errors. All 66 built-in reports export to CSV and xlsx. PDF, xlsx and CSV downloads were checked on the balance sheet, 3CD, GSTR-1 and expenses reports.
- The CA Pack opens in openpyxl with 31 sheets. The balance sheet shows "Balanced". The confirmation letters PDF renders one page per party.
- Reset: a wrong password is refused, staff are refused (403), and "delete" in lower case is refused. The owner reset cleared the data and kept the settings, and a second open device emptied itself through the epoch reload. The backup table was created.
- Every main screen opens with no console errors. The phone layout (390 px) has no sideways page scroll.

## 3. Files

Latest zip: shivaa-jewels-website.zip (29 files, about 0.7 MB):

- index.html (inline script unchanged, so the CSP hash still matches; assets use ?v=15; the sw.js cache name is sj-app-v15, so bump both together)
- adv.css, adv.js
- sj-api.js, sj-api.php, sj-config.php
- sj-estimates.js, sj-stock.js
- sj-royal.css, sj-royal.js
- sj-pro.css, sj-charts.js, sj-insights.js, sj-pro.js, sj-bill.js
- sj-reports.js (new: Report Centre, CA Pack, xlsx writer, fixed assets, reset UI)
- sj-biz.js (Network, Party 360, Loans, Bullion & melting, attachments)
- sj-pwa.js, sw.js, manifest.json, icon-192.png, icon-512.png, icon-maskable-512.png, apple-touch-icon.png (installable app)
- PEHLE-PADHEIN.txt (Hindi install and user guide)
- sj-data/.htaccess, sj-data/index.html, sj-data/index.php, sj-data/sj-b2b-seed.php (party list; no database or key files)

Setup code for the owner's first login: B3TP-FS9G (set in sj-config.php).

**Important:** on a live install, sj-data holds the encrypted database and sj-key.php. Never overwrite or ship them.

Sandbox working files (not shipped): the scratchpad folder holds pro/patch_index.py (builds index.html and recomputes the CSP hash; always edit through it), pro/pro_src.css (source of sj-pro.css), and the test scripts. These do not carry over to a new chat.

## 4. Open items and known limits

- **TSPL RFID write command is unverified.** The manual could not be read. Settings -> Tag -> "RFID printer" has an editable {EPC} template. ZPL printers are supported by design. Test one tag before relying on it.
- **TE244 is print-only.** It cannot write RFID chips. Chips need an RFID printer, or tags are read and linked by hand.
- **Hindi font (Mukta)** loads from Google Fonts. Offline or blocked networks fall back to system Devanagari fonts.
- **Rates:** silver and gold values show "bhaav set karo" until today's rates are entered.
- **Not redesigned this round:** the rate card and the bill layout were verified, not redesigned.
- **Still open from earlier:** the Field Teams module, the supplier requirement message, and connecting Claude routines to website data.
- **Reports depend on entries.** P&L and the balance sheet use the double-entry engine plus closing stock from the vault at cost. Opening stock and a past year's closing stock are typed into the report (owner or manager), and the CA must check final figures. The yield in the 3CD report uses only completed karigar jobs. There are no AIS/26AS match and no PF/ESI reports, because the app has no data for them.
- **Attachments live outside the database** in sj-data/files. The server JSON backup does not include them, so the sj-data folder must be backed up as well. The reset keeps them on disk.
- **The global change handler swallows file inputs**, so sj-biz listens in the capture phase on window. Keep that pattern for new file inputs.
- **Reset on MySQL** uses `CREATE TABLE ... AS SELECT`. It was tested on SQLite only.
- **Not tested on real hardware:** a real TSC printer, a real UHF reader, a real hosting account, or MySQL. Testing used a headless browser against the PHP built-in server on SQLite.

## 5. How to continue in the next chat

1. Attach this report and the latest zip.
2. Say which area to work on first. Open choices: confirm the AI Assistant with a real key, a fresh rate card design, a bill redesign, Field Teams, RFID printer testing on the real printer, the supplier message, and filling GSTIN and address for the B2B parties.
3. For any change: prefer a separate sj-*.js file (as this round did). If the inline script in index.html changes, recompute the CSP sha256 hash. Re-test on a fresh copy, then rebuild the zip.

**Setup for a new install:** upload the zip, extract it into public_html (or a subfolder), open the site over https, enter setup code B3TP-FS9G, and create the owner login. Keep sj-data and sj-key.php safe. Back up with the app's Full backup and the sj-data folder.


## v17 — Shivaa AI "Jarvis" upgrade and the key-test hang fix

- **The hang:** the old `ai_key` test generated a reply through `generateContent`, and there were no time limits on the client or the server. On Hostinger the request could wait indefinitely, which left the screen stuck on "AI se test ho raha hai…".
- **Fix (server):** the key is now checked with `GET models`. This is fast and uses no quota (Gemini: `v1beta/models`; Claude: `/v1/models`, overridable with `ai_models_url`). Gemini's model list is saved in meta `ai_models`. "Auto" picks `gemini-flash-latest`, otherwise the newest stable `gemini-X-flash`. `sj_ai_http` now has a 12 s connect timeout, forces IPv4, and gives a clear timeout message; the check gets 25 s and each answer 100 s. `set_time_limit` is raised for the AI actions.
- **Fix (client):** `rawCall` accepts a timeout and has an `AbortController` (status 20 s, key 60 s, ask 180 s). The Setup card shows a live seconds counter. Its buttons were renamed `aikey-*`; the old `ai-save` collided with the chat's "Save bill" button.
- **Tool use:** `a=ai` accepts tools plus provider-neutral messages (user / assistant / assistant-raw / tool results) and returns `{text}` or `{calls, raw}`. Each provider's raw turn is passed back unchanged, which keeps Gemini's `thoughtSignature`; empty args or input are restored as `{}`. The browser runs the tools on its local data, up to 9 rounds. If Gemini hits a 429 or 404, the request is retried once on a lighter model (`sj_ai_lite`). Tool results are masked for Gemini.
- **sj-jarvis.js (new)** adds:
  - the bridge: `getSample` / `getLimits` with tools enabled;
  - 6 new tools:
    - `query_data` — any collection; `where` is JSON text, plus `sum`, `groupBy`, `sort` and `fields`;
    - `describe_data`;
    - `run_report` — any Report Centre id;
    - `calculate` — a safe parser, because CSP has no `unsafe-eval`;
    - `open_screen`;
    - `business_insights`;
  - Jarvis rules appended to `agentRules`;
  - `agentData` extended with `collections`, `reportCatalogue` and `screens`;
  - `mdLite` extended with tables, headings, italics and code;
  - new suggestion chips and a greeting;
  - the top-bar ✦ button: tap opens the AI, press and hold starts voice; Ctrl+J also opens the AI;
  - the Setup card.
- **Tests:** done against local Gemini and Claude mocks (the sandbox cannot reach the real APIs). All 15 tool schemas pass Gemini's schema rules (no `object` without `properties`). Regression passed: smoke, 84 report exports, PWA, biz and bullion.


## v18 — more AI powers

- **New tools (now 19 in total):**
  - `whatsapp_draft` — fuzzy-matches the party (customers and suppliers); if several match, it returns the candidates.
  - `make_chart`
  - `sales_forecast` — this-month projection = so far + (0.6·avg30 + 0.4·avg7) × days left, plus a 90-day regression trend and the best weekday.
  - `collection_plan` — score = due × (1 + age/30).
- **Answer extras:** a tool output that should appear under the answer is pushed to `EXTRAS` and appended by the browser as the markers `[[wa|phone10|msg|name]]` and `[[chart|title|unit|label=value;…]]`. Fields are URI-encoded, and any marker the model types itself is stripped. This way phone numbers never pass through Gemini. `mdLite` renders the markers as a WhatsApp card with a send button, or as CSS bars.
- **Rules:** an "expert" cross-check rule and when to use each new tool.
- **Chat redraw:** the chat is redrawn after load, so history saved with markers renders correctly when the page opens on `#assistant`.
- **Hands-free wake word:** a per-device opt-in (`localStorage sjx_wake`) using continuous SpeechRecognition. Saying "shivaa" / "shiva" / "jarvis" (or शिवा / जार्विस) followed by a question sends it; the wake word alone starts voice mode. Listening pauses while voice mode is on or the tab is hidden, and stops for a day if mic permission is denied. A green dot appears on ✦ while it listens.


## v19 — "2050" pack (`sj-2050.js` and `portal.php`)

### Server (`sj-api.php`)
- **Vision:** `a=ai` accepts `images` (≤3, base64 JPEG/PNG/WebP, max 5.5 MB) on user messages. Gemini receives them as `inlineData` parts and Claude as `image` blocks.
- **Alerts:**
  - `sj_alerts_for()` runs inside `batch` for every non-owner user. It catches:
    - invoice delete
    - invoice edit (payable Δ>₹1, payments reduced, party or date changed)
    - rate change (`gold24`/`silver999`)
    - product weight edit
    - any delete
    - night entries (22:00–07:00 IST)
  - Alerts are written by `sj_put_docs()` as encrypted docs in the `alerts` collection.
  - `sj_check_op` blocks non-owners from writing to `alerts`, and `sync` skips `alerts` rows for non-owners.
  - Email goes through PHP `mail()` to meta `alert_email`, at most 60 per day. It is set with `a=alert_cfg` / `a=alert_status` (owner only).
- **Portal:**
  - `portal.php?t=TOKEN` maps to the GET `a=portal` route and `sj_portal_page()`.
  - It looks the token up across customers (`portalToken`, not `portalOff`) and renders standalone HTML with a strict CSP.
  - Contents: due, billed and paid totals; fine due; today's rate; sale orders with a 5-step bar; schemes; bills (estimates only when `portalKacha`); payments.
  - Bad tokens are throttled per IP (20 per 15 min, key `p:<ip>`, kept separate from login throttling).

### Client (`sj-2050.js`)
- **Chat photo:** 📷 button and preview chip. `window.SJX_TAKE_IMG` is read by the jarvis bridge.
- **Visual search:** dHash plus a colour histogram on Vault `p.photo`. Available as a Vault button and as the `photo_stock_match` tool.
- **`check_entry` tool:** runs `specToState` / build* validators, and the rules force a call to it before any action.
- **New action types** (pushed into `ACTIONS`):
  - `receive_payment`: allocates oldest dues first, takes a bank match, and saves payments on the invoices.
  - `update_order_status`.
  - `add_bullion`: opens and fills the bullion form.
- **`RECORD_COLS` extended:** customers `dob`/`anniversary`/`email`/`notes`; orders `status`/`dueDate`/`priority`/`notes`.
- **`save` wrapper:** stamps `orders.track` and shows a WhatsApp update flash.
- **Dashboard cards:** alerts (owner) and today's occasions with offer/scheme wish and `wishLog`.
- **Party 360 portal bar:** make, renew, off, kacha toggle, copy, WhatsApp.
- **Reports:** `stock_advice`, `alerts_log`.
- **Setup:** alert email and Notification permission.
- **More AI tools:** `stock_advice`, `customer_portal_link`, `todays_occasions`, `recent_alerts`.

### Not possible without paid services
- Fully automatic WhatsApp sending needs the WhatsApp Business API, so this build uses one tap.
- Push notifications when the app is closed need Web Push plus VAPID, so this build uses email.


## v20 — `sj-2050b.js` plus server additions

### Bill lock
- `sj_lock_check()` is called from `sj_check_op` for every non-owner write to `invoices`. The lock age is taken from `createdAt`, or from the bill date at 23:59 IST if there is no `createdAt`.
- After `bill_lock_hours` (stored in meta, default 24, 0 = off; set through the owner-only `lock_cfg` action, `lock_status` for everyone), the following are rejected:
  - delete
  - any change to items, totals, party, date, type, no, oldMetal, discount, roundOff, book, creditDays, gstMode, pos, splits, received or payMode
  - removing a payment, or changing a payment's amount, date, mode or fine
- Still allowed on a locked bill: adding a payment, and changing a payment's bank.
- Every rejected attempt writes a `lock_try` alert.
- The client wraps `persistInvoice` to show the message before it reaches the server.

### Cash-difference alert
- In `sj_alerts_for`, a `closings` record with |diff| ≥ meta `cash_alert_min` (default ₹100) raises an alert, but only when the record is new or its diff changed.
- The client `save` wrapper stamps `by` / `byRole` and the `denoms` from the note counter.

### Mistake checks
- `advGuard` is wrapped to add:
  - the party's median wastage and labour from the last 60 bills
  - mismatch with the party's `findRule` matrix
  - weight typos (≥8× the usual weight, or ≥1 kg)
  - purity vs tunch differing by 3 points or more
  - less ≥ 50% of gross
  - price per gram more than 15% away from the 30-day median
  - rates not updated today
  - an edit of a locked bill
- The AI's `check_entry` merges these through `SJX_EXTRA_CHECKS`.

### New reports
- `cash_milaan`: closings, notes counted, and days not closed.
- `karigar_score`: per karigar — issued and received metal, real ghatt vs allowed wastage, labour, on-time %, average days, balance and score; plus job lists.
- `ca_month`: composite of pnl, gstr3b, itc, cashbank, outstanding, payables, stockval, expense, cash2l, cash40a3, cash milaan and alerts. The AI advice is stored in the `caNotes` collection. The report is also added to the CA pack.

### UI cards
- Karigar score-card.
- Dashboard CA card on days 1–10 of the month (owner only).
- Setup card for lock and cash settings.

### AI tools
- `karigar_hisaab`, `cash_milaan`, `bill_lock_info`, `ca_month_report`.


## v21 — security and bug audit

### Method
- **Code review** of `sj-api.php`: auth and session, roles, `check_op`, `file_put`/`file_get`, export, history, wipe, users, AI, portal, lock and alerts.
- **XSS crawl** with hostile names (`<img onerror>`) placed in customers, suppliers, products, expenses, notes, orders, karigar jobs, an invoice and chat (markdown tables, headings, code, charts, WhatsApp markers).
  - Coverage: all 23 views, 141 sub-tabs, 96 reports and 5 forms.
  - Run on desktop and at 390 px, as owner and as staff.
  - Result: **0 XSS executions**.
- **API tests** of permissions and the lock.
- **PHP log scan:** no warnings or notices.

### Fixed
1. Lock bypass by resetting `createdAt` — `id` and `createdAt` were added to the lock denylist.
2. Negative payment or fine on a locked bill is now rejected, as are malformed payment rows.
3. Staff could change `portalToken`/`portalOff`/`portalKacha` — now owner and manager only (server-side).
4. A manager's `export` included owner-only `alerts` — they are now skipped for non-owners.
5. Prompt-injected `[[wa|…]]` / `[[chart|…]]` markers in AI replies are always stripped, so only the app's tools add them.
6. The `customer_portal_link` AI tool is limited to owner and manager.
7. `SJ_REPORTS.open()` and `reportBody()` crashed on link-only reports (`tagsrfid`, `partyledger`, `gstscreen`, `cashbook`, `targetpage`, `ledgers`, `party360`) — they now follow `R.link`.
8. Mobile overflow on the Karigar score-card — the table now scrolls inside its card.

### Verified OK
- Password hashing; HttpOnly + SameSite=Strict cookie; login throttling.
- Every API needs a login; the X-SJ header blocks CSRF.
- AES-GCM at rest; `sj-data` returns 403/404 and the key file self-guards.
- Role checks for staff, viewer and owner-only actions.
- The audit trail is write-once.
- The portal has a strict CSP, `no-referrer`, a token throttle, and estimates hidden by default.


## v22 / v23 — sample PDFs, PDF emoji fix, bill design, estimate book

- **v22:** `Pdf.prototype.text`, `width` and `wrap` are wrapped (in `sj-2050b.js`) to strip emoji, because the built-in PDF font printed them as "??".
- **v23, `sj-bill.js` `royalInvoicePdf`:**
  - A rate strip appears on sale and estimate bills: 24K, 22K (= 24K × 0.916) and silver. It uses the current settings for today's bills and `advRateAt` for older dates. The strip also carries a gross / net / fine summary.
  - A BIS-style price breakup appears on retail sale and estimate bills: HUID, net, purity, metal value (net × tunch/100 × rate), making + wastage (the remainder), stone + HM, and amount. Up to 10 rows.
  - Both blocks are included in `tailH`, so pagination still works.
- **Bug: new estimates were filed in the Pakka book.**
  - Cause: `persistInvoice` defaulted `quality` to `pakka`, and the builder defaulted `INV.quality` to `pakka` for every bill type.
  - Fix: an `openInvoice` wrapper sets `kacha` for new estimate and estpurchase bills, and a `persistInvoice` wrapper does the same unless the user touched the quality select (`_qualityTouched`). The AI path is covered too.
  - Existing data is not migrated.
- **Open question for the owner:** `BILL_MAIN.name` in the inline script is "SHIVAA JEWELS PRIVATE LIMITED", while the default `settings.legal` is "Ernate Shine Jewellery Pvt. Ltd." Both appear with the same GSTIN and CIN. Confirm the correct legal name.

## v24 — Signature bill as the default PDF

- `sj-billx.js` (new): `signatureInvoicePdf(v)` draws each A4 page on a 2480×3508 canvas (300 DPI) and embeds it as a JPEG (quality 0.96) in the app's `Pdf`. Bundled OFL fonts in `fonts/` (Lora, Poppins), loaded with FontFace and pre-warmed 4 s after start.
- Wraps `invoicePdf`, so download and share both use it. Falls back to the previous design if rendering throws (with a toast).
- Style: `SJ_BILLX.styleNow()` → `signature` unless the owner picks a style in Setup after v24 (`settings.pro.bsV24`). `proCfg` default is now `signature`; the select lists Signature first.
- Long titles (Old Gold Purchase Voucher, Metal Account Voucher) wrap to two lines.
- Promo coupon only on customer-facing bills (not purchase / metal).
- `sw.js` caches `sj-billx.js` and the six fonts (cache `sj-app-v24`).
- Tested: sale, estimate, purchase via `downloadInvoicePdf`; metal, oldgold, estpurchase via `invoicePdf`; style switch; smoke, reports (89 exports), pwa, t2050c, crawl.

## v25 — privilege, verify QR, girvi, backups, 2-step, camera scan

- `sj-2051.js` (new): privilege auto-discount (wraps renderInvParty / refreshTotals / persistInvoice; `invoice.privilege = {id, pct, amount, making}`; report `privilege`), WhatsApp light PDF button, e-way bill Part-A JSON (`SJX_2051.ewbJson`), camera scan via BarcodeDetector on `#scan-q`, `#aud-in`, `#rf-in`, AI rate button in `openRates` + morning prompt (`localStorage sjx_rate_prompt`), Setup cards (2-step, backups, portal catalogue), portal-request dashboard card, Girvi view (`girvi` collection, simple monthly interest day-wise, min months, PDF receipt), AI tools `girvi_summary`, `privilege_info`, `portal_requests`.
- `sj-billx.js`: `signatureInvoicePdf(v, {lite, noVerify})`; verify QR in the footer (`verify_tok` → `verify.php?i=&k=`, HMAC of the id with the data key); coupon only on retail bills; "Privilege 20% making" row label.
- `sj-api.php`: `verify` GET route + `sj_verify_page`; TOTP (`totp_status/init/enable/disable`, login `otp`, replay-safe, 8 hashed backup codes, `disable_2fa` config bypass); daily auto-backup after the first sync of the IST day (`sj-data/backups/sj-auto-YYYY-MM-DD.json.gz`, encrypted rows, 14 daily + 12 monthly), `backup_list/now/get/cfg`, weekly email; `ai_rate` (Gemini google_search grounding / Claude web_search); portal catalogue (`catalog_cfg/status`, signed same-day nonce, `portalReqs` + `portal_req` alert, 10 requests/customer/day); `privilege` locked with the bill.
- `verify.php` (new), `portal.php` now accepts POST. `sj-api.js`: OTP step on login; `SJ_API_CALL(action, body, ms)`.
- Tested (`tests/v25.js`): privilege apply / toggle / save / report, verify genuine / tampered / deleted, lite PDF ~300 KB vs 2.1 MB, e-way JSON, AI rate via mock, camera fallback message, girvi interest maths (₹1.5 L × 1.5% × 134 d = ₹10,050; split payment), backup + decrypted export + traversal block, portal catalogue + request + forged nonce, 2-step enable / wrong / correct / backup-code disable; regression smoke, reports (90), pwa, bullion, j2, t2050c, crawl; mobile 390 px no overflow.

## v28 — vouchers, referral, review, item QR, AI KYC, insurance, weddings, staff targets, sizes, portal locker

- `sj-2052.js` (new): collections `vouchers`, `weddings`; views `shaadi`, `gifts`. Money in for voucher sales / wedding advances is a `banktx` (`cashin` / `receipt`, source "Advance from customer"); redemption is an invoice payment with mode `Gift voucher` (added to `NON_MONEY`) or `Advance` (wedding). Referral: `customers.refCode`, `customers.referredBy`, `invoice.referral`, reward voucher `source:'referral'`; cfg `settings.pro.referral` + meta `referral_cfg` (portal text). Review: `settings.pro.reviewUrl`, `invoice.reviewAsked`. Sizes: `customers.sizes`. Insurance: `settings.pro.insurance`. Staff targets: `settings.pro.staffTargets` (sales by audit `create` author). AI tools: customer_sizes, gift_vouchers, wedding_packages, staff_targets, insurance_status, referral_info.
- `sj-api.php`: `sj_portal_locker` (portal: locker, vouchers, referral code); `item` GET route + `sj_item_page`, `item_tok`; `referral_cfg`; voucher rules in `sj_check_op` (no negative balance; non-owner cannot top up or change code / amount / dates); portal catalogue CSS fix (v25 bug: images overflowed on phones).
- `item.php` (new).
- Tests: `tests/v28.js`, `v28b.js`, `negv.js`, `mob28.js`; regression smoke, reports (90), pwa, bullion, j2, t2050c, crawl, staff crawl, v25, v26.

## v29 — Shaadi package v2

- `sj-shaadi.js` (new) replaces the v28 wedding code in `sj-2052.js` (only the menu entry stays there). Old packages are normalised on read (`norm`: item ids, metal, advance type).
- Model: wedding `{…, makingPct, gstPct, side, items[], advances[], used[], billed[]}`; item `{id, name, metal, purity, qty, unit, wMin, wMax, photos[{src}] (≤4, 1000px JPEG), productId, custom{size,length,stone,meena,finish,engraving,back,other}, makingPct, labour, stone, extra, status, karigar, due, actualGross, actualLess, huid, billed, billNo}`; advance `{type:'cash', amount, mode, btxId, lock{metal, rate, fine}}` or `{type:'metal', metal{metal, desc, gross, tunch, fine}, usedIn}`.
- `calc(w)`: per metal fine need = net × (tunch + making)/100; locked fine first at the average locked rate, rest at today's rate; GST; balance = total − free cash advance − old-metal credit.
- Bill: opens the sale builder with items (manual flags set), blended rate per metal, old-metal lines; `persistInvoice` wrapper marks items billed, records lock use and old-metal use, and adds an `Advance` payment for the free cash advance.
- Package PDF on the Signature kit (photos, customisation, bhav cutting, hisaab, terms, sign). Advance / bhav-cutting receipt PDF (A5).
- Fixed on the way: the app's global file handler empties file inputs after `change` — the item form now captures files in a capture-phase listener.
- Tests: `tests/v29.js`, `mob29.js`; regression smoke, reports (90), pwa, crawl, staff crawl, v26, v28b.
## v32 — Mera sapna, naya andaaz
- Targets banner: live countdown (din/ghante/minute/second), gold progress ring, bikri ki raftaar se Dhanteras tak ka andaaz, lakshya (₹) ke hisaab se aage/peeche, padaav ki timeline.
- Setup → Mera sapna: bikri lakshya aur apne padaav (`YYYY-MM-DD | naam`).
- Mobile par photo upar, phir ghadi, phir hisaab.

## v33 — "This is Shivaa's Showroom in 27 October 2027"
- Banner, dashboard card, photo label aur Setup card se "Mera sapna" hataya; nayi headline: COMING SOON · This is / Shivaa's Showroom / in 27 October 2027 (gold gradient).

## v34 — Showroom banner motion graphics
- Canvas gold-dust + sparkle layer (rAF, pause when tab hidden, off for prefers-reduced-motion), rotating light rays, title shimmer, staggered entrance, flip countdown digits, ring/timeline draw-in, photo float + Ken Burns + glare + rotating halo; dashboard card shimmer.

## v35 — Nayi showroom photo
- User ki nayi photo (bina pole): taaron ka saaya hataya, shaam ka aasmaan gehra, LED glow, clarity; vision-shop.jpg / -sm.jpg badle.

## v36 — Final showroom photo
- User ki nayi raat wali photo (Lakshmi ji board, 3 floor) vision-shop.jpg / -sm.jpg mein; mobile par photo poori chaudai mein, tiles overflow fix.

## v37 — Target 🎯 page par "Manzil"
- Retailers + Customers mission hero mein showroom photo (MANZIL tag, chamak, tairna), "This is Shivaa's Showroom · in 27 October 2027 · X din", "Sapna dekho →". Computer par beech ka column, tablet par countdown ke bagal, mobile par alag patti. Reports → Party growth mein bhi.

## v38 — "Sapna" shabd hataya
- UI, toasts, Setup form, milestones aur AI rules se "sapna" hataya; ab "Showroom dekho →", "Safar shuru hone se bikri", "Udghatan ki tareekh".

## v39 — Gemini "high demand" (503) se bachaav
- sj_ai_http: 500/502/503/504 ya "high demand/overloaded/unavailable" → `ai_busy`.
- sj_ai_call: same model 1 retry (1.5s), phir fallback chain (sticky 15 min model, lite, numbered flash/flash-lite, aliases), 95s budget; busy/limit error ko priority. Key-bad / prompt-too-large par turant ruk.
- SJ_AI.ask: network drop (`unavailable`) par 2.5s baad ek auto-retry.

## v40 — Offline mode + Roz ki report
- **sj-api.js**: IndexedDB `sj-offline` (stores `docs` key `uname\x01col\x01id` → JSON, `kv` meta:/ob:). Device copy written after full pull (`OFF.online`) and incrementally (`OFF.touch`, 1.2 s debounce). Outbox `OB`: network/timeout failures (`unavailable`/`timeout`) resolve writes immediately and persist ops in order; `flushOutbox` resends (45 s timeout), splits batch on server refusal, drops rejected docs locally after a full re-pull, fires `sj-outbox-sent`. `summary`/`tagState` collapsed in outbox; audit/summary not counted for the user. Offline boot when `status` fails and a copy exists. Logout / logout-all wipe the copy. Pill: amber when data is safe offline. Batch calls now have a 45 s timeout.
- **sj-offline.js**: Setup card; duplicate bill-number detector (firm + no) with "Naya number do" (keeps `renumberedFrom`); never opens over another modal.
- **sj-roz.js**: daily report image (canvas 1080 px, Lora/Poppins) + WhatsApp text from `dayClosing()`; dashboard card, Close-the-day button, once-a-day nudge, settings `pro.rozPhone/rozAuto/rozNames`, Jarvis tool `daily_report`.
- **sw.js**: `V` constant; SHELL built from it (old SHELL was stuck at ?v=31).
- **sj-2050b.js**: lock_status only after login (removed a 401 on the login screen).
- Tests: offline save → reopen offline → online flush → 2nd device sees; server-refused op dropped; reopen-online flush; dup renumber; logout wipe; reports 90, crawl, staff crawl, pwa, smoke, v29.

## v41 — Field, 3 floors, server-enforced security
**Server (sj-sec.php, loaded by sj-api.php; schema 3 → sj_tokens.dev/elev, sj_chain, sj_gps)**
- Policy `sec_policy` (hours, devices, pin, totpAll, dayLock, exportOwner, floorWall, maskPii, discStaff/discMgr, ogStaff, idleMin, fieldMax/fieldTwo, tolG/tolPc, radius); per-user `uext:<id>` (pin hash, floor, field, anyHours); per-user TOTP `totp:<id>` (owner keeps `totp`); enrollment ticket on login (`totp_setup` → `totp_enroll`).
- Device cookie `sj_dev` (HttpOnly, SameSite=Strict) → `devices` meta; pending/ok/blocked; blocked kills sessions.
- Rules in `sj_sec_check`: PIN elevation (5 min, `sj_tokens.elev`) for deletes outside SJ_PIN_FREE; `sjReqs` maker-checker with server HMAC token (`apr|kind|ref|val`), manager limit, no self-approval; discount/old-gold bound to `discKey|partyId|round(itemsTotal)` / `ogKey|partyId`; day lock; floor wall; challan ownership / closing / issue limits; `fieldConfirms` server-only.
- Alerts (`sj_sec_alerts`): field entry/exit/seal/far/override/panic/short/waive, manual weight, floor transfer short, audit missing, gate alarm, new device, off-hours, PIN lock, export, policy.
- Tamper chain: HMAC(prev|at|ops) per write batch (batch, put_docs, b2b seed; genesis on upgrade and wipe); `chain_verify` reports broken links, changed and missing records.
- GPS: gps.php (OsmAnd query + Traccar JSON), `loc_push`, `gps_live`, `gps_track`, `gps_cfg`; 8 s rate limit, 120-day retention.
- RFID gate `rfid_push` (key), retailer confirm page `confirm` (signed link + nonce), `cron` (backup, backup mail, late challans, gps cleanup), `keys`.
- Fixed: `sync` paging ended early for non-owners when alerts were skipped (could miss records).
**Client**: sj-scan.js (scan session, keyboard-wedge/serial/camera, weight tolerance, Web Serial kaanta + ⚖, wSrc on bills, RFID bind, SJ_ASK / SJ_CONFIRM dialogs) · sj-guard.js (Suraksha card, policy, devices, staff rules, PIN, my 2-step, keys, chain check, approvals + inbox, idle lock, PII mask, Rakhwala report) · sj-floors.js (device floor, stamps on new bills/stock, transfers, tally, floor-wise view) · sj-field.js (challan, custody, 5-step visits, memo creation, confirm link / signature, panic, return, waive, parchi image) · sj-control.js (OSM map without libraries, control room, GPS devices, cameras). sj-api.js: ApiError.data, PIN prompt on `pin_required`, 2-step enrollment, off-hours screen, `SJ_SEC`.
- CSP: img-src + tile.openstreetmap.org, frame-src + https: (camera pages).
- Tests: v41api (≈50 server checks incl. tamper), v41ui (floors, full field day on phone + desktop, approvals, lock, mask, control room), plus smoke / reports 90 / crawl / staff crawl / pwa / v29 / v40 offline.

## v42 — Smart Dukaan, Showroom, Sehat, field hardening, law rules
Company name confirmed by the owner: **SHIVAA JEWELS PRIVATE LIMITED** (already `BILL_MAIN.name`; the open question from v23 is closed).

### Server
- `sj-v42.php` (new, required after `sj-sec.php`; `sj_v42_route($a)` runs after `sj_sec_route`).
  - **Telegram**: meta `tg` {chat, level high|all, backup off|day|week, health, on, bot, chatName}; token in `tg_tok` (encrypted). Routes `tg_status`, `tg_cfg` (getMe check), `tg_find` (getUpdates → chat), `tg_test`, `tg_backup_now`. `sj_alert_mail()` calls `sj_tg_alerts()` first; `sj_sec_alert()` sends non-high levels via Telegram too. 300 messages/day cap. URL override `tg_url` in sj-config (tests use a mock on :8096).
  - **Offsite backup**: `sj_bk_seal()` = `SJBK1|salt16|iv12|tag16|ct`, AES-256-GCM, key PBKDF2-SHA256(password, salt, 150000). Password stored encrypted as `bk_pass`. Content = `sj_bk_export()` gzipped (normal restore file). Browser opens it in Setup → 🩺 → "Telegram backup kholo" (WebCrypto + DecompressionStream).
  - **Law**: `sj_law_check()` (from `sj_sec_check`, non-owners): 269ST — cash per bill ≥ ₹2L, or same party same day across bills ≥ ₹2L (scans invoices only when cash increases); 114B — sale/estimate payable ≥ ₹2L needs partyPan / partyGstin / `form60` on bill or customer (`pan`, `gstin`, `form60`). Errors `law` / `law_pan`. Policy keys `cash269`, `panRule` (default on).
  - **CA login**: `uext.until` (YYYY-MM-DD); `sj_user()` and login refuse after it (`expired`). Routes `login_until`, `login_untils`.
  - **Emergency access**: meta `emerg` {uid, hours 24–168, req}. Any owner request auto-cancels a pending request (`sj_emerg_owner_seen` in `sj_user`). `emerg_take` after the wait: sets the owner password, clears owner TOTP + sessions, high alert.
  - **Health**: `sj_health()` (backup, cron, restore test, chain, disk, errors, telegram, owner 2-step, PIN policy, https), `health`, `restore_test` (decrypts a sample of the latest backup), cron monthly restore test, weekly chain verify (before 6 am), nightly health alert / Telegram OK message.
  - **Error log**: meta `errlog` (150, grouped by signature, 30/hour/user); `err_log`, `err_list`, `err_clear`.
  - **Tijori**: `tijori_open` {kind open|close, uname/pin, uname2/pin2, why}; open needs 2 different users (owner/manager or `uext.keyholder`); writes collection `tijoriLog` (server only) + alert. `keyholder` route.
  - **Field**: `conf_hash` (PBKDF2 10k of an 8-char code shown on the confirm page after "Haan"); collection `fieldCodes` hidden from staff in `sync` / `export`, writable only by owner/manager; `fieldPhotos` write-once for staff; challan `codeH` / `creditOk` protected like `diffOk`; `sj_gps_watch()` (stay alert, `stayMin`), `sj_noloc_cron()` (`noLocMin`, 9:00–21:00 IST).
  - New policy keys in `sj_pol()`: `cash269, panRule, fieldPhoto, creditBlock, stayMin, noLocMin`.

### Client
- `sj-field.js`: photo proof (entry before the seal, exit before the scan; separate `fieldPhotos` docs, 720 px JPEG stamped), offline codes (8 per challan, PBKDF2 20k with salt `sjfc|<challanId>`), `manzoori()` = online request → else code, retailer code confirm, bill-at-shop (`billApproval`), udhaar check on route + issue (owner PIN override), AI challan sujhav, 📈 Score tab (staff + retailer A/B/C). `SJ_FIELD` exports `codeOk, credit, shopProfile`.
- `sj-smart.js` (new view `smart`): Malik ka 1 minute (+ dashboard card), fine gold position, aging, risk score (audit + alerts + discounts), weight spy, karigar ghatt (`pro.ghattMax`), reorder + season (same 60 days last year × growth), making %, supplier cost / tunch, incentive (`pro.incentive`). Jarvis tools: malik_minute, fine_gold_position, old_stock, staff_risk, weight_spy, karigar_ghatt, reorder_season, making_supplier, staff_incentive.
- `sj-dukaan.js` (new view `showroom`): token (`qTokens`), kisht (`emis`, payments go into the bill), gaadi (`vehLog`), tijori UI, TV mode (`pro.tvOffers`, `pro.tvSec`), machine test, purity parchi (`purityTests`). Setup cards: 🩺 sehat (Telegram, health, errors, restore test, backup open, emergency, CA, keyholders), 🎓 practice, ✅ Setup sahayak (also on the dashboard until complete). `persistInvoice` wrapper: PAN / Form 60 prompt (saved on the customer) and 269ST check before save.
- `sj-api.js`: practice mode (`sessionStorage sj-practice`): `enqueue` no-op, IndexedDB copy untouched, only read-type API actions allowed, banner. Global error → `err_log` (max 25 / session).
- `sj-guard.js`: policy form has the new toggles and stay / no-location minutes.

### Already there before v42 (not rebuilt)
Item QR "janam patra" (`item.php`), customer portal + catalogue + order request (`portal.php`), order / repair tracking, occasions / wishes, rate card image, UPI "Scan & Pay" QR on the bill, Tally XML + GSTR-1 + CA pack, photo visual search, insurance, Shaadi package, gold schemes, Hindi voice in Jarvis.

### Tests
- `tests/v42api.js` (all pass): 269ST single / same-day / owner, PAN / Form 60 / manager, CA end date, tijori (2 PIN, same person, wrong PIN, keyholder, forged log), field codes hidden + protected, photos write-once, retailer code ↔ hash, Telegram (token checks, chat, test, encrypted backup decrypts in Node, wrong password fails, panic reaches Telegram), health / restore test / error log, GPS stay + no-location (cron), emergency access full cycle.
- `tests/v42ui.js`: dashboard cards, 10 Smart tabs, token / TV / kisht / gaadi / tijori / machine test / purity parchi, PAN prompt, Setup cards, practice mode (nothing saved), field: AI sujhav, 8 codes, staff entry photo, retailer code while the staff phone is offline (outbox flushes later), bill at shop, exit photo, offline code on the phone, owner sees both photos, Score tab, phone layout.
- Regression: v41ui (with `fieldPhoto: false`), v41api, smoke, reports, pwa, crawl, staff crawl, v40off, v40dup.

### Limits
- Telegram, the real cron and offsite backup were tested against a local mock, not the real Telegram API.
- Telegram backup must stay under 45 MB.
- Emergency access hands over the owner account; choose the person carefully.
- Hindi / English switch for the whole software and multi-branch were not built (floors cover the 3-floor showroom).

## v43 — Showroom TV redesign (`sj-tv.js`)
- New file `sj-tv.js` (`window.SJ_TV = {start(opt), close, rates, slides}`); `sj-dukaan.js` `tvStart()` delegates to it and the old `tvHtml` + `.dk-tv` CSS are removed. `start({ full: false })` skips fullscreen (used for recording).
- Static DOM built once, then live parts update in place: rate odometers (per-digit rolling strips), change vs the last `rateHistory` day before today, 10-point SVG sparkline with draw-in, spotlight cycling card, flash banner on rate change (polls `settings()` every 4 s), crossfading A/B slide layers with Ken Burns, progress bar + dots, live clock with seconds, countdown slide, token "Ab ki baari", seamless marquee, canvas gold dust, rotating rays, animated conic border, wake lock, 60 s burn-in shift, cursor auto-hide, portrait layout (`max-aspect-ratio:1/1`).
- Settings: `pro.tvTag` (new), `pro.tvOffers`, `pro.tvSec`. Logo is recoloured to gold with a CSS filter.
- Uses `div`s, not `main`/`header`/`footer`, because the app styles `main` (max-width).
- Tested: landscape 1600×900 and portrait 900×1600 screenshots, a 29 s recording with a live rate change, v42ui, smoke, crawl.

## v44 — TV display: no blinking on tablets
- Owner's tablet video showed digits / header / cards disappearing (GPU tile drops). Causes: `background-clip:text` on rolling digits + masks, animated `background-position` on the name, `@property` conic border repaint, `left` sweep animation, `mix-blend-mode` logo, huge rotating conic rays, per-frame radial gradients in the dust canvas, and the app's own canvases / aurora still running behind the overlay.
- Fix (`sj-tv.js`): only transform / opacity animations; solid gold text; odometer `translate3d` without masks; static border; sweep only on the highlighted card via transform; progress bar via `scaleX`; marquee edge fades via overlays (no mask); dust from one pre-drawn sprite at ≤30 fps with fewer particles; logo recoloured to gold once on a canvas; drifting glows instead of rays. `html.tv-on` hides the app (`display:none`) and pauses `sj-royal.js` / `sj-vision.js` canvases and the body aurora.
- Modes: `pro.tvFx` = auto | full | lite. Auto starts `tv-mid` on touch / ≤4 GB devices and switches to `tv-lite` if rAF falls below 42 fps in the first seconds (`ov.dataset.fps`).
- Measured under 6× CPU throttle: 8 fps (v43) → ~50 fps full, 60 fps lite; layouts 86 → ~12 per 8 s.

## v45 — Silver box / peti / counter tray (`sj-lot.js`)
- Collections `boxes` {no, design, purity, pcs, gross, tare, avg, rfid, labour, loc}, `petis` {no, team, staffUids, boxes, seal, status out|back|short, log[{k start|pre|post|end|check, w, exp, diff, ok, seal, sealBad, shop, lat, lon, photo}], sales[{partyId, lines[{boxId, pcs, w}], w, pcs, type estimate|metal}], checks}, `trays`, `trayLogs` (id `<tray>_<date>`, open/close/hand with exp vs counted).
- Expected peti weight = last weigh − sales after it; tolerance `pro.lotTol` (1.5 g). Mismatch / seal change → `lot_alert` route (new, `sj-v42.php`, throttled) → `sj_sec_alert` → Telegram.
- Sale opens the normal invoice builder (`estimate` for money, `metal` for fine silver) with one item per box; boxes are reduced at "pakki".
- AI via `SJ_AI.ask` with `images`: scale display reading and box slot counting (advisory). Jarvis tool `silver_peti`.
- `sj-tv.js`: `?tv=1` auto-starts the TV after login.
- Test `tests/v45ui.js` (boxes, peti, sale 15/30/60 by weight, bill lines, short peti alert, box-wise find, tray open) + smoke.

## v46 — full regression + hardening
- `sj_lot_guard()` (sj-v42.php, called from `sj_sec_check` for staff): no create/delete of boxes / petis / trays; box only `pcs`/`gross` down; peti `boxes, staffUids, tare, no, date, status` fixed and `log / sales / checks` append-only. Test `tests/lotapi.js`.
- `sj-lot.js`: weigh / scale photos saved as `fieldPhotos` docs (write-once), peti keeps only ids.
- `SJ_CONFIRM` now escapes the message (keeps `<b>` and line breaks) — closes an HTML-injection path through names.
- Regression run: v45ui, v42api (with Telegram mock), v42ui, v41api, v41ui, smoke, reports, pwa, crawl, crawl_staff, v40off (expected bad-record 400s only), v40dup, lotapi — all pass.
