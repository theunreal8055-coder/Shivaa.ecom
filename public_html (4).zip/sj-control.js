/* =====================================================================
   Shivaa Jewels — CONTROL ROOM · v41 (Field screen tabs for Owner / Manager)
   🛰 Control room  map (OpenStreetMap) with every car / staff phone / shop
                    visit, each staff's bag colour (hara / peela / laal),
                    maal bahar · bika · wapas aana baaki, aaj ke alert,
                    poore din ka raasta (track)
   📍 Gaadiyan & GPS  add a car tracker or a staff phone (Traccar Client app,
                    free) — they report to gps.php on your own server
   📹 Cameras       your CCTV / body-camera live pages (https) in one grid
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { role: 'owner' };
  const isOwner = () => !SITE || me().role === 'owner';
  const q$ = (s, r) => (r || document).querySelector(s);
  const API = (a, b, ms) => window.SJ_API_CALL(a, b || {}, ms);
  const ago = ms => { const s = Math.max(0, Math.round((Date.now() - ms) / 1000)); return s < 60 ? s + ' sec' : s < 3600 ? Math.round(s / 60) + ' min' : s < 86400 ? Math.round(s / 3600) + ' ghante' : Math.round(s / 86400) + ' din'; };
  const tm = ms => ms ? new Date(ms).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';

  /* ================= tiny map (no library — OpenStreetMap tiles) ================= */
  const TS = 256, lx = (lon, z) => (lon + 180) / 360 * TS * 2 ** z, ly = (lat, z) => { const r = lat * Math.PI / 180; return (1 - Math.log(Math.tan(r) + 1 / Math.cos(r)) / Math.PI) / 2 * TS * 2 ** z; };
  function mapMount(box, pts, lines) {
    box.innerHTML = '<div class="mp-t"></div><svg class="mp-l"></svg><div class="mp-m"></div><div class="mp-z"><button type="button" data-z="1">+</button><button type="button" data-z="-1">−</button><button type="button" data-z="0" title="Sab dikhao">⤢</button></div><div class="mp-a">© OpenStreetMap contributors</div>';
    const T = q$('.mp-t', box), L = q$('.mp-l', box), M = q$('.mp-m', box);
    const all = pts.concat(...(lines || []).map(l => l.pts.map(p => ({ lat: p[0], lon: p[1] }))));
    let z = 12, cx = 0, cy = 0;
    function fit() {
      const w = box.clientWidth || 600, h = box.clientHeight || 400;
      if (!all.length) { z = 11; cx = lx(73.85, z); cy = ly(26.9, z); return; }   // Rajasthan by default
      let la0 = 90, la1 = -90, lo0 = 180, lo1 = -180; all.forEach(p => { la0 = Math.min(la0, p.lat); la1 = Math.max(la1, p.lat); lo0 = Math.min(lo0, p.lon); lo1 = Math.max(lo1, p.lon); });
      for (z = 17; z > 3; z--) { if (lx(lo1, z) - lx(lo0, z) < w - 80 && ly(la0, z) - ly(la1, z) < h - 80) break; }
      cx = (lx(lo0, z) + lx(lo1, z)) / 2; cy = (ly(la0, z) + ly(la1, z)) / 2;
    }
    function draw() {
      const w = box.clientWidth, h = box.clientHeight, n = 2 ** z; let html = '';
      for (let tx = Math.floor((cx - w / 2) / TS); tx <= Math.floor((cx + w / 2) / TS); tx++) for (let ty = Math.floor((cy - h / 2) / TS); ty <= Math.floor((cy + h / 2) / TS); ty++) {
        if (ty < 0 || ty >= n) continue; const wx = ((tx % n) + n) % n;
        html += `<img src="https://tile.openstreetmap.org/${z}/${wx}/${ty}.png" style="left:${Math.round(tx * TS - cx + w / 2)}px;top:${Math.round(ty * TS - cy + h / 2)}px" alt="" draggable="false" loading="lazy">`;
      }
      T.innerHTML = html;
      const P = p => [lx(p.lon, z) - cx + w / 2, ly(p.lat, z) - cy + h / 2];
      L.setAttribute('width', w); L.setAttribute('height', h);
      L.innerHTML = (lines || []).map(l => `<polyline fill="none" stroke="${l.color || '#e2bd62'}" stroke-width="4" stroke-linejoin="round" stroke-opacity=".85" points="${l.pts.map(q => P({ lat: q[0], lon: q[1] }).map(Math.round).join(',')).join(' ')}"/>`).join('');
      M.innerHTML = pts.map((p, i) => { const [x, y] = P(p); return `<button type="button" class="mp-pin ${p.cls || ''}" style="left:${Math.round(x)}px;top:${Math.round(y)}px" data-mp="${i}" title="${esc(p.label || '')}"><i>${p.icon || '●'}</i>${p.short ? `<span>${esc(p.short)}</span>` : ''}</button>`; }).join('');
    }
    fit(); draw();
    let drag = null;
    box.addEventListener('pointerdown', e => { if (e.target.closest('.mp-z,.mp-pin')) return; drag = { x: e.clientX, y: e.clientY, cx, cy }; box.setPointerCapture(e.pointerId); box.classList.add('drag'); });
    box.addEventListener('pointermove', e => { if (!drag) return; cx = drag.cx - (e.clientX - drag.x); cy = drag.cy - (e.clientY - drag.y); draw(); });
    box.addEventListener('pointerup', () => { drag = null; box.classList.remove('drag'); });
    const zoom = (d, ax, ay) => { const w = box.clientWidth, h = box.clientHeight; const nz = Math.max(3, Math.min(18, z + d)); if (nz === z) return; const k = 2 ** (nz - z); const px = cx + (ax ?? w / 2) - w / 2, py = cy + (ay ?? h / 2) - h / 2; cx = px * k - ((ax ?? w / 2) - w / 2); cy = py * k - ((ay ?? h / 2) - h / 2); z = nz; draw(); };
    box.addEventListener('wheel', e => { e.preventDefault(); const r = box.getBoundingClientRect(); zoom(e.deltaY < 0 ? 1 : -1, e.clientX - r.left, e.clientY - r.top); }, { passive: false });
    box.addEventListener('click', e => { const b = e.target.closest('[data-z]'); if (b) { const d = +b.dataset.z; if (d) zoom(d); else { fit(); draw(); } return; } const pin = e.target.closest('[data-mp]'); if (pin) { const p = pts[+pin.dataset.mp]; let pop = q$('.mp-pop', box); if (!pop) { pop = document.createElement('div'); pop.className = 'mp-pop'; box.appendChild(pop); } pop.innerHTML = p.html || esc(p.label || ''); pop.style.left = pin.style.left; pop.style.top = pin.style.top; pop.style.display = 'block'; } else { const pop = q$('.mp-pop', box); if (pop) pop.style.display = 'none'; } });
    new ResizeObserver(() => draw()).observe(box);
  }

  /* ================= control room ================= */
  let LIVE = { points: [], now: 0, at: 0 }, loading = false, timer = null;
  async function loadLive(force) {
    if (!SITE || loading || (!force && Date.now() - LIVE.at < 15000)) return; loading = true;
    try { const r = await API('gps_live', {}); LIVE = { points: r.points || [], now: r.now, at: Date.now() }; } catch (e) { LIVE.err = e.message; } finally { loading = false; }
    const box = q$('#cr-map'); if (box && (ui.fdTab === 'ctrl')) paintCtrl();
  }
  const F = () => window.SJ_FIELD;
  function staffColor(c) {
    const bad = (c.panic || []).length || (c.visits || []).some(v => (v.entry && (v.entry.missing.length || v.entry.wBad) && !v.override) || (v.exit && (v.exit.missing.length || v.exit.wBad) && !v.override2) || v.sealBad);
    if (bad) return 'red'; if (F().curVisit(c)) return 'amber'; return 'green';
  }
  function ctrlBody() {
    const t = todayStr(), out = S.challans.filter(c => c.status === 'out' || (c.status === 'issued' && c.date === t));
    const todays = S.challans.filter(c => c.date === t);
    const bagV = sum(out, c => sum(F().bag(c), i => i.value)), sold = sum(todays, c => (c.visits || []).reduce((n, v) => n + (v.sel || []).filter(s => s.mode === 'sale').length, 0)), appr = sum(todays, c => (c.visits || []).reduce((n, v) => n + (v.sel || []).filter(s => s.mode !== 'sale').length, 0));
    const al = (S.alerts || []).filter(a => num(a.at) >= Date.now() - 86400e3 && /^(field|panic|gate|floor|audit)/.test(a.kind || '')).sort((a, b) => b.at - a.at);
    const cards = out.map(c => { const col = staffColor(c), b = F().bag(c), v = F().curVisit(c); const next = c.route.find(r => !(c.visits || []).some(x => x.done && x.partyId === r.partyId));
      const lp = LIVE.points.find(p => p.key === 'u:' + c.staffUid) || (c.carDev && LIVE.points.find(p => p.key === 'd:' + c.carDev));
      return `<div class="cr-s ${col}" data-act="fd-open" data-id="${esc(c.id)}" role="button" tabindex="0"><div class="cr-sh"><i></i><b>${esc(c.staff)}</b>${c.staff2 ? `<span class="small muted">+ ${esc(c.staff2)}</span>` : ''}<span class="pill">${esc(c.no)}</span></div>
        <div class="cr-sk"><span>Bag <b>${b.length}</b> pcs</span><span>${inr(sum(b, i => i.value))}</span><span>${(c.visits || []).filter(x => x.done).length}/${c.route.length} dukaan</span></div>
        <div class="small">${(c.panic || []).length ? '<b class="red">🆘 PANIC</b> · ' : ''}${v ? `▶ <b>${esc(v.party)}</b> (kadam ${Math.min(5, v.step)})` : next ? `Agla: ${esc(next.name)}` : 'Saari dukaan ho gayi — wapsi baaki'}</div>
        <div class="small muted">${lp ? `📍 ${ago(lp.at)} pehle${lp.spd ? ' · ' + Math.round(lp.spd) + ' km/h' : ''}${lp.batt ? ' · 🔋' + Math.round(lp.batt) + '%' : ''}` : '📍 location nahi aa rahi'}${c.car ? ' · 🚗 ' + esc(c.car) : ''}</div></div>`; }).join('');
    return `<div class="stats">${stat('Bahar staff', String(new Set(out.map(c => c.staffUid)).size), out.length + ' challan', 'users', 'sky')}${stat('Bahar maal', compactInr(bagV), g3(sum(out, c => sum(F().bag(c), i => i.gross))), 'coin', 'gold')}${stat('Aaj bika / approval', sold + ' / ' + appr + ' pcs', todays.reduce((n, c) => n + (c.visits || []).filter(v => v.done).length, 0) + ' dukaan visit', 'trend', '')}${stat('Aaj ke alert', String(al.length), al.filter(a => a.level === 'high').length + ' gambhir', 'spark', al.length ? 'red' : '')}</div>
      <div class="cr-grid"><div class="card cr-mapc"><div class="card-h"><h3>🛰 Live map</h3><div class="btns"><select data-o="cr-trk" aria-label="Raasta"><option value="">Poore din ka raasta…</option>${LIVE.points.map(p => `<option value="${esc(p.key)}">${esc(p.name)}</option>`).join('')}</select><button type="button" class="btn sm" data-act="cr-refresh">↻</button></div></div><div id="cr-map" class="mp"></div><div class="small muted" style="margin-top:6px">${LIVE.err ? esc(LIVE.err) : LIVE.at ? 'Updated ' + tm(LIVE.at) + ' · har 20 sec' : 'Location aa rahi hai…'} · 🚗 gaadi · 📱 staff phone · 🏪 dukaan visit</div></div>
      <div class="cr-side"><div class="card"><h3>👥 Staff ka bag</h3>${cards || '<div class="small muted">Abhi koi field mein nahi</div>'}<div class="cr-legend"><span><i class="g"></i> sab theek</span><span><i class="a"></i> dukaan par</span><span><i class="r"></i> gadbad</span></div></div>
      <div class="card"><h3>🚨 Aaj ke field alert</h3>${al.length ? al.slice(0, 15).map(a => `<div class="cr-al ${a.level}"><b>${esc(a.text)}</b><span class="small muted">${tm(a.at)}</span></div>`).join('') : `<div class="small muted">${isOwner() ? 'Koi alert nahi ✓' : 'Alert sirf Owner ko dikhte hain'}</div>`}</div></div></div>`;
  }
  function pinsNow() {
    const pts = [];
    LIVE.points.forEach(p => { if (Date.now() - p.at > 3 * 86400e3) return; pts.push({ lat: p.lat, lon: p.lon, icon: p.kind === 'car' ? '🚗' : '📱', short: p.name, cls: Date.now() - p.at > 15 * 60e3 ? 'old' : 'live', label: p.name, html: `<b>${esc(p.name)}</b><br>${ago(p.at)} pehle${p.spd ? ' · ' + Math.round(p.spd) + ' km/h' : ''}${p.acc ? ' · ±' + Math.round(p.acc) + ' m' : ''}<br><a href="https://maps.google.com/?q=${p.lat},${p.lon}" target="_blank" rel="noopener">Google Maps</a>` }); });
    S.challans.filter(c => c.date === todayStr()).forEach(c => (c.visits || []).forEach(v => { if (v.lat) pts.push({ lat: v.lat, lon: v.lon, icon: '🏪', cls: v.far || v.sealBad || (v.entry && v.entry.missing.length) || (v.exit && v.exit.missing.length) ? 'bad' : 'shop', label: v.party, html: `<b>${esc(v.party)}</b><br>${esc(c.staff)} · ${tm(v.at)}${v.far ? `<br><b class="red">${v.far} m door check-in</b>` : ''}` }); }));
    S.challans.filter(c => c.status === 'out').forEach(c => (c.panic || []).forEach(p => { if (p.lat) pts.push({ lat: p.lat, lon: p.lon, icon: '🆘', cls: 'bad', label: 'PANIC ' + c.staff, html: `<b class="red">🆘 PANIC</b><br>${esc(c.staff)} · ${tm(p.at)}` }); }));
    return pts;
  }
  let track = null;
  function paintCtrl() {
    const vb = q$('#vbody'); if (!vb || ui.fdTab !== 'ctrl') return;
    const keep = q$('[data-o="cr-trk"]', vb) ? q$('[data-o="cr-trk"]', vb).value : '';
    vb.innerHTML = ctrlBody(); const sel = q$('[data-o="cr-trk"]', vb); if (sel && keep) sel.value = keep;
    const box = q$('#cr-map'); if (box) mapMount(box, pinsNow(), track ? [track] : []);
  }
  async function showTrack(key) {
    if (!key) { track = null; paintCtrl(); return; }
    try { const r = await API('gps_track', { key, date: todayStr() }); track = { pts: r.points.map(p => [p[1], p[2]]), color: '#38bdf8' }; if (!track.pts.length) toast('Aaj ka raasta nahi mila'); paintCtrl(); q$('[data-o="cr-trk"]').value = key; } catch (e) { toast(e.message, 'err'); }
  }

  /* ================= GPS devices ================= */
  let GPSD = null;
  async function gpsLoad() { try { GPSD = (await API('gps_cfg', {})).devices || {}; } catch (e) { GPSD = { _err: e.message }; } const vb = q$('#vbody'); if (vb && ui.fdTab === 'gps') vb.innerHTML = gpsBody(); }
  function gpsBody() {
    if (!isOwner()) return emptyBox('GPS devices Owner jodta hai.');
    if (!GPSD) { gpsLoad(); return '<div class="small muted">Load ho raha hai…</div>'; }
    if (GPSD._err) return `<div class="warn-box">${esc(GPSD._err)}</div>`;
    const url = location.origin + location.pathname.replace(/[^/]*$/, '') + 'gps.php';
    const rows = Object.entries(GPSD).map(([id, d]) => { const lp = LIVE.points.find(p => p.key === 'd:' + id); return `<div class="cr-dev"><div><b>${d.kind === 'car' ? '🚗' : '📱'} ${esc(d.name)}</b>${d.staff ? ` <span class="small muted">${esc(d.staff)}</span>` : ''}<div class="small">Device ID: <b class="mono no-mask">${esc(id)}</b></div><div class="small muted">${lp ? '📍 aakhri location ' + ago(lp.at) + ' pehle' : 'Abhi tak location nahi aayi'}</div></div><div class="btns"><button type="button" class="btn sm" data-act="cr-gps-ren" data-id="${esc(id)}">Naam</button><button type="button" class="btn sm danger" data-act="cr-gps-del" data-id="${esc(id)}">Hatao</button></div></div>`; }).join('');
    return `<div class="card"><div class="card-h"><h3>📍 Gaadiyan & staff phone</h3><div class="btns"><button type="button" class="btn sm gold" data-act="cr-gps-add" data-k="car">+ Gaadi</button><button type="button" class="btn sm" data-act="cr-gps-add" data-k="staff">+ Staff phone</button></div></div>${rows || '<div class="small muted">Abhi koi device nahi jodi.</div>'}</div>
      <div class="card"><h3>Kaise jodein</h3><ol class="small cr-how"><li><b>Staff ka phone (poore din, screen band ho tab bhi):</b> Play Store se free app <b>Traccar Client</b> install kijiye → <i>Server URL</i>: <span class="mono no-mask">${esc(url)}</span> → <i>Device identifier</i>: upar wali Device ID → <i>Frequency</i>: 60 → Service chalu. Battery saver se is app ko hata dijiye.</li>
      <li><b>Gaadi ka GPS tracker:</b> aisa tracker lijiye jo <b>OsmAnd / Traccar</b> protocol ya HTTP "forward" kar sake. Uske URL mein upar wala URL aur Device ID daaliye. (Tracker company ka platform aage bhej sakta ho to bhi chalega.)</li>
      <li><b>Bina app ke:</b> challan chalu ho aur software khula ho to staff ka phone khud har minute location bhejta hai.</li></ol><p class="small muted">Location sirf duty ke samay — staff se likhit sahmati lijiye (DPDP Act 2023). Purani location 120 din baad apne aap mit jaati hai.</p></div>`;
  }

  /* ================= cameras ================= */
  const cams = () => { const c = (settings().pro || {}).cams; return Array.isArray(c) ? c : []; };
  function camsBody() {
    if (!isOwner()) return emptyBox('Cameras sirf Owner dekh sakta hai.');
    const L = cams(); const groups = [...new Set(L.map(c => c.place || 'Dukaan'))];
    const tiles = groups.map(g => `<h4 class="fd-h">${esc(g)}</h4><div class="cam-grid">${L.map((c, i) => [c, i]).filter(([c]) => (c.place || 'Dukaan') === g).map(([c, i]) => `<div class="cam"><div class="cam-h"><b>${esc(c.name)}</b><span><a class="btn sm" href="${esc(c.url)}" target="_blank" rel="noopener">⤢ Kholo</a> <button type="button" class="btn sm danger" data-act="cr-cam-del" data-i="${i}">✕</button></span></div>${/^https:\/\//i.test(c.url) && c.kind !== 'link' ? `<iframe src="${esc(c.url)}" loading="lazy" allow="autoplay; fullscreen" referrerpolicy="no-referrer"></iframe>` : `<div class="cam-x">Is camera ko naye tab mein kholiye (${/^https:/i.test(c.url) ? 'page andar nahi khulta' : 'http link — surakshit nahi, isliye andar nahi khulta'})</div>`}</div>`).join('')}</div>`).join('');
    return `<div class="card"><div class="card-h"><h3>📹 Cameras</h3><button type="button" class="btn sm gold" data-act="cr-cam-add">+ Camera jodo</button></div><p class="small muted" style="margin:0">Teeno floor ke CCTV aur field staff ke body camera ka <b>https live page</b> yahan jodiye (jaise NVR company ki cloud website, ya dukaan ke chhote computer par chal raha <b>go2rtc</b> ka "stream.html?src=…" link). Camera ka password kabhi URL mein mat daaliye.</p></div>${L.length ? tiles : emptyBox('Abhi koi camera nahi jodi.')}`;
  }
  async function camAdd() {
    const name = await SJ_ASK('Camera jodo', 'Camera ka naam', { ph: 'jaise Ground floor counter' }); if (!name) return;
    const place = await SJ_ASK('Camera kahan hai', 'Jagah', { ph: 'Ground / 1st / 2nd / Field', val: 'Ground' }); if (place === null) return;
    const url = await SJ_ASK('Live page ka link', 'https://… link', { ph: 'https://…', mono: true }); if (!url) return;
    if (!/^https?:\/\//i.test(url)) return toast('Link https:// se shuru hona chahiye', 'err');
    if (/\/\/[^/]*:[^/]*@/.test(url)) return toast('Link mein password mat daaliye — camera ki website par alag login rakhiye', 'err');
    const L = cams().concat([{ name: name.slice(0, 40), place: (place || 'Dukaan').slice(0, 30), url: url.slice(0, 500), kind: 'frame' }]);
    if (await saveSettings({ ...S.settings, pro: { ...((S.settings || {}).pro || {}), cams: L } })) { toast('✓ Camera judi'); renderView(true); }
  }

  /* ================= wiring into the Field screen ================= */
  window.SJ_CONTROL = {
    tabs: () => [['ctrl', '🛰 Control room'], ['gps', '📍 Gaadiyan & GPS'], ...(isOwner() ? [['cams', '📹 Cameras']] : [])],
    body(t) {
      if (t === 'ctrl') { setTimeout(() => { const box = q$('#cr-map'); if (box && !box.firstChild) mapMount(box, pinsNow(), track ? [track] : []); loadLive(); }, 30); return ctrlBody(); }
      if (t === 'gps') { if (!LIVE.at) loadLive(true); return gpsBody(); }
      if (t === 'cams') return camsBody();
      return null;
    },
    mapMount
  };
  setInterval(() => { if (typeof view !== 'undefined' && view === 'field' && ui.fdTab === 'ctrl' && document.visibilityState === 'visible') loadLive(true); }, 20000);

  const ACT = {
    'cr-refresh': () => loadLive(true),
    'cr-gps-add': async t => { const name = await SJ_ASK(t.dataset.k === 'car' ? 'Gaadi jodo' : 'Staff phone jodo', 'Naam', { ph: t.dataset.k === 'car' ? 'jaise Swift RJ-14' : 'jaise Ramesh ka phone' }); if (!name) return; try { GPSD = (await API('gps_cfg', { add: 1, name, kind: t.dataset.k })).devices; toast('✓ Juda — ab Device ID tracker / Traccar Client mein daaliye'); renderView(true); } catch (e) { toast(e.message, 'err'); } },
    'cr-gps-del': async t => { if (!await SJ_CONFIRM('Ye device hata dein? Uski location aana band ho jayega.', 'Hatao')) return; try { GPSD = (await API('gps_cfg', { remove: t.dataset.id })).devices; renderView(true); } catch (e) { toast(e.message, 'err'); } },
    'cr-gps-ren': async t => { const n = await SJ_ASK('Naya naam', 'Naam'); if (!n) return; try { GPSD = (await API('gps_cfg', { rename: t.dataset.id, name: n })).devices; renderView(true); } catch (e) { toast(e.message, 'err'); } },
    'cr-cam-add': () => camAdd(),
    'cr-cam-del': async t => { if (!await SJ_CONFIRM('Ye camera hata dein?', 'Hatao')) return; const L = cams().filter((c, i) => i !== +t.dataset.i); if (await saveSettings({ ...S.settings, pro: { ...((S.settings || {}).pro || {}), cams: L } })) renderView(true); }
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="cr-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);
  document.addEventListener('change', e => { const s = e.target; if (s.dataset && s.dataset.o === 'cr-trk') { e.stopPropagation(); showTrack(s.value); } }, true);

  const st = document.createElement('style');
  st.textContent = `.mp{position:relative;height:440px;border-radius:14px;overflow:hidden;background:#d8d4cb;touch-action:none;cursor:grab;user-select:none}.mp.drag{cursor:grabbing}.mp-t img{position:absolute;width:256px;height:256px;max-width:none;pointer-events:none}.mp-l{position:absolute;inset:0;pointer-events:none}.mp-m{position:absolute;inset:0;pointer-events:none}
    .mp-pin{position:absolute;transform:translate(-50%,-100%);pointer-events:auto;display:flex;flex-direction:column;align-items:center;border:0;background:none;padding:0;cursor:pointer}.mp-pin i{font-style:normal;font-size:20px;line-height:1;width:34px;height:34px;display:grid;place-items:center;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:#1b1408;border:2px solid #e2bd62;box-shadow:0 4px 10px rgba(0,0,0,.4)}.mp-pin i{transform:none;border-radius:50%}
    .mp-pin span{margin-top:2px;font:700 11px system-ui;color:#1b1408;background:rgba(255,255,255,.92);border-radius:6px;padding:1px 5px;white-space:nowrap}.mp-pin.live i{border-color:#22c55e;animation:mpb 2s infinite}.mp-pin.old i{opacity:.6}.mp-pin.bad i{border-color:#ef4444;background:#3b0a0a}.mp-pin.shop i{font-size:16px}@keyframes mpb{50%{box-shadow:0 0 0 8px rgba(34,197,94,.25)}}
    .mp-z{position:absolute;right:10px;top:10px;display:flex;flex-direction:column;gap:4px}.mp-z button{width:34px;height:34px;border-radius:10px;border:1px solid rgba(0,0,0,.2);background:#fff;color:#111;font:700 18px system-ui;cursor:pointer}.mp-a{position:absolute;right:6px;bottom:4px;font:10px system-ui;color:#333;background:rgba(255,255,255,.8);padding:1px 5px;border-radius:4px}
    .mp-pop{position:absolute;transform:translate(-50%,calc(-100% - 46px));background:var(--card,#fff);color:var(--ink,#111);border:1px solid var(--line);border-radius:10px;padding:8px 10px;font-size:12.5px;min-width:160px;box-shadow:0 8px 20px rgba(0,0,0,.35);display:none;z-index:2}
    .cr-grid{display:grid;grid-template-columns:minmax(0,1.6fr) minmax(0,1fr);gap:14px}.cr-mapc{margin:0}.cr-side{display:flex;flex-direction:column;gap:14px}.cr-side .card{margin:0}
    .cr-s{border:1px solid var(--line);border-left:5px solid var(--line);border-radius:12px;padding:8px 10px;margin-bottom:8px;cursor:pointer;display:flex;flex-direction:column;gap:3px}.cr-s.green{border-left-color:#22c55e}.cr-s.amber{border-left-color:#f59e0b}.cr-s.red{border-left-color:#ef4444;background:rgba(239,68,68,.06)}
    .cr-sh{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.cr-sh i{width:10px;height:10px;border-radius:50%;background:currentColor}.cr-s.green .cr-sh i{color:#22c55e}.cr-s.amber .cr-sh i{color:#f59e0b}.cr-s.red .cr-sh i{color:#ef4444}.cr-sk{display:flex;gap:12px;font-size:12.5px;flex-wrap:wrap}
    .cr-legend{display:flex;gap:12px;font-size:11.5px;color:var(--muted);margin-top:6px}.cr-legend i{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:4px}.cr-legend .g{background:#22c55e}.cr-legend .a{background:#f59e0b}.cr-legend .r{background:#ef4444}
    .cr-al{display:flex;flex-direction:column;gap:2px;padding:7px 0;border-bottom:1px solid var(--line);font-size:12.5px}.cr-al.high b{color:#f87171}
    .cr-dev{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--line)}.cr-how li{margin-bottom:8px;line-height:1.5}
    .cam-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,360px),1fr));gap:12px}.cam{border:1px solid var(--line);border-radius:14px;overflow:hidden;background:#000}.cam-h{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 10px;background:var(--card)}.cam iframe{display:block;width:100%;aspect-ratio:16/9;border:0;background:#000}.cam-x{aspect-ratio:16/9;display:grid;place-items:center;color:#aaa;font-size:13px;padding:16px;text-align:center}
    @media(max-width:900px){.cr-grid{grid-template-columns:1fr}.mp{height:360px}}@media(max-width:560px){.cr-dev{flex-direction:column;align-items:stretch}}`;
  document.head.appendChild(st);
})();
