<?php
/* =====================================================================
   Shivaa Jewels — SECURITY + FIELD server part (v41)
   Loaded by sj-api.php. Everything here is checked on the server, so a
   staff browser cannot skip it.
   • Policy (sec_policy): login hours, device approval, PIN for risky work,
     2-step for everybody, discount / old-gold limits, day lock, export
   • Per-user extras (uext:<id>): PIN, floor, field staff, hours exemption
   • Devices: every phone / computer gets a device cookie; Owner approves
   • Approvals (sjReqs): staff asks → Manager / Owner approves → server
     signs a token the bill must carry
   • Tamper-proof log (sj_chain): every saved record is chained with a
     secret key — a record changed outside the software is caught
   • GPS (sj_gps): car trackers / Traccar Client / the app itself
   • RFID gate, retailer confirm page, cron (backup, overdue challans)
   ===================================================================== */
if (!defined('SJ')) { http_response_code(403); exit; }

/* ---------------- policy & per-user extras ---------------- */
function sj_pol() {
    static $p = null; if ($p !== null) return $p;
    $d = ['hours' => false, 'from' => '09:00', 'to' => '21:30', 'devices' => false, 'pin' => false, 'totpAll' => false,
        'discStaff' => 0, 'discMgr' => 0, 'ogStaff' => 0, 'dayLock' => false, 'exportOwner' => false, 'idleMin' => 0,
        'floorWall' => false, 'maskPii' => false, 'fieldMax' => 0, 'fieldTwo' => 0, 'tolG' => 0.10, 'tolPc' => 0.02, 'radius' => 200,
        'cash269' => true, 'panRule' => true, 'fieldPhoto' => true, 'stayMin' => 30, 'noLocMin' => 45, 'creditBlock' => true];
    $j = json_decode((string)sj_meta_get('sec_policy'), true);
    return $p = is_array($j) ? array_merge($d, array_intersect_key($j, $d)) : $d;
}
function sj_uext($uid) { $j = json_decode((string)sj_meta_get('uext:' . $uid), true); return is_array($j) ? $j : []; }
function sj_uext_put($uid, $j) { sj_meta_set('uext:' . $uid, json_encode($j)); }
function sj_hm_now() { return gmdate('H:i', time() + 19800); }
function sj_in_hours() { $p = sj_pol(); $t = sj_hm_now(); return $p['from'] <= $p['to'] ? ($t >= $p['from'] && $t <= $p['to']) : ($t >= $p['from'] || $t <= $p['to']); }
function sj_hours_block($u) {
    if (!$u || $u['role'] === 'owner') return null;
    $p = sj_pol(); if (!$p['hours'] || sj_in_hours()) return null;
    $x = sj_uext($u['id']); if (!empty($x['anyHours'])) return null;
    return 'Dukaan ka samay ' . $p['from'] . '–' . $p['to'] . ' hai. Is samay login / kaam band hai — Owner se baat kijiye.';
}
function sj_sec_alert($kind, $text, $level, $u = null, $extra = []) {
    $now = (int)round(microtime(true) * 1000); $who = $u ? $u['name'] . ' (' . $u['role'] . ')' : 'system';
    $al = ['kind' => $kind, 'text' => $text, 'col' => 'security', 'docId' => '', 'level' => $level, 'night' => sj_ist_hour() >= 22 || sj_ist_hour() < 7, 'by' => $who, 'byUser' => $u ? $u['uname'] : '', 'at' => $now, 'seen' => false] + $extra;
    $id = 'al_' . base_convert((string)$now, 10, 36) . '_' . bin2hex(random_bytes(3)); $al['id'] = $id;
    sj_put_docs([['alerts', $id, $al]], $u ? $u['id'] : 'system');
    if ($level === 'high') { try { sj_alert_mail([$al]); } catch (Exception $e) { /* mail is best effort */ } }
    elseif (function_exists('sj_tg_alerts')) { try { sj_tg_alerts([$al]); } catch (Exception $e) { /* best effort */ } }
}
/* once per key per day (e.g. "off-hours try by ramesh") */
function sj_once_today($key) { $k = 'once:' . substr(hash('sha256', $key), 0, 24); $d = gmdate('Y-m-d', time() + 19800); if (sj_meta_get($k) === $d) return false; sj_meta_set($k, $d); return true; }

/* ---------------- devices ---------------- */
function sj_dev_raw() {
    static $d = null; if ($d !== null) return $d;
    $c = isset($_COOKIE['sj_dev']) ? (string)$_COOKIE['sj_dev'] : '';
    if (!preg_match('/^[a-f0-9]{40}$/', $c)) {
        $c = bin2hex(random_bytes(20));
        $o = ['expires' => time() + 86400 * 1800, 'path' => sj_cookie_path(), 'secure' => sj_https(), 'httponly' => true, 'samesite' => 'Strict'];
        if (PHP_VERSION_ID >= 70300) setcookie('sj_dev', $c, $o); else setcookie('sj_dev', $c, $o['expires'], $o['path'] . '; samesite=Strict', '', $o['secure'], true);
    }
    return $d = $c;
}
function sj_dev_id() { return substr(hash('sha256', 'dev|' . sj_dev_raw()), 0, 24); }
function sj_devs() { $j = json_decode((string)sj_meta_get('devices'), true); return is_array($j) ? $j : []; }
function sj_devs_put($j) { sj_meta_set('devices', json_encode($j)); }
function sj_dev_name() {
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';
    $os = preg_match('/Android ([\d.]+)/', $ua, $m) ? 'Android ' . $m[1] : (preg_match('/iPhone|iPad/', $ua) ? 'iPhone/iPad' : (preg_match('/Windows/', $ua) ? 'Windows' : (preg_match('/Mac OS X/', $ua) ? 'Mac' : (preg_match('/Linux/', $ua) ? 'Linux' : 'Device'))));
    $br = preg_match('/Edg\//', $ua) ? 'Edge' : (preg_match('/Chrome\//', $ua) ? 'Chrome' : (preg_match('/Firefox\//', $ua) ? 'Firefox' : (preg_match('/Safari\//', $ua) ? 'Safari' : 'Browser')));
    $mdl = preg_match('/;\s*([^;()]+?)\s+Build\//', $ua, $m) ? ' · ' . trim($m[1]) : (preg_match('/Android [\d.]+; ([^;)]+)\)/', $ua, $m) ? ' · ' . trim($m[1]) : '');
    return substr($os . ' · ' . $br . $mdl, 0, 80);
}
/* returns null when the device may log in, else an error code */
function sj_dev_gate($u) {
    $id = sj_dev_id(); $all = sj_devs(); $now = time(); $p = sj_pol();
    $d = isset($all[$id]) ? $all[$id] : null;
    if (!$d) { $d = ['st' => ($u['role'] === 'owner' || !$p['devices']) ? 'ok' : 'pending', 'name' => sj_dev_name(), 'first' => $now, 'ip' => sj_ip(), 'users' => []]; $isNew = true; } else $isNew = false;
    $d['last'] = $now; $d['ip'] = sj_ip(); if (!in_array($u['uname'], $d['users'], true)) $d['users'][] = $u['uname']; $d['users'] = array_slice($d['users'], -6);
    if ($d['st'] === 'blocked') { $all[$id] = $d; sj_devs_put($all); return 'device_blocked'; }
    if ($u['role'] === 'owner' && $d['st'] !== 'ok') $d['st'] = 'ok';
    if ($d['st'] === 'pending' && !$p['devices']) $d['st'] = 'ok';
    $all[$id] = $d;
    if (count($all) > 300) { uasort($all, function ($a, $b) { return (isset($b['last']) ? $b['last'] : 0) - (isset($a['last']) ? $a['last'] : 0); }); $all = array_slice($all, 0, 300, true); }
    sj_devs_put($all);
    if ($isNew && $p['devices']) sj_sec_alert('new_device', ($d['st'] === 'pending' ? 'NAYA DEVICE approve ka intezaar: ' : 'Naye device se login: ') . $u['name'] . ' · ' . $d['name'] . ' · IP ' . sj_ip(), $d['st'] === 'pending' ? 'high' : 'medium', $u);
    return $d['st'] === 'pending' ? 'device_pending' : null;
}

/* ---------------- per-user 2-step (Owner keeps the old "totp" key) ---------------- */
function sj_tkey($uid) { return $uid === SJ_OWNER_ID ? 'totp' : 'totp:' . $uid; }
function sj_utotp_get($uid) { $k = sj_tkey($uid); $v = sj_meta_get($k); if (!$v) return null; try { $j = json_decode((string)sj_dec($v, 'meta', $k), true); } catch (Exception $e) { return null; } return is_array($j) && !empty($j['secret']) ? $j : null; }
function sj_utotp_put($uid, $j) { $k = sj_tkey($uid); if ($j === null) { sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute([$k]); return; } sj_meta_set($k, sj_enc(json_encode($j), 'meta', $k)); }
function sj_utotp_on($uid) { return !sj_cfg('disable_2fa', false) && sj_utotp_get($uid) !== null; }
function sj_utotp_check($uid, $code) {
    $j = sj_utotp_get($uid); if (!$j) return false; $code = strtoupper(preg_replace('/[\s-]/', '', (string)$code)); if ($code === '') return false;
    if (preg_match('/^\d{6}$/', $code)) { $now = (int)floor(time() / 30); foreach ([0, -1, 1] as $d) { $c = $now + $d; if ($c <= (int)(isset($j['last']) ? $j['last'] : 0)) continue; if (hash_equals(sj_totp_at($j['secret'], $c), $code)) { $j['last'] = $c; sj_utotp_put($uid, $j); return true; } } return false; }
    $h = hash('sha256', $code); $codes = isset($j['codes']) && is_array($j['codes']) ? $j['codes'] : [];
    foreach ($codes as $i => $c) if (hash_equals($c, $h)) { array_splice($codes, $i, 1); $j['codes'] = $codes; sj_utotp_put($uid, $j); return true; }
    return false;
}
function sj_new_codes() { $codes = []; $hash = []; for ($k = 0; $k < 8; $k++) { $c = strtoupper(substr(sj_b32_enc(random_bytes(6)), 0, 8)); $codes[] = substr($c, 0, 4) . '-' . substr($c, 4); $hash[] = hash('sha256', $c); } return [$codes, $hash]; }
function sj_totp_uri($uname, $sec) { $set = sj_load_doc('settings', 'main'); $iss = is_array($set) && !empty($set['firm']) ? $set['firm'] : 'Shivaa Jewels'; return 'otpauth://totp/' . rawurlencode($iss . ':' . $uname) . '?secret=' . $sec . '&issuer=' . rawurlencode($iss) . '&digits=6&period=30'; }
function sj_totp_match($sec, $code) { $code = preg_replace('/\D/', '', (string)$code); $now = (int)floor(time() / 30); foreach ([0, -1, 1] as $d) if (hash_equals(sj_totp_at($sec, $now + $d), $code)) return $now + $d; return false; }

/* ---------------- PIN (re-check before risky work) ---------------- */
function sj_elevated() { $h = sj_token_hash(); if (!$h) return false; $st = sj_db()->prepare('SELECT elev FROM sj_tokens WHERE h = ?'); $st->execute([$h]); return (int)$st->fetchColumn() > time(); }
function sj_need_pin($u) {
    if (!sj_pol()['pin'] || sj_elevated()) return null;
    return empty(sj_uext($u['id'])['pin']) ? 'pin_not_set' : 'pin_required';
}
function sj_pin_fail($code) { sj_fail($code, 403, $code === 'pin_not_set' ? 'Is kaam ke liye apna PIN chahiye — Setup → Suraksha → "Mera PIN" banaiye.' : 'Is kaam se pehle apna PIN daaliye.'); }
const SJ_PIN_FREE = ['summary', 'tagState', 'alerts', 'trash', 'portalReqs', 'notes', 'sjReqs', 'fieldConfirms', 'audit'];

/* ---------------- approval tokens ---------------- */
function sj_atok($kind, $ref, $val) { return substr(hash_hmac('sha256', 'apr|' . $kind . '|' . $ref . '|' . $val, sj_key() ?: 'sj'), 0, 32); }
function sj_disc_pct($v) { $t = isset($v['totals']) && is_array($v['totals']) ? $v['totals'] : []; $it = (float)(isset($t['itemsTotal']) ? $t['itemsTotal'] : 0); $d = (float)(isset($t['discount']) ? $t['discount'] : 0); return $it > 0 ? round($d / $it * 100, 2) : 0; }

/* ---------------- extra record rules (called from sj_check_op) ---------------- */
function sj_sec_check($u, $o, $c, $i, &$d) {
    $role = $u['role']; $p = sj_pol();
    // PIN before deleting business records
    if ($o === 'del' && !in_array(explode('/', $c)[0], SJ_PIN_FREE, true)) { $need = sj_need_pin($u); if ($need) return '#' . $need; }
    $new = $d === null ? null : json_decode($d, true);
    if ($c === 'fieldConfirms') return 'Dukaandar ki pushti sirf uske link se hoti hai.';
    if (in_array($c, ['boxes', 'petis', 'trays'], true) && $role === 'staff' && function_exists('sj_lot_guard')) { $lg = sj_lot_guard($o, $c, $i, $new); if ($lg) return $lg; }
    if ($c === 'fieldPhotos' && in_array($role, ['staff', 'viewer'], true) && ($o === 'del' || (($od = sj_load_doc($c, $i)) !== null && json_encode($od) !== json_encode($new)))) return 'Saboot ki photo badli / mitaayi nahi ja sakti.';
    if ($c === 'tijoriLog') return 'Tijori ka record sirf do PIN se banta hai.';
    if ($c === 'fieldCodes' && !in_array($role, ['owner', 'manager'], true)) return 'Ye sirf Manager / Owner ke liye hai.';
    if ($c === 'invoices' && is_array($new) && $role !== 'owner' && function_exists('sj_law_check')) { $lw = sj_law_check($u, $i, $new); if ($lw) return $lw; }
    // approval requests: anybody asks, only Manager / Owner decide; the server signs the token
    if ($c === 'sjReqs') {
        $old = sj_load_doc($c, $i);
        if ($o === 'del') return in_array($role, ['owner', 'manager'], true) ? null : 'Request sirf Manager / Owner hata sakte hain.';
        if (!is_array($new)) return 'Galat request.';
        $st = isset($new['status']) ? $new['status'] : 'pending'; $ost = $old && isset($old['status']) ? $old['status'] : null;
        if ($role === 'staff' || $role === 'viewer') {
            if ($old && $ost !== 'pending') return 'Faisla ho chuki request badli nahi ja sakti.';
            if ($st !== 'pending' || isset($new['tok'])) return 'Manzoori sirf Manager / Owner de sakte hain.';
            $new['by'] = $u['name']; $new['byUid'] = $u['id'];
        } else {
            if ($st === 'approved' && $ost !== 'approved') {
                $kind = (string)(isset($new['kind']) ? $new['kind'] : ''); $ref = (string)(isset($new['ref']) ? $new['ref'] : ''); $val = (string)(isset($new['val']) ? $new['val'] : '');
                if ($role === 'manager' && $kind === 'disc' && $p['discMgr'] > 0 && (float)$val > (float)$p['discMgr'] + 0.001) return 'Itna discount sirf Owner manzoor kar sakta hai (Manager ki seema ' . $p['discMgr'] . '%).';
                if (!empty($new['byUid']) && $new['byUid'] === $u['id'] && $role !== 'owner') return 'Apni hi request khud manzoor nahi kar sakte.';
                $new['tok'] = sj_atok($kind, $ref, $val); $new['decidedBy'] = $u['name']; $new['decidedAt'] = (int)round(microtime(true) * 1000);
            } elseif ($st !== 'approved') unset($new['tok']);
            else if ($old && isset($old['tok'])) $new['tok'] = $old['tok'];
        }
        $d = json_encode($new, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
        return null;
    }
    // day lock: after "Close the day", that day's money / bills change only by the Owner
    if ($p['dayLock'] && $role !== 'owner' && in_array($c, ['invoices', 'expenses', 'banktx'], true)) {
        $old = sj_load_doc($c, $i);
        foreach ([$old, $new] as $x) { if (!is_array($x) || empty($x['date'])) continue; $cl = sj_load_doc('closings', (string)$x['date']); if ($cl && !empty($cl['closedAt'])) {
            if ($c === 'invoices' && $old && is_array($new) && sj_only_payments_added($old, $new)) continue;   // money received later is still recorded
            return '🔒 ' . $x['date'] . ' ka din band ho chuka hai — us din ki entry sirf Owner badal sakta hai.'; } }
    }
    // discount / old-gold limits (only when the amount changes)
    if ($c === 'invoices' && is_array($new) && $role !== 'owner') {
        $old = sj_load_doc($c, $i);
        $lim = $role === 'manager' ? (float)$p['discMgr'] : (float)$p['discStaff'];
        $pct = sj_disc_pct($new);
        if ($lim > 0 && $pct > $lim + 0.01 && (!$old || abs(sj_disc_pct($old) - $pct) > 0.01)) {
            $ref = (isset($new['discKey']) ? (string)$new['discKey'] : '') . '|' . (isset($new['partyId']) ? $new['partyId'] : '') . '|' . round((float)(isset($new['totals']['itemsTotal']) ? $new['totals']['itemsTotal'] : 0));
            $ok = false; for ($v = (int)ceil($pct - 0.001); $v <= 100; $v++) if (!empty($new['discOk']) && hash_equals(sj_atok('disc', $ref, (string)$v), (string)$new['discOk'])) { $ok = true; break; }
            if (!$ok) return '#approval_required:Discount ' . $pct . '% aapki seema (' . $lim . '%) se zyada hai — Manager / Owner ki manzoori chahiye.';
        }
        if (isset($new['type']) && $new['type'] === 'oldgold' && $role === 'staff' && (float)$p['ogStaff'] > 0) {
            $amt = sj_doc_payable($new);
            if ($amt > (float)$p['ogStaff'] && (!$old || abs(sj_doc_payable($old) - $amt) > 1)) {
                $ref = (isset($new['ogKey']) ? (string)$new['ogKey'] : '') . '|' . (isset($new['partyId']) ? $new['partyId'] : '');
                $ok = false; foreach ([(string)round($amt), (string)ceil($amt / 1000) * 1000] as $v) if (!empty($new['ogOk']) && hash_equals(sj_atok('og', $ref, $v), (string)$new['ogOk'])) $ok = true;
                if (!$ok && !empty($new['ogOk']) && !empty($new['ogMax']) && (float)$new['ogMax'] + 0.5 >= $amt && hash_equals(sj_atok('og', $ref, (string)(int)$new['ogMax']), (string)$new['ogOk'])) $ok = true;
                if (!$ok) return '#approval_required:Purana sona ' . sj_inr($amt) . ' ka hai — ' . sj_inr($p['ogStaff']) . ' se upar Manager / Owner ki manzoori chahiye.';
            }
        }
    }
    // floor wall: staff cannot change another floor's stock (selling still works)
    if ($c === 'products' && $role === 'staff' && $p['floorWall'] && is_array($new)) {
        $old = sj_load_doc($c, $i); $mf = (string)(isset(sj_uext($u['id'])['floor']) ? sj_uext($u['id'])['floor'] : '');
        if ($old && $mf !== '' && !empty($old['floor']) && (string)$old['floor'] !== $mf) {
            foreach (['gross', 'less', 'net', 'purity', 'category', 'floor', 'huid', 'sku', 'rfid', 'tunch', 'making'] as $k) if (json_encode(isset($old[$k]) ? $old[$k] : null) !== json_encode(isset($new[$k]) ? $new[$k] : null)) return 'Ye piece doosre floor (' . $old['floor'] . ') ka hai — aap sirf apne floor (' . $mf . ') ka stock badal sakte hain.';
        }
    }
    // field challans: only the staff on the challan (or Manager / Owner) may touch it; closing with a shortfall needs a Manager
    if ($c === 'challans' && is_array($new)) {
        $old = sj_load_doc($c, $i);
        if ($role === 'staff') {
            $mine = function ($x) use ($u) { return is_array($x) && ((isset($x['staffUid']) && $x['staffUid'] === $u['id']) || (isset($x['staff2Uid']) && $x['staff2Uid'] === $u['id'])); };
            if ($old && !$mine($old) && !(isset($old['issuedByUid']) && $old['issuedByUid'] === $u['id'] && (isset($old['status']) ? $old['status'] : '') === 'draft')) return 'Ye challan aapka nahi hai.';
            foreach (['diffOk', 'diffOkBy', 'codeH', 'creditOk'] as $k) if (json_encode($old && isset($old[$k]) ? $old[$k] : null) !== json_encode(isset($new[$k]) ? $new[$k] : null)) return 'Challan ka fark sirf Manager / Owner maaf kar sakte hain.';
            if ($old && in_array(isset($old['status']) ? $old['status'] : '', ['closed'], true)) return 'Band challan badla nahi ja sakta.';
            if ($old && isset($old['items']) && json_encode($old['items']) !== json_encode(isset($new['items']) ? $new['items'] : null) && (isset($old['status']) ? $old['status'] : '') !== 'draft') return 'Issue hone ke baad challan ka maal sirf Manager badal sakta hai.';
        }
        if (isset($new['status']) && $new['status'] === 'closed' && !empty($new['ret']['short']) && $role === 'staff') return 'Kam maal wala challan sirf Manager / Owner band kar sakte hain.';
        $issuing = isset($new['status']) && $new['status'] === 'issued' && (!$old || !in_array(isset($old['status']) ? $old['status'] : '', ['issued', 'out', 'returned', 'closed'], true));
        if ($p['fieldTwo'] > 0 && $issuing && (float)(isset($new['value']) ? $new['value'] : 0) > (float)$p['fieldTwo'] && empty($new['staff2'])) return 'Itne maal (' . sj_inr($new['value']) . ') ke saath do log jaane chahiye — doosra staff chuniye.';
        if ($p['fieldMax'] > 0 && $issuing && (float)(isset($new['value']) ? $new['value'] : 0) > (float)$p['fieldMax'] && $role !== 'owner') return 'Ek challan mein ' . sj_inr($p['fieldMax']) . ' se zyada ka maal sirf Owner bhej sakta hai.';
    }
    return null;
}
function sj_only_payments_added($old, $new) {
    $a = $old; $b = $new; unset($a['payments'], $b['payments'], $a['updatedAt'], $b['updatedAt']); ksort($a); ksort($b);
    if (json_encode($a) !== json_encode($b)) return false;
    $op = []; foreach (isset($old['payments']) && is_array($old['payments']) ? $old['payments'] : [] as $x) if (isset($x['id'])) $op[$x['id']] = json_encode($x);
    $np = []; foreach (isset($new['payments']) && is_array($new['payments']) ? $new['payments'] : [] as $x) if (isset($x['id'])) $np[$x['id']] = json_encode($x);
    foreach ($op as $k => $v) if (!isset($np[$k]) || $np[$k] !== $v) return false;
    return true;
}

/* ---------------- server alerts for field / weights (added to sj_alerts_for) ---------------- */
function sj_sec_alerts($u, $c, $i, $old, $new, $add) {
    if ($c === 'challans' && is_array($new)) {
        $no = isset($new['no']) ? $new['no'] : $i; $st = isset($new['staff']) ? $new['staff'] : '';
        $ov = []; foreach ($old && isset($old['visits']) && is_array($old['visits']) ? $old['visits'] : [] as $v) if (isset($v['id'])) $ov[$v['id']] = $v;
        foreach (isset($new['visits']) && is_array($new['visits']) ? $new['visits'] : [] as $v) {
            if (!isset($v['id'])) continue; $o = isset($ov[$v['id']]) ? $ov[$v['id']] : [];
            $pn = isset($v['party']) ? $v['party'] : '';
            foreach (['entry' => 'ENTRY scan', 'exit' => 'EXIT scan'] as $k => $lb) {
                $m = isset($v[$k]['missing']) && is_array($v[$k]['missing']) ? count($v[$k]['missing']) : 0; $om = isset($o[$k]['missing']) && is_array($o[$k]['missing']) ? count($o[$k]['missing']) : 0;
                $wd = isset($v[$k]['wDiff']) ? abs((float)$v[$k]['wDiff']) : 0;
                if (($m > 0 || !empty($v[$k]['wBad'])) && ($m !== $om || empty($o[$k]))) $add('field_' . $k, $lb . ' mein GADBAD: challan ' . $no . ' · ' . $st . ' · ' . $pn . ' · ' . $m . ' piece nahi mile' . ($wd > 0 ? ' · weight fark ' . number_format($wd, 3) . ' g' : ''), $c, $i, 'high');
            }
            if (!empty($v['far']) && empty($o['far'])) $add('field_far', 'Dukaan se DOOR check-in: challan ' . $no . ' · ' . $st . ' · ' . $pn . ' · ' . (int)$v['far'] . ' m door', $c, $i, 'medium');
            if (!empty($v['sealBad']) && empty($o['sealBad'])) $add('field_seal', 'SEAL nahi mila: challan ' . $no . ' · ' . $st . ' · ' . $pn, $c, $i, 'high');
            if (!empty($v['override']) && empty($o['override'])) $add('field_override', 'Gadbad ke baad aage badhne ki manzoori: challan ' . $no . ' · ' . $pn . ' · ' . (isset($v['override']['by']) ? $v['override']['by'] : '') . ' — ' . (isset($v['override']['why']) ? $v['override']['why'] : ''), $c, $i, 'medium');
        }
        $op = $old && isset($old['panic']) ? count((array)$old['panic']) : 0; $np = isset($new['panic']) ? count((array)$new['panic']) : 0;
        if ($np > $op) { $pz = end($new['panic']); $add('panic', '🆘 PANIC BUTTON: ' . $st . ' (challan ' . $no . ')' . (isset($pz['lat']) ? ' · location https://maps.google.com/?q=' . $pz['lat'] . ',' . $pz['lon'] : ''), $c, $i, 'high'); }
        if (!empty($new['ret']['short']) && empty($old['ret']['short'])) $add('field_short', 'Challan WAPSI mein kam maal: ' . $no . ' · ' . $st . ' · ' . (int)$new['ret']['short'] . ' piece · ' . (isset($new['ret']['shortWt']) ? number_format((float)$new['ret']['shortWt'], 3) . ' g' : '') . ' · ' . sj_inr(isset($new['ret']['shortVal']) ? $new['ret']['shortVal'] : 0), $c, $i, 'high');
        if (!empty($new['diffOk']) && empty($old['diffOk'])) $add('field_waive', 'Challan ka fark MAAF kiya: ' . $no . ' · ' . (isset($new['diffOkBy']) ? $new['diffOkBy'] : '') . ' — ' . (isset($new['diffOk']) ? (string)$new['diffOk'] : ''), $c, $i, 'medium');
        return;
    }
    if ($c === 'invoices' && is_array($new) && (!$old || json_encode(isset($old['items']) ? $old['items'] : null) !== json_encode(isset($new['items']) ? $new['items'] : null))) {
        $man = 0; foreach (isset($new['items']) && is_array($new['items']) ? $new['items'] : [] as $it) if (is_array($it) && isset($it['wSrc']) && $it['wSrc'] === 'manual') $man++;
        if ($man > 0) $add('manual_weight', 'Kaante ki jagah HAATH se weight likha: bill ' . (isset($new['no']) ? $new['no'] : $i) . ' · ' . $man . ' item', $c, $i, 'medium');
    }
    if ($c === 'floorTx' && is_array($new) && isset($new['status']) && $new['status'] === 'received' && !empty($new['short'])) $add('floor_short', 'Floor transfer mein KAM maal: ' . (isset($new['no']) ? $new['no'] : $i) . ' · ' . (int)$new['short'] . ' piece', $c, $i, 'high');
    if ($c === 'audits' && is_array($new) && !empty($new['missing']) && (!$old || count((array)$old['missing']) !== count((array)$new['missing']))) $add('audit_missing', 'Stock milaan mein piece NAHI MILE: ' . (isset($new['title']) ? $new['title'] : '') . ' · ' . count((array)$new['missing']) . ' piece', $c, $i, 'high');
}

/* ---------------- tamper-proof chain ---------------- */
const SJ_CHAIN_SKIP = ['summary', 'tagState'];
function sj_chain_hash($prev, $at, $ops) { return hash_hmac('sha256', $prev . '|' . $at . '|' . $ops, (sj_key() ?: 'sj') . '|chain'); }
function sj_chain_add($db, $rows, $uid, $kind = 'w') {   // rows: [[col, id, plainJson|null]]
    $ops = []; foreach ($rows as $r) { if (in_array(explode('/', $r[0])[0], SJ_CHAIN_SKIP, true)) continue; $ops[] = [$r[0], $r[1], $r[2] === null ? null : substr(hash('sha256', $r[2]), 0, 32)]; }
    if (!$ops) return;
    $prev = (string)$db->query('SELECT h FROM sj_chain ORDER BY n DESC LIMIT 1')->fetchColumn();
    $at = (int)round(microtime(true) * 1000); $oj = json_encode(['k' => $kind, 'o' => $ops], JSON_UNESCAPED_SLASHES);
    $db->prepare('INSERT INTO sj_chain (at, uid, ops, h) VALUES (?, ?, ?, ?)')->execute([$at, $uid, $oj, sj_chain_hash($prev, $at, $oj)]);
}
function sj_chain_genesis($label) {
    $db = sj_db(); $rows = [];
    foreach ($db->query('SELECT col, id, data FROM sj_docs WHERE deleted = 0 AND data IS NOT NULL') as $r) { if (in_array(explode('/', $r['col'])[0], SJ_CHAIN_SKIP, true)) continue; try { $rows[] = [$r['col'], $r['id'], sj_dec($r['data'], $r['col'], $r['id'])]; } catch (Exception $e) { /* unreadable row is reported by verify */ } }
    $db->beginTransaction(); try { sj_chain_add($db, $rows ?: [['system', 'genesis', '{}']], 'system', 'g:' . $label); $db->commit(); } catch (Exception $e) { $db->rollBack(); error_log('[shivaa] chain genesis: ' . $e->getMessage()); }
}
function sj_chain_verify() {
    $db = sj_db(); $prev = ''; $n = 0; $broken = null; $map = [];
    foreach ($db->query('SELECT n, at, ops, h FROM sj_chain ORDER BY n') as $r) {
        $n++;
        if (!hash_equals(sj_chain_hash($prev, (int)$r['at'], $r['ops']), $r['h'])) { $broken = ['n' => (int)$r['n'], 'at' => (int)$r['at']]; break; }
        $prev = $r['h']; $j = json_decode($r['ops'], true); if (!is_array($j)) continue;
        if (isset($j['k']) && strpos((string)$j['k'], 'g:') === 0) $map = [];
        foreach ($j['o'] as $o) $map[$o[0] . "\x01" . $o[1]] = $o[2];
    }
    if ($broken) return ['ok' => false, 'entries' => $n, 'broken' => $broken, 'changed' => [], 'missing' => []];
    $changed = []; $seen = [];
    foreach ($db->query('SELECT col, id, data FROM sj_docs WHERE deleted = 0 AND data IS NOT NULL') as $r) {
        if (in_array(explode('/', $r['col'])[0], SJ_CHAIN_SKIP, true)) continue; $k = $r['col'] . "\x01" . $r['id']; $seen[$k] = 1;
        try { $hh = substr(hash('sha256', sj_dec($r['data'], $r['col'], $r['id'])), 0, 32); } catch (Exception $e) { $hh = 'x'; }
        if (!array_key_exists($k, $map) || $map[$k] !== $hh) { if (count($changed) < 50) $changed[] = $r['col'] . '/' . $r['id']; }
    }
    $missing = []; foreach ($map as $k => $h) if ($h !== null && !isset($seen[$k]) && count($missing) < 50) $missing[] = str_replace("\x01", '/', $k);
    return ['ok' => !$changed && !$missing, 'entries' => $n, 'broken' => null, 'changed' => $changed, 'missing' => $missing];
}

/* ---------------- GPS ---------------- */
function sj_gps_devs() { $j = json_decode((string)sj_meta_get('gps_dev'), true); return is_array($j) ? $j : []; }
function sj_gps_save($dev, $lat, $lon, $spd, $acc, $batt, $at) {
    if (!is_finite($lat) || !is_finite($lon) || abs($lat) > 90 || abs($lon) > 180 || ($lat == 0 && $lon == 0)) return false;
    $last = json_decode((string)sj_meta_get('gps_last'), true); if (!is_array($last)) $last = [];
    if (isset($last[$dev]) && $at - (int)$last[$dev]['at'] < 8000 && $at >= (int)$last[$dev]['at']) return true;   // max one point / 8 s
    sj_db()->prepare('INSERT INTO sj_gps (dev, at, lat, lon, spd, acc, batt) VALUES (?, ?, ?, ?, ?, ?, ?)')->execute([$dev, $at, $lat, $lon, $spd, $acc, $batt]);
    if (!isset($last[$dev]) || $at >= (int)$last[$dev]['at']) { $last[$dev] = ['at' => $at, 'lat' => round($lat, 6), 'lon' => round($lon, 6), 'spd' => $spd, 'acc' => $acc, 'batt' => $batt]; sj_meta_set('gps_last', json_encode($last)); if (function_exists('sj_gps_watch')) { try { sj_gps_watch($dev, $lat, $lon, $at); } catch (Exception $e) { /* best effort */ } } }
    if (mt_rand(1, 500) === 1) sj_db()->prepare('DELETE FROM sj_gps WHERE at < ?')->execute([(time() - 120 * 86400) * 1000]);
    return true;
}
/* Traccar Client / OsmAnd protocol: ?id=&lat=&lon=&timestamp=&speed=&accuracy=&batt=  (also JSON body of newer Traccar Client) */
function sj_gps_push() {
    $q = $_GET + $_POST; $raw = file_get_contents('php://input'); $j = $raw ? json_decode($raw, true) : null;
    if (is_array($j)) { $loc = isset($j['location']) ? $j['location'] : $j; $co = isset($loc['coords']) ? $loc['coords'] : $loc;
        $q['id'] = isset($j['device_id']) ? $j['device_id'] : (isset($q['id']) ? $q['id'] : ''); $q['lat'] = isset($co['latitude']) ? $co['latitude'] : null; $q['lon'] = isset($co['longitude']) ? $co['longitude'] : null;
        $q['speed'] = isset($co['speed']) ? $co['speed'] : 0; $q['accuracy'] = isset($co['accuracy']) ? $co['accuracy'] : 0; $q['batt'] = isset($loc['battery']['level']) ? $loc['battery']['level'] * 100 : null;
        $q['timestamp'] = isset($loc['timestamp']) ? $loc['timestamp'] : null; }
    $id = preg_replace('/[^A-Za-z0-9_-]/', '', (string)(isset($q['id']) ? $q['id'] : (isset($q['deviceid']) ? $q['deviceid'] : '')));
    $devs = sj_gps_devs();
    if ($id === '' || !isset($devs[$id])) { sj_add_fail('g:' . sj_ip()); http_response_code(404); echo 'unknown device'; exit; }
    $ts = isset($q['timestamp']) ? $q['timestamp'] : null; $at = (int)round(microtime(true) * 1000);
    if (is_numeric($ts)) { $t = (float)$ts; $at = (int)($t > 1e12 ? $t : $t * 1000); } elseif (is_string($ts) && strtotime($ts)) $at = strtotime($ts) * 1000;
    if ($at > (time() + 300) * 1000) $at = (int)round(microtime(true) * 1000);
    $spd = isset($q['speed']) ? (float)$q['speed'] : 0; if (!is_array($j) && isset($q['speed'])) $spd = (float)$q['speed'] * 1.852;   // OsmAnd speed is knots → km/h
    $ok = sj_gps_save('d:' . $id, (float)(isset($q['lat']) ? $q['lat'] : 999), (float)(isset($q['lon']) ? $q['lon'] : 999), round($spd, 1), isset($q['accuracy']) ? (float)$q['accuracy'] : null, isset($q['batt']) ? (float)$q['batt'] : null, $at);
    http_response_code($ok ? 200 : 400); header('Content-Type: text/plain'); echo $ok ? 'OK' : 'bad location'; exit;
}

/* ---------------- RFID gate / reader bridge ---------------- */
function sj_rfid_push() {
    $key = (string)sj_meta_get('rfid_key'); $k = isset($_GET['k']) ? (string)$_GET['k'] : '';
    if ($key === '' || !hash_equals($key, $k)) { sj_add_fail('r:' . sj_ip()); sj_fail('forbidden', 403, 'Galat key'); }
    $raw = file_get_contents('php://input'); $j = $raw ? json_decode($raw, true) : null; $list = [];
    if (is_array($j)) $list = isset($j['epcs']) ? (array)$j['epcs'] : (isset($j['epc']) ? [$j['epc']] : []);
    if (isset($_GET['epc'])) $list = array_merge($list, explode(',', (string)$_GET['epc']));
    $gate = substr(preg_replace('/[^\p{L}\p{N} _-]/u', '', isset($_GET['gate']) ? (string)$_GET['gate'] : (is_array($j) && isset($j['gate']) ? (string)$j['gate'] : 'Gate')), 0, 40);
    $epcs = []; foreach (array_slice($list, 0, 300) as $e) { $e = strtoupper(preg_replace('/[^A-Fa-f0-9]/', '', (string)$e)); if (strlen($e) >= 8) $epcs[$e] = 1; }
    if (!$epcs) sj_out(['ok' => true, 'alarm' => false, 'items' => []]);
    $hit = [];
    foreach (sj_all_docs('products') as $p) { if (!is_array($p) || empty($p['rfid'])) continue; $e = strtoupper((string)$p['rfid']); if (!isset($epcs[$e])) continue;
        $st = isset($p['status']) ? $p['status'] : ''; if ($st === 'Sold' || !empty($p['custody'])) continue;
        $hit[] = ['sku' => isset($p['sku']) ? $p['sku'] : '', 'name' => trim((isset($p['category']) ? $p['category'] : '') . ' ' . (isset($p['purity']) ? $p['purity'] : '')), 'net' => isset($p['net']) ? $p['net'] : 0, 'status' => $st]; }
    if ($hit) {
        $key2 = 'gate:' . implode(',', array_map(function ($h) { return $h['sku']; }, $hit));
        $last = (int)sj_meta_get('gate_last:' . substr(hash('sha256', $key2), 0, 16));
        if (time() - $last > 300) { sj_meta_set('gate_last:' . substr(hash('sha256', $key2), 0, 16), (string)time()); sj_sec_alert('gate_alarm', '🚨 EXIT GATE ALARM (' . $gate . '): bina bill ka maal — ' . implode(', ', array_map(function ($h) { return '#' . $h['sku'] . ' ' . $h['name']; }, array_slice($hit, 0, 6))), 'high'); }
    }
    sj_out(['ok' => true, 'alarm' => !!$hit, 'items' => $hit]);
}

/* ---------------- retailer confirm page (no login; signed link) ---------------- */
function sj_ctok($cid, $vid) { return substr(hash_hmac('sha256', 'conf|' . $cid . '|' . $vid, sj_key() ?: 'sj'), 0, 24); }
function sj_confirm_page() {
    $cid = isset($_GET['c']) ? (string)$_GET['c'] : ''; $vid = isset($_GET['v']) ? (string)$_GET['v'] : ''; $k = isset($_GET['k']) ? (string)$_GET['k'] : '';
    header('Content-Type: text/html; charset=utf-8');
    $bad = function ($m) { http_response_code(404); echo sj_page_head('Shivaa Jewels') . '<div class="w"><div class="card"><h2>Link sahi nahi hai</h2><p class="sub">' . sj_h($m) . '</p></div></div></body></html>'; exit; };
    if (!sj_valid_id($cid) || !preg_match('/^[A-Za-z0-9_-]{4,40}$/', $vid) || !hash_equals(sj_ctok($cid, $vid), $k)) { sj_add_fail('v:' . sj_ip()); $bad('Ye link galat ya purana hai.'); }
    $ch = sj_load_doc('challans', $cid); if (!is_array($ch)) $bad('Challan nahi mila.');
    $v = null; foreach (isset($ch['visits']) ? $ch['visits'] : [] as $x) if (isset($x['id']) && $x['id'] === $vid) $v = $x; if (!$v) $bad('Visit nahi mila.');
    $done = sj_load_doc('fieldConfirms', $vid);
    $set = sj_load_doc('settings', 'main'); $firm = is_array($set) && !empty($set['firm']) ? $set['firm'] : 'Shivaa Jewels';
    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST' && !$done) {
        $n = isset($_POST['n']) ? (string)$_POST['n'] : ''; if (!hash_equals(substr(hash_hmac('sha256', 'cn|' . $vid . '|' . gmdate('Y-m-d'), sj_key() ?: 'sj'), 0, 20), $n)) $bad('Page purana ho gaya — link dobara kholiye.');
        $done = ['id' => $vid, 'challanId' => $cid, 'at' => (int)round(microtime(true) * 1000), 'ip' => sj_ip(), 'ua' => substr(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '', 0, 160), 'name' => substr(trim(isset($_POST['name']) ? (string)$_POST['name'] : ''), 0, 60)];
        sj_put_docs([['fieldConfirms', $vid, $done]], 'retailer');
    }
    $sel = isset($v['sel']) && is_array($v['sel']) ? $v['sel'] : []; $tw = 0; $rows = '';
    foreach ($sel as $s) { $tw += (float)(isset($s['net']) ? $s['net'] : 0); $rows .= '<tr><td>#' . sj_h(isset($s['sku']) ? $s['sku'] : '') . '</td><td>' . sj_h(isset($s['name']) ? $s['name'] : '') . '</td><td class="n">' . number_format((float)(isset($s['net']) ? $s['net'] : 0), 3) . ' g</td><td>' . (isset($s['mode']) && $s['mode'] === 'sale' ? 'Kharida' : 'Approval') . '</td></tr>'; }
    $o = sj_page_head($firm . ' — maal ki pushti', "'self'");
    $o .= '<div class="w"><div class="firm">' . sj_h($firm) . '</div><div class="card"><h2>Maal ki pushti</h2><p class="sub">' . sj_h(isset($v['party']) ? $v['party'] : '') . ' · challan ' . sj_h(isset($ch['no']) ? $ch['no'] : '') . ' · staff ' . sj_h(isset($ch['staff']) ? $ch['staff'] : '') . '</p>';
    $o .= '<div class="tw"><table><thead><tr><th>Tag</th><th>Gehna</th><th class="n">Wazan</th><th></th></tr></thead><tbody>' . ($rows ?: '<tr><td colspan="4">Koi piece nahi</td></tr>') . '</tbody></table></div><p class="sub"><b>Kul: ' . count($sel) . ' piece · ' . number_format($tw, 3) . ' g</b></p>';
    if ($done) $o .= '<p class="ok">✓ Aapne pushti kar di — ' . gmdate('d-m-Y h:i A', (int)($done['at'] / 1000) + 19800) . '. Dhanyavaad!</p>' . (function_exists('sj_conf_code') ? '<p class="sub">Staff ke phone mein net na ho to unhe ye <b>pushti code</b> bataiye:</p><p style="font:700 30px/1.2 ui-monospace,monospace;letter-spacing:4px;text-align:center;margin:10px 0">' . sj_h(implode(' ', str_split(sj_conf_code($vid), 4))) . '</p>' : '');
    else $o .= '<form method="post"><input type="hidden" name="n" value="' . sj_h(substr(hash_hmac('sha256', 'cn|' . $vid . '|' . gmdate('Y-m-d'), sj_key() ?: 'sj'), 0, 20)) . '"><input name="name" maxlength="60" placeholder="Aapka naam" style="width:100%;padding:12px;border-radius:12px;border:1px solid #ccc;margin:8px 0;font:inherit"><button class="btn">✓ Haan, ye maal maine liya / rakha</button></form><p class="note">Agar list galat hai to pushti mat kijiye aur ' . sj_h($firm) . ' ko turant phone kijiye.</p>';
    $o .= '</div><div class="foot">' . sj_h($firm) . ' · ye page sirf is visit ke liye hai</div></div></body></html>';
    echo $o; exit;
}

/* ---------------- cron (Hostinger → Advanced → Cron Jobs) ---------------- */
function sj_cron() {
    $key = (string)sj_meta_get('cron_key'); $k = isset($_GET['k']) ? (string)$_GET['k'] : '';
    if ($key === '' || !hash_equals($key, $k)) { sj_add_fail('c:' . sj_ip()); sj_fail('forbidden', 403); }
    @set_time_limit(120); $out = [];
    try { sj_auto_backup(); $out[] = 'backup'; } catch (Exception $e) { $out[] = 'backup-fail'; }
    if (sj_meta_get('backup_mail') === '1' && (int)gmdate('G', time() + 19800) >= 22) { try { sj_backup_mail(false); $out[] = 'mail'; } catch (Exception $e) { $out[] = 'mail-fail'; } }
    // challans still out late in the evening / from an earlier day
    $today = gmdate('Y-m-d', time() + 19800); $late = (int)gmdate('G', time() + 19800) >= 20;
    foreach (sj_all_docs('challans') as $c) {
        if (!is_array($c) || !in_array(isset($c['status']) ? $c['status'] : '', ['issued', 'out'], true)) continue;
        $d = isset($c['date']) ? $c['date'] : $today;
        if ($d < $today || $late) { $key2 = 'late:' . (isset($c['id']) ? $c['id'] : '') . ':' . $today . ($late ? 'e' : '');
            if (sj_once_today($key2)) sj_sec_alert('field_late', 'Challan ' . (isset($c['no']) ? $c['no'] : '') . ' (' . (isset($c['staff']) ? $c['staff'] : '') . ') abhi tak WAPAS nahi aaya · maal ' . sj_inr(isset($c['value']) ? $c['value'] : 0), 'high'); }
    }
    $out[] = 'challans';
    if (function_exists('sj_v42_cron')) sj_v42_cron($out);
    if (mt_rand(1, 20) === 1) sj_db()->prepare('DELETE FROM sj_gps WHERE at < ?')->execute([(time() - 120 * 86400) * 1000]);
    sj_meta_set('cron_last', (string)time());
    sj_out(['ok' => true, 'done' => $out]);
}

/* ---------------- routes ---------------- */
function sj_sec_route($a) {
    switch ($a) {
    case 'sec_status': {   // the policy everybody's app needs + my own security state
        $u = sj_require_user(); $x = sj_uext($u['id']); $p = sj_pol();
        sj_out(['ok' => true, 'policy' => $p, 'me' => ['pin' => !empty($x['pin']), 'floor' => isset($x['floor']) ? $x['floor'] : '', 'field' => !empty($x['field']), 'anyHours' => !empty($x['anyHours']), 'totp' => sj_utotp_on($u['id'])], 'elev' => sj_elevated(), 'device' => sj_dev_id()]);
    }
    case 'sec_policy': {
        sj_require_role(['owner']); $b = sj_body(); $need = sj_need_pin(sj_user()); if ($need === 'pin_required' && sj_pol()['pin']) sj_pin_fail($need);
        $cur = sj_pol(); $n = $cur;
        foreach (['hours', 'devices', 'pin', 'totpAll', 'dayLock', 'exportOwner', 'floorWall', 'maskPii', 'cash269', 'panRule', 'fieldPhoto', 'creditBlock'] as $k) if (isset($b[$k])) $n[$k] = !!$b[$k];
        foreach (['from', 'to'] as $k) if (isset($b[$k]) && preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', (string)$b[$k])) $n[$k] = (string)$b[$k];
        foreach (['discStaff' => [0, 100], 'discMgr' => [0, 100], 'ogStaff' => [0, 1e9], 'idleMin' => [0, 240], 'fieldMax' => [0, 1e10], 'fieldTwo' => [0, 1e10], 'tolG' => [0, 5], 'tolPc' => [0, 1], 'radius' => [30, 5000], 'stayMin' => [10, 240], 'noLocMin' => [15, 480]] as $k => $r) if (isset($b[$k]) && is_numeric($b[$k])) $n[$k] = max($r[0], min($r[1], (float)$b[$k]));
        if ($n['devices'] && !$cur['devices']) {   // switching on: this device and every device in use today is approved
            $all = sj_devs(); $me = sj_dev_id(); if (!isset($all[$me])) $all[$me] = ['name' => sj_dev_name(), 'first' => time(), 'users' => []];
            foreach ($all as $id => &$d) if (!isset($d['st']) || $d['st'] !== 'blocked') $d['st'] = 'ok'; unset($d); sj_devs_put($all);
        }
        sj_meta_set('sec_policy', json_encode($n)); sj_sec_alert('policy', 'Suraksha ke niyam badle (Owner)', 'medium', sj_user());
        sj_out(['ok' => true, 'policy' => $n]);
    }
    case 'uext_save': {   // Owner: floor / field staff / hours exemption / PIN reset / 2-step reset for a login
        sj_require_role(['owner']); $b = sj_body(); $id = sj_str($b, 'id', 32);
        $st = sj_db()->prepare('SELECT id FROM sj_users WHERE id = ?'); $st->execute([$id]); if (!$st->fetch()) sj_fail('not_found', 404, 'Login nahi mila.');
        $x = sj_uext($id);
        if (isset($b['floor'])) $x['floor'] = substr(preg_replace('/[^\p{L}\p{N} _-]/u', '', (string)$b['floor']), 0, 20);
        foreach (['field', 'anyHours'] as $k) if (isset($b[$k])) $x[$k] = !!$b[$k];
        if (!empty($b['pinReset'])) unset($x['pin']);
        if (!empty($b['totpReset']) && $id !== SJ_OWNER_ID) sj_utotp_put($id, null);
        sj_uext_put($id, $x); sj_out(['ok' => true]);
    }
    case 'uext_list': {
        sj_require_role(['owner', 'manager']); $out = [];
        foreach (sj_db()->query('SELECT id, uname, name, role, active FROM sj_users ORDER BY name')->fetchAll() as $r) { $x = sj_uext($r['id']); $out[] = ['id' => $r['id'], 'uname' => $r['uname'], 'name' => $r['name'], 'role' => $r['role'], 'active' => (int)$r['active'], 'floor' => isset($x['floor']) ? $x['floor'] : '', 'field' => !empty($x['field']), 'anyHours' => !empty($x['anyHours']), 'pin' => !empty($x['pin']), 'totp' => sj_utotp_on($r['id'])]; }
        sj_out(['ok' => true, 'users' => $out]);
    }
    case 'pin_set': {
        $u = sj_require_user(); $b = sj_body();
        if (sj_throttled($u['uname'])) sj_fail('throttled', 429, 'Bahut baar galat koshish hui. 15 minute baad try kijiye.');
        $st = sj_db()->prepare('SELECT pass FROM sj_users WHERE id = ?'); $st->execute([$u['id']]);
        if (!password_verify(isset($b['password']) ? (string)$b['password'] : '', (string)$st->fetchColumn())) { sj_add_fail($u['uname']); sj_fail('wrong_password', 403, 'Password galat hai.'); }
        $pin = preg_replace('/\D/', '', isset($b['pin']) ? (string)$b['pin'] : '');
        if (strlen($pin) < 4 || strlen($pin) > 8) sj_fail('bad_pin', 400, 'PIN 4 se 8 ank ka rakhiye.');
        if (preg_match('/^(\d)\1+$/', $pin) || in_array($pin, ['1234', '12345', '123456', '4321', '0000'], true)) sj_fail('weak_pin', 400, 'Itna aasaan PIN nahi — doosra chuniye.');
        $x = sj_uext($u['id']); $x['pin'] = password_hash($pin, PASSWORD_DEFAULT); sj_uext_put($u['id'], $x);
        sj_out(['ok' => true]);
    }
    case 'pin_check': {
        $u = sj_require_user(); $b = sj_body(); $x = sj_uext($u['id']);
        if (empty($x['pin'])) sj_pin_fail('pin_not_set');
        if (sj_throttled('pin:' . $u['uname'])) sj_fail('throttled', 429, 'Bahut baar galat PIN. 15 minute baad try kijiye.');
        if (!password_verify(preg_replace('/\D/', '', isset($b['pin']) ? (string)$b['pin'] : ''), $x['pin'])) { sj_add_fail('pin:' . $u['uname']); if (sj_throttled('pin:' . $u['uname'])) sj_sec_alert('pin_lock', 'PIN baar-baar GALAT: ' . $u['name'] . ' — 15 minute ke liye band', 'high', $u); sj_fail('wrong_pin', 403, 'PIN galat hai.'); }
        $h = sj_token_hash(); sj_db()->prepare('UPDATE sj_tokens SET elev = ? WHERE h = ?')->execute([time() + 300, $h]);
        sj_out(['ok' => true, 'until' => time() + 300]);
    }
    case 'pin_ok': { $u = sj_require_user(); $need = sj_need_pin($u); if ($need) sj_pin_fail($need); sj_out(['ok' => true]); }
    case 'my_totp_init': {
        $u = sj_require_user(); $b = sj_body();
        if (sj_throttled($u['uname'])) sj_fail('throttled', 429, 'Bahut baar galat koshish hui. 15 minute baad try kijiye.');
        $st = sj_db()->prepare('SELECT pass FROM sj_users WHERE id = ?'); $st->execute([$u['id']]);
        if (!password_verify(isset($b['password']) ? (string)$b['password'] : '', (string)$st->fetchColumn())) { sj_add_fail($u['uname']); sj_fail('wrong_password', 403, 'Password galat hai.'); }
        $sec = sj_b32_enc(random_bytes(20)); sj_meta_set('tpend:' . $u['id'], sj_enc(json_encode(['secret' => $sec, 'at' => time()]), 'meta', 'tpend:' . $u['id']));
        sj_out(['ok' => true, 'secret' => $sec, 'uri' => sj_totp_uri($u['uname'], $sec)]);
    }
    case 'my_totp_enable': {
        $u = sj_require_user(); $b = sj_body(); $pk = 'tpend:' . $u['id'];
        $pv = sj_meta_get($pk); $pj = $pv ? json_decode((string)sj_dec($pv, 'meta', $pk), true) : null;
        if (!is_array($pj) || time() - (int)$pj['at'] > 1800) sj_fail('expired', 400, 'Setup purana ho gaya — dobara shuru kijiye.');
        $hit = sj_totp_match($pj['secret'], isset($b['code']) ? $b['code'] : ''); if ($hit === false) { sj_add_fail($u['uname']); sj_fail('wrong_otp', 403, 'Code nahi mila — phone ka time sahi hai? App mein naya code daaliye.'); }
        list($codes, $hash) = sj_new_codes(); sj_utotp_put($u['id'], ['secret' => $pj['secret'], 'codes' => $hash, 'last' => $hit, 'since' => time()]);
        sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute([$pk]);
        sj_out(['ok' => true, 'codes' => $codes]);
    }
    case 'totp_enroll': {   // first login when "2-step for everybody" is on: ticket from login + code from the app
        sj_require_secure(); $b = sj_body(); $t = preg_replace('/[^a-f0-9]/', '', sj_str($b, 'ticket', 64));
        if (sj_throttled()) sj_fail('throttled', 429, 'Bahut baar galat koshish hui. 15 minute baad try kijiye.');
        $k = 'tenroll:' . $t; $v = $t ? sj_meta_get($k) : null; $j = $v ? json_decode((string)sj_dec($v, 'meta', $k), true) : null;
        if (!is_array($j) || time() - (int)$j['at'] > 900) sj_fail('expired', 400, 'Samay nikal gaya — dobara login kijiye.');
        $hit = sj_totp_match($j['secret'], isset($b['code']) ? $b['code'] : ''); if ($hit === false) { sj_add_fail(); sj_fail('wrong_otp', 403, 'Code nahi mila — app mein naya code daaliye.'); }
        list($codes, $hash) = sj_new_codes(); sj_utotp_put($j['uid'], ['secret' => $j['secret'], 'codes' => $hash, 'last' => $hit, 'since' => time()]);
        sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute([$k]);
        $st = sj_db()->prepare('SELECT * FROM sj_users WHERE id = ?'); $st->execute([$j['uid']]); $u = $st->fetch(); if (!$u) sj_fail('not_found', 404);
        sj_issue_token($u['id']); sj_out(['ok' => true, 'user' => sj_public_user($u), 'codes' => $codes]);
    }
    case 'devices': {
        sj_require_role(['owner']); $all = sj_devs(); $me = sj_dev_id(); $out = [];
        foreach ($all as $id => $d) $out[] = ['id' => $id, 'name' => isset($d['name']) ? $d['name'] : '', 'st' => isset($d['st']) ? $d['st'] : 'ok', 'first' => isset($d['first']) ? $d['first'] : 0, 'last' => isset($d['last']) ? $d['last'] : 0, 'ip' => isset($d['ip']) ? $d['ip'] : '', 'users' => isset($d['users']) ? $d['users'] : [], 'label' => isset($d['label']) ? $d['label'] : '', 'me' => $id === $me];
        usort($out, function ($a, $b) { return ($a['st'] === 'pending' ? 0 : 1) - ($b['st'] === 'pending' ? 0 : 1) ?: $b['last'] - $a['last']; });
        sj_out(['ok' => true, 'devices' => $out]);
    }
    case 'device_set': {
        $u = sj_require_role(['owner']); $b = sj_body(); $id = preg_replace('/[^a-f0-9]/', '', sj_str($b, 'id', 24)); $all = sj_devs();
        if (!isset($all[$id])) sj_fail('not_found', 404, 'Device nahi mila.');
        if ($id === sj_dev_id() && isset($b['st']) && $b['st'] !== 'ok') sj_fail('invalid_argument', 400, 'Jis device par aap abhi hain use block nahi kar sakte.');
        if (isset($b['label'])) $all[$id]['label'] = substr(trim((string)$b['label']), 0, 40);
        if (!empty($b['remove'])) { unset($all[$id]); sj_db()->prepare('DELETE FROM sj_tokens WHERE dev = ?')->execute([$id]); }
        elseif (isset($b['st']) && in_array($b['st'], ['ok', 'blocked', 'pending'], true)) { $all[$id]['st'] = $b['st']; if ($b['st'] === 'blocked') sj_db()->prepare('DELETE FROM sj_tokens WHERE dev = ?')->execute([$id]); }
        sj_devs_put($all); sj_out(['ok' => true]);
    }
    case 'chain_verify': { sj_require_role(['owner']); @set_time_limit(120); sj_out(['ok' => true, 'result' => sj_chain_verify()]); }
    case 'confirm_tok': { $u = sj_require_user(); $b = sj_body(); $c = sj_str($b, 'c', 200); $v = sj_str($b, 'v', 40); if (!sj_valid_id($c) || !preg_match('/^[A-Za-z0-9_-]{4,40}$/', $v)) sj_fail('invalid_argument', 400); sj_out(['ok' => true, 'k' => sj_ctok($c, $v)]); }
    case 'loc_push': {   // the app itself (phone browser) while a challan is active
        $u = sj_require_user(); $b = sj_body();
        $ok = sj_gps_save('u:' . $u['id'], (float)(isset($b['lat']) ? $b['lat'] : 999), (float)(isset($b['lon']) ? $b['lon'] : 999), isset($b['spd']) ? round((float)$b['spd'] * 3.6, 1) : null, isset($b['acc']) ? (float)$b['acc'] : null, isset($b['batt']) ? (float)$b['batt'] : null, (int)round(microtime(true) * 1000));
        sj_out(['ok' => $ok]);
    }
    case 'gps_cfg': {   // Owner: list / add / remove tracked devices (cars, Traccar Client phones)
        sj_require_role(['owner']); $b = sj_body(); $devs = sj_gps_devs();
        if (!empty($b['add'])) { $id = strtolower(bin2hex(random_bytes(8))); $devs[$id] = ['name' => substr(trim((string)(isset($b['name']) ? $b['name'] : 'Car')), 0, 40) ?: 'Car', 'kind' => in_array(isset($b['kind']) ? $b['kind'] : '', ['car', 'staff'], true) ? $b['kind'] : 'car', 'staff' => substr(trim((string)(isset($b['staff']) ? $b['staff'] : '')), 0, 40), 'at' => time()]; sj_meta_set('gps_dev', json_encode($devs)); }
        if (!empty($b['remove'])) { $id = preg_replace('/[^a-z0-9]/', '', (string)$b['remove']); unset($devs[$id]); sj_meta_set('gps_dev', json_encode($devs)); }
        if (!empty($b['rename'])) { $id = preg_replace('/[^a-z0-9]/', '', (string)$b['rename']); if (isset($devs[$id])) { $devs[$id]['name'] = substr(trim((string)(isset($b['name']) ? $b['name'] : '')), 0, 40) ?: $devs[$id]['name']; sj_meta_set('gps_dev', json_encode($devs)); } }
        sj_out(['ok' => true, 'devices' => $devs]);
    }
    case 'gps_live': {
        sj_require_role(['owner', 'manager']); $last = json_decode((string)sj_meta_get('gps_last'), true); $devs = sj_gps_devs();
        $users = []; foreach (sj_db()->query('SELECT id, name FROM sj_users')->fetchAll() as $r) $users[$r['id']] = $r['name'];
        $out = [];
        foreach (is_array($last) ? $last : [] as $k => $p) {
            if (strpos($k, 'd:') === 0) { $id = substr($k, 2); if (!isset($devs[$id])) continue; $out[] = ['key' => $k, 'name' => $devs[$id]['name'], 'kind' => $devs[$id]['kind'], 'staff' => isset($devs[$id]['staff']) ? $devs[$id]['staff'] : ''] + $p; }
            elseif (strpos($k, 'u:') === 0) { $id = substr($k, 2); if (!isset($users[$id])) continue; $out[] = ['key' => $k, 'name' => $users[$id], 'kind' => 'phone', 'uid' => $id] + $p; }
        }
        sj_out(['ok' => true, 'points' => $out, 'now' => (int)round(microtime(true) * 1000), 'devices' => $devs]);
    }
    case 'gps_track': {
        sj_require_role(['owner', 'manager']); $b = sj_body(); $k = preg_replace('/[^a-z0-9_:]/', '', sj_str($b, 'key', 60)); $d = sj_str($b, 'date', 10);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) $d = gmdate('Y-m-d', time() + 19800);
        $a0 = (strtotime($d . ' 00:00:00 UTC') - 19800) * 1000; $st = sj_db()->prepare('SELECT at, lat, lon, spd FROM sj_gps WHERE dev = ? AND at >= ? AND at < ? ORDER BY at LIMIT 5000'); $st->execute([$k, $a0, $a0 + 86400000]);
        $pts = []; foreach ($st->fetchAll() as $r) $pts[] = [(int)$r['at'], (float)$r['lat'], (float)$r['lon'], $r['spd'] === null ? null : (float)$r['spd']];
        sj_out(['ok' => true, 'points' => $pts]);
    }
    case 'keys': {   // Owner: secret keys for cron / RFID gate (made on first ask)
        sj_require_role(['owner']); $b = sj_body(); $out = [];
        foreach (['cron_key', 'rfid_key'] as $k) { $v = (string)sj_meta_get($k); if ($v === '' || (!empty($b['renew']) && $b['renew'] === $k)) { $v = bin2hex(random_bytes(16)); sj_meta_set($k, $v); } $out[$k] = $v; }
        $out['cron_last'] = (int)sj_meta_get('cron_last'); sj_out(['ok' => true] + $out);
    }
    }
    return false;
}
