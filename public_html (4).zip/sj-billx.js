/* =====================================================================
   SJ BILL — "Signature" design (v24)
   A4 page painted at 300 DPI (2480 × 3508 px) on a canvas → print-quality PDF.
   - gold-foil header, photo of every item, BIS price breakup in the table
   - today's rate strip, payment + UPI QR, totals with status
   - "Lifetime Privilege" promotion coupon (20% off making charges)
   - bundled fonts (Lora + Poppins) so every device prints the same
   ===================================================================== */
(() => {
  'use strict';
  if (typeof Pdf === 'undefined' || typeof billData === 'undefined') return;
  const PX = 2480, PY = 3508, MM = PX / 210, M = 118, CW = PX - 2 * M;
  const SERIF = '"SJ Lora", "Lora", Georgia, "Times New Roman", serif';
  const SANS = '"SJ Poppins", "Poppins", "Plus Jakarta Sans", "Mukta", system-ui, sans-serif';
  const HIN = '"SJ Poppins", "Mukta", "Noto Sans Devanagari", "Nirmala UI", "FreeSans", sans-serif';
  const C = { ink: '#1b1610', mut: '#6f6553', line: '#e4d7b8', cream: '#fbf6ea', ivory: '#fffdf8', gold: '#b98a2d', goldT: '#8a6618', dark: '#0d0b07', red: '#b3261e', green: '#1e7a46' };
  const GOLD = ['#fff1bf', '#efc95e', '#b98a2d', '#f6dc8c', '#9c6f17'];

  /* ---------- fonts (bundled, OFL) ---------- */
  let fontsP = null;
  function loadFonts() {
    if (fontsP) return fontsP;
    const list = [['SJ Lora', 'fonts/Lora-Variable.ttf', { weight: '400 700' }], ['SJ Lora', 'fonts/Lora-Italic-Variable.ttf', { weight: '400 700', style: 'italic' }],
      ['SJ Poppins', 'fonts/Poppins-Light.ttf', { weight: '300' }], ['SJ Poppins', 'fonts/Poppins-Regular.ttf', { weight: '400' }], ['SJ Poppins', 'fonts/Poppins-Medium.ttf', { weight: '500' }], ['SJ Poppins', 'fonts/Poppins-Bold.ttf', { weight: '700' }]];
    fontsP = Promise.all(list.map(([fam, url, d]) => { try { const f = new FontFace(fam, `url(${url})`, d); return f.load().then(x => { document.fonts.add(x); return true; }).catch(() => false); } catch (e) { return Promise.resolve(false); } }))
      .then(r => (document.fonts && document.fonts.load ? Promise.all(['400 40px "Mukta"', '700 40px "Mukta"'].map(s => document.fonts.load(s).catch(() => null))) : null).then(() => r));
    return fontsP;
  }

  /* ---------- drawing helpers ---------- */
  const loadImg = src => new Promise(res => { if (!src) return res(null); const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = src; });
  const font = (x, w, s, fam, it) => { x.font = `${it ? 'italic ' : ''}${w} ${s}px ${fam || SANS}`; };
  const grad = (x, x0, y0, x1, y1, cols) => { const g = x.createLinearGradient(x0, y0, x1, y1); (cols || GOLD).forEach((c, i, a) => g.addColorStop(i / (a.length - 1), c)); return g; };
  function rr(x, X, Y, w, h, r) { r = Math.min(r, w / 2, h / 2); x.beginPath(); x.moveTo(X + r, Y); x.arcTo(X + w, Y, X + w, Y + h, r); x.arcTo(X + w, Y + h, X, Y + h, r); x.arcTo(X, Y + h, X, Y, r); x.arcTo(X, Y, X + w, Y, r); x.closePath(); }
  function fit(x, s, maxW, w, size, fam, min) { let z = size; font(x, w, z, fam); while (maxW && z > (min || size * 0.6) && x.measureText(s).width > maxW) { z -= 1; font(x, w, z, fam); } return z; }
  function T(x, s, X, Y, o) { o = o || {}; s = String(s == null ? '' : s); fit(x, s, o.maxW, o.w || 400, o.size || 30, o.fam, o.min); x.fillStyle = o.color || C.ink; x.textAlign = o.align || 'left'; x.textBaseline = o.base || 'alphabetic';
    if (o.ls) { try { x.letterSpacing = o.ls + 'px'; } catch (e) { /* older browsers */ } } x.fillText(s, X, Y); if (o.ls) { try { x.letterSpacing = '0px'; } catch (e) { /* */ } } }
  function wrap(x, s, maxW, w, size, fam) { font(x, w, size, fam); const out = []; String(s || '').split('\n').forEach(par => { let line = ''; par.split(/\s+/).forEach(word => { const t = line ? line + ' ' + word : word; if (x.measureText(t).width > maxW && line) { out.push(line); line = word; } else line = t; }); if (line) out.push(line); }); return out; }
  const money = n => '₹ ' + fmtAmt(n), g3x = n => num(n).toFixed(3) + ' g';
  const jpeg = (c, q) => { const bin = atob(c.toDataURL('image/jpeg', q).split(',')[1]); const d = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) d[i] = bin.charCodeAt(i); return { data: d, w: c.width, h: c.height }; };
  function qrDraw(x, text, X, Y, size, dark) { let Mx; try { Mx = QR.encode(text); } catch (e) { return false; } const n = Mx.length, u = size / (n + 2); x.fillStyle = '#ffffff'; x.fillRect(X, Y, size, size); x.fillStyle = dark || '#111'; for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (Mx[r][c]) x.fillRect(Math.round(X + (c + 1) * u), Math.round(Y + (r + 1) * u), Math.ceil(u), Math.ceil(u)); return true; }
  function sheen(x, x0, y0, x1, y1) { const g = x.createLinearGradient(x0, y0, x1, y1); [['#8a6212', 0], ['#e9c35a', 0.18], ['#fff4c8', 0.32], ['#d9a93a', 0.46], ['#9c6f17', 0.62], ['#f3d27a', 0.8], ['#b98a2d', 1]].forEach(([c, o]) => g.addColorStop(o, c)); return g; }
  async function goldLogo(src, w) { const im = await loadImg(src); if (!im || !im.naturalWidth) return null; const h = Math.round(w * im.naturalHeight / im.naturalWidth); const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.drawImage(im, 0, 0, w, h); x.globalCompositeOperation = 'source-in'; x.fillStyle = grad(x, 0, 0, w, h); x.fillRect(0, 0, w, h); return c; }
  const hallmark = it => { const t = num(it.tunch); const map = [[99.9, '999'], [99.5, '995'], [95.8, '958'], [91.6, '916'], [87.5, '875'], [83.3, '833'], [75, '750'], [58.5, '585'], [92.5, '925'], [80, '800']]; const h = map.find(([k]) => Math.abs(k - t) < 0.15); return h ? h[1] : ''; };
  function photoOf(it) { const p = S.products.find(q => (it.productId && q.id === it.productId) || (it.sku && q.sku === it.sku)); return p && p.photo ? p.photo : ''; }
  function privilegeId(v) { const c = (S.customers || []).find(q => q.id === v.partyId) || {}; const ph = String(c.phone || v.partyPhone || '').replace(/\D/g, '').slice(-4) || '0000'; let h = 0; String(c.id || v.partyId || v.partyName || '').split('').forEach(ch => { h = (h * 31 + ch.charCodeAt(0)) >>> 0; }); return 'SJP-' + ph + '-' + h.toString(36).toUpperCase().slice(-4).padStart(4, '0'); }

  /* ---------- bill verification QR (server-signed link, works for old bills too) ---------- */
  const VT = new Map();
  const verifyBase = () => location.origin + location.pathname.replace(/[^/]*$/, '');
  async function verifyUrl(v) {
    if (!window.SJ_API_CALL || !v || !v.id || !/^https?:/.test(location.protocol)) return '';
    if (!VT.has(v.id)) { try { const r = await Promise.race([window.SJ_API_CALL('verify_tok', { ids: [v.id] }), new Promise((_, rej) => setTimeout(() => rej(new Error('slow')), 7000))]); if (r && r.tokens && r.tokens[v.id]) VT.set(v.id, r.tokens[v.id]); } catch (e) { return ''; } }
    const k = VT.get(v.id); return k ? verifyBase() + 'verify.php?i=' + encodeURIComponent(v.id) + '&k=' + k : '';
  }
  /* print resolution: 360 DPI on computers, 300 DPI on phones (memory) — both are print-shop quality */
  const DPI_K = () => { const mob = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent || '') || (navigator.deviceMemory && navigator.deviceMemory < 4); return mob ? 1 : 1.2; };
  const shrink = (c, k) => { const o = document.createElement('canvas'); o.width = Math.round(c.width * k); o.height = Math.round(c.height * k); const g = o.getContext('2d'); g.imageSmoothingQuality = 'high'; g.drawImage(c, 0, 0, o.width, o.height); return o; };

  /* ---------- the bill ---------- */
  async function signatureInvoicePdf(v, o) {
    o = o || {};
    await loadFonts();
    const vurl = o.noVerify ? '' : await verifyUrl(v);
    const D = billData(v), B = D.B, t = D.t, s = settings();
    const retail = !D.buy && D.type !== 'metal' && D.chan !== 'wholesale';
    const due = invDue(v), paid = invPaid(v), payable = invPayable(v);
    const own = !B.logo || B.logo === SJ_LOGO || (typeof BILL_LOGO !== 'undefined' && B.logo === BILL_LOGO);
    const logo = own ? await goldLogo(SJ_LOGO, 900) : await loadImg(B.logo);
    const wm = own ? await goldLogo(SJ_LOGO, 1500) : null;
    const bis = B.showBis !== false && typeof BIS_LOGO !== 'undefined' ? await loadImg(BIS_LOGO) : null;
    const photos = await Promise.all(D.items.map(it => loadImg(photoOf(it))));
    const anyPhoto = photos.some(Boolean);
    let rate24 = 0, rateAg = 0; try { if (v.date === todayStr() || typeof advRateAt !== 'function') { rate24 = num(s.gold24); rateAg = num(s.silver999); } else { rate24 = num(advRateAt(v.date, 'gold')) || num(s.gold24); rateAg = num(advRateAt(v.date, 'silver')) || num(s.silver999); } } catch (e) { /* */ }
    const [tMain, tSub] = String(D.docTitle || 'TAX INVOICE').split(' -- ');
    const promo = retail;   // the lifetime-making coupon is for retail customers only

    /* columns: retail shows the BIS breakup inside the table; others follow the app's own columns */
    const sale = it => { const c = calcItem(it, v.type); const tn = num(it.tunch) > 0 ? num(it.tunch) : 100; const pure = v.type === 'metal' ? 0 : r2(c.net * tn / 100 * num(it.rate)); return { c, pure, stone: num(it.stone), hm: num(it.hm), making: r2(Math.max(0, c.amount - pure - num(it.stone) - num(it.hm))) }; };
    let cols;
    if (retail) cols = [['#', 50, 'c', (it, i) => String(i + 1)], ['', 230, 'photo'], ['ITEM DETAILS', 410, 'desc'], ['GROSS / NET', 235, 'r', it => [g3x(it.gross), num(it.less) ? 'Net ' + g3x(it.net) : '']], ['PURITY', 150, 'r', it => [String(it.purity || ''), hallmark(it) ? hallmark(it) + ' · ' + num(it.tunch) + '%' : (num(it.tunch) ? num(it.tunch) + '%' : '')]], ['RATE / g', 185, 'r', it => { const x = sale(it); const tn = num(it.tunch) > 0 ? num(it.tunch) : 100; return [num(it.rate) ? '₹' + fmtAmt(r2(num(it.rate) * tn / 100)) : '', '']; }], ['METAL VALUE', 235, 'r', it => [fmtAmt(sale(it).pure), '']], ['MAKING', 215, 'r', it => { const x = sale(it); const pg = x.c.net > 0 && x.making ? '₹' + fmtAmt(Math.round(x.making / x.c.net)) + '/g' : ''; return [fmtAmt(x.making), [num(it.wastage) ? 'W ' + num(it.wastage) + '%' : '', pg].filter(Boolean).join(' · ')]; }], ['STONE / HM', 165, 'r', it => { const x = sale(it); return [x.stone + x.hm ? fmtAmt(x.stone + x.hm) : '—', x.hm ? 'HM ' + fmtAmt(x.hm) : '']; }], ['AMOUNT', 0, 'r', it => [fmtAmt(it.amount), '']]];
    else { const base = D.cols.slice(2).map(c => [String(c.h).replace(/\(₹\)/, '').toUpperCase(), c.w, 'r', (it, i) => [String(c.v(it, i) == null ? '' : c.v(it, i)), '']]); cols = [['#', 60, 'c', (it, i) => String(i + 1)], ['', anyPhoto ? 230 : 0, 'photo'], ['ITEM DETAILS', 0, 'desc']].concat(base); }
    { const fixed = cols.filter(c => c[2] !== 'desc' && c[1]).reduce((a, c) => a + c[1], 0); if (retail) { cols[cols.length - 1][1] = CW - fixed - cols.find(c => c[2] === 'desc')[1]; } else { const rest = cols.slice(3); const scale = Math.min(1, (CW - 60 - (anyPhoto ? 230 : 0) - 520) / rest.reduce((a, c) => a + c[1] * 10, 0)); rest.forEach(c => { c[1] = c[1] * 10 * scale; }); cols[2][1] = CW - cols.filter(c => c[2] !== 'desc').reduce((a, c) => a + c[1], 0); } }
    cols = cols.filter(c => c[1] > 0);
    const colX = []; { let xx = M; cols.forEach(c => { colX.push(xx); xx += c[1]; }); }
    const RH = anyPhoto ? 200 : 140;

    /* blocks heights */
    const HDR = 600, CONT = 250, BOTTOM = 3508 - 120, PH = 300, ROWS_TOP1 = HDR + 23 + 50 + PH + 36 + 86, ROWS_TOP2 = CONT + 10 + 60 + 86;
    const sumRows = D.rows.filter(r => r[1] !== '' && r[1] != null);
    if (v.privilege && num(v.privilege.amount) > 0) sumRows.forEach(r => { if (/^Discount/.test(r[0])) r[0] = 'Privilege 20% making'; });
    const bankN = !D.buy && B.bank ? [B.bank.accNo, B.bank.bank, B.bank.branch, B.bank.ifsc].filter(Boolean).length : 0;
    const payH = 64 + bankN * 42 + (D.qr ? 248 : 0) + (D.modeText ? 44 : 0) + 30;
    const gridH = Math.max(480, payH, 30 + sumRows.reduce((a, r) => a + (r[2] === 'band' ? 92 : 52), 0) + 20);
    const hsn = (() => { if (!D.gstOn || !D.items.length) return []; const ratio = num(t.itemsTotal) ? num(t.taxable) / num(t.itemsTotal) : 1; const m = new Map(); D.items.forEach(it => { const code = String((typeof hsnInfo === 'function' && hsnInfo(it).code) || (typeof hsnOf === 'function' ? hsnOf(it) : '7113')); m.set(code, (m.get(code) || 0) + num(it.amount) * ratio); }); const tot = [...m.values()].reduce((a, b) => a + b, 0) || 1; return [...m].map(([code, tx]) => { const sh = tx / tot; return [code, tx, num(t.cgst) * sh, num(t.sgst) * sh, num(t.igst) * sh]; }); })();
    const hsnH = hsn.length ? 56 + (hsn.length + 1) * 44 + 16 : 0;
    const promoH = promo ? 330 : 0, footH = 300, rateH = (rate24 || rateAg) && !D.buy ? 100 : 0;
    const tailH = 30 + rateH + gridH + 26 + hsnH + (promoH ? promoH + 54 : 0) + footH + 10;

    /* paginate rows */
    const pages = []; let tailPage = 0; { let cur = [], y = ROWS_TOP1; D.items.forEach((it, i) => { if (y + RH + 110 > BOTTOM - 40 && cur.length) { pages.push(cur); cur = []; y = ROWS_TOP2; } cur.push(i); y += RH; }); pages.push(cur); y += 110;
      if (y + tailH > BOTTOM) { pages.push(null); } }   // null = a page with only the totals / payment / promotion
    const nP = pages.length, lastItems = pages.reduce((a, p, i) => (p ? i : a), 0);

    const pdf = new Pdf(210, 297); pdf.pages.length = 0;
    for (let pi = 0; pi < nP; pi++) {
      const K = o.lite || o.preview ? 1 : DPI_K(); const cv = document.createElement('canvas'); cv.width = Math.round(PX * K); cv.height = Math.round(PY * K); const x = cv.getContext('2d'); x.scale(K, K); x.imageSmoothingQuality = 'high'; x.textRendering = 'optimizeLegibility';
      x.fillStyle = C.ivory; x.fillRect(0, 0, PX, PY); frame(x, pi);
      let y;
      if (pi === 0) y = header(x); else y = contHeader(x, pi);
      if (pi === 0) { y = partyCards(x, y + 50) + 36; } else y += 60;
      if (pages[pi]) { y = tableHead(x, y); pages[pi].forEach((ri, n) => { y = itemRow(x, ri, y, n); }); }
      const last = pi === nP - 1;
      if (pi === lastItems) y = totalRow(x, y);
      if (last) y = tail(x, y + 30);
      else { T(x, pi === lastItems ? 'Payment, totals & your Lifetime Privilege — next page →' : 'Continued on next page …', PX - M, y + 70, { align: 'right', size: 28, w: 500, color: C.goldT }); }
      bottomStrip(x, pi);
      if (o.preview) { o.pages = o.pages || []; o.pages.push(shrink(cv, 0.5).toDataURL('image/jpeg', 0.85)); continue; }
      pdf.addPage(); pdf.image(o.lite ? jpeg(shrink(cv, 0.5), 0.8) : jpeg(cv, 0.97), 0, 0, 210, 297);
    }
    if (o.preview) return null;
    return pdf.blob();

    /* ===== sections ===== */
    function mandala(x, cx, cy, R) {
      x.save(); x.globalAlpha = 0.055; x.strokeStyle = '#a07a22'; x.fillStyle = '#a07a22'; x.lineWidth = 3;
      for (let ring = 0; ring < 5; ring++) { const r = R * (0.25 + ring * 0.18), n = 8 + ring * 8; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI * 2); x.stroke();
        for (let k = 0; k < n; k++) { const a = k / n * Math.PI * 2; x.save(); x.translate(cx + Math.cos(a) * r, cy + Math.sin(a) * r); x.rotate(a); x.beginPath(); x.ellipse(0, 0, R * 0.075, R * 0.025, 0, 0, Math.PI * 2); x.stroke(); if (ring % 2) { x.beginPath(); x.arc(R * 0.09, 0, 5, 0, Math.PI * 2); x.fill(); } x.restore(); } }
      x.beginPath(); x.arc(cx, cy, R * 0.12, 0, Math.PI * 2); x.stroke(); x.restore();
    }
    function grain(x) { const t = document.createElement('canvas'); t.width = 256; t.height = 256; const g = t.getContext('2d'); const im = g.createImageData(256, 256); for (let k = 0; k < im.data.length; k += 4) { const v = 120 + Math.random() * 120; im.data[k] = v; im.data[k + 1] = v * 0.94; im.data[k + 2] = v * 0.82; im.data[k + 3] = 10; } g.putImageData(im, 0, 0); x.save(); x.fillStyle = x.createPattern(t, 'repeat'); x.fillRect(0, 0, PX, PY); x.restore(); }
    function frame(x, pi) {
      grain(x); mandala(x, PX / 2, pi === 0 ? 1900 : 1500, 900);
      const top = (pi === 0 ? HDR : CONT) + 44, bot = PY - 92 - 22, l = 52, r = PX - 52;
      x.strokeStyle = '#d6b871'; x.lineWidth = 3; x.strokeRect(l, top, r - l, bot - top); x.strokeStyle = '#ead7a6'; x.lineWidth = 1.5; x.strokeRect(l + 12, top + 12, r - l - 24, bot - top - 24);
      [[l, top], [r, top], [l, bot], [r, bot]].forEach(([cx, cy]) => { x.save(); x.translate(cx, cy); x.rotate(Math.PI / 4); x.fillStyle = grad(x, -16, -16, 16, 16); x.fillRect(-15, -15, 30, 30); x.fillStyle = C.ivory; x.fillRect(-6, -6, 12, 12); x.restore(); });
    }
    function divider(x, yy) {
      x.fillStyle = grad(x, 0, 0, PX, 0); x.fillRect(0, yy, PX, 12); x.fillStyle = '#f6dc8c'; x.fillRect(0, yy + 18, PX, 3);
      const cx = PX / 2; x.save(); x.translate(cx, yy + 6); x.rotate(Math.PI / 4); x.fillStyle = '#0d0b07'; x.fillRect(-30, -30, 60, 60); x.fillStyle = grad(x, -24, -24, 24, 24); x.fillRect(-22, -22, 44, 44); x.fillStyle = '#0d0b07'; x.fillRect(-8, -8, 16, 16); x.restore();
      [-1, 1].forEach(sg => { x.beginPath(); x.arc(cx + sg * 70, yy + 6, 9, 0, Math.PI * 2); x.fillStyle = grad(x, cx - 80, 0, cx + 80, 0); x.fill(); });
    }
    function header(x) {
      const g = x.createLinearGradient(0, 0, PX, HDR); g.addColorStop(0, '#07060a'); g.addColorStop(0.55, '#15100a'); g.addColorStop(1, '#2a1d0c'); x.fillStyle = g; x.fillRect(0, 0, PX, HDR);
      // fine guilloche lines
      x.save(); x.globalAlpha = 0.07; x.strokeStyle = '#f2d68a'; x.lineWidth = 1.4; for (let k = -HDR; k < PX; k += 26) { x.beginPath(); x.moveTo(k, HDR); x.lineTo(k + HDR * 0.6, 0); x.stroke(); } x.restore();
      { const rg = x.createRadialGradient(M + 280, HDR / 2, 20, M + 280, HDR / 2, 420); rg.addColorStop(0, 'rgba(242,214,138,0.22)'); rg.addColorStop(1, 'rgba(242,214,138,0)'); x.fillStyle = rg; x.fillRect(0, 0, 900, HDR); }
      divider(x, HDR);
      let nx = M; if (logo) { const lw = 560, lh = lw * logo.height / logo.width, ly = (HDR - Math.min(lh, 360)) / 2; x.drawImage(logo, M, ly, lw, Math.min(lh, 360)); nx = M + lw + 70; x.fillStyle = grad(x, 0, 120, 0, HDR - 120); x.fillRect(nx - 36, 120, 3, HDR - 240); }
      const rw = 720, lim = PX - M - rw - nx - 30;
      fit(x, B.name, lim, 700, 78, SERIF, 50); x.textAlign = 'left'; x.save(); x.shadowColor = 'rgba(0,0,0,0.55)'; x.shadowBlur = 10; x.shadowOffsetY = 4; x.fillStyle = sheen(x, nx, 120, nx + lim * 0.7, 210); x.fillText(B.name, nx, 190); x.restore();
      let yy = 190; if (B.tagline) { yy += 62; T(x, B.tagline.toUpperCase(), nx, yy, { size: 27, w: 500, color: '#e3d3a6', maxW: lim, ls: 4 }); }
      const addr = B.address + (B.stateCode && !/CODE\s*:/i.test(B.address) ? ', Code ' + B.stateCode : ''); wrap(x, addr, lim, 400, 29).slice(0, 2).forEach(l => { yy += 46; T(x, l, nx, yy, { size: 29, color: '#d8ccb0', maxW: lim }); });
      const ct = [B.phone ? '☎ ' + B.phone : '', B.email || '', B.main ? 'www.' + String((window.SJ_PRO ? SJ_PRO.proCfg().website : '') || 'shivaa.in').replace(/^https?:\/\//, '') : ''].filter(Boolean).join('     '); if (ct) { yy += 48; T(x, ct, nx, yy, { size: 28, color: '#d8ccb0', maxW: lim }); }
      const gl = [D.gstOn && B.gstin ? 'GSTIN  ' + B.gstin : '', D.gstOn && B.cin ? 'CIN  ' + B.cin : ''].filter(Boolean).join('      '); if (gl) { yy += 54; T(x, gl, nx, yy, { size: 30, w: 700, color: '#f2d68a', maxW: lim }); }
      // title block
      const R = PX - M; let tl = [tMain];
      if (fit(x, tMain, rw, 700, 92, SERIF, 66) <= 66 && x.measureText(tMain).width > rw) { const ws = String(tMain).split(/\s+/); let best = 1, bd = 1e9; for (let k = 1; k < ws.length; k++) { const d = Math.abs(ws.slice(0, k).join(' ').length - ws.slice(k).join(' ').length); if (d < bd) { bd = d; best = k; } } tl = [ws.slice(0, best).join(' '), ws.slice(best).join(' ')]; }
      if (tl.length === 1) { x.textAlign = 'right'; x.save(); x.shadowColor = 'rgba(0,0,0,0.6)'; x.shadowBlur = 12; x.shadowOffsetY = 5; x.fillStyle = sheen(x, R - rw, 110, R, 215); x.fillText(tMain, R, 200); x.restore(); }
      else { const z = Math.min(fit(x, tl[0], rw, 700, 74, SERIF, 44), fit(x, tl[1], rw, 700, 74, SERIF, 44)); font(x, 700, z, SERIF); x.textAlign = 'right'; tl.forEach((l, k) => { x.save(); x.shadowColor = 'rgba(0,0,0,0.6)'; x.shadowBlur = 12; x.shadowOffsetY = 5; x.fillStyle = sheen(x, R - rw, 90 + k * 80, R, 170 + k * 80); x.fillText(l, R, 150 + k * 80); x.restore(); }); }
      if (tSub) T(x, tSub, R, tl.length > 1 ? 268 : 250, { align: 'right', size: tl.length > 1 ? 25 : 28, color: '#d8ccb0' });
      const chips = [D.qual, !D.buy && D.type !== 'metal' ? (D.chan === 'wholesale' ? 'WHOLESALE' : 'RETAIL') : ''].filter(Boolean); let cx = R;
      chips.slice().reverse().forEach(c => { font(x, 700, 26); const w = x.measureText(c).width + 56; rr(x, cx - w, 285, w, 56, 28); x.fillStyle = '#1f180c'; x.fill(); x.lineWidth = 3; x.strokeStyle = '#c9a046'; x.stroke(); T(x, c, cx - w / 2, 323, { align: 'center', size: 26, w: 700, color: '#f2d68a', ls: 2 }); cx -= w + 16; });
      T(x, D.noLbl.replace(/:\s*$/, '').toUpperCase(), R, 405, { align: 'right', size: 25, color: '#bfb08c', ls: 3 });
      T(x, String(v.no || ''), R, 470, { align: 'right', size: 58, w: 700, color: '#ffffff', maxW: rw });
      T(x, longDate(v.date), R, 528, { align: 'right', size: 30, color: '#e3d3a6' });
      return HDR + 21;
    }
    function contHeader(x, pi) {
      const g = x.createLinearGradient(0, 0, PX, 0); g.addColorStop(0, '#07060a'); g.addColorStop(1, '#2a1d0c'); x.fillStyle = g; x.fillRect(0, 0, PX, CONT); divider(x, CONT);
      x.fillStyle = grad(x, M, 0, M + 1200, 0); fit(x, B.name, 1300, 700, 62, SERIF); x.textAlign = 'left'; x.fillText(B.name, M, 150);
      T(x, `${tMain}  ·  ${v.no}  ·  continued (page ${pi + 1})`, PX - M, 150, { align: 'right', size: 32, color: '#e3d3a6' }); return CONT + 10;
    }
    function partyCards(x, top) {
      const lw = 1330, gap = 40, rx = M + lw + gap, rw2 = CW - lw - gap, h = PH;
      // buyer
      rr(x, M, top, lw, h, 26); x.fillStyle = C.cream; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      x.fillStyle = grad(x, 0, top, 0, top + h); x.fillRect(M, top + 30, 9, h - 60);
      T(x, String(D.partyLbl).toUpperCase(), M + 50, top + 62, { size: 25, w: 700, color: C.goldT, ls: 3 });
      T(x, v.partyName || '', M + 50, top + 128, { size: 52, w: 700, fam: SERIF, maxW: lw - 100 });
      const lines = []; D.pinfo.forEach(p => { (p.wrap ? wrap(x, p.t, lw - 100, 400, 30).slice(0, 2) : [p.t]).forEach(l => lines.push(l)); });
      let yy = top + 124; lines.slice(0, 4).forEach((l, i) => { yy += 40; T(x, l, M + 50 + (i >= 3 && lines.length > 4 ? 0 : 0), yy, { size: 29, color: '#3d362a', maxW: lw - 100 }); });
      // meta
      rr(x, rx, top, rw2, h, 26); x.fillStyle = '#ffffff'; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
      const meta = [[D.dtLbl.replace(/:\s*$/, ''), longDate(v.date)], ...D.pright.map(z => { const i = z.indexOf(': '); return i > 0 ? [z.slice(0, i), z.slice(i + 2)] : ['', z]; })]; if (num(v.creditDays) && !D.pright.some(z => /^Due/.test(z))) meta.push(['Credit', num(v.creditDays) + ' days']);
      let my = top + 66; meta.slice(0, 3).forEach(([k, val]) => { T(x, k, rx + 44, my, { size: 28, color: C.mut }); T(x, val, rx + rw2 - 44, my, { align: 'right', size: 30, w: 700, maxW: rw2 - 330 }); my += 52; });
      { const heroL = due > 0.5 ? (D.buy ? 'BALANCE TO PAY' : 'AMOUNT DUE') : D.type === 'metal' ? 'TOTAL CHARGES' : (D.buy ? 'PAID' : 'AMOUNT PAID'); const heroV = due > 0.5 ? due : (paid || payable);
        x.strokeStyle = '#efe5cd'; x.lineWidth = 2; x.beginPath(); x.moveTo(rx + 30, top + h - 112); x.lineTo(rx + rw2 - 30, top + h - 112); x.stroke();
        T(x, heroL, rx + 44, top + h - 74, { size: 22, w: 700, color: C.goldT, ls: 3 }); T(x, money(heroV), rx + 44, top + h - 24, { size: 50, w: 700, fam: SERIF, color: due > 0.5 ? C.red : C.ink, maxW: rw2 - 360 }); }
      if (!D.buy && D.type !== 'metal' || D.type === 'metal') { const st = due <= 0.5 ? ['PAID IN FULL', C.green] : paid > 0 ? ['PARTLY PAID', '#b7791f'] : ['PAYMENT DUE', C.red]; font(x, 700, 26); const w = x.measureText(st[0]).width + 60; rr(x, rx + rw2 - 44 - w, top + h - 82, w, 54, 27); x.fillStyle = st[1]; x.fill(); T(x, st[0], rx + rw2 - 44 - w / 2, top + h - 46, { align: 'center', size: 26, w: 700, color: '#fff', ls: 2 }); }
      return top + h;
    }
    function tableHead(x, y) {
      rr(x, M, y, CW, 86, 18); x.fillStyle = '#0d0b07'; x.fill(); x.fillStyle = grad(x, M, 0, M + CW, 0); x.fillRect(M + 18, y + 82, CW - 36, 4);
      cols.forEach((c, i) => { if (!c[0]) return; const al = c[2] === 'r' ? 'right' : c[2] === 'c' ? 'center' : 'left'; const tx = al === 'right' ? colX[i] + c[1] - 18 : al === 'center' ? colX[i] + c[1] / 2 : colX[i] + 18; T(x, c[0], tx, y + 54, { align: al, size: 23, w: 700, color: '#f2d68a', maxW: c[1] - 24, ls: 1.5, min: 15 }); });
      return y + 86;
    }
    function itemRow(x, ri, y, n) {
      const it = D.items[ri]; if (n % 2) { x.fillStyle = '#fbf7ee'; x.fillRect(M, y, CW, RH); }
      cols.forEach((c, i) => {
        const X0 = colX[i], w = c[1];
        if (c[2] === 'photo') { const ph = photos[ri]; const sz = RH - 36, px = X0 + (w - sz) / 2, py = y + 18; x.save(); x.shadowColor = 'rgba(80,55,10,0.28)'; x.shadowBlur = 18; x.shadowOffsetY = 6; rr(x, px, py, sz, sz, 22); x.fillStyle = '#fff'; x.fill(); x.restore(); x.save(); rr(x, px, py, sz, sz, 22); x.clip(); if (ph) { const k = Math.max(sz / ph.naturalWidth, sz / ph.naturalHeight); const dw = ph.naturalWidth * k, dh = ph.naturalHeight * k; x.drawImage(ph, px + (sz - dw) / 2, py + (sz - dh) / 2, dw, dh); } else { x.fillStyle = '#f3ead2'; x.fillRect(px, py, sz, sz); T(x, (String(it.category || 'S')[0] || 'S').toUpperCase(), px + sz / 2, py + sz / 2 + 36, { align: 'center', size: 100, w: 700, fam: SERIF, color: '#d9c38c' }); } x.restore(); rr(x, px, py, sz, sz, 22); x.lineWidth = 4; x.strokeStyle = '#d4b062'; x.stroke(); return; }
        if (c[2] === 'desc') { const tx = X0 + 22; T(x, [it.category, it.purity].filter(Boolean).join('  ·  '), tx, y + (RH > 160 ? 64 : 56), { size: 38, w: 700, fam: SERIF, maxW: w - 40 });
          let ly = y + (RH > 160 ? 64 : 56); const tags = []; if (it.sku) tags.push(['SKU ' + it.sku, '#efe4c6', '#5a4512']); if (it.huid) tags.push(['HUID ' + String(it.huid).toUpperCase(), '#0d0b07', '#f2d68a']); if (hallmark(it) && tags.length < 3) tags.push([hallmark(it), 'gold', '#1b1206']);
          if (tags.length) { ly += 26; let tx2 = tx; tags.forEach(([lb, bg, fg]) => { font(x, 700, 22); const tw = x.measureText(lb).width + 34; if (tx2 + tw > X0 + w - 10) return; rr(x, tx2, ly, tw, 44, 22); x.fillStyle = bg === 'gold' ? grad(x, tx2, ly, tx2 + tw, ly + 44) : bg; x.fill(); T(x, lb, tx2 + tw / 2, ly + 31, { align: 'center', size: 22, w: 700, color: fg, ls: 1 }); tx2 += tw + 12; }); ly += 44; }
          const sub = [it.making, it.desc || it.description, num(it.less) ? 'Less ' + g3x(it.less) : '', num(it.pcs) > 1 ? num(it.pcs) + ' pcs' : ''].filter(Boolean).join('  ·  '); if (sub) T(x, sub, tx, ly + 46, { size: 25, color: C.mut, maxW: w - 40 }); return; }
        const vals = c[3](it, ri) || []; const a = Array.isArray(vals) ? vals : [vals, '']; const al = c[2] === 'c' ? 'center' : 'right'; const tx = al === 'center' ? X0 + w / 2 : X0 + w - 18; const last = i === cols.length - 1;
        T(x, a[0], tx, y + RH / 2 + (a[1] ? -4 : 12), { align: al, size: last ? 34 : 29, w: last ? 700 : 500, maxW: w - 26, min: 18 }); if (a[1]) T(x, a[1], tx, y + RH / 2 + 38, { align: al, size: 23, color: C.mut, maxW: w - 26 });
      });
      x.strokeStyle = '#eadfc4'; x.lineWidth = 2; x.beginPath(); x.moveTo(M, y + RH); x.lineTo(M + CW, y + RH); x.stroke();
      return y + RH;
    }
    function totalRow(x, y) {
      rr(x, M, y + 10, CW, 86, 18); x.fillStyle = '#f3e7c6'; x.fill(); const yy = y + 66;
      T(x, `TOTAL  ·  ${D.tot.pcs} pc${D.tot.pcs > 1 ? 's' : ''}`, colX[cols.findIndex(c => c[2] === 'desc')] + 22, yy, { size: 30, w: 700 });
      cols.forEach((c, i) => { const h = c[0]; let val = ''; if (/GROSS/.test(h)) { val = g3x(D.tot.gross); if (/NET/.test(h) && Math.abs(num(D.tot.gross) - num(D.tot.net)) > 0.0005) { T(x, 'Net ' + g3x(D.tot.net), colX[i] + c[1] - 18, yy + 30, { align: 'right', size: 21, color: C.mut }); } } else if (/^NET/.test(h)) val = g3x(D.tot.net); else if (/FINE/.test(h)) val = g3x(D.tot.fine); else if (/METAL VALUE/.test(h)) val = fmtAmt(sum(D.items, it => sale(it).pure)); else if (/^MAKING/.test(h)) val = fmtAmt(sum(D.items, it => sale(it).making)); if (val) T(x, val, colX[i] + c[1] - 18, yy, { align: 'right', size: 28, w: 700, maxW: c[1] - 24 }); });
      T(x, fmtAmt(t.itemsTotal), M + CW - 18, yy, { align: 'right', size: 36, w: 700 });
      return y + 96;
    }
    function tail(x, y) {
      // rate strip
      if (rateH) { rr(x, M, y, CW, 80, 20); x.fillStyle = '#fffaf0'; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke(); x.fillStyle = grad(x, 0, y, 0, y + 80); x.fillRect(M, y + 14, 9, 52);
        T(x, v.date === todayStr() ? 'AAJ KA BHAV' : 'BILL KE DIN KA BHAV', M + 44, y + 52, { size: 25, w: 700, color: C.goldT, ls: 3 });
        const parts = [rate24 ? ['Gold 24K', money(rate24) + ' /10g'] : null, rate24 ? ['22K', money(Math.round(rate24 * 0.916)) + ' /10g'] : null, rate24 ? ['18K', money(Math.round(rate24 * 0.75)) + ' /10g'] : null, rateAg ? ['Silver 999', money(rateAg) + ' /kg'] : null].filter(Boolean);
        let px2 = M + 420; const slot = (CW - 460) / Math.max(1, parts.length); parts.forEach(([k, val], pi2) => { px2 = M + 420 + pi2 * slot; T(x, k, px2, y + 52, { size: 25, color: C.mut }); font(x, 400, 25); const kw = x.measureText(k).width; T(x, val, px2 + kw + 16, y + 52, { size: 29, w: 700 }); });
        y += rateH; }
      // three cards
      const y0 = y, w1 = 720, w2 = 770, gap = 30, w3 = CW - w1 - w2 - 2 * gap, x1 = M, x2 = M + w1 + gap, x3 = x2 + w2 + gap;
      [[x1, w1], [x2, w2]].forEach(([xx, ww]) => { rr(x, xx, y0, ww, gridH, 24); x.fillStyle = '#ffffff'; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke(); });
      // payment
      let ly = y0 + 64; T(x, D.buy ? 'PAYMENT' : 'PAYMENT DETAILS', x1 + 40, ly, { size: 24, w: 700, color: C.goldT, ls: 3 });
      const bank = !D.buy && B.bank ? [['A/c No.', B.bank.accNo], ['Bank', B.bank.bank], ['Branch', B.bank.branch], ['IFSC', B.bank.ifsc]].filter(z => z[1]) : [];
      bank.forEach(([k, val]) => { ly += 42; T(x, k, x1 + 40, ly, { size: 26, color: C.mut }); T(x, String(val), x1 + 200, ly, { size: 28, w: 700, maxW: w1 - 240 }); });
      if (D.qr) { ly += 26; const qs = 200; rr(x, x1 + 34, ly - 6, qs + 12, qs + 12, 14); x.fillStyle = '#fff'; x.fill(); x.lineWidth = 2; x.strokeStyle = C.line; x.stroke(); qrDraw(x, D.qr, x1 + 40, ly, qs); T(x, 'Scan & Pay', x1 + 270, ly + 52, { size: 32, w: 700 }); T(x, due > 0.5 ? 'UPI · ' + money(due) : 'UPI', x1 + 270, ly + 94, { size: 26, color: C.mut, maxW: w1 - 300 }); T(x, B.upi, x1 + 270, ly + 134, { size: 23, color: C.mut, maxW: w1 - 300, min: 15 }); T(x, 'GPay · PhonePe · Paytm · BHIM', x1 + 270, ly + 172, { size: 22, color: C.mut, maxW: w1 - 300 }); ly += qs + 22; }
      if (D.modeText) wrap(x, 'Received: ' + D.modeText, w1 - 80, 500, 25).slice(0, 2).forEach(l => { ly += 40; T(x, l, x1 + 40, ly, { size: 25, w: 500, color: '#3d362a' }); });
      // words + old gold + notes
      let my = y0 + 64; D.words.forEach(([k, w]) => { T(x, String(k).replace(/:$/, '').toUpperCase(), x2 + 40, my, { size: 23, w: 700, color: C.goldT, ls: 2, maxW: w2 - 80 }); wrap(x, w, w2 - 80, 400, 28).forEach(l => { my += 42; T(x, l, x2 + 40, my, { size: 28 }); }); my += 46; });
      if (D.old.length) { T(x, (D.metal ? 'METAL RECEIVED' : 'OLD GOLD / SILVER EXCHANGED'), x2 + 40, my, { size: 23, w: 700, color: C.goldT, ls: 2 }); D.old.slice(0, 3).forEach(o => wrap(x, o, w2 - 80, 400, 25).forEach(l => { my += 38; T(x, l, x2 + 40, my, { size: 25, color: '#3d362a' }); })); my += 44; }
      if (v.notes) { T(x, 'NOTE', x2 + 40, my, { size: 23, w: 700, color: C.goldT, ls: 2 }); wrap(x, v.notes, w2 - 80, 400, 25).slice(0, 3).forEach(l => { my += 38; T(x, l, x2 + 40, my, { size: 25, color: '#3d362a' }); }); }
      if (D.irn) wrap(x, 'IRN: ' + D.irn.irn, w2 - 80, 400, 20).forEach(l => { my += 30; T(x, l, x2 + 40, my, { size: 20, color: C.mut }); });
      // totals
      let ry = y0; sumRows.forEach(r => { if (r[2] === 'band') { rr(x, x3, ry + 6, w3, 80, 18); x.fillStyle = grad(x, x3, 0, x3 + w3, 0, ['#0d0b07', '#2a1d0c']); x.fill(); x.lineWidth = 3; x.strokeStyle = '#c9a046'; x.stroke(); x.fillStyle = grad(x, x3, 0, x3 + w3, 0); font(x, 700, 36, SERIF); x.textAlign = 'left'; x.fillText(r[0], x3 + 34, ry + 60); x.textAlign = 'right'; fit(x, (/Fine|g$/.test(r[1]) ? '' : '₹ ') + r[1], w3 - 300, 700, 42); x.fillText((/Fine|g$/.test(r[1]) ? '' : '₹ ') + r[1], x3 + w3 - 34, ry + 62); ry += 92; }
        else { const bal = /^Balance/.test(r[0]), bold = r[2] === 'bold' || bal; T(x, r[0], x3 + 34, ry + 38, { size: 27, w: bold ? 700 : 400, color: bold ? C.ink : C.mut }); T(x, r[1], x3 + w3 - 34, ry + 38, { align: 'right', size: bold ? 31 : 28, w: bold ? 700 : 500, color: bal && due > 0.5 ? C.red : C.ink }); ry += 52; x.strokeStyle = '#efe5cd'; x.lineWidth = 2; x.beginPath(); x.moveTo(x3 + 24, ry); x.lineTo(x3 + w3 - 24, ry); x.stroke(); } });
      y = y0 + gridH + 26;
      // HSN
      if (hsn.length) { const hc = [['HSN / SAC', 330, 'l'], ['Taxable value', 420, 'r'], [t.intra !== false ? 'CGST 1.5%' : 'CGST', 360, 'r'], [t.intra !== false ? 'SGST 1.5%' : 'SGST', 360, 'r'], [t.intra === false ? 'IGST 3%' : 'IGST', 360, 'r'], ['Total tax', CW - 1830, 'r']]; const hx = []; { let xx = M; hc.forEach(c => { hx.push(xx); xx += c[1]; }); }
        T(x, 'HSN-WISE TAX SUMMARY', M, y + 34, { size: 23, w: 700, color: C.goldT, ls: 3 }); y += 50; rr(x, M, y, CW, 44, 12); x.fillStyle = '#f3e7c6'; x.fill(); hc.forEach((c, i) => T(x, c[0], c[2] === 'l' ? hx[i] + 22 : hx[i] + c[1] - 22, y + 31, { align: c[2] === 'l' ? 'left' : 'right', size: 23, w: 700 })); y += 44;
        hsn.forEach(r => { [r[0], fmtAmt(r[1]), fmtAmt(r[2]), fmtAmt(r[3]), fmtAmt(r[4]), fmtAmt(r[2] + r[3] + r[4])].forEach((val, i) => T(x, val, hc[i][2] === 'l' ? hx[i] + 22 : hx[i] + hc[i][1] - 22, y + 32, { align: hc[i][2] === 'l' ? 'left' : 'right', size: 25 })); y += 44; }); y += 16; }
      // promotion coupon
      if (promo) { y += 10; promoCard(x, y); y += promoH + 44; }
      if (promo && BOTTOM - footH - y > 320) { services(x, y); y += 300; }
      footer(x);
      return y;
    }
    function seal(x, cx, cy, code, k) {
      x.save(); x.translate(cx, cy); x.scale(k || 1, k || 1); x.translate(-cx, -cy); x.globalAlpha = 0.93;
      x.beginPath(); x.arc(cx, cy, 92, 0, Math.PI * 2); x.fillStyle = grad(x, cx - 92, cy - 92, cx + 92, cy + 92); x.fill();
      for (let k = 0; k < 36; k++) { const a = k / 36 * Math.PI * 2; x.beginPath(); x.arc(cx + Math.cos(a) * 92, cy + Math.sin(a) * 92, 7, 0, Math.PI * 2); x.fill(); }
      x.beginPath(); x.arc(cx, cy, 74, 0, Math.PI * 2); x.strokeStyle = '#fff3c9'; x.lineWidth = 3; x.stroke(); x.beginPath(); x.arc(cx, cy, 66, 0, Math.PI * 2); x.strokeStyle = '#7a5410'; x.lineWidth = 1.5; x.stroke();
      T(x, 'BIS HALLMARKED', cx, cy - 26, { align: 'center', size: 15, w: 700, color: '#3a2606', ls: 1 }); T(x, code, cx, cy + 22, { align: 'center', size: 46, w: 700, fam: SERIF, color: '#2a1a04' }); T(x, 'GENUINE', cx, cy + 50, { align: 'center', size: 15, w: 700, color: '#3a2606', ls: 2 });
      x.restore();
    }
    function promoCard(x, y) {
      const h = promoH, X = M, Wd = CW;
      rr(x, X, y, Wd, h, 34); const g = x.createLinearGradient(X, y, X + Wd, y + h); g.addColorStop(0, '#120d06'); g.addColorStop(0.5, '#2b1c09'); g.addColorStop(1, '#120d06'); x.fillStyle = g; x.fill();
      x.save(); rr(x, X, y, Wd, h, 34); x.clip(); x.globalAlpha = 0.09; x.strokeStyle = '#f2d68a'; x.lineWidth = 1.4; for (let k = -h; k < Wd; k += 22) { x.beginPath(); x.moveTo(X + k, y + h); x.lineTo(X + k + h * 0.7, y); x.stroke(); } x.restore();
      x.save(); x.setLineDash([18, 12]); x.lineWidth = 3.5; x.strokeStyle = '#d9b45a'; rr(x, X + 20, y + 20, Wd - 40, h - 40, 24); x.stroke(); x.restore();
      x.fillStyle = C.ivory; [[X, y + h / 2], [X + Wd, y + h / 2]].forEach(([cx, cy]) => { x.beginPath(); x.arc(cx, cy, 30, 0, Math.PI * 2); x.fill(); });
      const bx = X + 110; font(x, 700, 190, SERIF); x.textAlign = 'left'; x.save(); x.shadowColor = 'rgba(0,0,0,0.7)'; x.shadowBlur = 18; x.shadowOffsetY = 6; x.fillStyle = sheen(x, bx, y + 50, bx + 420, y + 230); x.fillText('20%', bx, y + 200); x.restore(); x.lineWidth = 1.5; x.strokeStyle = 'rgba(255,240,190,0.35)'; x.strokeText('20%', bx, y + 200);
      T(x, 'OFF  ·  MAKING CHARGES', bx + 6, y + 262, { size: 25, w: 700, color: '#f2d68a', ls: 4 });
      x.fillStyle = grad(x, 0, y + 60, 0, y + h - 60); x.fillRect(bx + 500, y + 60, 3, h - 120);
      const tx = bx + 556, qs = 200, tw = Wd - (tx - X) - qs - 150, mkTot = r2(sum(D.items, it => sale(it).making)), twH = tw - (mkTot > 0 ? 470 : 0);
      T(x, (v.partyName ? 'DEAR ' + String(v.partyName).toUpperCase() + ' JI  ·  ' : '') + 'YOUR SHIVAA LIFETIME PRIVILEGE', tx, y + 88, { size: 22, w: 700, color: '#d9b45a', ls: 3, maxW: tw - 60 });
      wrap(x, 'Get LIFETIME 20% OFF on making charges on any jewellery you purchase', twH, 700, 40, SERIF).slice(0, 2).forEach((l, i) => { x.fillStyle = '#fff4d6'; font(x, 700, 40, SERIF); x.textAlign = 'left'; x.fillText(l, tx, y + 144 + i * 48); });
      T(x, 'हर गहने की बनवाई (making) पर आजीवन 20% की छूट — हर बार, हमेशा।', tx, y + 246, { size: 27, fam: HIN, color: '#e9d7a5', maxW: tw });
      if (mkTot > 0) { const sv = Math.round(mkTot * 0.2), pw2 = 430, px3 = X + Wd - 110 - qs - 40 - pw2; rr(x, px3, y + 124, pw2, 80, 40); x.fillStyle = 'rgba(242,214,138,0.14)'; x.fill(); x.lineWidth = 2; x.strokeStyle = '#d9b45a'; x.stroke(); T(x, 'AGLI KHARID PAR AAPKI BACHAT', px3 + pw2 / 2, y + 156, { align: 'center', size: 17, w: 700, color: '#cdbb8f', ls: 1, maxW: pw2 - 40 }); T(x, money(sv) + '*', px3 + pw2 / 2, y + 191, { align: 'center', size: 30, w: 700, color: '#f6dc8c' }); }
      const pid = privilegeId(v), lab = `PRIVILEGE ID  ${pid}`; T(x, lab, tx, y + 286, { size: 25, w: 700, color: '#f2d68a', ls: 2, maxW: tw });
      font(x, 700, 25); const pw = x.measureText(lab).width + lab.length * 2 + 14; T(x, '·  ' + (v.partyName || ''), tx + pw, y + 286, { size: 24, color: '#cdbb8f', maxW: Math.max(80, tw - pw) });
      const qx = X + Wd - 110 - qs, qy = y + 44; const shop = String(B.phone || '').replace(/\D/g, '').slice(-10);
      const q = shop.length === 10 ? `https://wa.me/91${shop}?text=${encodeURIComponent('Namaste! Mera Shivaa Lifetime Privilege ID ' + pid + ' hai — 20% making chhoot activate kijiye.')}` : `Shivaa Privilege ${pid}`;
      rr(x, qx - 10, qy - 10, qs + 20, qs + 20, 16); x.fillStyle = '#fff'; x.fill(); qrDraw(x, q, qx, qy, qs, '#1a1206');
      T(x, 'Scan · save on WhatsApp', qx + qs / 2, qy + qs + 42, { align: 'center', size: 20, color: '#cdbb8f', maxW: qs + 60 });
      T(x, '*Offer sirf making charges par · bachat is bill ki making ka 20% (andaaza) · billing par yeh bill ya Privilege ID dikhayein · kisi doosre offer ke saath nahi', X + Wd - 10, y + h + 26, { align: 'right', size: 19, color: C.mut, maxW: Wd - 40 });
    }
    function services(x, y) {
      const items = [['Swarn Bachat Yojana', '11 kisht bhariye, 12vi hum dete hain*'], ['Purana sona exchange', 'Tunch ke hisaab se sabse achha daam'], ['Repair & polish', 'Har gehne ki dekhbhaal'], ['Rate booking', 'Aaj ka bhav lock kijiye, baad mein lijiye']];
      T(x, 'SHIVAA SERVICES', M, y + 30, { size: 23, w: 700, color: C.goldT, ls: 4 }); const w = (CW - 3 * 30) / 4;
      items.forEach(([h, d], i) => { const X = M + i * (w + 30), Y = y + 56; rr(x, X, Y, w, 190, 22); x.fillStyle = '#ffffff'; x.fill(); x.lineWidth = 2.5; x.strokeStyle = C.line; x.stroke();
        x.beginPath(); x.arc(X + 70, Y + 95, 40, 0, Math.PI * 2); x.fillStyle = grad(x, X + 30, Y + 55, X + 110, Y + 135); x.fill(); T(x, String(i + 1), X + 70, Y + 110, { align: 'center', size: 40, w: 700, fam: SERIF, color: '#1b1206' });
        T(x, h, X + 130, Y + 82, { size: 30, w: 700, maxW: w - 150 }); wrap(x, d, w - 150, 400, 24).slice(0, 2).forEach((l, k) => T(x, l, X + 130, Y + 122 + k * 34, { size: 24, color: C.mut })); });
      T(x, '*Scheme ke niyam ke hisaab se', M + CW, y + 280, { align: 'right', size: 19, color: C.mut });
    }
    function footer(x) {
      const yF = BOTTOM - footH + 6; x.fillStyle = grad(x, M, 0, M + CW, 0); x.fillRect(M, yF, CW, 3);
      const lw0 = 1250, lw = vurl ? 1040 : lw0; let fy = yF + 50;
      const decl = String(B.declaration || ''), terms = String(B.terms || '').split('\n').filter(z => z.trim());
      if (decl) { T(x, 'DECLARATION', M, fy, { size: 21, w: 700, color: C.goldT, ls: 3 }); wrap(x, decl, lw, 400, 22).slice(0, 2).forEach(l => { fy += 31; T(x, l, M, fy, { size: 22, color: '#4a4234' }); }); fy += 42; }
      if (terms.length) { T(x, 'TERMS & CONDITIONS', M, fy, { size: 21, w: 700, color: C.goldT, ls: 3 }); terms.slice(0, 3).forEach(l => { fy += 31; T(x, l.trim(), M, fy, { size: 22, color: '#4a4234', maxW: lw }); }); }
      T(x, 'गहने की खरीद पर पक्का बिल लें · हॉलमार्क HUID की जाँच BIS CARE ऐप से करें', M, BOTTOM - 14, { size: 22, fam: HIN, color: C.goldT, maxW: lw });
      if (vurl) { const qs = 150, qx = M + lw0 - qs - 10, qy = yF + 34; rr(x, qx - 8, qy - 8, qs + 16, qs + 16, 12); x.fillStyle = '#ffffff'; x.fill(); x.lineWidth = 2; x.strokeStyle = C.line; x.stroke(); qrDraw(x, vurl, qx, qy, qs, '#1a1206');
        T(x, 'BILL ASLI HAI?', qx + qs / 2, qy + qs + 34, { align: 'center', size: 17, w: 700, color: C.goldT, ls: 1 }); T(x, 'Scan karke check karein', qx + qs / 2, qy + qs + 60, { align: 'center', size: 16, color: C.mut, maxW: qs + 50 }); }
      const bxp = M + lw0 + 70; if (bis) { const bw = 130, bh = bw * bis.naturalHeight / bis.naturalWidth; x.drawImage(bis, bxp, yF + 34, bw, bh); T(x, 'BIS HALLMARKED', bxp + bw / 2, yF + 60 + bh, { align: 'center', size: 19, w: 700, color: C.goldT, ls: 2 }); T(x, 'Verify HUID: BIS CARE app', bxp + bw / 2, yF + 90 + bh, { align: 'center', size: 18, color: C.mut }); }
      const R = PX - M; T(x, 'for ' + B.name, R, yF + 56, { align: 'right', size: 26, w: 700, color: C.goldT, maxW: 640 });
      x.strokeStyle = '#8f8778'; x.lineWidth = 2; x.beginPath(); x.moveTo(R - 420, BOTTOM - 62); x.lineTo(R, BOTTOM - 62); x.moveTo(bxp + 240, BOTTOM - 62); x.lineTo(bxp + 540, BOTTOM - 62); x.stroke();
      if (!D.buy) seal(x, R - 210, BOTTOM - 150, D.items.map(hallmark).find(Boolean) || '916', 0.78);
      T(x, 'Authorised Signatory', R - 210, BOTTOM - 26, { align: 'center', size: 22, color: C.mut }); T(x, D.signL, bxp + 390, BOTTOM - 26, { align: 'center', size: 22, color: C.mut });
    }
    function bottomStrip(x, pi) {
      const y = PY - 92; x.fillStyle = '#0d0b07'; x.fillRect(0, y, PX, 92); x.fillStyle = grad(x, 0, 0, PX, 0); x.fillRect(0, y, PX, 5);
      T(x, 'Thank you for choosing ' + (s.firm || 'Shivaa Jewels') + '   ·   धन्यवाद, फिर पधारें', PX / 2, y + 60, { align: 'center', size: 27, w: 500, fam: HIN, color: '#f2d68a' });
      T(x, 'Computer-generated invoice', M, y + 60, { size: 21, color: '#a89a78' }); T(x, `Page ${pi + 1} of ${nP}`, PX - M, y + 60, { align: 'right', size: 21, color: '#a89a78' });
    }
  }

  /* default style = Signature; "royal" / "ivory" / "classic" still available from Bill settings */
  /* Signature is the default from v24. A style the owner picks after v24 (Royal / Ivory / Classic) is respected. */
  const styleNow = () => { const pro = (S.settings && S.settings.pro) || {}; return pro.bsV25 ? (pro.billStyle || 'signature') : 'signature'; };
  { const prev = invoicePdf; invoicePdf = async function (v) { if (styleNow() !== 'signature') return prev.call(this, v); try { return await signatureInvoicePdf(v); } catch (e) { console.error(e); toast('Signature bill nahi bana (' + String(e && e.message || e).slice(0, 80) + ') — purana design bhej rahe hain. Ye message ka photo bhejiye.', 'err'); return prev.call(this, v); } }; }
  document.addEventListener('change', e => { if (e.target && e.target.matches && e.target.matches('[data-pro="billStyle"]')) setTimeout(() => { try { saveSettings({ ...S.settings, pro: { ...((S.settings && S.settings.pro) || {}), billStyle: e.target.value, bsV25: true } }); } catch (er) { console.error(er); } }, 900); }, true);
  /* the bill window inside the app shows the same Signature design (not the old HTML layout) */
  if (typeof openInvoiceView === 'function') {
    const OV = openInvoiceView;
    openInvoiceView = function (id) {
      const r = OV.apply(this, arguments);
      try {
        const v = S.invoices.find(z => z.id === id); const el = document.querySelector('#modal-root').lastElementChild; const doc = el && el.querySelector('.inv-doc');
        if (v && doc && v.type !== 'oldgold' && styleNow() === 'signature') {
          doc.classList.add('sjx-sigprev'); const old = doc.innerHTML; doc.innerHTML = '<div class="sjx-sigwait">Signature bill ban raha hai…</div>';
          const o = { preview: true, noVerify: false };
          signatureInvoicePdf(v, o).then(() => { if (!doc.isConnected) return; doc.innerHTML = (o.pages || []).map((u, i) => `<img src="${u}" alt="Bill page ${i + 1}">`).join('') + '<div class="sjx-sigtag">✦ Signature design · PDF print quality: ' + (DPI_K() > 1 ? '360' : '300') + ' DPI</div>'; })
            .catch(e => { console.error(e); if (doc.isConnected) doc.innerHTML = old; });
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }
  { const st = document.createElement('style'); st.textContent = '.inv-doc.sjx-sigprev{background:transparent!important;padding:0!important;border:0!important;box-shadow:none!important}.sjx-sigprev img{display:block;width:100%;max-width:820px;margin:0 auto 12px;border-radius:6px;box-shadow:0 6px 24px rgba(0,0,0,.35)}.sjx-sigwait{padding:60px 10px;text-align:center;opacity:.7}.sjx-sigtag{text-align:center;font-size:12px;opacity:.75;margin-bottom:6px}'; document.head.appendChild(st); }
  /* Setup → Bill design select always shows the design really in use */
  setInterval(() => { const s2 = document.querySelector('[data-pro="billStyle"]'); if (s2 && !s2.dataset.sjxSync && document.activeElement !== s2) { s2.dataset.sjxSync = '1'; s2.value = styleNow(); } }, 1000);
  window.SJ_BILLX = { signatureInvoicePdf, loadFonts, styleNow, verifyUrl, kit: { PX, PY, M, CW, SERIF, SANS, HIN, C, GOLD, font, grad, rr, fit, T, wrap, jpeg, qrDraw, sheen, goldLogo, loadImg, shrink, DPI_K } };
  setTimeout(loadFonts, 4000);   // warm the fonts so the first bill is quick
})();
