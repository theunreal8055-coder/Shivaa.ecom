/* =====================================================================
   Shivaa Jewels — v25 pack
   1. Privilege coupon          — 20% making chhoot apne-aap (retail privilege customers) + report
   2. Bill verify + WhatsApp    — light PDF for WhatsApp (verify QR is drawn in sj-billx.js)
   3. Camera scan               — phone camera reads tag QR / barcode (bill, scanner, stock audit)
   4. Aaj ka bhav               — morning reminder + AI web lookup (owner confirms)
   5. E-way bill JSON           — Part-A JSON for the e-way bill portal bulk upload
   6. Auto backup + 2-step      — server backups list / download / weekly email; owner Authenticator login
   7. Girvi register            — gold loan against jewellery: interest, payments, release, receipt PDF
   8. Portal catalogue          — customers see in-stock designs and tap "Mujhe ye chahiye"
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { name: 'Owner', role: 'owner' };
  const role = () => me().role || 'owner';
  const isOwner = () => !SITE || role() === 'owner';
  const canAdmin = () => !SITE || ['owner', 'manager'].includes(role());
  const canEdit = () => role() !== 'viewer';
  const q$ = (s, r) => (r || document).querySelector(s);
  const F = (label, inner, cls) => `<label class="f${cls ? ' ' + cls : ''}"><span>${label}</span>${inner}</label>`;
  const inp = (name, v, o = {}) => `<input name="${name}"${o.type ? ` type="${o.type}"` : ''}${o.step ? ` step="${o.step}"` : ''}${o.min != null ? ` min="${o.min}"` : ''}${o.ph ? ` placeholder="${esc(o.ph)}"` : ''}${o.im ? ` inputmode="${o.im}"` : ''}${o.req ? ' required' : ''} value="${esc(v == null ? '' : v)}">`;
  const sel = (name, list, v) => `<select name="${name}">${opts(list, v)}</select>`;
  const tabs = (k, arr) => `<div class="rep-tabs">${arr.map(([v, l]) => `<button type="button" data-act="seg" data-k="${k}" data-v="${v}" class="${(ui[k] || arr[0][0]) === v ? 'on' : ''}">${l}</button>`).join('')}</div>`;
  const kpis = arr => `<div class="kpis">${arr.map(([l, v, s]) => kpi(esc(l), v, s || '')).join('')}</div>`;
  const formVals = f => { const o = {}; [...f.elements].forEach(e => { if (e.name) o[e.name] = e.type === 'checkbox' ? e.checked : e.value; }); return o; };
  const phoneLink = (ph, msg) => { const d = String(ph || '').replace(/\D/g, '').slice(-10); return d.length === 10 ? `https://wa.me/91${d}${msg ? '?text=' + encodeURIComponent(msg) : ''}` : ''; };
  const nextNo = (col, pre) => { let mx = 0; (S[col] || []).forEach(x => { if (x.no && x.no.startsWith(pre)) mx = Math.max(mx, parseInt(x.no.slice(pre.length)) || 0); }); return pre + String(mx + 1).padStart(4, '0'); };
  const css = document.createElement('style'); document.head.appendChild(css); const addCss = t => { css.textContent += t; };
  ['girvi', 'portalReqs'].forEach(c => { if (typeof COLS !== 'undefined' && !COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const ACT = {};   // data-act → handler(t, e)
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act]'); if (!t) return; const h = ACT[t.dataset.act]; if (!h) return;
    e.preventDefault(); e.stopPropagation(); if (t.disabled) return;
    try { await h(t, e); } catch (err) { console.error(err); toast(err && err.message ? err.message : 'Kuch galat hua — dobara try kijiye', 'err'); }
  }, true);

  /* =====================================================================
     1. PRIVILEGE — 20% off making for retail customers who already have a Shivaa bill
     ===================================================================== */
  const PRIV_PCT = 20;
  function privilegeId(c, v) { const ph = String((c && c.phone) || (v && v.partyPhone) || '').replace(/\D/g, '').slice(-4) || '0000'; let h = 0; String((c && c.id) || (v && (v.partyId || v.partyName)) || '').split('').forEach(ch => { h = (h * 31 + ch.charCodeAt(0)) >>> 0; }); return 'SJP-' + ph + '-' + h.toString(36).toUpperCase().slice(-4).padStart(4, '0'); }
  const isRetailBill = v => (v.type === 'sale' || v.type === 'estimate') && chanOf(v) === 'retail';
  function privOf(c, exceptId) { if (!c) return null; const L = S.invoices.filter(v => v.partyId === c.id && v.id !== exceptId && !v.deleted && isRetailBill(v)).sort((a, b) => String(a.date).localeCompare(String(b.date))); return L.length ? { id: privilegeId(c), since: L[0].date, first: L[0].no, bills: L.length } : null; }
  function makingOf(items, type) { return r2(sum(items || [], it => { if (!num(it.gross) && !num(it.net)) return 0; const c = calcItem(it, type); const tn = num(it.tunch) > 0 ? num(it.tunch) : 100; const pure = r2(c.net * tn / 100 * num(it.rate)); return Math.max(0, c.amount - pure - num(it.stone) - num(it.hm)); })); }
  const privAuto = () => ((settings().pro || {}).privAuto !== false);
  function invIsRetail() { if (!INV) return false; if (INV.type !== 'sale' && INV.type !== 'estimate') return false; const p = invParty(); return INV.channel ? INV.channel === 'retail' : (p ? chanOfParty(p) === 'retail' : false); }
  function privBanner() {
    if (!INV || !INV.el) return; const box = q$('#inv-party', INV.el); if (!box) return; let b = q$('#sjx-priv', INV.el);
    const p = invParty(); const pr = p && invIsRetail() ? privOf(p, INV.orig && INV.orig.id) : null;
    if (!pr) { if (b) b.remove(); if (INV.privilege && INV.privilege.on) { INV.privilege = { on: false }; } return; }
    if (INV.privilege === undefined) INV.privilege = { on: INV.orig ? !!INV.orig.privilege : (privAuto() && !num(INV.discValue)) };
    const mk = makingOf(INV.items, INV.type), amt = Math.round(mk * PRIV_PCT / 100);
    if (!b) { b = document.createElement('div'); b.id = 'sjx-priv'; box.insertAdjacentElement('afterend', b); }
    b.className = 'sjx-priv' + (INV.privilege.on ? ' on' : '');
    b.innerHTML = `<div><b>⭐ Privilege customer</b> <span class="mono small">${esc(pr.id)}</span><div class="small muted">Pehla bill ${esc(pr.first)} · ${fmtD(pr.since)} · ${pr.bills} bill · making par lifetime ${PRIV_PCT}% chhoot</div></div><div class="right">${INV.privilege.on ? `<b class="green">− ${inr(amt)}</b><div class="small muted">making ${inr(mk)} ka ${PRIV_PCT}%</div>` : `<span class="small muted">Chhoot ${inr(amt)}</span>`}<div><button type="button" class="btn sm ${INV.privilege.on ? '' : 'gold'}" data-act="sjx-priv-toggle">${INV.privilege.on ? 'Hatao' : 'Chhoot lagao'}</button></div></div>`;
  }
  function privApply() {
    if (!INV || !INV.privilege || !INV.privilege.on || !invIsRetail()) return;
    const amt = Math.round(makingOf(INV.items, INV.type) * PRIV_PCT / 100); INV.discMode = 'flat'; INV.discValue = amt || '';
    const a = q$('[data-inv="discValue"]', INV.el), m = q$('[data-inv="discMode"]', INV.el); if (a) a.value = amt || ''; if (m) m.value = 'flat';
  }
  if (typeof renderInvParty === 'function') { const R0 = renderInvParty; renderInvParty = function () { const r = R0.apply(this, arguments); try { privBanner(); if (INV && INV.privilege && INV.privilege.on) { privApply(); } } catch (e) { console.error(e); } return r; }; }
  if (typeof refreshTotals === 'function') { const T0 = refreshTotals; let busy = false; refreshTotals = function () { if (!busy && INV && INV.el) { busy = true; try { privApply(); privBanner(); } catch (e) { console.error(e); } busy = false; } return T0.apply(this, arguments); }; }
  document.addEventListener('input', e => { const t = e.target; if (!INV || !INV.el || !t.matches || !t.matches('[data-inv="discValue"],[data-inv="discMode"]')) return; if (INV.privilege && INV.privilege.on) { INV.privilege = { on: false }; privBanner(); } }, true);
  ACT['sjx-priv-toggle'] = () => { if (!INV) return; INV.privilege = { on: !(INV.privilege && INV.privilege.on) }; if (!INV.privilege.on) { INV.discValue = ''; const a = q$('[data-inv="discValue"]', INV.el); if (a) a.value = ''; } refreshTotals(); };
  if (typeof persistInvoice === 'function') {
    const P0 = persistInvoice;
    persistInvoice = async function (st) {
      const r = await P0.apply(this, arguments);
      try {
        if (r && r.inv && (r.inv.type === 'sale' || r.inv.type === 'estimate')) {
          const on = st && st.privilege && st.privilege.on && num(st.discValue) > 0 && chanOf(r.inv) === 'retail';
          if (on) { const c = custById(r.inv.partyId); const inv2 = { ...r.inv, privilege: { id: privilegeId(c, r.inv), pct: PRIV_PCT, amount: r2(num(st.discValue)), making: makingOf(r.inv.items, r.inv.type) } }; if (await save('invoices', inv2)) r.inv = inv2; }
          else if (r.inv.privilege) { const inv2 = { ...r.inv }; delete inv2.privilege; if (await save('invoices', inv2)) r.inv = inv2; }
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }
  addCss(`.sjx-priv{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-top:10px;padding:10px 12px;border:1px dashed var(--gold,#c9a046);border-radius:12px;background:rgba(201,160,70,.07)}.sjx-priv.on{border-style:solid;background:rgba(60,207,122,.08)}.sjx-priv .right{text-align:right}.sjx-priv .btn{margin-top:4px}`);
  function privReport(a, b) {
    const L = S.invoices.filter(v => !v.deleted && v.privilege && num(v.privilege.amount) > 0 && (!a || inRange(v.date, a, b))).sort((x, y) => String(y.date).localeCompare(String(x.date)));
    const cust = new Map(); S.invoices.forEach(v => { if (!v.deleted && isRetailBill(v)) cust.set(v.partyId, (cust.get(v.partyId) || 0) + 1); });
    return { L, members: cust.size, repeat: [...cust.values()].filter(n => n > 1).length };
  }
  if (window.SJ_REPORTS && SJ_REPORTS.add) {
    const H = SJ_REPORTS.h;
    SJ_REPORTS.add('privilege', 'sales', '⭐ Privilege (20% making) — bachat & repeat grahak', 'Kis bill par kitni privilege chhoot di, kul chhoot, privilege grahak, kitne dobara aaye', { period: 'range', defRp: 'fy', build(r) {
      const x = privReport(r.a, r.b);
      return { summary: [['Privilege bills', x.L.length], ['Kul chhoot', inr(sum(x.L, v => v.privilege.amount))], ['Privilege grahak (kul)', x.members], ['Dobara aaye', x.repeat]],
        sections: [H.sec('', [H.C('Date', 'd'), H.C('Bill', 's'), H.C('Grahak', 's'), H.C('Privilege ID', 's'), H.C('Making', 'inr'), H.C('Chhoot', 'inr'), H.C('Bill rakam', 'inr')], x.L.map(v => [v.date, v.no, v.partyName, v.privilege.id || '', num(v.privilege.making), num(v.privilege.amount), invPayable(v)]))] };
    } });
  }

  /* =====================================================================
     2. WhatsApp PDF (light) + E-way bill JSON buttons on the bill view
     ===================================================================== */
  if (typeof openInvoiceView === 'function') {
    const OV = openInvoiceView;
    openInvoiceView = function (id) {
      const r = OV.apply(this, arguments);
      try {
        const v = S.invoices.find(x => x.id === id); const el = q$('#modal-root').lastElementChild;
        const pb = el && q$('.m-foot [data-act="inv-pdf"]', el);
        if (v && pb && v.type !== 'oldgold' && !q$('[data-act="sjx-wa-pdf"]', el)) {
          pb.insertAdjacentHTML('beforebegin', `<button type="button" class="btn green" data-act="sjx-wa-pdf" data-id="${esc(v.id)}" title="Halki PDF (lagbhag 300–600 KB) — WhatsApp par bhejne ke liye">📲 WhatsApp PDF</button>`);
          if (v.type === 'sale' && hasGst(v.type) && v.quality !== 'kacha') pb.insertAdjacentHTML('beforebegin', `<button type="button" class="btn" data-act="sjx-ewb" data-id="${esc(v.id)}" title="E-way bill Part-A JSON (portal bulk upload)">🚚 E-way JSON</button>`);
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }
  ACT['sjx-wa-pdf'] = async t => {
    const v = S.invoices.find(x => x.id === t.dataset.id); if (!v) return; t.disabled = true; const old = t.textContent; t.textContent = '⏳ Ban raha hai…';
    try {
      const sig = window.SJ_BILLX && SJ_BILLX.styleNow() === 'signature';
      const blob = sig ? await SJ_BILLX.signatureInvoicePdf(v, { lite: true }) : await invoicePdf(v);
      const name = safeName(v.no + '_' + v.partyName) + '.pdf'; const file = new File([blob], name, { type: 'application/pdf' });
      const msg = (() => { try { const u = waLink(v); return u ? decodeURIComponent(u.split('?text=')[1] || '') : ''; } catch (e) { return ''; } })();
      if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file], text: msg }); return; } catch (e) { if (e && e.name === 'AbortError') return; } }
      await offerDownload(name, blob); const wa = waLink(v); toast('PDF (' + Math.round(blob.size / 1024) + ' KB) download hui — ' + (wa ? 'WhatsApp khul raha hai, PDF attach kijiye' : 'WhatsApp mein attach kijiye'));
      if (wa) setTimeout(() => window.open(wa, '_blank', 'noopener'), 800);
    } finally { t.disabled = false; t.textContent = old; }
  };

  // ---- e-way bill Part-A JSON (NIC bulk-generation format) ----
  const stOf = g => { const m = String(g || '').match(/^(\d{2})/); return m ? +m[1] : 0; };
  const pinOf2 = s => { const m = String(s || '').match(/\b([1-9]\d{5})\b/); return m ? +m[1] : 0; };
  const dmy = d => { const [y, m, dd] = String(d).split('-'); return `${dd}/${m}/${y}`; };
  function ewbJson(v, o) {
    const s = settings(), c = custById(v.partyId) || {}, t = v.totals || {}, ratio = num(t.itemsTotal) ? num(t.taxable) / num(t.itemsTotal) : 1, intra = t.intra !== false;
    const fromSt = +(s.stateCode || stOf(s.gstin)) || 8, toG = String(v.partyGstin || c.gstin || '').toUpperCase(), toSt = stOf(toG) || +(c.stateCode || (intra ? fromSt : 0)) || fromSt;
    const hsn = it => { try { return +String(hsnInfo(it).code).slice(0, 8) || 7113; } catch (e) { return 7113; } };
    const items = (v.items || []).map((it, i) => ({ itemNo: i + 1, productName: `${it.category || 'Jewellery'} ${it.purity || ''}`.trim().slice(0, 100), productDesc: (`${it.category || ''} ${it.purity || ''}${it.huid ? ' HUID ' + it.huid : ''}`).trim().slice(0, 100), hsnCode: hsn(it), quantity: r3(num(it.net) || num(it.gross) || 1), qtyUnit: 'GMS', taxableAmount: r2(num(it.amount) * ratio), sgstRate: intra ? 1.5 : 0, cgstRate: intra ? 1.5 : 0, igstRate: intra ? 0 : 3, cessRate: 0, cessNonAdvol: 0 }));
    const firmAddr = String(s.address || ''), toAddr = String(v.partyAddress || c.address || c.city || '');
    return { version: '1.0.0621', billLists: [{ userGstin: s.gstin, supplyType: 'O', subSupplyType: 1, subSupplyDesc: '', docType: 'INV', docNo: String(v.no).slice(0, 16), docDate: dmy(v.date), transType: 1,
      fromGstin: s.gstin, fromTrdName: (s.legal || s.firm || '').slice(0, 100), fromAddr1: firmAddr.slice(0, 120), fromAddr2: '', fromPlace: (s.city || 'Jayal').slice(0, 50), fromPincode: pinOf2(firmAddr), fromStateCode: fromSt, actualFromStateCode: fromSt,
      toGstin: /^[0-9]{2}[A-Z0-9]{13}$/.test(toG) ? toG : 'URP', toTrdName: String(v.partyName || '').slice(0, 100), toAddr1: toAddr.slice(0, 120), toAddr2: '', toPlace: String(v.partyCity || c.city || '').slice(0, 50), toPincode: +(c.pin || pinOf2(toAddr)) || 0, toStateCode: toSt, actualToStateCode: toSt,
      totalValue: r2(num(t.taxable)), cgstValue: r2(num(t.cgst)), sgstValue: r2(num(t.sgst)), igstValue: r2(num(t.igst)), cessValue: 0, cessNonAdvolValue: 0, TotNonAdvolVal: 0, OthValue: r2(num(t.grand) - num(t.taxable) - num(t.cgst) - num(t.sgst) - num(t.igst)), totInvValue: r2(num(t.grand)),
      transMode: o.mode === 'self' ? 1 : +o.mode || 1, transDistance: String(Math.max(0, Math.round(num(o.km)))), transporterName: o.tname || '', transporterId: String(o.tid || '').toUpperCase(), transDocNo: o.lr || '', transDocDate: o.lrDate ? dmy(o.lrDate) : '', vehicleNo: String(o.vno || '').toUpperCase().replace(/[^A-Z0-9]/g, ''), vehicleType: 'R',
      mainHsnCode: items.length ? items.slice().sort((a, b) => b.taxableAmount - a.taxableAmount)[0].hsnCode : 7113, itemList: items }] };
  }
  ACT['sjx-ewb'] = t => {
    const v = S.invoices.find(x => x.id === t.dataset.id); if (!v) return; const s = settings(); const c = custById(v.partyId) || {};
    const miss = []; if (!/^[0-9]{2}[A-Z0-9]{13}$/.test(String(s.gstin || ''))) miss.push('firm GSTIN'); if (!pinOf2(s.address)) miss.push('firm address mein PIN'); if (!(c.pin || pinOf2(v.partyAddress || c.address))) miss.push('customer ka PIN code');
    const inter = (v.totals || {}).intra === false;
    openModal(`<form data-sjx="ewb" data-id="${esc(v.id)}" novalidate>${mHead('🚚 E-way bill — ' + esc(v.no), 'Part-A JSON · ewaybillgst.gov.in → Generate → Bulk upload')}<div class="m-body">
      <div class="note small" style="margin-bottom:10px">${inter ? '<b>Doosre state mein maal:</b> sone / gehne (Chapter 71) ke liye e-way bill zaroori hai, rakam kitni bhi ho.' : '<b>Rajasthan ke andar:</b> Chapter 71 (sona / gehne) ke liye e-way bill state ke notification par nirbhar hai — CA se confirm karein.'} JSON portal par upload karne se pehle wahan details ek baar dekh lijiye.</div>
      ${miss.length ? `<div class="note red small" style="margin-bottom:10px">Kami: ${miss.map(esc).join(', ')} — JSON banega, par portal ise rok sakta hai.</div>` : ''}
      <div class="fg">${F('Doori (km) *', inp('km', '', { type: 'number', min: 0, im: 'numeric' }))}${F('Kaise ja raha hai', sel('mode', [['1', 'Road (gaadi / courier)'], ['2', 'Rail'], ['3', 'Air'], ['4', 'Ship']], '1'))}${F('Gaadi no.', inp('vno', '', { ph: 'RJ21AB1234' }))}${F('Transporter / courier naam', inp('tname', ''))}${F('Transporter ID (GSTIN / TRANSIN)', inp('tid', ''))}${F('LR / docket no.', inp('lr', ''))}${F('LR date', inp('lrDate', '', { type: 'date' }))}</div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button type="submit" class="btn primary">⬇ JSON banao</button></div></form>`);
  };
  document.addEventListener('submit', async e => {
    const f = e.target; if (!f.matches || !f.matches('form[data-sjx="ewb"]')) return; e.preventDefault(); e.stopPropagation();
    const v = S.invoices.find(x => x.id === f.dataset.id); const o = formVals(f); if (!num(o.km) && num(o.km) !== 0 || o.km === '') return toast('Doori (km) daaliye', 'err');
    const j = ewbJson(v, o); await offerDownload('ewaybill_' + safeName(v.no) + '.json', new Blob([JSON.stringify(j, null, 1)], { type: 'application/json' })); closeModal(f.closest('.overlay'));
  }, true);
  window.SJX_EWB = ewbJson;

  /* =====================================================================
     3. Camera scan (Android Chrome: BarcodeDetector) — tags, bill, stock audit
     ===================================================================== */
  const HAS_BD = 'BarcodeDetector' in window;
  let CAM = null;
  function beep() { try { const a = new (window.AudioContext || window.webkitAudioContext)(); const o = a.createOscillator(); const g = a.createGain(); o.frequency.value = 1250; g.gain.value = 0.08; o.connect(g); g.connect(a.destination); o.start(); setTimeout(() => { o.stop(); a.close(); }, 90); } catch (e) { /* */ } try { navigator.vibrate && navigator.vibrate(40); } catch (e) { /* */ } }
  async function camScan(o) {
    if (!HAS_BD) { toast('Is browser mein camera scan nahi chalta (iPhone Safari / purana browser). Android par Chrome kholiye, ya barcode gun / RFID reader lagaiye.', 'err'); return; }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { toast('Camera nahi mila', 'err'); return; }
    let formats = ['qr_code', 'code_39', 'code_128', 'ean_13']; try { const sup = await BarcodeDetector.getSupportedFormats(); formats = formats.filter(f => sup.includes(f)); } catch (e) { /* */ }
    const det = new BarcodeDetector({ formats });
    const el = openModal(`${mHead('📷 ' + esc(o.title || 'Camera scan'), o.continuous ? 'Ek-ek karke tags camera ke saamne laaiye — har scan apne-aap judta jayega' : 'Tag ka QR / barcode camera ke saamne laaiye')}<div class="m-body"><div class="sjx-cam"><video playsinline muted autoplay></video><i></i></div><div class="sjx-cam-log small muted">Camera khul raha hai…</div></div><div class="m-foot"><button type="button" class="btn primary" data-act="close">${o.continuous ? '✓ Ho gaya' : 'Band karo'}</button></div>`, { small: true });
    const video = q$('video', el), log = q$('.sjx-cam-log', el); let stream = null, alive = true, last = '', lastAt = 0, n = 0;
    const stop = () => { alive = false; try { stream && stream.getTracks().forEach(t => t.stop()); } catch (e) { /* */ } CAM = null; };
    new MutationObserver((m, ob) => { if (!el.isConnected) { stop(); ob.disconnect(); } }).observe(q$('#modal-root'), { childList: true });
    try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false }); } catch (e) { log.innerHTML = '<span class="red">Camera ki permission nahi mili — browser settings mein camera allow kijiye.</span>'; return; }
    video.srcObject = stream; CAM = { stop }; log.textContent = 'Taiyaar — scan kijiye';
    const tick = async () => {
      if (!alive) return;
      try { if (video.readyState >= 2) { const codes = await det.detect(video); for (const c of codes) { const val = String(c.rawValue || '').trim(); if (!val) continue; const now = Date.now(); if (val === last && now - lastAt < 2500) continue; last = val; lastAt = now; n++; beep(); log.innerHTML = `${n} scan · aakhri: <b class="mono">${esc(val.slice(0, 40))}</b>`; const keep = await o.onCode(val); if (!o.continuous || keep === false) { closeModal(el); stop(); return; } } } } catch (e) { /* frame not ready */ }
      setTimeout(tick, 180);
    };
    video.onloadedmetadata = () => { video.play().catch(() => { }); tick(); };
  }
  const tagValue = val => { const m = String(val).match(/[?&](?:sku|s)=([A-Za-z0-9-]+)/); return (m ? m[1] : String(val)).trim(); };
  function pressEnter(inpEl, val) { inpEl.value = val; inpEl.dispatchEvent(new Event('input', { bubbles: true })); inpEl.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true, cancelable: true })); }
  function mountCamBtns() {
    [['scan-q', false, 'Piece scan'], ['aud-in', true, 'Stock milaan (audit)'], ['rf-in', false, 'Piece ka QR']].forEach(([id, cont, title]) => {
      const i = document.getElementById(id); if (!i || i.dataset.sjxCam) return; i.dataset.sjxCam = '1';
      const b = document.createElement('button'); b.type = 'button'; b.className = 'btn sm sjx-cam-btn'; b.textContent = '📷 Camera'; b.title = 'Phone camera se QR / barcode scan'; b.dataset.act = 'sjx-cam'; b.dataset.for = id; b.dataset.cont = cont ? '1' : ''; b.dataset.title = title;
      const host = i.closest('.scan-input,.scanbox') || i; host.insertAdjacentElement('afterend', b);
    });
  }
  setInterval(mountCamBtns, 900);
  ACT['sjx-cam'] = t => { const id = t.dataset.for; camScan({ title: t.dataset.title, continuous: !!t.dataset.cont, onCode: v => { const i = document.getElementById(id); if (!i) return false; pressEnter(i, tagValue(v)); return true; } }); };
  addCss(`.sjx-cam{position:relative;border-radius:14px;overflow:hidden;background:#000;aspect-ratio:4/3}.sjx-cam video{width:100%;height:100%;object-fit:cover;display:block}.sjx-cam i{position:absolute;inset:22% 14%;border:3px solid rgba(242,214,138,.9);border-radius:14px;box-shadow:0 0 0 999px rgba(0,0,0,.25)}.sjx-cam-log{margin-top:10px}.sjx-cam-btn{margin:8px 0 0}`);
  window.SJX_CAM = camScan;

  /* =====================================================================
     4. Aaj ka bhav — morning reminder + AI web lookup (never saved without the owner's OK)
     ===================================================================== */
  if (typeof openRates === 'function') {
    const OR = openRates;
    openRates = function () {
      const r = OR.apply(this, arguments);
      try {
        const f = q$('form[data-form="rates"]'); if (f && SITE && canEdit() && !q$('.sjx-rate-ai', f)) {
          const sec = q$('.m-body section', f) || q$('.m-body', f);
          sec.insertAdjacentHTML('beforeend', `<div class="sjx-rate-ai"><div class="btns"><button type="button" class="btn sm gold" data-act="sjx-rate-ai">🤖 Aaj ka bazaar bhav dhoondo (internet)</button><input class="sjx-rate-city" value="${esc(((settings().pro || {}).rateCity) || 'Jaipur')}" aria-label="Shahar" style="max-width:130px"></div><div class="sjx-rate-out small muted">AI internet par aaj ka sarafa bhav dhoondhega — aap dekh kar hi bharenge. Bill wahi bhav lagega jo aap Save karenge.</div></div>`);
        }
      } catch (e) { console.error(e); }
      return r;
    };
  }
  ACT['sjx-rate-ai'] = async t => {
    const f = t.closest('form'); const out = q$('.sjx-rate-out', f); const city = (q$('.sjx-rate-city', f).value || 'Jaipur').trim();
    t.disabled = true; out.innerHTML = '⏳ Internet par aaj ka bhav dhoondh rahe hain (20–60 second)…';
    try {
      const r = await window.SJ_API_CALL('ai_rate', { city }, 120000);
      if (!(r.gold24 > 1000)) throw new Error('AI ko pakka bhav nahi mila — haath se daaliye.');
      f._ai = r; const gs = num(settings().gold24), ss = num(settings().silver999);
      const ch = (n, o2) => o2 ? ` <span class="${Math.abs(n - o2) / o2 > 0.04 ? 'red' : 'muted'}">(${n >= o2 ? '+' : ''}${inr(n - o2)})</span>` : '';
      out.innerHTML = `<div class="sjx-rate-res"><div>Sona 24K: <b>${inr(r.gold24)}</b>/10g${ch(r.gold24, gs)}${r.gold22 ? ` · 22K ${inr(r.gold22)}` : ''}</div><div>Chandi 999: <b>${r.silver ? inr(r.silver) + '/kg' : '—'}</b>${r.silver ? ch(r.silver, ss) : ''}</div><div class="muted">${esc(r.city || city)}${r.asOf ? ' · ' + esc(r.asOf) : ''}${r.note ? ' · ' + esc(r.note) : ''}</div>${(r.sources || []).length ? `<div class="muted">Source: ${r.sources.map(s => `<a href="${esc(s.url)}" target="_blank" rel="noopener noreferrer">${esc((s.title || s.url).slice(0, 40))}</a>`).join(' · ')}</div>` : ''}${gs && Math.abs(r.gold24 - gs) / gs > 0.04 ? '<div class="red">Kal ke bhav se 4% se zyada farq — dhyan se check kijiye.</div>' : ''}<div class="btns" style="margin-top:6px"><button type="button" class="btn sm primary" data-act="sjx-rate-fill">Ye bhav bharo</button></div></div>`;
    } catch (e) { out.innerHTML = '<span class="red">' + esc(e.message || 'Nahi mila') + '</span>'; }
    finally { t.disabled = false; }
  };
  ACT['sjx-rate-fill'] = t => { const f = t.closest('form'); const r = f && f._ai; if (!r) return; const g = q$('[name="gold24"]', f), s2 = q$('[name="silver999"]', f); if (g) g.value = Math.round(r.gold24); if (s2 && r.silver) s2.value = Math.round(r.silver); f._aiFilled = { g: Math.round(r.gold24), s: r.silver ? Math.round(r.silver) : null, city: r.city }; toast('Bhav bhar diya — check karke Save dabaiye'); };
  if (typeof submitRates === 'function') {
    const SR = submitRates;
    submitRates = async function (form) {
      const fill = form && form._aiFilled; const g = num((q$('[name="gold24"]', form) || {}).value), sv = num((q$('[name="silver999"]', form) || {}).value);
      await SR.apply(this, arguments);
      try { if (fill && g === fill.g && settings().ratesUpdated === todayStr()) { const src = 'auto: AI web (' + (fill.city || '') + ') — ' + (me().name || 'owner') + ' ne pakka kiya'; await saveSettings({ ...S.settings, ratesSource: src }); const t = todayStr(); save('rateHistory', { id: t, date: t, gold24: g, silver999: sv, source: src }, { quiet: true }); } } catch (e) { console.error(e); }
    };
  }
  // morning reminder: first open after 9 AM with yesterday's rates → open the rate box once
  setTimeout(function morning() {
    try {
      if (!canEdit() || typeof openRates !== 'function') return; const s = settings(); const t = todayStr(); if (s.ratesUpdated === t || new Date().getHours() < 9) return;
      let k = ''; try { k = localStorage.getItem('sjx_rate_prompt') || ''; } catch (e) { /* */ } if (k === t) return;
      if (q$('#modal-root') && q$('#modal-root').children.length) { setTimeout(morning, 20000); return; }
      try { localStorage.setItem('sjx_rate_prompt', t); } catch (e) { /* */ }
      toast('🌅 Suprabhat! Aaj ka sona-chandi bhav bhariye'); openRates();
    } catch (e) { console.error(e); }
  }, 6000);
  addCss(`.sjx-rate-ai{margin-top:12px;padding-top:10px;border-top:1px dashed var(--line,#3a2f1a)}.sjx-rate-out{margin-top:8px}.sjx-rate-res{display:flex;flex-direction:column;gap:3px;font-size:13px}`);

  /* =====================================================================
     6. Setup cards: auto-backup, 2-step login, portal catalogue
     ===================================================================== */
  const kb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';
  function backupCard() {
    if (!SITE || !isOwner()) return '';
    setTimeout(async () => { const el = q$('#sjx-bk-card'); if (!el) return; try { const r = await window.SJ_API_CALL('backup_list', {}); el._r = r; paintBackup(el); } catch (e) { q$('.sjx-bk-list', el).innerHTML = '<span class="red">' + esc(e.message || 'Nahi mila') + '</span>'; } }, 0);
    return `<div class="card" id="sjx-bk-card"><div class="card-h"><h3>🗄 Roz ka auto-backup</h3><button type="button" class="btn sm" data-act="sjx-bk-now">Abhi backup lo</button></div><p class="small muted" style="margin-top:0">Server roz pehli baar software khulte hi poore data ki copy bana leta hai (encrypted). Pichhle 14 din + har mahine ki ek copy (1 saal) rakhi jaati hai. Kisi bhi din ka data wapas chahiye to us din ki file download karke <b>Backup & restore → Restore</b> mein chuniye.</p><div class="sjx-bk-list small muted">Loading…</div>
      <div class="sjx-bk-mail" style="margin-top:12px"></div></div>`;
  }
  function paintBackup(el) {
    const r = el._r || {}; const L = r.list || [];
    q$('.sjx-bk-list', el).innerHTML = L.length ? `<div class="sjx-bk-rows">${L.slice(0, 20).map(b => `<div class="sp-row"><span>${fmtD(b.date)} <span class="muted">${kb(b.size)}</span></span><button type="button" class="btn sm" data-act="sjx-bk-get" data-name="${esc(b.name)}">⬇ Download</button></div>`).join('')}</div>` : 'Abhi koi backup nahi — "Abhi backup lo" dabaiye.';
    q$('.sjx-bk-mail', el).innerHTML = `<label class="chk"><input type="checkbox" class="sjx-bk-mailon" ${r.mail ? 'checked' : ''} ${r.email && r.mailFn ? '' : 'disabled'}> Har hafte backup email par bhi bhejo${r.email ? ' (<b>' + esc(r.email) + '</b>)' : ''}</label><div class="small muted">${!r.email ? 'Pehle neeche "Shaq wali activity — email" mein email daaliye.' : !r.mailFn ? '<span class="red">Hosting par mail() band hai.</span>' : 'Email mein poora data hota hai (15 MB tak) — ise sirf apne private email par rakhiye.' + (r.lastMail ? ' Aakhri email: ' + fmtD(new Date(r.lastMail * 1000).toISOString().slice(0, 10)) + '.' : '')}</div>${r.mail ? '<button type="button" class="btn sm" data-act="sjx-bk-mailtest" style="margin-top:6px">Abhi test email bhejo</button>' : ''}`;
  }
  ACT['sjx-bk-now'] = async t => { const el = t.closest('#sjx-bk-card'); t.disabled = true; try { const r = await window.SJ_API_CALL('backup_now', {}, 120000); if (!r.ok) throw new Error(r.message || 'Nahi bana'); el._r = { ...(el._r || {}), list: r.list }; paintBackup(el); toast('✓ Backup ban gaya'); } finally { t.disabled = false; } };
  ACT['sjx-bk-get'] = async t => {
    t.disabled = true; const old = t.textContent; t.textContent = '⏳';
    try { const res = await fetch('sj-api.php?a=backup_get', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-SJ': '1' }, body: JSON.stringify({ name: t.dataset.name }) }); if (!res.ok) { let m = 'Download nahi hua'; try { m = (await res.json()).message || m; } catch (e) { /* */ } throw new Error(m); } const b = await res.blob(); await offerDownload('shivaa-backup-' + t.dataset.name.slice(8, 18) + '.json', b); }
    finally { t.disabled = false; t.textContent = old; }
  };
  document.addEventListener('change', async e => { const c = e.target; if (!c.classList || !c.classList.contains('sjx-bk-mailon')) return; const el = c.closest('#sjx-bk-card'); try { const r = await window.SJ_API_CALL('backup_cfg', { mail: c.checked }); el._r = { ...(el._r || {}), mail: r.mail }; paintBackup(el); toast(r.mail ? '✓ Hafte ka backup email chalu' : 'Backup email band'); } catch (er) { c.checked = !c.checked; toast(er.message || 'Nahi hua', 'err'); } });
  ACT['sjx-bk-mailtest'] = async t => { t.disabled = true; try { const r = await window.SJ_API_CALL('backup_cfg', { test: true }, 120000); const m = { sent: '✓ Email bheja — inbox / spam dekhiye', no_email: 'Email set nahi hai', no_backup: 'Pehle "Abhi backup lo" dabaiye', too_big: 'Data 15 MB se bada hai — email nahi ja sakta, Download use kijiye', mail_failed: 'Hosting ne email nahi bheja' }; toast(m[r.result] || r.result, r.result === 'sent' ? '' : 'err'); } finally { t.disabled = false; } };

  function twoStepCard() {
    if (!SITE || !isOwner()) return '';
    setTimeout(async () => { const el = q$('#sjx-2fa-card'); if (!el) return; try { const r = await window.SJ_API_CALL('totp_status', {}); paint2fa(el, r); } catch (e) { /* */ } }, 0);
    return `<div class="card" id="sjx-2fa-card"><div class="card-h"><h3>🔐 Owner login par 2-step (OTP)</h3></div><div class="sjx-2fa small muted">Loading…</div></div>`;
  }
  function paint2fa(el, r) {
    q$('.sjx-2fa', el).innerHTML = r.on
      ? `<div><span class="pill green">Chalu ✓</span> Owner login par password ke saath phone ki Authenticator app ka code bhi lagta hai. Backup codes bache: <b>${r.codesLeft}</b>.</div>${r.bypass ? '<div class="red" style="margin-top:6px">sj-config.php mein disable_2fa = true hai — abhi 2-step band chal raha hai. Phone milte hi use hata dijiye.</div>' : ''}<div class="btns" style="margin-top:8px"><button type="button" class="btn sm danger" data-act="sjx-2fa-off">Band karo</button></div>`
      : `<p style="margin:0 0 8px">Password chori ho jaye tab bhi koi Owner login nahi kar payega — har login par phone ki <b>Google Authenticator</b> (ya Microsoft Authenticator) app ka 6 ank ka code lagega.</p><button type="button" class="btn sm gold" data-act="sjx-2fa-on">Chalu karo</button>`;
  }
  function pwModal(title, extra, cb) {
    const el = openModal(`<form data-sjx="pw" novalidate>${mHead(title, '')}<div class="m-body"><div class="fg">${F('Owner ka password', '<input name="password" type="password" autocomplete="current-password" required>')}${extra || ''}</div><div class="sjx-err red small"></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Aage</button></div></form>`, { small: true });
    q$('form', el).onsubmit = async ev => { ev.preventDefault(); const b = q$('button.primary', el); b.disabled = true; try { await cb(formVals(ev.target), el); } catch (er) { q$('.sjx-err', el).textContent = er.message || 'Nahi hua'; } finally { b.disabled = false; } };
  }
  ACT['sjx-2fa-on'] = () => pwModal('2-step login chalu karo', '', async (v, el) => {
    const r = await window.SJ_API_CALL('totp_init', { password: v.password }); closeModal(el);
    const el2 = openModal(`<form data-sjx="totp" novalidate>${mHead('Phone mein Authenticator jodo', '3 aasaan step')}<div class="m-body"><ol class="small" style="padding-left:18px;margin-top:0"><li>Phone mein <b>Google Authenticator</b> app install kijiye (Play Store / App Store).</li><li>App mein <b>+</b> → <b>Scan a QR code</b> → ye QR scan kijiye.</li><li>App mein dikh raha 6 ank ka code neeche daaliye.</li></ol><div class="sjx-qr">${qrSVG(r.uri)}</div><div class="small muted" style="text-align:center;word-break:break-all">QR scan na ho to ye key haath se daaliye:<br><b class="mono">${esc(r.secret.replace(/(.{4})/g, '$1 ').trim())}</b></div><div class="fg" style="margin-top:12px">${F('6 ank ka code', '<input name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required>')}</div><div class="sjx-err red small"></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Chalu karo</button></div></form>`, { small: true });
    q$('form', el2).onsubmit = async ev => { ev.preventDefault(); const b = q$('button.primary', el2); b.disabled = true;
      try { const x = await window.SJ_API_CALL('totp_enable', { code: formVals(ev.target).code }); closeModal(el2); const txt = x.codes.join('\n');
        openModal(`${mHead('✓ 2-step login chalu', 'Backup codes sambhal kar rakhiye')}<div class="m-body"><p class="small">Phone kho jaye to in codes se login ho jayega (har code ek hi baar chalta hai). Inhe likh kar ya print karke tijori mein rakhiye — phone mein nahi.</p><pre class="sjx-codes mono">${esc(txt)}</pre><p class="small muted">Sab codes bhi kho jayein: hosting File Manager mein <b>sj-config.php</b> mein <span class="mono">'disable_2fa' => true,</span> jodiye, login karke 2-step dobara set kijiye, phir wo line hata dijiye.</p></div><div class="m-foot"><button type="button" class="btn" data-act="sjx-codes-dl" data-t="${esc(txt)}">⬇ Codes download</button><button type="button" class="btn primary" data-act="close">Ho gaya</button></div>`, { small: true });
        const c = q$('#sjx-2fa-card'); if (c) paint2fa(c, { on: true, codesLeft: 8 });
      } catch (er) { q$('.sjx-err', el2).textContent = er.message || 'Code galat'; } finally { b.disabled = false; } };
  });
  ACT['sjx-codes-dl'] = t => offerDownload('shivaa-2step-backup-codes.txt', new Blob([(settings().firm || 'Shivaa Jewels') + ' — Owner 2-step backup codes (har code ek baar)\n\n' + t.dataset.t + '\n'], { type: 'text/plain' }));
  ACT['sjx-2fa-off'] = () => pwModal('2-step login band karo', F('Authenticator code ya backup code', '<input name="code" inputmode="numeric" autocomplete="one-time-code" required>'), async (v, el) => { await window.SJ_API_CALL('totp_disable', { password: v.password, code: v.code }); closeModal(el); toast('2-step login band'); const c = q$('#sjx-2fa-card'); if (c) paint2fa(c, { on: false }); });
  addCss(`.sjx-qr{display:flex;justify-content:center;margin:10px 0}.sjx-qr svg{width:210px;height:210px;background:#fff;padding:10px;border-radius:12px}.sjx-codes{font-size:17px;line-height:1.7;text-align:center;background:rgba(201,160,70,.08);border-radius:12px;padding:10px}.sjx-bk-rows{max-height:260px;overflow:auto}`);

  function catalogCard() {
    if (!SITE || !canAdmin()) return '';
    setTimeout(async () => { const el = q$('#sjx-cat-card'); if (!el) return; try { const r = await window.SJ_API_CALL('catalog_status', {}); paintCat(el, r.cfg || {}); } catch (e) { /* */ } }, 0);
    return `<div class="card" id="sjx-cat-card"><div class="card-h"><h3>🛍 Customer portal par naye design</h3></div><div class="sjx-cat small muted">Loading…</div></div>`;
  }
  function paintCat(el, c) {
    const cats = [...new Set(S.products.filter(p => p.status === 'In Stock').map(p => p.category).filter(Boolean))].sort(); const withPh = S.products.filter(p => p.status === 'In Stock' && p.photo).length; const on = new Set(c.cats || []);
    q$('.sjx-cat', el).innerHTML = `<p style="margin:0 0 8px">Customer apne portal link par dukaan ke <b>photo wale In-Stock</b> gehne dekh sakenge aur “Mujhe ye chahiye” daba sakenge — aapko turant alert aayega. Rate / keemat nahi dikhti. Abhi photo wale piece: <b>${withPh}</b>.</p>
      <label class="chk"><input type="checkbox" class="sjx-cat-on" ${c.on ? 'checked' : ''}> Portal par naye design dikhao</label>
      <div class="sjx-cat-cats" style="margin:8px 0">${cats.length ? cats.map(k => `<label class="chk" style="display:inline-flex;margin:0 12px 6px 0"><input type="checkbox" value="${esc(k)}" ${on.has(k) ? 'checked' : ''}> ${esc(k)}</label>`).join('') : ''}<div class="muted">Koi category na chunein = sab category.</div></div>
      <div class="fg">${F('Kitne design (6–60)', `<input type="number" class="sjx-cat-max" min="6" max="60" value="${esc(c.max || 24)}">`)}</div><div class="btns" style="margin-top:8px"><button type="button" class="btn sm primary" data-act="sjx-cat-save">Save</button></div>`;
  }
  ACT['sjx-cat-save'] = async t => { const el = t.closest('#sjx-cat-card'); t.disabled = true; try { await window.SJ_API_CALL('catalog_cfg', { on: q$('.sjx-cat-on', el).checked, cats: [...el.querySelectorAll('.sjx-cat-cats input:checked')].map(i => i.value), max: num(q$('.sjx-cat-max', el).value) || 24 }); toast('✓ Portal catalogue save'); } finally { t.disabled = false; } };
  { const V = VIEWDEF.setup; if (V && V.body) VIEWDEF.setup = { ...V, body() { return twoStepCard() + backupCard() + catalogCard() + V.body.apply(V, arguments); } }; }

  /* ---- portal requests → dashboard card ---- */
  function portalReqCard() {
    const L = (S.portalReqs || []).filter(r => r.status === 'new').sort((a, b) => num(b.at) - num(a.at)); if (!L.length) return '';
    return `<div class="card sjx-pr"><div class="card-h"><h3>🛍 Portal se maang (${L.length})</h3></div>${L.slice(0, 8).map(r => { const p = S.products.find(x => x.id === r.productId); const wa = phoneLink(r.phone, `Namaste ${r.name} ji 🙏 ${settings().firm} — aapne portal par ${r.label} pasand kiya. Kab dukaan aa sakte hain? Hum aapke liye rakh dete hain.`);
      return `<div class="row static"><div style="display:flex;gap:10px;align-items:center;min-width:0">${p && p.photo ? `<img src="${esc(p.photo)}" alt="" style="width:46px;height:46px;object-fit:cover;border-radius:8px">` : ''}<div style="min-width:0"><b>${esc(r.name)}</b><div class="small muted">${esc(r.label)} · ${fmtD(new Date(num(r.at)).toISOString().slice(0, 10))}${p && p.status !== 'In Stock' ? ' · <span class="red">' + esc(p.status) + '</span>' : ''}</div></div></div><div class="btns">${wa ? `<a class="btn sm green" href="${esc(wa)}" target="_blank" rel="noopener">WhatsApp</a>` : ''}${p ? `<button type="button" class="btn sm" data-act="sjx-pr-open" data-id="${esc(p.id)}">Piece</button>` : ''}${canEdit() ? `<button type="button" class="btn sm" data-act="sjx-pr-done" data-id="${esc(r.id)}">✓ Ho gaya</button>` : ''}</div></div>`; }).join('')}</div>`;
  }
  ACT['sjx-pr-open'] = t => { if (typeof openProductForm === 'function') openProductForm(t.dataset.id); };
  ACT['sjx-pr-done'] = async t => { const r = (S.portalReqs || []).find(x => x.id === t.dataset.id); if (!r) return; await save('portalReqs', { ...r, status: 'done', doneBy: me().name || '', updatedAt: Date.now() }); toast('✓ Ho gaya'); };

  /* =====================================================================
     7. GIRVI (gold loan against jewellery)
     ===================================================================== */
  Object.assign(ICON, { girvi: '<path d="M7 11V8a5 5 0 0 1 10 0v3"/><rect x="5" y="11" width="14" height="10" rx="2"/><circle cx="12" cy="16" r="1.6"/>' });
  if (typeof VIEWS !== 'undefined' && !VIEWS.some(v => v[0] === 'girvi')) { const i = VIEWS.findIndex(v => v[0] === 'loans'); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, ['girvi', 'Girvi', 'girvi', 'Girvi / Gold loan']); }
  const gcfg = () => ({ rate: 2, term: 12, minMonths: 1, ltv: 75, ...((settings().pro || {}).girvi || {}) });
  const rateG = metal => metal === 'silver' ? num(settings().silver999) / 1000 : num(settings().gold24) / 10;
  const fineOf = it => r3(num(it.net || it.gross) * (num(it.tunch) || (it.metal === 'silver' ? 92.5 : 91.6)) / 100);
  const valueOf = g => r2(sum(g.items || [], it => fineOf(it) * rateG(it.metal || 'gold')));
  /* simple interest per month (rate % / month) on the outstanding principal, day-wise (30-day month); minimum months on closing */
  function gCalc(g, asOf) {
    const end = asOf || todayStr(); const pays = (g.payments || []).slice().sort((a, b) => String(a.date).localeCompare(String(b.date)));
    let P = num(g.principal), acc = 0, from = g.startDate || end, paidI = 0, paidP = 0; const rate = num(g.rate) / 100;
    pays.forEach(p => { if (p.date > end) return; const d = Math.max(0, daysBetween(from, p.date)); acc += P * rate * d / 30; from = p.date > from ? p.date : from; paidI += num(p.interest); paidP += num(p.principal); P = Math.max(0, r2(num(g.principal) - paidP)); });
    acc += P * rate * Math.max(0, daysBetween(from, end)) / 30;
    const days = Math.max(0, daysBetween(g.startDate || end, end)); const minI = num(g.principal) * rate * Math.max(0, num(g.minMonths)); if (g.status !== 'closed' && acc < minI && days < num(g.minMonths) * 30) acc = Math.max(acc, minI);
    const intDue = Math.max(0, r2(acc - paidI)); const months = days / 30; const over = g.status !== 'closed' && num(g.term) > 0 && months > num(g.term);
    const lastI = pays.filter(p => num(p.interest) > 0).map(p => p.date).pop() || g.startDate; const unpaidMonths = Math.floor(Math.max(0, daysBetween(lastI || end, end)) / 30);
    return { P, acc: r2(acc), paidI: r2(paidI), paidP: r2(paidP), intDue, total: r2(P + intDue), days, months, over, unpaidMonths, value: valueOf(g) };
  }
  const gName = g => g.name || ((custById(g.customerId) || {}).name) || '—';
  const gPhone = g => g.phone || ((custById(g.customerId) || {}).phone) || '';
  const gItemsTxt = g => (g.items || []).map(it => `${it.desc || 'Gehna'} ${num(it.net || it.gross).toFixed(2)}g`).join(', ');
  if (!ui.gvTab) ui.gvTab = 'active';
  VIEWDEF.girvi = {
    shell: () => tabs('gvTab', [['active', '🔒 Chalu girvi'], ['due', '⏰ Byaaj baaki / muddat paar'], ['closed', '✅ Chhudaye gaye'], ['rules', '⚙ Niyam']]) + `<div class="toolbar">${canEdit() ? `<button class="btn primary" data-act="sjx-gv-new">${ic('plus', 16)} Nayi girvi</button>` : ''}<input type="search" data-ui="gvQ" value="${esc(ui.gvQ || '')}" placeholder="Naam / phone / girvi no. khojo" aria-label="Khojo"></div><div id="vbody"></div>`,
    body() {
      const t = ui.gvTab || 'active'; if (t === 'rules') return gRules();
      const q = String(ui.gvQ || '').toLowerCase().trim();
      let L = (S.girvi || []).filter(g => !q || [gName(g), gPhone(g), g.no].some(x => String(x || '').toLowerCase().includes(q)));
      const act = (S.girvi || []).filter(g => g.status !== 'closed'); const C = act.map(g => gCalc(g));
      const head = kpis([['Chalu girvi', act.length], ['Mool baaki', inr(sum(C, c => c.P))], ['Byaaj banta (baaki)', inr(sum(C, c => c.intDue))], ['Girvi maal (aaj ki keemat)', inr(sum(C, c => c.value))], ['Muddat paar', `<span class="${C.some(c => c.over) ? 'red' : ''}">${C.filter(c => c.over).length}</span>`]]);
      if (t === 'closed') L = L.filter(g => g.status === 'closed'); else L = L.filter(g => g.status !== 'closed');
      if (t === 'due') L = L.filter(g => { const c = gCalc(g); return c.over || c.unpaidMonths >= 3; });
      L.sort((a, b) => String(b.startDate).localeCompare(String(a.startDate)));
      if (!L.length) return head + emptyBox(t === 'closed' ? 'Abhi koi girvi chhudayi nahi gayi.' : t === 'due' ? 'Koi girvi muddat paar ya 3 mahine se byaaj baaki nahi. 👍' : 'Koi chalu girvi nahi. “Nayi girvi” se gehne girvi rakh kar diya paisa jodiye — byaaj apne-aap judega, rasid PDF milegi.');
      return head + `<div class="grid-cards sjx-gv">${L.map(g => { const c = gCalc(g); const ltv = c.value ? c.P / c.value * 100 : 0;
        return `<div class="card"><div style="display:flex;justify-content:space-between;gap:8px"><div><b>${esc(gName(g))}</b> <span class="pill">${esc(g.no)}</span>${g.status === 'closed' ? ' <span class="pill green">Chhudaya</span>' : c.over ? ' <span class="pill red">Muddat paar</span>' : c.unpaidMonths >= 3 ? ' <span class="pill overdue">' + c.unpaidMonths + ' mahine byaaj baaki</span>' : ''}<div class="small muted">${fmtD(g.startDate)} · ${num(g.rate)}% mahina · ${num(g.term)} mahine · ${esc(gItemsTxt(g)).slice(0, 90)}</div></div></div>
          <div class="sjx-gv-st"><div><span>Mool baaki</span><b>${inr(c.P)}</b></div><div><span>Byaaj baaki</span><b class="${c.intDue > 0.5 ? 'red' : ''}">${inr(c.intDue)}</b></div><div><span>Kul lena</span><b>${inr(c.total)}</b></div><div><span>Maal ki keemat</span><b>${inr(c.value)}</b><small class="${ltv > gcfg().ltv ? 'red' : 'muted'}">${ltv ? ltv.toFixed(0) + '% LTV' : ''}</small></div></div>
          <div class="btns">${g.status !== 'closed' && canEdit() ? `<button class="btn sm gold" data-act="sjx-gv-pay" data-id="${g.id}">Byaaj / jama</button><button class="btn sm" data-act="sjx-gv-close" data-id="${g.id}">Chhudao</button>` : ''}<button class="btn sm" data-act="sjx-gv-view" data-id="${g.id}">Hisaab</button><button class="btn sm" data-act="sjx-gv-pdf" data-id="${g.id}">${ic('dl', 14)} Rasid</button>${g.status !== 'closed' && gPhone(g) ? `<a class="btn sm green" target="_blank" rel="noopener" href="${esc(phoneLink(gPhone(g), `Namaste ${gName(g)} ji 🙏\n${settings().firm} — girvi ${g.no}: aaj tak byaaj ${inr(c.intDue)} baaki hai, mool ${inr(c.P)}. Kripya samay par jama karein.${c.over ? ' Girvi ki muddat poori ho chuki hai — jaldi chhuda lijiye.' : ''}`))}">WhatsApp</a>` : ''}</div></div>`; }).join('')}</div>`;
    }
  };
  function gRules() {
    const c = gcfg();
    return `<div class="card"><h3>Girvi ke default niyam</h3><form data-sjx="gvcfg" novalidate><div class="fg">${F('Byaaj % har mahine', inp('rate', c.rate, { type: 'number', step: '0.01', min: 0 }))}${F('Muddat (mahine)', inp('term', c.term, { type: 'number', step: '1', min: 1 }))}${F('Kam se kam byaaj (mahine)', inp('minMonths', c.minMonths, { type: 'number', step: '0.5', min: 0 }))}${F('Max LTV % (maal ki keemat ka)', inp('ltv', c.ltv, { type: 'number', step: '1', min: 10 }))}</div><div class="btns" style="margin-top:10px">${canAdmin() ? '<button class="btn primary">Save</button>' : ''}</div></form>
      <p class="small muted" style="margin:12px 0 0">Byaaj: saada byaaj, mool baaki par, din ke hisaab se (30 din = 1 mahina). Chhudate waqt kam se kam itne mahine ka byaaj lagta hai. Maal ki keemat = fine wazan × aaj ka bhav.</p>
      <div class="note small" style="margin-top:10px">⚖ <b>Kanooni dhyan:</b> Rajasthan mein byaaj par paisa dene (girvi) ke liye <b>Rajasthan Money-Lenders Act</b> ke tahat licence / registration aur us kanoon ki byaaj seema laagu hoti hai. Ye kaam shuru karne se pehle CA / vakeel se zaroor poochhiye. Software sirf hisaab rakhta hai.</div></div>`;
  }
  document.addEventListener('submit', async e => {
    const f = e.target; if (!f.matches) return;
    if (f.matches('form[data-sjx="gvcfg"]')) { e.preventDefault(); e.stopPropagation(); const v = formVals(f); const g = { rate: num(v.rate), term: Math.max(1, Math.round(num(v.term))), minMonths: Math.max(0, num(v.minMonths)), ltv: Math.max(10, num(v.ltv)) }; if (await saveSettings({ ...S.settings, pro: { ...((S.settings || {}).pro || {}), girvi: g } })) toast('✓ Niyam save'); return; }
    if (f.matches('form[data-sjx="gv"]')) { e.preventDefault(); e.stopPropagation(); await saveGirvi(f); return; }
    if (f.matches('form[data-sjx="gvpay"]')) { e.preventDefault(); e.stopPropagation(); await saveGPay(f); return; }
  }, true);
  const G_ROWS = 6;
  function gForm(id) {
    const g = id ? (S.girvi || []).find(x => x.id === id) : null; const c = gcfg(); const v = g || { startDate: todayStr(), rate: c.rate, term: c.term, minMonths: c.minMonths, items: [], mode: 'Cash' };
    const custs = S.customers.slice().sort((a, b) => a.name.localeCompare(b.name)).map(x => [x.id, x.name + (x.phone ? ' · ' + x.phone : '')]);
    const row = (it, k) => `<div class="sjx-gv-row"><input name="d${k}" placeholder="Gehna (jaise Kangan jodi)" value="${esc(it.desc || '')}"><select name="m${k}">${opts([['gold', 'Sona'], ['silver', 'Chandi']], it.metal || 'gold')}</select><input name="g${k}" type="number" step="0.001" min="0" inputmode="decimal" placeholder="Gross g" value="${esc(it.gross || '')}"><input name="n${k}" type="number" step="0.001" min="0" inputmode="decimal" placeholder="Net g" value="${esc(it.net || '')}"><input name="t${k}" type="number" step="0.01" min="0" max="100" inputmode="decimal" placeholder="Tunch %" value="${esc(it.tunch || '')}"></div>`;
    const items = (v.items || []).slice(0, G_ROWS); while (items.length < G_ROWS) items.push({});
    openModal(`<form data-sjx="gv" data-id="${esc(id || '')}" novalidate>${mHead(g ? 'Girvi badlo — ' + esc(g.no) : 'Nayi girvi', 'Gehne rakh kar diya paisa · byaaj mahine ke hisaab se')}<div class="m-body">
      <div class="fg">${F('Customer (list se)', `<select name="customerId">${opts(custs, v.customerId || '', '— naya / bina list —')}</select>`)}${F('Naam *', inp('name', v.name || ''))}${F('Phone', inp('phone', v.phone || '', { im: 'tel' }))}${F('Pata', inp('address', v.address || ''))}${F('ID (Aadhaar / PAN / DL)', inp('idNo', v.idNo || ''))}${F('Date *', inp('startDate', v.startDate, { type: 'date', req: 1 }))}</div>
      <h4 style="margin:14px 0 6px">Girvi rakhe gehne</h4><div class="sjx-gv-rows">${items.map(row).join('')}</div>
      <div class="fg" style="margin-top:12px">${F('Diya paisa (mool) ₹ *', inp('principal', v.principal || '', { type: 'number', step: '1', min: 0, im: 'decimal' }))}${F('Byaaj % / mahina', inp('rate', v.rate, { type: 'number', step: '0.01', min: 0 }))}${F('Muddat (mahine)', inp('term', v.term, { type: 'number', step: '1', min: 1 }))}${F('Kam se kam byaaj (mahine)', inp('minMonths', v.minMonths, { type: 'number', step: '0.5', min: 0 }))}${F('Paisa kaise diya', sel('mode', PAY_MODES, v.mode || 'Cash'))}${F('Note', inp('notes', v.notes || ''))}</div>
      <div class="sjx-gv-calc small" style="margin-top:10px"></div></div><div class="m-foot">${g && canAdmin() ? `<button type="button" class="btn danger" data-act="sjx-gv-del" data-id="${g.id}">Delete</button><span style="flex:1"></span>` : ''}<button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`, { wide: true });
    gPreview();
  }
  function gFormItems(v) { const L = []; for (let k = 0; k < G_ROWS; k++) { const gr = num(v['g' + k]), n = num(v['n' + k]) || gr; if (!(gr || n) && !String(v['d' + k] || '').trim()) continue; L.push({ desc: String(v['d' + k] || '').trim() || 'Gehna', metal: v['m' + k] === 'silver' ? 'silver' : 'gold', gross: r3(gr || n), net: r3(n), tunch: num(v['t' + k]) || (v['m' + k] === 'silver' ? 92.5 : 91.6) }); } return L; }
  function gPreview() {
    const f = q$('form[data-sjx="gv"]'); if (!f) return; const v = formVals(f); const g = { items: gFormItems(v), principal: num(v.principal) }; const val = valueOf(g), ltv = val ? g.principal / val * 100 : 0, c = gcfg();
    q$('.sjx-gv-calc', f).innerHTML = g.items.length ? `Fine: <b>${g3(sum(g.items, fineOf))}</b> · aaj ki keemat <b>${inr(val)}</b> · ${c.ltv}% tak: <b>${inr(val * c.ltv / 100)}</b>${g.principal ? ` · LTV <b class="${ltv > c.ltv ? 'red' : 'green'}">${ltv.toFixed(1)}%</b>` : ''} · byaaj har mahine <b>${inr(g.principal * num(v.rate) / 100)}</b>${!num(settings().gold24) ? ' · <span class="red">aaj ka bhav nahi bhara</span>' : ''}` : '<span class="muted">Gehne ka wazan daaliye — keemat aur LTV apne-aap dikhega.</span>';
  }
  document.addEventListener('input', e => { if (e.target.closest && e.target.closest('form[data-sjx="gv"]')) { if (e.target.name === 'customerId') return; gPreview(); } });
  document.addEventListener('change', e => { const f = e.target.closest && e.target.closest('form[data-sjx="gv"]'); if (!f) return; if (e.target.name === 'customerId' && e.target.value) { const c = custById(e.target.value); if (c) { ['name', 'phone', 'address'].forEach(k => { if (!f.elements[k].value) f.elements[k].value = c[k] || ''; }); if (!f.elements.idNo.value) f.elements.idNo.value = c.pan || c.aadhar || ''; } } gPreview(); });
  async function saveGirvi(f) {
    const id = f.dataset.id; const prev = id ? (S.girvi || []).find(x => x.id === id) : null; const v = formVals(f); const items = gFormItems(v);
    if (!String(v.name || '').trim()) return toast('Naam daaliye', 'err'); if (!items.length) return toast('Kam se kam ek gehna daaliye', 'err'); if (!(num(v.principal) > 0)) return toast('Diya paisa daaliye', 'err');
    const val = valueOf({ items }), ltv = val ? num(v.principal) / val * 100 : 0; if (ltv > gcfg().ltv && !f._ltvOk) { f._ltvOk = true; return toast(`Diya paisa maal ki keemat ka ${ltv.toFixed(0)}% hai (seema ${gcfg().ltv}%) — pakka hai to Save dobara dabaiye`, 'err'); }
    const g = { ...(prev || {}), id: prev ? prev.id : uid('gv'), no: prev ? prev.no : nextNo('girvi', 'GV-'), customerId: v.customerId || '', name: v.name.trim(), phone: String(v.phone || '').trim(), address: String(v.address || '').trim(), idNo: String(v.idNo || '').trim().toUpperCase(), startDate: v.startDate || todayStr(), items, principal: r2(num(v.principal)), rate: num(v.rate), term: Math.max(1, Math.round(num(v.term)) || 12), minMonths: Math.max(0, num(v.minMonths)), mode: v.mode || 'Cash', notes: String(v.notes || ''), valueAtStart: prev ? prev.valueAtStart : val, status: prev ? prev.status : 'active', payments: prev ? prev.payments || [] : [], createdAt: prev ? prev.createdAt : Date.now(), updatedAt: Date.now(), by: prev ? prev.by : (me().name || '') };
    if (!await save('girvi', g)) return; closeModal(f.closest('.overlay')); toast('✓ Girvi ' + g.no + ' save'); if (!prev) gPdf(g.id);
  }
  function gPayForm(id, closing) {
    const g = (S.girvi || []).find(x => x.id === id); if (!g) return; const c = gCalc(g);
    openModal(`<form data-sjx="gvpay" data-id="${esc(id)}" data-close="${closing ? 1 : ''}" novalidate>${mHead((closing ? 'Girvi chhudao — ' : 'Byaaj / jama — ') + esc(gName(g)), esc(g.no) + ' · mool baaki ' + inr(c.P) + ' · byaaj baaki ' + inr(c.intDue))}<div class="m-body"><div class="fg">${F('Date', inp('date', todayStr(), { type: 'date' }))}${F('Kul rakam ₹', inp('amount', closing ? c.total : Math.round(c.intDue), { type: 'number', step: '1', min: 0, im: 'decimal' }))}${F('Kaise', sel('mode', PAY_MODES, 'Cash'))}${F('Note', inp('note', ''))}</div>
      <div class="sjx-gv-split small" style="margin-top:8px"></div>${closing ? `<div class="note small" style="margin-top:10px">Chhudane par saare gehne customer ko wapas — ID dekh kar hi dijiye. ${(g.items || []).map(it => esc(it.desc) + ' ' + num(it.net || it.gross).toFixed(3) + 'g').join(' · ')}</div>` : ''}</div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">${closing ? '✓ Chhudao & gehne wapas' : 'Save'}</button></div></form>`, { small: true });
    gSplit();
  }
  function gSplit() { const f = q$('form[data-sjx="gvpay"]'); if (!f) return; const g = (S.girvi || []).find(x => x.id === f.dataset.id); const v = formVals(f); const c = gCalc(g, v.date || todayStr()); const amt = num(v.amount); const i = Math.min(amt, c.intDue), p = Math.max(0, Math.min(c.P, amt - i)); f._split = { i: r2(i), p: r2(p), c };
    q$('.sjx-gv-split', f).innerHTML = `Byaaj mein: <b>${inr2(i)}</b> · mool mein: <b>${inr2(p)}</b>${amt - i - p > 0.5 ? ` · <span class="red">${inr2(amt - i - p)} zyada</span>` : ''} · baad mein baaki: <b>${inr(c.P - p + c.intDue - i)}</b>${f.dataset.close && c.P - p + c.intDue - i > 0.5 ? ' <span class="red">(poora jama nahi — chhudane ke liye kul ' + inr(c.total) + ')</span>' : ''}`; }
  document.addEventListener('input', e => { if (e.target.closest && e.target.closest('form[data-sjx="gvpay"]')) gSplit(); });
  async function saveGPay(f) {
    const g = (S.girvi || []).find(x => x.id === f.dataset.id); if (!g) return; gSplit(); const v = formVals(f); const s = f._split; if (!(num(v.amount) > 0)) return toast('Rakam daaliye', 'err');
    const closing = !!f.dataset.close; if (closing && s.c.P - s.p + s.c.intDue - s.i > 0.5) return toast('Chhudane ke liye poori rakam ' + inr(s.c.total) + ' chahiye', 'err');
    const pay = { id: uid('gp'), date: v.date || todayStr(), amount: r2(num(v.amount)), interest: s.i, principal: s.p, mode: v.mode || 'Cash', note: v.note || '', by: me().name || '' };
    const g2 = { ...g, payments: [...(g.payments || []), pay], updatedAt: Date.now() }; if (closing) { g2.status = 'closed'; g2.closedDate = pay.date; g2.closedBy = me().name || ''; }
    if (!await save('girvi', g2)) return; closeModal(f.closest('.overlay')); toast(closing ? '✓ Girvi chhudayi — gehne wapas' : '✓ Jama save'); if (closing) gPdf(g2.id);
  }
  function gView(id) {
    const g = (S.girvi || []).find(x => x.id === id); if (!g) return; const c = gCalc(g);
    openModal(`${mHead(esc(g.no) + ' — ' + esc(gName(g)), fmtD(g.startDate) + ' · ' + num(g.rate) + '% mahina · ' + num(g.term) + ' mahine' + (g.status === 'closed' ? ' · chhudayi ' + fmtD(g.closedDate) : ''))}<div class="m-body">${kpis([['Diya (mool)', inr(g.principal)], ['Mool baaki', inr(c.P)], ['Byaaj ab tak', inr(c.acc)], ['Byaaj mila', inr(c.paidI)], ['Byaaj baaki', inr(c.intDue)], ['Kul lena', inr(c.total)]])}
      <h4>Gehne</h4>${btable([['Gehna'], ['Dhatu'], ['Gross', 'r'], ['Net', 'r'], ['Tunch', 'r'], ['Fine', 'r']], (g.items || []).map(it => `<tr>${td(esc(it.desc))}${td(it.metal === 'silver' ? 'Chandi' : 'Sona')}${td(g3(it.gross), 1)}${td(g3(it.net), 1)}${td(num(it.tunch) + '%', 1)}${td(g3(fineOf(it)), 1)}</tr>`))}
      <h4>Jama</h4>${(g.payments || []).length ? btable([['Date'], ['Mode'], ['Byaaj', 'r'], ['Mool', 'r'], ['Kul', 'r'], ['Kisne']], g.payments.map(p => `<tr>${td(fmtD(p.date))}${td(esc(p.mode))}${td(inr2(p.interest), 1)}${td(inr2(p.principal), 1)}${td(inr2(p.amount), 1)}${td(esc(p.by || ''))}</tr>`)) : '<p class="small muted">Abhi koi jama nahi.</p>'}
      ${g.idNo || g.address ? `<p class="small muted">${esc([g.address, g.idNo && 'ID ' + g.idNo, g.notes].filter(Boolean).join(' · '))}</p>` : ''}</div><div class="m-foot">${canEdit() && g.status !== 'closed' ? `<button class="btn" data-act="sjx-gv-edit" data-id="${g.id}">${ic('edit', 14)} Badlo</button>` : ''}<button class="btn" data-act="sjx-gv-pdf" data-id="${g.id}">${ic('dl', 14)} Rasid PDF</button><button class="btn primary" data-act="close">Close</button></div>`, { wide: true });
  }
  async function gPdf(id) {
    const g = (S.girvi || []).find(x => x.id === id); if (!g) return; const s = settings(); const c = gCalc(g); const closed = g.status === 'closed';
    const pdf = new Pdf(148, 210); const L = 10, R = 138; let y = 12;
    pdf.fill('#7a5410').font(true, 14).text(s.firm || 'Shivaa Jewels', 74, y, { align: 'center' }); y += 5;
    pdf.fill('#444444').font(false, 7.5).text(String(s.address || ''), 74, y, { align: 'center', maxW: 128 }); y += 3.8; pdf.text([s.phone ? 'Mob ' + s.phone : '', s.gstin ? 'GSTIN ' + s.gstin : ''].filter(Boolean).join('   '), 74, y, { align: 'center' }); y += 5;
    pdf.stroke('#c9a046').lw(0.6).line(L, y, R, y); y += 6;
    pdf.fill('#000000').font(true, 12).text(closed ? 'GIRVI CHHUDANE KI RASID' : 'GIRVI RASID (PLEDGE RECEIPT)', 74, y, { align: 'center' }); y += 7;
    const kv = (k, v2, x2) => { pdf.font(false, 8).fill('#555555').text(k, x2, y); pdf.font(true, 9).fill('#000000').text(String(v2 || '—'), x2 + 26, y, { maxW: 40 }); };
    kv('Girvi no.', g.no, L); kv('Date', fmtD(g.startDate), 76); y += 5.5; kv('Naam', gName(g), L); kv('Phone', gPhone(g), 76); y += 5.5; kv('ID', g.idNo, L); kv('Muddat', num(g.term) + ' mahine', 76); y += 5.5;
    if (g.address) { pdf.font(false, 8).fill('#555555').text('Pata', L, y); pdf.font(false, 8.5).fill('#000000').text(g.address, L + 26, y, { maxW: 100 }); y += 5.5; }
    y += 2; pdf.fill('#f3e7c6').rect(L, y - 4, R - L, 6.5, 'F'); pdf.fill('#000000').font(true, 8);
    const cx = [L + 2, 64, 84, 104, R - 2]; ['Gehna', 'Gross g', 'Net g', 'Tunch', 'Fine g'].forEach((h, i) => pdf.text(h, cx[i], y, { align: i ? 'right' : 'left' })); y += 6;
    pdf.font(false, 8.5); (g.items || []).forEach(it => { pdf.text((it.desc || '') + (it.metal === 'silver' ? ' (chandi)' : ''), cx[0], y, { maxW: 46 }); pdf.text(num(it.gross).toFixed(3), cx[1], y, { align: 'right' }); pdf.text(num(it.net).toFixed(3), cx[2], y, { align: 'right' }); pdf.text(num(it.tunch) + '%', cx[3], y, { align: 'right' }); pdf.text(fineOf(it).toFixed(3), cx[4], y, { align: 'right' }); y += 5; });
    pdf.stroke('#dddddd').lw(0.3).line(L, y - 2.5, R, y - 2.5); y += 3;
    const line = (k, v2, b) => { pdf.font(!!b, b ? 10 : 9).fill('#000000').text(k, L, y); pdf.text(v2, R, y, { align: 'right' }); y += 5.5; };
    line('Diya paisa (mool)', 'Rs ' + fmtAmt(g.principal), true); line('Byaaj', num(g.rate) + '% har mahine (saada, din ke hisaab se; kam se kam ' + num(g.minMonths) + ' mahina)'); line('Gehnon ki keemat (rasid ke din)', 'Rs ' + fmtAmt(g.valueAtStart || c.value));
    if ((g.payments || []).length) { y += 1; pdf.font(true, 9).text('Jama', L, y); y += 5; pdf.font(false, 8.5); g.payments.forEach(p => { pdf.text(fmtD(p.date) + ' · ' + (p.mode || ''), L, y); pdf.text('Byaaj ' + fmtAmt(p.interest) + '  Mool ' + fmtAmt(p.principal) + '  = Rs ' + fmtAmt(p.amount), R, y, { align: 'right' }); y += 4.6; }); y += 1; }
    if (closed) { line('Sab chuka — girvi band (' + fmtD(g.closedDate) + ')', 'Rs 0', true); pdf.font(false, 8.5).text('Upar likhe saare gehne customer ko sahi haalat mein wapas mil gaye.', L, y); y += 6; }
    else { line('Aaj tak baaki (mool + byaaj)', 'Rs ' + fmtAmt(c.total), true); }
    y += 3; pdf.font(true, 8.5).text('Niyam', L, y); y += 4.5; pdf.font(false, 7.8).fill('#333333');
    ['1. Gehne isi rasid aur ID dikhakar hi wapas milenge. Rasid kho jaye to turant dukaan ko bataiye.', `2. Byaaj ${num(g.rate)}% har mahine. Muddat ${num(g.term)} mahine; muddat ke baad likhit notice dekar kanoon ke hisaab se karyavahi ho sakti hai.`, '3. Gehnon ka wazan aur tunch dono pakshon ke saamne liya gaya hai.', '4. Ye rasid computer se bani hai.'].forEach(t2 => { pdf.wrap(t2, R - L).forEach(l => { pdf.text(l, L, y); y += 3.8; }); });
    y = Math.max(y + 14, 186); pdf.stroke('#888888').lw(0.3).line(L, y, L + 45, y).line(R - 45, y, R, y); pdf.fill('#555555').font(false, 8).text('Customer ke hastakshar', L + 22.5, y + 4, { align: 'center' }).text('for ' + (s.firm || ''), R - 22.5, y + 4, { align: 'center' });
    await offerDownload('girvi_' + safeName(g.no + '_' + gName(g)) + '.pdf', pdf.blob());
  }
  ACT['sjx-gv-new'] = () => gForm('');
  ACT['sjx-gv-edit'] = t => { closeModal(t.closest('.overlay')); gForm(t.dataset.id); };
  ACT['sjx-gv-pay'] = t => gPayForm(t.dataset.id, false);
  ACT['sjx-gv-close'] = t => gPayForm(t.dataset.id, true);
  ACT['sjx-gv-view'] = t => gView(t.dataset.id);
  ACT['sjx-gv-pdf'] = t => gPdf(t.dataset.id);
  ACT['sjx-gv-del'] = t => { const id = t.dataset.id; confirmBox('Ye girvi aur uska saara hisaab delete karein? (Trash mein 30 din rahega)', async () => { await removeDoc('girvi', id); document.querySelectorAll('form[data-sjx="gv"]').forEach(f => closeModal(f.closest('.overlay'))); toast('Delete ho gaya'); }, 'Delete'); };
  addCss(`.sjx-gv .card{display:flex;flex-direction:column;gap:10px}.sjx-gv-st{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.sjx-gv-st div{border:1px solid var(--line,#3a2f1a);border-radius:10px;padding:6px 8px}.sjx-gv-st span{display:block;font-size:11px;opacity:.7}.sjx-gv-st small{display:block;font-size:11px}@media(max-width:560px){.sjx-gv-st{grid-template-columns:repeat(2,1fr)}}
    .sjx-gv-row{display:grid;grid-template-columns:2fr 0.9fr 1fr 1fr 0.9fr;gap:6px;margin-bottom:6px}@media(max-width:560px){.sjx-gv-row{grid-template-columns:1fr 1fr 1fr}.sjx-gv-row input:first-child{grid-column:1/-1}}`);
  function girviDashCard() {
    const L = (S.girvi || []).filter(g => g.status !== 'closed').map(g => ({ g, c: gCalc(g) })).filter(x => x.c.over || x.c.unpaidMonths >= 3); if (!L.length) return '';
    return `<div class="card"><div class="card-h"><h3>🔒 Girvi — dhyan dein (${L.length})</h3><button class="link" data-act="sjx-go-girvi">Girvi →</button></div>${L.slice(0, 5).map(({ g, c }) => `<div class="row static"><div><b>${esc(gName(g))}</b> <span class="pill ${c.over ? 'red' : 'overdue'}">${c.over ? 'Muddat paar' : c.unpaidMonths + ' mahine byaaj baaki'}</span><div class="small muted">${esc(g.no)} · mool ${inr(c.P)} · byaaj ${inr(c.intDue)}</div></div></div>`).join('')}</div>`;
  }
  ACT['sjx-go-girvi'] = () => goTo('girvi', { gvTab: 'due' });
  { const V = VIEWDEF.dashboard; if (V && V.body) VIEWDEF.dashboard = { ...V, body() { let x = ''; try { x = portalReqCard() + girviDashCard(); } catch (e) { console.error(e); } return x + V.body.apply(V, arguments); } }; }

  /* ---- AI: knows the new records ---- */
  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    const tool = (name, description, props, fn, label) => ({ name, description, inputSchema: { type: 'object', properties: props, required: [] }, execute: async input => { if (typeof setChatStatus === 'function') setChatStatus(label); return fn(input || {}); } });
    agentTools = function () {
      const L = T0.apply(this, arguments); const add = t => { if (!L.some(x => x.name === t.name)) L.push(t); };
      add(tool('girvi_summary', 'Girvi / gold-loan register (jewellery pledged against money given): pledges with principal left, interest due, total due, over-term flag, item weights. Optional name filter and status (active / closed / all).', { name: { type: 'string' }, status: { type: 'string' } }, a => { const q = String(a.name || '').toLowerCase(); const st = a.status || 'active'; return (S.girvi || []).filter(g => (!q || gName(g).toLowerCase().includes(q)) && (st === 'all' || (st === 'closed') === (g.status === 'closed'))).map(g => { const c = gCalc(g); return { no: g.no, name: gName(g), status: g.status, start: g.startDate, ratePerMonthPct: g.rate, principal: g.principal, principalLeft: c.P, interestDue: c.intDue, totalDue: c.total, overTerm: c.over, monthsRunning: +c.months.toFixed(1), itemsValueToday: c.value, items: gItemsTxt(g) }; }).slice(0, 60); }, 'Girvi dekh raha hoon…'));
      add(tool('privilege_info', 'Shivaa lifetime privilege (20% off making on retail bills for customers who already have a retail bill): is a customer a member, privilege ID, since when, savings given so far.', { name: { type: 'string' } }, a => { const q = String(a.name || '').toLowerCase(); return S.customers.filter(c => !q || String(c.name).toLowerCase().includes(q)).slice(0, 10).map(c => { const p = privOf(c); const used = S.invoices.filter(v => v.partyId === c.id && v.privilege); return { name: c.name, member: !!p, id: p ? p.id : null, since: p ? p.since : null, savedSoFar: r2(sum(used, v => v.privilege.amount)), billsWithDiscount: used.length }; }); }, 'Privilege dekh raha hoon…'));
      add(tool('portal_requests', 'Designs customers asked for from their portal link ("Mujhe ye chahiye"), newest first.', {}, () => (S.portalReqs || []).slice().sort((x, y) => num(y.at) - num(x.at)).slice(0, 30).map(r => ({ name: r.name, phone: r.phone, item: r.label, status: r.status, at: new Date(num(r.at)).toISOString().slice(0, 16) })), 'Portal maang dekh raha hoon…'));
      return L;
    };
    if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { return R0.apply(this, arguments) + `
GIRVI & PRIVILEGE: girvi_summary for "girvi", "gold loan", "kiska byaaj baaki", "kaun si girvi muddat paar" (open screen "girvi"). privilege_info for "privilege", "20% chhoot", "kya ye privilege customer hai". On a retail sale for a privilege customer the bill applies 20% off making automatically — mention it. portal_requests for "portal se kisne kya maanga".`; }; }
  }
  window.SJX_2051 = { gCalc, privOf, makingOf, privilegeId, ewbJson };
})();
