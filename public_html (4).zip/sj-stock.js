/* =====================================================================
   STOCK PRO — jewellery tags, TSC printing, RFID & stock audit
   Vault → "Tags & Print" · "RFID & Audit" · "Stock Insights"
   - 81 × 12 mm tail tags: front = Shivaa INC. logo, back = weights,
     purity, item, HUID + QR (SKU)
   - Print: direct USB (TSPL, Chrome on Android / desktop), Windows TSC
     driver, or PDF
   - UHF RFID: link a tag to a piece, bulk stock audit (missing / extra)
   ===================================================================== */
(() => {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined' || typeof VT === 'undefined') return;

  /* Minimal QR Code encoder (byte mode, ECC level M, versions 1-10). Based on the public QR spec / Nayuki's reference algorithm. */
const QRENC = (() => {
  const ECC_PER_BLOCK = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26];
  const NUM_BLOCKS = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];
  const FORMAT_M = 0;
  const rawModules = v => { let r = (16 * v + 128) * v + 64; if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; } return r; };
  const dataCodewords = v => Math.floor(rawModules(v) / 8) - ECC_PER_BLOCK[v] * NUM_BLOCKS[v];
  const gmul = (x, y) => { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z & 0xFF; };
  function rsDivisor(deg) { const r = new Array(deg).fill(0); r[deg - 1] = 1; let root = 1; for (let i = 0; i < deg; i++) { for (let j = 0; j < r.length; j++) { r[j] = gmul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = gmul(root, 0x02); } return r; }
  function rsRemainder(data, div) { const r = div.map(() => 0); for (const b of data) { const f = b ^ r.shift(); r.push(0); div.forEach((c, i) => { r[i] ^= gmul(c, f); }); } return r; }
  function encode(text) {
    const bytes = Array.from(new TextEncoder().encode(String(text)));
    let ver = 0;
    for (let v = 1; v <= 10; v++) { const ccBits = v <= 9 ? 8 : 16; if (4 + ccBits + bytes.length * 8 <= dataCodewords(v) * 8) { ver = v; break; } }
    if (!ver) throw new Error('QR: text too long');
    const bits = [];
    const put = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
    put(4, 4); put(bytes.length, ver <= 9 ? 8 : 16); bytes.forEach(b => put(b, 8));
    const cap = dataCodewords(ver) * 8;
    put(0, Math.min(4, cap - bits.length));
    put(0, (8 - bits.length % 8) % 8);
    for (let pad = 0xEC; bits.length < cap; pad ^= 0xEC ^ 0x11) put(pad, 8);
    const data = []; for (let i = 0; i < bits.length; i += 8) { let b = 0; for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j]; data.push(b); }
    // ECC + interleave
    const nb = NUM_BLOCKS[ver], el = ECC_PER_BLOCK[ver], raw = Math.floor(rawModules(ver) / 8);
    const nShort = nb - raw % nb, shortLen = Math.floor(raw / nb), div = rsDivisor(el);
    const blocks = []; for (let i = 0, k = 0; i < nb; i++) { const d = data.slice(k, k + shortLen - el + (i < nShort ? 0 : 1)); k += d.length; const e = rsRemainder(d, div); if (i < nShort) d.push(0); blocks.push(d.concat(e)); }
    const cw = []; for (let i = 0; i < blocks[0].length; i++) blocks.forEach((b, j) => { if (i !== shortLen - el || j >= nShort) cw.push(b[i]); });
    // matrix
    const size = ver * 4 + 17;
    const mod = Array.from({ length: size }, () => new Array(size).fill(false));
    const fn = Array.from({ length: size }, () => new Array(size).fill(false));
    const setF = (x, y, d) => { mod[y][x] = d; fn[y][x] = true; };
    for (let i = 0; i < size; i++) { setF(6, i, i % 2 === 0); setF(i, 6, i % 2 === 0); }
    const finder = (cx, cy) => { for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const d = Math.max(Math.abs(dx), Math.abs(dy)), x = cx + dx, y = cy + dy; if (x >= 0 && x < size && y >= 0 && y < size) setF(x, y, d !== 2 && d !== 4); } };
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    const align = []; if (ver > 1) { const n = Math.floor(ver / 7) + 2; const step = Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2; align.push(6); for (let p = size - 7; align.length < n; p -= step) align.splice(1, 0, p); }
    const na = align.length;
    for (let i = 0; i < na; i++) for (let j = 0; j < na; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) setF(align[i] + dx, align[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
    const drawFormat = mask => {
      const d = (FORMAT_M << 3) | mask; let rem = d; for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      const b = ((d << 10) | rem) ^ 0x5412; const g = i => ((b >>> i) & 1) !== 0;
      for (let i = 0; i <= 5; i++) setF(8, i, g(i)); setF(8, 7, g(6)); setF(8, 8, g(7)); setF(7, 8, g(8));
      for (let i = 9; i < 15; i++) setF(14 - i, 8, g(i));
      for (let i = 0; i < 8; i++) setF(size - 1 - i, 8, g(i));
      for (let i = 8; i < 15; i++) setF(8, size - 15 + i, g(i));
      setF(8, size - 8, true);
    };
    drawFormat(0);
    if (ver >= 7) {
      let rem = ver; for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
      const b = (ver << 12) | rem;
      for (let i = 0; i < 18; i++) { const bit = ((b >>> i) & 1) !== 0, a = size - 11 + i % 3, c = Math.floor(i / 3); setF(a, c, bit); setF(c, a, bit); }
    }
    // codewords
    let i = 0;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (let vert = 0; vert < size; vert++) for (let j = 0; j < 2; j++) {
        const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - vert : vert;
        if (!fn[y][x] && i < cw.length * 8) { mod[y][x] = ((cw[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0; i++; }
      }
    }
    const maskFn = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x, y) => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
      (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => x * y % 2 + x * y % 3 === 0,
      (x, y) => (x * y % 2 + x * y % 3) % 2 === 0, (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0];
    const applyMask = m => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && maskFn[m](x, y)) mod[y][x] = !mod[y][x]; };
    const penalty = () => {
      let p = 0, dark = 0;
      for (let y = 0; y < size; y++) { let run = 1; for (let x = 1; x <= size; x++) { if (x < size && mod[y][x] === mod[y][x - 1]) run++; else { if (run >= 5) p += run - 2; run = 1; } } }
      for (let x = 0; x < size; x++) { let run = 1; for (let y = 1; y <= size; y++) { if (y < size && mod[y][x] === mod[y - 1][x]) run++; else { if (run >= 5) p += run - 2; run = 1; } } }
      for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) { const c = mod[y][x]; if (c === mod[y][x + 1] && c === mod[y + 1][x] && c === mod[y + 1][x + 1]) p += 3; }
      const pat = [true, false, true, true, true, false, true];
      const hasFinderLike = (get) => { let n = 0; for (let a = 0; a < size; a++) for (let b = 0; b + 7 <= size; b++) { let ok = true; for (let k = 0; k < 7; k++) if (get(a, b + k) !== pat[k]) { ok = false; break; } if (ok) n++; } return n; };
      p += 40 * (hasFinderLike((y, x) => mod[y][x]) + hasFinderLike((x, y) => mod[y][x]));
      for (const row of mod) for (const c of row) if (c) dark++;
      const total = size * size; p += Math.floor(Math.abs(dark * 20 - total * 10) / total) * 10;
      return p;
    };
    let best = 0, bestP = Infinity;
    for (let m = 0; m < 8; m++) { applyMask(m); drawFormat(m); const pp = penalty(); if (pp < bestP) { bestP = pp; best = m; } applyMask(m); }
    applyMask(best); drawFormat(best);
    return { size, modules: mod, version: ver, mask: best };
  }
  return { encode };
})();

  const TAG_LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAoAAAAESCAAAAABI4DsqAAABCGlDQ1BJQ0MgUHJvZmlsZQAAeJx9kK1Ow1AYhp8DS/gJBMEEAnHExAxkIAhiaogGRwok61DtWVeztc1pCTcADoHFkRnuYLsF3EhIECguYSEBTU4bcmbKq568ecT7fSBeAGotGMW5dp2O7Ho9ufKJQFDEV1lKdQT8vJfu294/XlXW+mGmgDnQ0F2vB6IO1KOSm4aDktuGb/I0B3FmWF+4JyD6QDNa4GCBVaqNfw+0R8NrZXezEcaX58AqsEuGi0PH3F8qyRiOv2H5wXbBI0zvYOfDdo0n2LqFycx29iepr/2iqgFLgwF8PcOmB9uvsH7194iKbbLY5pCQEDEkRHJKjGIfySEtDjj6BabWPz+CHaivAABMH0lEQVR42u1dZ4BURdY9t6p6hpwlI6AiQVSCCiIqyYQRzLvmNXy6ugZcXNOqaw6rrmkVIyq6AiIqiiQBCSqrIqAioAIKCIikIc10Vd3vx+uXuntguntm6B1e/dAZZqb6hVM3nnsvMfbkxTTu5u+44PxnBSFau2PRHg1AKz4dsI0YmH6UkREYdscSe/bxw33bFEPSR+AICxEAK3sZWvgJWQC8KkJCBMDdsSZuFhYAakZIiABY+UtiJAEAY98ICREAK98Fwfw5bAEwuu/pqiAC4G4B4NtaMkBcrQOiMEwEwEpeLEsmJXzhbvUjJEQArHQBSN99IQwAgV4FNpKAEQArfX0YJxBg0R02gkIEwMq+dTsGDIBsg8MiHyQCICo9Cv31d2AwCG334QiAEQArfU3ergCA6KgoERcBsPJ9YPMhLAMA940AGAGw8tdPs2ABkKnTOcJBBMBKNwHxvhbOE+jeIjIBIwBWtgYWPN7JfhC6FpgoChgBEJVMRV38X8fyMzgiysNFAKx8EThjk7QAiOscFUUBIwBW+n3T2241QpdGkQSMAFjpxUgrZzEDgEQ/mAgHEQAr3QcuEk4ejnpEKIgAWPl54MnOrZNt3jkyASMAVroP/Os0R/ESOraMgjC7cak8tdHAQChBRgCovLwF5k9+lwYgZuodgSACYBI6LFQpUNNUPvXjNCpRjcQ8IPKBIwD6upEhiQS4aEvRxrXr1m3evnV7rHr1GrUbNmhUr1rtBgqwnHMbDStXfer4wMTNOgEcQTACIMCwrABsWDDvu6W/rlmT8gs1mu3T7ZgjCwCTEwSZrPhktVMPLPXhdaNEcARAANYqSKz/Zs74eZu07x8lNCUA8LYff5z0SKuTT+yvkEsnF4LARxCWGGAcLuKxCAbYw5sTWSYBLB//8fxFACAEM6deGBGRBnDY9WfKXIQg08b9fyMGQFw49fCoLdGeDkDLElg0+aPJOwCSlsHeZRGIwPDRSBBs0f/m/jkYbka8czolTMB9vy2MQLBHq2DLUuDniSPmbQAEMevEsSASbJkT6pekSehhGEieMu2mu5TN2najd0lqABCmd6GNTMA9F4DMVsFMH/HhakDC2ABXgK0FUNCwQwOzefOPGzSk8fNo0tz3/ct1soSOletmsvtRAyM2/p4LQGsViR/HDf+aIZlNoGeQYWCfzu32a9e+fnUBa9d/8N44LWygok2O+X3UXtkhkPm/Pzl7kanTJYLAHmgDMgGwENg++6UpawBlPWyRYAvU7Xha7/2ahP5m3mPDRdAxUbrX+/WIssrD/d9zjjiV5siPZRSH3vMkIAFsFFa+OWoOoKzVnpsrtEHhMccc2wGAYSICCAxYHPxK2ztFQF/q2OwrRnI26BHbPvT26aGiIMweCEBmlmrZS8+thSDWHiylZluz1ykntgWY2U+6ESBhcEfBLcr4CIyr0SPOyyKEYuTUlQm5b9AfUQxmz1PBliVWPvPyr5Dsm3UkDND5j8d1BaBFGuOOrbzw1YAdCGHbLqiRuQg08tonVMLXbvhDvSgNt6cBkK3EsmHPrUdQnJHUEKdddoyEdRRvWttt1YHrg9crzbNXaJWx/Vl0yOJEHs4MGhPhD3sWH5ANyVW3H37/eim0hyUhWDf403/fPl4aI2RpOQ6hm18avl4aUSI5Y/U/dzHZhGo/JmLj7yk2YELSWCF/+/dzq6CM8S08qdH0gos6gq2UO/ddzn68JCACjfj8uy6ZWoEsRkMYB9A1e0Yu8J4CQHJaQoodzz28EtL3PEDC6PYXXroXDO2K6yfRZf9vgjqYSmZ3oUxbwmyf4l1S+4MiJswepILZCHq/93UrJfkpD5JsWv5z5s17GSN3TS+w4ggEDUTG7EwTGQafuhqYqY+MGqPuOWEYI+X8e0cGlS8gjWl51RUNYEQZFWnbJK9pSYY6lAmTteMDg/nkSAPvMQC0kFv++ehmEjogfdnUvvyvTcoOP0abJL2+vqQgMz9Wxsck2vEStzkoev97CgCNxEe3fgWlTSjwd/ZNXcsOP4BRP+n7+PaCDCXg54sTAJT6yAYRFXBPACATW7nqjhcgrQ5p3y73nJgJ/NIKVp1pHngsJ2g1FlFj1D0DgGSkfPOmXwJ8KkCyqT3k+jrMMjNXWiVhRsYy9IG3eD6wrRnl4fYIALKVq29+BUob33+QBgPvOzjjyg7G9pDbQCisnZEJaOW3C5wgIIgPbhv5IKj6YRhD8p0jXhFCA+xWl5Np8fy4gw1nSoUiFCUBskFmqUTCu24bBMIpHA0HqfIAZCN/v3zwTy7hjwGwZL5g1qVkJWUezV6RpILbZ2oNvOdy/G3saIpMwKqugq2QH92wUEAHS9tMy0fOhpEiGx7AwiRAdsjQF/90SQKAwhzQOUqDVHEJyEYUDTlpYYDvDEi2g2edba1EFgYYYX6SBDwwQ0d2Uoly6+1614qaElVtCWiF/OS6uaHQM0ld/94roSVlI/6sWPRdEHBkC/fJBMYsS953h8JZPikSgFVbAhqx/e/95kr3jRMAwbrf9CutVdm1ubL4aFuQfkW8X7PMnOhv53ppkGa9IvlXlSUgW7n4immB2B8D0uCWO2NaZT3byE4MAVfYw+qWOZLDBCtGuxck9fG1o4LgKgxAK+Tov/waIh5A6ZbPnAyrsh/tsXQ66RCzpX8m9iOLHRN8YdoPEQCrrgrWYsfQM3+VOqAvhdD9pp1scjC8GB9sDYWhud4xmVy/FfO/IevYArbR0VEapMoCkLVafPzDRCakLu2QD/bVknLhtI4Ja2A6tnFmvszkYun2+ujWKqICVlUVbIV65+pVwZIjQOkmT5+eg/oFYOS3X4aDLjwYJoMdJUb7HtEgjqLQVVQCGmH+fsaqkPolqQ//+HSTa9zjwyIZrMo0LY7OSANj7jdeGqR6H4oEYJWUgGzUL5d/lKx+zWWP1NE5fpQ0ryV1LT+paSZsBiveizs+MAlz2D4soorMKigBmdXkPh+FSVPK1npmWB2rch0tM2MBAnXssLgooyi0Kpnkf9e3wERUmCoIQEvisRN/CqtfpQ+YdCXnnHZgjAiKa5bc+5CMAIhFc1y5bNQp0XCaqqiCtdr05xGJqltPUunjXmmak/frQFut/iAgAEGgq1QmGpjxftwLi3fqEgGw6klANurH40dIsiHPk4e839Qoyr2F/rhfg41hyHQ4IyM6NZmxrmEgMYgiKmCVAyBbOaHPZ+HoizSFzz8SszL34gvBwygcFPxbzGbkm3+1wKcC9kMEwKoGQAv56MAVMlQkpEyLcZdqFsjZ4Dc0dW4QxdIecmaGqbRJO5QLwPbdOEqDVDEAGsHXDOGw+ad07xn9taJy6ezxqg4SYZhvq84ZMbH0WC8KTUfXitIgVcwJMXLtxR/KIPMURPrsYXWMKh/vevk7FKrpPPVUKzMqDf32C58KeHoUAqxiEtDIhcd9KEPmnyB743/qlE/lNzM9vZmCBmGtezNLpVmMdANBxG0OidIgVQqArOXH/b9WNjwR2v7zYS4nU8uKFcNDPBh74wEZeTYst09wb1ViYO2IjF+VAMhQw08Mc68gbd0xN5RfsoGGrw2kgaXpNdRk5NlYWrBAJFBnxDFRR4SqBEALuueiYmnCedu9xw8ysrzGS4sNTwdamRLXfa56ZkqU8EEJOUpbcPP+kBECq4IT4oz7EPrq5yjU6pak7jJqP11uSRYrnw4EoUnqxztnaFsKO8b3gQfUtiICYFWRgEZsOP25pI4tQh83aT9TfvgTy58MXKbU112kZaZdKRf5Ds2ZzBERoUoAkAAjlx37Xtj8I2UueKdROTY+Y7p3rZ86k/r4h2zGPWU+iCei0MK2jnzgqiMBtZx33BfKhFGpbxte3ZYf/qz84nXfA5Gm0/BYhghitX28q4EF+jQ2IvJCqkYg2qhpZ68NZ99ImEevN+UrY+7a7jkNwjT8T+PMm2rNn5ewIcngJK9nerT+xwEYj008Z0Mo+wZhzdNXWUHl2Vt1/DjvMwiFbxyYsXZn4UWhwY2OiZhYVUQF69jYwRtEOPzMsZeuipen/LO0daif3JP2yWN15vjbPsG/3RPrRnm4qgHAuHrjnK1J+LP0ysUmVp4vmMVj37gfwlLfeFnm0R1Lny9ynRimgdFwpKoBQB17+YLiMK+TbI2Rf9DlSnSycvGDhERjS6lPfzAr73qCy6QRtkVUkF41AGjUvy+xIhRQE1z45um6fMvsGEO3CJtobGkOf4UyV+8sS972o9A9m0R54LxzQmw2JRpPXEuw8OIZxILla6fkiD+mcIDEqLHvuh6IMG3eqGUyz2EYOXuJe4vMZ9moIj1/FhMpcDYxO/HQTSJYJMlMoJfPzFX+UVL1nNr0V1+/1x/VJhv1KekdJGYjkW3cV0Q+cP4sglVM8ufvN0shSQghhCAhBQkZYwIEEYHI/a/zJYGAt24SQUnCIGGGna9Vrh4m0dYQz+GOHxIsB0KNJ7tsllkxGSa6R0XqfjWKojxI/gjAzQ0Lyf5+y8hNOxV2JAQJEpT4vyCSekUycIR54hqTa/zPipU3LwwoYVEyz9fJDTttyUZ4sdr8vTuXm7hVi5IIf3kj/+zqtneDnwZErDCxCkIrppSSUgohko3/ZKhJ3M9xznXF+fY0U14JABHlOCoWUQIkH9d+CqsUG5up5xw0/wAofePfyoX+IhCMLDpmJgMilyrKAJMr8j/yLARDJQqkJR3fuQTWsrXMbDnxlbXe15bZMltrLZtY0SIKmX+A1H98qDz6jUq+fM6X5DvWaz0IFdbPFoJix0b/WuvUiOqB8wd+JRvItFYwIL5s0E5LgpjBzGALtthycmrfqgEvlIt6I27+/ho/0nP1244HIs0BbzXgbCPZt72U8IGFbTquRRQFzJdl5YLTtkMqMBib4k4shsL/SXwZfmcXfZmkEKU58K1q5cH/YyKWzb1vP3/faSYkTMt32mW9afF0j4nFvbpH7z2P1joAQsEAULFkAHHgvwgm4O4YI8P4E6bxqPIZvEsAecEdG7+hRBoAwtYf005nWcVhxcc/uvlCw6faaEBw3iwjtzNADpte7MRzDP1R7L37wt1fQFTwWvvye6+uuDXqjdkO/lAw4lCjstTwLEaRNx6z3kARBQHzZrEgBoTjaIoyUwMu0TYJf+afx2pZ/le38Q4wACL79AlZ72/lhukelxXHN4qYWHkFQRCkgClzfIxh/u/3ZAVsz7q6/PEHS48skxaAMPdcmv3+lmcs9dmsJ0ZMrPwCoCP7uMwS0IonpoYJ0BBm73+xoPJvtL/kCWEJUOaaW3PoLijofVfoCdO4X8SFzi8/2ALKUcFUxlmBd8skg41izzatiIlDdGsRMUPps59wts/OBxFb3keiERbREc1NBMD8UsEAZSIB6eYNYeoWC3PZCRXgWBoxZZSwgNTHDedgWCjjxuYT1rh+NfO5UR4kzwDIBOHYgKJsEY13khWwbXUnE8q7yJEpfiuIIU2XEYXIZbYXxrkELrJNjqBIAOadChaOBKSyvM3iO5N/j/juvawo9xy/FS99LgyE2futhjlkLhhy7STX75AY0CxKw+XfIgELLgvP09KkGUkCUJoB59uK8IB/vY8AYeuP3j8XB5ssf7rSDWAbDETUFjXPJKAThimjEyLoCYTnTBNX/0eFdPkRT/wsLXG1/xyaG8Oa6C2PzsWNBlbkdPhoZe+ElC0Qbejz6WRD1p6wp/Y0FSEAf/w3GRJ48djc8GfF2unMSHhZx9eLfJA8BKCTCdm1dc6E50uS8rFW3EQV4hrdt0lAmEf/kCO6Lab86ofNT+UoCp2HKrjMToj4ZTQlWYB84sEVEAK0cu4IstLceF2u0lVivB+FbnVk5APnrRMCEruCoMWrm5L5xHQmVYBZT3xHsVT6vAe1yM27Zlr/gesDE/VqEkWh800BW8B1QsQuuQFFbybBgUyj41ARMeiJH8VM/IRhlGuDX4uP1rtnxvIZkQWYl2QEUTYv2NLcRUnj1QhdGleAAJTmnni84Nqx1cshuPgOuVFobtw30sB57AWX4eXM1IqTANibK8QwPSA2aMbjBTkTp6xcMYsTTQElBjaMgoB56IQAQpXJCZH4PJXK1KUiRk6SePCinjC5E2wszfw1UdTOlo6DjSRgPi4hYMC0S1uOl6TKz+YV06yhbk8ujwEPkka6UUthmwyIemLlexiGd6qsN69K+gWyBdUqps6bLZVLgdOaaX5GpF+jSAPnqQp2bEDalRbeakqt3qiAyFA5mLcG4za4eULmM6KWWPmrgi2wa/1kUkZrUHFJ/vaaJxY8AcKdD9y8R1SMlL8q2JZFmFWnZLRJrMvrkqtVASbWkc0jF+R/mIzAINTfKyVli/mcz/c2eaPwmFgnIKIC5i8ZgR2zi3faXEq2S1bBjE/yWq+95V4dcd0Ts/WBI8uxkjIhu2I1G/ROlZKfrSbL+dp35Kc5rt8hcEx29cBsjYmXxLWJYJgHmZAeycQDK9eOoXwt9LaY6hUwE07mLDBkDQmpYgUxJSMHpuIAKFWZirUF92i/KImQz3jqksL8RCBLjPVHd+51JGWcWGGjYL77YdX6LWhyQOcW7mzaaJXnMm4qbtc1IWTqXnojJxOOFz49JE+b/dCKKf5khkPaZnyVVqglY19d6vSrFvUanHlfpIYrJhBNZQzDCL54X05W1HTvEmHy0VI3GLvdj0IPzjhjY8XaPx8x9JutECoWk3b9D42igqaK84LLVPZNtsHdDgApkO7fcGV+dr0V5kPXZyKueWzmxSSf937mNyWIrI7HjaR2f46aelRoZwSSu+bDmLMHaxmOTLCcMkTY/DOOrPjpU7d+QHK/lhleoRWfH7NEkXZH2hBfWRg1Vq0gFSzL3J6NxLD9kljtbMRjf5f5l2ZlnupGoYkxQGSGHsb2IUXKHwIvdPMLORKAFeWEiLLyCoRt+HqdZEvIyruHCMq3cjNBb3qWgak1MMMotBVTZ0njqwTCFQ0iC7BiyzLLZOEI0+O1RKcWCvRZffT8IplfoVpLi79wxTKh+36ZaWAmTATYH4JnG14UhWAq0gsuM7NK6lNecULPHETg633nyKSS9d19X+O3SC8NcgbbTHsELw7ejOQz9o6oDKgI6rGfCy6jj6f0OS9IFmFPxIgv+9yvhab8iUKbD/34Zc2+lM3MzkAENHZ5+QrAiJqYREjlsnNAlbn41YJkcWDl9ltOXKLY5s0I0OXTXLNU8GH7Zyi+mHFAwOeQPKBb+cVg2BpDZKLsctAJ4QzaP4r4uaNrJTfEMqQm9n6eRZ48VsZYbyAhY0AsQweCgPOreaCVuub95SayWJOQslhLSRE9LIWOVba3EzMnv9/aJIUNWcu1l/efJSkvIEj2XffyyKrBGTOxhD34cWuVIBJSmurPH1xeAtCS2jB9aK+uXY669TcRycCEEwI+BKizhm1ZJ1pqXtYHKVOfSUJe9Quztrybl+b5Nd05TwKHm8x3sIafrpW4rwM+Y10OF2WZWfO6f3RIbLvvVDa8hy/N/0I1POZIwAy0lLStJ/7FWpXMHpH2mR7/KpJ5EBScsjXhA7PAScJkURVlrppxXru61Vse9cDMHuU1A0rLH/v//XshpRBS/ThovoiadTEAoZjLUpQUUlGxf/W78QdKsmMMyVXXvTj0HGWxW5nSEqPcKDSZGgOy28N2ee23tSUN9wbKi+5j1OITfoq5c3ELNj77DOVGJS5PWnLOrmwuTghzpj3oBZtTZ13ONomoyYbkgvOP+TAR295tdsV3/2VvOuH+3VhmN2JY73VA173ZsCwvivYPp/wk49Y7rT8iOzPQah03IBPP3d5mq+NxS9C5cL5ZCJGtQes4ITahgjPYhKRp/NyEHoZVMgSFmHbiwKkkeLe5IxbvxKV3gyepLM+CUNYYi/IiQ1vxy0mLZEDpcu3sgjgQSsUkQcYkcU4FEcaSULGYACklE7UVWfDGafndQ+dmSYmyAEhZhw2TmRCUzMf2+fcDqyHDD8FC2PHjT7y+v2QjQLsjCl08AX4Q5tTsr0GU66koOndRYmpxwibsjEz6DzOBybKEWTDrl40birh+84OObJtDe0bLEju+/OzXDZu2UqNWXXs3BVMW0w6YVhy3CP+eekhWuSKnIr34IKB+EdtM3TrNvPyyWOqLIkkQJ01g5vhu8IgNzytwTVCJblvZ5oPDZ+z5oQ7phML/ZupdW8285N7OMW+TGn9YnK0rbQ3z1ze39c2L2teuzupJxfkNxApxO5dk4wXfj2oYhu0HAvWzeVFWM885jdKGZIAj3tzMbEzl+/b3eh6VwlCOl/ICtNa60kJGmu9GyFqRdHym2NHMS29oDEAopaRSioDmX2eFQKuZ511cx91LKgWg+6/WZnNnkwCFp0p5zrv423tQDS9ga2egwfZsAltsDfO4IwEpkucMSwIOfnw9szaVK4Ks7Q6vAklMTSdmrPGeVtxUjlSeEQsbkwIfZCYAreXfbq8LqEB1FcXQq8Rmczm89P8KEDoSVIALswTzdRKD1mcH3rtRDS9hywFAgx3Znm3DxS8fBIhkg4+kAFre9n2lvWX3puZ4rVUJ+8XTnBvNzCVLpk+ePOWr9VwZGtqYogPCcS6JQ7Zl9Mo08wutkewSkcT7ruixvOt7sYm9dtxfPww/ABAyodAzfiILPjVZnsu7UIiXUNQJaFiSwyvnrS8dCMiUykchgXp//LikMsWg5rs9Y0vi+tRDbZh3vH9Jz0YAEOt08cRKuabrkuKsAs9norOs5hVn+vDzn7PCjY4gNVprHS/LY7aa5x3lwy8gT/E0a9860SZjfZg5AO9ANbyCzZ2ARiU5KD3NvOPZrkg9VCAF4LBnVlWaQ2I5fqjnFQkxIeU1a+YXOwOAVEoBwNXFFX04DM8vDB9Oor23ZPDOLPMHbX0zJxDllzjNE+plQ4Jhfr6e/6JCe13NcedtZggqk+UTNPx3FGK4sgzk0hCXJNvCK/4w8ZkZcYRD0MSahJkz576TLzlEwbKsBCbWgi/cSxB2v+7JpRxG/njNeJAAGwAkyD51+B8qurSZ7ywOT5kX5vKaZf9QK8zd9xgvhigNnEpEYjB+j8dghfz5/S9+3lyzy8l9xc6pi1ZsufE5SJe7GQxMEn4Hwwr5zUfzft5W79AzupWeIuFAoItyiFcZAIQNHYCm8RyPeZyZp15SozRNjONfLKoMTRznmz1tJ+nCZEO/hKc1hxKh6pEutmIvStuPlUhSwA2XWVN2ObH1dF9SkUS9165037nA4TvYMD/SOPHjc7fv9G4M/3KoL2xIou1Yr22TwmAu0Vw0tEbix7dwaXuZUr/JUALeggK8jt/bA83iOSs/bZh/vK1TOk0sJAGtb5tb4Q6JtTsOgQRAICK8Z3WS/n2vdoo1VmdJacrGlouLYvj0JBkhcUXZXWDDW04Kqcwj5/NStzeyQJ+44U2nAFJIKWUMj+zMttT8azd/LwGc+wuPVwlwK/yBt/GKw9y9JD4oBVyGd6xLREF442bO+gAb/hsKMALr9gdaxMvlrDOvf/0oFQ7LwAvL1Dx5bBGzqcDom+aZBZ6phMbrwwCK85jqyfqCEEsTqjHlFyQ0/EPdJG4GFXxXZrnh4C+QnLltB2t7QuIYSQyM8+/9PfdEieNs6Xgw/MtBwb3UU8zx4jaJRyJxmeGFHTyASros7TGxhj/t9jyXMFureVLn97JGoOGhKMCbgnO0AQMgY13/j9Mn/amOsSKZNM0kt75/Wo/7fxCSNFdYmcuEEo/KjIH1bdBs0WrkudtFSmpYF6cZ1iSllKTLo/cc461N4RmPigd3LGviisXmM8Z5KTxp6464u9AydfFssPXqpxOmKJOw/NhuLqbS7b/lJ84P7LX3xD9bFgUHes+uSMwe+L30Xg6vS38/4p4+XxlHHDPwzSl/Lsm6OYZDg1mzH9Bal5cO1JZ5+T0dkUYMkhRAw3Mm72A28QoSgR19H5heC7jeluM8QqbaywT6MPmgW149evj0+b9zOahgyzsOC38qkZxeVg1s7LYTfJkl0Xoma8sl/DBiiatvNLNTwuZwfqN/vDThanhlZ9/+kOixmOPMxl7qSdOjP6oTMFAkzk+9TMuGr0csNsxJvcV5UiyGs+LZesE3IIa3sHpfoG15AZCZjWbe+tYpsbQOiQJw+D/XZO+771wDz/BqBQQarQzgx5bw8FiawgOCmhJ+ztbysH0AyI6XzsjoGm0pGlglcxz6lRXX1vC5Qfx1WcZxZi7hf8LNCMumQaNWpQONeyEbDvP3UjhxI8eZ2fAViQ0I9WoGj4rAHWn20vwGZDU86QLwQxQoPJgdadzw9YhhFFbtA+yjyxMIRjPzgiH7pQ0NCgE0vHqGExosXw80zkPdZ0yCTgrKAs3Pp+W3EKrNDj0+a/g2QEoJQLyagY+nS/nXYUnBDIFxpb8vG4Ky5uuD+Gu/1PnDEn4AsbSkHYVbS2EFWFN8mr9XDP22Ordm+LwAgil0nSPSSEC7pT1iaJWoUzB2SUfERIPlVmcFwGsRw2isbAu0K2fn1MaZec3rfaolXOCwrSgA1e8/G8vbIbFcdCB8E/DlQEw1zs8KP/wQAmC97wMos6x5uBOoIVGAx8p4tK21Jn05jOYzk7JwdMiOXRw7a7S2ljnOD/t/K7DPD4mr0Twk5JcE7+b5Ug/Cn4NY7leU+D3Lx0Gknfsi8Hnq8dM8EgqHLHXPiOXfT4LCw5wdAK+Bwtv4pQ3QvvyjIybOzLP+0gSATHYDSQHodO9SZluOEDQ8Gz7I6v7kPBXLzHF+2n28hFC3VIGmIV/Z2PXNyIuyvZ1BjdU7J29LVa2WS7qFASjw4i7elqv3NY/wL1Wg9UIXM5YvTF9CQRCT08psq/k+P5Es0XOt+2uWu6YPJBOqLU3dy+qjIRotcu/AsuY1+4Pab+GsSBFXQ2EMfm4NdKiI8JzRhnntv48AIGU6h6T+JTO4HOvoNF9PPhNroDW+KnvM54wlB4Xbh56d5n94L5fUkjKqYGvt9cBvqW/B8Mo2EKGM6747pyEYw7xo2pxVrHlmLfIvut4X/lvnU0oDYM2f0iJB85tB/HX4xTsD1u6bHoACHdan7GV4YV1gSDDWGOenQWJaNiLQ8JVQGIvlewOdKig2ZzQzT7u8fjpNLCSA/m9sY9amfDzwrQEfGI96PBHND/txJgmc2dZHhECImKftL43cty7RY3vZDrY1fBWo5qLU39Y8t2ZI5cudq3Wrmd85pj5wHfPqtv5RENUneW/dshlQGgCblaQ/mXPrBLDceJ6PP96xd3oASgwwKfejeYoEphodlNdLqgOvZ8MHNPx/UHgPy1oBB1RYcNhqy7zq4Z4AVCpli4ADHl+dIK7mdA2W4zwlJsj5CEKBm+Cwmh8KpLLQ5r35tX2TQOK6IAAN/9l5twRI3F7Gc635ERRQ7TXpADghFGMV1HT1TkPF/NMFALDvMlt8UgB/eNl/w5a9QHSK1OqVftfNBwYMvRoBcWVZt04PwBguTb37OI8Cai8I/sDw6rbAo9mQTSxfDon3hGVUYP9ZkjDc7Mapk89upC1JCmKQDSR9e92hQxcJwSa3DkAEwkdx4TVl67Gf80ls5ANDZaLahiRfOOvkiUV+ZJhwYKASx9K8V5xQNYNMwSllq5GwctFdQnP9Rqm/zigJ9TAmPqeJLa1olY2wT/V8lQrRaGRrumecMl6J3j8u8gtIyFLz9FsQ2qUpK2LLly/wRlYIevloLf3rkU2olBhxq9TaRsYmoE6t4H0SatQHNmY3Q8Cp6PyhBXBwxSbkbZyZF93f0RGDSXazBKr9YWrOxqDl4v28J+M5Zkbzvb4MUriNWff3zxsJCkRhrOE/er6iQM8yKmBtToYk1FqZajHGeZwvrAigGgtLoyFYzfzNCYCUaDSbeXQwaHw+ByOScX4xbbUeKdydNnT3QNABviskrDTfklaaEuGVVLUa55FA3W/CEnBtO+DhbFSw5Usg6UMsaQ505Yom6hnNvHXsoFqJipFkY1D2f7s4N2PQ2Cm+D0zVEzU/mu8Kmt8XsjbLCoMm4D5rfNgY/tKPWyo8UDYXRPObkADh7XQ6a1w4UHwmlxLcjjNvvLs2pJBoOIPN0qbkB5QO2hiqrTF2Xdu0OkthdCoQDH9aEHgCA21IWRpeXIPSxkcLZqWLwkwkEjNsyAb8qTZheHYAvAiSxmNxM6B7BddpMNtEePrOfdJk6UgB6PrEulyqmOJ8VYALfUiJcaTKnUFJ0ne7LeFnAi9P4eTAY9b2VN/uIlW2rjCGl7YgAUjcnU5kBAFIVDg5bcjWaubtwzsBEhKNZ3AxBy5E1PwiBAXLhicVpLEOCAWfp1yy0UXdA+nJ1quSYGVSIuWJvRquT+fU/7AX4abgh2h+BgITsvGCLV8IISdgUVPgEK6MZY1m3vb6KdLRxJScIGl1++Ksc3SWN3Z0mViQuI01szX8d3hjKCT2X8HG8BmBAkmJO33UaDujUPglnYdsLUuexprivpAAFK5PzULEeXIA7gJNitOQvGycmUf2BCSRQvsFXMwvea4QKQxLfrua/5NOAgq0WZUitTTf7N0vCTUhda87kWZSh8DB6U/bYKJma6wXRbR6y0GgfTZm40FaPh9CTsDCpsBhXEnLGGae/5c2abJ0UgANLvkyyArPiAs2maRnaomv2LDVfGuQ/tZwHmvDq5oHXh5hSlADnx4Ul0PLpFbi/BfnBct0aTDNM4Jul6DL2YQzzzrOzNtH9wKkgAJOXcVxu7RRQAFfkIwZY39vlQ6AEr1s8uk1PD0WCEHdk3xPxs6vTmn3upBtOhE4BjEMYnaq8Wzc8DUowN3ZFdTxHyHUJHzXGOjJlbe0ZV793GFIKfICKUCd+UlW+RHDV3noEeiyja01QQObRLVJrDnOH4TwV29DIPP6RShlM7ssTzXOr5MiR+4+k6qHNE8NZriIcB1z3NhEUauTilz9WA+ABAmBGvcajhs+2ad1o+2GZLdF87UBpYoQfyWeLJ+3HhTITvZLUS+a/Um2wb0UHklb0cpbO0Ph+h3MWmvNzPdDUbOVNjsAnguKTcG3jZE+flShmlhPPLdmGghKQJw8vtTc/s6i0H5AS+FG1lbzUH9/ko5XZ/jagBMkcKx/zLU9L5hi7VBcBrWi+et6HsDeS+OE2P8EOyIQJE5YwMysS0ocrMx5YmAdQAgIARz/JVur+VW/AE7IialKc5JMm9YReCj1d/0SBSHqpGR2NA/zcCfCEvCDtArA8OxCEUOfsZuYmbd/eBqETOd9lQ2AZ4MKPsaCvYDeXLnLaGZe+NcmiXxIcleFo0Zvz1ARx/l9z3wjUhNZa58aA0DhDo4zszWdQj7IP7xnZ3hhdQr4wDeV4alqXrG/Z0HFvkpXBHpVSg1AvZvmbXR+unrStV2rAxBSSAJ6jmXWbMzaluTHjW5IUZrmtw7wkjWHnRaIKWF80hVo+1VBIJ38bCo+v6/jfpbCOT18zwc156e/f80PQ8SA/fsPGjygM6AkhmRZF2L5LFDhNMxrBBzFlb6MZl55335pWIOSgF5vZOYRa77aM/cE2my3JfxwQL4qXMzaMmv+snpgAo0gr7CbNf816LCqCbs2Aa3d3Nv9G0LNtSki09qi5m5qBl4dB9DxxEuG/u2ak5oDgJJCKgA9Rxi2JsWW2JykNK3mS9yfSxywMkCYgVrKAQYuszV8bEABn5LCvI0X9/NrkvqVnJU4sQSB9r+nh5XV/LBEQeJoy0Lg5mxrzSyfDqo2DfMaAkfzbljGMG98rluqP0JSAH0mMJf5zixvbB3IA5/BJfxqINgjcUyxMcwc58cCHybQ5GefFrK+hS9MBNoV7dIHttqeDeWhq2VxmtzpHalh3oAJIGOFMQEAjU//aIdjHRue7fEmSFb/LFVoveUeLIluS3mY7+Oi3ebwFWgeHkjBNVuaakze7/61xOCtfE3A9BxQ6sPXPLY9AJKSALR+ibOlFlseDFT/BHMbAH15tyyjmYtH9ZOpkUEhgNPmlDk7Yux4BPK7DxseHSgGlzjwNzYOa2VwiHXey3u/cX42+BO6cpca2MYdmekKtl5pfMYFtTxtKoQQwqk3k6qgsLCwMCFGYi3OeHlJorKVrSnuGRBaf03xgHlZ44TXKtBzLdsPA8HPU8J+qzVrWgW86RdS9/q80CuJO32HtQ8FAHhl6f2uDK9/5fC6BUCsdpcnV2afwrd8GlBjJr6qD/Tn3bSsZuap59dI8kcIEAR1zQouazbiQgpEUD7kKbWCtlGThW7bkzX1A1ERSUNYuwWG8R6hiN3kXdqgcX4QkkCoVg2AxJmpAlAft/Pex9UOOOW6Z2ZvZ79kWvMw70kItN1gkxVw3K+I67yCi3mad9Ux/C1sNWi+IYCo/sVJh9nYTR0TP1cYuJ1LeFhAiTy7k7NvmHnV7LFvz1yeUwLV8ilAzVmqYskIZWirIPr0ufWl//wcbKvAgCWpn3z7tj8VmF2X7LH4fbo3zEOYgv1XnbfFq/oXUK93cBoRMGZtCHADmPsiEaZjmvO5//HC7tNtV32utXrmJmkZVNBzFjEILZMT8kYOn5CoQiNh7j9mZdGmTVt3FG/fYYHCOrX3atGqYaN6Dl3APT0stjxA3pg7eqReqIECk1H3jXe2FKbp2y20RBHcQj+L9km9S5e87P6MuPDBgqRuliyuXug8JKUPe6OaFfg9wBLospNG34KtbNbMbQyeW5NyIvy3LnAc785lDPOaJ/cDZBJhSwJHzuRdBZmsjfM7QQF40JJDQ4r2BVcyxPkSClZA1P6FjTtC4bKgNY/LdqWB4/wKCQIkht4KBSj8M8lrMbymKby8yjHpb8KWxE2IG/B4QAEPSo6Hav5IuVW89WdznDU/5VXBoDAcufSoZYmwukm+gX8n/lRi/+WsOc6X+h5VnXW867qBnOvKBgK1P8OcOsDxvHuX0cxFT3RGcrNLIVH4sN2lP2r4T74KFzj82BCYbvVbmIX6pEn02ZF4zIZXtQgGqOntXXxmnEcqJwN81NYBkIDCm0l/EnBXieou4pJE2yl/GWOTteLvbcn/myVJp8Dw4paOUSfIYaga33UXaL4hVFzAi7ywkqT9f0siemiemrCSJZp+zZo5zse5YBboVZIegNakXVki8QSgzuf4rDYwkHf3snHmDc91THFHJHDa8l0YGpY3Nw5z1IQX9VA415MjmmerQBBG4UYXM9qOCBWHNdxFcjPO71cHAQLNft5SDwQiTA7DxfDHXldKiefKSGx4INDe9fZkkWqLEpKdSIxyeqnxWX6fmJ5JxQUXBcI5r3Nyl5JFTZ2/FKg7k+OJxmLSfTJXVMocneOAOnMU704bMBB4Y1vv8gtGPDE/1LMJhsTYuU+fiJ31ErBywtog7ZPJJjpIQepez7IgdwTmXB3oFG7osOCE6+CMhmPr7pRgqdW7520XFoSCV1rN2QgGuE7oDIBp2w0uP1aagZeXpRcC02//cu9DmJZ/CbcTY8bF/5XGaUnw/BnaCQAt90/NoRycoivmjXItQGkOPys8349F0QWrnb24xltHOGzX9esTdFYGDkz7wJk2/hxLpbxSvGnjbAmpRJhVEzglL3p5G828+eHmSGnmQzcX70yCxAM80nDlpcS+v/hn2QbZBhCosyrRWNTystqgAJ31DbszinmcRxVAAKTwKJthjigMEguZWfN9LqNFiDqLy5Qs1fzPgNBKLh6J89+duyTpE0B1C9/MfD1MFL3CMwBESvcHzeck9hJqNMfZMhv+pp6X1Umu1me3u9grtRvWSVp16zSsfRdn1WByAFD/S8ysAZyWH83k2caZl/2ZkNxRGQN+KL3qwPCalqWUdlHDucECiK1Ng9QUT2fZOD8epC1gr6U70UC2hEdWgwCgcB0X85WQgER3EyZ6LqwtPGg8USYFHKyqEtSxKJwJivN/nNAvFG5O2CSWf67njsUjOTdw0YaX1/OZZceFb8eWuDRJEl54UPM0Ijem2ezXtIAo4efSxZUIf8sOgH2BBnMxozowOE8A6AQGJx2YxE4jhZbjSsWEtmNLqRITckzAjjI8QYT6297i8dr0ySGS4Ik7AYzV/KpK4O8sNtr2hQIkjg9abFbrE3zvoH/Z2D2G34TvSb0WvoY4T0lUaUpcxQnvxfDsAi8Qvu/aILfWz8GQKJwR3kvz84kjLvGQe7DjPMr3QQ5Nj4cSfiYNeZ8K5dDsANgHaPC1skxM+TPHXVoM+OSuJ2xorJCWK0575NpSIoJEb6bvzyTMI4MC02CsmGoDJiDjCDLC+cHqWTCBHxy/M7NF/vMmKyygdN/hzHLtcid+uE/wzFj5+keJGxBo+ESZhucxmachnI5cwh56dsgI02rW4C3CAlD63Cds4rMYK0s8u3X/Rn6gj+XG1936JKlPOyIUTtRq1JXOfCypb/2r8cI4vwTMyfRFRoQ2R9QNjNsxBQWz1pGI272ymwfk2IDTCgln5Y0ETIzA+XC/VDV8S/rKTctrm6a9f4Vrgu6z5eI+IROw8U+e9hkVUuEFP3Lp6t7e4IhniU5r2GieEyMCRKg9heXfWvq22fNlYytp+7FLXSGJkSEXWPOXTZ0Cd4UT/dYecX7MJxNcz/7MBs3P+1lgNTekPOI8riYldPlV/gMyfK1Pcni5jASrLTdUFwp1H9ueHXx6A40W4ONCwtl5BEBHza08O7nvicI1aUOfcR6Rtr+hxAmhAJXhZXVCTbmPtl7+649BhgD6xkt7HHHedDaUw/rfZxEbjvObUAAERgfArvkKJPp0SZxRxmyV4fPdPxLoFrehOrhvEhxohaM2+3CK8xC3TRFheAA0pqQHeWg6J8k7mpDogiXxB+sXZFs+zTMa6KvSABiIA5Ywj9sfEjjm62zfcy9gr28wJUY4N78AyBxn/pdMsuxk8MAGK57Og0rTJgX7r0568uODG0oMSRgu1m5pHyIJPljafKU4/3S4s4dE62+cSPBNiUqUABtQ8zS3EE2g1aqy0YUtr63vz9keGS78+aa1+7GHrgt49Zb/4DGo5PzgBXi2IYlqn9nQXlPrulgeuC10aW6XGIEWq3YZBrSaN1wtUIDaD8azHundE2j8HSbHBP6QbwBka3hy0zCwKMgfDb+4dOZKna+STe/bwoj+MPGUNX8eJAmicE76J2oNf9wGykF3k68SkeAE467QI3axNVu7uQENKd4t4+uJ87Mez5QODTaQ0bxkP1dm7b8s1Msr3sfr7tcswAYzfiWSxBlBMMX5kwYu/o7cGILZjr0Sn68wIL4rPGjmjzpDAX2+yqFPeQ+gyXeYKAXOyzsAso3zvA5hxJBMiegza349XYmilKNSEll9Q9mOWi6BNB4KLggcnD6zpJkfK3AFUYOZCSkZb+mEAdsFi0se8K2pq8pYMWuNPsFP6wbVaZyXtHM/tlWoKNzy7+09qXVC0Nrd3sYbF6W+CDnHsxs4eyl0WxdEjuWf3C42Mfx55xdtreEN10nEUPuhklz6CRwKNP0eHwmBC/IPgGzjvKJnkgykunNTyxoGpWFkuBT8IP5CtWQSR2uvH+RFoSDM0LQyS/OWS+EKolaznd0Nf1vDKfns4wkNw9/X9QJqncrauEzzwhr+X+0Iyqzv93cwI9Dsi9ClGf65jpdxHBLUwON8F+gUHWyTOLOxewudf0naa7ryIjpP7BSA1jCP7wwJ9J/LOaXsugPNFuMjIXBRHgKQWfNvPZOHrB22LXziDC9vnBqFlhhkU6jEM6sFRGXMw5nlkq4hZKbrYGoNf3tEgkytcOB3nv88EkSAwh/dbq9Wa7etEMnCWWW1jzTf7zu0j/t/pfnzNq78a/JZcrp5PryKjmcCBc58gSdM6R0n0evcw1jP/uu8PAydoCKhcTvt4GV4/fVAAeo8ZHNsp9IVaL4EH5LEJXkJQI7zyv3C6FLJlV9x+0ZqFFqi66ZU+tFLQQ0s8Ibrg/CGmkETsPbidD0p+Pn6ieSBwrHr3Gso4TugEmTQEr+vpGd/3VFm+9zabi7Tmfb6yYuQx/ndOi7+WvyXw7aZ8WpMSQSq2Ayvbe1p5nbFgUTnvwtc+dd1VUqi737PnKy+qDS55owFm9QZUqDflxnXLibv1gVo8QM+gMSl+QlA1vxV3VCIRVC9n8O8cz4tRQMTNVqYpkXAX0Odleu5wzoMfxrG7ubkv7VxXndJQv0S4Zyt3i+4XcQVnvDg/FvLBBlHote2sna7MbygtjewY5D7Yq3ll2IuZlrO5RSh/pSXva3l/1TzBPfUKr/FnGG+LVG+otDll+R7LPE6mxAab9+ZXbRpiEQBat5XwnHrriwBeBDQ8ie8D4nL8hSAHA9EVN0xQzZkh6+tl+KDCDEmxYixbE4IuRoHWpuuj7jCqcmt0zXztM4JpqIAbvbtHstbuifKQlwCod+ihkSdb8psIcX5BT9196p1FTzfBTf/1uarNJMXb/Qk3T6/BU7FTe6ZFGqWt1fxZXBzyT1Wp8guw6cnrlvg8J1d6cddQRJHzy0PK78z0Gop3kNl0b+y80TCXb6JagRVZJxfBCVljhUeSBet2dI6WA7id7yI810h/uqfwnlNq7nkzkKPPFz4YgCfhpfVcj4+9olzUZpnFnpFa/9mnUm/ZHf2R41fHHGgedvFcHMWXX9IVC2FAPgHr0Ckmy+HDPf2hGlnp1DOxvnXxPmjGPqvS7kwy/pob6+zSx9etvlvMSiqdtt6U7TNX0XZDVu1nYC9lytGPvABS68ZeWTaumAdh9z29OMc6Pg4EVKH2jJKfcFNRiAlm7l5ZejXjvS/3BAqU6ifNF9Izrl+NoR2iidaDO+vgznC5U6CFtUaJvK5268vdliA0pz+f6asz5WFnp8oSSE+sLFD/5NLL56uDANQusfolk7SNnxTm72vqpPx6kqKlnoGbfvaRgIMNff8b5UGQBQfPLyWTY0b7NjqfdmwtMs0avQDUmjE3vuPDtxabNOQG+OxLEpCLECkbD4DEGT2vvY2EWKbvvuPOi64rFw5BSbsgJjuT1lKlopg+kGHvu3qfxNPiuD4f2lZ7njk/m3SOg9JH/pae6OCaP3KrW9rAAJg1L/+6xYNtXqSqewp+m0/JgAo7MEFVsBIGnXtr1IDEEKf9HrdtPNdfQDWD9za8iIv2d/NqY7Cv24vcvYic8WTsXRk05JtbhtZNCyt3ylDx2SJwJb5YZPHrsuhKEnkNwCZ+LIWwQfGWDEbht1vPl8nOAzYZm/VTnM/jB+CXEDbItAkqyBEeljuD8M1Qn424PZtwjBA0tr/m9jeyJAc/SpRlV6tERNg1cJ7ySSYYM80sxk81s2/eu+/JQxrufnKs36VBgTB+vK369q0PLxt3tdNgg9oC7nU5jaA1XL5oOuKhAEgrHnw2Rinezwl/l6NUOrwNxPfYW3yDD2b2swXZZ0XTEIBBMpfCUim8dmPUqDTstQzj/dFy3gK1xML9eq+RnKabs0/Qhj/9zo05sADDz6TLzbUZwLARsmVT/5rhyP+iEzLx86AlaEx9/xt4quaigFmPSRRDkr6mpMyGITNtMZ6b7MRTEzNuepLAQNipeU9f+O0BHnBxd7dNQzc6W82QcZnNGMbE+9f/bMyDpWr9nPnlkJqK9nqwa5BaQAkNGpfqFOj/sXNs0MQeypYIn8X8UWPGe+REFt8qpWDMBbxzzj4sFiaRwdomfZxrAiN69hfxj0eyX6BE2zFktkDrWAmoba9effyRIWKNHzGo61suJWeFb+4cquBYxAMH+90Axf2kIdsRu9kHTypVcjV1j/18BalAbDUjYYNspRelm4r9p5Lo8Bb3ejWChNXo9jPDzzn0CBJ6g4v9yztWBRv9f6+XmkXqXBKX5WmJkTXTKWDlNUGFIpTTNv8WgKdDp/tjVllML7cUs+VAQuWJhmAl/7FqPSHd31IaXQKDFXqEYsHf/HZE40kYN3LI+ZBWuPUlTe8+0okvzsrlvwWAKCVq28Cs1Pp81w1m5FdEw+MT6QnHlvmuD0kTPeXD9SylPdT7EujIGi0W5LFiG155Mn1zl7C6hOHNdelIcUdW0sWNUClWYEFDcvz1VoA+e6EADDyhNnSBmcFrKrnPB8rFm4NMqeV7vN0+vfO0q73FQtZeYBP2ESrnjN97Wxp6k/7lKz47oNxKyCQEH+m/1MdbIqeYCxxquwI9cHEGLomIS/13d2MzEgXFcIzaye8MQGO3pfWXPJEzVIxE+Ts1gwcqEC8/eWZ8929jLj1LjKq9HiDcc2BgtJFEqcFZibeVgojWnGijjZ//RB0EZqCoZcfO7nqajO50CGG1G2HF6TXfExFG4OWTY3O/gsz8uIZvo3JtPX8fZcv2ACohPFHpuYdN8hUMcQSCwJOqJHjR4gE/k681ojMppy08F/KGxCcAH7hw9fAlq7dlAwA0N9rL89Js8+4MlzqZv8+Fbb0UyGVy+4vrLYzkzz95Wf3Yi0g8l8FQ6B9/d9DV7jRbzvkNVJhkrr5f/YuVfBs3hT8rnXDwKwGPnfYZ74gZcyeDUiwE04hgz6PdOc0MCCy34Id5NbTuqDkZkf6CtvsWZmZBUho1fxXd69EjxwB025YH0M7QXIAgDUCex1Uc5tXXuzIcGF1j5c7armTvaR3gwUFO8dM2vKvrFWwY6/msxMCQot64cYHW332fEcthZRSCsH6qE8OK13xbdvmS0CBdiGJWu2pmibQo1AqScZYgKSw5oA3JndPCwPGjh+RCEnsraqJ2+ZJR2Ty0y0NZRjtrD2IVeICbeKT7dmz+pidYQYx6V1KrUCIqWMPr6Td3UtePbmjVju7KOH5ZIXVShdIJNMukXUcUEhl8zoMA4BsjTrJ8aNEzIzrj718euIfm/3lumqlqhhG8fbg9/sGrWxhur99wVpS7rYmEdEhbdDh+osKStVceotzFYxRvGP66ITFqG8cZGTGrv6QMb8WaAYYRBDaoMNdZ2Gn+xCE9Pqv1gze6z3HbomZ4F6H/2PAzlR5QgImDmVBYakSSyyfUz1VBortnTtakZ0KdmbE5LcNCKB2GEw1PL4v7z9p/sefrypu1LrvgL122r9jx45gvWZ4qJo0x8285W0d6F7KlmFQvetlg+vAiNK2deQiw2LChIQugdLnPJz52xDc9t3zF3k9OKzsev6Fde0uNJMNNNiuHrgbe/jrV6zx96rR7ZJzq9ldaUnlWX6qVBVsxMTLVZo4oL75PiOydkLs/wAAk8ziWgHpGOveHY6kKB0oALCdvVAOLJqHY63StBs1/fUP1sX9pyvr9T7hkO6AlrLUSXyi0JUaksmRf7H4cS9k4xSSPfSTN0Z+syMOqHqdBxzdS2CXYtTLW3NYhwk+tfNr7/xYrIGChl0GHO0+oJ1K0xr13DYzSu0sNy9TJaDMtq6c/yfigABQEr7slkEPgpmlNKn99lMCbT7p1KjQZEsmSIujj9727dxFv220xKJJy7ZtD2gAsBVqJ4+nsPUqEAPETp8fkIz3e6tmNuoIwja+7rpfl20qsU0OqgnAiDKo8RZeUiRcPGP3vfPvy1du1rx3x2oA2zLsVbOBx65WpeMhbkyacCSKs8WfIwEJsvTsX16szWGR3xah4S9glmW4Wx+AXL9h2KsBBIyoceihSSaKkDuZQ0pW9fpU6MSTBBjS6IuerGWyc+mEZbfvKAxEmTZp5nw0cUyGzpMwkG3bZrAXWemdSSlLj0ccfGnNVATKrUdnoUOZjJ+Ky2sJyCJeFHpRbetmHIfi8Amr1zD1bySYLTtq3ICISO5ib8YZTxrfnSapq//jRrDMOtwEZgbcTy7Daur5wyL8NGSmexnR0HVoVKnMKolevUr9URYvlhNkhLy3AVdtDqGtW/Us5b1fklk7fZRVJH6vbJlNaXue/mZBidsDTevDnjzMEuVEvcgsPtU0JSCT7V4BDoxUO8dMztedooLzHIBWeilX57F3hVbIKbBYI1aqnUYZbfTEsk8FQGBrUOeam2uWoaN6ea6WAQlIOQZbm7mUjJ06IVTeqeD/BRWMRYGuVmQKemZ+vYSYj2FGTVhRLkSdRuP++pLjmHfrc/5+O0t1VchqUS1h/ivKOdrfzo0SVNoZsv8bdCxI/jwgAIVp0yMbiV0I65trtVFeMfIGL143c9HG1r3bNy2AJapUqi6hwb7fOrCJydw5R9W3EtgxhisJgPifCMMwbZ0apNxSv2rZ+JmFwgbL0stpCcaBBzpfaiEqOUMJrrPPt8ICxErkvFvzpj+STXhjlXMnjhMi8t0GZExfEZouc1ZW24Q4HqocGdvWGGOszR0DWdTL0L5pvOBsd+sUCAdUngSk/wEAjvJDCSRtx+5ZXC6heo2AnC8ox+tLcCF2jxJxydy5o9/n6MrK0oiWAXIKJSiffeA1U3wSEBNOqqOzudxatVHllsAByjEsinXuAHQpkrqy4OC4v4Lz2wlhfPyLn38kXe3CbOQ1oWbtYLll1QAg4bDGIICxoTj3vQ6q7ZzsrUZw5dmADoeD8vmUPxn0gdH/gKxMZK7VIH1U+n8agFyjJxHA9PvmXA03wR3aQQCMdb+BK1sC5q8NaOidz0IH8o/xeDavSlOzwDEzVUQHWwxOJIM/4xxHHZApOMZJfK74gW0lKTePES3yVwFvuCUgsISpf2isIDsN0zZwrotQVUTgMS1ZAIR3KXdVc4lkgIWeQqLSnBDhOCEiT5USG3nz9xSo2sWWy+75bHNJVvZ6wPLbUlW8ENv4z1YAjI9/FCY3JSxsu4ttDDB4bXvlwCHhBeexCmarXngupIBFfNrtp935czYPqFvgj3bkd+4nE9Rc11vHhJUb7y4HO/6OtvEYsfjxMaErywZEHjshbEi+eKUInGuSFke9NvXe/bJJBu+9t59K31JCXEX84GqjDotb4thrz8kcrUDBLUe2jbOggvsnxmzlecH5KQHZaJKbrrlUB/An2HQaMf28jtWzAQ9XP4KkyxzdshFVRgk3nXxLJ7Zx+3+P5JrAEPaQT67Y25qSLcePrAwl7Ig+ZfIOgIZJksSaKfcsDMo/aQpvuqEuTFZ0DdLq8De9735f15ipqiCw9r1Dl3/65e/rZ/TumasMtC2fXbf0k282rn//4PYV/4ASAMwrL5gZTBLAumnjp/8Yml0tTeuX+kErma2T17fmNoc6YsWmFR2tQBVBINu6Bx2UU4uCwF7cqNGh5bPXrkkmjhOSTx1SrVUEYOXXX38yZyMgOYS/ziM7xpXK/nR3Pmq8O41Xzzm2ighAp4usoyfKIR9N5OxVKYEYB3kqP3LBbCFICKxa/PHMJSsACGFNqHDy4A9a6NxoVDdPYDcO/coNNbQQVUUNlycPsRI5jc6g4HyQgMxWSaD4s5mff7oOgFI7YG24cLfjey2Mys3A6X3uCEenM/143r+bQJOoOnIQ/4t5HEBg91LymWCtJBIl386dNGONBpQwRut6XTZ+TUH/o827e5tcY3d0z/iNjhXI4p3Zt53WMsLA7jb4dzcAmS0JgY2z3/9qXjGAAhgNtDj+mAObBI00YVq81y5n/AnT5oHLpeuHrLnmocP79jqIIxm4+yUg7yYVzEYRsOyTqePXAFAsTAmw74Djjq0JDP7K94CF3evdA03uuQthL1t2H2KGGWAhf/ll5I0PRwDcjQB0JOBuqgmxLEnZxVPfXrAWICHYsEG7o87u2giIxx55x8efNLXf7q5VeaQN7L1dbvzZlb1Ql9wX4W+3Mk28OCBVvs8rgSWjpsyIA5IsKA40Pv34ATUAA469c7vPQRWm1pgjjSqnAo4zj3jxo692gGKq1WHnHRuBYHdLQOmoYKpkjp+QWDz9rU+3AZKdQRNNjh58XD3AEKRWk8/f4XkgwtYZPUCXVxWRMM1vv3ntSl29NRVWr+Q6ymjlQyaELQmJ1RNHfr4OkLBM1qJOzz8e2RawVkrAqM/O2Oq1UpOm9jv9jEJ56UpprWrePHEpMgJBHtiAlamC2SiJHR+Oe3c9oCxbEgY4ZNDgDoCBIAUgHvt80CYPf8I0HHOUVuV4hUIwGKBAN8po7T4bUFYiANlIUvzFmNE/AIJYC6kZbfpf2L0G2LpoMLFJZ25KOCDEStcbc5RRKGcKU6R480QFE1Nl2YDMLBWWjxz3CQBlLJE0Ntb3/GOaAFq4HezYqDEXFbmTF1jqNqO7u2ORohWFYbIfOGgUYduEt97fBhLMGtIwmp32p+6AFuRN4GBSz15tPP2rdPsxnbSKBFbVD8NUrBNiSSh8N+LtRYAgayCEMeh6yamtAOM0SXdknJH25oeE73/oXiNbaBW9qCoehjHgijSL2JLE5jFjxmsIshYkhEZs8B9PImjhWn4EAFqtv2wMMTuTzkiYE4c3NJH+rcoApApXwZalxBcj31wBCLAFSc1231P/1MkTfr6RqBZe+F9nQjgDgs31/yQrI/0bZUJyivmh6MNXpsRBwlhAkNF06OUnNQHbQCtsJsBIenXIukQfSmJp1ON/5irDWo5WOvglyAhcQV4wGyWx8K0RPwDSsgFBahSecd7xQbfXxZ9WG4a+ALcakJXe+6X+Wkb4q+J0LHIZ0aICYjxClUwdNnUDSBoDQLLVLc68ogPYhnUvCEaqT6+cJ2CdYRsE3ffFtiZyP6r4MhVGSGVmiY0j3pwFKMMaIILB/pee2xKWU6ZWsJX2wXu2ueYfkcX191Y3UZ5iD+EDlrcTwmQk4Zu3XlkBkZh5Kq3FEX86uwbSTZ00Un5z7cee+iVh9nriHER52j1jlXMmhIlhpTSfPT1+IwSZRP8tg6OHnKBg0mRfLWT8qbs2SbcERBrTe1hHS5H5tyeoYDcMU26sJGKjJN56YTKgjHX/CQOuGpR++Blbian/mAZv7LnU1W69KRap3z1JBZvyqwK1LFXRu//6AiSsdtlP6DPkeJV2Xh4bJZfeNzweEH/68Md6ROp3D4oDOjUhkson7Cfx+yuvfw0SiZmKggz6DDmpVOmntj370Bqv/YEgU3jjbdW0itRv5IRksbSSy597aQ0kJyrKSRj0vO5sMKdj3hkpzWsPfwfp1p8rjQH3Hbqrwd7RqoqZkHKozzZSrX/uyV8TnocDP9Phr+dWTzdHmmGFNO8+8N8A/Ixu+vfLpRGR+NsDyzJztgGZJV56+HvP8wCkMS1vuKwWTJrps8xC4r0nJ/vNXwRpXPz3NhFJfo8DoMOIztULNpIm3TULkrXfya/hldc1TG/7GUX44OHpEPCFJfr8vS8i8benquDcAMhW/jr0dQgYJGrZpMHFf9sfOo30syxV8fjHp4NEQFfvd9v5wkJ6zMBoYc9JxTEANiaX9mBjr19GZP35G6bV44NRIsimYl5h+39emA0i1/gjNvWv/ksjExdVZnhCtMoGP+NJQFlb5mJ8PfJXSL+ZFUGd/2jd0uaxrRj99A8OM9XFX8vzh9YDZGT97WFLohoIEooBPe47LbLm23/4spfJcEZDn3DqtB1pQ4u8Yv7ElRChSVkHnt5zxrbI+NsDJWDhDKcr0cG5N3YNb0A1dgr8JKzVLIjexR67BO5g9bPMYWSBZYQaOQsCeJtM+o1AVbgXpHb/aWtUH74nAxDAORX9ISlhbqIo2xEtZ73Dalirb5vVyGouCdmCSd8KG/SHT2pmpNP7UgghZaxgy7LFv62PhwGpoev2aFmDo8e/Zy+yJQefgpxGBtlD5gYUMHHNefsGf7zsy68W//BdSVD2EQxkp7NOPTB6/tFKwNBmS0g1ckHvrUEAEx8/sEGDmtW3bNq04ZelS3/anBwwtBboeOyg3hImijhHC0wyFwloxerDVoZiKsQACmPFrs4lgcTsWRKwDLTtc273BoBB5HlEK4AZZJsDvvLZmMs/IAYghbFwWu4yu2O2CCQ0gAaDjz2uDqCjqF+0ygeAzBsueQ/SyaERB9pssPcPJKEByIO7nHRUQ8Ai6koarfICIJjsS//8HkRk02xDAswMqMZdTzzkgBpOh8DoiUer/AAIJmx79e3JiYllYJdjA6JEvrdlz+49etQA3LlEkfMRrXIEINhKmG/emfDDutSf7dWqw+E92uzlToJzCzcjBEar/AAIsFEAFixZsmz97+s3bdu+1dSsUa3+3q1bt+54AAFgLaKRbNEqdf0/num8mpkG44MAAAAASUVORK5CYII=';
  const AUD = 'stockAudits', TST = 'tagState';
  [AUD, TST].forEach(c => {
    if (!COLS.includes(c)) COLS.push(c);
    if (!Array.isArray(S[c])) S[c] = [];
    if (typeof DB !== 'undefined' && DB) { try { DB.collection(c).onSnapshot(snap => { S[c] = snap.docs.map(d => ({ ...d.data(), id: d.id })); scheduleRender(); }); } catch (e) { console.error(e); } }
  });
  if (typeof AUDIT_SKIP !== 'undefined' && AUDIT_SKIP.add) { AUDIT_SKIP.add(TST); AUDIT_SKIP.add(AUD); }

  /* ---------- settings ---------- */
  const TAG_DEF = { dpi: 203, w: 81, h: 12, part: 27, gap: 2, offX: 0, offY: 0, density: 8, speed: 3, invert: false, dir: 1, method: 'auto', logo: '', rfEnc: 'off', rfCmd: '', rfAuto: true,
    lines: { gross: true, less: true, net: true, pkt: true, item: true, huid: true, tray: false, note: true } };
  const MAX_LINES = 6;
  const tagCfg = () => { const t = (S.settings && S.settings.tag) || {}; return { ...TAG_DEF, ...t, lines: { ...TAG_DEF.lines, ...(t.lines || {}) } }; };
  const CAT_CODE = { Rings: 'RING', Bangles: 'BANGLE', Necklaces: 'NECKLACE', Chains: 'CHAIN', Earrings: 'EARRING', Pendants: 'PENDANT', Mangalsutra: 'M.SUTRA',
    Bracelets: 'BRACELET', Kada: 'KADA', 'Payal / Anklets': 'PAYAL', 'Nose Pins': 'NOSE PIN', 'Bridal Sets': 'BRIDAL SET', 'Coins / Biscuits': 'COIN', Others: 'ITEM' };
  const catCode = p => CAT_CODE[p.category] || String(p.category || p.making || 'ITEM').toUpperCase().slice(0, 10);
  const w3 = n => num(n).toFixed(3);
  const tagSig = p => JSON.stringify([p.sku, w3(p.gross), w3(p.less), w3(p.net), p.purity, p.category, num(p.pcs) || 1, p.huid || '', p.tray || '', p.tagNote || '', num(p.pktWt) ? w3(p.pktWt) : '']);
  const tagDoc = () => S[TST].find(x => x.id === 'main') || { id: 'main', printed: {} };
  const printedOf = p => (tagDoc().printed || {})[p.id] || null;
  const tagState = p => { const r = printedOf(p); return !r ? 'new' : r.s === tagSig(p) ? 'ok' : 'changed'; };
  const inStock = () => S.products.filter(p => p.status === 'In Stock');
  const pendingTags = () => inStock().filter(p => tagState(p) !== 'ok');

  /* ---------- tag rendering ---------- */
  const dotsPerMm = dpi => (num(dpi) >= 290 && num(dpi) <= 310 ? 12 : num(dpi) >= 200 && num(dpi) <= 206 ? 8 : num(dpi) / 25.4);   // TSC: 203 dpi = 8 dots/mm, 300 dpi = 12
  function tagLines(p, cfg) {
    const l = cfg.lines, L = [];
    if (l.gross) L.push({ t: 'G  ' + w3(p.gross) + ' g', b: true });
    if (l.less) L.push({ t: 'L  ' + w3(p.less) + ' g', b: false });
    if (l.net) L.push({ t: 'N  ' + w3(p.net) + ' g', b: true });
    if (l.pkt && num(p.pktWt) > 0) L.push({ t: 'PKT ' + w3(p.pktWt) + ' g', b: true });
    if (l.item) L.push({ t: [p.purity, catCode(p)].filter(Boolean).join(' · ') + (num(p.pcs) > 1 ? ' · ' + num(p.pcs) + 'pc' : ''), b: false });
    if (l.huid && p.huid) L.push({ t: 'HUID ' + p.huid, b: false });
    if (l.tray && p.tray) L.push({ t: 'Tray ' + p.tray, b: false });
    if (l.note && p.tagNote) L.push({ t: String(p.tagNote), b: false });
    return L.slice(0, MAX_LINES);
  }
  const loadImg = src => new Promise(res => { if (!src) return res(null); const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = src; });
  let logoCache = { src: null, img: null };
  async function tagLogo(cfg) { const src = cfg.logo || TAG_LOGO; if (logoCache.src !== src) logoCache = { src, img: await loadImg(src) }; return logoCache.img; }
  function threshold(ctx, x0, y0, w, h, th) {
    x0 = Math.max(0, Math.round(x0)); y0 = Math.max(0, Math.round(y0));
    w = Math.min(ctx.canvas.width - x0, Math.round(w)); h = Math.min(ctx.canvas.height - y0, Math.round(h));
    if (w <= 0 || h <= 0) return;
    const im = ctx.getImageData(x0, y0, w, h), d = im.data;
    for (let i = 0; i < d.length; i += 4) { const v = (d[i] * 299 + d[i + 1] * 587 + d[i + 2] * 114) / 1000; const o = v < th ? 0 : 255; d[i] = d[i + 1] = d[i + 2] = o; d[i + 3] = 255; }
    ctx.putImageData(im, x0, y0);
  }
  const FONT = (px, b) => `${b ? 800 : 600} ${px}px Arial, Helvetica, Roboto, "Liberation Sans", sans-serif`;

  async function renderTag(p, cfg) {
    cfg = cfg || tagCfg();
    const dpm = dotsPerMm(cfg.dpi);
    const W = Math.round(cfg.w * dpm), H = Math.round(cfg.h * dpm), part = cfg.part * dpm;
    const ox = cfg.offX * dpm, oy = cfg.offY * dpm;
    const c = document.createElement('canvas'); c.width = W; c.height = H;
    const x = c.getContext('2d');
    x.fillStyle = '#fff'; x.fillRect(0, 0, W, H);
    // front: logo
    const lg = await tagLogo(cfg);
    if (lg) {
      const mw = part - 2.4 * dpm, mh = H - 1.8 * dpm, r = Math.min(mw / lg.width, mh / lg.height);
      const lw = lg.width * r, lh = lg.height * r;
      x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
      x.drawImage(lg, ox + (part - lw) / 2, oy + (H - lh) / 2, lw, lh);
      threshold(x, 0, 0, Math.min(W, ox + part), H, 170);
    }
    // back: QR + lines
    const bx = ox + part, pad = 0.8 * dpm;
    const q = QRENC.encode(String(p.sku || ''));
    const skuH = 1.5 * dpm;
    const mod = Math.max(2, Math.floor((H - 2 * pad - skuH) / q.size));
    const qs = q.size * mod, qx = Math.round(bx + part - pad - qs), qy = Math.round(oy + pad * 0.7);
    x.fillStyle = '#000';
    for (let yy = 0; yy < q.size; yy++) for (let xx = 0; xx < q.size; xx++) if (q.modules[yy][xx]) x.fillRect(qx + xx * mod, qy + yy * mod, mod, mod);
    let fs = 1.35 * dpm; x.font = FONT(fs, true);
    while (x.measureText(p.sku).width > qs + 2 * pad && fs > 0.9 * dpm) { fs -= 0.5; x.font = FONT(fs, true); }
    x.textAlign = 'center'; x.textBaseline = 'alphabetic';
    x.fillText(String(p.sku || ''), qx + qs / 2, Math.min(oy + H - pad * 0.45, qy + qs + fs + 1));
    x.textAlign = 'left';
    const lines = tagLines(p, cfg), n = Math.max(lines.length, 1);
    const top = oy + pad * 0.85, bottom = oy + H - pad * 0.7, lh = (bottom - top) / n;
    const tx = bx + 1.0 * dpm, maxW = qx - tx - 0.7 * dpm;
    lines.forEach((ln, i) => {
      let f = Math.min(lh * 0.88, 2.0 * dpm); x.font = FONT(f, ln.b);
      while (x.measureText(ln.t).width > maxW && f > 6) { f -= 0.5; x.font = FONT(f, ln.b); }
      x.fillText(ln.t, tx, top + lh * i + lh * 0.80);
    });
    threshold(x, bx, 0, part, H, 140);
    return c;
  }

  /* ---------- printing ---------- */
  function toBitmap(c, cfg) {
    const w = c.width, h = c.height, wb = Math.ceil(w / 8);
    const d = c.getContext('2d').getImageData(0, 0, w, h).data;
    const out = new Uint8Array(wb * h);
    for (let y = 0; y < h; y++) for (let xb = 0; xb < wb; xb++) {
      let byte = 0;
      for (let bit = 0; bit < 8; bit++) {
        const xx = xb * 8 + bit; const black = xx < w && d[(y * w + xx) * 4] < 128;
        // TSPL BITMAP: bit 0 = dot printed (black), bit 1 = blank
        if (cfg.invert ? black : !black) byte |= (0x80 >> bit);
      }
      out[y * wb + xb] = byte;
    }
    return { bytes: out, wb, h };
  }
  const enc = s => new TextEncoder().encode(s);
  function concatBytes(parts) { const n = parts.reduce((a, p) => a + p.length, 0); const o = new Uint8Array(n); let k = 0; parts.forEach(p => { o.set(p, k); k += p.length; }); return o; }
  function tsplHeader(cfg) {
    return `SIZE ${cfg.w} mm,${cfg.h} mm\r\nGAP ${num(cfg.gap)} mm,0 mm\r\nDIRECTION ${cfg.dir ? 1 : 0},0\r\nREFERENCE 0,0\r\nOFFSET 0 mm\r\nSET TEAR ON\r\nDENSITY ${Math.round(num(cfg.density))}\r\nSPEED ${num(cfg.speed)}\r\n`;
  }
  function tsplJob(canvases, cfg, copies, epcs) {
    const parts = [enc(tsplHeader(cfg))]; const rf = cfg.rfEnc === 'tspl' && String(cfg.rfCmd || '').includes('{EPC}') && epcs;
    canvases.forEach((c, i) => { const b = toBitmap(c, cfg); const w = rf && epcs[i] ? String(cfg.rfCmd).replace(/\{EPC\}/g, epcs[i]).replace(/\r?\n/g, '\r\n') + '\r\n' : '';
      parts.push(enc(`CLS\r\nBITMAP 0,0,${b.wb},${b.h},0,`), b.bytes, enc(`\r\n${w}PRINT 1,${Math.max(1, copies | 0)}\r\n`)); });
    return concatBytes(parts);
  }
  // ZPL (Zebra-type RFID printers): the tag picture as ^GFA + ^RFW,H writes the EPC into the chip
  function zplJob(canvases, cfg, copies, epcs) {
    const out = []; const dots = mm => Math.round(mm * (num(cfg.dpi) || 203) / 25.4);
    canvases.forEach((c, i) => { const b = toBitmap(c, cfg); let hex = ''; for (let k = 0; k < b.bytes.length; k++) { const v = cfg.invert ? b.bytes[k] : (~b.bytes[k]) & 0xFF; hex += v.toString(16).padStart(2, '0'); }
      out.push(`^XA^PW${dots(cfg.w)}^LL${dots(cfg.h)}^LH0,0^FO0,0^GFA,${b.bytes.length},${b.bytes.length},${b.wb},${hex.toUpperCase()}^FS${epcs && epcs[i] ? `^RFW,H^FD${epcs[i]}^FS` : ''}^PQ${Math.max(1, copies | 0)}^XZ`); });
    return enc(out.join('\r\n'));
  }

  const USB = { dev: null, ep: null };
  const usbOK = () => !!(navigator.usb && window.isSecureContext);
  async function usbOpen(dev) {
    if (!dev.opened) await dev.open();
    if (dev.configuration === null) await dev.selectConfiguration(1);
    for (const itf of dev.configuration.interfaces) for (const alt of itf.alternates) {
      const ep = alt.endpoints.find(e => e.direction === 'out' && e.type === 'bulk');
      if (ep) {
        try { await dev.claimInterface(itf.interfaceNumber); }
        catch (e) { throw new Error('Printer USB se jud nahi paya. Windows par TSC driver printer ko pakde rehta hai — wahan "Windows driver se print" use kijiye. (' + e.message + ')'); }
        if (alt.alternateSetting) { try { await dev.selectAlternateInterface(itf.interfaceNumber, alt.alternateSetting); } catch (e) { /* ignore */ } }
        USB.dev = dev; USB.ep = ep.endpointNumber; return dev;
      }
    }
    throw new Error('Is USB device mein printer port nahi mila');
  }
  async function usbConnect(ask, any) {
    if (!usbOK()) throw new Error('Is browser mein direct USB print nahi chalta. Android par Chrome use kijiye, ya Windows driver se print kijiye.');
    if (USB.dev && USB.dev.opened) return USB.dev;
    const known = await navigator.usb.getDevices();
    let dev = known.find(d => d.vendorId === 0x1203) || (known.length === 1 ? known[0] : null);
    if (!dev && ask) dev = await navigator.usb.requestDevice({ filters: any ? [] : [{ vendorId: 0x1203 }] });
    if (!dev) return null;
    return usbOpen(dev);
  }
  async function usbSend(bytes) {
    if (!USB.dev) await usbConnect(true);
    for (let i = 0; i < bytes.length; i += 16384) {
      const r = await USB.dev.transferOut(USB.ep, bytes.slice(i, i + 16384));
      if (r.status !== 'ok') throw new Error('USB transfer: ' + r.status);
    }
  }
  if (navigator.usb && navigator.usb.addEventListener) navigator.usb.addEventListener('disconnect', ev => { if (ev.device === USB.dev) { USB.dev = null; USB.ep = null; scheduleRender(); } });

  async function driverPrint(canvases, cfg) {
    const imgs = canvases.map(c => c.toDataURL('image/png'));
    const html = `<!doctype html><html><head><meta charset="utf-8"><title>Tags</title><style>@page{size:${cfg.w}mm ${cfg.h}mm;margin:0}html,body{margin:0;padding:0;background:#fff}img{display:block;width:${cfg.w}mm;height:${cfg.h}mm;image-rendering:pixelated;break-after:page;page-break-after:always}img:last-child{break-after:auto;page-break-after:auto}</style></head><body>${imgs.map(s => `<img src="${s}">`).join('')}</body></html>`;
    const f = document.createElement('iframe');
    f.setAttribute('aria-hidden', 'true'); f.style.cssText = 'position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;opacity:0';
    document.body.appendChild(f);
    await new Promise(r => { f.onload = r; f.srcdoc = html; });
    await Promise.all(Array.from(f.contentDocument.images).map(im => im.complete ? 0 : new Promise(r => { im.onload = im.onerror = r; })));
    f.contentWindow.focus(); f.contentWindow.print();
    setTimeout(() => f.remove(), 120000);
  }
  async function pdfTags(products, cfg) {
    const big = { ...cfg, dpi: cfg.dpi * 2 };
    const pdf = new Pdf(cfg.w, cfg.h);
    for (let i = 0; i < products.length; i++) {
      if (i) pdf.addPage();
      const c = await renderTag(products[i], big);
      const im = await loadJpeg(c.toDataURL('image/png'), Math.max(c.width, c.height));
      if (im) pdf.image(im, 0, 0, cfg.w, cfg.h);
    }
    return pdf.blob();
  }

  function methodFor(cfg) {
    if (cfg.method && cfg.method !== 'auto') return cfg.method;
    if (USB.dev) return 'usb';
    return /Android/i.test(navigator.userAgent) && usbOK() ? 'usb' : 'driver';
  }
  async function markPrinted(list) {
    const doc = tagDoc(); const printed = { ...(doc.printed || {}) }; const at = Date.now();
    list.forEach(p => { printed[p.id] = { s: tagSig(p), at }; });
    const live = new Set(S.products.map(p => p.id)); Object.keys(printed).forEach(k => { if (!live.has(k)) delete printed[k]; });
    await save(TST, { ...doc, id: 'main', printed, updatedAt: at });
  }
  async function printTags(list, opts = {}) {
    if (!list.length) return toast('Koi piece select nahi hai', 'err');
    const cfg = tagCfg(); const copies = Math.max(1, Math.min(20, opts.copies | 0 || 1));
    const method = opts.method || methodFor(cfg);
    toast(`${list.length} tag${list.length > 1 ? 's' : ''} ban rahe hain…`);
    try {
      if (method === 'pdf') {
        const all = []; list.forEach(p => { for (let k = 0; k < copies; k++) all.push(p); });
        await offerDownload('tags_' + todayStr() + '.pdf', await pdfTags(all, cfg));
      } else {
        const canvases = []; for (const p of list) canvases.push(await renderTag(p, cfg));
        if (method === 'usb') { const epcs = cfg.rfEnc !== 'off' ? list.map(p => p.rfid ? hexOnly(p.rfid) : skuEpc(p.sku)) : null;
          await usbConnect(true); await usbSend(cfg.rfEnc === 'zpl' ? zplJob(canvases, cfg, copies, epcs) : tsplJob(canvases, cfg, copies, epcs)); toast(`✓ ${list.length * copies} tag printer ko bhej diye${epcs ? ' · RFID chip mein code likha ja raha hai' : ''}`);
          if (epcs && cfg.rfAuto) await rfAutoLink(list, epcs); }
        else { const all = []; canvases.forEach(c => { for (let k = 0; k < copies; k++) all.push(c); }); await driverPrint(all, cfg); }
      }
      if (!opts.noMark) await markPrinted(list);
      return true;
    } catch (e) {
      console.error(e);
      if (e && e.name === 'NotFoundError') toast('Printer select nahi kiya', 'err');
      else toast(e && e.message ? e.message : 'Print nahi hua', 'err');
      return false;
    }
  }
  // after an RFID print: the written EPC is linked to its piece (only if the piece has none and no other piece uses it)
  async function rfAutoLink(list, epcs) {
    const m = lookups(); let n = 0;
    for (let i = 0; i < list.length; i++) { const p = S.products.find(x => x.id === list[i].id); const e = epcs[i]; if (!p || !e || p.rfid) continue; const o = m.rfid.get(e); if (o && o.id !== p.id) continue;
      if (await save('products', { ...p, rfid: e, updatedAt: Date.now() }, { quiet: true })) n++; }
    if (n) toast(`✓ ${n} piece RFID se jud gaye`);
  }
  const SAMPLE = { id: '_sample', sku: 'SJ00012', gross: 5.633, less: 0, net: 5.633, pktWt: 5.910, purity: '22K', category: 'Rings', huid: '29PG4U', pcs: 1, tray: 'A1', tagNote: '' };

  /* ---------- small helpers ---------- */
  const normCode = s => String(s || '').trim().toUpperCase().replace(/^#/, '').replace(/\s+/g, '');
  const hexOnly = s => normCode(s).replace(/[^0-9A-F]/g, '');
  const isEpc = s => { const n = normCode(s); return /^[0-9A-F]{8,}$/.test(n); };
  // EPC from SKU: the SKU's ASCII bytes as hex, zero-padded to 96 bits (24 hex). Readers then give back a code that decodes to the SKU,
  // so a tag written by the printer works even before it is linked by hand.
  function skuEpc(sku) { const t = String(sku || '').trim().toUpperCase(); if (!t || t.length > 12 || /[^\x20-\x7E]/.test(t)) return ''; let h = ''; for (const ch of t) h += ch.charCodeAt(0).toString(16).padStart(2, '0').toUpperCase(); return h.padEnd(24, '0'); }
  function epcSku(hex) { const h = hexOnly(hex); if (h.length < 8 || h.length % 2) return ''; let out = ''; for (let i = 0; i < h.length; i += 2) { const c = parseInt(h.slice(i, i + 2), 16); if (c === 0) { if (/^0*$/.test(h.slice(i))) break; return ''; } if (c < 0x20 || c > 0x7E) return ''; out += String.fromCharCode(c); } return out.length >= 3 ? out : ''; }
  function lookups() {
    const L = S.products;
    if (lookups.src === L) return lookups.m;
    const m = { sku: new Map(), huid: new Map(), rfid: new Map() };
    L.forEach(p => { if (p.sku) m.sku.set(normCode(p.sku), p); if (p.huid) m.huid.set(normCode(p.huid), p); if (p.rfid) m.rfid.set(hexOnly(p.rfid), p); });
    lookups.src = L; lookups.m = m; return m;
  }
  function findByCode(code) {
    const m = lookups(), n = normCode(code), h = hexOnly(n);
    const asEpc = h.length >= 8 && /^[0-9A-F:\-]+$/.test(n) ? m.rfid.get(h) : null;
    const bySkuEpc = !asEpc && h.length >= 8 && h === n ? m.sku.get(normCode(epcSku(h))) : null;
    return asEpc || bySkuEpc || m.sku.get(n) || m.huid.get(n) || null;
  }
  let actx = null;
  function beep(ok) {
    try {
      actx = actx || new (window.AudioContext || window.webkitAudioContext)();
      const o = actx.createOscillator(), g = actx.createGain();
      o.frequency.value = ok ? 1500 : 320; g.gain.value = 0.08; o.connect(g); g.connect(actx.destination);
      o.start(); o.stop(actx.currentTime + (ok ? 0.07 : 0.25));
    } catch (e) { /* no sound */ }
  }
  const css = document.createElement('style');
  css.textContent = `
  .tagprev{background:#fff;border:1px solid var(--line2);border-radius:14px;padding:10px;display:flex;justify-content:center;overflow:auto}
  .tagprev img{width:100%;max-width:810px;height:auto;image-rendering:pixelated;display:block}
  .tq-row{display:grid;grid-template-columns:28px minmax(0,1fr) auto;gap:10px;align-items:center;padding:11px 14px;border-bottom:1px solid var(--line)}
  .tq-row:last-child{border-bottom:0}
  .tq-row input{width:18px;height:18px;accent-color:var(--gold)}
  .scanbox{display:flex;align-items:center;gap:10px;border:2px solid var(--gold);border-radius:18px;padding:4px 14px;background:var(--card2)}
  .scanbox input{border:0!important;box-shadow:none!important;background:transparent!important;font:600 17px 'JetBrains Mono',ui-monospace,monospace!important;padding:12px 0!important}
  .aud-big{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin:12px 0}
  .aud-big div{background:var(--card2);border:1px solid var(--line2);border-radius:16px;padding:12px;text-align:center}
  .aud-big b{display:block;font-size:30px;color:var(--head);font-variant-numeric:tabular-nums;line-height:1.1}
  .aud-big span{font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}
  .aud-big .ok b{color:var(--green)}.aud-big .bad b{color:var(--red)}.aud-big .warn b{color:var(--amber)}
  .rf-last{font-family:'JetBrains Mono',monospace;font-size:12px}
  .pill.rf{background:var(--sky-soft);color:var(--sky);border-color:transparent}
  .pkt-in{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:800;color:var(--muted)}
  .pkt-in input{width:96px;padding:7px 9px!important;border-radius:10px!important;font-weight:700}
  @media(max-width:600px){.tq-row{grid-template-columns:28px minmax(0,1fr)}.tq-row .right{grid-column:2;justify-content:flex-start!important}}
  `;
  document.head.appendChild(css);

  /* ======================= Vault sub-tabs ======================= */
  if (!VT.some(t => t[0] === 'tags')) VT.push(['tags', 'Tags & Print'], ['rfid', 'RFID & Audit'], ['insights', 'Stock Insights']);
  if (!ui.tqView) ui.tqView = 'pending';
  if (!ui.rfMode) ui.rfMode = 'audit';
  const SEL = new Set();

  /* ---------- Tags & Print ---------- */
  function tagsShell() {
    const cfg = tagCfg(); const m = methodFor(cfg);
    const mLabel = { usb: 'Direct USB (TSC)', driver: 'Windows TSC driver', pdf: 'PDF download' }[m];
    return `<div class="card"><div class="card-h"><h3>Tag preview · ${cfg.w} × ${cfg.h} mm</h3><div class="btns">
        <button class="btn sm" data-act="tag-settings">${ic('gear', 14)} Tag settings</button>
        <button class="btn sm" data-act="tag-usb">${USB.dev ? '✓ Printer juda hai' : 'USB printer jodo'}</button>
        <button class="btn sm" data-act="tag-test">Test print</button></div></div>
      <div class="tagprev"><img id="tag-prev" alt="Tag preview"></div>
      <div class="small muted" style="margin-top:8px">Bayein: aage wala hissa (logo) · beech mein: peeche wala hissa (details + QR) · daayein: tail. Print tareeka: <b>${mLabel}</b> · ${cfg.dpi} dpi · gap ${num(cfg.gap)} mm</div></div>
      <div class="toolbar">${searchBox('tags', 'SKU, HUID, category ya QR scan…')}${seg('tqView', [['pending', 'Print baaki'], ['all', 'Sab In Stock'], ['printed', 'Chhap chuke']])}
        <button class="btn sm" data-act="tag-selall">Sab chuno</button><button class="btn sm" data-act="tag-selnone">Hatao</button>
        <label class="small muted" style="display:flex;align-items:center;gap:6px">Copies <input id="tag-copies" type="number" min="1" max="20" value="1" style="width:64px;padding:8px"></label>
        <button class="btn gold" data-act="tag-print">${ic('dl', 16)} Print selected</button>
        <button class="btn sm" data-act="tag-pdf">PDF</button></div><div id="vbody"></div>`;
  }
  function tagsList() {
    const q = norm(ui.q.tags).replace(/^#/, '');
    let L = ui.tqView === 'printed' ? inStock().filter(p => tagState(p) === 'ok') : ui.tqView === 'all' ? inStock() : pendingTags();
    if (q) L = L.filter(p => [p.sku, p.huid, p.category, p.making, p.tray, p.rfid].some(x => norm(x).includes(q)));
    return L.sort((a, b) => String(b.sku).localeCompare(String(a.sku)));
  }
  function tagsBody() {
    if (!S.products.length) return emptyBox('Vault mein abhi koi piece nahi hai. Pehle Stock tab se piece add kijiye.');
    const L = tagsList(); const pend = pendingTags().length;
    const head = `<div class="list-sum"><span>Print baaki <b>${pend}</b></span><span>Selected <b>${[...SEL].filter(id => S.products.some(p => p.id === id)).length}</b></span><span>Dikh rahe <b>${L.length}</b></span></div>`;
    if (!L.length) return head + emptyBox(ui.tqView === 'pending' ? 'Sab tags chhap chuke hain ✓' : 'Koi piece nahi mila.');
    const st = p => { const s = tagState(p); const r = printedOf(p); return s === 'new' ? '<span class="pill gold">Naya — print baaki</span>' : s === 'changed' ? '<span class="pill red">Badla — dobara print</span>' : `<span class="pill green">Chhapa ${fmtD(tsDate(r.at))}</span>`; };
    return head + `<div class="tcard">${L.slice(0, 500).map(p => `<label class="tq-row"><input type="checkbox" data-tsel="${esc(p.id)}"${SEL.has(p.id) ? ' checked' : ''}>
      <div style="min-width:0"><b class="mono">#${esc(p.sku)}</b> ${p.huid ? `<span class="pill mono">${esc(p.huid)}</span>` : ''} ${p.rfid ? '<span class="pill rf">RFID</span>' : ''}
      <div class="small">${esc(p.purity || '')} · ${esc(p.category || '')} · G ${w3(p.gross)} · N ${w3(p.net)}${num(p.pcs) > 1 ? ' · ' + num(p.pcs) + ' pcs' : ''}${p.tray ? ' · Tray ' + esc(p.tray) : ''}</div></div>
      <div class="right" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;justify-content:flex-end"><span class="pkt-in" title="Packet ke saath weight">PKT <input name="pkt_${esc(p.id)}" data-pkt="${esc(p.id)}" type="number" step="0.001" inputmode="decimal" placeholder="g" value="${num(p.pktWt) ? w3(p.pktWt) : ''}"></span>${st(p)}<button type="button" class="btn sm" data-act="tag-one" data-id="${esc(p.id)}">Print</button></div></label>`).join('')}</div>` + (L.length > 500 ? '<p class="small muted">Pehle 500 dikh rahe hain — search se chhota kijiye.</p>' : '');
  }
  let prevTimer = null;
  async function refreshPreview() {
    const img = document.getElementById('tag-prev'); if (!img) return;
    const pick = [...SEL].map(id => S.products.find(p => p.id === id)).find(Boolean) || tagsList()[0] || SAMPLE;
    try { const c = await renderTag(pick, tagCfg()); img.src = c.toDataURL('image/png'); img.title = pick.sku; } catch (e) { console.error(e); }
  }

  /* ---------- tag settings ---------- */
  function openTagSettings() {
    const c = tagCfg();
    const chk = (k, l) => `<label class="chk"><input type="checkbox" name="ln_${k}"${c.lines[k] ? ' checked' : ''}> ${l}</label>`;
    const ov = openModal(`<form data-form="tagcfg" novalidate>${mHead('Tag settings', 'TSC TE244 · 81 × 12 mm tail tag')}<div class="m-body">
      <section class="sec"><h4><span>1</span> Peeche kya chhape (max 6 line)</h4><div class="fg">
        ${chk('gross', 'Gross weight')}${chk('less', 'Less / stone weight')}${chk('net', 'Net weight')}${chk('pkt', 'Packet weight (packet ke saath)')}${chk('item', 'Purity + item (22K · RING)')}${chk('huid', 'HUID')}${chk('tray', 'Tray')}${chk('note', 'Piece ka "Tag note" (jaise MC code)')}
      </div><p class="small muted" style="margin:8px 0 0">QR code mein piece ka SKU hota hai — 2D scanner se scan karte hi piece khul jata hai. SKU QR ke neeche bhi chhapta hai.</p></section>
      <section class="sec"><h4><span>2</span> Aage ka logo</h4>
        <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap"><div style="background:#fff;border-radius:12px;padding:8px;border:1px solid var(--line2)"><img src="${esc(c.logo || TAG_LOGO)}" alt="" style="height:44px;display:block"></div>
        <label class="btn sm file-btn">Doosra logo upload<input type="file" accept="image/*" data-tagfile="logo"></label>${c.logo ? '<button type="button" class="btn sm" data-act="tag-logo-reset">Shivaa INC. logo wapas</button>' : ''}</div>
        <p class="small muted" style="margin:8px 0 0">Logo safed background par kaala hona chahiye. Kaale background wala logo apne aap ulta (invert) ho jayega.</p></section>
      <section class="sec"><h4><span>3</span> Printer</h4><div class="fg">
        ${selFld('Print tareeka', 'method', [['auto', 'Auto (Android = USB, Windows = driver)'], ['usb', 'Direct USB (TSPL)'], ['driver', 'Windows TSC driver'], ['pdf', 'PDF download']], c.method)}
        ${selFld('Printer DPI', 'dpi', [['203', '203 dpi (TE244 / TE200)'], ['300', '300 dpi (TE310)']], String(c.dpi))}
        ${fld('Tag ke beech gap (mm)', 'gap', c.gap, { type: 'number' })}
        ${fld('Darkness (1–15)', 'density', c.density, { type: 'number', step: '1' })}
        ${fld('Speed (1–4)', 'speed', c.speed, { type: 'number', step: '1' })}
        ${fld('Left/right khiskao (mm)', 'offX', c.offX, { type: 'number' })}
        ${fld('Upar/neeche khiskao (mm)', 'offY', c.offY, { type: 'number' })}
        ${selFld('Print direction', 'dir', [['1', 'Normal (DIRECTION 1)'], ['0', 'Ulta (DIRECTION 0)']], String(c.dir ? 1 : 0))}
        <label class="chk"><input type="checkbox" name="invert"${c.invert ? ' checked' : ''}> Print ulta-rang (kaala/safed palat) aa raha hai</label>
      </div><p class="small muted" style="margin:8px 0 0">Pehli baar: “Calibrate” dabaiye (printer gap khud naapega), phir “Test print”. Logo ya details khiske hon to upar ke mm se theek kijiye.</p></section>
      <section class="sec"><h4><span>4</span> RFID printer (chip mein code likhna)</h4><div class="fg">
        ${selFld('RFID encode', 'rfEnc', [['off', 'Band — sirf print (abhi jaisa)'], ['zpl', 'ZPL printer (Zebra / ZPL mode) — ^RFW'], ['tspl', 'TSPL RFID printer — apni command']], c.rfEnc || 'off')}
        <label class="f"><span>TSPL RFID command ({EPC} = code)</span><input name="rfCmd" class="mono" value="${esc(c.rfCmd || '')}" placeholder="printer manual ki RFID write command, {EPC} ke saath"></label>
        <label class="chk"><input type="checkbox" name="rfAuto"${c.rfAuto !== false ? ' checked' : ''}> Print ke baad RFID code piece se apne aap jodo</label>
      </div><p class="small muted" style="margin:8px 0 0">Code = piece ka SKU (jaise SJ00012 → <span class="mono">${esc(skuEpc('SJ00012'))}</span>). Reader yeh code padhte hi piece pehchan leta hai — haath se jodne ki zaroorat nahi. Sirf “Direct USB” print mein chalta hai. TSPL RFID printer ki command model ke hisaab se alag hoti hai — printer ke manual/dealer se lekar daaliye, phir 1 tag par test kijiye.</p></section>
      </div><div class="m-foot"><button type="button" class="btn" data-act="tag-calib">Calibrate (USB)</button><button type="button" class="btn" data-act="close">Cancel</button><button type="submit" class="btn gold">Save</button></div></form>`);
    ov._logo = c.logo;
    return ov;
  }
  async function submitTagCfg(form) {
    const ov = form.closest('.overlay'); const d = formObj(form);
    const lines = {}; Object.keys(TAG_DEF.lines).forEach(k => { lines[k] = !!d['ln_' + k]; });
    const n = Object.values(lines).filter(Boolean).length;
    const t = { ...tagCfg(), lines, method: d.method, dpi: num(d.dpi) || 203, gap: Math.max(0, num(d.gap)), density: Math.min(15, Math.max(1, Math.round(num(d.density) || 8))), speed: Math.min(6, Math.max(1, num(d.speed) || 3)),
      offX: num(d.offX), offY: num(d.offY), dir: d.dir === '0' ? 0 : 1, invert: !!d.invert, logo: ov._logo || '', rfEnc: ['zpl', 'tspl'].includes(d.rfEnc) ? d.rfEnc : 'off', rfCmd: String(d.rfCmd || '').trim(), rfAuto: !!d.rfAuto };
    if (settingsGuard()) return;
    if (await saveSettings({ ...S.settings, tag: t })) { closeModal(ov); toast('Tag settings saved' + (n > MAX_LINES ? ' — sirf pehli ' + MAX_LINES + ' line chhapengi' : '')); renderView(true); }
  }
  async function readLogo(file) {
    const src = await shrinkImage(file, 700, 'image/png');
    const im = await loadImg(src); const c = document.createElement('canvas'); c.width = im.width; c.height = im.height;
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(im, 0, 0);
    const d = x.getImageData(0, 0, c.width, c.height); let sum = 0;
    for (let i = 0; i < d.data.length; i += 4) sum += d.data[i];
    if (sum / (d.data.length / 4) < 128) { for (let i = 0; i < d.data.length; i += 4) { d.data[i] = 255 - d.data[i]; d.data[i + 1] = 255 - d.data[i + 1]; d.data[i + 2] = 255 - d.data[i + 2]; } x.putImageData(d, 0, 0); }
    return c.toDataURL('image/png');
  }

  /* ---------- RFID & Audit ---------- */
  const LINK = { pid: '', epc: '', log: [] };
  let AUDIT = null;
  try { const a = JSON.parse(localStorage.getItem('sj-audit-draft') || 'null'); if (a && a.expected) AUDIT = { ...a, found: new Set(a.found), wrong: new Map(a.wrong), unknown: new Map(a.unknown) }; } catch (e) { AUDIT = null; }
  function saveDraft() {
    try {
      if (!AUDIT) return localStorage.removeItem('sj-audit-draft');
      localStorage.setItem('sj-audit-draft', JSON.stringify({ ...AUDIT, _set: undefined, found: [...AUDIT.found], wrong: [...AUDIT.wrong], unknown: [...AUDIT.unknown] }));
    } catch (e) { /* storage full */ }
  }
  const trays = () => [...new Set(inStock().map(p => p.tray).filter(Boolean))].sort();
  const cats = () => [...new Set(inStock().map(p => p.category).filter(Boolean))].sort();

  function rfidKpis() {
    const L = inStock(); const linked = L.filter(p => p.rfid).length;
    const last = S[AUD].slice().sort((a, b) => num(b.finishedAt) - num(a.finishedAt))[0];
    return `<div class="kpis">${kpi('In stock', L.length, sum(L, p => p.net).toFixed(3) + ' g net')}${kpi('RFID jude', linked, L.length ? Math.round(100 * linked / L.length) + '% pieces' : '—')}${kpi('RFID baaki', L.length - linked, 'Inhe tag lagakar jodiye')}${kpi('Last audit', last ? fmtD(tsDate(last.finishedAt)) : '—', last ? `${last.found}/${last.expected} mile · ${(last.missing || []).length} missing` : 'Abhi tak nahi hua')}</div>`;
  }
  function rfidShell() {
    const modes = seg('rfMode', [['audit', '📋 Stock audit'], ['link', '🔗 RFID jodo'], ['history', '🕘 Audit history']]);
    let panel = '';
    if (ui.rfMode === 'link') {
      panel = `<div class="card"><h3>RFID tag ko piece se jodo</h3><p class="small muted" style="margin:0 0 10px">1) Piece ka QR scan kijiye (ya SKU likhiye) · 2) Us piece ka RFID tag reader se padhaiye. Ulta kram bhi chalega. Juda hua tag “RFID” badge ke saath dikhega.</p>
        <div class="scanbox">${ic('hash', 20)}<input id="rf-in" name="rfscan" autocomplete="off" autocapitalize="characters" placeholder="Yahan scan kijiye…"></div>
        <div id="rf-state" class="small" style="margin-top:10px"></div></div>`;
    } else if (ui.rfMode === 'audit') {
      panel = AUDIT
        ? `<div class="card"><div class="card-h"><h3>Audit chal raha hai · ${esc(AUDIT.label)}</h3><div class="btns"><label class="btn sm file-btn">EPC file import<input type="file" accept=".txt,.csv,text/plain,text/csv" data-tagfile="epc"></label><button class="btn sm danger" data-act="aud-cancel">Cancel</button><button class="btn sm gold" data-act="aud-finish">✓ Finish & save</button></div></div>
           <p class="small muted" style="margin:0 0 10px">RFID reader ka trigger dabakar tray/counter par ghumaiye — har tag apne aap gin liya jayega. QR scanner se bhi scan kar sakte hain.</p>
           <div class="scanbox">${ic('hash', 20)}<input id="aud-in" name="audscan" autocomplete="off" autocapitalize="characters" placeholder="Reader/scanner yahan type karega…"></div></div>`
        : `<div class="card"><h3>Naya stock audit</h3><p class="small muted" style="margin:0 0 10px">Kaunsa maal ginna hai chuniye, phir RFID reader se sab tags padhaiye. Jo piece nahi mila wo “Missing” mein dikhega.</p>
           <div class="fg"><label class="f"><span>Kya ginna hai</span><select id="aud-scope">${opts([['all', 'Poora In-Stock maal'], ...trays().map(t => ['tray:' + t, 'Tray ' + t]), ...cats().map(c => ['cat:' + c, c])], 'all')}</select></label></div>
           <div class="btns" style="margin-top:12px"><button class="btn gold" data-act="aud-start">▶ Audit shuru karo</button></div></div>`;
    }
    return `<div style="margin-bottom:12px">${modes}</div>` + panel + '<div id="vbody"></div>';
  }
  function linkStateHTML() {
    const p = LINK.pid && S.products.find(x => x.id === LINK.pid);
    const cur = p ? `Piece: <b class="mono">#${esc(p.sku)}</b> · ${esc(p.category || '')} ${esc(p.purity || '')} · N ${w3(p.net)}${p.rfid ? ` · abhi juda: <span class="mono">${esc(p.rfid)}</span>` : ''}` : 'Piece: —';
    const tag = LINK.epc ? `RFID: <b class="mono">${esc(LINK.epc)}</b>` : 'RFID: —';
    return `<div>${cur}</div><div style="margin-top:4px">${tag}</div>${!p && !LINK.epc ? '<div class="muted" style="margin-top:4px">Pehle QR ya RFID scan kijiye</div>' : !p ? '<div class="gold-t" style="margin-top:4px">Ab piece ka QR scan kijiye</div>' : !LINK.epc ? '<div class="gold-t" style="margin-top:4px">Ab RFID tag padhaiye</div>' : ''}`;
  }
  function rfidBody() { return rfidKpis() + rfidBody2(); }
  function rfidBody2() {
    if (ui.rfMode === 'link') {
      const left = inStock().filter(p => !p.rfid);
      return `<div class="two"><div class="card"><h3>Abhi jode (${LINK.log.length})</h3>${LINK.log.length ? LINK.log.slice(0, 30).map(l => `<div class="sp-row"><div><b class="mono">#${esc(l.sku)}</b><div class="rf-last muted">${esc(l.epc)}</div></div><span class="small muted">${esc(l.t)}</span></div>`).join('') : '<p class="small muted" style="margin:0">Abhi koi nahi</p>'}</div>
        <div class="card"><h3>RFID baaki (${left.length})</h3>${left.slice(0, 60).map(p => `<div class="sp-row"><div><b class="mono">#${esc(p.sku)}</b> <span class="small muted">${esc(p.category || '')} · ${esc(p.purity || '')} · N ${w3(p.net)}${p.tray ? ' · ' + esc(p.tray) : ''}</span></div><button class="btn sm" data-act="rf-pick" data-id="${esc(p.id)}">Chuno</button></div>`).join('') || '<p class="small muted" style="margin:0">Sab In-Stock pieces jude hue hain ✓</p>'}</div></div>`;
    }
    if (ui.rfMode === 'history') {
      const A = S[AUD].slice().sort((a, b) => num(b.finishedAt) - num(a.finishedAt));
      if (!A.length) return emptyBox('Abhi tak koi audit save nahi hua.');
      return `<div class="tcard">${A.map(a => `<div class="row" data-act="aud-view" data-id="${esc(a.id)}"><div><b class="mono">${esc(a.no)}</b> · ${esc(a.label || '')}<div class="small muted">${fmtD(tsDate(a.finishedAt))} · ${num(a.reads)} reads</div></div><div class="right"><b>${num(a.found)}/${num(a.expected)}</b><div class="small ${(a.missing || []).length ? 'red' : 'green'}">${(a.missing || []).length} missing${(a.wrong || []).length ? ' · ' + a.wrong.length + ' galat' : ''}</div></div></div>`).join('')}</div>`;
    }
    if (!AUDIT) return '';
    const exp = AUDIT.expected.length, f = AUDIT.found.size;
    const missing = AUDIT.expected.filter(id => !AUDIT.found.has(id)).map(id => S.products.find(p => p.id === id)).filter(Boolean);
    const wrong = [...AUDIT.wrong.keys()].map(id => S.products.find(p => p.id === id)).filter(Boolean);
    const unk = [...AUDIT.unknown.entries()];
    const pct = exp ? Math.round(100 * f / exp) : 0;
    const row = (p, rf) => `<div class="sp-row"><div><b class="mono">#${esc(p.sku)}</b> <span class="small muted">${esc(p.category || '')} · ${esc(p.purity || '')} · N ${w3(p.net)}${p.tray ? ' · Tray ' + esc(p.tray) : ''}${rf && !p.rfid ? ' · <span class="red">RFID nahi juda</span>' : ''}</span></div><span class="small">${esc(p.status)}</span></div>`;
    return `<div class="aud-big"><div class="ok"><b>${f}</b><span>Mile</span></div><div class="bad"><b>${exp - f}</b><span>Missing</span></div><div class="warn"><b>${wrong.length}</b><span>Galat jagah / sold</span></div><div><b>${unk.length}</b><span>Anjaan tags</span></div><div><b>${AUDIT.reads}</b><span>Total reads</span></div></div>
      <div class="progress"><i style="width:${pct}%"></i></div><div class="small muted" style="margin-bottom:12px">${pct}% maal mil gaya · shuru ${new Date(AUDIT.startedAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</div>
      <div class="two"><div class="card"><h3>Missing (${missing.length})</h3>${missing.slice(0, 200).map(p => row(p, true)).join('') || '<p class="small green" style="margin:0">Sab mil gaye ✓</p>'}</div>
      <div class="card"><h3>Galat jagah / sold mile (${wrong.length})</h3>${wrong.slice(0, 100).map(p => row(p, false)).join('') || '<p class="small muted" style="margin:0">Koi nahi</p>'}
        <h3 style="margin-top:16px">Anjaan tags (${unk.length})</h3>${unk.slice(0, 60).map(([c, n]) => `<div class="sp-row"><span class="rf-last">${esc(c)}</span><span class="small muted">${n}×</span></div>`).join('') || '<p class="small muted" style="margin:0">Koi nahi</p>'}</div></div>`;
  }

  function linkProcess(code) {
    const n = normCode(code); if (!n) return;
    const m = lookups();
    const bySku = m.sku.get(n) || m.huid.get(n);
    if (bySku) { LINK.pid = bySku.id; }
    else if (isEpc(n)) {
      const owner = m.rfid.get(hexOnly(n));
      if (owner && owner.id !== LINK.pid) { beep(false); toast(`Ye RFID pehle se #${owner.sku} se juda hai`, 'err'); LINK.epc = ''; refreshLink(); return; }
      LINK.epc = hexOnly(n);
    } else { beep(false); toast('Ye code kisi piece ka nahi hai: ' + n, 'err'); return; }
    if (LINK.pid && LINK.epc) doLink();
    refreshLink();
  }
  async function doLink() {
    const p = S.products.find(x => x.id === LINK.pid); const epc = LINK.epc;
    if (!p) return;
    if (await save('products', { ...p, rfid: epc, updatedAt: Date.now() })) {
      beep(true); LINK.log.unshift({ sku: p.sku, epc, t: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) });
      toast(`✓ #${p.sku} se RFID jud gaya`);
      LINK.pid = ''; LINK.epc = '';
    }
    refreshLink(); scheduleRender();
  }
  function refreshLink() { const el = document.getElementById('rf-state'); if (el) el.innerHTML = linkStateHTML(); }

  function startAudit(scope) {
    let L = inStock(), label = 'Poora In-Stock maal';
    if (scope.startsWith('tray:')) { const t = scope.slice(5); L = L.filter(p => p.tray === t); label = 'Tray ' + t; }
    if (scope.startsWith('cat:')) { const c = scope.slice(4); L = L.filter(p => p.category === c); label = c; }
    if (!L.length) return toast('Is hisse mein koi In-Stock piece nahi', 'err');
    AUDIT = { scope, label, startedAt: Date.now(), expected: L.map(p => p.id), found: new Set(), wrong: new Map(), unknown: new Map(), reads: 0 };
    saveDraft(); renderView(true); focusScan();
  }
  let audRender = null;
  function auditRead(code) {
    if (!AUDIT) return;
    const n = normCode(code); if (!n || n.length < 3) return;
    AUDIT.reads++;
    const p = findByCode(n);
    if (!p) AUDIT.unknown.set(n, (AUDIT.unknown.get(n) || 0) + 1);
    else if ((AUDIT._set || (AUDIT._set = new Set(AUDIT.expected))).has(p.id)) AUDIT.found.add(p.id);
    else if (!AUDIT.wrong.has(p.id)) { AUDIT.wrong.set(p.id, p.status); beep(false); }
    if (!audRender) audRender = setTimeout(() => { audRender = null; saveDraft(); scheduleRender(); }, 250);
  }
  async function finishAudit() {
    if (!AUDIT) return;
    const prod = id => S.products.find(p => p.id === id) || {};
    const missing = AUDIT.expected.filter(id => !AUDIT.found.has(id)).map(id => { const p = prod(id); return { id, sku: p.sku || '', category: p.category || '', net: num(p.net), tray: p.tray || '' }; });
    const doc = { id: uid('aud'), no: nextNo(AUD, 'AUD-'), label: AUDIT.label, scope: AUDIT.scope, startedAt: AUDIT.startedAt, finishedAt: Date.now(), date: todayStr(),
      expected: AUDIT.expected.length, found: AUDIT.found.size, reads: AUDIT.reads, missing: missing.slice(0, 3000),
      wrong: [...AUDIT.wrong].map(([id, st]) => ({ id, sku: prod(id).sku || '', status: st })), unknown: [...AUDIT.unknown.keys()].slice(0, 500) };
    if (await save(AUD, doc)) { AUDIT = null; saveDraft(); toast(`Audit ${doc.no} save hua — ${missing.length} missing`); ui.rfMode = 'history'; renderView(true); viewAudit(doc.id); }
  }
  function viewAudit(id) {
    const a = S[AUD].find(x => x.id === id); if (!a) return;
    openModal(`${mHead('Audit ' + esc(a.no), esc((a.label || '') + ' · ' + fmtD(tsDate(a.finishedAt))))}<div class="m-body">
      <div class="aud-big"><div class="ok"><b>${num(a.found)}</b><span>Mile</span></div><div class="bad"><b>${(a.missing || []).length}</b><span>Missing</span></div><div class="warn"><b>${(a.wrong || []).length}</b><span>Galat jagah</span></div><div><b>${(a.unknown || []).length}</b><span>Anjaan</span></div></div>
      <section class="sec"><h4>Missing pieces</h4>${(a.missing || []).map(m => `<div class="sp-row"><b class="mono">#${esc(m.sku)}</b><span class="small muted">${esc(m.category)} · N ${w3(m.net)}${m.tray ? ' · Tray ' + esc(m.tray) : ''}</span></div>`).join('') || '<p class="small green" style="margin:0">Koi missing nahi ✓</p>'}</section>
      ${(a.wrong || []).length ? `<section class="sec"><h4>Galat jagah / sold mile</h4>${a.wrong.map(m => `<div class="sp-row"><b class="mono">#${esc(m.sku)}</b><span class="small">${esc(m.status)}</span></div>`).join('')}</section>` : ''}
      </div><div class="m-foot"><button type="button" class="btn" data-act="aud-csv" data-id="${esc(a.id)}">${ic('dl', 14)} CSV</button><button type="button" class="btn" data-act="close">Close</button></div>`, { wide: true });
  }
  function focusScan() { setTimeout(() => { const el = document.getElementById(ui.rfMode === 'link' ? 'rf-in' : 'aud-in'); if (el) el.focus(); }, 30); }

  /* ---------- Stock Insights ---------- */
  function insightsBody() {
    const L = inStock(); if (!L.length) return emptyBox('Abhi In-Stock maal nahi hai.');
    const t = todayStr(); const rate = num(settings().gold24);
    const age = p => daysBetween(tsDate(p.createdAt) || t, t);
    const B = [['0–30 din', 0, 30], ['31–90 din', 31, 90], ['91–180 din', 91, 180], ['6–12 mahine', 181, 365], ['1 saal+', 366, 1e9]];
    const bucket = B.map(([l, a, b]) => { const x = L.filter(p => age(p) >= a && age(p) <= b); return [l, x.length, sum(x, p => p.net), sum(x, prodValue)]; });
    const byCat = {}; L.forEach(p => { const k = (p.category || '—') + ' · ' + (p.purity || ''); const o = byCat[k] || (byCat[k] = { n: 0, net: 0, fine: 0, val: 0, age: 0 }); o.n += Math.max(1, num(p.pcs) || 1); o.net += num(p.net); o.fine += prodFine(p); o.val += prodValue(p); o.age += age(p); });
    const byTray = {}; L.forEach(p => { const k = p.tray || '— (tray nahi)'; const o = byTray[k] || (byTray[k] = { n: 0, net: 0, rf: 0 }); o.n++; o.net += num(p.net); if (p.rfid) o.rf++; });
    const slow = L.slice().sort((a, b) => age(b) - age(a)).slice(0, 15);
    const noHuid = L.filter(p => metalOf(p.purity) === 'gold' && !p.huid).length;
    const appr = S.products.filter(p => p.status === 'On Approval').length;
    const tbl = (head, rows) => `<div class="tbl-scroll"><table class="btable"><thead><tr>${head.map(h => `<th${h[1] ? ' class="r"' : ''}>${h[0]}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`;
    return `<div class="kpis">${kpi('In-stock pieces', sum(L, p => Math.max(1, num(p.pcs) || 1)), L.length + ' entries')}${kpi('Net weight', sum(L, p => p.net).toFixed(3) + ' g', 'Fine ' + sum(L, prodFine).toFixed(3) + ' g')}${kpi('Aaj ki value', rate ? inr(sum(L, prodValue)) : 'Rate daaliye', rate ? 'Gold ' + inr(rate) + '/10g' : '')}${kpi('Tag print baaki', pendingTags().length, 'Tags & Print mein')}${kpi('RFID jude', L.filter(p => p.rfid).length + '/' + L.length, '')}${kpi('HUID nahi', noHuid, 'Gold pieces')}${kpi('Approval par', appr, 'Jangad')}</div>
      <div class="two"><div class="card"><h3>Kitne din se stock mein</h3>${tbl([['Umar'], ['Pcs', 1], ['Net g', 1], ['Value', 1]], bucket.map(b => `<tr><td>${b[0]}</td><td class="r">${b[1]}</td><td class="r">${b[2].toFixed(3)}</td><td class="r">${rate ? inr(b[3]) : '—'}</td></tr>`))}</div>
      <div class="card"><h3>Tray-wise</h3>${tbl([['Tray'], ['Pcs', 1], ['Net g', 1], ['RFID', 1]], Object.entries(byTray).sort().map(([k, o]) => `<tr><td>${esc(k)}</td><td class="r">${o.n}</td><td class="r">${o.net.toFixed(3)}</td><td class="r">${o.rf}/${o.n}</td></tr>`))}</div></div>
      <div class="card" style="margin-top:14px"><h3>Category & purity</h3>${tbl([['Category · Purity'], ['Pcs', 1], ['Net g', 1], ['Fine g', 1], ['Value', 1], ['Avg din', 1]], Object.entries(byCat).sort((a, b) => b[1].net - a[1].net).map(([k, o]) => `<tr><td>${esc(k)}</td><td class="r">${o.n}</td><td class="r">${o.net.toFixed(3)}</td><td class="r">${o.fine.toFixed(3)}</td><td class="r">${rate ? inr(o.val) : '—'}</td><td class="r">${Math.round(o.age / Math.max(1, o.n))}</td></tr>`))}</div>
      <div class="card"><h3>Sabse purana maal (slow movers)</h3>${tbl([['SKU'], ['Item'], ['Net g', 1], ['Tray'], ['Din', 1]], slow.map(p => `<tr class="click" data-act="prod-edit" data-id="${esc(p.id)}"><td><b class="mono">#${esc(p.sku)}</b></td><td>${esc(p.category || '')} · ${esc(p.purity || '')}</td><td class="r">${w3(p.net)}</td><td>${esc(p.tray || '—')}</td><td class="r">${age(p)}</td></tr>`))}</div>`;
  }

  /* ---------- wire into the Vault ---------- */
  const MINE = { tags: { shell: tagsShell, body: tagsBody, mount: () => { refreshPreview(); } },
    rfid: { shell: rfidShell, body: rfidBody, mount: () => { refreshLink(); focusScan(); } },
    insights: { shell: () => '<div id="vbody"></div>', body: insightsBody } };
  {
    const VV = VIEWDEF.vault;
    VIEWDEF.vault = {
      shell: () => { const m = MINE[ui.vTab]; return m ? subTabs('vTab', VT) + m.shell() : VV.shell(); },
      mount() { const m = MINE[ui.vTab]; if (m) { if (m.mount) m.mount(); } else if (VV.mount) VV.mount(); },
      body() {
        const m = MINE[ui.vTab]; if (m) return m.body();
        const b = VV.body();
        if (!ui.vTab || ui.vTab === 'stock') {
          const n = pendingTags().length; let top = '';
          if (AUDIT) top += `<div class="banner"><span>📋 Stock audit chal raha hai (${esc(AUDIT.label)}) — ${AUDIT.found.size}/${AUDIT.expected.length} mile.</span><button class="btn sm primary" data-act="aud-open">Audit kholo</button></div>`;
          if (n) top += `<div class="banner"><span>🏷 <b>${n}</b> piece${n > 1 ? 's' : ''} ke tag print baaki hain (naye ya weight badla).</span><button class="btn sm primary" data-act="seg" data-k="vTab" data-v="tags">Tags & Print</button></div>`;
          return top + b;
        }
        return b;
      }
    };
  }
  // re-render the preview when the tags list changes
  const _rv = renderView;
  renderView = function (full) { const r = _rv.apply(this, arguments); if (view === 'vault' && ui.vTab === 'tags') { clearTimeout(prevTimer); prevTimer = setTimeout(refreshPreview, 120); } return r; };

  /* ---------- piece form: RFID, tag note, print tag ---------- */
  if (typeof openProductForm === 'function') {
    const opf = openProductForm;
    openProductForm = function (id) {
      const el = opf.apply(this, arguments);
      try {
        const p = id ? S.products.find(x => x.id === id) : null;
        const fg = el.querySelector('form[data-form="product"] .sec .fg');
        if (fg) fg.insertAdjacentHTML('beforeend', `<label class="f"><span>RFID tag (EPC)</span><input name="rfid" class="mono" value="${esc(p && p.rfid || '')}" placeholder="Reader se padhaiye" autocomplete="off"></label>${fld('Tag par extra line', 'tagNote', p && p.tagNote, { ph: 'jaise MC-55 (optional)', max: 18 })}`);
        const netF = el.querySelector('form[data-form="product"] [data-o="net"]');
        if (netF) netF.closest('.f').insertAdjacentHTML('afterend', fld('Packet wt (packet ke saath, g)', 'pktWt', p && num(p.pktWt) ? w3(p.pktWt) : '', { type: 'number', ph: 'tag par PKT chhapega' }));
        if (p) {
          const foot = el.querySelector('.m-foot'); const cancel = foot && foot.querySelector('[data-act="close"]');
          if (cancel) cancel.insertAdjacentHTML('beforebegin', `<button type="button" class="btn" data-act="tag-one" data-id="${esc(p.id)}">🏷 Print tag</button>`);
          const bp = el.querySelector('.barcode-prev');
          if (bp) renderTag(p, tagCfg()).then(c => { bp.innerHTML = `<img src="${c.toDataURL('image/png')}" alt="Tag" style="width:100%;max-width:520px;image-rendering:pixelated;display:block;margin:0 auto"><div class="mono small" style="margin-top:6px">${esc(p.sku)}${p.huid ? ' · HUID ' + esc(p.huid) : ''}${p.rfid ? ' · RFID ✓' : ''}</div>`; }).catch(() => {});
        }
      } catch (e) { console.error(e); }
      return el;
    };
  }
  // validate RFID before the app saves the piece (capture phase runs first)
  document.addEventListener('submit', e => {
    const f = e.target; if (!f || f.dataset.form !== 'product') return;
    const inp = f.querySelector('[name="rfid"]'); if (!inp) return;
    const v = hexOnly(inp.value); inp.value = v;
    if (v) { const other = S.products.find(p => p.id !== f.dataset.id && p.rfid && hexOnly(p.rfid) === v); if (other) { e.preventDefault(); e.stopImmediatePropagation(); toast(`Ye RFID pehle se #${other.sku} se juda hai`, 'err'); } }
  }, true);
  // Smart Scanner: RFID read finds the piece too
  if (typeof scanList === 'function') {
    const sl = scanList;
    scanList = function (el) {
      const r = sl.apply(this, arguments);
      try {
        const o = el._opts || {}; const h = hexOnly(r.q);
        if (h.length >= 8) { const p = lookups().rfid.get(h) || (h === normCode(r.q) ? lookups().sku.get(normCode(epcSku(h))) : null); if (p && (!o.inStockOnly || p.status === 'In Stock') && !(o.exclude || []).includes(p.id) && !r.list.includes(p)) r.list = [p]; }
      } catch (e) { /* ignore */ }
      return r;
    };
  }

  /* ---------- events ---------- */
  SUBMIT2.tagcfg = submitTagCfg;
  const ACT = {
    'tag-settings': () => openTagSettings(),
    'tag-usb': async () => { try { await usbConnect(true, false); toast('✓ Printer jud gaya'); renderView(true); } catch (e) { if (e.name === 'NotFoundError') { try { await usbConnect(true, true); toast('✓ Printer jud gaya'); renderView(true); } catch (e2) { if (e2.name !== 'NotFoundError') toast(e2.message, 'err'); } } else toast(e.message, 'err'); } },
    'tag-test': async () => { await printTags([[...SEL].map(id => S.products.find(p => p.id === id)).find(Boolean) || tagsList()[0] || SAMPLE], { noMark: true }); },
    'tag-calib': async () => { try { await usbConnect(true); await usbSend(enc(`SIZE ${tagCfg().w} mm,${tagCfg().h} mm\r\nGAPDETECT\r\n`)); toast('Calibrate command bheja — printer 2–3 tag aage badhayega'); } catch (e) { toast(e.message || 'USB printer nahi juda', 'err'); } },
    'tag-logo-reset': (t, ov) => { ov._logo = ''; toast('Shivaa INC. logo wapas — Save dabaiye'); },
    'tag-selall': () => { tagsList().forEach(p => SEL.add(p.id)); renderView(); refreshPreview(); },
    'tag-selnone': () => { SEL.clear(); renderView(); refreshPreview(); },
    'tag-print': async () => {
      const list = [...SEL].map(id => S.products.find(p => p.id === id)).filter(Boolean);
      const copies = num((document.getElementById('tag-copies') || {}).value) || 1;
      if (await printTags(list, { copies })) { SEL.clear(); scheduleRender(); }
    },
    'tag-pdf': async () => { const list = [...SEL].map(id => S.products.find(p => p.id === id)).filter(Boolean); if (await printTags(list, { method: 'pdf', copies: num((document.getElementById('tag-copies') || {}).value) || 1 })) { SEL.clear(); scheduleRender(); } },
    'tag-one': async t => { const p = S.products.find(x => x.id === t.dataset.id); if (p) await printTags([p]); },
    'rf-pick': t => { LINK.pid = t.dataset.id; refreshLink(); focusScan(); },
    'aud-start': () => startAudit((document.getElementById('aud-scope') || {}).value || 'all'),
    'aud-cancel': () => confirmBox('Ye audit band karein? Abhi tak ki ginti save nahi hogi.', () => { AUDIT = null; saveDraft(); renderView(true); }, 'Band karo'),
    'aud-finish': () => { const miss = AUDIT ? AUDIT.expected.length - AUDIT.found.size : 0; confirmBox(`Audit khatam karke save karein?${miss ? ` <b>${miss}</b> piece missing dikh rahe hain.` : ' Sab maal mil gaya ✓'}`, finishAudit, 'Save audit'); },
    'aud-view': t => viewAudit(t.dataset.id),
    'aud-open': () => { ui.vTab = 'rfid'; ui.rfMode = 'audit'; renderView(true); focusScan(); },
    'aud-csv': async t => {
      const a = S[AUD].find(x => x.id === t.dataset.id); if (!a) return;
      const rows = [...(a.missing || []).map(m => ['Missing', m.sku, m.category, m.net, m.tray]), ...(a.wrong || []).map(m => ['Galat jagah / ' + m.status, m.sku, '', '', '']), ...(a.unknown || []).map(c => ['Anjaan tag', c, '', '', ''])];
      await offerDownload(`audit_${a.no}.csv`, csvBlob(csvOf(['Type', 'SKU / Code', 'Category', 'Net g', 'Tray'], rows)));
    }
  };
  document.addEventListener('click', async ev => {
    const t = ev.target.closest('[data-act]'); if (!t) return;
    const h = ACT[t.dataset.act]; if (!h) return;
    if (t.tagName === 'BUTTON' && t.disabled) return;
    try { await h(t, t.closest('.overlay'), ev); } catch (err) { console.error(err); toast('Something went wrong — please try again', 'err'); }
  });
  document.addEventListener('change', ev => {
    const t = ev.target;
    if (t && t.dataset && t.dataset.pkt !== undefined) {
      const p = S.products.find(x => x.id === t.dataset.pkt); const v = t.value === '' ? '' : r3(num(t.value));
      if (p && String(v) !== String(p.pktWt ?? '')) {
        if (v !== '' && v < num(p.gross)) toast(`#${p.sku}: packet weight gross (${w3(p.gross)} g) se kam hai — check kar lijiye`, 'err');
        save('products', { ...p, pktWt: v, updatedAt: Date.now() }).then(okk => { if (okk) { toast(`#${p.sku} packet weight ${v === '' ? 'hataya' : w3(v) + ' g'}`); clearTimeout(prevTimer); prevTimer = setTimeout(refreshPreview, 60); } });
      }
      return;
    }
    if (t && t.dataset && t.dataset.tsel !== undefined) { if (t.checked) SEL.add(t.dataset.tsel); else SEL.delete(t.dataset.tsel); const s = document.querySelector('.list-sum span:nth-child(2) b'); if (s) s.textContent = SEL.size; clearTimeout(prevTimer); prevTimer = setTimeout(refreshPreview, 60); }
  });
  // files (capture phase — the app clears file inputs after its own handler)
  document.addEventListener('change', async ev => {
    const t = ev.target; if (!t || t.type !== 'file' || !t.dataset.tagfile) return;
    const file = t.files && t.files[0]; if (!file) return;
    const kind = t.dataset.tagfile;
    try {
      if (kind === 'logo') { const ov = t.closest('.overlay'); ov._logo = await readLogo(file); const im = ov.querySelector('img'); if (im) im.src = ov._logo; toast('Logo badla — Save dabaiye'); }
      if (kind === 'epc') { const txt = await file.text(); const codes = txt.split(/[\s,;]+/).map(normCode).filter(c => c.length >= 4); codes.forEach(auditRead); toast(codes.length + ' codes import hue'); }
    } catch (e) { console.error(e); toast('File nahi padh paye', 'err'); }
  }, true);
  // scanner / RFID reader input (keyboard wedge: code + Enter or Tab)
  const scanIdle = {};
  function handleScanValue(el) {
    const v = el.value; el.value = '';
    v.split(/[\r\n,;]+/).map(s => s.trim()).filter(Boolean).forEach(c => { if (el.id === 'aud-in') auditRead(c); else linkProcess(c); });
  }
  document.addEventListener('keydown', ev => {
    const el = ev.target;
    if (el && (el.id === 'aud-in' || el.id === 'rf-in') && (ev.key === 'Enter' || ev.key === 'Tab')) { ev.preventDefault(); handleScanValue(el); return; }
    if (el && el.dataset && el.dataset.pkt !== undefined && ev.key === 'Enter') { ev.preventDefault(); el.blur(); return; }
    // keep reader input from getting lost while an audit is running
    if (AUDIT && view === 'vault' && ui.vTab === 'rfid' && ui.rfMode === 'audit' && !$('#modal-root').children.length) {
      const inp = document.getElementById('aud-in');
      if (inp && document.activeElement !== inp && !/INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '') && ev.key.length === 1) inp.focus();
    }
  }, true);
  document.addEventListener('input', ev => {
    const el = ev.target;
    if (!el || (el.id !== 'aud-in' && el.id !== 'rf-in')) return;
    if (/[\r\n]/.test(el.value)) { handleScanValue(el); return; }
    clearTimeout(scanIdle[el.id]);
    const v = normCode(el.value);
    if (/^[0-9A-F]{24}$|^[0-9A-F]{32}$/.test(v)) scanIdle[el.id] = setTimeout(() => { if (normCode(el.value) === v) handleScanValue(el); }, 150);
  });
  document.addEventListener('paste', ev => {
    const el = ev.target; if (!el || (el.id !== 'aud-in' && el.id !== 'rf-in')) return;
    const txt = (ev.clipboardData || window.clipboardData).getData('text'); if (!/[\s,;]/.test(txt.trim())) return;
    ev.preventDefault(); el.value = txt; handleScanValue(el);
  });

  window.SJ_STOCK = { renderTag, tsplJob, zplJob, skuEpc, epcSku, rfAutoLink, toBitmap, printTags, QRENC, tagCfg, pendingTags, auditRead, startAudit, findByCode, pdfTags, driverPrint, tagSig };
})();
