/* =====================================================================
   SJ REPORTS — Report Centre (Reports → "📚 Report Centre")
   - 60+ detailed reports in 8 groups (sales, stock, metal, profit,
     parties, GST & tax, cash & growth, CA / audit)
   - every report: period / as-on filter, Pakka-Kacha + Wholesale-Retail
     aware, Excel (.xlsx), CSV and PDF export
   - "CA Pack": the whole year's books in one Excel workbook
   - Fixed asset register (IT Act WDV depreciation)
   - Setup → "Sab data mitao" (Owner only): clear all data, start fresh
   ===================================================================== */
(() => {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined' || typeof REP_TABS === 'undefined') return;

  /* ---------------- extra collection: fixed assets ---------------- */
  const FA = 'fixedAssets';
  if (!COLS.includes(FA)) COLS.push(FA);
  if (!S[FA]) S[FA] = [];

  /* ---------------- small helpers ---------------- */
  const T = v => v.totals || {};
  const isCash = m => (m || 'Cash') === 'Cash';
  const today = () => todayStr();
  const fyStart = d => { const [y, m] = String(d || today()).split('-').map(Number); return (m >= 4 ? y : y - 1) + '-04-01'; };
  const fyEnd = d => { const s = fyStart(d); return (+s.slice(0, 4) + 1) + '-03-31'; };
  const fyLabel = d => 'FY ' + fy(d || today());
  const metalName = m => m === 'silver' ? 'Silver' : 'Gold';
  const supById = id => S.suppliers.find(x => x.id === id);
  const partyOf = v => (INV_TYPES[v.type] || {}).party === 'supplier' ? supById(v.partyId) : custById(v.partyId);
  const saleSide = v => isSaleT(v.type) || v.type === 'metal';
  const INVS = (a, b, f) => S.invoices.filter(v => inBook(v) && (!a || inRange(v.date, a, b)) && (!f || f(v)));
  const payRows = (a, b) => { const out = []; S.invoices.forEach(v => { if (!inBook(v)) return; invPayments(v).forEach(p => { const d = p.date || v.date; if (a && !inRange(d, a, b)) return; out.push({ date: d, amt: num(p.amount), fine: num(p.fine), mode: p.mode || 'Cash', note: p.note || '', v, buy: isBuy(v.type) }); }); }); return out; };
  const paidUpto = (v, d) => r2(sum(invPayments(v).filter(p => (p.date || v.date) <= d), p => p.amount));
  const dueAsOf = (v, d) => r2(invPayable(v) - paidUpto(v, d));
  const auditBy = (() => { let key = '', map = new Map(); return id => { const A = S.audit || []; const k = A.length + ':' + (A[A.length - 1] || {}).id; if (k !== key) { key = k; map = new Map(); A.forEach(e => { if (e.col === 'invoices' && e.action === 'create' && e.docId) map.set(e.docId, e.by || e.user || ''); }); } return map.get(id) || ''; }; })();
  const lc = s => String(s || '').toLowerCase();
  const tsDay = ms => { const n = num(ms); return n > 0 ? dstrOf(new Date(n)) : ''; };
  const dstrOf = d => d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  const months = (a, b) => { const out = []; let m = monthKey(a); const e = monthKey(b); let g = 0; while (m <= e && g++ < 240) { out.push(m); m = shiftMonth(m, 1); } return out; };
  const pctOf = (x, t) => t ? x / t * 100 : 0;
  const stockLive = p => p.status === 'In Stock' || p.status === 'On Approval';
  const pFine = p => r3(num(p.net) * num(p.tunch || (PUR[p.purity] || {}).t) / 100);
  const pAge = p => { const d = p.purchaseDate || tsDay(p.createdAt); return d ? Math.max(0, daysBetween(d, today())) : null; };
  const pCost = (() => { let ctx = null, key = ''; return p => { const k = S.products.length + ':' + S.invoices.length; if (k !== key) { key = k; try { ctx = advPfCtx(); } catch (e) { ctx = null; } }
    const net = num(p.net); if (!(net > 0)) return 0; const tc = num(p.tunch) || (PUR[p.purity] || {}).t || 0; let cr = 0; try { cr = (ctx && ctx.pRate.get(p.id)) || advRateAt(p.purchaseDate || today(), metalOf(p.purity)); } catch (e) { cr = rateFor(metalOf(p.purity)); }
    return r2(net * (tc + num(p.wastage)) / 100 * cr + net * num(p.labour)); }; })();

  /* ---------------- column / section model ---------------- */
  // column: {h: header, t: type, w: pdf width weight}; types: s, d, inr, inr2, g, n, pct, x (html, not exported)
  const C = (h, t, w) => ({ h, t: t || 's', w: w || (t === 's' || !t ? 2 : 1.1) });
  const sec = (title, cols, rows, o) => ({ title, cols, rows, foot: (o || {}).foot || null, note: (o || {}).note || '', empty: (o || {}).empty || '' });
  const row = (cells, o) => { const r = cells.slice(); if (o) Object.assign(r, o); return r; };   // r._inv (bill id), r._b (bold), r._h (heading)
  const FMT = {
    s: v => v == null ? '' : String(v), x: v => v == null ? '' : String(v), d: v => v ? fmtD(v) : '',
    inr: v => v === '' || v == null ? '' : inr(v), inr2: v => v === '' || v == null ? '' : inr2(v),
    g: v => v === '' || v == null ? '' : num(v).toFixed(3), n: v => v === '' || v == null ? '' : String(Math.round(num(v))),
    pct: v => v === '' || v == null ? '—' : num(v).toFixed(2) + '%'
  };
  const fmtCell = (t, v) => (FMT[t] || FMT.s)(v);
  const isNumT = t => t === 'inr' || t === 'inr2' || t === 'g' || t === 'n' || t === 'pct';
  const totalsRow = (cols, rows, label, skip) => { const out = cols.map((c, i) => i === 0 ? (label || 'Total') : (isNumT(c.t) && c.t !== 'pct' && !(skip || []).includes(i) ? r3(sum(rows.filter(r => !r._h), r => r[i])) : '')); out._b = 1; return out; };

  /* ---------------- report registry ---------------- */
  const GRP = [
    ['sales', 'Bikri & Billing', '🧾', 'Sales register, day book, staff, returns, discount'],
    ['stock', 'Stock & Vault', '📦', 'Stock value, movement, ageing, fast/slow, HUID'],
    ['metal', 'Metal, Karigar & Hallmark', '⚖️', 'Fine balance, old gold, karigar loss & delays'],
    ['profit', 'Profit', '📈', 'Wastage, bill-wise, party-wise, P&L, rate impact'],
    ['party', 'Parties & Udhaari', '👥', 'Outstanding, ageing, follow-up, credit limit'],
    ['tax', 'GST & Tax', '🏛️', 'GSTR-1/3B, ITC, cash ₹2 lakh, TDS 194Q, e-invoice'],
    ['cash', 'Cash, Kharcha & Growth', '💰', 'Cash & bank, expenses, scheme, birthdays'],
    ['ca', 'CA / Audit — saal ka hisaab', '🧑‍💼', 'Balance sheet, Form 3CD stock, 40A(3), GSTR-9']
  ];
  const REPS = []; const RMAP = {};
  // period: 'range' (from–to), 'asof' (as on date), 'none'
  function rep(id, g, t, d, o) { const r = { id, g, t, d, period: o.period || 'range', defRp: o.defRp || '', build: o.build, link: o.link || null, tag: o.tag || '' }; REPS.push(r); RMAP[id] = r; }

  /* =====================================================================
     A. SALES & BILLING
     ===================================================================== */
  rep('salesreg', 'sales', 'Sales register (bill-wise)', 'Har bill: party, sector, wazan, taxable, GST, total, mila, baaki', { build(r) {
    const L = INVS(r.a, r.b, saleSide).sort((x, y) => x.date.localeCompare(y.date) || String(x.no).localeCompare(String(y.no)));
    const cols = [C('Date', 'd', 1), C('Bill no', 's', 1.6), C('Type', 's', 1), C('Party', 's', 2.4), C('Sector', 's', 1), C('Net g', 'g'), C('Fine g', 'g'), C('Taxable', 'inr'), C('GST', 'inr'), C('Bill total', 'inr'), C('Received', 'inr'), C('Balance', 'inr')];
    const rows = L.map(v => { const t = T(v); return row([v.date, v.no, (INV_TYPES[v.type] || {}).short || v.type, v.partyName, chanOf(v) === 'wholesale' ? 'Wholesale' : 'Retail', t.net, t.fine, t.taxable, num(t.cgst) + num(t.sgst) + num(t.igst), invPayable(v), invPaid(v), invDue(v)], { _inv: v.id }); });
    const tr = totalsRow(cols, rows);
    return { summary: [['Bills', L.length], ['Sales', inr(tr[9])], ['GST', inr(tr[8])], ['Received', inr(tr[10])], ['Baaki', inr(tr[11])]], sections: [sec('', cols, rows, { foot: tr })] };
  } });

  rep('daybook', 'sales', 'Day book (roz-namcha)', 'Din ki har entry — bill, payment, kharcha, bank/cash, scheme — ek jagah', { defRp: 'today', build(r) {
    const E = [];
    INVS(r.a, r.b).forEach(v => E.push({ d: v.date, k: (INV_TYPES[v.type] || {}).short || v.type, ref: v.no, p: v.partyName, in: 0, out: 0, val: invPayable(v), m: '', inv: v.id }));
    payRows(r.a, r.b).forEach(p => E.push({ d: p.date, k: p.buy ? 'Payment diya' : 'Payment mila', ref: p.v.no, p: p.v.partyName, in: p.buy ? 0 : p.amt, out: p.buy ? p.amt : 0, val: '', m: p.mode, inv: p.v.id }));
    S.expenses.filter(e => inRange(e.date, r.a, r.b)).forEach(e => E.push({ d: e.date, k: 'Kharcha', ref: e.category || '', p: e.notes || '', in: 0, out: num(e.amount), val: '', m: e.mode || 'Cash' }));
    (S.banktx || []).filter(x => inRange(x.date, r.a, r.b)).forEach(x => { const B = BTX[x.kind] || {}; const a = num(x.amount); const inn = x.kind === 'receipt' || x.kind === 'interest' || x.kind === 'cashin'; const out = x.kind === 'payment' || x.kind === 'charges' || x.kind === 'cashout'; E.push({ d: x.date, k: B.label || x.kind, ref: x.ref || '', p: [x.party, x.source, x.purpose, x.notes].filter(Boolean).join(' · '), in: inn ? a : 0, out: out ? a : 0, val: (!inn && !out) ? a : '', m: x.kind === 'cashin' || x.kind === 'cashout' ? 'Cash' : 'Bank' }); });
    (S.schemes || []).forEach(sc => (sc.payments || []).forEach(p => { if (inRange(p.date, r.a, r.b)) E.push({ d: p.date, k: 'Scheme kisht', ref: sc.no, p: sc.customerName, in: num(p.amount), out: 0, val: '', m: p.mode || 'Cash' }); }));
    E.sort((x, y) => x.d.localeCompare(y.d));
    const cols = [C('Date', 'd', 1), C('Entry', 's', 1.4), C('Ref / Bill', 's', 1.6), C('Party / Detail', 's', 3), C('Bill value', 'inr'), C('Money in', 'inr'), C('Money out', 'inr'), C('Mode', 's', 1)];
    const rows = E.map(e => row([e.d, e.k, e.ref, e.p, e.val, e.in || '', e.out || '', e.m], { _inv: e.inv }));
    const tin = sum(E, e => e.in), tout = sum(E, e => e.out);
    const cashIn = sum(E.filter(e => e.m === 'Cash'), e => e.in), cashOut = sum(E.filter(e => e.m === 'Cash'), e => e.out);
    return { summary: [['Entries', E.length], ['Money in', inr(tin)], ['Money out', inr(tout)], ['Net', inr(tin - tout)], ['Cash in / out', inr(cashIn) + ' / ' + inr(cashOut)]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [4]) })] };
  } });

  rep('catsales', 'sales', 'Category + purity wise sales', 'Kaunsa maal kitna bika — pcs, net, fine, value, avg wastage, hissa %', { build(r) {
    const G = groupLines(saleLines(r.a, r.b), 'catpur').sort((x, y) => y.amount - x.amount); const tot = sum(G, x => x.amount);
    const cols = [C('Category + purity', 's', 2.6), C('Bills', 'n', .8), C('Pcs', 'n', .8), C('Gross g', 'g'), C('Net g', 'g'), C('Fine g', 'g'), C('Avg wastage', 'pct'), C('Value', 'inr'), C('Share', 'pct'), C('Wastage profit g', 'g')];
    const rows = G.map(x => [x.key, x.bills, x.pcs, x.gross, x.net, x.fine, x.avgW, x.amount, pctOf(x.amount, tot), x.gainFine]);
    return { summary: [['Categories', G.length], ['Value', inr(tot)], ['Net', g3(sum(G, x => x.net))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows) })], chart: barsHtml(G.slice(0, 12).map(x => [x.key, x.amount]), inr) };
  } });

  rep('staffsales', 'sales', 'Staff / salesman wise sales', 'Kisne kitne bill banaye, kitna becha, kitna wastage profit', { build(r) {
    const L = saleLines(r.a, r.b); const m = new Map();
    L.forEach(l => { const k = auditBy(l.invId) || '(pata nahi)'; const x = m.get(k) || { k, bills: new Set(), pcs: 0, net: 0, fine: 0, amt: 0, gain: 0 }; x.bills.add(l.invId); x.pcs += l.pcs; x.net += l.net; x.fine += l.fine; x.amt += l.amount; x.gain += num(l.gainValue); m.set(k, x); });
    const X = [...m.values()].sort((a, b) => b.amt - a.amt); const tot = sum(X, x => x.amt);
    const cols = [C('Staff', 's', 2.4), C('Bills', 'n', .8), C('Pcs', 'n', .8), C('Net g', 'g'), C('Fine g', 'g'), C('Sales', 'inr'), C('Share', 'pct'), C('Avg bill', 'inr'), C('Wastage profit ₹', 'inr')];
    const rows = X.map(x => [x.k, x.bills.size, x.pcs, x.net, x.fine, x.amt, pctOf(x.amt, tot), x.bills.size ? x.amt / x.bills.size : 0, x.gain]);
    return { summary: [['Staff', X.length], ['Sales', inr(tot)]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [7]), note: 'Staff ka naam audit trail se aata hai (bill kisne banaya). Purane bills jinka audit nahi hai "(pata nahi)" mein dikhte hain.' })] };
  } });

  rep('pattern', 'sales', 'Bikri ka pattern (din & ghanta)', 'Kis din aur kis ghante sabse zyada bikri — staff aur dukaan timing ke liye', { build(r) {
    const W = ['Ravivar', 'Somvar', 'Mangal', 'Budh', 'Guru', 'Shukra', 'Shani']; const wd = W.map(n => ({ n, b: 0, a: 0 })); const hr = {};
    INVS(r.a, r.b, saleSide).forEach(v => { const d = parseD(v.date).getDay(); wd[d].b++; wd[d].a += invPayable(v); const ms = num(v.createdAt); if (ms > 0) { const h = new Date(ms).getHours(); const x = hr[h] || (hr[h] = { b: 0, a: 0 }); x.b++; x.a += invPayable(v); } });
    const c1 = [C('Din', 's', 2), C('Bills', 'n'), C('Sales', 'inr'), C('Avg bill', 'inr')];
    const r1 = wd.map(x => [x.n, x.b, x.a, x.b ? x.a / x.b : 0]);
    const c2 = [C('Ghanta', 's', 2), C('Bills', 'n'), C('Sales', 'inr')];
    const r2_ = Object.keys(hr).map(Number).sort((a, b) => a - b).map(h => [String(h).padStart(2, '0') + ':00 – ' + String(h + 1).padStart(2, '0') + ':00', hr[h].b, hr[h].a]);
    const best = wd.slice().sort((a, b) => b.a - a.a)[0];
    return { summary: [['Sabse achha din', best && best.a ? best.n : '—']], sections: [sec('Hafte ke din', c1, r1), sec('Din ka ghanta', c2, r2_, { empty: 'Ghante ka data naye bills se aata hai.' })], chart: barsHtml(wd.map(x => [x.n, x.a]), inr) };
  } });

  rep('returns', 'sales', 'Sales return / Credit-Debit note register', 'Wapas aaya maal aur credit/debit notes — kaaran ke saath', { build(r) {
    const L = (S.cdn || []).filter(c => inRange(c.date, r.a, r.b)).sort((x, y) => x.date.localeCompare(y.date));
    const cols = [C('Date', 'd', 1), C('Note no', 's', 1.4), C('Type', 's', 1), C('Party', 's', 2.4), C('Against bill', 's', 1.5), C('Reason', 's', 2), C('Taxable', 'inr'), C('GST', 'inr'), C('Total', 'inr')];
    const rows = L.map(c => row([c.date, c.no, c.kind === 'credit' ? 'Credit note' : 'Debit note', c.partyName, c.invNo, c.reason, c.taxable, num(c.cgst) + num(c.sgst) + num(c.igst), c.total], { _inv: c.invId }));
    return { summary: [['Notes', L.length], ['Credit notes', inr(sum(L.filter(c => c.kind === 'credit'), c => c.total))], ['Debit notes', inr(sum(L.filter(c => c.kind !== 'credit'), c => c.total))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows) })] };
  } });

  rep('discount', 'sales', 'Discount report', 'Kis bill par kitna discount diya aur kisne', { build(r) {
    const L = INVS(r.a, r.b, v => isSaleT(v.type) && num(T(v).discount) > 0.5);
    const cols = [C('Date', 'd', 1), C('Bill no', 's', 1.6), C('Party', 's', 2.4), C('Items total', 'inr'), C('Discount', 'inr'), C('Discount %', 'pct'), C('Bill total', 'inr'), C('Staff', 's', 1.3)];
    const rows = L.map(v => row([v.date, v.no, v.partyName, T(v).itemsTotal, T(v).discount, pctOf(num(T(v).discount), num(T(v).itemsTotal)), invPayable(v), auditBy(v.id)], { _inv: v.id }));
    return { summary: [['Bills with discount', L.length], ['Discount diya', inr(sum(L, v => T(v).discount))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [5]) })] };
  } });

  rep('making', 'sales', 'Making / labour realisation', 'Labour kitna liya vs kharid labour — kahan kam liya', { build(r) {
    const L = saleLines(r.a, r.b).filter(l => num(l.labourAmt) > 0 || l.labourGain != null);
    const G = new Map(); L.forEach(l => { const k = l.category + ' ' + l.purity; const x = G.get(k) || { k, net: 0, lab: 0, gain: 0, known: 0 }; x.net += l.net; x.lab += num(l.labourAmt); if (l.labourGain != null) { x.gain += l.labourGain; x.known++; } G.set(k, x); });
    const cols = [C('Category + purity', 's', 2.6), C('Net g', 'g'), C('Labour liya ₹', 'inr'), C('Labour per g', 'inr2'), C('Labour margin ₹', 'inr')];
    const rows = [...G.values()].sort((a, b) => b.lab - a.lab).map(x => [x.k, x.net, x.lab, x.net ? x.lab / x.net : 0, x.known ? x.gain : '']);
    const low = L.filter(l => l.labourGain != null && l.labourGain < -0.5);
    const c2 = [C('Date', 'd', 1), C('Bill', 's', 1.5), C('Party', 's', 2.2), C('Item', 's', 2), C('Net g', 'g'), C('Labour/g liya', 'inr2'), C('Ghaata ₹', 'inr')];
    const r2_ = low.map(l => row([l.date, l.no, l.party, l.category + ' ' + l.purity, l.net, l.labour, l.labourGain], { _inv: l.invId }));
    return { summary: [['Labour liya', inr(sum(L, l => l.labourAmt))], ['Labour margin', inr(sum(L, l => num(l.labourGain)))], ['Kam labour wali lines', low.length]], sections: [sec('Category-wise', cols, rows, { foot: totalsRow(cols, rows, 'Total', [3]) }), sec('Kharid se kam labour par bika', c2, r2_, { empty: 'Koi line kharid labour se kam par nahi biki. 👍' })] };
  } });

  rep('edited', 'sales', 'Badle / mitaye gaye bills', 'Save hone ke baad edit ya delete hue bills — kisne, kab, kya badla (fraud check)', { build(r) {
    const A = (S.audit || []).filter(e => e.col === 'invoices' && (e.action === 'update' || e.action === 'delete') && inRange(e.date || tsDay(e.at), r.a, r.b)).sort((x, y) => num(y.at) - num(x.at));
    const cols = [C('Date', 'd', 1), C('Time', 's', .8), C('Kaam', 's', .9), C('Bill', 's', 2.4), C('Kisne', 's', 1.3), C('Kya badla', 's', 4)];
    const rows = A.map(e => row([e.date || tsDay(e.at), e.at ? new Date(num(e.at)).toTimeString().slice(0, 5) : '', e.action === 'delete' ? 'DELETE' : 'Edit', e.label, e.by || e.user || '', (e.changes || []).slice(0, 6).map(c => Array.isArray(c) ? c.join(': ') : (c.f || c.field || '') + (c.from !== undefined ? ': ' + c.from + ' → ' + c.to : '')).join('; ')], { _inv: e.action === 'delete' ? null : e.docId }));
    return { summary: [['Edits', A.filter(e => e.action === 'update').length], ['Deletes', A.filter(e => e.action === 'delete').length]], sections: [sec('', cols, rows, { empty: 'Is period mein koi bill badla ya mitaya nahi gaya.' })] };
  } });

  /* =====================================================================
     B. STOCK & VAULT
     ===================================================================== */
  rep('stockval', 'stock', 'Stock summary & valuation', 'Category + purity: pcs, gross, net, fine, cost value, aaj ke bhaav se value', { period: 'none', build() {
    const m = new Map(); S.products.filter(stockLive).forEach(p => { const k = p.category + '|' + p.purity; const x = m.get(k) || { cat: p.category, pur: p.purity, metal: metalOf(p.purity), pcs: 0, gross: 0, net: 0, fine: 0, cost: 0, appr: 0 }; x.pcs += Math.max(1, num(p.pcs) || 1); x.gross += num(p.gross); x.net += num(p.net); x.fine += pFine(p); x.cost += pCost(p); if (p.status === 'On Approval') x.appr += num(p.net); m.set(k, x); });
    const X = [...m.values()].sort((a, b) => a.metal.localeCompare(b.metal) || b.net - a.net);
    const cols = [C('Category', 's', 2), C('Purity', 's', 1.2), C('Pcs', 'n', .8), C('Gross g', 'g'), C('Net g', 'g'), C('Fine g', 'g'), C('Approval par g', 'g'), C('Cost value', 'inr'), C('Market value', 'inr')];
    const rows = X.map(x => [x.cat, x.pur, x.pcs, x.gross, x.net, x.fine, x.appr, x.cost, x.fine * rateFor(x.metal)]);
    const gv = sum(X.filter(x => x.metal === 'gold'), x => x.fine * rateFor('gold')), sv = sum(X.filter(x => x.metal === 'silver'), x => x.fine * rateFor('silver'));
    return { summary: [['Gold fine', g3(sum(X.filter(x => x.metal === 'gold'), x => x.fine))], ['Silver fine', g3(sum(X.filter(x => x.metal === 'silver'), x => x.fine))], ['Market value', rateFor('gold') || rateFor('silver') ? inr(gv + sv) : 'bhaav set karo'], ['Cost value', inr(sum(X, x => x.cost))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [1]) })] };
  } });

  rep('stockmove', 'stock', 'Stock movement (opening → in → out → closing)', 'Gold aur silver ka fine-gram hisaab: opening, kharid, old metal, karigar, bikri, closing', { build(r) {
    const secs = []; const summ = [];
    ['gold', 'silver'].forEach(metal => { const ev = metalEvents(metal); let open = 0; const src = new Map();
      ev.forEach(e => { if (e.date < r.a) { open += e.dir * e.fine; return; } if (e.date > r.b) return; const k = (e.dir > 0 ? 'in' : 'out') + '|' + e.src; src.set(k, (src.get(k) || 0) + e.fine); });
      const ins = [...src].filter(([k]) => k.startsWith('in|')), outs = [...src].filter(([k]) => k.startsWith('out|'));
      const tin = sum(ins, x => x[1]), tout = sum(outs, x => x[1]); const close = open + tin - tout;
      const rows = [row(['Opening balance', '', open], { _b: 1 }), ...ins.map(([k, v]) => ['  + ' + k.slice(3), v, '']), row(['Total aaya (in)', '', tin], { _b: 1 }), ...outs.map(([k, v]) => ['  − ' + k.slice(4), v, '']), row(['Total gaya (out)', '', tout], { _b: 1 }), row(['Closing balance (books)', '', close], { _b: 1 })];
      const vault = sum(S.products.filter(p => stockLive(p) && metalOf(p.purity) === metal), pFine);
      if (r.b >= today()) rows.push(row(['Vault mein abhi (physical)', '', vault], { _b: 1 }), row(['Farak (vault − books)', '', vault - close], { _b: 1 }));
      secs.push(sec(metalName(metal) + ' — fine grams', [C('Particulars', 's', 4), C('Fine g', 'g', 1.4), C('Balance g', 'g', 1.4)], rows));
      summ.push([metalName(metal) + ' closing', g3(close)]); });
    return { summary: summ, sections: secs, note: 'Books ka stock bills, old metal aur karigar entries se banta hai. Vault mein jo maal bina bill ke daala gaya ho, wo "farak" mein dikhega.' };
  } });

  rep('stockage', 'stock', 'Stock ageing', 'Kitna maal kitne din se pada hai — 0-30 / 31-90 / 91-180 / 180+ din', { period: 'none', build() {
    const B = [['0–30', 30], ['31–90', 90], ['91–180', 180], ['180+', 1e9]]; const m = new Map();
    S.products.filter(stockLive).forEach(p => { const k = p.category + ' ' + p.purity; const x = m.get(k) || { k, n: [0, 0, 0, 0], g: [0, 0, 0, 0], unk: 0 }; const a = pAge(p); if (a == null) { x.unk += num(p.net); m.set(k, x); return; } const i = B.findIndex(b => a <= b[1]); x.n[i] += Math.max(1, num(p.pcs) || 1); x.g[i] += num(p.net); m.set(k, x); });
    const X = [...m.values()].sort((a, b) => (b.g[3] + b.g[2]) - (a.g[3] + a.g[2]));
    const cols = [C('Category + purity', 's', 2.6), ...B.map(b => C(b[0] + ' din g', 'g')), C('Total g', 'g'), C('180+ hissa', 'pct')];
    const rows = X.map(x => [x.k, ...x.g, sum(x.g) + x.unk, pctOf(x.g[3], sum(x.g))]);
    const old = S.products.filter(p => stockLive(p) && (pAge(p) || 0) > 180).sort((a, b) => pAge(b) - pAge(a));
    const c2 = [C('SKU', 's', 1.1), C('Item', 's', 2.4), C('Net g', 'g'), C('Din', 'n', .8), C('Tray', 's', 1), C('Supplier', 's', 1.8)];
    const r2_ = old.slice(0, 300).map(p => [p.sku, p.category + ' ' + p.purity + (p.making ? ' · ' + p.making : ''), p.net, pAge(p), p.tray || '', supName(p)]);
    return { summary: [['Pieces', S.products.filter(stockLive).length], ['180+ din purane', old.length]], sections: [sec('Category-wise ageing', cols, rows, { foot: totalsRow(cols, rows, 'Total', [6]) }), sec('180 din se purane pieces (dead stock)', c2, r2_, { empty: 'Koi piece 180 din se purana nahi. 👍' })] };
  } });

  rep('fastslow', 'stock', 'Fast / slow moving maal', 'Bikri vs stock — kitne din ka stock bacha hai (days of stock)', { defRp: '90', build(r) {
    const days = Math.max(1, daysBetween(r.a, r.b) + 1); const m = new Map();
    saleLines(r.a, r.b).forEach(l => { const k = l.category + ' ' + l.purity; const x = m.get(k) || { k, sold: 0, pcs: 0, stock: 0, spcs: 0 }; x.sold += l.net; x.pcs += l.pcs; m.set(k, x); });
    S.products.filter(stockLive).forEach(p => { const k = p.category + ' ' + p.purity; const x = m.get(k) || { k, sold: 0, pcs: 0, stock: 0, spcs: 0 }; x.stock += num(p.net); x.spcs += Math.max(1, num(p.pcs) || 1); m.set(k, x); });
    const X = [...m.values()].map(x => ({ ...x, perDay: x.sold / days, dos: x.sold > 0 ? x.stock / (x.sold / days) : null, turn: x.stock > 0 ? x.sold / x.stock : null })).sort((a, b) => (a.dos == null ? 1e9 : a.dos) - (b.dos == null ? 1e9 : b.dos));
    const cols = [C('Category + purity', 's', 2.6), C('Bika g', 'g'), C('Bike pcs', 'n', .8), C('Stock g', 'g'), C('Stock pcs', 'n', .8), C('Roz ki bikri g', 'g'), C('Stock kitne din', 's', 1.1), C('Speed', 's', 1.1)];
    const rows = X.map(x => [x.k, x.sold, x.pcs, x.stock, x.spcs, x.perDay, x.dos == null ? (x.stock > 0 ? 'bika nahi' : '—') : Math.round(x.dos) + ' din', x.dos == null ? (x.stock > 0 ? '🔴 Slow' : '') : x.dos <= 30 ? '🟢 Fast' : x.dos <= 120 ? '🟡 Theek' : '🔴 Slow']);
    return { summary: [['Fast', X.filter(x => x.dos != null && x.dos <= 30).length], ['Slow', X.filter(x => x.dos == null ? x.stock > 0 : x.dos > 120).length]], sections: [sec('', cols, rows)], note: 'Fast = 30 din se kam ka stock (order karo). Slow = 120 din se zyada ya bika hi nahi (discount / exchange par socho).' };
  } });

  rep('reorder', 'stock', 'Re-order / kam stock', 'Jo maal 15 din mein khatam ho jayega — supplier ko order bhejne ki list', { defRp: '30', build(r) {
    const days = Math.max(1, daysBetween(r.a, r.b) + 1); const m = new Map();
    saleLines(r.a, r.b).forEach(l => { const k = l.category + '|' + l.purity; const x = m.get(k) || { cat: l.category, pur: l.purity, sold: 0, stock: 0 }; x.sold += l.net; m.set(k, x); });
    S.products.filter(stockLive).forEach(p => { const k = p.category + '|' + p.purity; const x = m.get(k); if (x) x.stock += num(p.net); });
    const X = [...m.values()].map(x => ({ ...x, need: x.sold / days * 30 - x.stock, dos: x.stock / (x.sold / days) })).filter(x => x.dos < 15).sort((a, b) => a.dos - b.dos);
    const cols = [C('Category', 's', 2), C('Purity', 's', 1.2), C('Bika (period) g', 'g'), C('Stock g', 'g'), C('Stock kitne din', 'n'), C('30 din ke liye mangao g', 'g')];
    const rows = X.map(x => [x.cat, x.pur, x.sold, x.stock, x.dos, Math.max(0, x.need)]);
    return { summary: [['Order chahiye', X.length + ' items']], sections: [sec('', cols, rows, { empty: 'Sab maal 15 din se zyada ka hai. 👍' })] };
  } });

  rep('approval', 'stock', 'Approval / memo outstanding', 'Approval par gaya maal jo abhi wapas ya bill nahi hua', { period: 'none', build() {
    const L = (S.approvals || []).map(a => ({ a, c: apCalc(a) })).filter(x => x.c.open).sort((x, y) => y.c.overdue - x.c.overdue);
    const cols = [C('Memo', 's', 1.3), C('Date', 'd', 1), C('Party', 's', 2.4), C('Wapsi date', 'd', 1), C('Bahar pcs', 'n', .8), C('Bahar net g', 'g'), C('Bahar fine g', 'g'), C('Value (aaj)', 'inr'), C('Late din', 'n', .8)];
    const rows = L.map(({ a, c }) => [a.no, a.date, a.partyName, a.returnBy || '', c.out.pcs, c.out.net, c.out.fine, sum((a.lines || []).filter(l => (l.status || 'out') === 'out'), l => num(l.net) * ((PUR[l.purity] || {}).t || 0) / 100 * rateFor(metalOf(l.purity))), c.overdue || '']);
    return { summary: [['Khule memo', L.length], ['Bahar net', g3(sum(L, x => x.c.out.net))], ['Late', L.filter(x => x.c.overdue).length]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [8]), empty: 'Koi maal approval par bahar nahi hai.' })] };
  } });

  rep('huid', 'stock', 'HUID register', 'Har HUID wala piece — stock mein ya bika, kisko, kis bill se', { period: 'none', build() {
    const L = S.products.filter(p => p.huid).sort((a, b) => String(a.huid).localeCompare(String(b.huid)));
    const cols = [C('HUID', 's', 1.1), C('SKU', 's', 1.1), C('Item', 's', 2.2), C('Purity', 's', 1), C('Gross g', 'g'), C('Net g', 'g'), C('Status', 's', 1), C('Bika kisko', 's', 2), C('Bill', 's', 1.4), C('Date', 'd', 1)];
    const rows = L.map(p => [p.huid, p.sku, p.category + (p.making ? ' · ' + p.making : ''), p.purity, p.gross, p.net, p.status, p.soldTo || '', p.soldInvoice || '', p.soldDate || '']);
    const noH = S.products.filter(p => stockLive(p) && metalOf(p.purity) === 'gold' && !p.huid).length;
    return { summary: [['HUID pieces', L.length], ['Stock mein', L.filter(stockLive).length], ['Gold bina HUID (stock)', noH]], sections: [sec('', cols, rows, { empty: 'Abhi kisi piece par HUID nahi bhara gaya.' })] };
  } });

  rep('tagsrfid', 'stock', 'Tags pending & RFID audit', 'Tag print baaki, RFID jodna baaki, audit history', { period: 'none', link: () => goTo('vault', { vTab: 'tags' }) });
  rep('stocktrend', 'stock', 'Stock value trend', 'Roz ka stock snapshot — value aur fine ka graph', { build(r) {
    const L = (S.stockSnaps || []).filter(x => inRange(x.date || x.id, r.a, r.b)).sort((a, b) => String(a.date || a.id).localeCompare(String(b.date || b.id)));
    const cols = [C('Date', 'd', 1), C('Gold pcs', 'n'), C('Gold fine g', 'g'), C('Gold value', 'inr'), C('Silver pcs', 'n'), C('Silver fine g', 'g'), C('Silver value', 'inr'), C('Total value', 'inr')];
    const rows = L.map(x => { const g = x.g || {}, s = x.s || {}; return [x.date || x.id, g.pcs, g.fine, g.val, s.pcs, s.fine, s.val, num(g.val) + num(s.val)]; });
    return { summary: [['Snapshots', L.length]], sections: [sec('', cols, rows, { empty: 'Stock snapshot roz apne aap banta hai — kuch din baad yahan dikhega.' })], chart: lineHtml(rows.map(x => [fmtD(x[0]).slice(0, 5), x[7]]), inr) };
  } });

  /* =====================================================================
     C. METAL, KARIGAR & HALLMARK
     ===================================================================== */
  rep('finebal', 'metal', 'Party-wise fine metal balance', 'Metal bills ka baaki fine gold + paisa — har party', { period: 'none', build() {
    const m = new Map(); S.invoices.filter(v => v.type === 'metal' && inBook(v)).forEach(v => { const x = m.get(v.partyId) || { n: v.partyName, out: 0, inn: 0, fine: 0, rs: 0, last: '' }; x.out += num(T(v).fineOut); x.inn += num(T(v).fineIn) + sum(invPayments(v), p => p.fine); x.fine += invFineDue(v); x.rs += invDue(v); if (v.date > x.last) x.last = v.date; m.set(v.partyId, x); });
    const X = [...m.values()].filter(x => Math.abs(x.fine) > 0.0005 || Math.abs(x.rs) > 0.5).sort((a, b) => b.fine - a.fine);
    const cols = [C('Party', 's', 2.6), C('Fine diya g', 'g'), C('Fine wapas g', 'g'), C('Fine baaki g', 'g'), C('Value (aaj)', 'inr'), C('Paisa baaki', 'inr'), C('Last bill', 'd', 1)];
    const rows = X.map(x => [x.n, x.out, x.inn, x.fine, x.fine * rateFor('gold'), x.rs, x.last]);
    return { summary: [['Parties', X.length], ['Fine baaki', g3(sum(X, x => x.fine))], ['Paisa baaki', inr(sum(X, x => x.rs))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [6]), empty: 'Kisi party ka fine metal baaki nahi hai.' })] };
  } });

  rep('oldgold', 'metal', 'Old gold / silver purchase register', 'Purana sona-chandi: kharid voucher + bill mein exchange — gross, tunch, fine, value', { build(r) {
    const rows = [];
    INVS(r.a, r.b, v => v.type === 'oldgold').forEach(v => (v.items || []).forEach(it => rows.push(row([v.date, v.no, 'Old gold voucher', v.partyName, metalName(metalOf(it.purity)), it.gross, it.tunch, num(it.fine) || r3(num(it.net) * num(it.tunch) / 100), it.amount, v.partyPan || (custById(v.partyId) || {}).pan || ''], { _inv: v.id }))));
    INVS(r.a, r.b, v => saleSide(v)).forEach(v => (v.oldMetal || []).forEach(o => rows.push(row([v.date, v.no, v.type === 'metal' ? 'Metal received' : 'Exchange in bill', v.partyName, metalName(o.metal || 'gold'), num(o.gross || o.weight || o.net), o.tunch, o.fine, num(o.value) || (typeof calcOld === 'function' ? calcOld(o).value : 0), v.partyPan || (custById(v.partyId) || {}).pan || ''], { _inv: v.id }))));
    rows.sort((a, b) => String(a[0]).localeCompare(String(b[0])));
    const cols = [C('Date', 'd', 1), C('Bill / voucher', 's', 1.6), C('Kaise', 's', 1.4), C('Party', 's', 2.2), C('Metal', 's', .8), C('Gross g', 'g'), C('Tunch %', 'pct'), C('Fine g', 'g'), C('Value', 'inr'), C('PAN', 's', 1.1)];
    return { summary: [['Entries', rows.length], ['Fine aaya', g3(sum(rows, x => x[7]))], ['Value', inr(sum(rows, x => x[8]))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [6]) })] };
  } });

  const jobsIn = (r, f) => (S.jobs || []).filter(j => j.status !== 'Cancelled' && (!r || inRange(j.issueDate || '', r.a, r.b)) && (!f || f(j)));
  rep('karigar', 'metal', 'Karigar issue / receipt register', 'Har job: diya, wapas aaya, wastage, fine baaki, labour', { build(r) {
    const L = jobsIn(r).sort((a, b) => String(a.issueDate).localeCompare(String(b.issueDate)));
    const cols = [C('Job', 's', 1.1), C('Karigar', 's', 1.8), C('Item', 's', 1.6), C('Purity', 's', .9), C('Diya date', 'd', 1), C('Diya g', 'g'), C('Diya fine g', 'g'), C('Aaya g', 'g'), C('Scrap g', 'g'), C('Wastage %', 'pct'), C('Credit fine g', 'g'), C('Fine baaki g', 'g'), C('Labour ₹', 'inr'), C('Status', 's', 1)];
    const rows = L.map(j => { const c = jobCalc(j); return [j.no, j.karigarName, [j.category, j.making].filter(Boolean).join(' · '), j.purity, j.issueDate, j.issuedWt, c.issuedFine, j.receivedWt || '', j.scrapWt || '', j.wastage, c.received ? c.credited : '', c.balance, c.labourAmt, j.status]; });
    return { summary: [['Jobs', L.length], ['Khule', L.filter(j => j.status === 'Issued').length], ['Fine baaki', g3(sum(rows, x => x[11]))], ['Labour', inr(sum(rows, x => x[12]))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [9]) })] };
  } });

  rep('karigarloss', 'metal', 'Karigar / melting loss (yield)', 'Har karigar ka fine loss % — kahan sona-chandi kam ho raha hai', { build(r) {
    const m = new Map(); jobsIn(r, j => j.status === 'Received').forEach(j => { const c = jobCalc(j); const t = c.t; const x = m.get(j.karigarName) || { k: j.karigarName || '—', jobs: 0, issW: 0, recW: 0, scrap: 0, issF: 0, physF: 0, cred: 0, lab: 0 }; x.jobs++; x.issW += num(j.issuedWt); x.recW += num(j.receivedWt); x.scrap += num(j.scrapWt); x.issF += c.issuedFine; x.physF += r3((num(j.receivedWt) + num(j.scrapWt)) * t / 100); x.cred += c.credited; x.lab += c.labourAmt; m.set(x.k, x); });
    const X = [...m.values()].map(x => ({ ...x, loss: x.issF - x.physF, lossPct: pctOf(x.issF - x.physF, x.issF), bal: x.issF - x.cred })).sort((a, b) => b.lossPct - a.lossPct);
    const cols = [C('Karigar', 's', 2.2), C('Jobs', 'n', .7), C('Diya g', 'g'), C('Aaya + scrap g', 'g'), C('Diya fine g', 'g'), C('Physical fine wapas g', 'g'), C('Loss fine g', 'g'), C('Loss %', 'pct'), C('Wastage di g', 'g'), C('Fine baaki g', 'g'), C('Labour ₹', 'inr')];
    const rows = X.map(x => [x.k, x.jobs, x.issW, x.recW + x.scrap, x.issF, x.physF, x.loss, x.lossPct, x.cred - x.physF, x.bal, x.lab]);
    return { summary: [['Karigar', X.length], ['Total loss', g3(sum(X, x => x.loss))], ['Avg loss', (pctOf(sum(X, x => x.loss), sum(X, x => x.issF))).toFixed(2) + '%']], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [7]) })], note: 'Loss = diya fine − (aaya + scrap) ka fine. Isme karigar ko di gayi wastage shamil hai — "Wastage di" alag dikhayi gayi hai. Yahi 3CD ke "yield / shortage" ke liye CA ko chahiye.' };
  } });

  rep('kdelay', 'metal', 'Karigar pending jobs & delays', 'Karigar ke paas pada kaam — delivery date se kitna late', { period: 'none', build() {
    const t = today(); const L = jobsIn(null, j => j.status === 'Issued').map(j => ({ j, late: j.dueDate && j.dueDate < t ? daysBetween(j.dueDate, t) : 0 })).sort((a, b) => b.late - a.late);
    const cols = [C('Job', 's', 1.1), C('Karigar', 's', 2), C('Item', 's', 2), C('Diya date', 'd', 1), C('Delivery date', 'd', 1), C('Diya g', 'g'), C('Fine g', 'g'), C('Late din', 'n', .8), C('Status', 's', 1)];
    const rows = L.map(({ j, late }) => [j.no, j.karigarName, [j.category, j.making].filter(Boolean).join(' · '), j.issueDate, j.dueDate, j.issuedWt, jobCalc(j).issuedFine, late || '', late ? '🔴 Late' : '🟢 Time par']);
    return { summary: [['Khule jobs', L.length], ['Late', L.filter(x => x.late).length], ['Karigar ke paas fine', g3(sum(rows, x => x[6]))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [7]), empty: 'Karigar ke paas koi kaam pending nahi.' })] };
  } });

  rep('hallmark', 'metal', 'Hallmarking register', 'Hallmark centre bheja-aaya, pcs, charges, HUID', { build(r) {
    const L = (S.hallmark || []).filter(h => inRange(h.date, r.a, r.b)).sort((a, b) => String(a.date).localeCompare(String(b.date)));
    const cols = [C('Date', 'd', 1), C('No', 's', 1.2), C('Centre', 's', 2), C('Pcs', 'n', .7), C('Gross g', 'g'), C('Rate/pc', 'inr2'), C('Charges', 'inr'), C('HUID bhare', 'n', .9), C('Status', 's', 1), C('Din', 'n', .7)];
    const rows = L.map(h => { const c = hmCalc(h); return [h.date, h.no, h.centre || h.center || h.partyName || '', c.pcs, c.gross, h.rate, c.charge, c.huidDone, h.status, c.days || '']; });
    return { summary: [['Lots', L.length], ['Pcs', sum(rows, x => x[3])], ['Charges', inr(sum(rows, x => x[6]))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [5, 9]) })] };
  } });

  /* =====================================================================
     D. PROFIT
     ===================================================================== */
  rep('wastageprofit', 'profit', 'Wastage profit (kharid vs bikri wastage)', 'Category + purity: kharid wastage, bikri wastage, fark, profit fine + ₹', { build(r) {
    const G = groupLines(saleLines(r.a, r.b), 'catpur').sort((a, b) => b.gainValue - a.gainValue);
    const cols = [C('Category + purity', 's', 2.6), C('Net bika g', 'g'), C('Bikri wastage', 'pct'), C('Kharid wastage', 'pct'), C('Fark', 'pct'), C('Profit fine g', 'g'), C('Profit ₹', 'inr'), C('Ghaate lines', 'n', .8)];
    const rows = G.map(x => [x.key, x.net, x.avgW, x.avgCostW == null ? '' : x.avgCostW, x.avgCostW == null ? '' : x.avgW - x.avgCostW, x.gainFine, x.gainValue, x.loss || '']);
    return { summary: [['Profit fine', g3(sum(G, x => x.gainFine))], ['Profit ₹', inr(sum(G, x => x.gainValue))], ['Ghaate lines', sum(G, x => x.loss)]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [2, 3, 4]) })], chart: barsHtml(G.slice(0, 12).map(x => [x.key, x.gainValue]), inr) };
  } });

  rep('billprofit', 'profit', 'Bill-wise profit', 'Har bill ka revenue, cost, profit, margin % — ghaate wale bill upar', { build(r) {
    const L = advProfitIn(r.a, r.b).sort((a, b) => a.profit - b.profit);
    const cols = [C('Date', 'd', 1), C('Bill', 's', 1.6), C('Party', 's', 2.4), C('Sector', 's', 1), C('Revenue', 'inr'), C('Cost', 'inr'), C('Profit', 'inr'), C('Margin', 'pct'), C('Cost pata', 's', .9)];
    const rows = L.map(x => row([x.v.date, x.v.no, x.v.partyName, chanOf(x.v) === 'wholesale' ? 'Wholesale' : 'Retail', x.revenue, x.cost, x.profit, x.margin, x.known + '/' + x.lines.length], { _inv: x.v.id }));
    const rev = sum(L, x => x.revenue), pf = sum(L, x => x.profit);
    return { summary: [['Bills', L.length], ['Revenue', inr(rev)], ['Profit', inr(pf)], ['Margin', pctOf(pf, rev).toFixed(2) + '%'], ['Ghaate ke bills', L.filter(x => x.profit < -0.5).length]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [7]) })] };
  } });

  rep('partyprofit', 'profit', 'Party-wise profitability', 'Kaunsi party sach mein kamaai deti hai — profit, margin, udhaari ke saath', { build(r) {
    const m = new Map(); advProfitIn(r.a, r.b).forEach(x => { const k = x.v.partyId || x.v.partyName; const y = m.get(k) || { n: x.v.partyName, id: x.v.partyId, bills: 0, rev: 0, cost: 0, pf: 0 }; y.bills++; y.rev += x.revenue; y.cost += x.cost; y.pf += x.profit; m.set(k, y); });
    const X = [...m.values()].sort((a, b) => b.pf - a.pf);
    const cols = [C('Party', 's', 2.6), C('Type', 's', 1), C('Bills', 'n', .7), C('Revenue', 'inr'), C('Profit', 'inr'), C('Margin', 'pct'), C('Abhi baaki', 'inr'), C('Profit hissa', 'pct')];
    const tp = sum(X, x => x.pf);
    const rows = X.map(x => { const c = custById(x.id); return [x.n, c ? ptypeOf(c) : '', x.bills, x.rev, x.pf, pctOf(x.pf, x.rev), x.id ? partyDue(x.id, 'customer') : '', pctOf(x.pf, tp)]; });
    return { summary: [['Parties', X.length], ['Profit', inr(tp)], ['Top 10 ka hissa', pctOf(sum(X.slice(0, 10), x => x.pf), tp).toFixed(1) + '%']], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [5, 7]) })] };
  } });

  /* ---- P&L and Balance sheet (double entry books) ---- */
  const stockCfg = () => { const s = settings(); return { open: num(s.rcOpenStock), close: s.rcCloseStock === '' || s.rcCloseStock == null ? null : num(s.rcCloseStock) }; };
  function pnlData(a, b) {
    const D = deBuild(ui.rpBook === 'pakka' ? 'pakka' : 'both'); const bal = deBalances(D, b, a); const A = D.A;
    const val = id => -num(bal[id]); const ex = id => num(bal[id]);
    const ids = Object.keys(A).filter(id => Math.abs(num(bal[id])) >= 0.005);
    const sales = ids.filter(id => /^(sales:|unb:)/.test(id)), ret = ids.filter(id => id === 'salesret');
    const purch = ids.filter(id => /^(pur:|oldgold$)/.test(id)), pret = ids.filter(id => id === 'purret');
    const direct = ids.filter(id => /^exp:(Hallmarking|Packaging|Transport)$/.test(id));
    const indirect = ids.filter(id => A[id].g === 'E' && !purch.includes(id) && !pret.includes(id) && !direct.includes(id));
    const otherInc = ids.filter(id => A[id].g === 'I' && !sales.includes(id) && !ret.includes(id));
    const sc = stockCfg(); const closeStock = sc.close != null ? sc.close : deStockCost().value; const openStock = sc.open;
    const netSales = sum(sales, val) + sum(ret, val); const cogs = openStock + sum(purch, ex) + sum(pret, ex) + sum(direct, ex) - closeStock;
    const gp = netSales - cogs; const np = gp + sum(otherInc, val) - sum(indirect, ex);
    return { D, A, bal, sales, ret, purch, pret, direct, indirect, otherInc, val, ex, openStock, closeStock, netSales, cogs, gp, np, sc };
  }
  rep('pnl', 'profit', 'Profit & Loss statement (Trading + P&L)', 'Opening stock + kharid − closing stock, gross profit, kharche, net profit', { defRp: 'fy', tag: 'CA', build(r) {
    const P = pnlData(r.a, r.b); const n = id => P.A[id].name;
    const cols = [C('Particulars', 's', 4), C('Amount ₹', 'inr2', 1.4), C('Total ₹', 'inr2', 1.4)];
    const rows = [row(['TRADING ACCOUNT', '', ''], { _h: 1 }),
      row(['Sales', '', ''], { _b: 1 }), ...P.sales.map(id => ['  ' + n(id), P.val(id), '']), ...P.ret.map(id => ['  Less: ' + n(id), P.val(id), '']), row(['Net sales (A)', '', P.netSales], { _b: 1 }),
      ['Opening stock', P.openStock, ''], ...P.purch.map(id => ['Add: ' + n(id), P.ex(id), '']), ...P.pret.map(id => ['Less: ' + n(id), P.ex(id), '']), ...P.direct.map(id => ['Add: ' + n(id) + ' (direct)', P.ex(id), '']), ['Less: Closing stock (at cost)', -P.closeStock, ''], row(['Cost of goods sold (B)', '', P.cogs], { _b: 1 }),
      row(['GROSS PROFIT (A − B)', '', P.gp], { _b: 1 }),
      row(['PROFIT & LOSS ACCOUNT', '', ''], { _h: 1 }),
      ['Gross profit', '', P.gp], ...P.otherInc.map(id => ['Add: ' + n(id), P.val(id), '']), ...P.indirect.map(id => ['Less: ' + n(id), -P.ex(id), '']),
      row([P.np >= 0 ? 'NET PROFIT' : 'NET LOSS', '', P.np], { _b: 1 })];
    return { summary: [['Net sales', inr(P.netSales)], ['Gross profit', inr(P.gp)], ['Net profit', inr(P.np)], ['GP %', pctOf(P.gp, P.netSales).toFixed(2) + '%'], ['NP %', pctOf(P.np, P.netSales).toFixed(2) + '%']], sections: [sec('', cols, rows)], tools: stockTools(), note: 'Closing stock = vault ka maal kharid rate par (aaj tak). Pichhle saal ka P&L dekh rahe hain to "Closing stock" khud bhariye. Opening stock pehle saal ka closing hai — Setup ke bina yahan bhar sakte hain (sirf Owner/Manager).' };
  } });

  rep('balsheet', 'profit', 'Balance sheet', 'Assets, liabilities, capital — kisi bhi din ka', { period: 'asof', tag: 'CA', build(r) {
    const D = deBuild(ui.rpBook === 'pakka' ? 'pakka' : 'both'); const bal = deBalances(D, r.b); const A = D.A; const ids = Object.keys(A).filter(id => Math.abs(num(bal[id])) >= 0.005);
    const sc = stockCfg(); const closeStock = sc.close != null ? sc.close : deStockCost().value; const openStock = sc.open;
    const debt = ids.filter(id => id.startsWith('cust:')), cred = ids.filter(id => id.startsWith('sup:'));
    const dPos = sum(debt.filter(id => bal[id] > 0), id => bal[id]), dNeg = -sum(debt.filter(id => bal[id] < 0), id => bal[id]);
    const cCr = -sum(cred.filter(id => bal[id] < 0), id => bal[id]), cDr = sum(cred.filter(id => bal[id] > 0), id => bal[id]);
    const other = g => ids.filter(id => A[id].g === g && !id.startsWith('cust:') && !id.startsWith('sup:'));
    const inc = sum(ids.filter(id => A[id].g === 'I'), id => -bal[id]), exp = sum(ids.filter(id => A[id].g === 'E'), id => bal[id]);
    const profit = inc - exp + closeStock - openStock;
    const capAcc = other('C'); const capital = sum(capAcc, id => -bal[id]) + openStock;
    const assetsList = [...other('A').map(id => [A[id].name, bal[id]]), ['Sundry debtors (' + debt.filter(id => bal[id] > 0).length + ' parties)', dPos], ['Advances to suppliers (debit balance)', cDr], ['Closing stock (at cost)', closeStock]].filter(x => Math.abs(x[1]) >= 0.5);
    const liabList = [...other('L').map(id => [A[id].name, -bal[id]]), ['Sundry creditors (' + cred.filter(id => bal[id] < 0).length + ' parties)', cCr], ['Customer advances (credit balance)', dNeg]].filter(x => Math.abs(x[1]) >= 0.5);
    const tA = sum(assetsList, x => x[1]), tL = sum(liabList, x => x[1]);
    const cols = [C('Particulars', 's', 4), C('Amount ₹', 'inr2', 1.4), C('Total ₹', 'inr2', 1.4)];
    const rows = [row(['CAPITAL & LIABILITIES', '', ''], { _h: 1 }), row(['Capital account', '', ''], { _b: 1 }), ...capAcc.map(id => ['  ' + A[id].name, -bal[id], '']), ...(openStock ? [['  Opening stock introduced', openStock, '']] : []), ['  Add: Profit / (loss) till date', profit, ''], row(['Capital total', '', capital + profit], { _b: 1 }),
      row(['Liabilities', '', ''], { _b: 1 }), ...liabList.map(x => ['  ' + x[0], x[1], '']), row(['Liabilities total', '', tL], { _b: 1 }), row(['TOTAL', '', capital + profit + tL], { _b: 1 }),
      row(['ASSETS', '', ''], { _h: 1 }), ...assetsList.map(x => ['  ' + x[0], x[1], '']), row(['TOTAL', '', tA], { _b: 1 })];
    const diff = r2(tA - (capital + profit + tL));
    return { summary: [['Total assets', inr(tA)], ['Capital', inr(capital + profit)], ['Liabilities', inr(tL)], ['Check', Math.abs(diff) < 1 ? '✓ Balanced' : 'Farak ' + inr(diff)]], sections: [sec('', cols, rows)], tools: stockTools(), note: 'Ye balance sheet aapke bills, payments, kharche aur bank entries se apne aap banti hai. Fixed assets aur loans tabhi aayenge jab unki entry Cash & Bank mein ho. Final balance sheet CA se check karwaiye.' };
  } });

  rep('rateimpact', 'profit', 'Bhaav ka asar (rate impact)', 'Stock par sona-chandi ke bhaav badalne se kitna fayda / nuksaan', { build(r) {
    const rows = []; ['gold', 'silver'].forEach(m => { const fine = sum(S.products.filter(p => stockLive(p) && metalOf(p.purity) === m), pFine); let ra = 0, rb = 0; try { ra = advRateAt(r.a, m); rb = advRateAt(r.b, m); } catch (e) { /* none */ } if (r.b >= today()) rb = rateFor(m) || rb; rows.push([metalName(m), fine, ra, rb, rb - ra, fine * (rb - ra)]); });
    const cols = [C('Metal', 's', 1.4), C('Stock fine g', 'g'), C('Bhaav shuru (₹/g)', 'inr2'), C('Bhaav ant (₹/g)', 'inr2'), C('Badlav ₹/g', 'inr2'), C('Stock par asar ₹', 'inr')];
    return { summary: [['Kul asar', inr(sum(rows, x => x[5]))]], sections: [sec('', cols, rows)], note: 'Aaj ke stock ke fine ko period ki shuruaat aur ant ke bhaav se guna kiya gaya hai (bhaav history se). Ye "kaagzi" fayda-nuksaan hai — maal bikne par hi asli hota hai.' };
  } });

  /* =====================================================================
     E. PARTIES & UDHAARI
     ===================================================================== */
  function partyRows(side, asOf) { const sup = side === 'supplier'; const m = new Map();
    S.invoices.forEach(v => { if (!inBook(v) || isBuy(v.type) !== sup || v.date > asOf) return; const x = m.get(v.partyId) || { id: v.partyId, n: v.partyName, bills: 0, val: 0, due: 0, fine: 0, last: '', oldest: '' }; x.bills++; x.val += invPayable(v); const d = dueAsOf(v, asOf); x.due += d; if (v.type === 'metal') x.fine += invFineDue(v); if (v.date > x.last) x.last = v.date; if (d > 0.5 && (!x.oldest || v.date < x.oldest)) x.oldest = v.date; m.set(v.partyId, x); });
    return [...m.values()]; }
  rep('outstanding', 'party', 'Party outstanding summary', 'Har customer / supplier: kitna baaki, fine baaki, sabse purana bill, credit limit', { period: 'asof', build(r) {
    const mk = side => { const X = partyRows(side, r.b).filter(x => Math.abs(x.due) > 0.5 || Math.abs(x.fine) > 0.0005).sort((a, b) => b.due - a.due); const P = side === 'supplier' ? supById : custById;
      return X.map(x => { const p = P(x.id) || {}; return [x.n, p.city || '', p.phone || '', x.bills, x.due, x.fine || '', x.oldest, x.oldest ? daysBetween(x.oldest, r.b) : '', num(p.creditLimit) || '']; }); };
    const cols = [C('Party', 's', 2.4), C('City', 's', 1.1), C('Phone', 's', 1.2), C('Bills', 'n', .6), C('Baaki ₹', 'inr'), C('Fine baaki g', 'g'), C('Sabse purana', 'd', 1), C('Din', 'n', .6), C('Credit limit', 'inr')];
    const A = mk('customer'), B = mk('supplier');
    return { summary: [['Lena hai (customers)', inr(sum(A, x => x[4]))], ['Dena hai (suppliers)', inr(sum(B, x => x[4]))], ['Customers', A.length], ['Suppliers', B.length]], sections: [sec('Customers — lena hai', cols, A, { foot: totalsRow(cols, A, 'Total', [3, 7, 8]) }), sec('Suppliers — dena hai', cols, B, { foot: totalsRow(cols, B, 'Total', [3, 7, 8]) })] };
  } });

  function ageRows(side, asOf) { const sup = side === 'supplier'; const m = new Map();
    S.invoices.forEach(v => { if (!inBook(v) || isBuy(v.type) !== sup || v.date > asOf) return; const d = dueAsOf(v, asOf); if (d <= 0.5) return; const age = daysBetween(v.date, asOf); const i = age <= 30 ? 0 : age <= 60 ? 1 : age <= 90 ? 2 : age <= 180 ? 3 : 4; const x = m.get(v.partyId) || { n: v.partyName, b: [0, 0, 0, 0, 0] }; x.b[i] += d; m.set(v.partyId, x); });
    return [...m.values()].map(x => [x.n, ...x.b, sum(x.b)]).sort((a, b) => b[6] - a[6]); }
  const ageCols = [C('Party', 's', 2.6), C('0–30 din', 'inr'), C('31–60', 'inr'), C('61–90', 'inr'), C('91–180', 'inr'), C('180+', 'inr'), C('Total', 'inr')];
  rep('ageing', 'party', 'Receivable ageing (udhaari kitni purani)', 'Har customer ka baaki — 0-30 / 31-60 / 61-90 / 91-180 / 180+ din', { period: 'asof', build(r) {
    const rows = ageRows('customer', r.b); const t = totalsRow(ageCols, rows);
    return { summary: [['Kul udhaari', inr(t[6])], ['90 din se upar', inr(num(t[4]) + num(t[5]))], ['Parties', rows.length]], sections: [sec('', ageCols, rows, { foot: t })], chart: barsHtml([['0–30', t[1]], ['31–60', t[2]], ['61–90', t[3]], ['91–180', t[4]], ['180+', t[5]]], inr) };
  } });
  rep('payables', 'party', 'Supplier payable & ageing', 'Suppliers ko kitna dena hai — kitna purana', { period: 'asof', build(r) {
    const rows = ageRows('supplier', r.b); const t = totalsRow(ageCols, rows);
    return { summary: [['Kul dena', inr(t[6])], ['Suppliers', rows.length]], sections: [sec('', ageCols, rows, { foot: t })] };
  } });

  rep('followup', 'party', 'Payment follow-up list (aaj kisko call karein)', 'Overdue parties — kitne din late, kitna baaki, WhatsApp button', { period: 'none', build() {
    const t = today(); const m = new Map();
    S.invoices.forEach(v => { if (!inBook(v) || isBuy(v.type)) return; const d = invDue(v); if (d <= 0.5) return; const dd = invDueDate(v); const x = m.get(v.partyId) || { id: v.partyId, n: v.partyName, due: 0, over: 0, late: 0, bills: 0 }; x.due += d; x.bills++; if (dd < t) { x.over += d; x.late = Math.max(x.late, daysBetween(dd, t)); } m.set(v.partyId, x); });
    const X = [...m.values()].filter(x => x.over > 0.5).sort((a, b) => b.over * (1 + b.late / 30) - a.over * (1 + a.late / 30));
    const s = settings();
    const cols = [C('#', 'n', .4), C('Party', 's', 2.4), C('Phone', 's', 1.2), C('City', 's', 1.1), C('Overdue ₹', 'inr'), C('Kul baaki ₹', 'inr'), C('Late din', 'n', .7), C('Bills', 'n', .6), C('WhatsApp', 'x', 1)];
    const rows = X.map((x, i) => { const c = custById(x.id) || {}; const ph = String(c.phone || '').replace(/\D/g, '').slice(-10); const msg = `Namaste ${x.n} ji 🙏\n${s.firm} — aapka ${inr(x.over)} ka payment ${x.late} din se baaki hai (kul baaki ${inr(x.due)}). Kripya jaldi bhijwa dein.${s.upi ? '\nUPI: ' + s.upi : ''}\nDhanyavaad`;
      return [i + 1, x.n, c.phone || '', c.city || '', x.over, x.due, x.late, x.bills, ph.length === 10 ? `<a class="btn sm green" target="_blank" rel="noopener" href="https://wa.me/91${ph}?text=${encodeURIComponent(msg)}">WhatsApp</a>` : '—']; });
    return { summary: [['Call karna hai', X.length], ['Overdue', inr(sum(X, x => x.over))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [0, 6, 7]), empty: 'Koi payment overdue nahi. 🎉' })] };
  } });

  rep('creditlimit', 'party', 'Credit limit breach', 'Jinki udhaari credit limit ke 80% se upar hai', { period: 'none', build() {
    const X = S.customers.map(c => ({ c, due: partyDue(c.id, 'customer'), lim: num(c.creditLimit) })).filter(x => x.lim > 0 && x.due >= 0.8 * x.lim).sort((a, b) => b.due / b.lim - a.due / a.lim);
    const cols = [C('Party', 's', 2.6), C('City', 's', 1.2), C('Credit limit', 'inr'), C('Baaki', 'inr'), C('Use %', 'pct'), C('Credit din', 'n', .8), C('Status', 's', 1.2)];
    const rows = X.map(x => [x.c.name, x.c.city || '', x.lim, x.due, pctOf(x.due, x.lim), x.c.creditDays || '', x.due > x.lim ? '🔴 Limit paar' : '🟡 80%+']);
    return { summary: [['Limit paar', X.filter(x => x.due > x.lim).length], ['80%+', X.length]], sections: [sec('', cols, rows, { empty: 'Koi customer credit limit ke paas nahi. 👍' })] };
  } });

  rep('dormant', 'party', 'Dormant parties (jo ab nahi aate)', 'Customers jinka 60+ din se koi bill nahi — kitna becha tha, kab aaye the', { period: 'none', build() {
    const t = today(); const last = new Map(), life = new Map(); S.invoices.forEach(v => { if (isBuy(v.type) || !inBook(v)) return; if (!last.has(v.partyId) || v.date > last.get(v.partyId)) last.set(v.partyId, v.date); life.set(v.partyId, (life.get(v.partyId) || 0) + invPayable(v)); });
    const X = S.customers.filter(c => last.has(c.id) && daysBetween(last.get(c.id), t) >= 60).map(c => ({ c, d: last.get(c.id), gap: daysBetween(last.get(c.id), t), v: life.get(c.id) })).sort((a, b) => b.v - a.v);
    const never = S.customers.filter(c => !last.has(c.id));
    const cols = [C('Party', 's', 2.6), C('Type', 's', .9), C('City', 's', 1.2), C('Phone', 's', 1.2), C('Last bill', 'd', 1), C('Din se nahi aaye', 'n', 1), C('Ab tak ki kharid', 'inr')];
    const rows = X.map(x => [x.c.name, ptypeOf(x.c), x.c.city || '', x.c.phone || '', x.d, x.gap, x.v]);
    const c2 = [C('Party', 's', 2.6), C('Type', 's', .9), C('City', 's', 1.2), C('Phone', 's', 1.2), C('Jude', 'd', 1)];
    const r2_ = never.map(c => [c.name, ptypeOf(c), c.city || '', c.phone || '', tsDay(c.createdAt)]);
    return { summary: [['60+ din se nahi aaye', X.length], ['Kabhi kharida hi nahi', never.length]], sections: [sec('Purane customers — wapas bulao', cols, rows), sec('Jude par kabhi bill nahi bana', c2, r2_)] };
  } });

  rep('estconv', 'party', 'Order estimate conversion', 'Kitne estimate bheje, kitni deal hui, kyun nahi hui', { build(r) {
    const L = (S.estimates || []).filter(e => inRange(e.date || tsDay(e.createdAt), r.a, r.b));
    const by = s => L.filter(e => e.status === s).length; const won = by('Won'), lost = by('Lost');
    const reasons = new Map(); L.filter(e => e.status === 'Lost').forEach(e => { const k = e.lostReason || '(kaaran nahi likha)'; reasons.set(k, (reasons.get(k) || 0) + 1); });
    const cols = [C('Date', 'd', 1), C('No', 's', 1.2), C('Party', 's', 2.4), C('Items', 'n', .7), C('Status', 's', 1), C('Kaaran', 's', 2.4)];
    const rows = L.sort((a, b) => String(b.date).localeCompare(String(a.date))).map(e => [e.date, e.no, e.partyName, (e.items || []).length, e.status === 'Won' ? 'Deal hui' : e.status === 'Lost' ? 'Nahi hui' : e.status || 'Pending', e.lostReason || '']);
    return { summary: [['Estimates', L.length], ['Deal hui', won], ['Nahi hui', lost], ['Conversion', pctOf(won, won + lost).toFixed(1) + '%']], sections: [sec('Na hone ke kaaran', [C('Kaaran', 's', 4), C('Kitne', 'n')], [...reasons].sort((a, b) => b[1] - a[1])), sec('Sab estimates', cols, rows)] };
  } });
  rep('partyledger', 'party', 'Party ledger / statement', 'Kisi bhi party ka poora khata — opening, har bill, payment, running balance (PDF bhi)', { period: 'none', link: () => goTo('accounts', { accTab: 'party' }) });

  /* =====================================================================
     F. GST & TAX
     ===================================================================== */
  rep('gstr1', 'tax', 'GSTR-1 summary', 'B2B, B2C large, B2C small, HSN — return bharne ke liye', { defRp: 'lastmonth', build(r) {
    const G = gstr1(r.a, r.b); const c = [C('GSTIN / Place', 's', 2.4), C('Bill', 's', 1.6), C('Date', 'd', 1), C('Taxable', 'inr2'), C('IGST', 'inr2'), C('CGST', 'inr2'), C('SGST', 'inr2'), C('Total', 'inr2')];
    const b2b = G.b2b.map(x => row([x.gstin + ' · ' + x.v.partyName, x.v.no, x.v.date, x.tx, x.ia, x.ca, x.sa, x.val], { _inv: x.v.id }));
    const b2cl = G.b2cl.map(x => row([posName(x.pos), x.v.no, x.v.date, x.tx, x.ia, x.ca, x.sa, x.val], { _inv: x.v.id }));
    const b2cs = G.b2cs.map(x => [posName(x.pos) + (x.inter ? ' (inter-state)' : ' (intra)'), '', '', x.tx, x.ia, x.ca, x.sa, x.val]);
    const hc = [C('HSN', 's', 1), C('Description', 's', 2.4), C('Qty (g)', 'g'), C('Taxable', 'inr2'), C('IGST', 'inr2'), C('CGST', 'inr2'), C('SGST', 'inr2'), C('Total', 'inr2')];
    const hsn = [...G.hsnB2B.map(x => ['B2B', x]), ...G.hsnB2C.map(x => ['B2C', x])].map(([k, x]) => [x.code + ' · ' + k, x.desc, x.qty, x.tx, x.ia, x.ca, x.sa, x.val]);
    return { summary: [['GST bills', G.sales.length], ['Taxable', inr(G.tot.tx)], ['Tax', inr(G.tot.ia + G.tot.ca + G.tot.sa)], ['Invoice value', inr(G.tot.val)]], warn: G.warn, sections: [sec('4A — B2B (registered)', c, b2b, { foot: totalsRow(c, b2b, 'Total', [2]) }), sec('5A — B2C large (inter-state > ₹1 lakh)', c, b2cl, { foot: totalsRow(c, b2cl, 'Total', [2]) }), sec('7 — B2C small', c, b2cs, { foot: totalsRow(c, b2cs, 'Total', [2]) }), sec('12 — HSN summary', hc, hsn, { foot: totalsRow(hc, hsn, 'Total', [2]) })] };
  } });

  function gstMonth(a, b) { const out = INVS(a, b, v => v.type === 'sale'), inn = S.invoices.filter(v => v.type === 'purchase' && inRange(v.date, a, b)); const cn = (S.cdn || []).filter(c => inRange(c.date, a, b));
    const t = (L, k) => r2(sum(L, v => T(v)[k] != null ? T(v)[k] : v[k])); const cr = cn.filter(c => c.kind === 'credit'), dr = cn.filter(c => c.kind !== 'credit');
    return { otx: t(out, 'taxable'), oc: t(out, 'cgst'), os: t(out, 'sgst'), oi: t(out, 'igst'), itx: t(inn, 'taxable'), ic: t(inn, 'cgst'), is: t(inn, 'sgst'), ii: t(inn, 'igst'), crtx: r2(sum(cr, c => c.taxable)), crt: r2(sum(cr, c => num(c.cgst) + num(c.sgst) + num(c.igst))), drtx: r2(sum(dr, c => c.taxable)), drt: r2(sum(dr, c => num(c.cgst) + num(c.sgst) + num(c.igst))), nOut: out.length, nIn: inn.length }; }
  rep('gstr3b', 'tax', 'GSTR-3B summary (tax payable)', 'Output tax − ITC = cash mein kitna GST bharna hai', { defRp: 'lastmonth', build(r) {
    const g = gstMonth(r.a, r.b); const outT = g.oc + g.os + g.oi - g.crt, itc = g.ic + g.is + g.ii - g.drt;
    const cols = [C('Particulars', 's', 3.6), C('Taxable', 'inr2'), C('IGST', 'inr2'), C('CGST', 'inr2'), C('SGST', 'inr2'), C('Total tax', 'inr2')];
    const rows = [['3.1(a) Outward taxable supplies', g.otx, g.oi, g.oc, g.os, g.oi + g.oc + g.os], ['Less: credit notes', -g.crtx, '', '', '', -g.crt], row(['Output tax', '', '', '', '', outT], { _b: 1 }), ['4(A) ITC — purchases', g.itx, g.ii, g.ic, g.is, g.ii + g.ic + g.is], ['Less: debit notes (ITC reversal)', -g.drtx, '', '', '', -g.drt], row(['Net ITC', '', '', '', '', itc], { _b: 1 }), row([outT - itc >= 0 ? 'GST bharna hai (cash)' : 'ITC aage jayega', '', '', '', '', Math.abs(outT - itc)], { _b: 1 })];
    return { summary: [['Output tax', inr(outT)], ['ITC', inr(itc)], [outT - itc >= 0 ? 'Bharna hai' : 'Carry forward', inr(Math.abs(outT - itc))]], sections: [sec('', cols, rows)], note: 'ITC sirf un purchase bills ka milta hai jo supplier ne GSTR-1 mein bhare hon (GSTR-2B se milaiye — Pakka/Kacha → GST mein 2B match hai).' };
  } });

  rep('itc', 'tax', 'Purchase GST register (ITC)', 'Har GST purchase bill: supplier GSTIN, taxable, CGST/SGST/IGST', { defRp: 'lastmonth', build(r) {
    const L = S.invoices.filter(v => v.type === 'purchase' && inRange(v.date, r.a, r.b)).sort((a, b) => a.date.localeCompare(b.date));
    const cols = [C('Date', 'd', 1), C('Bill no', 's', 1.5), C('Supplier', 's', 2.4), C('GSTIN', 's', 1.6), C('Taxable', 'inr2'), C('IGST', 'inr2'), C('CGST', 'inr2'), C('SGST', 'inr2'), C('Total', 'inr2'), C('GSTIN theek', 's', .8)];
    const rows = L.map(v => { const g = String(v.partyGstin || (supById(v.partyId) || {}).gstin || '').toUpperCase(); return row([v.date, v.supplierBillNo || v.no, v.partyName, g, T(v).taxable, T(v).igst, T(v).cgst, T(v).sgst, T(v).grand, RX.gstin.test(g) ? '✓' : '✗'], { _inv: v.id }); });
    return { summary: [['Bills', L.length], ['ITC', inr(sum(L, v => num(T(v).cgst) + num(T(v).sgst) + num(T(v).igst)))], ['GSTIN galat', rows.filter(x => x[9] === '✗').length]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows) })] };
  } });

  /* cash rules */
  function cashChecks(a, b) {
    const R = { st: [], pan: [], a3: [], loans: [] };
    const day = new Map(); payRows(a, b).filter(p => !p.buy && isCash(p.mode)).forEach(p => { const k = p.v.partyId + '|' + p.date; const x = day.get(k) || { d: p.date, n: p.v.partyName, id: p.v.partyId, amt: 0, bills: new Set() }; x.amt += p.amt; x.bills.add(p.v.no); day.set(k, x); });
    day.forEach(x => { if (x.amt >= 200000) R.st.push([x.d, x.n, [...x.bills].join(', '), x.amt, 'Ek din mein ek party se ₹2 lakh+ cash']); });
    INVS(a, b, v => !isBuy(v.type)).forEach(v => { const c = sum(invPayments(v).filter(p => isCash(p.mode)), p => p.amount); if (c >= 200000 && ![...day.values()].some(x => x.id === v.partyId && x.amt >= 200000 && x.bills.has(v.no))) R.st.push([v.date, v.partyName, v.no, c, 'Ek bill par ₹2 lakh+ cash (alag-alag din)']); });
    INVS(a, b, v => saleSide(v) && invPayable(v) >= 200000).forEach(v => { const c = custById(v.partyId) || {}; if (!c.pan && !v.partyPan && !RX.gstin.test(String(v.partyGstin || c.gstin || '').toUpperCase())) R.pan.push(row([v.date, v.no, v.partyName, invPayable(v), 'PAN / Form 60 lena zaroori'], { _inv: v.id })); });
    const pd = new Map(); payRows(a, b).filter(p => p.buy && isCash(p.mode)).forEach(p => { const k = p.v.partyId + '|' + p.date; const x = pd.get(k) || { d: p.date, n: p.v.partyName, amt: 0, w: 'Supplier ko cash payment' }; x.amt += p.amt; pd.set(k, x); });
    S.expenses.filter(e => inRange(e.date, a, b) && isCash(e.mode)).forEach(e => { const k = 'e|' + e.date + '|' + lc(e.category) + '|' + lc(e.notes); const x = pd.get(k) || { d: e.date, n: (e.category || 'Kharcha') + (e.notes ? ' — ' + e.notes : ''), amt: 0, w: 'Cash kharcha' }; x.amt += num(e.amount); pd.set(k, x); });
    (S.banktx || []).filter(x => x.kind === 'cashout' && inRange(x.date, a, b)).forEach(x => { const k = 'b|' + x.date + '|' + lc(x.party || x.purpose); const y = pd.get(k) || { d: x.date, n: [x.party, x.purpose].filter(Boolean).join(' — ') || 'Cash paid', amt: 0, w: 'Cash payment (other)' }; y.amt += num(x.amount); pd.set(k, y); });
    pd.forEach(x => { if (x.amt > 10000) R.a3.push([x.d, x.n, x.w, x.amt]); });
    (S.banktx || []).filter(x => inRange(x.date, a, b) && num(x.amount) >= 20000 && ((x.kind === 'cashin' && /loan|advance|capital/i.test(x.source || '')) || (x.kind === 'cashout' && /loan/i.test(x.purpose || '')))).forEach(x => R.loans.push([x.date, x.kind === 'cashin' ? 'Cash mein liya (269SS)' : 'Cash mein lautaya (269T)', x.party || x.source || x.purpose || '', num(x.amount)]));
    Object.values(R).forEach(L => L.sort((p, q) => String(p[0]).localeCompare(String(q[0])))); return R;
  }
  rep('cash2l', 'tax', 'Cash ₹2 lakh limit + PAN register', 'Sec 269ST (₹2 lakh+ cash), Rule 114B (₹2 lakh+ bill par PAN) — penalty se bachne ke liye', { defRp: 'fy', tag: 'CA', build(r) {
    const R = cashChecks(r.a, r.b);
    const c1 = [C('Date', 'd', 1), C('Party', 's', 2.4), C('Bill(s)', 's', 1.8), C('Cash ₹', 'inr'), C('Kya hua', 's', 2.6)];
    const c2 = [C('Date', 'd', 1), C('Bill', 's', 1.6), C('Party', 's', 2.4), C('Bill value', 'inr'), C('Kya karein', 's', 2)];
    return { summary: [['269ST cases', R.st.length], ['PAN missing', R.pan.length]], sections: [sec('Sec 269ST — ₹2 lakh ya zyada cash liya (penalty = utni hi rakam)', c1, R.st, { empty: 'Koi case nahi. 👍' }), sec('Rule 114B — ₹2 lakh+ ka bill, customer ka PAN nahi', c2, R.pan, { empty: 'Sab bade bills par PAN / GSTIN hai. 👍' })], note: 'Cash ₹2 lakh se zyada lena (ek din / ek bill / ek mauke) mana hai — bacha hua payment cheque / UPI / bank se lijiye.' };
  } });

  rep('tds194q', 'tax', 'TDS 194Q / TCS register', 'Har supplier se saal ki kharid — ₹50 lakh paar hone par TDS 0.1%', { defRp: 'fy', tag: 'CA', build(r) {
    const m = new Map(); S.invoices.filter(v => isBuy(v.type) && v.type !== 'oldgold' && inRange(v.date, r.a, r.b)).sort((a, b) => a.date.localeCompare(b.date)).forEach(v => { const x = m.get(v.partyId) || { n: v.partyName, id: v.partyId, tot: 0, cross: '' }; const before = x.tot; x.tot += num(T(v).taxable); if (before <= 5000000 && x.tot > 5000000) x.cross = v.date; m.set(v.partyId, x); });
    const X = [...m.values()].sort((a, b) => b.tot - a.tot);
    const cols = [C('Supplier', 's', 2.6), C('PAN / GSTIN', 's', 1.6), C('Kharid (taxable) ₹', 'inr'), C('₹50 lakh se upar', 'inr'), C('TDS 0.1% ₹', 'inr2'), C('Kab paar hua', 'd', 1)];
    const rows = X.map(x => { const s = supById(x.id) || {}; const over = Math.max(0, x.tot - 5000000); return [x.n, s.pan || s.gstin || '', x.tot, over, over * 0.001, x.cross]; });
    const paid = (S.banktx || []).filter(x => /income tax|tds/i.test(x.purpose || '') && inRange(x.date, r.a, r.b));
    const c2 = [C('Date', 'd', 1), C('Detail', 's', 3), C('Amount', 'inr')];
    return { summary: [['Suppliers', X.length], ['TDS banta hai', inr(sum(rows, x => x[4]))], ['Tax / TDS jama', inr(sum(paid, x => x.amount))]], sections: [sec('Supplier-wise kharid', cols, rows, { foot: totalsRow(cols, rows, 'Total', [5]) }), sec('Income tax / TDS jama kiya (Cash & Bank se)', c2, paid.map(x => [x.date, [x.purpose, x.party, x.notes].filter(Boolean).join(' · '), x.amount]))], note: 'Sec 194Q tabhi lagta hai jab pichhle saal aapka turnover ₹10 crore se zyada ho. CA se confirm kijiye.' };
  } });

  rep('einv', 'tax', 'E-invoice status', 'B2B GST bills jinka IRN bana / nahi bana', { defRp: 'month', build(r) {
    const L = S.invoices.filter(v => v.type === 'sale' && inRange(v.date, r.a, r.b) && RX.gstin.test(String(v.partyGstin || '').toUpperCase()));
    const cols = [C('Date', 'd', 1), C('Bill', 's', 1.6), C('Party', 's', 2.4), C('GSTIN', 's', 1.6), C('Value', 'inr'), C('IRN', 's', 1.4)];
    const rows = L.map(v => row([v.date, v.no, v.partyName, v.partyGstin, invPayable(v), v.irn ? '✓ ' + String(v.ackNo || '') : '✗ nahi'], { _inv: v.id }));
    return { summary: [['B2B bills', L.length], ['IRN bina', L.filter(v => !v.irn).length]], sections: [sec('', cols, rows)], note: 'E-invoice tabhi zaroori hai jab saal ka turnover ₹5 crore se upar ho. Jewellery par e-way bill nahi lagta (precious metal exempt).' };
  } });
  rep('gstscreen', 'tax', 'GST returns screen (JSON, 2B match)', 'GSTR-1 JSON, 3B, 2B reconciliation, filing status', { period: 'none', link: () => goTo('books', { bkTab: 'gst' }) });

  /* =====================================================================
     G. CASH, EXPENSES & GROWTH
     ===================================================================== */
  rep('cashbank', 'cash', 'Cash & bank summary', 'Har cash/bank account: opening, aaya, gaya, closing', { build(r) {
    const D = deBuild('both'); const ids = Object.keys(D.A).filter(id => id === 'cash' || id.startsWith('bank:'));
    const rows = ids.map(id => { let o = 0, dr = 0, cr = 0; D.E.forEach(e => e.lines.forEach(l => { if (l.acc !== id) return; if (e.date < r.a) o += l.dr - l.cr; else if (e.date <= r.b) { dr += l.dr; cr += l.cr; } })); return [D.A[id].name, o, dr, cr, o + dr - cr]; });
    const cols = [C('Account', 's', 2.6), C('Opening', 'inr2'), C('Aaya (in)', 'inr2'), C('Gaya (out)', 'inr2'), C('Closing', 'inr2')];
    return { summary: [['Closing (sab)', inr(sum(rows, x => x[4]))], ['Cash', inr((rows.find(x => x[0] === 'Cash in hand') || [0, 0, 0, 0, 0])[4])]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows) })] };
  } });
  rep('cashbook', 'cash', 'Cash book / Bank book / Bank reconciliation', 'Har entry ke saath running balance', { period: 'none', link: () => goTo('accounts', { accTab: 'cash' }) });

  rep('expense', 'cash', 'Expense analysis (mahine-wise)', 'Har category ka kharcha har mahine — kahan badh raha hai', { defRp: 'fy', build(r) {
    const M = months(r.a, r.b); const m = new Map(); S.expenses.filter(e => inRange(e.date, r.a, r.b)).forEach(e => { const k = e.category || 'Other'; const x = m.get(k) || Object.fromEntries(M.map(k2 => [k2, 0])); x[monthKey(e.date)] += num(e.amount); m.set(k, x); });
    const cols = [C('Category', 's', 1.8), ...M.map(k => C(monthLabel(k), 'inr', 1)), C('Total', 'inr', 1.2), C('Hissa', 'pct', .8)];
    const all = sum([...m.values()], x => sum(M, k => x[k]));
    const rows = [...m].map(([k, x]) => [k, ...M.map(k2 => x[k2]), sum(M, k2 => x[k2]), pctOf(sum(M, k2 => x[k2]), all)]).sort((a, b) => b[b.length - 2] - a[a.length - 2]);
    const L = S.expenses.filter(e => inRange(e.date, r.a, r.b)).sort((a, b) => a.date.localeCompare(b.date));
    const c2 = [C('Date', 'd', 1), C('Category', 's', 1.4), C('Detail', 's', 3), C('Mode', 's', 1), C('Amount', 'inr2')];
    return { summary: [['Kul kharcha', inr(all)], ['Entries', L.length]], sections: [sec('Category × mahina', cols, rows, { foot: totalsRow(cols, rows, 'Total', [cols.length - 1]) }), sec('Kharcha register (voucher list)', c2, L.map(e => [e.date, e.category, e.notes || '', e.mode || 'Cash', e.amount]), { foot: totalsRow(c2, L.map(e => [e.date, e.category, e.notes || '', e.mode || 'Cash', e.amount])) })], chart: barsHtml(rows.slice(0, 10).map(x => [x[0], x[x.length - 2]]), inr) };
  } });

  rep('scheme', 'cash', 'Gold saving scheme report', 'Har member: kisht, jama, gram, agli kisht, late, maturity', { period: 'none', build() {
    const L = (S.schemes || []).map(m => ({ m, c: schemeCalc(m) })).sort((a, b) => num(b.c.overdue) - num(a.c.overdue));
    const cols = [C('No', 's', 1), C('Member', 's', 2.2), C('Phone', 's', 1.2), C('Shuru', 'd', 1), C('Kisht ₹', 'inr'), C('Bhari', 's', .8), C('Jama ₹', 'inr'), C('Gram', 'g'), C('Agli kisht', 'd', 1), C('Late din', 'n', .7), C('Maturity', 'd', 1), C('Status', 's', 1)];
    const rows = L.map(({ m, c }) => [m.no, m.customerName, m.phone || (custById(m.customerId) || {}).phone || '', m.startDate, m.installment, (m.payments || []).length + '/' + (m.months || 11), c.paid, c.grams, c.nextDue || '', c.overdue || '', c.matureOn, m.status || (m.closedOn ? 'Closed' : 'Active')]);
    const act = L.filter(x => !x.m.closedOn);
    return { summary: [['Members', act.length], ['Jama (liability)', inr(sum(act, x => x.c.paid))], ['Late', act.filter(x => x.c.overdue).length]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [4, 9]) })], note: 'Scheme mein jama paisa aapki liability hai (Balance sheet mein "Gold scheme deposits"). Scheme ke kanooni niyam (BUDS Act 2019) apne CA se zaroor check karwaiye.' };
  } });

  rep('occasions', 'cash', 'Birthday / anniversary list', 'Agle 30 din mein kiska birthday / anniversary — WhatsApp offer ke liye', { period: 'none', build() {
    const t = today(); const out = []; const nxt = md => { if (!md) return null; const m = String(md).slice(5, 10); if (!/^\d{2}-\d{2}$/.test(m)) return null; let d = t.slice(0, 4) + '-' + m; if (d < t) d = (+t.slice(0, 4) + 1) + '-' + m; return d; };
    S.customers.forEach(c => [['Birthday 🎂', c.dob], ['Anniversary 💍', c.anniversary]].forEach(([k, v]) => { const d = nxt(v); if (d && daysBetween(t, d) <= 30) out.push([d, daysBetween(t, d), c.name, k, c.phone || '', c.city || '']); }));
    out.sort((a, b) => a[1] - b[1]);
    return { summary: [['Agle 30 din', out.length]], sections: [sec('', [C('Date', 'd', 1), C('Kitne din', 'n', .7), C('Naam', 's', 2.4), C('Mauka', 's', 1.2), C('Phone', 's', 1.2), C('City', 's', 1.2)], out, { empty: 'Agle 30 din mein koi birthday/anniversary nahi (ya customers mein date nahi bhari).' })] };
  } });

  rep('growth', 'cash', 'Naye customers & growth (city-wise)', 'Mahine-wise naye B2B / retail customers, city-wise, target 700 + 1100', { defRp: 'fy', build(r) {
    const L = S.customers.filter(c => inRange(tsDay(c.createdAt), r.a, r.b)); const M = months(r.a, r.b);
    const cols = [C('Mahina', 's', 1.4), C('B2B naye', 'n'), C('Retail naye', 'n'), C('Kul', 'n')];
    const rows = M.map(k => { const x = L.filter(c => monthKey(tsDay(c.createdAt)) === k); const b = x.filter(c => ptypeOf(c) === 'B2B').length; return [monthLabel(k), b, x.length - b, x.length]; });
    const city = new Map(); S.customers.forEach(c => { const k = (c.city || '(city nahi)').trim(); const x = city.get(k) || { b: 0, r: 0, n: 0 }; if (ptypeOf(c) === 'B2B') x.b++; else x.r++; if (L.includes(c)) x.n++; city.set(k, x); });
    const c2 = [C('City', 's', 2), C('B2B', 'n'), C('Retail', 'n'), C('Is period mein naye', 'n')];
    const r2_ = [...city].sort((a, b) => (b[1].b + b[1].r) - (a[1].b + a[1].r)).map(([k, x]) => [k, x.b, x.r, x.n]);
    const s = settings(); const g = s.growth || {}; const b2b = S.customers.filter(c => ptypeOf(c) === 'B2B').length;
    return { summary: [['B2B kul', b2b + ' / ' + (g.b2b || 700)], ['Retail kul', (S.customers.length - b2b) + ' / ' + (g.retail || 1100)], ['Is period mein naye', L.length]], sections: [sec('Mahine-wise', cols, rows, { foot: totalsRow(cols, rows) }), sec('City-wise', c2, r2_)] };
  } });
  rep('targetpage', 'cash', 'Target 🎯 page & Analytics charts', 'Graph wale reports — target, trend, calendar', { period: 'none', link: () => goTo('reports', { rTab: 'analytics' }) });

  /* =====================================================================
     H. CA / AUDIT
     ===================================================================== */
  rep('tb', 'ca', 'Trial balance', 'Har account ka debit / credit — CA ka pehla kaagaz', { period: 'asof', tag: 'CA', build(r) {
    const D = deBuild(ui.rpBook === 'pakka' ? 'pakka' : 'both'); const bal = deBalances(D, r.b);
    const L = deAccounts(D).filter(a => Math.abs(num(bal[a.id])) >= 0.005);
    const cols = [C('Account', 's', 3), C('Group', 's', 1.4), C('Debit ₹', 'inr2'), C('Credit ₹', 'inr2')];
    const rows = L.map(a => [a.name + (a.grp ? ' (' + a.grp + ')' : ''), DE_G[a.g], bal[a.id] > 0 ? bal[a.id] : '', bal[a.id] < 0 ? -bal[a.id] : '']);
    const t = totalsRow(cols, rows);
    return { summary: [['Debit', inr(t[2])], ['Credit', inr(t[3])], ['Check', Math.abs(num(t[2]) - num(t[3])) < 0.01 ? '✓ Balanced' : 'Farak']], sections: [sec('', cols, rows, { foot: t })] };
  } });
  rep('pnl2', 'ca', 'Profit & Loss (Trading + P&L)', 'Saal ka munafa — CA format mein', { defRp: 'fy', tag: 'CA', build: r => RMAP.pnl.build(r) });
  rep('balsheet2', 'ca', 'Balance sheet', 'Saal ke ant ki balance sheet', { period: 'asof', tag: 'CA', build: r => RMAP.balsheet.build(r) });

  rep('capital', 'ca', 'Capital account & drawings', 'Owner ka paisa daala, nikala (drawings), income tax — saal bhar', { defRp: 'fy', tag: 'CA', build(r) {
    const D = deBuild('both'); const ids = Object.keys(D.A).filter(id => D.A[id].g === 'C'); const rows = [];
    D.E.forEach(e => e.lines.forEach(l => { if (!ids.includes(l.acc) || !inRange(e.date, r.a, r.b)) return; rows.push([e.date, D.A[l.acc].name, e.narr, l.dr || '', l.cr || '']); }));
    const open = -sum(ids, id => num(deBalances(D, addDays(r.a, -1))[id]));
    const cols = [C('Date', 'd', 1), C('Account', 's', 2), C('Detail', 's', 3), C('Nikala (Dr)', 'inr2'), C('Daala (Cr)', 'inr2')];
    const P = pnlData(r.a, r.b); const t = totalsRow(cols, rows);
    const close = open + num(t[4]) - num(t[3]) + P.np;
    return { summary: [['Opening capital', inr(open)], ['Daala', inr(t[4])], ['Nikala', inr(t[3])], ['Profit', inr(P.np)], ['Closing capital', inr(close)]], sections: [sec('', cols, rows, { foot: t })] };
  } });

  rep('loans', 'ca', 'Loans & advances statement', 'Liye / diye loans, advances, scheme deposits — saal ke ant ka balance', { period: 'asof', tag: 'CA', build(r) {
    const D = deBuild('both'); const bal = deBalances(D, r.b); const ids = Object.keys(D.A).filter(id => /^(loans|advance|supadv|scheme|cred:un|deb:un|suspense)$/.test(id) || id.startsWith('loan:'));
    const rows = ids.map(id => [D.A[id].name, DE_G[D.A[id].g], bal[id] > 0 ? bal[id] : '', bal[id] < 0 ? -bal[id] : '']).filter(x => x[2] || x[3]);
    const cols = [C('Account', 's', 3), C('Group', 's', 1.2), C('Debit (lena)', 'inr2'), C('Credit (dena)', 'inr2')];
    return { summary: [['Accounts', rows.length]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows), empty: 'Koi loan / advance ki entry nahi. (Cash & Bank mein "Loan received" / "Loan repayment" se aati hai.)' })], note: 'Loan par byaaj aur bank ka loan statement CA ko alag se dijiye. "Suspense" mein jo hai uska hisaab CA se pehle theek kar lijiye.' };
  } });

  /* ---- Form 3CD clause 35: quantitative details ---- */
  function qtyData(a, b) {
    const m = new Map(); const K = (pur, metal) => { let x = m.get(pur); if (!x) { x = { pur, metal: metal || metalOf(pur), open: 0, buy: 0, old: 0, kin: 0, sale: 0, kout: 0, jI: 0, jR: 0 }; m.set(pur, x); } return x; };
    const ev = (d, pur, k, w, metal) => { if (!pur || !w) return; const x = K(pur, metal); if (d < a) { x.open += (k === 'sale' || k === 'kout' ? -w : w); return; } if (d > b) return; x[k] += w; };
    S.invoices.forEach(v => { (v.items || []).forEach(it => ev(v.date, it.purity, isBuy(v.type) ? 'buy' : 'sale', num(it.net))); if (!isBuy(v.type)) (v.oldMetal || []).forEach(o => { const mt = o.metal === 'silver' ? 'silver' : 'gold'; ev(v.date, o.purity || (mt === 'silver' ? 'Old silver (mixed)' : 'Old gold (mixed)'), 'old', num(o.net || o.gross || o.weight), mt); }); });
    (S.jobs || []).forEach(j => { if (j.status === 'Cancelled') return; if (j.issueDate) ev(j.issueDate, j.purity, 'kout', num(j.issuedWt)); if (j.status === 'Received' && j.receivedDate) { ev(j.receivedDate, j.purity, 'kin', num(j.receivedWt) + num(j.scrapWt)); if (inRange(j.receivedDate, a, b) && j.purity) { const x = K(j.purity); x.jI += num(j.issuedWt); x.jR += num(j.receivedWt) + num(j.scrapWt); } } });
    const phys = new Map(); S.products.filter(stockLive).forEach(p => phys.set(p.purity, (phys.get(p.purity) || 0) + num(p.net)));
    return [...m.values()].map(x => ({ ...x, close: x.open + x.buy + x.old + x.kin - x.sale - x.kout, phys: phys.get(x.pur) || 0 })).sort((p, q) => p.metal.localeCompare(q.metal) || p.pur.localeCompare(q.pur));
  }
  rep('qty3cd', 'ca', 'Quantitative stock details (Form 3CD cl. 35)', 'Gold & silver, purity-wise: opening, kharid, bikri, closing, shortage — gram mein', { defRp: 'fy', tag: 'CA', build(r) {
    const X = qtyData(r.a, r.b); const now = r.b >= today();
    const cols = [C('Metal / purity', 's', 1.6), C('Opening g', 'g'), C('Kharid g', 'g'), C('Old metal aaya g', 'g'), C('Karigar se aaya g', 'g'), C('Bikri g', 'g'), C('Karigar ko diya g', 'g'), C('Closing (books) g', 'g'), C('Vault (physical) g', 'g'), C('Shortage(−)/Excess(+) g', 'g'), C('Yield / loss %', 'pct')];
    const rows = X.map(x => [/^(silver|old)/i.test(x.pur) ? x.pur : metalName(x.metal) + ' ' + x.pur, x.open, x.buy, x.old, x.kin, x.sale, x.kout, x.close, now ? x.phys : '', now ? x.phys - x.close : '', x.jI ? pctOf(x.jI - x.jR, x.jI) : '']);
    const sub = metal => { const L = rows.filter((rr, i) => X[i].metal === metal); const t = totalsRow(cols, L, metalName(metal) + ' total', [10]); return t; };
    const all = [...rows.filter((rr, i) => X[i].metal === 'gold'), sub('gold'), ...rows.filter((rr, i) => X[i].metal === 'silver'), sub('silver')];
    return { summary: [['Gold closing', g3(sum(X.filter(x => x.metal === 'gold'), x => x.close))], ['Silver closing', g3(sum(X.filter(x => x.metal === 'silver'), x => x.close))]], sections: [sec('Net weight (gram) — purity-wise', cols, all)], note: 'Opening = period se pehle ke saare bills/karigar entries ka hisaab. Vault (physical) sirf aaj ki tareekh par milta hai. Yield/loss % = poore hue karigar jobs mein diya − wapas aaya (aaya + scrap). Shortage ka kaaran (melting loss, sample, galat entry) CA ko likh kar dijiye.' };
  } });

  rep('valuation', 'ca', 'Closing stock valuation (cost ya market, jo kam)', 'Har category: cost value, market value, lower of the two (ICDS II)', { period: 'none', tag: 'CA', build() {
    const m = new Map(); S.products.filter(stockLive).forEach(p => { const k = p.category + ' ' + p.purity; const x = m.get(k) || { k, metal: metalOf(p.purity), pcs: 0, net: 0, fine: 0, cost: 0 }; x.pcs += Math.max(1, num(p.pcs) || 1); x.net += num(p.net); x.fine += pFine(p); x.cost += pCost(p); m.set(k, x); });
    const X = [...m.values()].sort((a, b) => b.cost - a.cost);
    const cols = [C('Category + purity', 's', 2.6), C('Pcs', 'n', .7), C('Net g', 'g'), C('Fine g', 'g'), C('Cost value', 'inr'), C('Market value', 'inr'), C('Lower of two', 'inr'), C('Basis', 's', .9)];
    const rows = X.map(x => { const mv = x.fine * rateFor(x.metal); const low = mv > 0 ? Math.min(x.cost, mv) : x.cost; return [x.k, x.pcs, x.net, x.fine, x.cost, mv, low, mv > 0 && mv < x.cost ? 'Market' : 'Cost']; });
    return { summary: [['Cost', inr(sum(rows, x => x[4]))], ['Market', inr(sum(rows, x => x[5]))], ['Value (lower)', inr(sum(rows, x => x[6]))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows) })], note: 'Cost = kharid rate (fine + wastage) + labour. Market = aaj ke bhaav par sirf fine. Aaj ke bhaav Dashboard par bhariye.' };
  } });

  rep('cash40a3', 'ca', 'Cash payments > ₹10,000 — Sec 40A(3)', 'Ek din mein ek aadmi ko ₹10,000+ cash — ye kharcha disallow ho sakta hai', { defRp: 'fy', tag: 'CA', build(r) {
    const R = cashChecks(r.a, r.b); const cols = [C('Date', 'd', 1), C('Kisko / kya', 's', 3), C('Type', 's', 1.6), C('Cash ₹', 'inr')];
    return { summary: [['Cases', R.a3.length], ['Rakam', inr(sum(R.a3, x => x[3]))]], sections: [sec('', cols, R.a3, { foot: totalsRow(cols, R.a3), empty: 'Koi ₹10,000+ cash payment nahi. 👍' })], note: 'Supplier ko maal ke payment par bhi ye niyam lagta hai. Aage se ₹10,000 se upar ka payment bank / UPI se kijiye.' };
  } });
  rep('cash269ss', 'ca', 'Cash loans ≥ ₹20,000 — Sec 269SS / 269T', 'Cash mein loan / deposit liya ya lautaya', { defRp: 'fy', tag: 'CA', build(r) {
    const R = cashChecks(r.a, r.b); const cols = [C('Date', 'd', 1), C('Type', 's', 2), C('Kisse', 's', 2.4), C('Cash ₹', 'inr')];
    return { summary: [['Cases', R.loans.length]], sections: [sec('', cols, R.loans, { empty: 'Koi cash loan ₹20,000+ nahi. 👍' })] };
  } });
  rep('sft', 'ca', 'SFT (Form 61A) — ₹2 lakh+ cash customers', 'Saal mein jis customer se ₹2 lakh se zyada cash mila — PAN ke saath', { defRp: 'fy', tag: 'CA', build(r) {
    const m = new Map(); payRows(r.a, r.b).filter(p => !p.buy && isCash(p.mode)).forEach(p => { const x = m.get(p.v.partyId) || { id: p.v.partyId, n: p.v.partyName, amt: 0, n2: 0 }; x.amt += p.amt; x.n2++; m.set(p.v.partyId, x); });
    const X = [...m.values()].filter(x => x.amt > 200000).sort((a, b) => b.amt - a.amt);
    const cols = [C('Customer', 's', 2.4), C('PAN', 's', 1.2), C('Phone', 's', 1.2), C('Address', 's', 2.6), C('Cash mila ₹', 'inr'), C('Payments', 'n', .7)];
    const rows = X.map(x => { const c = custById(x.id) || {}; return [x.n, c.pan || '⚠ nahi', c.phone || '', [c.address, c.city, c.pin].filter(Boolean).join(', '), x.amt, x.n2]; });
    return { summary: [['Customers', X.length], ['Cash', inr(sum(X, x => x.amt))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [5]) })], note: 'Tax audit wale business ko ye list Form 61A (SFT) mein 31 May tak bharni hoti hai. CA se confirm kijiye.' };
  } });
  rep('advtax', 'ca', 'Advance tax / income tax paid', 'Quarter-wise income tax / TDS jama (15 Jun, 15 Sep, 15 Dec, 15 Mar)', { defRp: 'fy', tag: 'CA', build(r) {
    const L = (S.banktx || []).filter(x => /income tax|tds|advance tax/i.test([x.purpose, x.notes].join(' ')) && inRange(x.date, r.a, r.b)).sort((a, b) => a.date.localeCompare(b.date));
    const q = d => { const m = +d.slice(5, 7); return m >= 4 && m <= 6 ? 'Q1 (15 Jun)' : m <= 9 && m >= 7 ? 'Q2 (15 Sep)' : m >= 10 ? 'Q3 (15 Dec)' : 'Q4 (15 Mar)'; };
    const cols = [C('Date', 'd', 1), C('Quarter', 's', 1.2), C('Detail', 's', 3), C('Amount', 'inr')];
    const rows = L.map(x => [x.date, q(x.date), [x.purpose, x.party, x.notes].filter(Boolean).join(' · '), x.amount]);
    return { summary: [['Jama', inr(sum(L, x => x.amount))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows), empty: 'Cash & Bank mein "Income tax / TDS" purpose se entry kijiye — yahan aa jayegi.' })] };
  } });

  rep('gstr9', 'ca', 'GSTR-9 annual data (mahine-wise)', '12 mahine ki bikri, kharid, tax, ITC, credit/debit notes — annual return ke liye', { defRp: 'fy', tag: 'CA', build(r) {
    const M = months(r.a, r.b); const cols = [C('Mahina', 's', 1.2), C('Bills', 'n', .6), C('Outward taxable', 'inr'), C('CGST', 'inr'), C('SGST', 'inr'), C('IGST', 'inr'), C('Credit notes', 'inr'), C('Inward taxable', 'inr'), C('ITC CGST', 'inr'), C('ITC SGST', 'inr'), C('ITC IGST', 'inr'), C('Net tax', 'inr')];
    const rows = M.map(k => { const a = k + '-01' < r.a ? r.a : k + '-01'; const e = addDays(shiftMonth(k, 1) + '-01', -1); const b = e > r.b ? r.b : e; const g = gstMonth(a, b); return [monthLabel(k), g.nOut, g.otx, g.oc, g.os, g.oi, g.crt, g.itx, g.ic, g.is, g.ii, (g.oc + g.os + g.oi - g.crt) - (g.ic + g.is + g.ii - g.drt)]; });
    const t = totalsRow(cols, rows);
    return { summary: [['Outward', inr(t[2])], ['Tax', inr(num(t[3]) + num(t[4]) + num(t[5]))], ['ITC', inr(num(t[8]) + num(t[9]) + num(t[10]))]], sections: [sec('', cols, rows, { foot: t })] };
  } });

  rep('gst9c', 'ca', 'Turnover reconciliation (Books vs GST vs Bank)', 'GSTR-9C ke liye: books ki bikri, GST returns, bank mein aaya paisa — farak kahan hai', { defRp: 'fy', tag: 'CA', build(r) {
    const D = deBuild('both'); const bal = deBalances(D, r.b, r.a); const cr = id => -num(bal[id]);
    const g = gstMonth(r.a, r.b); const pakka = cr('sales:pakka'), kacha = cr('sales:kacha'), unbP = cr('unb:pakka'), unbK = cr('unb:kacha'), ret = cr('salesret');
    let bankIn = 0; D.E.forEach(e => { if (!inRange(e.date, r.a, r.b)) return; const bank = e.lines.filter(l => l.acc.startsWith('bank:') && l.dr); const fromCash = e.lines.some(l => l.acc === 'cash' && l.cr) || e.lines.some(l => l.acc.startsWith('bank:') && l.cr); if (!fromCash) bankIn += sum(bank, l => l.dr); });
    const cols = [C('Particulars', 's', 4), C('Amount ₹', 'inr2', 1.4)];
    const rows = [row(['Turnover as per GST bills (GSTR-1 taxable)', g.otx]), ['Less: credit notes', -g.crtx], row(['A. Net turnover as per GST returns', g.otx - g.crtx], { _b: 1 }),
      ['Books — Sales Pakka (GST bills)', pakka], ['Books — Cash sales Pakka (bina bill, Cash & Bank se)', unbP], ['Books — Sales returns', ret], row(['B. Pakka turnover as per books', pakka + unbP + ret], { _b: 1 }),
      row(['Farak (B − A) — iska GST bill banna chahiye tha', pakka + unbP + ret - (g.otx - g.crtx)], { _b: 1 }),
      ['Kacha / estimate sales (GST mein nahi)', kacha + unbK], row(['Kul bikri (pakka + kacha)', pakka + unbP + ret + kacha + unbK], { _b: 1 }),
      ['Bank mein aaya paisa (cash deposit / transfer chhod kar)', bankIn]];
    return { summary: [['GST turnover', inr(g.otx - g.crtx)], ['Books pakka', inr(pakka + unbP + ret)], ['Kacha', inr(kacha + unbK)], ['Bank receipts', inr(bankIn)]], sections: [sec('', cols, rows)], note: 'Income tax dept 26AS/AIS mein bank receipts aur GST turnover dono dekhta hai. Bada farak ho to CA ko kaaran pehle se bataiye.' };
  } });

  rep('bankstock', 'ca', 'Monthly stock statement (bank CC/OD)', 'Bank ko har mahine: stock value, debtors, creditors, drawing power', { period: 'asof', tag: 'CA', build(r) {
    const st = { g: { net: 0, fine: 0, cost: 0 }, s: { net: 0, fine: 0, cost: 0 } }; S.products.filter(stockLive).forEach(p => { const x = metalOf(p.purity) === 'silver' ? st.s : st.g; x.net += num(p.net); x.fine += pFine(p); x.cost += pCost(p); });
    const ag = ageRows('customer', r.b); const d90 = sum(ag, x => x[1] + x[2] + x[3]), dOld = sum(ag, x => x[4] + x[5]); const cred = sum(ageRows('supplier', r.b), x => x[6]);
    const mg = num(settings().rcBankMargin) || 25; const gv = st.g.fine * rateFor('gold'), sv = st.s.fine * rateFor('silver'); const stockV = Math.min(st.g.cost + st.s.cost, (gv + sv) || 1e15);
    const dp = Math.max(0, (stockV - cred) * (1 - mg / 100)) + d90 * (1 - mg / 100);
    const cols = [C('Particulars', 's', 3.6), C('Net g', 'g'), C('Fine g', 'g'), C('Value ₹', 'inr')];
    const rows = [row(['A. STOCK', '', '', ''], { _h: 1 }), ['Gold jewellery (cost)', st.g.net, st.g.fine, st.g.cost], ['Silver jewellery (cost)', st.s.net, st.s.fine, st.s.cost], ['Market value (aaj ke bhaav)', '', '', gv + sv], row(['Stock value (lower)', '', '', stockV], { _b: 1 }),
      row(['B. DEBTORS', '', '', ''], { _h: 1 }), ['90 din tak purane', '', '', d90], ['90 din se purane (DP mein nahi)', '', '', dOld],
      row(['C. CREDITORS', '', '', ''], { _h: 1 }), ['Suppliers ko dena', '', '', cred],
      row(['DRAWING POWER (approx, ' + mg + '% margin)', '', '', dp], { _b: 1 })];
    return { summary: [['Stock', inr(stockV)], ['Debtors ≤90d', inr(d90)], ['Creditors', inr(cred)], ['Drawing power', inr(dp)]], sections: [sec('', cols, rows)], tools: `<label class="small muted">Bank margin % <input type="number" min="0" max="90" step="1" value="${mg}" data-rc-set="rcBankMargin" style="width:80px"></label>`, note: 'Drawing power ka asli formula aapke bank ke sanction letter mein hota hai — margin wahan se bhariye.' };
  } });

  rep('confirm', 'ca', 'Party balance confirmation letters', 'Har party ko balance confirm karne ki chitthi (PDF, ek page ek party)', { period: 'asof', tag: 'CA', build(r) {
    const A = partyRows('customer', r.b).filter(x => Math.abs(x.due) > 0.5 || Math.abs(x.fine) > 0.0005), B = partyRows('supplier', r.b).filter(x => Math.abs(x.due) > 0.5);
    const cols = [C('Party', 's', 2.6), C('Type', 's', 1), C('City', 's', 1.2), C('Balance ₹', 'inr'), C('Dr / Cr', 's', .7), C('Fine g', 'g')];
    const rows = [...A.map(x => [x.n, 'Customer', (custById(x.id) || {}).city || '', Math.abs(x.due), x.due >= 0 ? 'Dr' : 'Cr', x.fine || '']), ...B.map(x => [x.n, 'Supplier', (supById(x.id) || {}).city || '', Math.abs(x.due), x.due >= 0 ? 'Cr' : 'Dr', ''])];
    return { summary: [['Letters', rows.length]], sections: [sec('', cols, rows)], tools: `<button class="btn sm gold" data-act="rc-letters">${ic('dl', 14)} Sab letters ka PDF</button>`, _letters: { A, B, asOf: r.b } };
  } });

  rep('salary', 'ca', 'Salary register', 'Har mahine salary ka kharcha — staff ke naam ke saath (notes se)', { defRp: 'fy', tag: 'CA', build(r) {
    const L = S.expenses.filter(e => /salary|wage|bonus/i.test(e.category || '') && inRange(e.date, r.a, r.b)).sort((a, b) => a.date.localeCompare(b.date));
    const m = new Map(); L.forEach(e => { const k = (e.notes || '(naam nahi)').trim(); m.set(k, (m.get(k) || 0) + num(e.amount)); });
    const cols = [C('Date', 'd', 1), C('Staff / detail', 's', 3), C('Mode', 's', 1), C('Amount', 'inr2')];
    const rows = L.map(e => [e.date, e.notes || '', e.mode || 'Cash', e.amount]);
    return { summary: [['Salary', inr(sum(L, e => e.amount))], ['Cash mein', inr(sum(L.filter(e => isCash(e.mode)), e => e.amount))]], sections: [sec('Staff-wise', [C('Staff', 's', 3), C('Kul', 'inr2')], [...m].sort((a, b) => b[1] - a[1])), sec('Har payment', cols, rows, { foot: totalsRow(cols, rows) })], note: 'Kharche mein category "Salary" aur notes mein staff ka naam likhiye. 20+ staff hone par PF/ESI ki zaroorat CA se poochiye.' };
  } });

  /* ---- Fixed asset register (IT Act, WDV) ---- */
  const BLOCKS = [['Furniture & fittings', 10], ['Plant & machinery', 15], ['Computers & software', 40], ['Motor car / vehicle', 15], ['Building', 10], ['Intangible (trademark, etc.)', 25]];
  function faSchedule(a, b) {
    const L = (S[FA] || []).filter(x => !x.soldOn || x.soldOn >= a); const rows = [];
    L.forEach(x => { const rate = num(x.rate) || 15; let wdv = num(x.cost); const start = fyStart(x.date); let y = start; let open = 0, add = 0, dep = 0;
      for (let g = 0; g < 60 && y <= a; g++) { const fe = fyEnd(y); const first = y === start; const half = first && daysBetween(x.date, fe) + 1 < 180; const d = wdv * rate / 100 * (half ? .5 : 1); if (y < a) { wdv -= d; y = (+y.slice(0, 4) + 1) + '-04-01'; continue; } break; }
      if (x.date < a) open = wdv; else if (x.date <= b) add = num(x.cost); else return;
      const half = x.date >= a && daysBetween(x.date, b) + 1 < 180; dep = (open + add) * rate / 100 * (half ? .5 : 1);
      rows.push({ x, rate, open, add, half, dep, close: open + add - dep }); });
    return rows;
  }
  rep('fixedassets', 'ca', 'Fixed asset register & depreciation', 'Furniture, safe, computer, gaadi — IT Act WDV depreciation (180 din ka niyam)', { defRp: 'fy', tag: 'CA', build(r) {
    const X = faSchedule(r.a, r.b);
    const cols = [C('Asset', 's', 2.4), C('Block', 's', 1.8), C('Kharid date', 'd', 1), C('Rate', 'pct', .7), C('Opening WDV', 'inr'), C('Addition', 'inr'), C('180 din se kam', 's', .8), C('Depreciation', 'inr'), C('Closing WDV', 'inr'), C('', 'x', .1)];
    const rows = X.map(z => [z.x.name, z.x.block, z.x.date, z.rate, z.open, z.add, z.half ? 'Haan (½)' : '', z.dep, z.close, `<button class="link" data-act="rc-fa-edit" data-id="${esc(z.x.id)}">Edit</button>`]);
    return { summary: [['Assets', X.length], ['Depreciation', inr(sum(X, z => z.dep))], ['Closing WDV', inr(sum(X, z => z.close))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows, 'Total', [3]), empty: 'Abhi koi asset nahi — "Asset jodo" se counter, tijori, computer, gaadi waghera jodiye.' })], tools: `<button class="btn sm primary" data-act="rc-fa-edit">${ic('plus', 14)} Asset jodo</button>`, note: 'Income Tax (WDV) rates: Furniture 10%, Plant & machinery (tijori, AC, printer) 15%, Computer 40%, Gaadi 15%. Jo asset saal mein 180 din se kam use hua uska aadha depreciation.' };
  } });

  rep('vouchers', 'ca', 'Expense voucher register', 'Har kharcha date, category, detail, mode ke saath — CA vouching ke liye', { defRp: 'fy', tag: 'CA', build: r => { const x = RMAP.expense.build(r); return { summary: x.summary, sections: [x.sections[1]] }; } });
  rep('ledgers', 'ca', 'Account ledgers (sab accounts)', 'Journal aur har account ka ledger — Ledger screen par', { period: 'none', link: () => goTo('accounts', { accTab: 'acledger' }) });

  /* =====================================================================
     charts (small, theme-aware SVG)
     ===================================================================== */
  function barsHtml(pairs, f) { pairs = pairs.filter(p => num(p[1]) !== 0); if (pairs.length < 2) return ''; const mx = Math.max(...pairs.map(p => Math.abs(num(p[1])))) || 1;
    return `<div class="rc-bars">${pairs.map(([l, v]) => `<div class="rc-bar"><span class="l" title="${esc(l)}">${esc(l)}</span><span class="t"><i class="${num(v) < 0 ? 'neg' : ''}" style="width:${Math.max(1.5, Math.abs(num(v)) / mx * 100).toFixed(1)}%"></i></span><span class="v">${esc(f(v))}</span></div>`).join('')}</div>`; }
  function lineHtml(pairs, f) { if (pairs.length < 2) return ''; const W = 640, H = 160, P = 8; const vs = pairs.map(p => num(p[1])); const mx = Math.max(...vs), mn = Math.min(...vs, 0); const sx = i => P + i * (W - 2 * P) / (pairs.length - 1), sy = v => H - P - (v - mn) / ((mx - mn) || 1) * (H - 2 * P);
    const d = vs.map((v, i) => (i ? 'L' : 'M') + sx(i).toFixed(1) + ' ' + sy(v).toFixed(1)).join(' ');
    return `<div class="rc-line"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="trend"><path d="${d} L${sx(vs.length - 1)} ${H - P} L${P} ${H - P} Z" class="a"/><path d="${d}" class="s"/></svg><div class="rc-line-l"><span>${esc(pairs[0][0])}</span><span>${esc(f(vs[vs.length - 1]))}</span><span>${esc(pairs[pairs.length - 1][0])}</span></div></div>`; }

  /* =====================================================================
     UI: Report Centre inside Reports
     ===================================================================== */
  if (!REP_TABS.some(x => x[0] === 'hub')) REP_TABS.splice(REP_TABS.findIndex(x => x[0] === 'analytics') + 1, 0, ['hub', '📚 Report Centre']);
  Object.assign(ui, { rcId: ui.rcId || '', rcRp: ui.rcRp || 'month', rcFrom: '', rcTo: '', rcAsOf: '' });
  const rcRange = rp => { const R = RMAP[ui.rcId]; if (R && R.period === 'asof') { const d = ui.rcAsOf || today(); return { a: '2000-01-01', b: d, label: 'As on ' + fmtD(d) }; } return rangeFor(ui.rcRp || 'month', ui.rcFrom, ui.rcTo); };
  const canEditSettings = () => { const u = window.SJ_USER; return !u || u.role === 'owner' || u.role === 'manager'; };
  function stockTools() { const sc = stockCfg(); if (!canEditSettings()) return ''; return `<label class="small muted">Opening stock ₹ <input type="number" step="1" value="${sc.open || ''}" placeholder="0" data-rc-set="rcOpenStock" style="width:120px"></label><label class="small muted">Closing stock ₹ <input type="number" step="1" value="${sc.close == null ? '' : sc.close}" placeholder="vault se (${Math.round(deStockCost().value)})" data-rc-set="rcCloseStock" style="width:150px"></label>`; }

  function catalogue() {
    const n = REPS.length;
    const head = `<div class="card rc-hero"><div><h3>📚 Report Centre</h3><div class="small muted">${n} reports · har report ka Excel, CSV aur PDF · upar wala Sector bar (Wholesale / Retail) aur Pakka/Kacha yahan bhi chalta hai</div></div>
      <div class="btns"><input type="search" class="rc-q" placeholder="Report dhoondo… (jaise GST, karigar, cash)" aria-label="Search reports"><button class="btn gold" data-act="rc-capack">${ic('dl', 16)} CA Pack (Excel)</button></div></div>`;
    const groups = GRP.map(([g, l, i, d]) => { const L = REPS.filter(x => x.g === g); return `<section class="rc-grp" data-g="${g}"><div class="rc-gh"><span class="rc-gi">${i}</span><div><b>${esc(l)}</b><div class="small muted">${esc(d)}</div></div><span class="pill">${L.length}</span></div><div class="rc-grid">${L.map((x, k) => `<button type="button" class="rc-card" data-act="rc-open" data-id="${x.id}" data-k="${esc(lc(x.t + ' ' + x.d + ' ' + l))}"><span class="rc-n">${GRP.findIndex(z => z[0] === g) + 1}.${k + 1}</span><b>${esc(x.t)}</b><span class="small muted">${esc(x.d)}</span>${x.link ? '<span class="rc-tag lk">screen kholo →</span>' : x.tag ? `<span class="rc-tag">${x.tag}</span>` : ''}</button>`).join('')}</div></section>`; }).join('');
    return head + groups;
  }

  function cellHtml(c, v) { if (c.t === 'x') return v == null ? '' : String(v); const s = fmtCell(c.t, v); const neg = isNumT(c.t) && num(v) < -0.004; return `<span class="${neg ? 'red' : ''}">${esc(s)}</span>`; }
  function secHtml(s) {
    const head = s.cols.map(c => [esc(c.h), isNumT(c.t) ? 'r' : '']);
    const rows = s.rows.map(r => { if (r._h) return `<tr class="rc-h"><td colspan="${s.cols.length}">${esc(r[0])}</td></tr>`; const cls = [r._b ? 'rc-b' : '', r._inv ? 'click' : ''].join(' ').trim(); return `<tr${cls ? ` class="${cls}"` : ''}${r._inv ? ` data-act="inv-view" data-id="${esc(r._inv)}"` : ''}>${s.cols.map((c, i) => `<td class="${isNumT(c.t) ? 'r num' : ''}">${cellHtml(c, r[i])}</td>`).join('')}</tr>`; });
    const foot = s.foot ? `<tr>${s.cols.map((c, i) => `<td class="${isNumT(c.t) ? 'r' : ''}"><b>${cellHtml(c, s.foot[i])}</b></td>`).join('')}</tr>` : '';
    const more = rows.length > 1500 ? `<p class="small muted">Screen par pehli 1500 lines — poori list Excel / CSV mein.</p>` : '';
    return `<div class="card rc-sec">${s.title ? `<h3>${esc(s.title)} <span class="small muted">· ${s.rows.filter(r => !r._h).length}</span></h3>` : ''}${btable(head, rows.slice(0, 1500), { foot, empty: s.empty || 'Is period mein kuch nahi.', cls: 'rc-tbl' })}${more}${s.note ? `<p class="small muted rc-note">${esc(s.note)}</p>` : ''}</div>`;
  }
  let LAST = null;   // last built report (for export)
  function buildCur() { const R = RMAP[ui.rcId]; if (!R || !R.build) return null; const r = rcRange(); const out = withBook(ui.rpBook, () => R.build(r)); LAST = { R, r, out }; return LAST; }
  function reportBody() {
    const R = RMAP[ui.rcId]; if (!R) { ui.rcId = ''; return catalogue(); }
    if (!R.build) { ui.rcId = ''; if (R.link) setTimeout(() => R.link(), 0); return emptyBox('Ye report alag screen par khulti hai — le ja rahe hain…'); }
    let X; try { X = buildCur(); } catch (e) { console.error(e); return emptyBox('Ye report abhi ban nahi paayi: ' + esc(e.message || e)); }
    const o = X.out; const kp = (o.summary || []).length ? `<div class="kpis rc-kpis">${o.summary.map(([l, v]) => kpi(esc(l), esc(String(v)))).join('')}</div>` : '';
    const warn = (o.warn || []).length ? `<div class="card rc-warn"><b>⚠ Dhyan dijiye</b>${o.warn.slice(0, 20).map(w => `<div class="small">${esc(w)}</div>`).join('')}</div>` : '';
    const empty = (o.sections || []).every(s => !s.rows.length) && !(o.summary || []).length;
    return kp + warn + (o.tools ? `<div class="toolbar rc-tools">${o.tools}</div>` : '') + (o.chart ? `<div class="card">${o.chart}</div>` : '') + (empty ? emptyBox('Is period mein koi data nahi.') : (o.sections || []).map(secHtml).join('')) + (o.note ? `<p class="small muted rc-note">ℹ ${esc(o.note)}</p>` : '');
  }
  function hubShell() {
    const tabs = `<div class="rep-tabs">${REP_TABS.map(([k, l]) => `<button type="button" data-act="seg" data-k="rTab" data-v="${k}" class="${ui.rTab === k ? 'on' : ''}">${l}</button>`).join('')}</div>`;
    const R = RMAP[ui.rcId]; if (!R) return tabs + '<div id="vbody"></div>';
    const r = rcRange(); const book = seg('rpBook', [['both', 'Sab'], ['pakka', 'Pakka'], ['kacha', 'Kacha']]);
    const per = R.period === 'asof' ? `<span class="small muted" style="font-weight:700">As on</span><input type="date" data-ui="rcAsOf" data-full="1" value="${esc(ui.rcAsOf || today())}" aria-label="As on date">` : R.period === 'none' ? `<span class="small muted">Aaj tak (${fmtD(today())})</span>` : `<select data-ui="rcRp" data-full="1" aria-label="Period">${opts(RP_PRESETS, ui.rcRp || 'month')}</select>${ui.rcRp === 'custom' ? `<input type="date" data-ui="rcFrom" data-full="1" value="${esc(ui.rcFrom || r.a)}" aria-label="From"><input type="date" data-ui="rcTo" data-full="1" value="${esc(ui.rcTo || r.b)}" aria-label="To">` : ''}`;
    const gi = GRP.find(g => g[0] === R.g) || [];
    return tabs + `<div class="rc-top"><button class="btn sm" data-act="rc-back">← Sab reports</button><div class="rc-title"><div class="small muted">${gi[2] || ''} ${esc(gi[1] || '')}</div><h2>${esc(R.t)}</h2><div class="small muted">${esc(R.d)}</div></div></div>
      <div class="toolbar">${per}${book}<span style="flex:1"></span><button class="btn sm" data-act="rc-xlsx">${ic('dl', 14)} Excel</button><button class="btn sm" data-act="rc-csv">${ic('dl', 14)} CSV</button><button class="btn sm" data-act="rc-pdf">${ic('dl', 14)} PDF</button></div>
      <div class="small muted" style="margin:-4px 2px 10px">${esc(r.label || '')}${REP_CHAN && REP_CHAN !== 'all' ? ' · ' + (REP_CHAN === 'wholesale' ? 'Wholesale' : 'Retail') + ' only' : ''}${ui.rpBook && ui.rpBook !== 'both' ? ' · ' + (ui.rpBook === 'pakka' ? 'Pakka' : 'Kacha') + ' only' : ''}</div><div id="vbody"></div>`;
  }
  { const V = VIEWDEF.reports; VIEWDEF.reports = { ...V, shell() { if (ui.rTab === 'hub') return hubShell(); return V.shell.call(V); }, body() { if (ui.rTab === 'hub') return ui.rcId ? reportBody() : catalogue(); return V.body.call(V); } }; }

  /* =====================================================================
     exports: CSV, PDF, XLSX
     ===================================================================== */
  const expCols = s => s.cols.map((c, i) => [c, i]).filter(([c]) => c.t !== 'x');
  const plain = (c, v) => { if (v == null || v === '') return ''; if (c.t === 'inr' || c.t === 'inr2') return r2(v); if (c.t === 'g') return r3(v); if (c.t === 'n') return Math.round(num(v)); if (c.t === 'pct') return r2(v); if (c.t === 'd') return fmtD(v); return String(v); };
  const fileBase = X => safeName('shivaa_' + X.R.t.replace(/[^A-Za-z0-9 ]+/g, ' ').trim().toLowerCase() + '_' + (X.R.period === 'none' ? today() : X.R.period === 'asof' ? 'ason_' + X.r.b : X.r.a + '_to_' + X.r.b));
  function toCsv(X) { const L = []; const q = v => { v = String(v ?? ''); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    L.push(q(settings().firm + ' — ' + X.R.t)); L.push(q(X.r.label || '')); (X.out.summary || []).forEach(([k, v]) => L.push(q(k) + ',' + q(v))); L.push('');
    (X.out.sections || []).forEach(s => { if (s.title) L.push(q(s.title)); const E = expCols(s); L.push(E.map(([c]) => q(c.h)).join(',')); s.rows.forEach(r => L.push(r._h ? q(r[0]) : E.map(([c, i]) => q(plain(c, r[i]))).join(','))); if (s.foot) L.push(E.map(([c, i]) => q(plain(c, s.foot[i]))).join(',')); L.push(''); });
    return '﻿' + L.join('\n'); }
  async function toPdf(X) {
    const s = settings(); const wide = (X.out.sections || []).some(z => z.cols.length > 7); const pdf = new Pdf(wide ? 297 : 210, wide ? 210 : 297); const logo = await loadJpeg(s.logo, 400);
    let y = pdfHeader(pdf, s, logo, X.R.t.toUpperCase().slice(0, 60), (X.r.label || '') + (ui.rpBook && ui.rpBook !== 'both' ? ' · ' + ui.rpBook : ''));
    const sm = X.out.summary || []; if (sm.length) { let sx = 12; sm.forEach(([k, v]) => { const w = Math.max(28, Math.max(pdf.font(false, 7.5).width(k), pdf.font(true, 9).width(String(v))) + 6); if (sx + w > pdf.W - 12) { sx = 12; y += 11; } pdf.font(false, 7.5).fill(PC.muted).text(k, sx, y + 3); pdf.font(true, 9).fill(PC.ink).text(String(v), sx, y + 7.5); sx += w; }); y += 12; }
    (X.out.sections || []).forEach(z => { const E = expCols(z); if (y > pdf.H - 40) { pdf.addPage(); y = 14; } if (z.title) { pdf.fill(PC.maroon).font(true, 10).text(z.title, 12, y + 4); y += 7; }
      const W = pdf.W - 24, tw = sum(E, ([c]) => c.w); const cols = E.map(([c]) => ({ h: c.h, w: c.w / tw * W, a: isNumT(c.t) ? 'r' : '' }));
      const rows = z.rows.map(r => r._h ? E.map((e, k) => k === 0 ? { t: String(r[0]), b: 1 } : '') : E.map(([c, i]) => { const t = fmtCell(c.t, r[i]); return r._b ? { t, b: 1 } : t; }));
      if (z.foot) rows.push(E.map(([c, i]) => ({ t: fmtCell(c.t, z.foot[i]), b: 1 })));
      if (!rows.length) rows.push(E.map((e, k) => k === 0 ? (z.empty || '—') : ''));
      y = pdfTable(pdf, cols, rows, y, { onNewPage: yy => yy + 2 }) + 6;
      if (z.note) { pdf.fill(PC.muted).font(false, 7); pdf.wrap(z.note, pdf.W - 24).forEach(t => { if (y > pdf.H - 18) { pdf.addPage(); y = 14; } pdf.text(t, 12, y); y += 3.6; }); y += 2; } });
    if (X.out.note) { pdf.fill(PC.muted).font(false, 7); pdf.wrap('Note: ' + X.out.note, pdf.W - 24).forEach(t => { if (y > pdf.H - 18) { pdf.addPage(); y = 14; } pdf.text(t, 12, y); y += 3.6; }); }
    pdfFooters(pdf, `${X.R.t} · ${s.firm} · generated ${fmtD(today())}`); return pdf.blob();
  }

  /* --- minimal XLSX writer (zip "store" + SpreadsheetML) --- */
  const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = t[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }; })();
  function zip(files) { const enc = new TextEncoder(); const parts = [], cen = []; let off = 0; const d = new Date(); const dt = ((d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1)) & 0xFFFF, dd = (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF;
    files.forEach(([name, text]) => { const nb = enc.encode(name), db = typeof text === 'string' ? enc.encode(text) : text; const crc = CRC(db);
      const h = new DataView(new ArrayBuffer(30)); h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true); h.setUint16(10, dt, true); h.setUint16(12, dd, true); h.setUint32(14, crc, true); h.setUint32(18, db.length, true); h.setUint32(22, db.length, true); h.setUint16(26, nb.length, true); h.setUint16(28, 0, true);
      parts.push(new Uint8Array(h.buffer), nb, db);
      const c = new DataView(new ArrayBuffer(46)); c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true); c.setUint16(12, dt, true); c.setUint16(14, dd, true); c.setUint32(16, crc, true); c.setUint32(20, db.length, true); c.setUint32(24, db.length, true); c.setUint16(28, nb.length, true); c.setUint32(42, off, true);
      cen.push(new Uint8Array(c.buffer), nb); off += 30 + nb.length + db.length; });
    const cs = sum(cen, x => x.length); const e = new DataView(new ArrayBuffer(22)); e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cs, true); e.setUint32(16, off, true);
    return new Blob([...parts, ...cen, new Uint8Array(e.buffer)], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }); }
  const xe = s => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, '');
  const colL = i => { let s = ''; i++; while (i) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
  // styles: 0 normal, 1 header, 2 title, 3 ₹, 4 grams, 5 bold ₹, 6 bold grams, 7 bold text, 8 pct, 9 section
  function sheetXml(X) { const rows = []; let maxC = 2; const widths = [];
    const cell = (ci, ri, v, st) => { if (v === '' || v == null) return st ? `<c r="${colL(ci)}${ri}" s="${st}"/>` : ''; if (typeof v === 'number' && isFinite(v)) return `<c r="${colL(ci)}${ri}" s="${st || 0}"><v>${v}</v></c>`; return `<c r="${colL(ci)}${ri}" t="inlineStr" s="${st || 0}"><is><t xml:space="preserve">${xe(v)}</t></is></c>`; };
    const push = cells => { const ri = rows.length + 1; rows.push(`<row r="${ri}">${cells.map(([v, st], ci) => { const w = String(v ?? '').length; widths[ci] = Math.max(widths[ci] || 8, Math.min(48, w + 2)); return cell(ci, ri, v, st); }).join('')}</row>`); maxC = Math.max(maxC, cells.length); };
    push([[settings().firm + ' — ' + X.R.t, 2]]); push([[X.r.label || '', 0]]); (X.out.summary || []).forEach(([k, v]) => push([[k, 7], [String(v), 0]])); push([]);
    (X.out.sections || []).forEach(s => { const E = expCols(s); if (s.title) push([[s.title, 9]]); push(E.map(([c]) => [c.h, 1]));
      const st = (c, b) => c.t === 'inr' || c.t === 'inr2' ? (b ? 5 : 3) : c.t === 'g' ? (b ? 6 : 4) : c.t === 'pct' ? 8 : (b ? 7 : 0);
      s.rows.forEach(r => push(r._h ? [[String(r[0]), 9]] : E.map(([c, i]) => { const v = plain(c, r[i]); return [v === '' ? '' : (isNumT(c.t) ? num(v) : v), st(c, r._b)]; })));
      if (s.foot) push(E.map(([c, i]) => { const v = plain(c, s.foot[i]); return [v === '' ? '' : (isNumT(c.t) ? num(v) : v), st(c, 1)]; })); if (s.note) push([[s.note, 0]]); push([]); });
    if (X.out.note) push([['Note: ' + X.out.note, 0]]);
    const cols = widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('');
    return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>${cols ? '<cols>' + cols + '</cols>' : ''}<sheetData>${rows.join('')}</sheetData><pageSetup orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>`; }
  function xlsx(list) {   // list: [[sheetName, X]]
    const used = new Set(); const names = list.map(([n]) => { let b = String(n).replace(/[\[\]:*?\/\\]/g, ' ').slice(0, 28).trim() || 'Sheet'; let k = b, i = 2; while (used.has(lc(k))) k = b.slice(0, 26) + ' ' + i++; used.add(lc(k)); return k; });
    const styles = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="3"><numFmt numFmtId="164" formatCode="#,##,##0.00"/><numFmt numFmtId="165" formatCode="0.000"/><numFmt numFmtId="166" formatCode="0.00&quot;%&quot;"/></numFmts><fonts count="4"><font><sz val="10"/><name val="Calibri"/></font><font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font><font><b/><sz val="14"/><color rgb="FF6D1F2C"/><name val="Calibri"/></font><font><b/><sz val="10"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF6D1F2C"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFF7EEDB"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="10"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="164" fontId="3" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/><xf numFmtId="165" fontId="3" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/><xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="0" fontId="3" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`;
    const files = [['[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${list.map((x, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`],
      ['_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`],
      ['xl/workbook.xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${xe(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets></workbook>`],
      ['xl/_rels/workbook.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${list.map((x, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${list.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`],
      ['xl/styles.xml', styles], ...list.map(([, X], i) => [`xl/worksheets/sheet${i + 1}.xml`, sheetXml(X)])];
    return zip(files);
  }

  /* ---- CA pack: the whole financial year in one workbook ---- */
  async function caPack() {
    const fys = []; const t0 = fyStart(today()); for (let i = 0; i < 4; i++) { const s = (+t0.slice(0, 4) - i) + '-04-01'; fys.push([s, 'FY ' + fy(s)]); }
    const el = openModal(`${mHead('CA Pack — saal ka poora hisaab', 'Ek Excel file, har report alag sheet mein')}<div class="m-body"><label class="f"><span>Financial year</span><select data-rc-fy>${fys.map(([s, l], i) => `<option value="${s}"${i === (new Date().getMonth() < 4 ? 1 : 0) ? ' selected' : ''}>${l}</option>`).join('')}</select></label>
      <label class="f"><span>Books</span><select data-rc-book><option value="both">Pakka + Kacha (sab)</option><option value="pakka">Sirf Pakka (official / GST)</option></select></label>
      <p class="small muted">Isme: Trial balance, P&L, Balance sheet, Capital, Loans, 3CD stock (cl. 35), stock valuation, karigar yield, 40A(3), 269ST + PAN, 269SS, SFT, TDS 194Q, advance tax, GSTR-9 data, 9C reconciliation, ITC register, credit/debit notes, sales & purchase registers, party balances, ageing, expenses, salary, fixed assets, scheme, old gold, HUID.</p></div>
      <div class="m-foot"><button class="btn" data-act="close">Cancel</button><button class="btn gold" data-act="rc-capack-go">${ic('dl', 16)} Excel banao</button></div>`);
    return el;
  }
  const CA_LIST = [['Trial balance', 'tb'], ['Profit & Loss', 'pnl'], ['Balance sheet', 'balsheet'], ['Capital & drawings', 'capital'], ['Loans & advances', 'loans'], ['3CD stock qty (cl 35)', 'qty3cd'], ['Stock valuation', 'valuation'], ['Karigar yield', 'karigarloss'], ['Cash 40A(3)', 'cash40a3'], ['Cash 269ST + PAN', 'cash2l'], ['Cash loans 269SS', 'cash269ss'], ['SFT 61A', 'sft'], ['TDS 194Q', 'tds194q'], ['Advance tax', 'advtax'], ['GSTR-9 data', 'gstr9'], ['Turnover recon 9C', 'gst9c'], ['ITC register', 'itc'], ['Credit-Debit notes', 'returns'], ['Sales register', 'salesreg'], ['Purchase register', '_purreg'], ['Party balances', 'outstanding'], ['Receivable ageing', 'ageing'], ['Payables', 'payables'], ['Expenses', 'expense'], ['Salary', 'salary'], ['Fixed assets', 'fixedassets'], ['Gold scheme', 'scheme'], ['Old gold register', 'oldgold'], ['HUID register', 'huid'], ['Cash & bank', 'cashbank']];
  rep('_purreg', 'ca', 'Purchase register (bill-wise)', 'Har kharid bill: supplier, GSTIN, wazan, taxable, GST, total, diya, baaki', { tag: 'CA', defRp: 'fy', build(r) {
    const L = INVS(r.a, r.b, v => isBuy(v.type)).sort((x, y) => x.date.localeCompare(y.date));
    const cols = [C('Date', 'd', 1), C('Bill no', 's', 1.6), C('Type', 's', 1), C('Supplier', 's', 2.4), C('GSTIN', 's', 1.5), C('Net g', 'g'), C('Fine g', 'g'), C('Taxable', 'inr'), C('GST', 'inr'), C('Total', 'inr'), C('Paid', 'inr'), C('Balance', 'inr')];
    const rows = L.map(v => row([v.date, v.supplierBillNo || v.no, (INV_TYPES[v.type] || {}).short, v.partyName, v.partyGstin || (supById(v.partyId) || {}).gstin || '', T(v).net, T(v).fine, T(v).taxable, num(T(v).cgst) + num(T(v).sgst) + num(T(v).igst), invPayable(v), invPaid(v), invDue(v)], { _inv: v.id }));
    return { summary: [['Bills', L.length], ['Purchases', inr(sum(L, invPayable))]], sections: [sec('', cols, rows, { foot: totalsRow(cols, rows) })] };
  } });

  /* ---- confirmation letters PDF ---- */
  async function lettersPdf(info) {
    const s = settings(); const pdf = new Pdf(210, 297); const logo = await loadJpeg(s.logo, 400); let first = true;
    const one = (name, p, side, due, fine) => { if (!first) pdf.addPage(); first = false; let y = pdfHeader(pdf, s, logo, 'BALANCE CONFIRMATION', 'As on ' + fmtD(info.asOf)); y += 6;
      pdf.fill(PC.ink).font(false, 10).text('Date: ' + fmtD(today()), 198, y, { align: 'right' }); y += 4;
      pdf.font(true, 10).text('To,', 14, y); y += 5; pdf.text(name, 14, y); y += 5; pdf.font(false, 9.5); [p.address, [p.city, p.pin].filter(Boolean).join(' - '), p.gstin ? 'GSTIN: ' + p.gstin : '', p.phone ? 'Ph: ' + p.phone : ''].filter(Boolean).forEach(t => { pdf.text(t, 14, y, { maxW: 120 }); y += 4.6; }); y += 6;
      pdf.font(true, 10.5).text('Subject: Confirmation of account balance as on ' + fmtD(info.asOf), 14, y); y += 9; pdf.font(false, 10);
      const dr = side === 'customer' ? (due >= 0 ? 'receivable from you (Debit)' : 'payable to you (Credit)') : (due >= 0 ? 'payable to you (Credit)' : 'receivable from you (Debit)');
      const body = `Dear Sir / Madam,\nAs per our books of account, the balance in your account as on ${fmtD(info.asOf)} is ${inr2(Math.abs(due))} ${dr}${fine ? ', and fine metal balance of ' + num(fine).toFixed(3) + ' g' : ''}.\nKindly verify the same with your books and confirm by signing and returning a copy of this letter. If there is any difference, please send us your statement of account so that it can be reconciled.\nThis is required for the audit of our accounts. If we do not hear from you within 15 days, the balance will be treated as confirmed.`;
      body.split('\n').forEach(par => { pdf.wrap(par, 180).forEach(t => { pdf.text(t, 14, y); y += 5.2; }); y += 2.5; });
      y += 6; pdf.font(true, 10).text('For ' + s.firm, 14, y); y += 18; pdf.font(false, 9).text('Authorised signatory', 14, y);
      y += 14; pdf.stroke(PC.line).lw(0.3).line(14, y, 196, y); y += 8; pdf.font(true, 10).text('CONFIRMATION', 14, y); y += 6; pdf.font(false, 9.5);
      pdf.wrap(`We confirm that the balance of ${inr2(Math.abs(due))} as stated above is correct / the balance as per our books is ₹ ____________________ .`, 180).forEach(t => { pdf.text(t, 14, y); y += 5; });
      y += 16; pdf.text('Signature & stamp: ____________________', 14, y); pdf.text('Date: ____________', 150, y); };
    info.A.forEach(x => one(x.n, custById(x.id) || {}, 'customer', x.due, x.fine)); info.B.forEach(x => one(x.n, supById(x.id) || {}, 'supplier', x.due, 0));
    if (first) { toast('Kisi party ka balance nahi hai', 'err'); return null; }
    pdfFooters(pdf, `Balance confirmation · ${s.firm}`); return pdf.blob();
  }

  /* ---- fixed asset form ---- */
  function faForm(id) {
    const x = id ? (S[FA] || []).find(a => a.id === id) : null; const v = x || { date: today(), block: BLOCKS[0][0], rate: BLOCKS[0][1] };
    openModal(`${mHead(x ? 'Asset badlo' : 'Naya fixed asset', 'Counter, tijori, computer, AC, gaadi…')}<form data-rc-fa="${esc(id || '')}" novalidate><div class="m-body">
      <label class="f"><span>Naam</span><input name="name" required value="${esc(v.name || '')}" placeholder="jaise Godrej tijori"></label>
      <label class="f"><span>Block</span><select name="block">${BLOCKS.map(([b, r]) => `<option value="${esc(b)}" data-r="${r}"${b === v.block ? ' selected' : ''}>${esc(b)} — ${r}%</option>`).join('')}</select></label>
      <div class="two"><label class="f"><span>Kharid date (use shuru)</span><input type="date" name="date" required value="${esc(v.date || '')}"></label><label class="f"><span>Cost ₹ (GST ITC chhod kar)</span><input type="number" step="0.01" min="0" name="cost" required value="${esc(v.cost || '')}"></label></div>
      <div class="two"><label class="f"><span>Depreciation rate %</span><input type="number" step="0.01" min="0" max="100" name="rate" value="${esc(v.rate || '')}"></label><label class="f"><span>Bech diya / hata diya (date)</span><input type="date" name="soldOn" value="${esc(v.soldOn || '')}"></label></div>
      <label class="f"><span>Bill / note</span><input name="notes" value="${esc(v.notes || '')}"></label>
      </div><div class="m-foot">${x && canEditSettings() ? `<button type="button" class="btn danger" data-act="rc-fa-del" data-id="${esc(id)}">Delete</button>` : ''}<span style="flex:1"></span><button type="button" class="btn" data-act="close">Cancel</button><button class="btn primary">Save</button></div></form>`);
  }

  /* ---- reset (Setup) ---- */
  function resetCard() {
    const u = window.SJ_USER; if (u && u.role !== 'owner') return '';
    if (typeof window.SJ_WIPE !== 'function') return '';
    return `<div class="card rc-danger" id="fresh-start"><div class="card-h"><h3>🧹 Sab data mitao — shuru se start</h3></div>
      <p class="small muted" style="margin-top:0">Trial / testing ka saara data (bills Pakka-Kacha, Wholesale-Retail, stock, parties, payments, kharche, karigar, scheme, estimates, audit…) ek saath mit jayega aur software bilkul naya ho jayega. Logins (Owner + staff) waise hi rahenge. Sirf <b>Owner</b> kar sakta hai.</p>
      <div class="btns"><button class="btn danger" data-act="rc-wipe">Sab data mitao…</button></div></div>`;
  }
  { const V = VIEWDEF.setup; if (V) VIEWDEF.setup = { ...V, body() { return V.body.call(V) + resetCard(); } }; }
  function wipeDialog() {
    openModal(`${mHead('⚠ Sab data mitao', 'Ye kaam wapas nahi hota — dhyan se padhiye')}<form data-rc-wipe novalidate><div class="m-body">
      <div class="rc-warn"><b>Kya mitega:</b> saare bills (GST, estimate, metal, purchase, old gold), payments, stock / vault, parties, karigar jobs, scheme, estimates, deals, kharche, bank entries, rate history, tags, RFID audit, audit trail, trash.<br><b>Kya rahega:</b> Owner aur staff ke logins.</div>
      <p class="small"><b>Step 1 — pehle backup lijiye</b> (agar galti se mita diya to isi file se "Restore from backup" karke sab wapas aa jayega):</p>
      <div class="btns"><a class="btn" href="${esc(window.SJ_EXPORT_URL || 'sj-api.php?a=export')}" download data-rc-bk>${ic('dl', 16)} Server backup download karo</a></div>
      <p class="small"><b>Step 2 — kya rakhna hai:</b></p>
      <label class="chk"><input type="checkbox" name="keepSettings" checked> Dukaan ki settings rakho (naam, GSTIN, logo, bank, bill design, tag settings) — opening balance 0 ho jayega</label>
      <label class="chk"><input type="checkbox" name="keepParties"> Customers & suppliers ki list rakho (sirf naam-number; unka hisaab mit jayega)</label>
      <p class="small muted" style="margin:4px 0 0 28px">Na rakhein to bhi Shivaa ki B2B parties ki list (170) agli baar khulte hi apne aap wapas jud jayegi.</p>
      <p class="small"><b>Step 3 — confirm:</b></p>
      <div class="two"><label class="f"><span>Neeche <b>DELETE</b> likhiye</span><input name="confirm" autocomplete="off" required placeholder="DELETE"></label><label class="f"><span>Owner ka password</span><input type="password" name="password" autocomplete="current-password" required></label></div>
      <div class="rc-err small red" hidden></div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn danger" type="submit">Haan, sab mitao</button></div></form>`, { small: true });
  }

  /* ---- events ---- */
  document.addEventListener('click', async e => { const t = e.target.closest && e.target.closest('[data-act]'); if (!t) return; const a = t.dataset.act;
    try { switch (a) {
      case 'rc-open': { const R = RMAP[t.dataset.id]; if (!R) break; if (R.link) { R.link(); break; } ui.rcId = R.id; if (R.defRp) { ui.rcRp = R.defRp; } renderView(true); window.scrollTo(0, 0); break; }
      case 'rc-back': ui.rcId = ''; renderView(true); window.scrollTo(0, 0); break;
      case 'rc-csv': case 'rc-pdf': case 'rc-xlsx': { const X = buildCur(); if (!X) break; const f = fileBase(X);
        if (a === 'rc-csv') await offerDownload(f + '.csv', new Blob([toCsv(X)], { type: 'text/csv;charset=utf-8' }));
        else if (a === 'rc-pdf') { toast('PDF ban raha hai…'); await offerDownload(f + '.pdf', await toPdf(X)); }
        else await offerDownload(f + '.xlsx', xlsx([[X.R.t, X]])); break; }
      case 'rc-capack': caPack(); break;
      case 'rc-capack-go': { const ov = t.closest('.overlay'); const s0 = $('[data-rc-fy]', ov).value; const bk = $('[data-rc-book]', ov).value; const r = { a: s0, b: fyEnd(s0), label: 'FY ' + fy(s0) + ' (' + fmtD(s0) + ' to ' + fmtD(fyEnd(s0)) + ')' };
        toast('CA Pack ban raha hai…'); const keep = ui.rpBook; ui.rpBook = bk; const list = [];
        try { CA_LIST.forEach(([n, id]) => { const R = RMAP[id]; if (!R || !R.build) return; const rr = R.period === 'asof' ? { a: '2000-01-01', b: r.b, label: 'As on ' + fmtD(r.b) } : R.period === 'none' ? { a: r.a, b: r.b, label: 'As on ' + fmtD(today()) + ' (current)' } : r; try { list.push([n, { R, r: rr, out: withBook(bk, () => R.build(rr)) }]); } catch (err) { console.error(id, err); } }); } finally { ui.rpBook = keep; }
        const idx = { R: { t: 'CA Pack — index' }, r, out: { summary: [['Firm', settings().firm], ['GSTIN', settings().gstin || ''], ['Period', r.label], ['Books', bk === 'pakka' ? 'Pakka only' : 'Pakka + Kacha'], ['Generated', fmtD(today())]], sections: [sec('Sheets', [C('#', 'n'), C('Sheet', 's', 3), C('Report', 's', 4)], list.map(([n, X], i) => [i + 2, n, X.R.t]))] } };
        await offerDownload(safeName('shivaa_CA_pack_' + fy(s0)) + '.xlsx', xlsx([['Index', idx], ...list])); if (ov) closeModal(ov); break; }
      case 'rc-letters': { const X = LAST && LAST.R.id === 'confirm' ? LAST : buildCur(); if (!X || !X.out._letters) break; toast('Letters ban rahe hain…'); const b = await lettersPdf(X.out._letters); if (b) await offerDownload(safeName('shivaa_balance_confirmation_' + X.r.b) + '.pdf', b); break; }
      case 'rc-fa-edit': faForm(t.dataset.id || ''); break;
      case 'rc-fa-del': { const id = t.dataset.id; if (!id || !confirmBox()) break; if (await removeDoc(FA, id)) { closeModal(t.closest('.overlay')); toast('Asset delete ho gaya'); } break; }
      case 'rc-wipe': wipeDialog(); break;
    } } catch (err) { console.error(err); toast('Kuch galat hua — dobara try kijiye', 'err'); } });
  const confirmBox = () => true;   // the form already asks; delete stays in Trash for 30 days

  document.addEventListener('input', e => { const t = e.target; if (t.classList && t.classList.contains('rc-q')) { const q = lc(t.value).trim(); $$('.rc-card').forEach(c => { c.hidden = !!q && !c.dataset.k.includes(q); }); $$('.rc-grp').forEach(g => { g.hidden = !$$('.rc-card', g).some(c => !c.hidden); }); } });
  document.addEventListener('change', async e => { const t = e.target; if (!t.dataset || t.dataset.rcSet === undefined) return; const k = t.dataset.rcSet; if (!canEditSettings()) { toast('Sirf Owner / Manager badal sakte hain', 'err'); return; }
    const s = { ...S.settings }; s[k] = t.value === '' ? '' : num(t.value); await saveSettings(s); renderView(true); });
  document.addEventListener('submit', async e => { const f = e.target;
    if (f.dataset && f.dataset.rcFa !== undefined) { e.preventDefault(); const id = f.dataset.rcFa || uid('fa'); const g = n => f.elements[n].value; const prev = (S[FA] || []).find(x => x.id === id) || {};
      const obj = { ...prev, id, name: g('name').trim(), block: g('block'), date: g('date'), cost: num(g('cost')), rate: g('rate') === '' ? num((BLOCKS.find(b => b[0] === g('block')) || [0, 15])[1]) : num(g('rate')), soldOn: g('soldOn'), notes: g('notes'), createdAt: prev.createdAt || Date.now(), updatedAt: Date.now() };
      if (!obj.name || !obj.date || !(obj.cost > 0)) { toast('Naam, date aur cost bhariye', 'err'); return; }
      if (await save(FA, obj)) { closeModal(f.closest('.overlay')); toast('Asset save ho gaya'); renderView(true); } return; }
    if (f.dataset && f.dataset.rcWipe !== undefined) { e.preventDefault(); const err = $('.rc-err', f); const btn = f.querySelector('[type=submit]'); err.hidden = true;
      if (!f.elements.password.value) { err.textContent = 'Owner ka password daaliye.'; err.hidden = false; return; }
      if (f.elements.confirm.value.trim() !== 'DELETE') { err.textContent = 'Confirm karne ke liye bade aksharon mein DELETE likhiye.'; err.hidden = false; return; }
      btn.disabled = true; btn.textContent = 'Mita raha hoon…';
      try { const r = await window.SJ_WIPE({ password: f.elements.password.value, confirm: 'DELETE', keepSettings: f.elements.keepSettings.checked, keepParties: f.elements.keepParties.checked });
        try { sessionStorage.setItem('sj-wiped', String(r.deleted || 0)); } catch (x) { /* ignore */ }
        btn.textContent = 'Ho gaya ✓'; setTimeout(() => location.reload(), 600);
      } catch (x) { err.textContent = x.message || 'Nahi ho paya'; err.hidden = false; btn.disabled = false; btn.textContent = 'Haan, sab mitao'; } }
  });
  document.addEventListener('change', e => { const t = e.target; if (t.name === 'block' && t.closest('[data-rc-fa]')) { const o = t.selectedOptions[0]; const r = t.form.elements.rate; if (o && r) r.value = o.dataset.r; } });
  setTimeout(() => { let n = null; try { n = sessionStorage.getItem('sj-wiped'); sessionStorage.removeItem('sj-wiped'); } catch (x) { /* ignore */ } if (n !== null) toast('✓ Saara purana data mit gaya (' + n + ' records). Ab shuru se shuru kijiye!'); }, 2500);

  /* quick find knows the report centre */
  if (typeof pcPalCmds === 'function') { const PC0 = pcPalCmds; pcPalCmds = function () { const L = PC0.apply(this, arguments); REPS.forEach(R => L.push({ ic: 'chart', t: R.t, s: 'Report Centre', run: () => { if (R.link) return R.link(); goTo('reports', { rTab: 'hub', rcId: R.id, ...(R.defRp ? { rcRp: R.defRp } : {}) }); } })); return L; }; }

  /* ---- styles ---- */
  const css = document.createElement('style'); css.textContent = `
  .rc-hero{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between}
  .rc-hero h3{margin:0 0 2px}.rc-hero .btns{display:flex;gap:8px;flex-wrap:wrap;flex:1;justify-content:flex-end;min-width:240px}
  .rc-q{flex:1;min-width:180px;max-width:360px}
  .rc-grp{margin:18px 0 6px}.rc-gh{display:flex;align-items:center;gap:10px;margin:0 2px 10px}.rc-gh .pill{margin-left:auto}
  .rc-gi{font-size:22px;width:40px;height:40px;display:grid;place-items:center;border-radius:12px;background:var(--card3);border:1px solid var(--line)}
  .rc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:10px}
  .rc-card{position:relative;text-align:left;display:flex;flex-direction:column;gap:4px;padding:14px 14px 12px;border-radius:16px;background:var(--card);border:1px solid var(--line);color:var(--ink);cursor:pointer;font:inherit;transition:border-color .15s,transform .15s}
  .rc-card:hover,.rc-card:focus-visible{border-color:var(--gold);transform:translateY(-1px)}
  .rc-card b{font-size:14px;color:var(--head);padding-right:34px}.rc-n{position:absolute;top:12px;right:12px;font-size:11px;color:var(--muted);font-variant-numeric:tabular-nums}
  .rc-tag{align-self:flex-start;margin-top:4px;font-size:10.5px;font-weight:800;letter-spacing:.06em;padding:2px 8px;border-radius:99px;background:color-mix(in srgb,var(--gold) 18%,transparent);color:var(--gold)}
  .rc-tag.lk{background:var(--card3);color:var(--ink2);letter-spacing:0;font-weight:700}
  .rc-top{display:flex;gap:12px;align-items:flex-start;margin:4px 0 12px}.rc-title h2{margin:2px 0;font-size:20px;color:var(--head)}
  .rc-sec h3{margin:4px 6px 10px}.rc-tbl td.num{font-variant-numeric:tabular-nums;white-space:nowrap}
  .rc-tbl tr.rc-b td{font-weight:800;background:var(--card2)}.rc-tbl tr.rc-h td{font-weight:800;letter-spacing:.06em;color:var(--gold);background:var(--card3);text-transform:uppercase;font-size:11.5px}
  .rc-tbl tr.click{cursor:pointer}.rc-tbl tr.click:hover td{background:var(--card3)}
  .rc-note{margin:8px 6px 0}.rc-warn{border:1px solid color-mix(in srgb,var(--amber) 50%,transparent);background:color-mix(in srgb,var(--amber) 8%,transparent);border-radius:14px;padding:12px 14px;margin-bottom:12px;display:flex;flex-direction:column;gap:4px}
  .rc-tools{gap:12px;flex-wrap:wrap;align-items:center}.rc-tools input{margin-left:6px}
  .rc-bars{display:flex;flex-direction:column;gap:6px}.rc-bar{display:grid;grid-template-columns:minmax(90px,180px) 1fr auto;gap:10px;align-items:center;font-size:12.5px}
  .rc-bar .l{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--ink2)}.rc-bar .t{height:10px;border-radius:6px;background:var(--track);overflow:hidden}
  .rc-bar .t i{display:block;height:100%;border-radius:6px;background:var(--gold)}.rc-bar .t i.neg{background:var(--red)}.rc-bar .v{font-variant-numeric:tabular-nums;font-weight:700;min-width:70px;text-align:right}
  .rc-line svg{width:100%;height:160px;display:block}.rc-line .a{fill:color-mix(in srgb,var(--gold) 16%,transparent)}.rc-line .s{fill:none;stroke:var(--gold);stroke-width:2;vector-effect:non-scaling-stroke}
  .rc-line-l{display:flex;justify-content:space-between;font-size:11.5px;color:var(--muted)}
  .rc-danger{border-color:color-mix(in srgb,var(--red) 45%,var(--line))}.rc-danger h3{color:var(--red)}
  @media (max-width:640px){.rc-grid{grid-template-columns:1fr}.rc-top{flex-direction:column}.rc-hero .btns{justify-content:stretch}.rc-q{max-width:none}.rc-bar{grid-template-columns:90px 1fr auto}}
  @media print{.rc-top .btn,.toolbar,.rep-tabs{display:none!important}}`;
  document.head.appendChild(css);

  /* =====================================================================
     Shivaa B2B parties — added automatically once (Owner / Manager)
     The list lives on the server (sj-data/sj-b2b-seed.php, not public).
     Fixed ids (c_b2b_<phone> / s_b2b_<phone>) → never added twice, even
     if two phones open the app at the same time. Existing parties with the
     same phone number are left untouched.
     ===================================================================== */
  const SEED_V = 'b2b-2026-11b';
  let seedBusy = false, seedInfo = null;
  const canSeed = () => { const u = window.SJ_USER; return !!u && (u.role === 'owner' || u.role === 'manager') && typeof window.SJ_SEED === 'function'; };
  async function seedParties(manual) {
    if (seedBusy || !canSeed()) return; seedBusy = true;
    try {
      const r = await window.SJ_SEED(); const L = r.parties || []; if (!L.length) { toast('B2B parties ki list server par nahi mili — zip ki sj-data/sj-b2b-seed.php file upload kijiye', 'err'); return false; }
      const custPh = new Set(); S.customers.forEach(c => { custPh.add(String(c.phone || '').slice(-10)); (c.phones || []).forEach(p => custPh.add(String(p).slice(-10))); });
      const supPh = new Set(); S.suppliers.forEach(c => { supPh.add(String(c.phone || '').slice(-10)); (c.phones || []).forEach(p => supPh.add(String(p).slice(-10))); });
      const now = Date.now(); const jobs = []; let nc = 0, ns = 0, skip = 0;
      L.forEach((p, i) => {
        const sup = String(p.kind).startsWith('sup:'); const id = (sup ? 's_b2b_' : 'c_b2b_') + p.phone; const phones = (p.phones || [p.phone]).map(String);
        const have = sup ? (S.suppliers.some(x => x.id === id) || phones.some(x => supPh.has(x))) : (S.customers.some(x => x.id === id) || phones.some(x => custPh.has(x)));
        if (have) { skip++; return; }
        const base = { id, name: p.name, phone: p.phone, phones, contact: p.contact || '', city: p.city || '', address: p.address || '', pin: '', gstin: '', pan: '', notes: p.notes || '', source: 'Shivaa B2B list', imported: true, createdAt: now + i, updatedAt: now };
        if (sup) { jobs.push(save('suppliers', { ...base, type: p.kind.slice(4) || 'Wholesaler', wastage: [], banks: [] }, { quiet: true })); ns++; }
        else { jobs.push(save('customers', { ...base, ptype: p.kind === 'retail' ? 'Retail' : 'B2B', creditLimit: 500000, creditDays: 0, margins: [], wastage: [] }, { quiet: true })); nc++; }
      });
      // earlier list version put some shops under Suppliers — they are B2B customers now; remove those auto-made suppliers if they have no bills
      S.suppliers.filter(x => String(x.id).startsWith('s_b2b_') && x.source === 'Shivaa B2B list' && !S.invoices.some(v => v.partyId === x.id) && !(S.jobs || []).some(j => j.karigarId === x.id)).forEach(x => jobs.push(removeDoc('suppliers', x.id)));
      await Promise.all(jobs);
      if (!S.settings || S.settings.b2bSeed !== (r.version || SEED_V)) await saveSettings({ ...S.settings, b2bSeed: r.version || SEED_V, b2bSeedAt: today() });
      seedInfo = { nc, ns, skip, total: L.length };
      if (nc || ns) toast(`✓ Shivaa ki B2B list jud gayi — ${nc} B2B parties`); else if (manual) toast('Sab parties pehle se hain ✓');
      renderView(true); return true;
    } catch (e) { console.error('[b2b seed]', e); toast('B2B parties nahi jud paayi: ' + (e.message || 'server error') + ' — Setup → "Check karo" dabaiye', 'err'); return false; }
    finally { seedBusy = false; }
  }
  // wait (as long as it takes — setup / login can take minutes), then add the list once; retry if the server was busy
  let seedTries = 0;
  (function waitAndSeed() {
    const ready = typeof MODE !== 'undefined' && MODE === 'cloud' && typeof settingsLoaded !== 'undefined' && settingsLoaded && canSeed();
    if (!ready) { setTimeout(waitAndSeed, 2000); return; }
    setTimeout(async () => { if (S.settings && S.settings.b2bSeed === SEED_V) return; seedTries++; const ok = await seedParties(false);
      if (!ok && seedTries < 5) setTimeout(waitAndSeed, 30000); }, 3500);   // let the first sync finish
  })();
  function seedCard() {
    if (!canSeed()) return '';
    const n = S.customers.filter(c => String(c.id).startsWith('c_b2b_')).length, m = S.suppliers.filter(c => String(c.id).startsWith('s_b2b_')).length;
    return `<div class="card" id="b2b-list"><div class="card-h"><h3>👥 Shivaa B2B parties (WhatsApp list)</h3></div><div class="auto-row" style="border:0;padding-top:0"><div style="flex:1;min-width:0"><b>${n} B2B parties${m ? ' · ' + m + ' suppliers' : ''}</b><div class="small muted">188 WhatsApp number → 170 B2B parties (ek dukaan ke kai number ek hi party mein). Pehli baar software khulte hi apne aap jud jaati hain aur sab phone par sync hoti hain. Kuch mit gaya ho to "Check karo" dabaiye — sirf jo nahi hain wahi judenge.${S.settings && S.settings.b2bSeedAt ? ' Last: ' + fmtD(S.settings.b2bSeedAt) + '.' : ''}</div></div><button class="btn sm" data-act="rc-seed">Check karo</button></div></div>`;
  }
  { const V = VIEWDEF.setup; if (V) VIEWDEF.setup = { ...V, body() { return V.body.call(V) + seedCard(); } }; }
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act="rc-seed"]'); if (t) seedParties(true); });

  window.SJ_REPORTS = { list: () => REPS.map(r => ({ id: r.id, g: r.g, t: r.t })), build: (id, a, b) => { const R = RMAP[id]; return R && R.build ? R.build({ a, b, label: '' }) : null; }, xlsx, toCsv, toPdf,
    // other modules add their own reports here
    addGroup: (g, label, icon, desc) => { if (!GRP.some(x => x[0] === g)) GRP.push([g, label, icon, desc]); },
    add: (id, g, t, d, o) => rep(id, g, t, d, o), addCa: (name, id) => { if (!CA_LIST.some(x => x[1] === id)) CA_LIST.push([name, id]); },
    open: (id, rp) => { const R = RMAP[id]; if (!R) return; if (!R.build && R.link) return R.link(); goTo('reports', { rTab: 'hub', rcId: id, ...(rp || R.defRp ? { rcRp: rp || R.defRp } : {}) }); },
    h: { C, sec, row, totalsRow, barsHtml, lineHtml, fmtCell, pctOf, months, fyStart, fyEnd, dueAsOf, payRows } };
})();
