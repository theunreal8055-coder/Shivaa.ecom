/* =====================================================================
   SJ PWA — "Install app" banner + service worker
   - As soon as the website opens, a banner offers to install the app
     (Android / Chrome / Edge / Samsung: one tap "Install").
   - iPhone / iPad (Safari): shows the 2-step "Share → Add to Home Screen" guide.
   - Setup page gets an "App install" card too.
   Browsers never allow a website to install itself without one tap from
   the user — the banner makes that one tap as easy as possible.
   ===================================================================== */
(() => {
  'use strict';
  const KEY = 'sj-pwa-later';
  const ls = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } } };
  const standalone = () => (window.matchMedia && (matchMedia('(display-mode: standalone)').matches || matchMedia('(display-mode: window-controls-overlay)').matches)) || navigator.standalone === true;
  const ua = navigator.userAgent || '';
  const isIOS = /iphone|ipad|ipod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  const iosSafari = isIOS && !/CriOS|FxiOS|EdgiOS|OPiOS/i.test(ua);
  let deferred = null, bar = null;

  /* ---- service worker ---- */
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').then(reg => {
        // a newer version was uploaded: use it on the next open
        reg.addEventListener('updatefound', () => { const w = reg.installing; if (w) w.addEventListener('statechange', () => { if (w.state === 'installed' && navigator.serviceWorker.controller) w.postMessage('skipWaiting'); }); });
        setInterval(() => reg.update().catch(() => null), 60 * 60 * 1000);
      }).catch(e => console.warn('[pwa] service worker', e));
    });
  }

  /* ---- banner ---- */
  const css = `
  .sjp-bar{position:fixed;left:50%;bottom:16px;transform:translate(-50%,140%);z-index:2100;width:min(560px,calc(100% - 24px));display:flex;gap:12px;align-items:center;padding:12px 12px 12px 14px;border-radius:20px;
    background:linear-gradient(135deg,#1a140b,#0b0906);border:1px solid rgba(212,175,55,.55);box-shadow:0 18px 50px rgba(0,0,0,.55);color:#f3ead6;font:500 14px/1.35 "Plus Jakarta Sans",system-ui,sans-serif;transition:transform .35s cubic-bezier(.2,.8,.2,1)}
  .sjp-bar.on{transform:translate(-50%,0)}
  .sjp-bar img{width:46px;height:46px;border-radius:12px;flex:none}
  .sjp-bar .t{flex:1;min-width:0}.sjp-bar b{display:block;font-size:15px;color:#fff}.sjp-bar small{color:#c9b98f;font-size:12.5px}
  .sjp-bar .bt{display:flex;gap:6px;flex:none}
  .sjp-bar button{font:700 13.5px "Plus Jakarta Sans",system-ui,sans-serif;border-radius:12px;padding:10px 14px;cursor:pointer;border:1px solid rgba(212,175,55,.35);background:transparent;color:#e9dcb8}
  .sjp-bar button.go{background:linear-gradient(180deg,#f0d68c,#b8892e);color:#1a1206;border:0}
  .sjp-ios{display:flex;flex-direction:column;gap:2px}.sjp-ios i{font-style:normal;display:inline-block;padding:0 6px;border-radius:6px;background:rgba(212,175,55,.18);color:#f0d68c}
  @media (max-width:900px){.sjp-bar{bottom:calc(84px + env(safe-area-inset-bottom,0px))}}
  @media (max-width:420px){.sjp-bar{flex-wrap:wrap}.sjp-bar .bt{width:100%}.sjp-bar .bt button{flex:1}}
  @media (prefers-reduced-motion:reduce){.sjp-bar{transition:none}}`;
  function addCss() { if (document.getElementById('sjp-css')) return; const s = document.createElement('style'); s.id = 'sjp-css'; s.textContent = css; document.head.appendChild(s); }
  function hide(later) { if (later) ls.set(KEY, String(Date.now())); if (bar) { bar.classList.remove('on'); const b = bar; bar = null; setTimeout(() => b.remove(), 400); } }
  function snoozed() { const t = Number(ls.get(KEY) || 0); return t && Date.now() - t < 2 * 864e5; }   // "Baad mein" = ask again after 2 days
  function show(html) {
    if (bar || standalone()) return; addCss();
    bar = document.createElement('div'); bar.className = 'sjp-bar'; bar.setAttribute('role', 'dialog'); bar.setAttribute('aria-label', 'Install app'); bar.innerHTML = html;
    document.body.appendChild(bar); requestAnimationFrame(() => requestAnimationFrame(() => bar && bar.classList.add('on')));
    bar.addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; if (b.dataset.k === 'go') install(); else hide(true); });
  }
  const ICON = '<img src="icon-192.png" alt="">';
  function showInstall(force) { if (!deferred || (!force && snoozed())) return; show(`${ICON}<div class="t"><b>Shivaa Jewels app install karein</b><small>Home screen par icon · full screen · tez khulega</small></div><div class="bt"><button data-k="later">Baad mein</button><button class="go" data-k="go">Install</button></div>`); }
  function showIOS(force) { if (!iosSafari || standalone() || (!force && snoozed())) return; show(`${ICON}<div class="t sjp-ios"><b>iPhone par app banayein</b><small>Neeche <i>Share ⬆︎</i> dabaiye → <i>Add to Home Screen</i> → <i>Add</i></small></div><div class="bt"><button class="go" data-k="later">Theek hai</button></div>`); }
  async function install() {
    if (!deferred) { if (iosSafari) { hide(false); showIOS(true); } else toast2('Browser menu (⋮) → "Install app" / "Add to Home screen" chuniye'); return; }
    const d = deferred; deferred = null; hide(false);
    try { d.prompt(); const r = await d.userChoice; if (r && r.outcome === 'dismissed') ls.set(KEY, String(Date.now())); } catch (e) { console.warn(e); }
    refreshCard();
  }
  function toast2(msg) { if (typeof toast === 'function') toast(msg); else alert(msg); }

  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); deferred = e; refreshCard(); const go = () => showInstall(false); if (document.readyState === 'complete') setTimeout(go, 600); else window.addEventListener('load', () => setTimeout(go, 600), { once: true }); });
  window.addEventListener('appinstalled', () => { deferred = null; hide(false); refreshCard(); toast2('✓ App install ho gaya — home screen par "Shivaa Jewels" icon dekhiye'); });
  window.addEventListener('load', () => setTimeout(() => showIOS(false), 1500));

  /* ---- Setup page card ---- */
  function cardHtml() {
    const done = standalone();
    const how = done ? 'Aap abhi app mein hi hain ✓' : deferred ? 'Ek tap mein phone / computer par app ban jayega — icon home screen / desktop par.' : iosSafari ? 'iPhone: Safari mein <b>Share ⬆︎</b> → <b>Add to Home Screen</b> → <b>Add</b>.' : 'Chrome / Edge: address bar ke daayein install icon ya menu (⋮) → <b>Install app</b> / <b>Add to Home screen</b>. (Website https:// par honi chahiye.)';
    return `<div class="card" id="sjp-card"><div class="card-h"><h3>📲 App install</h3></div><div class="auto-row" style="border:0;padding-top:0"><img src="icon-192.png" alt="" style="width:44px;height:44px;border-radius:12px;flex:none"><div style="flex:1;min-width:0"><b>Shivaa Jewels app</b><div class="small muted">${how}</div></div>${!done && (deferred || iosSafari) ? '<button class="btn gold" data-act="sjp-install">Install</button>' : ''}</div></div>`;
  }
  function refreshCard() { const c = document.getElementById('sjp-card'); if (c) c.outerHTML = cardHtml(); }
  if (typeof VIEWDEF !== 'undefined' && VIEWDEF.setup) { const V = VIEWDEF.setup; VIEWDEF.setup = { ...V, body() { return cardHtml() + V.body.call(V); } }; }
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act="sjp-install"]'); if (t) { if (deferred) install(); else if (iosSafari) showIOS(true); } });

  window.SJ_PWA = { install, state: () => ({ standalone: standalone(), canPrompt: !!deferred, iosSafari }) };
})();
