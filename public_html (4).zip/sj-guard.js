/* =====================================================================
   Shivaa Jewels — SURAKSHA (security) screens · v41
   The rules themselves are enforced on the server (sj-sec.php). This file:
   • Setup → "🛡 Suraksha" card: niyam (hours, devices, PIN, 2-step for
     all, discount / purana-sona seema, din-band lock, export, floor wall,
     phone/PAN chhupana, field seema), devices approve/block, staff ke
     niyam (floor / field / hours / PIN reset / 2-step reset), mera PIN,
     mera 2-step, na-mitne-wala record jaanch, cron & RFID gate keys
   • Manzoori (maker-checker): bill / purana sona over the limit → request
     → Manager / Owner approves on their phone → bill saves by itself
   • Auto screen lock after idle minutes (PIN to open)
   • Phone / PAN / Aadhaar masked on screen for Staff
   • Rakhwala report: what went wrong — alerts, tally gaps, manual
     weights, new devices — with WhatsApp share
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { role: 'owner', name: 'Owner', uname: 'owner' };
  const role = () => me().role || 'owner';
  const isOwner = () => !SITE || role() === 'owner';
  const boss = () => !SITE || role() === 'owner' || role() === 'manager';
  const pol = () => (window.SJ_SEC && SJ_SEC.policy) || {};
  const q$ = (s, r) => (r || document).querySelector(s);
  const API = (a, b, ms) => window.SJ_API_CALL(a, b || {}, ms);
  ['sjReqs'].forEach(c => { if (!COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const css = t => { const s = document.createElement('style'); s.textContent = t; document.head.appendChild(s); };
  const fmtT = ms => ms ? new Date(ms).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';

  /* ================= MANZOORI (maker-checker) ================= */
  // extra signed fields ride along on the bill the builder saves
  let EXTRA = null;
  if (typeof save === 'function') {
    const SV = save;
    save = function (col, obj, o) { if (EXTRA && col === 'invoices' && obj && !obj.discOk && !obj.ogOk) obj = { ...obj, ...EXTRA }; return SV.call(this, col, obj, o); };
  }
  function waitApproval(req) {
    return new Promise(resolve => {
      const el = openModal(`${mHead('⏳ Manzoori ka intezaar', esc(req.title))}<div class="m-body"><div class="gd-wait"><div class="gd-spin"></div><div><b>${esc(req.text)}</b><p class="small muted" style="margin:6px 0 0">Manager / Owner ke phone par request chali gayi hai. Manzoor hote hi bill apne aap save ho jayega — ye screen khuli rakhiye.</p></div></div></div><div class="m-foot"><button type="button" class="btn" data-act="gd-wait-x">Request wapas lo</button></div>`);
      el.classList.add('gd-wait-ov'); let fin = false;
      const end = v => { if (fin) return; fin = true; clearInterval(t); if (el.isConnected) closeModal(el); resolve(v); };
      const t = setInterval(() => { const r = (S.sjReqs || []).find(x => x.id === req.id); if (!r) return; if (r.status === 'approved' && r.tok) end(r); else if (r.status === 'rejected') { toast('❌ ' + (r.decidedBy || 'Manager') + ' ne manzoori nahi di' + (r.why ? ': ' + r.why : ''), 'err'); end(null); } }, 700);
      el._cancel = async () => { await save('sjReqs', { ...req, status: 'cancelled' }, { quiet: true }); end(null); };
      new MutationObserver((m, ob) => { if (!el.isConnected) { ob.disconnect(); end(null); } }).observe(q$('#modal-root'), { childList: true });
    });
  }
  async function ask(kind, ref, val, title, text, extra) {
    const prev = (S.sjReqs || []).find(x => x.kind === kind && x.ref === ref && String(x.val) === String(val) && x.status === 'approved' && x.tok);
    if (prev) return prev;
    const req = { id: uid('rq'), kind, ref, val: String(val), title, text, status: 'pending', at: Date.now(), by: me().name, byUser: me().uname, ...(extra || {}) };
    if (!await save('sjReqs', req)) return null;
    return waitApproval(req);
  }
  if (typeof persistInvoice === 'function') {
    const P0 = persistInvoice;
    persistInvoice = async function (st) {
      const p = pol(), r = role();
      if (!SITE || r === 'owner') return P0.apply(this, arguments);
      try {
        const v = validateInvoice(st); if (v.error) return P0.apply(this, arguments);
        const oldMetal = isBuy(st.type) ? [] : (st.oldMetal || []).filter(o => num(o.gross) > 0);
        const t = invTotals({ ...st, items: v.items, oldMetal }, v.party);
        const lim = r === 'manager' ? num(p.discMgr) : num(p.discStaff);
        const pct = t.itemsTotal > 0 ? Math.round(t.discount / t.itemsTotal * 10000) / 100 : 0;
        const origPct = st.orig && st.orig.totals && num(st.orig.totals.itemsTotal) > 0 ? Math.round(num(st.orig.totals.discount) / num(st.orig.totals.itemsTotal) * 10000) / 100 : null;
        let extra = {};
        if (lim > 0 && pct > lim + 0.01 && (origPct === null || Math.abs(origPct - pct) > 0.01)) {
          st.discKey = st.discKey || (typeof INV !== 'undefined' && INV && INV.discKey) || uid('dk'); if (typeof INV !== 'undefined' && INV) INV.discKey = st.discKey;
          const ref = st.discKey + '|' + v.party.id + '|' + Math.round(t.itemsTotal), val = Math.ceil(pct - 0.001);
          const a = await ask('disc', ref, val, 'Discount ' + pct + '% · ' + v.party.name, `${v.party.name} ke bill par ${pct}% discount (${inr(t.discount)}) — aapki seema ${lim}% hai`, { party: v.party.name, amount: Math.round(t.discount), pct, bill: Math.round(t.grand) });
          if (!a) return { error: 'Discount ki manzoori nahi mili — bill save nahi hua' };
          extra = { discKey: st.discKey, discOk: a.tok };
        }
        if (st.type === 'oldgold' && r === 'staff' && num(p.ogStaff) > 0 && t.payable > num(p.ogStaff) && (!st.orig || Math.abs(num(st.orig.totals && st.orig.totals.payable) - t.payable) > 1)) {
          st.ogKey = st.ogKey || (typeof INV !== 'undefined' && INV && INV.ogKey) || uid('ok'); if (typeof INV !== 'undefined' && INV) INV.ogKey = st.ogKey;
          const ref = st.ogKey + '|' + v.party.id, val = Math.round(t.payable);
          const a = await ask('og', ref, val, 'Purana sona ' + inr(val) + ' · ' + v.party.name, `${v.party.name} se ${inr(val)} ka purana sona — seema ${inr(p.ogStaff)}`, { party: v.party.name, amount: val });
          if (!a) return { error: 'Purane sone ki manzoori nahi mili — bill save nahi hua' };
          extra = { ...extra, ogKey: st.ogKey, ogOk: a.tok, ogMax: val };
        }
        EXTRA = Object.keys(extra).length ? extra : null;
        try { return await P0.apply(this, arguments); } finally { EXTRA = null; }
      } catch (e) { console.error(e); EXTRA = null; return P0.apply(this, arguments); }
    };
  }
  // inbox for Manager / Owner
  const pending = () => (S.sjReqs || []).filter(x => x.status === 'pending' && Date.now() - num(x.at) < 6 * 3600e3).sort((a, b) => a.at - b.at);
  let inboxPill = null, seenReq = new Set(), primed = false;
  function paintInbox() {
    if (!boss() || !SITE) { if (inboxPill) inboxPill.style.display = 'none'; return; }
    const L = pending();
    if (!primed) { L.forEach(x => seenReq.add(x.id)); primed = true; }
    L.forEach(x => { if (!seenReq.has(x.id)) { seenReq.add(x.id); if (x.byUser !== me().uname) { toast('🔔 Manzoori chahiye: ' + x.title); try { navigator.vibrate && navigator.vibrate([120, 80, 120]); } catch (e) { /* */ } } } });
    if (!inboxPill) { inboxPill = document.createElement('button'); inboxPill.type = 'button'; inboxPill.className = 'gd-inbox'; inboxPill.dataset.act = 'gd-inbox'; document.body.appendChild(inboxPill); }
    inboxPill.style.display = L.length ? 'flex' : 'none'; inboxPill.innerHTML = `🔔 <b>${L.length}</b> manzoori`;
    const ov = q$('.gd-inbox-ov'); if (ov) q$('.m-body', ov).innerHTML = inboxBody();
  }
  setInterval(paintInbox, 2500);
  function inboxBody() {
    const L = pending(); if (!L.length) return '<div class="empty">Koi request baaki nahi ✓</div>';
    return L.map(x => `<div class="gd-req"><div><b>${esc(x.title)}</b><div class="small">${esc(x.text || '')}</div><div class="small muted">${esc(x.by || '')} · ${esc(fmtT(x.at))}</div></div><div class="btns"><button type="button" class="btn sm danger" data-act="gd-rej" data-id="${esc(x.id)}">Mana</button><button type="button" class="btn sm gold" data-act="gd-ok" data-id="${esc(x.id)}">✓ Manzoor</button></div></div>`).join('');
  }
  async function decide(id, ok) {
    const x = (S.sjReqs || []).find(r => r.id === id); if (!x) return;
    let why = ''; if (!ok) { why = await SJ_ASK('Mana karna hai', 'Wajah (staff ko dikhegi)', { allowEmpty: true }); if (why === null) return; }
    if (await save('sjReqs', { ...x, status: ok ? 'approved' : 'rejected', why, decidedBy: me().name, decidedAt: Date.now() })) toast(ok ? '✓ Manzoor — staff ka bill save ho jayega' : 'Mana kar diya');
    paintInbox();
  }

  /* ================= SETUP → SURAKSHA ================= */
  const P_BOOL = [['pin', 'Delete / backup se pehle PIN zaroori', 'Bill, stock, party mitane ya poora backup lene se pehle har baar PIN (5 minute ke liye khulta hai)'],
    ['devices', 'Naya phone / computer Owner approve kare', 'Naye device par login tab tak nahi hoga jab tak aap "Devices" mein approve na karein'],
    ['totpAll', 'Sabke liye 2-step login', 'Har staff ko pehli baar login par Authenticator app jodna hoga'],
    ['hours', 'Sirf dukaan ke samay login', 'Staff / Manager is samay ke baahar kuch nahi kar payenge (Owner hamesha)'],
    ['dayLock', 'Din band ke baad lock', 'Close the day ke baad us din ke bill / kharche / bank entry sirf Owner badal sakta hai (payment jodna chalta hai)'],
    ['exportOwner', 'Poora backup sirf Owner', 'Manager bhi poora data download nahi kar payega'],
    ['floorWall', 'Floor ki deewar', 'Staff sirf apne floor ka stock badal sake (bechna sab jagah chalta hai)'],
    ['maskPii', 'Staff ko phone / PAN aadha dikhe', 'Screen par 98xxxxxx10 jaisa — poora sirf Owner / Manager ko'],
    ['cash269', 'Cash ₹2 lakh ki rok (Sec 269ST)', 'Ek grahak se ek din / ek bill par ₹2 lakh ya zyada cash — staff / Manager ka bill save nahi hoga (Owner ko chetavni)'],
    ['panRule', '₹2 lakh+ bill par PAN zaroori (Rule 114B)', 'PAN / GSTIN / Form 60 ke bina bada bill save nahi hoga'],
    ['fieldPhoto', 'Field: har dukaan par entry / exit photo', 'Bina photo staff aage nahi badh sakta — photo par time, dukaan, staff chhapta hai'],
    ['creditBlock', 'Field: udhaar seema paar dukaan ko maal nahi', 'Challan banate waqt — sirf Owner PIN se chhoot de sakta hai']];
  function secCard() {
    const p = pol(), m = (window.SJ_SEC && SJ_SEC.me) || {};
    const mine = `<div class="btns" style="margin-top:10px"><button type="button" class="btn sm" data-act="gd-pin">${m.pin ? '🔐 Mera PIN badlo' : '🔐 Mera PIN banao'}</button>${!isOwner() ? `<button type="button" class="btn sm" data-act="gd-my2fa">${m.totp ? '✓ Mera 2-step chalu' : '📱 Mera 2-step chalu karo'}</button>` : ''}${m.floor ? `<span class="pill">Floor: ${esc(m.floor)}</span>` : ''}${m.field ? '<span class="pill gold">Field staff</span>' : ''}</div>`;
    if (!isOwner()) return `<div class="card" id="gd-card"><div class="card-h"><h3>🛡 Suraksha</h3></div><p class="small muted" style="margin:0">PIN se aapke naam par koi doosra bada kaam nahi kar payega.</p>${mine}</div>`;
    const on = P_BOOL.filter(([k]) => p[k]).length;
    return `<div class="card" id="gd-card"><div class="card-h"><h3>🛡 Suraksha</h3><span class="pill ${on >= 5 ? 'green' : on ? 'gold' : ''}">${on}/${P_BOOL.length} niyam chalu</span></div>
      <p class="small muted" style="margin-top:0">Ye niyam server par laagu hote hain — staff ka browser inhe tod nahi sakta.</p>
      <div class="btns"><button type="button" class="btn sm gold" data-act="gd-policy">⚙ Niyam</button><button type="button" class="btn sm" data-act="gd-devices">📱 Devices</button><button type="button" class="btn sm" data-act="gd-staff">👥 Staff ke niyam</button><button type="button" class="btn sm" data-act="gd-report">🛡 Rakhwala report</button><button type="button" class="btn sm" data-act="gd-chain">🔗 Record jaanch</button><button type="button" class="btn sm" data-act="gd-keys">🔑 Cron / Gate keys</button></div>${mine}</div>`;
  }
  { const SU = VIEWDEF.setup; if (SU && SU.body) VIEWDEF.setup = { ...SU, body() { const h = SU.body.apply(SU, arguments); let x = ''; try { if (SITE) x = secCard(); } catch (e) { console.error(e); } return x + h; } }; }
  window.addEventListener('sj-sec', () => { const c = q$('#gd-card'); if (c) c.outerHTML = secCard(); applyMask(); armIdle(); });

  function policyForm() {
    const p = pol();
    const el = openModal(`<form data-gd="pol" novalidate>${mHead('🛡 Suraksha ke niyam', 'Server par laagu — staff inhe tod nahi sakta')}<div class="m-body">
      <div class="gd-tg">${P_BOOL.map(([k, l, d]) => `<label class="gd-t"><input type="checkbox" name="${k}" ${p[k] ? 'checked' : ''}><span><b>${l}</b><small>${d}</small></span></label>`).join('')}</div>
      <h4 class="gd-h">Samay aur seema</h4><div class="fg">
      ${fld('Dukaan khulne ka samay', 'from', p.from || '09:00', { type: 'time' })}${fld('Band hone ka samay', 'to', p.to || '21:30', { type: 'time' })}
      ${fld('Staff ka max discount % (0 = koi seema nahi)', 'discStaff', p.discStaff || 0, { type: 'number' })}${fld('Manager ka max discount %', 'discMgr', p.discMgr || 0, { type: 'number' })}
      ${fld('Staff purana sona bina manzoori (₹ tak)', 'ogStaff', p.ogStaff || 0, { type: 'number' })}${fld('Screen apne aap lock (minute, 0 = band)', 'idleMin', p.idleMin || 0, { type: 'number' })}</div>
      <h4 class="gd-h">Field (dukaan-dukaan maal)</h4><div class="fg">
      ${fld('Ek challan mein max maal ₹ (upar sirf Owner)', 'fieldMax', p.fieldMax || 0, { type: 'number' })}${fld('Is ₹ se upar do staff zaroori', 'fieldTwo', p.fieldTwo || 0, { type: 'number' })}
      ${fld('Weight ki chhoot (g, poore bag par)', 'tolG', p.tolG ?? 0.10, { type: 'number' })}${fld('+ har piece par chhoot (g)', 'tolPc', p.tolPc ?? 0.02, { type: 'number' })}
      ${fld('Dukaan se kitni doori tak check-in (metre)', 'radius', p.radius || 200, { type: 'number' })}
      ${fld('Staff ek jagah itne minute ruke to alert', 'stayMin', p.stayMin || 30, { type: 'number' })}${fld('Location itne minute na aaye to alert', 'noLocMin', p.noLocMin || 45, { type: 'number' })}</div>
      <p class="small muted">Naya-device niyam chalu karte hi aaj tak ke sab devices apne aap approved maane jayenge — baad ke naye devices aapse poochenge.</p>
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save niyam</button></div></form>`, { wide: true });
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); const b = q$('button.gold', el); b.disabled = true;
      try { const r = await API('sec_policy', f); window.SJ_SEC.policy = r.policy; closeModal(el); toast('✓ Suraksha ke niyam save'); window.dispatchEvent(new CustomEvent('sj-sec')); renderView(true); }
      catch (e) { if (e.code !== 'pin_cancel') toast(e.message || 'Save nahi hua', 'err'); } finally { b.disabled = false; }
    };
  }
  async function devicesModal() {
    let r; try { r = await API('devices'); } catch (e) { return toast(e.message, 'err'); }
    const st = { ok: ['green', 'Approved'], pending: ['gold', 'Intezaar'], blocked: ['red', 'Blocked'] };
    const rows = r.devices.map(d => `<div class="gd-dev ${d.st}"><div><b>${esc(d.label || d.name)}</b> <span class="pill ${st[d.st][0]}">${st[d.st][1]}</span>${d.me ? ' <span class="pill">ye device</span>' : ''}<div class="small muted">${esc(d.users.join(', '))} · pehli baar ${esc(fmtT(d.first * 1000))} · aakhri ${esc(fmtT(d.last * 1000))} · IP ${esc(d.ip)}</div></div><div class="btns">${d.st !== 'ok' ? `<button type="button" class="btn sm gold" data-act="gd-dev" data-id="${esc(d.id)}" data-st="ok">✓ Approve</button>` : ''}${!d.me && d.st !== 'blocked' ? `<button type="button" class="btn sm danger" data-act="gd-dev" data-id="${esc(d.id)}" data-st="blocked">Block</button>` : ''}<button type="button" class="btn sm" data-act="gd-dev-name" data-id="${esc(d.id)}">Naam</button></div></div>`).join('');
    const ov = q$('.gd-dev-ov'); const html = `${mHead('📱 Devices', 'Jin phone / computer se login hua')}<div class="m-body">${pol().devices ? '' : '<p class="warn-box small">"Naya phone / computer Owner approve kare" niyam abhi band hai — sirf list dikh rahi hai.</p>'}${rows || '<div class="empty">Koi device nahi</div>'}<p class="small muted">Block karte hi us device ka login turant khatam ho jata hai. Phone kho jaye to yahan Block kijiye.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`;
    if (ov) ov.querySelector('.sheet').innerHTML = html; else openModal(html, { wide: true }).classList.add('gd-dev-ov');
  }
  async function staffModal() {
    let r; try { r = await API('uext_list'); } catch (e) { return toast(e.message, 'err'); }
    const floors = (window.SJ_FLOORS && SJ_FLOORS.list()) || [];
    const rows = r.users.filter(u => u.role !== 'owner').map(u => `<form class="gd-st" data-gd="uext" data-id="${esc(u.id)}" novalidate><div class="gd-st-h"><b>${esc(u.name)}</b> <span class="small muted">${esc(u.uname)} · ${esc(u.role)}</span>${u.pin ? ' <span class="pill green">PIN</span>' : ''}${u.totp ? ' <span class="pill green">2-step</span>' : ''}</div>
      <div class="gd-st-f"><label class="f"><span>Floor</span><select name="floor"><option value="">— koi bhi —</option>${floors.map(f => `<option value="${esc(f.id)}"${u.floor === f.id ? ' selected' : ''}>${esc(f.name)}</option>`).join('')}</select></label>
      <label class="chk"><input type="checkbox" name="field" ${u.field ? 'checked' : ''}> Field staff</label><label class="chk"><input type="checkbox" name="anyHours" ${u.anyHours ? 'checked' : ''}> Samay ki chhoot</label>
      <label class="chk"><input type="checkbox" name="pinReset"> PIN mitao</label><label class="chk"><input type="checkbox" name="totpReset"> 2-step reset</label><button class="btn sm gold">Save</button></div></form>`).join('');
    const el = openModal(`${mHead('👥 Staff ke niyam', 'Floor, field duty, samay ki chhoot, PIN / 2-step reset')}<div class="m-body">${rows || '<div class="empty">Staff ke login Setup → Website login → Staff & logins se banaiye</div>'}</div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`, { wide: true });
    el.addEventListener('submit', async ev => { const f = ev.target.closest('form[data-gd="uext"]'); if (!f) return; ev.preventDefault(); ev.stopPropagation(); const d = formObj(f);
      try { await API('uext_save', { id: f.dataset.id, ...d }); toast('✓ Save'); f.querySelectorAll('[name=pinReset],[name=totpReset]').forEach(i => { i.checked = false; }); } catch (e) { toast(e.message, 'err'); } }, true);
  }
  function pinModal() {
    const el = openModal(`<form data-gd="pin" novalidate>${mHead('🔐 Mera PIN', 'Delete / backup jaise kaam se pehle poocha jayega')}<div class="m-body"><div class="fg">${fld('Login password', 'password', '', { type: 'password' })}${fld('Naya PIN (4–8 ank)', 'pin', '', { type: 'password' })}${fld('PIN dobara', 'pin2', '', { type: 'password' })}</div><p class="small muted">1234, 0000 jaise aasaan PIN nahi chalte. PIN kisi ko mat batayiye.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save PIN</button></div></form>`);
    q$('[name=pin]', el).inputMode = 'numeric'; q$('[name=pin2]', el).inputMode = 'numeric';
    q$('form', el).onsubmit = async ev => { ev.preventDefault(); const f = formObj(ev.target); if (f.pin !== f.pin2) return toast('Dono PIN ek jaise nahi', 'err');
      try { await API('pin_set', { password: f.password, pin: f.pin }); closeModal(el); toast('✓ PIN save'); if (window.SJ_SEC) SJ_SEC.me.pin = true; const c = q$('#gd-card'); if (c) c.outerHTML = secCard(); } catch (e) { toast(e.message, 'err'); } };
  }
  function my2fa() {
    const el = openModal(`<form novalidate>${mHead('📱 Mera 2-step login', 'Password ke saath phone ka code bhi lagega')}<div class="m-body"><div class="fg">${fld('Login password', 'password', '', { type: 'password' })}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Aage</button></div></form>`);
    q$('form', el).onsubmit = async ev => { ev.preventDefault(); let r; try { r = await API('my_totp_init', formObj(ev.target)); } catch (e) { return toast(e.message, 'err'); } closeModal(el);
      const el2 = openModal(`<form novalidate>${mHead('Authenticator jodo', 'Google Authenticator → + → QR scan')}<div class="m-body"><div class="gd-qr">${typeof qrSVG === 'function' ? qrSVG(r.uri) : ''}</div><p class="mono small" style="text-align:center;word-break:break-all">${esc(r.secret)}</p><div class="fg">${fld('6 ank ka code', 'code', '', { type: 'text' })}</div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Chalu karo</button></div></form>`);
      q$('form', el2).onsubmit = async e2 => { e2.preventDefault(); try { const x = await API('my_totp_enable', formObj(e2.target)); closeModal(el2); if (window.SJ_SEC) SJ_SEC.me.totp = true;
        openModal(`${mHead('✓ 2-step chalu', 'Backup codes likh kar rakhiye')}<div class="m-body"><pre class="gd-codes">${esc(x.codes.join('\n'))}</pre><p class="small muted">Phone kho jaye to inme se ek code se login hoga (har code ek baar).</p></div><div class="m-foot"><button type="button" class="btn gold" data-act="close">Likh liya</button></div>`); } catch (er) { toast(er.message, 'err'); } }; };
  }
  async function chainCheck() {
    const el = openModal(`${mHead('🔗 Record jaanch', 'Kisi ne software ke baahar se data to nahi badla?')}<div class="m-body"><div class="gd-wait"><div class="gd-spin"></div><div>Har record ki jaanch ho rahi hai…</div></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`);
    try { const { result: r } = await API('chain_verify', {}, 120000);
      q$('.m-body', el).innerHTML = r.ok ? `<div class="gd-big ok">✓</div><p style="text-align:center"><b>Sab record sahi hain.</b><br><span class="small muted">${r.entries} kadiyan jaanchi — koi record software ke baahar se badla ya mitaya nahi gaya.</span></p>`
        : `<div class="gd-big bad">!</div><p><b>${r.broken ? 'Record ki kadi TOOTI hui hai' : 'Kuch record software ke baahar se badle gaye'}</b></p>${r.broken ? `<p class="small">Kadi #${r.broken.n} (${esc(fmtT(r.broken.at))}) ke baad ka record database mein seedhe chheda gaya hai.</p>` : ''}${r.changed.length ? `<p class="small">Badle hue: ${r.changed.map(esc).join(', ')}</p>` : ''}${r.missing.length ? `<p class="small">Gayab: ${r.missing.map(esc).join(', ')}</p>` : ''}<p class="small muted">Hosting ka password badliye aur backup se milaiye. Zaroorat ho to developer se baat kijiye.</p>`;
    } catch (e) { q$('.m-body', el).innerHTML = `<p class="red">${esc(e.message)}</p>`; }
  }
  async function keysModal(renew) {
    let r; try { r = await API('keys', renew ? { renew } : {}); } catch (e) { return toast(e.message, 'err'); }
    const base = location.origin + location.pathname.replace(/[^/]*$/, '');
    const cron = `wget -q -O /dev/null "${base}sj-api.php?a=cron&k=${r.cron_key}"`;
    const html = `${mHead('🔑 Cron aur Gate keys', 'Ye keys kisi ko mat dikhaiye')}<div class="m-body">
      <h4 class="gd-h">⏰ Apne aap chalne wale kaam (Cron)</h4><p class="small">Hostinger hPanel → <b>Advanced → Cron Jobs</b> → "Custom" → har <b>30 minute</b> ke liye ye command daaliye:</p><pre class="gd-pre">${esc(cron)}</pre>
      <p class="small muted">Isse roz ka backup, raat ka backup email (agar chalu), aur shaam ko bina wapas aaye challan ka alert apne aap hota hai. Aakhri baar chala: <b>${r.cron_last ? esc(fmtT(r.cron_last * 1000)) : 'abhi tak nahi'}</b></p>
      <h4 class="gd-h">🚪 RFID exit gate / reader bridge</h4><p class="small">Gate ka software har tag par ye URL bulaye (POST JSON <span class="mono">{"epcs":["E280…"],"gate":"Ground"}</span>). Jawab mein <span class="mono">"alarm":true</span> aaye to siren bajaye:</p><pre class="gd-pre">${esc(base + 'sj-api.php?a=rfid_push&k=' + r.rfid_key)}</pre>
      <div class="btns"><button type="button" class="btn sm" data-act="gd-renew" data-k="cron_key">Cron key badlo</button><button type="button" class="btn sm" data-act="gd-renew" data-k="rfid_key">Gate key badlo</button></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`;
    const ov = q$('.gd-keys-ov'); if (ov) ov.querySelector('.sheet').innerHTML = html; else openModal(html, { wide: true }).classList.add('gd-keys-ov');
  }

  /* ================= RAKHWALA REPORT ================= */
  function guardData(days) {
    const since = Date.now() - (days || 1) * 86400e3; const A = (S.alerts || []).filter(a => num(a.at) >= since).sort((a, b) => b.at - a.at);
    const by = {}; A.forEach(a => { (by[a.kind] = by[a.kind] || []).push(a); });
    const ch = (S.challans || []).filter(c => num(c.updatedAt || c.createdAt) >= since);
    const short = ch.filter(c => c.ret && c.ret.short > 0);
    const manual = S.invoices.filter(v => num(v.updatedAt || v.createdAt) >= since && (v.items || []).some(i => i.wSrc === 'manual'));
    return { A, by, high: A.filter(a => a.level === 'high'), short, manual, ch };
  }
  const KL = { bill_delete: 'Bill delete', bill_edit: 'Bill badla', lock_try: 'Lock todne ki koshish', night_bill: 'Raat ko bill', delete: 'Kuch delete', stock_edit: 'Stock ka wazan badla', rate_change: 'Rate badla', night_entry: 'Raat ki entry', field_entry: 'Field entry scan gadbad', field_exit: 'Field exit scan gadbad', field_far: 'Dukaan se door check-in', field_seal: 'Seal nahi mila', field_short: 'Challan mein kam maal', field_waive: 'Fark maaf kiya', field_override: 'Gadbad ke baad manzoori', field_late: 'Challan der tak wapas nahi', panic: 'PANIC button', manual_weight: 'Haath se weight', floor_short: 'Floor transfer kam', audit_missing: 'Stock milaan kam', gate_alarm: 'Exit gate alarm', new_device: 'Naya device', off_hours: 'Samay ke baahar', pin_lock: 'PIN baar-baar galat', export: 'Poora backup liya', policy: 'Niyam badle', cash_diff: 'Galle mein fark' };
  function guardText(g, days) {
    const L = [`*${settings().firm || 'Shivaa Jewels'} — Rakhwala report* (${days === 1 ? 'pichle 24 ghante' : 'pichle ' + days + ' din'})`, ''];
    if (!g.A.length) L.push('✅ Koi gadbad nahi mili.');
    else { L.push(`🚨 ${g.high.length} gambhir · kul ${g.A.length} alert`); Object.entries(g.by).sort((a, b) => b[1].length - a[1].length).forEach(([k, v]) => L.push(`• ${KL[k] || k}: ${v.length}`)); L.push(''); g.high.slice(0, 6).forEach(a => L.push('‣ ' + a.text)); }
    if (g.short.length) L.push('', `📦 Challan mein kam maal: ${g.short.map(c => c.no + ' (' + c.staff + ')').join(', ')}`);
    if (g.manual.length) L.push(`⚖ Haath se weight wale bill: ${g.manual.length}`);
    return L.join('\n');
  }
  function reportModal(days) {
    days = days || 1; const g = guardData(days);
    const rows = Object.entries(g.by).sort((a, b) => b[1].length - a[1].length).map(([k, v]) => `<div class="gd-k ${v.some(a => a.level === 'high') ? 'hi' : ''}"><b>${v.length}</b><span>${esc(KL[k] || k)}</span></div>`).join('');
    const html = `${mHead('🛡 Rakhwala report', days === 1 ? 'Pichle 24 ghante' : 'Pichle ' + days + ' din')}<div class="m-body"><div class="btns" style="margin-bottom:10px">${[1, 7, 30].map(d => `<button type="button" class="btn sm ${d === days ? 'gold' : ''}" data-act="gd-report" data-d="${d}">${d === 1 ? '24 ghante' : d + ' din'}</button>`).join('')}</div>
      ${g.A.length ? `<div class="gd-ks">${rows}</div>` : '<div class="gd-big ok">✓</div><p style="text-align:center"><b>Koi gadbad nahi mili</b></p>'}
      ${g.high.length ? `<h4 class="gd-h">🚨 Gambhir</h4>${g.high.slice(0, 25).map(a => `<div class="gd-al"><b>${esc(a.text)}</b><span class="small muted">${esc(a.by || '')} · ${esc(fmtT(a.at))}</span></div>`).join('')}` : ''}
      ${g.short.length ? `<h4 class="gd-h">📦 Challan mein kam maal</h4>${g.short.map(c => `<div class="gd-al"><b>${esc(c.no)} · ${esc(c.staff)}</b><span class="small">${c.ret.short} piece · ${g3(c.ret.shortWt)} · ${inr(c.ret.shortVal)}${c.diffOk ? ' · maaf: ' + esc(c.diffOkBy || '') : ''}</span></div>`).join('')}` : ''}
      </div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><a class="btn green" target="_blank" rel="noopener" href="${esc('https://wa.me/?text=' + encodeURIComponent(guardText(g, days)))}">WhatsApp par bhejo</a></div>`;
    const ov = q$('.gd-rep-ov'); if (ov) ov.querySelector('.sheet').innerHTML = html; else openModal(html, { wide: true }).classList.add('gd-rep-ov');
  }
  { const D = VIEWDEF.dashboard; if (D && D.body) VIEWDEF.dashboard = { ...D, body() { let x = ''; try { if (SITE && isOwner()) { const g = guardData(1); x = `<div class="card gd-dash ${g.high.length ? 'hi' : ''}" data-act="gd-report" role="button" tabindex="0"><div><b>🛡 Rakhwala</b><span>${g.A.length ? `Pichle 24 ghante: <b>${g.high.length}</b> gambhir · ${g.A.length} alert` : 'Pichle 24 ghante mein koi gadbad nahi ✓'}</span></div><span class="btn sm">Report</span></div>`; } } catch (e) { console.error(e); } return x + D.body.apply(D, arguments); } }; }

  /* ================= SCREEN LOCK ================= */
  let idleT = null, locked = false, lastAct = Date.now();
  function armIdle() {
    clearInterval(idleT); const m = num(pol().idleMin); if (!SITE || !m) return;
    idleT = setInterval(() => { if (!locked && Date.now() - lastAct > m * 60000) lockScreen(); }, 15000);
  }
  ['pointerdown', 'keydown', 'touchstart', 'wheel'].forEach(ev => document.addEventListener(ev, () => { lastAct = Date.now(); }, { passive: true, capture: true }));
  function lockScreen() {
    if (locked) return; locked = true; const hasPin = window.SJ_SEC && SJ_SEC.me && SJ_SEC.me.pin;
    const el = document.createElement('div'); el.className = 'gd-lock';
    el.innerHTML = `<form novalidate><div class="gd-lock-i">🔒</div><h3>Screen lock</h3><p>${esc(me().name)} — ${hasPin ? 'PIN daal kar kholiye' : 'aapka PIN nahi bana, isliye dobara login karna hoga'}</p>${hasPin ? '<input name="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="off" placeholder="PIN"><div class="gd-lock-e"></div><button class="btn gold">Kholo</button>' : ''}<button type="button" class="btn" data-lo>Logout</button></form>`;
    document.body.appendChild(el); const f = q$('form', el); if (hasPin) setTimeout(() => f.pin.focus(), 50);
    f.querySelector('[data-lo]').onclick = () => { const b = document.querySelector('[data-sj="logout"]'); if (b) b.click(); else { window.SJ_API_CALL('logout').finally(() => location.reload()); } };
    f.onsubmit = async ev => { ev.preventDefault(); try { await API('pin_check', { pin: f.pin.value }); el.remove(); locked = false; lastAct = Date.now(); } catch (e) { q$('.gd-lock-e', el).textContent = e.message || 'PIN galat'; f.pin.value = ''; } };
  }

  /* ================= PHONE / PAN MASK (Staff) ================= */
  const RX = /(?<![\d₹,.])(?:\+?91[\s-]?)?([6-9]\d)(\d{6})(\d{2})(?!\d)|\b([A-Z]{3}[PCHFATBLJG])([A-Z])(\d{4})([A-Z])\b|\b(\d{4})[\s-]?(\d{4})[\s-]?(\d{4})\b/g;
  let maskOb = null;
  function maskNode(n) {
    if (n.nodeType === 3) { const t = n.nodeValue; if (!t || t.length < 10 || !/\d{4}|[A-Z]{5}\d/.test(t)) return; const p = n.parentElement; if (!p || p.closest('input,textarea,script,style,.no-mask,[contenteditable]')) return;
      const m = t.replace(RX, (all, a, b, c, d, e, f, g, h, i, j) => a ? a + 'xxxxxx' + c : d ? d + 'x' + 'xxxx'.slice(0, 4) + g : j ? 'xxxx xxxx ' + j : all); if (m !== t) n.nodeValue = m; return; }
    if (n.nodeType === 1 && !n.matches('input,textarea,script,style')) n.childNodes.forEach(maskNode);
  }
  function applyMask() {
    const on = SITE && pol().maskPii && role() === 'staff';
    if (on && !maskOb) { maskOb = new MutationObserver(ms => ms.forEach(m => { m.addedNodes.forEach(maskNode); if (m.type === 'characterData') maskNode(m.target); })); maskOb.observe(document.body, { childList: true, subtree: true, characterData: true }); maskNode(document.body); }
    else if (!on && maskOb) { maskOb.disconnect(); maskOb = null; }
  }

  /* ================= clicks ================= */
  const ACT = {
    'gd-wait-x': t => { const el = t.closest('.overlay'); el && el._cancel && el._cancel(); },
    'gd-inbox': () => openModal(`${mHead('🔔 Manzoori', 'Staff ki requests')}<div class="m-body">${inboxBody()}</div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button></div>`, { wide: true }).classList.add('gd-inbox-ov'),
    'gd-ok': t => decide(t.dataset.id, true), 'gd-rej': t => decide(t.dataset.id, false),
    'gd-policy': () => policyForm(), 'gd-devices': () => devicesModal(), 'gd-staff': () => staffModal(), 'gd-pin': () => pinModal(), 'gd-my2fa': () => { if (window.SJ_SEC && SJ_SEC.me.totp) return toast('2-step pehle se chalu hai — band karna ho to Owner se kahiye'); my2fa(); },
    'gd-chain': () => chainCheck(), 'gd-keys': () => keysModal(), 'gd-renew': async t => { if (await SJ_CONFIRM('Nayi key banate hi purani band ho jayegi — Hostinger cron / gate mein nayi daalni hogi.', 'Nayi key banao')) keysModal(t.dataset.k); },
    'gd-report': t => reportModal(num(t.dataset.d) || 1),
    'gd-dev': async t => { try { await API('device_set', { id: t.dataset.id, st: t.dataset.st }); toast(t.dataset.st === 'ok' ? '✓ Approve' : 'Block — us device ka login khatam'); devicesModal(); } catch (e) { toast(e.message, 'err'); } },
    'gd-dev-name': async t => { const n = await SJ_ASK('Device ka naam', 'Naam', { ph: 'jaise Ground floor counter / Ramesh ka phone' }); if (n === null) return; try { await API('device_set', { id: t.dataset.id, label: n }); devicesModal(); } catch (e) { toast(e.message, 'err'); } }
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="gd-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);

  if (typeof agentRules === 'function') { const R0 = agentRules; agentRules = function () { return R0.apply(this, arguments) + '\nSURAKSHA: security rules live on the server (Setup → Suraksha). Pending staff approvals show as a 🔔 pill for Owner / Manager. "Rakhwala report" (Dashboard / Setup) lists what went wrong; recent_alerts tool has the raw alerts.'; }; }
  window.SJ_GUARD = { reportModal, guardData, ask, lockScreen };

  css(`.gd-tg{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px}.gd-t{display:flex;gap:10px;align-items:flex-start;border:1px solid var(--line);border-radius:14px;padding:10px 12px;cursor:pointer}.gd-t input{margin-top:3px}.gd-t span{display:flex;flex-direction:column;gap:2px}.gd-t small{color:var(--muted);font-size:11.5px;line-height:1.35}.gd-t:has(input:checked){border-color:var(--gold-line,rgba(212,175,55,.5));background:var(--gold-soft,rgba(212,175,55,.08))}
    .gd-h{margin:16px 0 8px;font-size:13px;color:var(--gold)}.gd-dev,.gd-req,.gd-st{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--line)}.gd-dev>div:first-child,.gd-req>div:first-child{min-width:0}.gd-dev.pending{background:rgba(245,158,11,.06)}
    .gd-st{flex-direction:column;align-items:stretch}.gd-st-f{display:flex;flex-wrap:wrap;gap:10px 14px;align-items:center}.gd-st-f .f{min-width:160px;margin:0}
    .gd-wait{display:flex;gap:14px;align-items:center}.gd-spin{flex:none;width:34px;height:34px;border-radius:50%;border:3px solid var(--line);border-top-color:var(--gold);animation:gdsp 1s linear infinite}@keyframes gdsp{to{transform:rotate(360deg)}}
    .gd-inbox{position:fixed;right:16px;top:calc(76px + env(safe-area-inset-top));z-index:96;display:none;align-items:center;gap:6px;padding:9px 14px;border-radius:999px;border:0;background:#b45309;color:#fff;font:700 13px system-ui;box-shadow:0 10px 24px rgba(0,0,0,.4);cursor:pointer;animation:gdpl 1.6s ease-in-out infinite}@keyframes gdpl{50%{box-shadow:0 0 0 6px rgba(180,83,9,.25),0 10px 24px rgba(0,0,0,.4)}}
    .gd-qr{display:flex;justify-content:center}.gd-qr svg{width:200px;height:200px;background:#fff;padding:8px;border-radius:12px}.gd-codes{text-align:center;font:600 17px/1.7 ui-monospace,monospace}.gd-pre{white-space:pre-wrap;word-break:break-all;font:12px/1.5 ui-monospace,monospace;background:var(--card2,rgba(0,0,0,.25));border:1px solid var(--line);border-radius:10px;padding:10px}
    .gd-big{width:70px;height:70px;border-radius:50%;display:grid;place-items:center;margin:6px auto 10px;font:800 36px system-ui;color:#fff}.gd-big.ok{background:#16a34a}.gd-big.bad{background:#dc2626}
    .gd-ks{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px}.gd-k{border:1px solid var(--line);border-radius:12px;padding:8px 10px}.gd-k b{display:block;font-size:20px}.gd-k span{font-size:12px;color:var(--muted)}.gd-k.hi{border-color:rgba(239,68,68,.6);background:rgba(239,68,68,.06)}.gd-al{display:flex;flex-direction:column;gap:2px;padding:8px 0;border-bottom:1px solid var(--line);font-size:13px}
    .gd-dash{display:flex;justify-content:space-between;align-items:center;gap:12px;cursor:pointer;padding:14px 16px}.gd-dash>div{display:flex;flex-direction:column;gap:2px;min-width:0}.gd-dash span{font-size:12.5px;color:var(--muted)}.gd-dash.hi{border-color:rgba(239,68,68,.55)}.gd-dash.hi b:first-child{color:#f87171}
    .gd-lock{position:fixed;inset:0;z-index:3000;display:grid;place-items:center;background:var(--bg,#0b0905);padding:16px}.gd-lock form{width:100%;max-width:320px;text-align:center;display:flex;flex-direction:column;gap:10px}.gd-lock-i{font-size:44px}.gd-lock h3{margin:0}.gd-lock p{margin:0;color:var(--muted);font-size:13px}.gd-lock input{text-align:center;font-size:22px;letter-spacing:6px;padding:12px;border-radius:14px;border:1px solid var(--line2,var(--line));background:var(--card2,transparent);color:var(--ink)}.gd-lock-e{color:var(--red,#f87171);font-size:13px;min-height:16px}
    @media(max-width:640px){.gd-dev,.gd-req{flex-direction:column;align-items:stretch}.gd-inbox{top:calc(66px + env(safe-area-inset-top));right:12px}}`);
  setTimeout(() => { applyMask(); armIdle(); }, 1500);
})();
