<?php
/* Shivaa Jewels — bill verification page. Opened by the QR code printed on every bill (verify.php?i=…&k=…). */
$_GET['a'] = 'verify';
$_SERVER['REQUEST_METHOD'] = 'GET';
require __DIR__ . '/sj-api.php';
