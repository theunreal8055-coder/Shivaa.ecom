/* =====================================================================
   SJ PRO — core
   1. Wholesale / Retail switch (works like the Pakka / Kacha tabs) on
      Dashboard, Invoices, Pakka/Kacha, Metal, Parties and Reports
   2. Category-wise stock (gold + silver) valued at today's rate, purchase
      wastage vs sale wastage, profit in fine metal and in rupees
   3. Automation: daily stock snapshot, smart alerts
   4. Edit / delete everywhere: payment edit, scheme delete, day reopen,
      rate history edit, "Sab entries" data manager
   ===================================================================== */
(() => {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined' || typeof VT === 'undefined') return;

  const SNAP = 'stockSnaps';
  if (!COLS.includes(SNAP)) COLS.push(SNAP);
  if (!Array.isArray(S[SNAP])) S[SNAP] = [];
  if (typeof DB !== 'undefined' && DB) { try { DB.collection(SNAP).onSnapshot(snap => { S[SNAP] = snap.docs.map(d => ({ ...d.data(), id: d.id })); scheduleRender(); }); } catch (e) { console.error(e); } }
  if (typeof AUDIT_SKIP !== 'undefined' && AUDIT_SKIP.add) AUDIT_SKIP.add(SNAP);

  const role = () => (window.SJ_USER && window.SJ_USER.role) || 'owner';
  const canAdmin = () => role() === 'owner' || role() === 'manager';
  const hasV = v => v !== '' && v != null;
  const proCfg = () => ({ billStyle: 'signature', nightAudit: true, deadDays: 90, ...((S.settings && S.settings.pro) || {}) });
  const wt = (g, metal) => metal === 'silver' && Math.abs(num(g)) >= 1000 ? (num(g) / 1000).toFixed(3) + ' kg' : g3(g);
  const mName = m => m === 'silver' ? 'Silver' : 'Gold';
  const fire = (act, id, extra) => { const b = document.createElement('button'); b.type = 'button'; b.dataset.act = act; if (id != null) b.dataset.id = id; Object.assign(b.dataset, extra || {}); b.style.display = 'none'; document.body.appendChild(b); b.click(); b.remove(); };

  /* =================================================================
     1. WHOLESALE / RETAIL
     ================================================================= */
  ui.chan = lsGet('sj_chan', 'all'); if (!['all', 'wholesale', 'retail'].includes(ui.chan)) ui.chan = 'all';
  const CH_VIEWS = ['dashboard', 'billing', 'books', 'metal', 'parties', 'estimates', 'crm', 'accounts', 'reports'];
  const chanBypass = () => (view === 'reports' && ['gst', 'bank', 'growth', 'targets', 'ranking'].includes(ui.rTab)) || (view === 'books' && ui.bkTab === 'gst') || (view === 'parties' && ['suppliers', 'matrix'].includes(ui.pTab)) || (view === 'accounts' && !['ledger', 'reminders'].includes(ui.accTab || 'ledger'));
  const ordChan = o => o.channel === 'wholesale' || o.channel === 'retail' ? o.channel : (o.type === 'purchase' ? 'wholesale' : (c => c ? chanOfParty(c) : 'wholesale')(custById(o.partyId)));
  function swapCol(col, pred) {
    if (FIRM_COLS.includes(col)) { const keep = RAW[col]; RAW[col] = keep.filter(pred); bumpCol(col); return () => { RAW[col] = keep; bumpCol(col); }; }
    const keep = S[col]; if (!Array.isArray(keep)) return () => {}; S[col] = keep.filter(pred); return () => { S[col] = keep; };
  }
  function withChanData(fn) {
    const c = ui.chan; if ((c !== 'wholesale' && c !== 'retail') || chanBypass()) return fn();
    const undo = []; S._custAll = S.customers;
    try {
      undo.push(swapCol('invoices', v => chanOf(v) === c));
      undo.push(swapCol('orders', o => ordChan(o) === c));
      if (Array.isArray(S.estimates)) undo.push(swapCol('estimates', o => ordChan(o) === c));
      undo.push(swapCol('customers', x => chanOfParty(x) === c));
      return withChan(c, fn);
    } finally { undo.reverse().forEach(u => u()); delete S._custAll; _cmap = null; }
  }
  function chanBar() {
    lsSet('sj_chan', ui.chan); const off = chanBypass();
    const n = { all: 0, wholesale: 0, retail: 0 }; S.invoices.forEach(v => { if (isBuy(v.type)) return; n.all++; n[chanOf(v)]++; });
    return `<div class="chanbar${off ? ' off' : ''}"><span class="cb-l">Sector</span><div class="seg">${CHANS.map(([v, l]) => `<button type="button" data-act="seg" data-k="chan" data-v="${v}" class="${ui.chan === v ? 'on' : ''}">${v === 'wholesale' ? '🏭 ' : v === 'retail' ? '🛍 ' : ''}${l}<em>${n[v]}</em></button>`).join('')}</div><span class="cb-n">${off ? 'Ye tab hamesha poora data dikhata hai' : ui.chan === 'all' ? 'Wholesale + Retail dono' : ui.chan === 'wholesale' ? 'Sirf wholesale (B2B / vyapari) ka data' : 'Sirf retail (grahak) ka data'}</span></div>`;
  }
  CH_VIEWS.forEach(k => {
    const V = VIEWDEF[k]; if (!V) return;
    VIEWDEF[k] = { ...V, shell() { return chanBar() + V.shell.call(V); }, body() { return withChanData(() => V.body.call(V)); } };
  });
  // a new bill made while a sector is selected starts in that sector
  { const _oi = openInvoice; openInvoice = function (type, o) { o = o || {}; if (!o.edit && !isBuy(type) && (ui.chan === 'wholesale' || ui.chan === 'retail') && CH_VIEWS.includes(view)) o = { ...o, preset: { channel: ui.chan, ...(o.preset || {}) } }; return _oi.call(this, type, o); }; }

  /* =================================================================
     2. CATEGORY STOCK, WASTAGE & PROFIT
     ================================================================= */
  const tun = p => num(p.tunch || (PUR[p.purity] || {}).t);
  const rulesMap = () => (S.settings && S.settings.catW) || {};
  const buyW = (p, m) => hasV(p.wastage) ? num(p.wastage) : (r => r && hasV(r.b) ? num(r.b) : null)(catRule(p.category, p.purity, m || rulesMap()));
  const saleW = (p, m) => hasV(p.saleWastage) ? num(p.saleWastage) : (r => r && hasV(r.s) ? num(r.s) : null)(catRule(p.category, p.purity, m || rulesMap()));
  const owned = () => S.products.filter(p => p.status !== 'Sold');

  function catStock() {
    const m = rulesMap(); const rows = new Map();
    const row = (category, purity) => { const key = category + '|' + purity; let r = rows.get(key); if (!r) { r = { key, category, purity, metal: metalOf(purity), pcs: 0, gross: 0, net: 0, fine: 0, value: 0, bWN: 0, bN: 0, sWN: 0, sN: 0, pFine: 0, pNet: 0, appr: 0 }; rows.set(key, r); } return r; };
    owned().forEach(p => {
      if (!p.category || !p.purity) return; const r = row(p.category, p.purity); const net = num(p.net);
      r.pcs += Math.max(1, num(p.pcs) || 1); r.gross += num(p.gross); r.net += net; r.fine += net * tun(p) / 100; if (p.status === 'On Approval') r.appr++;
      const b = buyW(p, m), s = saleW(p, m);
      if (b != null) { r.bWN += b * net; r.bN += net; } if (s != null) { r.sWN += s * net; r.sN += net; }
      if (b != null && s != null) { r.pFine += net * (s - b) / 100; r.pNet += net; }
    });
    Object.keys(m).forEach(k => { const [c, pu] = k.split('|'); if (c && pu && PUR[pu]) row(c, pu); });
    return [...rows.values()].map(r => { const rule = catRule(r.category, r.purity, m) || {}; const rate = rateFor(r.metal);
      return { ...r, gross: r3(r.gross), net: r3(r.net), fine: r3(r.fine), value: r2(r.fine * rate), rule,
        buy: r.bN ? r.bWN / r.bN : (hasV(rule.b) ? num(rule.b) : null), sell: r.sN ? r.sWN / r.sN : (hasV(rule.s) ? num(rule.s) : null),
        pFine: r3(r.pFine), pValue: r2(r.pFine * rate), min: hasV(rule.min) ? num(rule.min) : null }; })
      .sort((a, b) => (a.metal === b.metal ? 0 : a.metal === 'gold' ? -1 : 1) || b.value - a.value || a.category.localeCompare(b.category));
  }
  function csRange() { const t = todayStr(), p = ui.csP || 'month'; if (p === 'all') return ['0000-01-01', '9999-12-31', 'ab tak']; if (p === 'fy') { const y = +t.slice(0, 4), m = +t.slice(5, 7); return [(m >= 4 ? y : y - 1) + '-04-01', t, 'is saal (FY)']; } if (p === '30') return [addDays(t, -29), t, 'pichhle 30 din']; return [monthRange(monthKey(t))[0], t, 'is mahine']; }
  function soldByCat(a, b) {
    const m = new Map();
    withChan('all', () => saleLines(a, b)).forEach(l => { const k = l.category + '|' + l.purity; let x = m.get(k); if (!x) { x = { key: k, category: l.category, purity: l.purity, metal: l.metal, net: 0, fine: 0, amount: 0, gFine: 0, gValue: 0, known: 0, wN: 0, cN: 0 }; m.set(k, x); }
      x.net += l.net; x.fine += l.fine; x.amount += l.amount; x.wN += l.w * l.net; if (l.gainFine != null) { x.gFine += l.gainFine; x.gValue += l.gainValue; x.known += l.net; x.cN += l.costW * l.net; } });
    return m;
  }
  const SJP = {};
  SJP.catStock = catStock; SJP.soldByCat = soldByCat; SJP.csRange = csRange; SJP.buyW = buyW; SJP.saleW = saleW; SJP.proCfg = proCfg; SJP.wt = wt;
  SJP.metalTotals = function () { const o = { gold: { pcs: 0, net: 0, fine: 0, value: 0, pFine: 0, pValue: 0 }, silver: { pcs: 0, net: 0, fine: 0, value: 0, pFine: 0, pValue: 0 } }; catStock().forEach(r => { const x = o[r.metal]; x.pcs += r.pcs; x.net += r.net; x.fine += r.fine; x.value += r.value; x.pFine += r.pFine; x.pValue += r.pValue; }); return o; };

  ui.csMetal = ui.csMetal || 'all'; ui.csP = ui.csP || 'month'; ui.pc = ui.pc || { metal: 'silver', wt: 500, b: 2, s: 5 };
  const csShell = () => `<div class="toolbar">${seg('csMetal', [['all', 'Gold + Silver'], ['gold', 'Gold'], ['silver', 'Silver']])}<span style="flex:1"></span><span class="small muted">Bikri ka profit:</span>${seg('csP', [['month', 'Is mahine'], ['30', '30 din'], ['fy', 'FY'], ['all', 'Sab']])}</div>
    <div class="quick"><button class="btn gold" data-act="prod-new">${ic('plus', 16)} Add Piece</button><button class="btn" data-act="cs-rule" data-k="">${ic('edit', 16)} Category wastage set karo</button></div><div id="vbody"></div>`;

  function pcCalc() { const p = ui.pc; const m = num(p.s) - num(p.b); const fine = r3(num(p.wt) * m / 100); const rate = rateFor(p.metal); return { m, fine, value: r2(fine * rate), rate }; }
  function pcHTML() { const p = ui.pc, c = pcCalc();
    return `<div class="card pc-card"><div class="card-h"><div><h3>🧮 Wastage profit calculator</h3><div class="small muted">Kis wastage mein kharida, kis wastage mein becha — bacha hua fine metal aur uska paisa.</div></div></div>
      <div class="fg pc-fg"><label class="f"><span>Metal</span><select data-pc="metal" name="pc_metal">${opts([['gold', 'Gold'], ['silver', 'Silver']], p.metal)}</select></label>
      <label class="f"><span>Kitna maal becha (g)</span><input name="pc_wt" data-pc="wt" type="number" step="any" inputmode="decimal" value="${esc(p.wt)}"></label>
      <label class="f"><span>Kharid wastage %</span><input name="pc_b" data-pc="b" type="number" step="0.01" inputmode="decimal" value="${esc(p.b)}"></label>
      <label class="f"><span>Bikri wastage %</span><input name="pc_s" data-pc="s" type="number" step="0.01" inputmode="decimal" value="${esc(p.s)}"></label></div>
      <div class="pc-out" id="pc-out">${pcOut(c)}</div></div>`; }
  const pcOut = c => `<div><span>Wastage ka fark</span><b>${pct(c.m)}</b></div><div><span>Fine metal bacha</span><b class="gold-t">${g3(c.fine)}</b></div><div><span>Aaj ke bhaav se${c.rate ? ' (' + inr(c.rate) + '/g)' : ''}</span><b class="${c.value < 0 ? 'red' : 'green'}">${c.rate ? inr(c.value) : 'Rate set karo'}</b></div>`;

  function csBody() {
    const M = ui.csMetal; const all = catStock(); const rows = all.filter(r => M === 'all' || r.metal === M);
    const [a, b, plabel] = csRange(); const sold = soldByCat(a, b);
    sold.forEach(x => { if ((M === 'all' || x.metal === M) && !rows.some(r => r.key === x.key)) rows.push({ key: x.key, category: x.category, purity: x.purity, metal: x.metal, pcs: 0, gross: 0, net: 0, fine: 0, value: 0, buy: null, sell: null, pFine: 0, pValue: 0, pNet: 0, rule: catRule(x.category, x.purity) || {}, min: null, appr: 0 }); });
    const T = m => { const L = rows.filter(r => r.metal === m); const SL = [...sold.values()].filter(x => x.metal === m);
      return { pcs: sum(L, r => r.pcs), net: sum(L, r => r.net), fine: sum(L, r => r.fine), value: sum(L, r => r.value), pFine: sum(L, r => r.pFine), pValue: sum(L, r => r.pValue), sNet: sum(SL, x => x.net), gFine: sum(SL, x => x.gFine), gValue: sum(SL, x => x.gValue), n: L.length }; };
    const G = T('gold'), SV = T('silver'); const mets = M === 'all' ? ['gold', 'silver'] : [M];
    if (!rows.length) return emptyBox('Abhi koi stock nahi hai. <b>Add Piece</b> se maal chadhaiye — har category ka alag stock, aaj ke bhaav ki value aur wastage ka profit yahan dikhega.', `<button class="btn gold" data-act="prod-new">${ic('plus', 16)} Add Piece</button>`) + pcHTML();
    const tot = { gold: G, silver: SV };
    const kp = mets.map(m => { const x = tot[m]; return `<div class="kpis k4">${[[`${mName(m)} stock`, wt(x.net, m), `${x.pcs} pcs · fine ${wt(x.fine, m)}`], [`${mName(m)} ki value (aaj)`, compactInr(x.value), rateFor(m) ? `${inr(rateFor(m))}/g fine` : 'Rate set karo', 'Fine wt × aaj ka bhaav'],
      [`Stock mein profit`, wt(x.pFine, m), inr(x.pValue) + ' (bikne par)', 'Net wt × (bikri wastage − kharid wastage) ÷ 100, jahan dono wastage pata hain'], [`Kamaya (${plabel})`, wt(x.gFine, m), `${inr(x.gValue)} · ${wt(x.sNet, m)} becha`, 'Bike hue maal par wastage ka profit']].map(a => kpi(a[0], a[1], a[2], a[3])).join('')}</div>`; }).join('<div style="height:10px"></div>');
    const donut = m => { const L = rows.filter(r => r.metal === m && r.value > 0); const byCat = new Map(); L.forEach(r => byCat.set(r.category, (byCat.get(r.category) || 0) + r.value));
      return `<div class="card"><div class="card-h"><h3>${mName(m)} stock — category wise value</h3></div>${byCat.size ? SJC.donut([...byCat].map(([l, v]) => ({ l, v })), { fmt: v => compactInr(v), center: { t: compactInr(tot[m].value), s: wt(tot[m].net, m) }, label: mName(m) + ' stock value by category' }) : '<p class="small muted">Is metal ka stock nahi hai (ya rate set nahi).</p>'}</div>`; };
    const profBar = (title, f, sub, c) => { const L = rows.map(r => { const x = f(r); return { l: r.category + ' · ' + r.purity, v: x.v, sub: x.sub, tip: x.tip }; }).filter(x => Math.abs(x.v) >= 0.5).sort((p, q) => q.v - p.v).slice(0, 10);
      return `<div class="card"><div class="card-h"><div><h3>${title}</h3><div class="small muted">${sub}</div></div></div>${L.length ? SJC.hbar(L, { fmt: v => compactInr(v), c, rank: true }) : '<p class="small muted">Abhi data nahi — category ki kharid / bikri wastage bhariye.</p>'}</div>`; };
    const cell = (v, f) => v == null ? '<span class="muted">—</span>' : f(v);
    const tr = r => { const x = sold.get(r.key) || { net: 0, gFine: 0, gValue: 0, known: 0 }; const mg = r.buy != null && r.sell != null ? r.sell - r.buy : null; const low = r.min != null && r.pcs < r.min;
      return `<tr class="${low ? 'cs-low' : ''}">${td(`<button class="link" data-act="cs-view" data-k="${esc(r.category)}"><b>${esc(r.category)}</b></button><div class="small muted">${esc(r.purity)}${low ? ` · <span class="red">kam stock (min ${r.min})</span>` : ''}</div>`)}${td(r.pcs + (r.appr ? `<div class="small muted">${r.appr} approval</div>` : ''), 1)}${td(wt(r.net, r.metal) + `<div class="small muted">fine ${wt(r.fine, r.metal)}</div>`, 1)}${td('<b>' + inr(r.value) + '</b>', 1)}${td(cell(r.buy, pct), 1)}${td(cell(r.sell, pct), 1)}${td(mg == null ? '<span class="muted">—</span>' : `<span class="${mg < 0 ? 'red' : 'green'}"><b>${pct(mg)}</b></span>`, 1)}${td(mg == null ? '<span class="muted">—</span>' : wt(r.pFine, r.metal) + `<div class="small ${r.pValue < 0 ? 'red' : 'green'}">${inr(r.pValue)}</div>`, 1)}${td(x.net ? wt(x.net, r.metal) : '<span class="muted">—</span>', 1)}${td(x.net && x.known ? wt(x.gFine, r.metal) + `<div class="small ${x.gValue < 0 ? 'red' : 'green'}">${inr(x.gValue)}</div>` : x.net ? '<span class="small muted">kharid wastage set karo</span>' : '<span class="muted">—</span>', 1)}${td(`<button class="icon-btn sm" data-act="cs-rule" data-k="${esc(r.key)}" title="Wastage set karo" aria-label="Wastage set karo">${ic('edit', 14)}</button>`, 1)}</tr>`; };
    const table = m => { const L = rows.filter(r => r.metal === m); if (!L.length) return ''; const x = tot[m];
      return `<div class="card"><div class="card-h"><h3>${m === 'gold' ? '🟡' : '⚪'} ${mName(m)} — har category ka alag stock</h3><span class="pill ${m === 'gold' ? 'gold' : 'blue'}">${inr(rateFor(m))}/g fine</span></div>${btable([['Category'], ['Pcs', 'r'], ['Net wt', 'r'], ['Value (aaj)', 'r'], ['Kharid W', 'r'], ['Bikri W', 'r'], ['Fark', 'r'], ['Stock ka profit', 'r'], [`Becha (${plabel})`, 'r'], ['Kamaya', 'r'], ['', 'r']], L.map(tr), { foot: `<tr><td><b>Total</b></td>${td('<b>' + x.pcs + '</b>', 1)}${td('<b>' + wt(x.net, m) + '</b>', 1)}${td('<b>' + inr(x.value) + '</b>', 1)}<td></td><td></td><td></td>${td('<b>' + wt(x.pFine, m) + '</b><div class="small">' + inr(x.pValue) + '</div>', 1)}${td('<b>' + wt(x.sNet, m) + '</b>', 1)}${td('<b>' + wt(x.gFine, m) + '</b><div class="small">' + inr(x.gValue) + '</div>', 1)}<td></td></tr>` })}</div>`; };
    return `<div class="card">${kp}</div>
      <div class="two">${mets.map(donut).join('')}${mets.length === 1 ? profBar('Stock mein chhupa profit', r => ({ v: r.pValue, sub: wt(r.pFine, r.metal) + ' fine' }), 'Agar poora stock set wastage par bik jaye', 'var(--v3)') : ''}</div>
      ${mets.map(table).join('')}
      <div class="two">${mets.length > 1 ? profBar('Stock mein chhupa profit', r => ({ v: r.pValue, sub: wt(r.pFine, r.metal) + ' fine' }), 'Agar poora stock set wastage par bik jaye', 'var(--v3)') : ''}${profBar(`Kamaya hua profit — ${plabel}`, r => { const x = sold.get(r.key); return { v: x ? x.gValue : 0, sub: x ? wt(x.gFine, r.metal) + ' fine · ' + wt(x.net, r.metal) + ' becha' : '' }; }, 'Bike hue maal par (bikri − kharid) wastage', 'var(--v1)')}</div>
      <p class="small muted legend"><b>Hisaab:</b> Profit (fine) = Net wt × (Bikri wastage − Kharid wastage) ÷ 100. Jaise 2% mein kharida, 5% mein becha → 3% fark; 500 g becha → 15 g fine metal bacha → 15 g × aaj ka bhaav = paisa. Piece par wastage likha ho to wahi, warna category ka set wastage lagta hai.</p>${pcHTML()}`;
  }

  function openCatRule(key) {
    if (settingsGuard()) return; const m = rulesMap(); const r = key ? (m[key] || {}) : {}; const [c0, p0] = key ? key.split('|') : ['', ''];
    const st = key ? catStock().find(x => x.key === key) : null;
    openModal(`<form data-form="catrule" data-k="${esc(key || '')}" novalidate>${mHead(key ? 'Category wastage' : 'Category wastage set karo', key ? esc(c0 + ' · ' + p0) : 'Har category + purity ka kharid aur bikri wastage')}
      <div class="m-body"><section class="sec"><div class="fg">${selFld('Category', 'category', CATEGORIES, c0, { req: 1, ph: 'Select' })}${selFld('Purity', 'purity', PURITIES.map(x => x.k), p0, { req: 1, ph: 'Select' })}
      ${fld('Kharid wastage % (kis wastage mein kharidte ho)', 'b', r.b, { type: 'number', step: '0.01' })}${fld('Bikri wastage % (kis wastage mein bechoge)', 's', r.s, { type: 'number', step: '0.01' })}
      ${fld('Minimum stock (pcs) — isse kam ho to alert', 'min', r.min, { type: 'number', step: '1' })}${outFld('Fark (profit wastage)', 'cm')}</div>
      ${st ? `<p class="small muted" style="margin:10px 0 0">Abhi stock: <b>${st.pcs} pcs</b> · net ${wt(st.net, st.metal)} · value ${inr(st.value)}</p>` : ''}
      <p class="small muted" style="margin:8px 0 0">Ye wastage naye piece aur naye bill mein apne aap bhar jayega (piece ya party ka apna wastage ho to wahi chalega).</p></section></div>
      <div class="m-foot">${key && m[key] ? `<button type="button" class="btn danger" data-act="cs-rule-del" data-k="${esc(key)}">Delete</button>` : ''}<button type="button" class="btn" data-act="close">Cancel</button><button type="submit" class="btn primary">Save</button></div></form>`, { small: false });
    const f = document.querySelector('form[data-form=catrule]'); if (f) ruleCalc(f);
  }
  function ruleCalc(f) { const b = f.querySelector('[name=b]').value, s = f.querySelector('[name=s]').value; const o = f.querySelector('[data-o=cm]'); if (o) o.textContent = b !== '' && s !== '' ? pct(num(s) - num(b)) : '—'; }
  async function submitCatRule(form) {
    const d = formObj(form); if (!d.category || !d.purity) return toast('Category aur purity chuniye', 'err');
    if (d.b === '' && d.s === '' && d.min === '') return toast('Kharid ya bikri wastage bhariye', 'err');
    if ([d.b, d.s].some(x => x !== '' && (num(x) < -50 || num(x) > 100))) return toast('Wastage % sahi bhariye', 'err');
    const key = d.category + '|' + d.purity; const m = { ...rulesMap() }; const old = form.dataset.k; if (old && old !== key) delete m[old];
    m[key] = { b: d.b === '' ? '' : num(d.b), s: d.s === '' ? '' : num(d.s), min: d.min === '' ? '' : Math.max(0, Math.round(num(d.min))) };
    const ov = form.closest('.overlay'); if (await saveSettings({ ...S.settings, catW: m })) { closeModal(ov); toast('Category wastage save ho gaya'); }
  }
  SUBMIT2.catrule = submitCatRule;

  /* product form: live category stock + profit of this piece */
  SJP.prodAuto = function (form, ov, n) {
    if (!form || !ov) return; const f = k => form.querySelector(`[name="${k}"]`); if (!f('saleWastage')) return;
    if (n !== 'init' && !['category', 'purity', 'supplierId', 'making'].includes(n)) return;
    const r = catRule(f('category').value, f('purity').value);
    if (!ov._sManual) { f('saleWastage').value = r && hasV(r.s) ? num(r.s) : ''; ov._sAuto = !!(r && hasV(r.s)); }
    if (!ov._wManual && f('wastage').value === '' && r && hasV(r.b)) { f('wastage').value = num(r.b); ov._wAuto = true; }
  };
  SJP.prodCalc = function (form, ov) {
    const f = k => form.querySelector(`[name="${k}"]`); const o = k => form.querySelector(`[data-o="${k}"]`); if (!f('saleWastage') || !o('pfine')) return;
    const net = Math.max(0, r3(num(f('gross').value) - num(f('less').value))); const pur = f('purity').value, cat = f('category').value; const metal = metalOf(pur);
    const b = f('wastage').value, s = f('saleWastage').value; const st = o('stag'); if (st) { st.textContent = ov && ov._sManual ? 'manual' : (ov && ov._sAuto ? 'auto' : ''); st.className = 'tag' + (ov && ov._sManual ? ' manual' : ''); }
    if (b !== '' && s !== '' && net > 0) { const fine = r3(net * (num(s) - num(b)) / 100), rate = rateFor(metal); o('pfine').textContent = `${g3(fine)} (${pct(num(s) - num(b))})`; o('pval').textContent = rate ? inr(fine * rate) : 'Set rates'; o('pval').className = fine < 0 ? 'red' : ''; }
    else { o('pfine').textContent = '—'; o('pval').textContent = b === '' || s === '' ? 'Kharid + bikri wastage bharo' : '—'; o('pval').className = ''; }
    const box = o('catlive'); if (!box) return; const id = form.dataset.id || '';
    const L = owned().filter(p => p.id !== id); const mt = L.filter(p => metalOf(p.purity) === metal); const same = L.filter(p => p.category === cat && p.purity === pur);
    const agg = A => ({ pcs: sum(A, p => Math.max(1, num(p.pcs) || 1)), net: sum(A, p => p.net), val: sum(A, prodValue) }); const A = agg(same), B = agg(mt);
    const add = net > 0 && pur ? r2(net * num(f('tunch').value || (PUR[pur] || {}).t) / 100 * rateFor(metal)) : 0; const pcsN = Math.max(1, num(f('pcs').value) || 1);
    box.innerHTML = cat && pur ? `<div class="cl-row"><div><span>${esc(cat)} · ${esc(pur)} ka stock</span><b>${A.pcs} pcs · ${wt(A.net, metal)}</b><em>${inr(A.val)}</em></div><div><span>Ye piece jodkar</span><b>${A.pcs + pcsN} pcs · ${wt(A.net + net, metal)}</b><em>${inr(A.val + add)}</em></div><div><span>Kul ${mName(metal)} stock</span><b>${B.pcs} pcs · ${wt(B.net, metal)}</b><em>${inr(B.val)}</em></div></div>` : `<div class="cl-row"><div><span>Category aur purity chuniye</span><b>Us category ka alag stock yahan dikhega</b><em></em></div></div>`;
  };

  // "Category Stock & Profit" tab in the Vault
  if (!VT.some(t => t[0] === 'catstock')) VT.splice(1, 0, ['catstock', 'Category Stock & Profit']);
  { const VV = VIEWDEF.vault; VIEWDEF.vault = { shell: () => ui.vTab === 'catstock' ? subTabs('vTab', VT) + csShell() : VV.shell(), mount() { if (ui.vTab !== 'catstock' && VV.mount) VV.mount(); },
      body() { if (ui.vTab === 'catstock') return csBody(); const b = VV.body(); if (ui.vTab && ui.vTab !== 'stock') return b; return catStrip() + b; } }; }
  function catStrip() {
    const L = catStock().filter(r => r.pcs > 0); if (!L.length) return '';
    const byCat = new Map(); L.forEach(r => { const k = r.metal + '|' + r.category; let x = byCat.get(k); if (!x) { x = { metal: r.metal, category: r.category, pcs: 0, net: 0, value: 0 }; byCat.set(k, x); } x.pcs += r.pcs; x.net += r.net; x.value += r.value; });
    return `<div class="catstrip">${[...byCat.values()].sort((a, b) => b.value - a.value).map(x => `<button type="button" class="cchip ${x.metal}${ui.vCat === x.category ? ' on' : ''}" data-act="cs-view" data-k="${esc(ui.vCat === x.category ? '' : x.category)}"><span>${x.metal === 'gold' ? '🟡' : '⚪'} ${esc(x.category)}</span><b>${wt(x.net, x.metal)}</b><em>${x.pcs} pcs · ${compactInr(x.value)}</em></button>`).join('')}<button type="button" class="cchip more" data-act="seg" data-k="vTab" data-v="catstock"><span>Profit & wastage</span><b>Category Stock →</b><em>har category ka hisaab</em></button></div>`;
  }

  /* =================================================================
     3. AUTOMATION — daily stock snapshot + smart alerts
     ================================================================= */
  function snapNow() { const t = todayStr(), s = settings(); const T = SJP.metalTotals(); const pk = x => ({ pcs: x.pcs, net: r3(x.net), fine: r3(x.fine), val: Math.round(x.value) });
    return { id: t, date: t, g: pk(T.gold), s: pk(T.silver), rg: num(s.gold24), rs: num(s.silver999), at: Date.now() }; }
  let snapBusy = false;
  async function autoSnap() {
    if (snapBusy || (MODE !== 'cloud' && MODE !== 'local') || role() === 'viewer' || typeof settingsLoaded === 'undefined' || !settingsLoaded) return;
    if (!S.products.length && !S[SNAP].length) return;
    const n = snapNow(); const cur = S[SNAP].find(x => x.id === n.id);
    if (cur && (Date.now() - num(cur.at) < 2 * 3600e3 || JSON.stringify([cur.g, cur.s, cur.rg, cur.rs]) === JSON.stringify([n.g, n.s, n.rg, n.rs]))) return;
    snapBusy = true; try { await save(SNAP, n, { quiet: true }); } catch (e) { console.error(e); } finally { snapBusy = false; }
  }
  { const _odr = onDataReady; onDataReady = function () { _odr.apply(this, arguments); setTimeout(autoSnap, 5000); }; }
  setInterval(autoSnap, 20 * 60e3); setTimeout(autoSnap, 12000);
  SJP.snaps = () => S[SNAP].slice().sort((a, b) => a.date.localeCompare(b.date));

  SJP.alerts = function () {
    const out = []; const s = settings(), t = todayStr(), cfg = proCfg(); const stock = S.products.filter(p => p.status === 'In Stock');
    if (!num(s.gold24) && !num(s.silver999)) out.push({ t: 'Aaj ke rate set nahi hain — stock ki value aur profit ke liye zaroori.', b: 'Rates', a: 'data-act="rates"', lvl: 'warn' });
    else if (s.ratesUpdated !== t) out.push({ t: `Rate aaj update nahi hue (last ${fmtD(s.ratesUpdated) || '—'}).`, b: 'Update', a: 'data-act="rates"', lvl: 'warn' });
    if (window.SJ_STOCK && SJ_STOCK.pendingTags) { const n = SJ_STOCK.pendingTags().length; if (n) out.push({ t: `${n} piece ke tag print baaki hain.`, b: 'Tags & Print', a: 'data-act="pro-go" data-v="vault" data-k="vTab" data-t="tags"' }); }
    if (stock.length && Array.isArray(S.stockAudits)) { const last = S.stockAudits.map(a => a.date || tsDate(a.finishedAt || a.createdAt)).filter(Boolean).sort().pop(); const hr = new Date().getHours();
      if (cfg.nightAudit && last !== t && hr >= 18) out.push({ t: `Aaj ka stock audit baaki hai${last ? ' (pichhla ' + fmtD(last) + ')' : ''} — raat ko RFID se scan kar lijiye.`, b: 'Audit', a: 'data-act="pro-go" data-v="vault" data-k="vTab" data-t="rfid"', lvl: 'warn' });
      else if (last && daysBetween(last, t) >= 7) out.push({ t: `${daysBetween(last, t)} din se stock audit nahi hua.`, b: 'Audit', a: 'data-act="pro-go" data-v="vault" data-k="vTab" data-t="rfid"' }); }
    const tagged = stock.filter(p => p.rfid).length; if (tagged && tagged < stock.length) out.push({ t: `${stock.length - tagged} piece par RFID tag juda nahi hai.`, b: 'RFID jodo', a: 'data-act="pro-go" data-v="vault" data-k="vTab" data-t="rfid"' });
    catStock().filter(r => r.min != null && r.pcs < r.min).slice(0, 4).forEach(r => out.push({ t: `Kam stock: ${r.category} ${r.purity} — ${r.pcs} pcs (minimum ${r.min}).`, b: 'Dekho', a: 'data-act="pro-go" data-v="vault" data-k="vTab" data-t="catstock"', lvl: 'warn' }));
    const dd = num(cfg.deadDays) || 90; const dead = stock.filter(p => p.createdAt && (Date.now() - num(p.createdAt)) / 864e5 > dd); if (dead.length) out.push({ t: `${dead.length} piece ${dd}+ din se pade hain (${compactInr(sum(dead, prodValue))}).`, b: 'Insights', a: 'data-act="pro-go" data-v="vault" data-k="vTab" data-t="insights"' });
    const [ma] = monthRange(monthKey(t)); const loss = withChan('all', () => saleLines(ma, t)).filter(l => l.gainFine != null && l.gainFine < -0.0005); if (loss.length) out.push({ t: `Is mahine ${loss.length} item kharid se kam wastage par bike.`, b: 'Report', a: 'data-act="go-rep" data-v="wastage"', lvl: 'bad' });
    const noW = catStock().filter(r => r.pcs > 0 && (r.buy == null || r.sell == null)).length; if (noW) out.push({ t: `${noW} category ka kharid / bikri wastage set nahi hai — profit ka hisaab adhoora.`, b: 'Set karo', a: 'data-act="pro-go" data-v="vault" data-k="vTab" data-t="catstock"' });
    return out;
  };

  /* =================================================================
     4. EDIT / DELETE EVERYWHERE
     ================================================================= */
  function openPayEdit(invId, payId) {
    const v = S.invoices.find(x => x.id === invId); if (!v) return; const p = invPayments(v).find(x => x.id === payId); if (!p) return;
    openModal(`<form data-form="payedit" data-id="${esc(invId)}" data-pay="${esc(payId)}" novalidate>${mHead('Payment badlo', 'Bill ' + esc(v.no) + ' · ' + esc(v.partyName || ''))}<div class="m-body"><section class="sec"><div class="fg">
      ${fld('Date', 'date', p.date, { type: 'date', req: 1 })}${fld('Amount ₹', 'amount', p.amount, { type: 'number' })}${v.type === 'metal' ? fld('Fine metal (g)', 'fine', p.fine, { type: 'number' }) : ''}
      ${selFld('Mode', 'mode', [...new Set(['Cash', 'UPI', 'Bank', 'Cheque', 'Card', 'Scheme', p.mode].filter(Boolean))], p.mode || 'Cash')}${fld('Note', 'note', p.note, { span: 1 })}</div></section></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button type="submit" class="btn primary">Save</button></div></form>`, { small: true });
  }
  SUBMIT2.payedit = async form => {
    const d = formObj(form); const v = S.invoices.find(x => x.id === form.dataset.id); if (!v) return; if (!d.date) return toast('Date bhariye', 'err');
    if (num(d.amount) < 0 || (num(d.amount) <= 0 && !(num(d.fine) > 0))) return toast('Amount bhariye', 'err');
    const pays = invPayments(v).map(p => p.id === form.dataset.pay ? { ...p, date: d.date, amount: r2(num(d.amount)), fine: v.type === 'metal' ? r3(num(d.fine)) : num(p.fine) || 0, mode: d.mode || 'Cash', note: d.note || '' } : p);
    if (await save('invoices', { ...v, payments: pays, updatedAt: Date.now() })) { closeAll(); toast('Payment badal gaya'); openInvoiceView(v.id); }
  };

  const DM = [['invoices', 'Bills / invoices', 'inv-view', 'inv-del'], ['customers', 'Customers', 'cust-edit', 'cust-del'], ['suppliers', 'Suppliers', 'sup-edit', 'sup-del'], ['products', 'Vault pieces', 'prod-edit', 'prod-del'], ['orders', 'Deals / orders', 'ord-edit', 'ord-del'], ['estimates', 'Order estimates', 'est-edit', 'est-del'],
    ['approvals', 'Approval memos', 'ap-edit', 'ap-del'], ['jobs', 'Karigar jobs', 'job-edit', 'job-del'], ['expenses', 'Expenses', 'exp-edit', 'exp-del'], ['banktx', 'Bank / cash entries', 'btx-edit', 'btx-del'], ['schemes', 'Scheme members', 'sc-open', 'sc-del'], ['bookings', 'Bookings', 'booking-edit', 'booking-del'],
    ['repairs', 'Repairs', 'repair-edit', 'repair-del'], ['hallmark', 'Hallmark batches', 'hm-edit', 'hm-del'], ['cdn', 'Credit / debit notes', '', 'cdn-del'], ['leads', 'Leads', 'lead-edit', 'lead-del'], ['targets', 'Targets', 'tg-edit', 'tg-del'], ['closings', 'Day closings', '', ''], ['rateHistory', 'Rate history', 'rh-edit', ''], ['stockAudits', 'Stock audits', 'aud-view', ''], ['notes', 'AI notes', '', 'note-del'], [SNAP, 'Stock snapshots', '', '']];
  const dmLabel = (c, d) => { const a = d.no || d.sku || d.name || d.title || d.label || d.customerName || d.partyName || (d.date ? fmtD(d.date) : '') || d.text || d.id; const b = [d.name && d.no ? d.name : '', d.partyName && d.partyName !== a ? d.partyName : '', d.customerName && d.customerName !== a ? d.customerName : '', d.category ? d.category + (d.purity ? ' ' + d.purity : '') : '', d.phone || '', d.kind || d.type || d.status || ''].filter(Boolean).slice(0, 3).join(' · ');
    const dt = d.date || tsDate(d.createdAt) || ''; const amt = d.totals && d.totals.grand != null ? inr(d.totals.grand) : hasV(d.amount) ? inr(d.amount) : c === 'rateHistory' ? `G ${inr(d.gold24)} · S ${inr(d.silver999)}` : c === 'products' ? g3(d.net) : ''; return { a: String(a).slice(0, 60), b, dt, amt }; };
  function dmList(ov) {
    const c = ov._col; const def = DM.find(x => x[0] === c); const q = norm(ov.querySelector('#dm-q').value); let L = (Array.isArray(S[c]) ? S[c] : []).slice();
    L.sort((x, y) => String(y.date || '').localeCompare(String(x.date || '')) || num(y.updatedAt || y.createdAt) - num(x.updatedAt || x.createdAt));
    if (q) L = L.filter(d => { const l = dmLabel(c, d); return [l.a, l.b, l.dt, d.partyPhone, d.huid, d.rfid].some(x => norm(x).includes(q)); });
    ov.querySelector('#dm-n').textContent = `${L.length} entries`;
    ov.querySelector('#dm-list').innerHTML = L.length ? L.slice(0, 150).map(d => { const l = dmLabel(c, d);
      return `<div class="dm-row"><div style="min-width:0"><b>${esc(l.a)}</b><div class="small muted">${esc([l.b, fmtD(l.dt)].filter(Boolean).join(' · '))}</div></div><div class="dm-r"><span class="small">${esc(l.amt)}</span>${def[2] ? `<button type="button" class="btn sm" data-act="dm-edit" data-id="${esc(d.id)}">${def[2].endsWith('view') || def[2].endsWith('open') ? 'Kholo' : 'Edit'}</button>` : ''}${canAdmin() ? `<button type="button" class="btn sm danger" data-act="dm-del" data-id="${esc(d.id)}">Delete</button>` : ''}</div></div>`; }).join('') + (L.length > 150 ? '<p class="small muted">Pehle 150 dikh rahe hain — search karke chhota kijiye.</p>' : '') : '<div class="empty small">Koi entry nahi mili.</div>';
  }
  function openDM(col) {
    const el = openModal(`${mHead('Sab entries — edit / delete', 'Kisi bhi bill ya entry ko dhoondo, kholo, badlo ya mitao')}<div class="m-body"><div class="fg"><label class="f"><span>Kya dekhna hai</span><select id="dm-col">${opts(DM.filter(x => Array.isArray(S[x[0]])).map(x => [x[0], `${x[1]} (${S[x[0]].length})`]), col || 'invoices')}</select></label><label class="f"><span>Search</span><input id="dm-q" placeholder="No., naam, phone, date…" autocomplete="off"></label></div>
      <div class="small muted" id="dm-n" style="margin:10px 0 6px"></div><div id="dm-list"></div><p class="small muted" style="margin:10px 0 0">Delete hui entry 30 din tak Setup → Recycle bin mein rehti hai. Delete sirf Owner / Manager kar sakte hain.</p></div><div class="m-foot"><button type="button" class="btn" data-act="close">Close</button></div>`, { wide: true });
    el._col = col || 'invoices'; el._dm = true; dmList(el); return el;
  }
  SJP.refreshDM = () => { const ov = [...document.querySelectorAll('#modal-root .overlay')].find(x => x._dm); if (ov && ov.isConnected) dmList(ov); };
  function openRateEdit(id) {
    const r = S.rateHistory.find(x => x.id === id) || { id: '', date: id || todayStr() };
    openModal(`<form data-form="rhedit" data-id="${esc(r.id || '')}" novalidate>${mHead(r.id ? 'Rate badlo' : 'Purana rate jodo', r.id ? fmtD(r.date) : '')}<div class="m-body"><section class="sec"><div class="fg">${fld('Date', 'date', r.date, { type: 'date', req: 1 })}${fld('Gold 24K — ₹ / 10 g', 'gold24', r.gold24, { type: 'number' })}${fld('Silver 999 — ₹ / kg', 'silver999', r.silver999, { type: 'number' })}</div></section></div>
      <div class="m-foot">${r.id && canAdmin() ? `<button type="button" class="btn danger" data-act="rh-del" data-id="${esc(r.id)}">Delete</button>` : ''}<button type="button" class="btn" data-act="close">Cancel</button><button type="submit" class="btn primary">Save</button></div></form>`, { small: true });
  }
  SUBMIT2.rhedit = async form => {
    const d = formObj(form); if (!d.date) return toast('Date bhariye', 'err'); if (num(d.gold24) <= 0 && num(d.silver999) <= 0) return toast('Rate bhariye', 'err');
    const old = form.dataset.id; const prev = S.rateHistory.find(x => x.id === (old || d.date)) || {};
    if (old && old !== d.date) await removeDoc('rateHistory', old);
    const ov = form.closest('.overlay');
    if (await save('rateHistory', { ...prev, id: d.date, date: d.date, gold24: num(d.gold24), silver999: num(d.silver999), source: prev.source || 'manual' }, { quiet: true })) {
      if (d.date === todayStr() && canAdmin()) await saveSettings({ ...S.settings, gold24: num(d.gold24) || S.settings.gold24, silver999: num(d.silver999) || S.settings.silver999, ratesUpdated: d.date, ratesSource: 'manual', ratesAt: new Date().toISOString() });
      closeModal(ov); toast('Rate save ho gaya'); SJP.refreshDM(); }
  };

  /* Setup card */
  function setupCard() {
    const c = proCfg(); const adm = canAdmin();
    return `<div class="card" id="sj-pro-card"><div class="card-h"><div><h3>Pro tools</h3><div class="small muted">Sab entries, bill ka design aur automation</div></div><div class="btns"><button class="btn sm gold" data-act="dm-open">${ic('search', 14)} Sab entries — edit / delete</button></div></div>
      <div class="fg"><label class="f"><span>GST bill ka design</span><select data-pro="billStyle"${adm ? '' : ' disabled'}>${opts([['signature', 'Signature — photo wala, 300 DPI (best)'], ['royal', 'Royal — kaala-sona premium'], ['ivory', 'Ivory — safed premium (kam ink)'], ['classic', 'Classic — purana design']], c.billStyle)}</select></label>
      <label class="f"><span>Purana stock alert (din)</span><input type="number" step="1" inputmode="numeric" data-pro="deadDays" value="${esc(c.deadDays)}"${adm ? '' : ' disabled'}></label>
      <label class="f chk"><span>Raat ko stock audit ki yaad</span><select data-pro="nightAudit"${adm ? '' : ' disabled'}>${opts([['1', 'Haan — shaam 6 baje ke baad yaad dilao'], ['0', 'Nahi']], c.nightAudit ? '1' : '0')}</select></label></div>
      <p class="small muted" style="margin:10px 0 0">Apne aap hota hai: roz ka stock snapshot (stock trend chart ke liye), category wastage se auto-fill, party ke hisaab se Wholesale / Retail, tag dobara-print list, aur dashboard par alerts.</p></div>`;
  }
  { const V = VIEWDEF.setup; if (V) VIEWDEF.setup = { ...V, body() { return V.body.call(V) + setupCard(); } }; }
  document.addEventListener('change', async e => {
    const t = e.target; if (!t || !t.dataset) return;
    if (t.dataset.pro) { if (settingsGuard()) return; const k = t.dataset.pro; let v = t.value; if (k === 'nightAudit') v = v === '1'; if (k === 'deadDays') v = Math.max(7, Math.round(num(v)) || 90); if (await saveSettings({ ...S.settings, pro: { ...((S.settings || {}).pro || {}), [k]: v } })) toast('Saved'); return; }
    if (t.id === 'dm-col') { const ov = t.closest('.overlay'); if (ov) { ov._col = t.value; dmList(ov); } }
  });
  document.addEventListener('input', e => {
    const t = e.target; if (!t || !t.dataset) return;
    if (t.dataset.pc) { ui.pc[t.dataset.pc] = t.dataset.pc === 'metal' ? t.value : t.value; const o = document.getElementById('pc-out'); if (o) o.innerHTML = pcOut(pcCalc()); return; }
    if (t.id === 'dm-q') { const ov = t.closest('.overlay'); if (ov) dmList(ov); return; }
    const f = t.closest && t.closest('form[data-form=catrule]'); if (f) ruleCalc(f);
  });

  const ACT = {
    'cs-rule': t => openCatRule(t.dataset.k || ''),
    'cs-rule-del': t => confirmBox('Is category ka wastage rule hatana hai?', async () => { const m = { ...rulesMap() }; delete m[t.dataset.k]; if (await saveSettings({ ...S.settings, catW: m })) { closeAll(); toast('Rule hata diya'); } }, 'Hatao'),
    'cs-view': t => { ui.vTab = 'stock'; ui.vCat = t.dataset.k || ''; ui.vStatus = 'In Stock'; if (view === 'vault') renderView(true); else location.hash = '#vault'; },
    'pro-go': t => { if (t.dataset.k) ui[t.dataset.k] = t.dataset.t; if (view === t.dataset.v) renderView(true); else location.hash = '#' + t.dataset.v; window.scrollTo(0, 0); },
    'pay-edit': t => openPayEdit(t.dataset.id, t.dataset.pay),
    'sc-del': t => { const m = S.schemes.find(x => x.id === t.dataset.id); if (!m) return; if (!canAdmin()) return toast('Delete sirf Owner / Manager kar sakte hain', 'err'); confirmBox(`Scheme member <b>${esc(m.no || '')} · ${esc(m.customerName || '')}</b> aur uski ${(m.payments || []).length} kisht ki entry mitani hai?`, async () => { if (await removeDoc('schemes', m.id)) { closeAll(); toast('Scheme entry delete ho gayi'); SJP.refreshDM(); } }); },
    'cl-del': t => { const d = t.dataset.id; const r = S.closings.find(x => x.id === d || x.date === d); if (!r) return toast('Is din ki closing nahi mili', 'err'); if (!canAdmin()) return toast('Sirf Owner / Manager', 'err'); confirmBox(`<b>${fmtD(r.date || d)}</b> ki day closing hata kar din dobara kholna hai?`, async () => { if (await removeDoc('closings', r.id)) { toast('Din dobara khul gaya'); SJP.refreshDM(); } }, 'Reopen'); },
    'dm-open': () => openDM(),
    'dm-edit': (t, ov) => { const def = DM.find(x => x[0] === ov._col); if (!def || !def[2]) return; if (def[2] === 'rh-edit') return openRateEdit(t.dataset.id); fire(def[2], t.dataset.id); },
    'dm-del': (t, ov) => { if (!canAdmin()) return toast('Delete sirf Owner / Manager kar sakte hain', 'err'); const c = ov._col, def = DM.find(x => x[0] === c), id = t.dataset.id; if (def && def[3]) return fire(def[3], id);
      const d = (S[c] || []).find(x => x.id === id); if (!d) return; confirmBox(`<b>${esc(dmLabel(c, d).a)}</b> — ye entry mitani hai?`, async () => { if (await removeDoc(c, id)) { toast('Entry delete ho gayi'); SJP.refreshDM(); } }); },
    'rh-edit': t => openRateEdit(t.dataset.id || ''),
    'rh-del': t => confirmBox('Is din ka rate record mitana hai?', async () => { if (await removeDoc('rateHistory', t.dataset.id)) { closeAll(); toast('Rate record delete'); } })
  };
  document.addEventListener('click', async e => {
    const t = e.target.closest && e.target.closest('[data-act]'); if (!t) return; const h = ACT[t.dataset.act]; if (!h) return; if (t.tagName === 'BUTTON' && t.disabled) return;
    try { await h(t, t.closest('.overlay'), e); } catch (err) { console.error(err); toast('Kuch gadbad hui — dobara try kijiye', 'err'); }
  });
  // keep the open "Sab entries" list fresh while data changes
  { const _sr = scheduleRender; scheduleRender = function () { const r = _sr.apply(this, arguments); clearTimeout(SJP._dmT); SJP._dmT = setTimeout(SJP.refreshDM, 250); return r; }; }


  /* =================================================================
     9. GOLD + SILVER STOCK — metal first
     Add Gold / Add Silver buttons, metal filter on the Vault, a metal
     picker in the Add Piece form (purity list follows the metal), and
     gold / silver totals on the stock tab.
     ================================================================= */
  ui.vMetal = ui.vMetal || 'all';
  { const _vl = vaultList; vaultList = function () { const L = _vl.apply(this, arguments); return ui.vMetal === 'gold' || ui.vMetal === 'silver' ? L.filter(p => metalOf(p.purity) === ui.vMetal) : L; }; }
  const metalBar = () => {
    const T = SJP.metalTotals(), g = T.gold, sv = T.silver;
    const tile = (m, t) => `<div class="mt-tile ${m}"><div class="mt-h"><span class="mt-dot"></span>${m === 'gold' ? 'Gold stock' : 'Silver stock'}</div><div class="mt-v">${wt(t.net, m)}</div><div class="mt-s">${t.pcs} pcs · ${rateFor(m) ? compactInr(t.value) + ' aaj ke bhaav par' : '<span class="red">bhaav set karo (Rates)</span>'}</div></div>`;
    return `<div class="metalbar"><div class="mb-tiles">${tile('gold', g)}${tile('silver', sv)}</div>
      <div class="mb-ctl"><div class="mb-add"><button type="button" class="btn gold" data-act="add-metal" data-m="gold">🟡 Gold piece add</button><button type="button" class="btn silverbtn" data-act="add-metal" data-m="silver">⚪ Silver piece add</button></div>
      <div class="seg">${[['all', 'Dono'], ['gold', 'Gold'], ['silver', 'Silver']].map(([v, l]) => `<button type="button" data-act="seg" data-k="vMetal" data-v="${v}" class="${ui.vMetal === v ? 'on' : ''}">${l}</button>`).join('')}</div></div></div>`;
  };
  { const VV = VIEWDEF.vault; const _sh = VV.shell; VIEWDEF.vault = { ...VV, shell: () => ui.vTab === 'catstock' || (ui.vTab && ui.vTab !== 'stock') ? _sh() : metalBar() + _sh() }; }
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act="add-metal"]'); if (!t) return; openProductForm(undefined, t.dataset.m === 'silver' ? { purity: 'Silver 925' } : { purity: '22K' }); });
  // Add Piece form: metal first, purity list follows
  function fillPurity(sel, m, keep) {
    sel.innerHTML = '<option value="">Select</option>' + PURITIES.filter(p => !m || p.metal === m).map(p => `<option value="${esc(p.k)}">${esc(p.k)}</option>`).join('');
    if (keep && (!m || metalOf(keep) === m)) sel.value = keep;
  }
  function enhanceMetal() {
    const f = document.querySelector('form[data-form=product]'); if (!f || f.dataset.mp) return;
    const pur = f.querySelector('[name=purity]'); if (!pur) return; f.dataset.mp = '1';
    const cur = pur.value; const m0 = cur ? metalOf(cur) : '';
    pur.closest('label').insertAdjacentHTML('beforebegin', `<label class="f"><span>Dhaatu (Metal)</span><select name="metalPick"><option value="">Dono (sab purity)</option><option value="gold"${m0 === 'gold' ? ' selected' : ''}>Gold</option><option value="silver"${m0 === 'silver' ? ' selected' : ''}>Silver</option></select></label>`);
    const pick = f.querySelector('[name=metalPick]'); if (m0) fillPurity(pur, m0, cur);
    pick.addEventListener('change', () => { const keep = pur.value; fillPurity(pur, pick.value, keep); });
    pur.addEventListener('change', () => { if (pur.value) pick.value = metalOf(pur.value); });
  }
  { const _opf = openProductForm; openProductForm = function () { const r = _opf.apply(this, arguments); try { enhanceMetal(); } catch (e) { console.error(e); } return r; }; }

  window.SJ_PRO = SJP;
})();
