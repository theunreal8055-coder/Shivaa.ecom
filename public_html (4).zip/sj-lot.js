/* =====================================================================
   Shivaa Jewels — CHANDI BOX / PETI + COUNTER TRAY (v45)
   • Box (lot): ek tag sirf box par — design, ginti, wazan, khaali box ka wazan
   • Peti: team ke saare box ek peti mein, ek seal; har dukaan se pehle / baad
     gaadi ke kaante par peti ka tol → pehle − biki = baad (fark = alert)
   • Bikri: box scan + dukaandar ke kaante ki photo (AI wazan padhta hai) →
     ginti apne aap, box se ghatta hai, bill (paisa ya fine chandi) khulta hai
   • Box-wise jaanch, AI se khaane ginna, samay + GPS har tol par
   • Counter tray: subah / shaam ginti + wazan, haath badalna PIN se
   ===================================================================== */
(function () {
  'use strict';
  if (typeof VIEWDEF === 'undefined' || typeof S === 'undefined') return;
  const SITE = !!window.SJ_AI;
  const me = () => window.SJ_USER || { role: 'owner', name: 'Owner', id: 'u_owner', uname: 'owner' };
  const boss = () => !SITE || ['owner', 'manager'].includes(me().role);
  const q$ = (s, r) => (r || document).querySelector(s);
  const API = (a, b) => window.SJ_API_CALL ? window.SJ_API_CALL(a, b || {}) : Promise.reject(new Error('website par chalta hai'));
  const g2 = n => num(n).toFixed(2) + ' g';
  const tm = ms => ms ? new Date(ms).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '';
  const tol = () => num((settings().pro || {}).lotTol) || 1.5;
  ['boxes', 'petis', 'trays', 'trayLogs'].forEach(c => { if (!COLS.includes(c)) COLS.push(c); if (!S[c]) S[c] = []; });
  const boxOf = id => S.boxes.find(b => b.id === id);
  const netOf = b => Math.max(0, num(b.gross) - num(b.tare));
  const avgOf = b => num(b.avg) || (num(b.pcs) ? netOf(b) / num(b.pcs) : 0);
  const findBox = raw => { const s = String(raw || '').trim().toUpperCase(); return S.boxes.find(b => String(b.no).toUpperCase() === s || String(b.rfid || '').toUpperCase() === s || String(b.design || '').toUpperCase() === s && b.loc); };
  const alertSrv = (text, level) => API('lot_alert', { text, level: level || 'high' }).catch(() => null);
  const gps = () => new Promise(res => { if (!navigator.geolocation) return res(null); navigator.geolocation.getCurrentPosition(p => res({ lat: +p.coords.latitude.toFixed(5), lon: +p.coords.longitude.toFixed(5) }), () => res(null), { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 }); });

  /* ---------- photo + AI ---------- */
  function pickPhoto() {
    return new Promise(res => {
      const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.capture = 'environment'; i.style.display = 'none'; document.body.appendChild(i);
      const on = ev => { if (ev.target !== i) return; ev.stopPropagation(); window.removeEventListener('change', on, true); const f = i.files && i.files[0]; i.remove(); if (!f) return res(null); const im = new Image(); const u = URL.createObjectURL(f); im.onload = () => { const s = Math.min(1, 900 / Math.max(im.naturalWidth, im.naturalHeight)); const c = document.createElement('canvas'); c.width = Math.round(im.naturalWidth * s); c.height = Math.round(im.naturalHeight * s); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', 0.7)); }; im.onerror = () => res(null); im.src = u; };
      window.addEventListener('change', on, true); i.click();
    });
  }
  async function aiJson(img, prompt) {
    if (!window.SJ_AI) throw new Error('AI website par chalta hai');
    const r = await SJ_AI.ask({ messages: [{ role: 'user', content: prompt + ' Reply ONLY JSON.', images: [{ mime: 'image/jpeg', data: img.split(',')[1] }] }], tools: [] });
    if (r.notSet) throw new Error('AI key nahi hai — Setup mein daaliye');
    const t = String(r.text || ''); const a = t.indexOf('{'), b = t.lastIndexOf('}'); if (a < 0) throw new Error('AI ne saaf jawab nahi diya');
    return JSON.parse(t.slice(a, b + 1));
  }
  const aiWeight = img => aiJson(img, 'This photo shows a digital weighing scale display (jewellery scale, grams). Read the number shown on the display. JSON: {"grams": number or null, "sure": true|false}');
  const aiSlots = img => aiJson(img, 'This photo shows a jewellery box with slots/compartments for rings. Count how many slots have a ring (filled) and how many are empty. JSON: {"filled": number, "empty": number, "sure": true|false}');

  /* ================= BOX MASTER ================= */
  async function boxForm(id) {
    const b = id ? boxOf(id) : { id: uid('bx'), no: nextNo('boxes', 'B-'), design: '', purity: 'Silver 80', pcs: '', gross: '', tare: '', loc: '' };
    const el = openModal(`<form novalidate>${mHead(id ? '📦 Box ' + esc(b.no) : '📦 Naya box', 'Tag sirf box par — ringon par design ka barcode')}<div class="m-body"><div class="fg">
      ${fld('Box no.', 'no', b.no, { req: 1 })}${fld('Design / code (ring par yahi barcode)', 'design', b.design, { req: 1, ph: 'R-12' })}
      <label class="f"><span>Purity</span><select name="purity">${PURITIES.filter(p => p.metal === 'silver').map(p => `<option ${p.k === b.purity ? 'selected' : ''}>${p.k}</option>`).join('')}</select></label>
      ${fld('Ginti (pcs)', 'pcs', b.pcs, { type: 'number', req: 1 })}${fld('Kul wazan box ke saath (g)', 'gross', b.gross, { type: 'number', req: 1 })}${fld('Khaali box ka wazan (g)', 'tare', b.tare, { type: 'number' })}
      ${fld('RFID / QR code (optional)', 'rfid', b.rfid || '')}${fld('Labour ₹ / g (bill ke liye)', 'labour', b.labour || '', { type: 'number' })}</div>
      <p class="small muted">Ek ring ka average = (kul − khaali box) ÷ ginti. Box tol kar bharein — 0.01 g wala kaanta.</p></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save</button></div></form>`);
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target);
      if (!(num(f.pcs) > 0) || !(num(f.gross) > num(f.tare))) return toast('Ginti aur wazan sahi daaliye', 'err');
      if (S.boxes.some(x => x.id !== b.id && String(x.no).toUpperCase() === String(f.no).toUpperCase())) return toast('Ye box no. pehle se hai', 'err');
      const o = { ...b, no: f.no.trim(), design: f.design.trim(), purity: f.purity, pcs: Math.round(num(f.pcs)), gross: r3(num(f.gross)), tare: r3(num(f.tare)), rfid: f.rfid.trim(), labour: num(f.labour), updatedAt: Date.now() };
      o.avg = r3((o.gross - o.tare) / o.pcs); if (!o.createdAt) o.createdAt = Date.now();
      if (await save('boxes', o)) { closeModal(el); toast(`✓ ${o.no}: ${o.pcs} pcs · ek ${o.avg} g`); renderView(true); }
    };
  }
  function boxBody() {
    const L = S.boxes.slice().sort((a, b) => String(a.no).localeCompare(String(b.no), 'en', { numeric: true }));
    return `<div class="toolbar">${boss() ? '<button type="button" class="btn gold" data-act="lt-box-new">📦 Naya box</button>' : ''}</div>
      <div class="stats">${stat('Box', L.length, '', 'box', 'gold')}${stat('Kul ring', sum(L, b => b.pcs), '', 'tag', '')}${stat('Kul chandi', (sum(L, netOf) / 1000).toFixed(3) + ' kg', 'box ke bina', 'coin', 'sky')}${stat('Field mein', L.filter(b => b.loc).length + ' box', '', 'truck', '')}</div>
      ${L.length ? `<div class="tw"><table class="tbl"><thead><tr><th>Box</th><th>Design</th><th class="r">Ginti</th><th class="r">Wazan (box ke saath)</th><th class="r">Ek ring</th><th>Kahan</th><th></th></tr></thead><tbody>${L.map(b => `<tr><td><b class="mono">${esc(b.no)}</b></td><td>${esc(b.design)} <span class="small muted">${esc(b.purity || '')}</span></td><td class="r"><b>${b.pcs}</b></td><td class="r">${g2(b.gross)}</td><td class="r">${num(avgOf(b)).toFixed(2)} g</td><td>${b.loc ? `<span class="pill sky">${esc((S.petis.find(p => p.id === b.loc) || {}).no || 'peti')}</span>` : 'Godown'}</td><td>${boss() ? `<button type="button" class="btn sm" data-act="lt-box-edit" data-id="${esc(b.id)}">Badlo</button>` : ''}</td></tr>`).join('')}</tbody></table></div>` : emptyBox('Abhi koi box nahi. "Naya box" se har box ka design, ginti aur wazan bhariye.')}`;
  }

  /* ================= PETI ================= */
  const myPetis = () => S.petis.filter(p => p.status === 'out' && (boss() || (p.staffUids || []).includes(me().id)));
  const lastW = p => { const L = (p.log || []).filter(x => x.w != null); return L.length ? L[L.length - 1] : null; };
  function expW(p) { const l = lastW(p); if (!l) return null; return r2(num(l.w) - sum((p.sales || []).filter(s => s.at > l.at), s => s.w)); }
  async function petiNew() {
    const free = S.boxes.filter(b => !b.loc && b.pcs > 0); if (!free.length) return toast('Godown mein koi box nahi', 'err');
    let staff = []; try { staff = (await API('uext_list')).users.filter(u => u.active && u.role !== 'viewer'); } catch (e) { /* offline */ }
    const el = openModal(`<form novalidate>${mHead('🧳 Naya peti (team ke liye)', 'Box chuniye, peti tolo, seal lagao')}<div class="m-body"><div class="fg">
      ${fld('Peti no.', 'no', nextNo('petis', 'P-'), { req: 1 })}${fld('Gaadi', 'car', '')}
      <label class="f span2"><span>Team (2 log)</span><select name="s1">${staff.map(u => `<option value="${esc(u.id)}">${esc(u.name)}</option>`).join('')}</select><select name="s2"><option value="">— doosra —</option>${staff.map(u => `<option value="${esc(u.id)}">${esc(u.name)}</option>`).join('')}</select></label></div>
      <h4 class="gd-h">Box</h4><div class="lt-pick">${free.map(b => `<label class="chk"><input type="checkbox" data-bx="${esc(b.id)}"> <b class="mono">${esc(b.no)}</b> ${esc(b.design)} · ${b.pcs} pcs · ${g2(b.gross)}</label>`).join('')}</div>
      <div class="fg">${fld('Khaali peti ka wazan (g)', 'tare', '', { type: 'number' })}${fld('Peti ka kul wazan — kaante par (g)', 'w', '', { type: 'number', req: 1 })}${fld('Seal no.', 'seal', '', { req: 1 })}</div><p class="small muted" data-o="sumw"></p></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Peti do</button></div></form>`, { wide: true });
    const upd = () => { const ids = [...el.querySelectorAll('[data-bx]:checked')].map(i => i.dataset.bx); const s = sum(ids.map(boxOf), b => b.gross) + num((q$('[name="tare"]', el) || {}).value); q$('[data-o="sumw"]', el).textContent = ids.length ? `${ids.length} box · hona chahiye ≈ ${g2(s)} (box + khaali peti)` : ''; };
    el.addEventListener('change', upd); el.addEventListener('input', upd);
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); const ids = [...el.querySelectorAll('[data-bx]:checked')].map(i => i.dataset.bx);
      if (!ids.length) return toast('Box chuniye', 'err'); if (!(num(f.w) > 0) || !f.seal) return toast('Wazan aur seal zaroori', 'err');
      const should = r2(sum(ids.map(boxOf), b => b.gross) + num(f.tare)); const d = r2(num(f.w) - should);
      if (Math.abs(d) > tol() && !await SJ_CONFIRM(`Kaante ka wazan ${g2(f.w)} hai, box ke hisaab se ${g2(should)} hona chahiye (fark ${d} g). Phir bhi peti dein?`, 'Haan')) return;
      const nm = id => (staff.find(u => u.id === id) || {}).name || '';
      const p = { id: uid('pt'), no: f.no, date: todayStr(), car: f.car, staffUids: [f.s1, f.s2].filter(Boolean), team: [nm(f.s1), nm(f.s2)].filter(Boolean).join(' + '), boxes: ids, tare: num(f.tare), seal: f.seal, status: 'out', sales: [], createdAt: Date.now(),
        log: [{ at: Date.now(), k: 'start', w: r2(num(f.w)), seal: f.seal, by: me().name, shop: 'Office', exp: should, diff: d, ok: Math.abs(d) <= tol() }] };
      if (!await save('petis', p)) return;
      for (const id of ids) await save('boxes', { ...boxOf(id), loc: p.id, updatedAt: Date.now() }, { quiet: true });
      closeModal(el); toast(`✓ ${p.no} — ${ids.length} box ${p.team} ko`); renderView(true);
    };
  }
  async function weigh(pid, k) {
    const p = S.petis.find(x => x.id === pid); if (!p) return; const exp = expW(p);
    const lbl = { pre: 'Dukaan se PEHLE', post: 'Dukaan ke BAAD', end: 'Shaam — office mein', check: 'Beech mein jaanch' }[k];
    const el = openModal(`<form novalidate>${mHead('⚖ Peti tolo — ' + lbl, esc(p.no) + ' · ' + esc(p.team || ''))}<div class="m-body">
      <div class="lt-exp">Hona chahiye: <b>${exp == null ? '—' : g2(exp)}</b></div>
      <div class="fg">${k === 'pre' || k === 'post' ? fld('Dukaan', 'shop', (p.cur || {}).shop || '', { req: 1 }) : ''}${fld('Kaante par wazan (g)', 'w', '', { type: 'number', req: 1 })}${fld(k === 'pre' || k === 'end' ? 'Seal no. (jo laga hai)' : 'Naya seal no.', 'seal', k === 'pre' || k === 'end' ? p.seal : '', { req: 1 })}</div>
      <div class="btns"><button type="button" class="btn sm" data-o="ph">📷 Kaante ki photo (AI padhega)</button></div><div class="small" data-o="ai"></div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save</button></div></form>`, { small: true });
    let photo = '';
    q$('[data-o="ph"]', el).onclick = async () => { const img = await pickPhoto(); if (!img) return; photo = img; const o = q$('[data-o="ai"]', el); o.textContent = '🤖 AI padh raha hai…'; try { const r = await aiWeight(img); if (r.grams != null) { q$('[name="w"]', el).value = r.grams; o.innerHTML = `✓ AI ne padha: <b>${r.grams} g</b>${r.sure ? '' : ' (pakka nahi — khud dekh lijiye)'}`; } else o.textContent = 'AI number nahi padh paya — khud likhiye'; } catch (e) { o.textContent = e.message; } };
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target); const w = r2(num(f.w)); if (!(w > 0)) return toast('Wazan daaliye', 'err');
      const p2 = S.petis.find(x => x.id === pid); const e2 = expW(p2); const d = e2 == null ? 0 : r2(w - e2); const ok = Math.abs(d) <= tol();
      const sealBad = (k === 'pre' || k === 'end') && f.seal && p2.seal && String(f.seal).trim() !== String(p2.seal).trim();
      const pos = await gps();
      let phId; if (photo) { phId = uid('lph'); await save('fieldPhotos', { id: phId, cid: pid, vid: phId, kind: 'peti-' + k, party: f.shop || '', staff: me().name, at: Date.now(), img: photo }, { quiet: true }); }
      const ent = { at: Date.now(), k, w, seal: f.seal, shop: f.shop || (k === 'end' ? 'Office' : ''), by: me().name, exp: e2, diff: d, ok: ok && !sealBad, sealBad: sealBad || undefined, photo: phId, ...(pos || {}) };
      const o = { ...p2, log: [...(p2.log || []), ent], seal: (k === 'post' || k === 'check') && f.seal ? f.seal : p2.seal, cur: k === 'pre' ? { shop: f.shop, at: Date.now() } : k === 'post' ? null : p2.cur, updatedAt: Date.now() };
      if (k === 'end') o.status = ok && !sealBad ? 'back' : 'short';
      if (!await save('petis', o)) return;
      if (k === 'end') for (const id of o.boxes) { const b = boxOf(id); if (b) await save('boxes', { ...b, loc: '', updatedAt: Date.now() }, { quiet: true }); }
      closeModal(el);
      if (!ok || sealBad) {
        const prev = (p2.log || []).filter(x => x.w != null).pop(); const pcs = Math.round(Math.abs(d) / 3.8);
        const txt = `PETI ${p2.no} (${p2.team}): ${sealBad ? 'SEAL BADLA (' + p2.seal + ' → ' + f.seal + ') ' : ''}${!ok ? `wazan ${d > 0 ? 'zyada' : 'KAM'} ${Math.abs(d).toFixed(2)} g (≈ ${pcs} ring)` : ''} — ${prev ? (prev.shop || prev.k) + ' ' + tm(prev.at) : ''} aur ${ent.shop || lbl} ${tm(ent.at)} ke beech`;
        alertSrv(txt, 'high'); await SJ_CONFIRM('⚠ ' + txt + '\n\nAb "Box-wise jaanch" se dhoondhiye kis box se gaya.', 'Theek'); boxCheck(pid);
      } else toast(`✓ Peti sahi — ${g2(w)}`);
      renderView(true);
    };
  }
  async function sale(pid) {
    const p = S.petis.find(x => x.id === pid); if (!p) return; const bx = p.boxes.map(boxOf).filter(Boolean);
    const cs = S.customers.slice().sort((a, b) => String(a.name).localeCompare(String(b.name)));
    const el = openModal(`<form novalidate>${mHead('🛍 Dukaan par bikri', esc(p.no) + ((p.cur || {}).shop ? ' · ' + esc(p.cur.shop) : ''))}<div class="m-body">
      <label class="f"><span>Party (dukaandar) <b class="req">*</b></span><input name="party" list="lt-cs" autocomplete="off" placeholder="naam likhiye…"><datalist id="lt-cs">${cs.map(c => `<option value="${esc(c.name)}">`).join('')}</datalist></label>
      <p class="small muted">Har box ke liye: box scan / chuno → dukaandar ke kaante par biki ringein tolo → wazan (ya photo se AI). Ginti apne aap.</p>
      <div data-o="rows">${bx.map(b => `<div class="lt-row" data-b="${esc(b.id)}"><div><b class="mono">${esc(b.no)}</b> ${esc(b.design)}<div class="small muted">abhi ${b.pcs} pcs · ek ${avgOf(b).toFixed(2)} g</div></div><input type="number" step="0.01" inputmode="decimal" placeholder="biki ka wazan g" data-w><input type="number" inputmode="numeric" placeholder="pcs" data-p><button type="button" class="btn sm" data-ph title="Kaante ki photo">📷</button></div>`).join('')}</div>
      <div class="lt-tot" data-o="tot"></div><div class="small" data-o="ai"></div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button type="button" class="btn" data-o="b-est">✓ Pakki — bill (paisa / RTGS)</button><button type="button" class="btn gold" data-o="b-metal">✓ Pakki — bill (fine chandi)</button></div></form>`, { wide: true });
    const photos = {};
    const recalc = () => { let w = 0, n = 0; el.querySelectorAll('.lt-row').forEach(r => { const b = boxOf(r.dataset.b); const wi = q$('[data-w]', r), pi = q$('[data-p]', r); const ww = num(wi.value); if (ww > 0 && !pi.dataset.manual) pi.value = Math.round(ww / avgOf(b)); const pc = num(pi.value); if (ww > 0) { w += ww; n += pc; const back = pc * avgOf(b); r.classList.toggle('bad', Math.abs(back - ww) > Math.max(avgOf(b) * 0.45, 0.6) || pc > b.pcs); } else r.classList.remove('bad'); }); q$('[data-o="tot"]', el).innerHTML = n ? `Kul: <b>${n} pcs · ${g2(w)}</b>` : ''; };
    el.addEventListener('input', e => { if (e.target.dataset && 'p' in e.target.dataset) e.target.dataset.manual = e.target.value ? '1' : ''; recalc(); });
    el.querySelectorAll('[data-ph]').forEach(bt => bt.onclick = async () => { const r = bt.closest('.lt-row'); const img = await pickPhoto(); if (!img) return; photos[r.dataset.b] = img; bt.textContent = '✓📷'; const o = q$('[data-o="ai"]', el); o.textContent = '🤖 AI kaanta padh raha hai…'; try { const a = await aiWeight(img); if (a.grams != null) { q$('[data-w]', r).value = a.grams; recalc(); o.innerHTML = `✓ AI: ${esc(boxOf(r.dataset.b).no)} = <b>${a.grams} g</b>${a.sure ? '' : ' (khud dekh lijiye)'}`; } else o.textContent = 'AI padh nahi paya — wazan khud likhiye'; } catch (e) { o.textContent = e.message; } });
    const done = async type => {
      const pn = (q$('[name="party"]', el).value || '').trim(); const party = S.customers.find(c => String(c.name).toLowerCase() === pn.toLowerCase());
      if (!party) return toast('Party list se chuniye (pehle Customers mein jodiye)', 'err');
      const lines = [...el.querySelectorAll('.lt-row')].map(r => ({ b: boxOf(r.dataset.b), w: r2(num(q$('[data-w]', r).value)), pcs: Math.round(num(q$('[data-p]', r).value)), photo: photos[r.dataset.b] })).filter(x => x.w > 0);
      if (!lines.length) return toast('Kam se kam ek box ka wazan daaliye', 'err');
      if (el.querySelector('.lt-row.bad') && !await SJ_CONFIRM('Laal wale box mein wazan aur ginti mel nahi kha rahe. Ringein dobara gin lijiye. Phir bhi pakka karein?', 'Haan, pakka')) return;
      const pos = await gps(); const p2 = S.petis.find(x => x.id === pid);
      const sid = uid('ls'); const s = { id: sid, at: Date.now(), shop: (p2.cur || {}).shop || party.name, partyId: party.id, partyName: party.name, lines: lines.map(l => ({ boxId: l.b.id, boxNo: l.b.no, design: l.b.design, purity: l.b.purity, pcs: l.pcs, w: l.w })), w: r2(sum(lines, l => l.w)), pcs: sum(lines, l => l.pcs), by: me().name, type, ...(pos || {}) };
      for (const l of lines) if (l.photo) { const id = uid('lph'); await save('fieldPhotos', { id, cid: pid, vid: sid, kind: 'kaanta', party: party.name, staff: me().name, at: Date.now(), img: l.photo }, { quiet: true }); s.lines.find(x => x.boxId === l.b.id).photo = id; }
      if (!await save('petis', { ...p2, sales: [...(p2.sales || []), s], updatedAt: Date.now() })) return;
      for (const l of lines) await save('boxes', { ...l.b, pcs: Math.max(0, l.b.pcs - l.pcs), gross: r3(num(l.b.gross) - l.w), updatedAt: Date.now() }, { quiet: true });
      closeModal(el); toast(`✓ ${s.pcs} pcs · ${g2(s.w)} — boxes se ghata diya`);
      billOpen(pid, sid);
    };
    q$('[data-o="b-est"]', el).onclick = () => done('estimate'); q$('[data-o="b-metal"]', el).onclick = () => done('metal');
  }
  function billOpen(pid, sid) {
    const p = S.petis.find(x => x.id === pid); const s = p && (p.sales || []).find(x => x.id === sid); if (!s) return;
    if (typeof openInvoice !== 'function') return;
    document.querySelectorAll('#modal-root .overlay').forEach(o => o.remove());
    openInvoice(s.type === 'metal' ? 'metal' : 'estimate', { preset: { partyId: s.partyId, notes: `Peti ${p.no} · ${s.shop} · ${s.pcs} pcs` } });
    if (typeof INV === 'undefined' || !INV) return;
    INV.items = s.lines.map(l => { const b = boxOf(l.boxId) || {}; return newItem({ category: l.design + ' ring', purity: l.purity || 'Silver 80', pcs: l.pcs, gross: l.w, less: 0, labour: b.labour || '', addToVault: false }); });
    INV.lotSale = { pid, sid };
    try { renderItems(); refreshTotals(); } catch (e) { console.error(e); }
    toast('Bill mein rate / tunch dekh kar Save kijiye — dukaandar fine chandi ya RTGS jo de');
  }
  async function boxCheck(pid) {
    const p = S.petis.find(x => x.id === pid); if (!p) return;
    const el = openModal(`${mHead('🔍 Box-wise jaanch', esc(p.no) + ' — har box kaante par rakho')}<div class="m-body">
      ${p.boxes.map(boxOf).filter(Boolean).map(b => `<div class="lt-row" data-b="${esc(b.id)}"><div><b class="mono">${esc(b.no)}</b> ${esc(b.design)}<div class="small muted">hona chahiye <b>${g2(b.gross)}</b> · ${b.pcs} pcs</div></div><input type="number" step="0.01" inputmode="decimal" placeholder="mila (g)" data-w><span class="lt-res" data-r></span><button type="button" class="btn sm" data-ai title="AI se khaane gino">🤖</button></div>`).join('')}
      <div class="small" data-o="ai"></div></div><div class="m-foot"><button type="button" class="btn" data-act="close">Band karo</button><button type="button" class="btn gold" data-o="sv">Save jaanch</button></div>`, { wide: true });
    el.addEventListener('input', e => { const r = e.target.closest('.lt-row'); if (!r) return; const b = boxOf(r.dataset.b); const w = num(q$('[data-w]', r).value); const out = q$('[data-r]', r); if (!w) { out.textContent = ''; return; } const d = r2(w - num(b.gross)); out.innerHTML = Math.abs(d) <= Math.max(0.3, tol() / 3) ? '<b class="green">✓</b>' : `<b class="red">${d} g ≈ ${Math.round(Math.abs(d) / avgOf(b))} ring</b>`; });
    el.querySelectorAll('[data-ai]').forEach(bt => bt.onclick = async () => { const r = bt.closest('.lt-row'); const b = boxOf(r.dataset.b); const img = await pickPhoto(); if (!img) return; const o = q$('[data-o="ai"]', el); o.textContent = '🤖 AI khaane gin raha hai…'; try { const a = await aiSlots(img); const ok = num(a.filled) === b.pcs; o.innerHTML = `${esc(b.no)}: AI ne <b>${a.filled}</b> bhare, ${a.empty} khaali gine · software mein ${b.pcs} — ${ok ? '<b class="green">✓ mel</b>' : `<b class="red">fark ${num(a.filled) - b.pcs}</b>`}${a.sure ? '' : ' (AI pakka nahi — khud gin lijiye)'}`; if (!ok && a.sure) alertSrv(`Box ${b.no} (${p.no}, ${p.team}): AI ne ${a.filled} ring gini, hona chahiye ${b.pcs}`, 'medium'); } catch (e) { o.textContent = e.message; } });
    q$('[data-o="sv"]', el).onclick = async () => {
      const res = [...el.querySelectorAll('.lt-row')].map(r => { const b = boxOf(r.dataset.b); const w = num(q$('[data-w]', r).value); return w ? { boxId: b.id, boxNo: b.no, w: r2(w), exp: num(b.gross), d: r2(w - num(b.gross)) } : null; }).filter(Boolean);
      if (!res.length) return closeModal(el);
      const bad = res.filter(x => Math.abs(x.d) > Math.max(0.3, tol() / 3)); const p2 = S.petis.find(x => x.id === pid);
      await save('petis', { ...p2, checks: [...(p2.checks || []), { at: Date.now(), by: me().name, res }], updatedAt: Date.now() });
      if (bad.length) alertSrv(`Box jaanch ${p2.no} (${p2.team}): ${bad.map(x => `${x.boxNo} ${x.d} g`).join(', ')}`, 'high');
      closeModal(el); toast(bad.length ? `⚠ ${bad.length} box mein fark — alert gaya` : '✓ Saare box sahi'); renderView(true);
    };
  }
  function petiCard(p) {
    const e = expW(p), l = lastW(p), bad = (p.log || []).filter(x => x.ok === false);
    const steps = (p.log || []).map(x => `<div class="lt-lg ${x.ok === false ? 'bad' : ''}"><span>${tm(x.at)}</span><b>${esc({ start: 'Office se nikli', pre: 'Dukaan se pehle', post: 'Dukaan ke baad', end: 'Wapas office', check: 'Jaanch' }[x.k] || x.k)}</b><span>${esc(x.shop || '')}</span><span>${g2(x.w)}${x.exp != null && x.k !== 'start' ? ` <small>(hona ${g2(x.exp)})</small>` : ''}</span><span>${x.ok === false ? `<b class="red">${x.sealBad ? 'seal ' : ''}${x.diff ? x.diff + ' g' : ''}</b>` : '✓'}</span>${x.lat ? `<a class="small" href="https://maps.google.com/?q=${x.lat},${x.lon}" target="_blank" rel="noopener">📍</a>` : '<span></span>'}</div>`).join('');
    const sales = (p.sales || []).map(s => `<div class="lt-lg"><span>${tm(s.at)}</span><b>🛍 ${esc(s.partyName)}</b><span>${s.lines.map(x => `${esc(x.boxNo)}: ${x.pcs}`).join(', ')}</span><span>${s.pcs} pcs · ${g2(s.w)}</span><span><button type="button" class="btn sm" data-act="lt-bill" data-p="${esc(p.id)}" data-s="${esc(s.id)}">Bill</button></span><span></span></div>`).join('');
    return `<div class="card lt-peti ${bad.length ? 'bad' : ''}"><div class="card-h"><h3>🧳 ${esc(p.no)} · ${esc(p.team || '')}</h3><span class="pill ${p.status === 'out' ? 'sky' : p.status === 'short' ? 'red' : 'green'}">${p.status === 'out' ? 'field mein' : p.status === 'short' ? 'kami' : 'wapas'}</span></div>
      <div class="lt-top"><div><span>Box</span><b>${p.boxes.length}</b></div><div><span>Seal</span><b class="mono">${esc(p.seal || '')}</b></div><div><span>Abhi hona chahiye</span><b>${e == null ? '—' : g2(e)}</b></div><div><span>Aaj bika</span><b>${sum(p.sales || [], s => s.pcs)} pcs · ${g2(sum(p.sales || [], s => s.w))}</b></div>${p.cur ? `<div><span>Abhi dukaan</span><b>${esc(p.cur.shop)}</b></div>` : ''}</div>
      ${p.status === 'out' ? `<div class="btns">${!p.cur ? `<button type="button" class="btn gold" data-act="lt-w" data-p="${esc(p.id)}" data-k="pre">⚖ Dukaan se pehle tolo</button>` : `<button type="button" class="btn gold" data-act="lt-sale" data-p="${esc(p.id)}">🛍 Bikri</button><button type="button" class="btn gold" data-act="lt-w" data-p="${esc(p.id)}" data-k="post">⚖ Dukaan ke baad tolo</button>`}<button type="button" class="btn" data-act="lt-chk" data-p="${esc(p.id)}">🔍 Box-wise jaanch</button>${boss() ? `<button type="button" class="btn" data-act="lt-w" data-p="${esc(p.id)}" data-k="end">🏠 Shaam — wapas</button>` : ''}</div>` : ''}
      <details ${bad.length || p.status === 'out' ? 'open' : ''}><summary class="small">Poora record (${(p.log || []).length} tol · ${(p.sales || []).length} bikri)</summary><div class="lt-log">${steps}${sales}</div></details></div>`;
  }
  function petiBody() {
    const out = S.petis.filter(p => p.status === 'out'), mine = myPetis(), today = S.petis.filter(p => p.date === todayStr() && p.status !== 'out');
    const show = boss() ? out : mine;
    return `<div class="toolbar">${boss() ? '<button type="button" class="btn gold" data-act="lt-peti-new">🧳 Naya peti do</button>' : ''}</div>
      ${show.length ? show.map(petiCard).join('') : emptyBox(boss() ? 'Abhi koi peti field mein nahi.' : 'Aapke naam koi peti nahi.')}
      ${boss() && today.length ? `<h3 class="gd-h">Aaj wapas aayi</h3>${today.map(petiCard).join('')}` : ''}
      <p class="small muted">Niyam: har dukaan se pehle aur baad gaadi ke kaante par peti tolo · biki ringein dukaandar ke kaante par · fark ${tol()} g se zyada = alert. Kaante ki photo par AI wazan padhta hai.</p>`;
  }

  /* ================= COUNTER TRAY ================= */
  const trayItems = t => (t.items || []).map(id => S.products.find(p => p.id === id)).filter(p => p && p.status === 'In Stock');
  const trayExp = t => { const L = trayItems(t); return { pcs: L.length + sum((t.boxes || []).map(boxOf).filter(Boolean), b => b.pcs), w: r2(sum(L, p => p.gross) + sum((t.boxes || []).map(boxOf).filter(Boolean), b => b.gross)) }; };
  const tlog = t => S.trayLogs.find(x => x.id === t.id + '_' + todayStr());
  async function trayNew(id) {
    const t = id ? S.trays.find(x => x.id === id) : { id: uid('tr'), no: nextNo('trays', 'T'), name: '', items: [], boxes: [] };
    const el = openModal(`<form novalidate>${mHead(id ? 'Tray ' + esc(t.no) : '🗂 Nayi tray', 'Piece scan karke tray mein jodiye')}<div class="m-body"><div class="fg">${fld('Tray no.', 'no', t.no, { req: 1 })}${fld('Naam', 'name', t.name, { ph: 'Counter 1 · Chain' })}</div>
      <label class="f"><span>Piece scan (SKU / tag) — Enter</span><input data-o="q" autocomplete="off" placeholder="scan…"></label><div class="small" data-o="list"></div>
      <h4 class="gd-h">Chandi ke box (optional)</h4><div class="lt-pick">${S.boxes.filter(b => !b.loc).map(b => `<label class="chk"><input type="checkbox" data-bx="${esc(b.id)}" ${(t.boxes || []).includes(b.id) ? 'checked' : ''}> ${esc(b.no)} ${esc(b.design)}</label>`).join('') || '<span class="small muted">—</span>'}</div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save</button></div></form>`, { wide: true });
    const items = new Set(t.items || []); const paint = () => { const L = [...items].map(i => S.products.find(p => p.id === i)).filter(Boolean); q$('[data-o="list"]', el).innerHTML = `${L.length} piece · ${g2(sum(L, p => p.gross))} — ${L.slice(-8).map(p => esc(p.sku)).join(', ')}`; }; paint();
    q$('[data-o="q"]', el).addEventListener('keydown', e => { if (e.key !== 'Enter') return; e.preventDefault(); const v = e.target.value.trim(); e.target.value = ''; const p = window.SJ_SCAN ? SJ_SCAN.find(v) : S.products.find(x => x.sku === v); if (!p) return toast('Ye piece nahi mila', 'err'); items.add(p.id); paint(); });
    q$('form', el).onsubmit = async ev => { ev.preventDefault(); const f = formObj(ev.target); const o = { ...t, no: f.no, name: f.name, items: [...items], boxes: [...el.querySelectorAll('[data-bx]:checked')].map(i => i.dataset.bx), updatedAt: Date.now() }; if (await save('trays', o)) { closeModal(el); toast('✓ Tray save'); renderView(true); } };
  }
  async function trayCount(id, k) {
    const t = S.trays.find(x => x.id === id); const e = trayExp(t);
    const el = openModal(`<form novalidate>${mHead(k === 'open' ? '🌅 Subah — tray kholo' : k === 'close' ? '🌙 Shaam — tray band' : '🤝 Tray haath badlo', esc(t.no) + ' ' + esc(t.name || ''))}<div class="m-body">
      <p class="small muted" style="margin-top:0">Pehle khud gin kar aur tol kar likhiye — software ka hisaab Save ke baad dikhega.</p>
      <div class="fg">${fld('Ginti (pcs)', 'pcs', '', { type: 'number', req: 1 })}${fld('Kul wazan (g)', 'w', '', { type: 'number', req: 1 })}${k === 'hand' ? fld('Kise de rahe (naam)', 'to', '', { req: 1 }) : ''}<label class="f"><span>Aapka PIN</span><input name="pin" type="password" inputmode="numeric" maxlength="8"></label></div></div>
      <div class="m-foot"><button type="button" class="btn" data-act="close">Cancel</button><button class="btn gold">Save</button></div></form>`, { small: true });
    q$('form', el).onsubmit = async ev => {
      ev.preventDefault(); const f = formObj(ev.target);
      if (SITE) { try { await API('pin_check', { pin: f.pin }); } catch (er) { return toast(er.message || 'PIN galat', 'err'); } }
      const dp = Math.round(num(f.pcs) - e.pcs), dw = r2(num(f.w) - e.w), ok = dp === 0 && Math.abs(dw) <= tol();
      const L = tlog(t) || { id: t.id + '_' + todayStr(), trayId: t.id, date: todayStr(), hand: [] };
      const ent = { at: Date.now(), by: me().name, pcs: Math.round(num(f.pcs)), w: r2(num(f.w)), exp: e, dp, dw, ok };
      const o = { ...L, ...(k === 'open' ? { open: ent } : k === 'close' ? { close: ent } : { hand: [...(L.hand || []), { ...ent, to: f.to }] }), updatedAt: Date.now() };
      if (!await save('trayLogs', o)) return; closeModal(el);
      if (!ok) { const txt = `Tray ${t.no} ${t.name || ''} (${k === 'open' ? 'subah' : k === 'close' ? 'shaam' : 'haath badalna'}): ${dp ? `ginti ${dp > 0 ? '+' : ''}${dp}` : ''} ${Math.abs(dw) > tol() ? `wazan ${dw} g` : ''} — ${me().name}`; alertSrv(txt, 'high'); await SJ_CONFIRM('⚠ ' + txt + `\nSoftware: ${e.pcs} pcs · ${g2(e.w)}`, 'Theek'); }
      else toast(`✓ Tray sahi — ${e.pcs} pcs · ${g2(e.w)}`);
      renderView(true);
    };
  }
  function trayBody() {
    const L = S.trays.slice().sort((a, b) => String(a.no).localeCompare(String(b.no), 'en', { numeric: true }));
    return `<div class="toolbar">${boss() ? '<button type="button" class="btn gold" data-act="lt-tray-new">🗂 Nayi tray</button>' : ''}</div>
      ${L.length ? `<div class="lt-trays">${L.map(t => { const e = trayExp(t), lg = tlog(t) || {}; const st = (x, l) => x ? `<span class="${x.ok ? 'green' : 'red'}">${l} ${tm(x.at)} ${x.ok ? '✓' : '✗ ' + (x.dp ? 'ginti ' + x.dp : '') + (Math.abs(x.dw) > tol() ? ' ' + x.dw + ' g' : '')}</span>` : `<span class="muted">${l} baaki</span>`;
        return `<div class="card lt-tray ${(lg.open && !lg.open.ok) || (lg.close && !lg.close.ok) ? 'bad' : ''}"><div class="card-h"><h3>🗂 ${esc(t.no)} ${esc(t.name || '')}</h3>${boss() ? `<button type="button" class="btn sm" data-act="lt-tray-edit" data-id="${esc(t.id)}">Badlo</button>` : ''}</div><div class="small">Software: <b>${e.pcs} pcs · ${g2(e.w)}</b></div><div class="small lt-ts">${st(lg.open, 'Subah')} · ${st(lg.close, 'Shaam')}${(lg.hand || []).length ? ` · ${lg.hand.length} baar haath badla` : ''}</div>
          <div class="btns"><button type="button" class="btn sm ${lg.open ? '' : 'gold'}" data-act="lt-tc" data-id="${esc(t.id)}" data-k="open">🌅 Subah</button><button type="button" class="btn sm" data-act="lt-tc" data-id="${esc(t.id)}" data-k="hand">🤝 Haath badlo</button><button type="button" class="btn sm ${lg.open && !lg.close ? 'gold' : ''}" data-act="lt-tc" data-id="${esc(t.id)}" data-k="close">🌙 Shaam</button></div></div>`; }).join('')}</div>` : emptyBox('Counter ki tray banaiye — har tray mein piece scan karke jodiye.')}
      <p class="small muted">Subah tray tijori se nikalte waqt aur shaam wapas rakhte waqt gin kar tolo. Bika hua maal software apne aap ghata deta hai. Fark par Owner ko alert.</p>`;
  }

  /* ================= VIEW ================= */
  Object.assign(ICON, { lotbox: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M3 11h18M9 7V4h6v3"/>' });
  if (!VIEWS.some(v => v[0] === 'lot')) { const i = VIEWS.findIndex(v => v[0] === 'field'); VIEWS.splice(i < 0 ? VIEWS.length : i + 1, 0, ['lot', 'Chandi box', 'lotbox', '🧳 Chandi box · Peti · Tray']); }
  const TABS = [['peti', '🧳 Peti (field)'], ['box', '📦 Box'], ['tray', '🗂 Counter tray']];
  VIEWDEF.lot = {
    shell: () => { const t = ui.ltTab || 'peti'; return `<div class="rep-tabs">${TABS.map(([k, l]) => `<button type="button" data-act="seg" data-k="ltTab" data-v="${k}" class="${t === k ? 'on' : ''}">${l}</button>`).join('')}</div><div id="vbody"></div>`; },
    body() { const t = ui.ltTab || 'peti'; try { return ({ peti: petiBody, box: boxBody, tray: trayBody }[t] || petiBody)(); } catch (e) { console.error(e); return emptyBox('Nahi khula: ' + esc(e.message)); } }
  };
  const ACT = {
    'lt-box-new': () => boxForm(), 'lt-box-edit': t => boxForm(t.dataset.id),
    'lt-peti-new': () => petiNew(), 'lt-w': t => weigh(t.dataset.p, t.dataset.k), 'lt-sale': t => sale(t.dataset.p), 'lt-chk': t => boxCheck(t.dataset.p), 'lt-bill': t => billOpen(t.dataset.p, t.dataset.s),
    'lt-tray-new': () => trayNew(), 'lt-tray-edit': t => trayNew(t.dataset.id), 'lt-tc': t => trayCount(t.dataset.id, t.dataset.k)
  };
  document.addEventListener('click', e => { const t = e.target.closest && e.target.closest('[data-act^="lt-"]'); if (!t || !ACT[t.dataset.act]) return; e.preventDefault(); e.stopPropagation(); ACT[t.dataset.act](t); }, true);

  if (typeof agentTools === 'function') {
    const T0 = agentTools;
    agentTools = function () {
      const L = T0.apply(this, arguments);
      if (!L.some(x => x.name === 'silver_peti')) L.push({ name: 'silver_peti', description: 'Chandi box / peti: field mein kaunsi peti, kis team ke paas, abhi kitna wazan hona chahiye, aaj ki bikri, kahin wazan kam (gadbad); counter tray ka subah/shaam hisaab.', inputSchema: { type: 'object', properties: {} }, execute: async () => ({ petis: S.petis.filter(p => p.status === 'out' || p.date === todayStr()).map(p => ({ no: p.no, team: p.team, status: p.status, boxes: p.boxes.length, expected_g: expW(p), soldPcs: sum(p.sales || [], s => s.pcs), sold_g: r2(sum(p.sales || [], s => s.w)), problems: (p.log || []).filter(x => x.ok === false).map(x => ({ at: new Date(x.at).toLocaleTimeString('en-IN'), shop: x.shop, diff_g: x.diff, seal: !!x.sealBad })) })), boxes: S.boxes.length, trays: S.trays.map(t => { const l = tlog(t) || {}; return { tray: t.no, open: l.open ? l.open.ok : null, close: l.close ? l.close.ok : null }; }), screen: 'Chandi box (🧳)' }) });
      return L;
    };
  }
  window.SJ_LOT = { expW, boxOf, avgOf, aiWeight, aiSlots };

  const st = document.createElement('style');
  st.textContent = `.lt-pick{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,260px),1fr));gap:4px 12px;max-height:240px;overflow:auto;margin-bottom:10px}
    .lt-row{display:grid;grid-template-columns:minmax(0,1fr) 120px 80px auto;gap:8px;align-items:center;border:1px solid var(--line);border-radius:12px;padding:8px 10px;margin-bottom:6px}.lt-row.bad{border-color:#ef4444;background:rgba(239,68,68,.06)}.lt-row input{min-width:0}
    @media(max-width:560px){.lt-row{grid-template-columns:1fr 1fr}.lt-row>div:first-child{grid-column:1/-1}}
    .lt-tot{font-size:15px;margin:8px 0}.lt-exp{font-size:16px;margin-bottom:10px}.lt-res{font-size:12.5px}
    .lt-top{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin-bottom:10px}.lt-top div{border:1px solid var(--line);border-radius:12px;padding:8px 10px;display:flex;flex-direction:column}.lt-top span{font-size:11.5px;color:var(--muted)}.lt-top b{font-size:15px}
    .lt-peti.bad,.lt-tray.bad{border-color:rgba(239,68,68,.6)}
    .lt-log{display:flex;flex-direction:column;gap:4px;margin-top:6px}.lt-lg{display:grid;grid-template-columns:62px minmax(0,1.2fr) minmax(0,1fr) minmax(0,1.2fr) auto 22px;gap:8px;align-items:center;font-size:12.5px;border-bottom:1px dashed var(--line);padding:4px 0}.lt-lg.bad{background:rgba(239,68,68,.07)}.lt-lg small{color:var(--muted)}
    @media(max-width:620px){.lt-lg{grid-template-columns:52px 1fr 1fr}}
    .lt-trays{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));gap:12px}.lt-trays .card{margin:0}.lt-ts{margin:6px 0}`;
  document.head.appendChild(st);
})();
