<?php
/* =====================================================================
   Shivaa Jewels — v42 server part (loaded by sj-api.php after sj-sec.php)
   • Telegram bot: free alerts on the owner's phone + encrypted backup copy
   • Kanoon: Sec 269ST (₹2 lakh+ cash) and Rule 114B (PAN) — checked on the server
   • CA / auditor login with an end date (view only)
   • Emergency access: a trusted person gets the shop after a waiting time
   • Software ki sehat: daily health check, restore test, error log
   • Tijori: opens only with two PINs, every opening logged
   • Field: offline manzoori codes (hidden from staff), dukaandar ka code,
     staff ek jagah zyada der ruke / location band → alert
   ===================================================================== */
if (!defined('SJ')) { http_response_code(403); exit; }

function sj_now_ms() { return (int)round(microtime(true) * 1000); }
function sj_ist_day() { return gmdate('Y-m-d', time() + 19800); }
function sj_jmeta($k) { $j = json_decode((string)sj_meta_get($k), true); return is_array($j) ? $j : []; }
function sj_jmeta_put($k, $j) { sj_meta_set($k, json_encode($j, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)); }
function sj_secret_get($k) { $v = sj_meta_get($k); if (!$v) return ''; try { return (string)sj_dec($v, 'meta', $k); } catch (Exception $e) { return ''; } }
function sj_secret_put($k, $v) { if ($v === '') { sj_db()->prepare('DELETE FROM sj_meta WHERE k = ?')->execute([$k]); return; } sj_meta_set($k, sj_enc($v, 'meta', $k)); }

/* ================= TELEGRAM ================= */
function sj_tg_cfg() { $c = sj_jmeta('tg'); return $c + ['chat' => '', 'level' => 'high', 'backup' => 'week', 'health' => true, 'on' => false]; }
function sj_tg_url($tok, $method) { return rtrim(sj_cfg('tg_url', 'https://api.telegram.org'), '/') . '/bot' . $tok . '/' . $method; }
function sj_tg_call($tok, $method, $fields = null, $timeout = 20) {
    if ($tok === '') return ['ok' => false, 'description' => 'no token'];
    $url = sj_tg_url($tok, $method);
    if (function_exists('curl_init')) {
        $ch = curl_init($url); $o = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 10];
        if ($fields !== null) { $o[CURLOPT_POST] = true; $o[CURLOPT_POSTFIELDS] = $fields; }
        if (defined('CURLOPT_IPRESOLVE')) $o[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V4;
        curl_setopt_array($ch, $o); $r = curl_exec($ch); curl_close($ch);
    } else {
        $ctx = stream_context_create(['http' => ['method' => $fields === null ? 'GET' : 'POST', 'header' => 'Content-Type: application/x-www-form-urlencoded', 'content' => $fields === null ? '' : http_build_query($fields), 'timeout' => $timeout, 'ignore_errors' => true]]);
        $r = @file_get_contents($url, false, $ctx);
    }
    $j = is_string($r) ? json_decode($r, true) : null;
    return is_array($j) ? $j : ['ok' => false, 'description' => 'Telegram se jawab nahi aaya (internet / curl).'];
}
function sj_tg_send($text, $force = false) {
    $c = sj_tg_cfg(); if ((!$c['on'] && !$force) || $c['chat'] === '') return false;
    $tok = sj_secret_get('tg_tok'); if ($tok === '') return false;
    $day = sj_ist_day(); $cnt = sj_jmeta('tg_count'); if (!isset($cnt['d']) || $cnt['d'] !== $day) $cnt = ['d' => $day, 'n' => 0];
    if ($cnt['n'] >= 300 && !$force) return false; $cnt['n']++; sj_jmeta_put('tg_count', $cnt);
    $r = sj_tg_call($tok, 'sendMessage', ['chat_id' => $c['chat'], 'text' => mb_substr($text, 0, 3900), 'disable_web_page_preview' => 'true']);
    return !empty($r['ok']);
}
/* called for every new alert (batch, security, portal) */
function sj_tg_alerts($alerts) {
    $c = sj_tg_cfg(); if (!$c['on'] || $c['chat'] === '') return;
    $set = sj_load_doc('settings', 'main'); $firm = is_array($set) && !empty($set['firm']) ? $set['firm'] : 'Shivaa Jewels';
    $pick = []; foreach ($alerts as $a) { $lv = isset($a['level']) ? $a['level'] : 'medium'; if ($c['level'] === 'all' || $lv === 'high' || (isset($a['kind']) && in_array($a['kind'], ['panic', 'portal_req', 'emergency', 'tijori'], true))) $pick[] = $a; }
    if (!$pick) return;
    $L = []; foreach (array_slice($pick, 0, 8) as $a) $L[] = ((isset($a['level']) && $a['level'] === 'high') ? '🔴 ' : '🟡 ') . (!empty($a['night']) ? '[RAAT] ' : '') . $a['text'] . "\n   — " . (isset($a['by']) ? $a['by'] : '') . ', ' . gmdate('d-m h:i A', (int)((isset($a['at']) ? $a['at'] : sj_now_ms()) / 1000) + 19800);
    if (count($pick) > 8) $L[] = '…aur ' . (count($pick) - 8) . ' alert — software mein dekhiye.';
    try { sj_tg_send('🚨 ' . $firm . "\n\n" . implode("\n\n", $L)); } catch (Exception $e) { /* best effort */ }
}
/* encrypted backup for Telegram: SJBK1 | salt16 | iv12 | tag16 | data  (AES-256-GCM, key = PBKDF2-SHA256(password, salt, 150000)) */
function sj_bk_seal($plain, $pass) {
    $salt = random_bytes(16); $iv = random_bytes(12); $key = hash_pbkdf2('sha256', $pass, $salt, 150000, 32, true); $tag = '';
    $ct = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
    if ($ct === false) throw new Exception('encrypt failed');
    return 'SJBK1' . $salt . $iv . $tag . $ct;
}
function sj_tg_backup($force = false) {
    $c = sj_tg_cfg(); if ($c['chat'] === '' || (!$c['on'] && !$force)) return 'tg_off';
    if (!$force && $c['backup'] === 'off') return 'off';
    $pass = sj_secret_get('bk_pass'); if ($pass === '') return 'no_password';
    $last = (int)sj_meta_get('tg_bk_at'); $gap = $c['backup'] === 'day' ? 0.9 * 86400 : 6.5 * 86400;
    if (!$force && time() - $last < $gap) return 'not_due';
    $L = sj_bk_list(); if (!$L) { sj_auto_backup(true); $L = sj_bk_list(); } if (!$L) return 'no_backup';
    $json = sj_bk_export($L[0]['name'], true); $gz = function_exists('gzencode') ? gzencode($json, 9) : $json;
    $blob = sj_bk_seal($gz, $pass); if (strlen($blob) > 45 * 1024 * 1024) return 'too_big';
    $tok = sj_secret_get('tg_tok'); if ($tok === '') return 'tg_off';
    $tmp = sj_bk_dir() . '/tg-' . bin2hex(random_bytes(6)) . '.sjbk'; file_put_contents($tmp, $blob);
    $fn = 'shivaa-backup-' . $L[0]['date'] . '.sjbk';
    $ok = false;
    if (function_exists('curl_init') && class_exists('CURLFile')) {
        $r = sj_tg_call($tok, 'sendDocument', ['chat_id' => $c['chat'], 'caption' => '🗄 Shivaa Jewels backup ' . $L[0]['date'] . " (taala band)\nKholne ke liye: Setup → Software ki sehat → \"Telegram backup kholo\" + backup password.", 'document' => new CURLFile($tmp, 'application/octet-stream', $fn)], 120);
        $ok = !empty($r['ok']);
    }
    @unlink($tmp);
    if ($ok) sj_meta_set('tg_bk_at', (string)time());
    sj_jmeta_put('tg_bk_last', ['at' => time(), 'ok' => $ok, 'date' => $L[0]['date'], 'size' => strlen($blob)]);
    return $ok ? 'sent' : 'failed';
}

/* ================= KANOON: 269ST + 114B ================= */
function sj_cash_days($v) {
    $m = []; $d0 = isset($v['date']) ? (string)$v['date'] : '';
    if (isset($v['payments']) && is_array($v['payments'])) { foreach ($v['payments'] as $p) if (is_array($p) && strtolower((string)(isset($p['mode']) ? $p['mode'] : '')) === 'cash') { $d = !empty($p['date']) ? (string)$p['date'] : $d0; $m[$d] = (isset($m[$d]) ? $m[$d] : 0) + (float)(isset($p['amount']) ? $p['amount'] : 0); } }
    elseif (isset($v['totals']['received']) && strtolower((string)(isset($v['payMode']) ? $v['payMode'] : '')) === 'cash') $m[$d0] = (float)$v['totals']['received'];
    return $m;
}
function sj_has_pan($v) {
    $rxp = '/^[A-Z]{5}[0-9]{4}[A-Z]$/'; $rxg = '/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/';
    if (preg_match($rxp, strtoupper((string)(isset($v['partyPan']) ? $v['partyPan'] : ''))) || preg_match($rxg, strtoupper((string)(isset($v['partyGstin']) ? $v['partyGstin'] : '')))) return true;
    if (!empty($v['form60'])) return true;
    $pid = isset($v['partyId']) ? (string)$v['partyId'] : ''; if ($pid === '' || !sj_valid_id($pid)) return false;
    $c = sj_load_doc('customers', $pid); if (!is_array($c)) return false;
    return !empty($c['form60']) || preg_match($rxp, strtoupper((string)(isset($c['pan']) ? $c['pan'] : ''))) || preg_match($rxg, strtoupper((string)(isset($c['gstin']) ? $c['gstin'] : '')));
}
function sj_law_check($u, $i, $new) {
    $t = isset($new['type']) ? $new['type'] : ''; if (!in_array($t, ['sale', 'estimate', 'metal'], true)) return null;
    if (!empty($new['deleted'])) return null;
    $p = sj_pol(); $old = sj_load_doc('invoices', $i);
    if ($p['cash269']) {
        $nc = sj_cash_days($new); $oc = is_array($old) ? sj_cash_days($old) : [];
        if (array_sum($nc) > array_sum($oc) + 0.5) {
            if (array_sum($nc) >= 200000) return '#law:269ST: is bill par kul cash ' . sj_inr(array_sum($nc)) . ' ho raha hai. ₹2 lakh ya usse zyada cash lena mana hai (penalty = utni hi rakam). Baaki paisa UPI / bank / cheque se lijiye.';
            $pid = isset($new['partyId']) ? (string)$new['partyId'] : '';
            foreach ($nc as $d => $amt) {
                if ($amt <= (isset($oc[$d]) ? $oc[$d] : 0) + 0.5 || $pid === '' || $amt < 1) continue;
                $other = 0;
                foreach (sj_all_docs('invoices') as $x) { if (!is_array($x) || (isset($x['id']) && $x['id'] === $i) || (isset($x['partyId']) ? $x['partyId'] : '') !== $pid || !in_array(isset($x['type']) ? $x['type'] : '', ['sale', 'estimate', 'metal'], true)) continue; $cd = sj_cash_days($x); if (isset($cd[$d])) $other += $cd[$d]; }
                if ($amt + $other >= 200000) return '#law:269ST: ' . (isset($new['partyName']) ? $new['partyName'] : 'is party') . ' se ' . $d . ' ko kul cash ' . sj_inr($amt + $other) . ' ho raha hai (doosre bill milakar). Ek din mein ek vyakti se ₹2 lakh ya zyada cash mana hai — baaki UPI / bank se lijiye.';
            }
        }
    }
    if ($p['panRule'] && in_array($t, ['sale', 'estimate'], true) && sj_doc_payable($new) >= 200000 && !sj_has_pan($new)) {
        if (!is_array($old) || abs(sj_doc_payable($old) - sj_doc_payable($new)) > 1 || sj_has_pan($old)) return '#law_pan:Rule 114B: ' . sj_inr(sj_doc_payable($new)) . ' ke bill par grahak ka PAN (ya Form 60) zaroori hai.';
    }
    return null;
}

/* ================= LOGIN END DATE (CA / auditor) + EMERGENCY ================= */
function sj_login_expired($uid) { if ($uid === SJ_OWNER_ID) return false; $x = sj_uext($uid); return !empty($x['until']) && (string)$x['until'] < sj_ist_day(); }
function sj_emerg() { return sj_jmeta('emerg') + ['uid' => '', 'hours' => 48, 'req' => null]; }
function sj_emerg_owner_seen() {   // the owner is active → any pending request is cancelled
    $e = sj_emerg(); if (empty($e['req']) || !empty($e['req']['done'])) return;
    $e['req'] = null; sj_jmeta_put('emerg', $e);
    sj_sec_alert('emergency', 'Emergency access ki request RADD — Owner khud active hain', 'high');
}

/* ================= SEHAT: health, restore test, error log ================= */
function sj_restore_test() {
    $L = sj_bk_list(); $r = ['at' => time(), 'ok' => false, 'rows' => 0, 'file' => '', 'msg' => ''];
    if (!$L) { $r['msg'] = 'Koi backup file nahi'; sj_jmeta_put('restore_last', $r); return $r; }
    $f = sj_bk_dir() . '/' . $L[0]['name']; $r['file'] = $L[0]['name'];
    $raw = substr($f, -3) === '.gz' ? @gzdecode((string)@file_get_contents($f)) : @file_get_contents($f);
    $j = is_string($raw) ? json_decode($raw, true) : null;
    if (!is_array($j) || !isset($j['rows']) || !is_array($j['rows'])) { $r['msg'] = 'Backup file kharab hai — khul nahi rahi'; sj_jmeta_put('restore_last', $r); return $r; }
    $n = count($j['rows']); $bad = 0; $step = max(1, (int)floor($n / 300));
    for ($k = 0; $k < $n; $k += $step) { $row = $j['rows'][$k]; try { $d = sj_dec($row[2], $row[0], $row[1]); if (json_decode($d, true) === null) $bad++; } catch (Exception $e) { $bad++; } }
    $live = (int)sj_db()->query('SELECT COUNT(*) FROM sj_docs WHERE deleted = 0 AND data IS NOT NULL')->fetchColumn();
    $r['rows'] = $n; $r['live'] = $live;
    if ($bad) $r['msg'] = $bad . ' record padhe nahi gaye';
    elseif ($live > 50 && $n < $live * 0.7) $r['msg'] = 'Backup mein record kam hain (' . $n . ' / ' . $live . ')';
    else { $r['ok'] = true; $r['msg'] = 'Backup sahi khula — ' . $n . ' record'; }
    sj_jmeta_put('restore_last', $r); return $r;
}
function sj_health() {
    $c = []; $now = time(); $add = function ($k, $ok, $txt, $fix = '') use (&$c) { $c[] = ['k' => $k, 'ok' => $ok, 'txt' => $txt, 'fix' => $fix]; };
    $L = sj_bk_list(); $bd = $L ? $L[0]['date'] : '';
    $add('backup', $bd !== '' && $bd >= gmdate('Y-m-d', $now + 19800 - 86400 * 2), $bd ? 'Aakhri backup: ' . $bd : 'Abhi tak koi backup nahi', 'Cron lagaiye ya Setup → Backup → "Abhi backup lo"');
    $cl = (int)sj_meta_get('cron_last'); $add('cron', $cl > $now - 26 * 3600, $cl ? 'Cron aakhri baar: ' . gmdate('d-m h:i A', $cl + 19800) : 'Cron abhi tak nahi chala', 'Setup → 🛡 Suraksha → 🔑 Keys ka command Hostinger Cron Jobs mein daaliye');
    $rt = sj_jmeta('restore_last'); $add('restore', !empty($rt['ok']) && (int)$rt['at'] > $now - 40 * 86400, !empty($rt['at']) ? 'Restore test: ' . $rt['msg'] . ' (' . gmdate('d-m-Y', (int)$rt['at'] + 19800) . ')' : 'Restore test abhi tak nahi hua', '"Restore test chalao" dabaiye (cron har mahine apne aap karta hai)');
    $ch = sj_jmeta('chain_last'); $add('chain', !empty($ch['at']) ? !empty($ch['ok']) : true, !empty($ch['at']) ? ('Record ki kadi: ' . (!empty($ch['ok']) ? 'sahi' : 'GADBAD') . ' (' . gmdate('d-m-Y', (int)$ch['at'] + 19800) . ')') : 'Record ki kadi: hafte mein ek baar cron jaanchta hai', 'Setup → 🛡 Suraksha → "Record jaancho"');
    $free = @disk_free_space(__DIR__ . '/sj-data'); $add('disk', $free === false || $free > 300 * 1024 * 1024, $free === false ? 'Disk: pata nahi' : 'Disk khaali: ' . round($free / 1048576) . ' MB', 'Hostinger mein purani files hataiye');
    $el = sj_jmeta('errlog'); $n24 = 0; foreach ($el as $e) if ((int)$e['at'] > ($now - 86400) * 1000) $n24++;
    $add('errors', $n24 < 20, 'Pichhle 24 ghante mein app ki galtiyan: ' . $n24, '"Galti ka record" dekhiye aur report bhejiye');
    $tg = sj_tg_cfg(); $add('telegram', $tg['on'] && $tg['chat'] !== '', $tg['on'] && $tg['chat'] !== '' ? 'Telegram alert chalu' : 'Telegram alert band', 'Setup → Software ki sehat → Telegram jodo');
    $add('owner2fa', sj_utotp_on(SJ_OWNER_ID), sj_utotp_on(SJ_OWNER_ID) ? 'Owner ka 2-step login chalu' : 'Owner ka 2-step login band', 'Setup → 2-step login');
    $add('pin', !!sj_pol()['pin'], sj_pol()['pin'] ? 'Delete se pehle PIN: chalu' : 'Delete se pehle PIN: band', 'Setup → 🛡 Suraksha → niyam');
    $add('https', sj_https() || sj_local(), sj_https() ? 'HTTPS chalu' : (sj_local() ? 'Apne computer par test (HTTPS ki zaroorat nahi)' : 'HTTPS nahi'), 'Hostinger mein SSL on kijiye');
    return $c;
}
function sj_health_cron() {
    if (!sj_once_today('health')) return;
    $bad = []; foreach (sj_health() as $h) if (!$h['ok'] && in_array($h['k'], ['backup', 'restore', 'chain', 'disk', 'errors'], true)) $bad[] = '• ' . $h['txt'] . ' → ' . $h['fix'];
    sj_jmeta_put('health_last', ['at' => time(), 'bad' => count($bad)]);
    if ($bad) sj_sec_alert('health', 'Software ki SEHAT mein dikkat: ' . implode(' ', $bad), 'medium');
    elseif (sj_tg_cfg()['health']) sj_tg_send('✅ Software ki sehat theek — backup, record aur restore test sab sahi (' . sj_ist_day() . ')');
}
function sj_err_add($u, $b) {
    $el = sj_jmeta('errlog'); $now = sj_now_ms();
    $mine = 0; foreach ($el as $e) if ($e['uid'] === $u['id'] && $e['at'] > $now - 3600000) $mine++; if ($mine >= 30) return false;
    $msg = substr(trim((string)(isset($b['msg']) ? $b['msg'] : '')), 0, 400); if ($msg === '') return false;
    $sig = substr(hash('sha256', $msg . '|' . (isset($b['src']) ? $b['src'] : '')), 0, 12);
    foreach ($el as &$e) if ($e['sig'] === $sig && $e['uid'] === $u['id'] && $e['at'] > $now - 600000) { $e['n'] = (int)$e['n'] + 1; $e['at'] = $now; sj_jmeta_put('errlog', $el); return true; } unset($e);
    $el[] = ['sig' => $sig, 'at' => $now, 'n' => 1, 'uid' => $u['id'], 'user' => $u['name'], 'msg' => $msg, 'src' => substr((string)(isset($b['src']) ? $b['src'] : ''), 0, 160), 'view' => substr((string)(isset($b['view']) ? $b['view'] : ''), 0, 40), 'ver' => substr((string)(isset($b['ver']) ? $b['ver'] : ''), 0, 10), 'ua' => substr((string)(isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : ''), 0, 120)];
    if (count($el) > 150) $el = array_slice($el, -150);
    sj_jmeta_put('errlog', $el); return true;
}

/* ================= FIELD: codes, stay / no-location ================= */
function sj_conf_code($vid) { $h = hash_hmac('sha256', 'ccode|' . $vid, sj_key() ?: 'sj'); $a = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; $o = ''; for ($k = 0; $k < 8; $k++) $o .= $a[hexdec(substr($h, $k * 2, 2)) % strlen($a)]; return $o; }
function sj_conf_hash($code, $vid) { return bin2hex(hash_pbkdf2('sha256', strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code)), 'sjfc|' . $vid, 10000, 32, true)); }
function sj_gps_watch($dev, $lat, $lon, $at) {
    if (strpos($dev, 'u:') !== 0) return; $uid = substr($dev, 2);
    $st = sj_jmeta('gps_stay'); $s = isset($st[$dev]) ? $st[$dev] : null;
    $dist = function ($a1, $o1, $a2, $o2) { $R = 6371000; $t = M_PI / 180; $dl = ($a2 - $a1) * $t; $dn = ($o2 - $o1) * $t; $h = sin($dl / 2) ** 2 + cos($a1 * $t) * cos($a2 * $t) * sin($dn / 2) ** 2; return 2 * $R * asin(min(1, sqrt($h))); };
    if (!$s || $dist($s['lat'], $s['lon'], $lat, $lon) > 150) { $st[$dev] = ['lat' => $lat, 'lon' => $lon, 'since' => $at, 'al' => 0]; sj_jmeta_put('gps_stay', $st); return; }
    $mins = ($at - (int)$s['since']) / 60000; $lim = max(10, (float)sj_pol()['stayMin']);
    if ($mins < $lim || !empty($s['al'])) return;
    $ch = null; foreach (sj_all_docs('challans') as $c) if (is_array($c) && (isset($c['status']) ? $c['status'] : '') === 'out' && ((isset($c['staffUid']) && $c['staffUid'] === $uid) || (isset($c['staff2Uid']) && $c['staff2Uid'] === $uid))) { $ch = $c; break; }
    $st[$dev]['al'] = 1; sj_jmeta_put('gps_stay', $st);
    if (!$ch) return;
    foreach (isset($ch['route']) && is_array($ch['route']) ? $ch['route'] : [] as $r) { $p = !empty($r['partyId']) && sj_valid_id((string)$r['partyId']) ? sj_load_doc('customers', (string)$r['partyId']) : null; if (is_array($p) && isset($p['geo']['lat']) && $dist((float)$p['geo']['lat'], (float)$p['geo']['lon'], $lat, $lon) < 400) return; }
    sj_sec_alert('field_stay', 'Staff ' . (isset($ch['staff']) ? $ch['staff'] : '') . ' (challan ' . (isset($ch['no']) ? $ch['no'] : '') . ') ' . (int)$mins . ' minute se EK JAGAH ruka hai — ye kisi route ki dukaan par nahi · https://maps.google.com/?q=' . round($lat, 5) . ',' . round($lon, 5), 'medium');
}
function sj_noloc_cron() {
    $h = (int)gmdate('G', time() + 19800); if ($h < 9 || $h >= 21) return;
    $last = sj_jmeta('gps_last'); $devs = sj_gps_devs(); $lim = max(15, (float)sj_pol()['noLocMin']) * 60000; $now = sj_now_ms();
    foreach (sj_all_docs('challans') as $c) {
        if (!is_array($c) || (isset($c['status']) ? $c['status'] : '') !== 'out') continue;
        $best = 0; foreach (['staffUid', 'staff2Uid'] as $k) if (!empty($c[$k]) && isset($last['u:' . $c[$k]])) $best = max($best, (int)$last['u:' . $c[$k]]['at']);
        foreach ($devs as $id => $d) if (!empty($d['staff']) && isset($c['staff']) && strcasecmp(trim($d['staff']), trim($c['staff'])) === 0 && isset($last['d:' . $id])) $best = max($best, (int)$last['d:' . $id]['at']);
        $since = !empty($c['acceptedAt']) ? (int)$c['acceptedAt'] : (!empty($c['updatedAt']) ? (int)$c['updatedAt'] : $now);
        if ($now - max($best, $since) > $lim && sj_once_today('noloc:' . (isset($c['id']) ? $c['id'] : '') . ':' . (int)floor($now / 10800000)))
            sj_sec_alert('field_noloc', 'Staff ' . (isset($c['staff']) ? $c['staff'] : '') . ' (challan ' . (isset($c['no']) ? $c['no'] : '') . ') ki LOCATION ' . ($best ? round(($now - $best) / 60000) . ' minute se nahi aayi' : 'aaj aayi hi nahi') . ' — phone band / location off?', 'high');
    }
}

/* ================= CRON part (called from sj_cron) ================= */
function sj_v42_cron(&$out) {
    try { sj_noloc_cron(); $out[] = 'noloc'; } catch (Exception $e) { $out[] = 'noloc-fail'; }
    $rt = sj_jmeta('restore_last'); if (empty($rt['at']) || (int)$rt['at'] < time() - 30 * 86400) { try { sj_restore_test(); $out[] = 'restore-test'; } catch (Exception $e) { $out[] = 'restore-fail'; } }
    $ch = sj_jmeta('chain_last'); if ((empty($ch['at']) || (int)$ch['at'] < time() - 7 * 86400) && (int)gmdate('G', time() + 19800) < 6) { try { $r = sj_chain_verify(); sj_jmeta_put('chain_last', ['at' => time(), 'ok' => !empty($r['ok'])]); if (empty($r['ok'])) sj_sec_alert('chain', 'Record ki KADI TOOTI — kisi ne database seedhe badla ho sakta hai. Setup → 🛡 Suraksha → "Record jaancho".', 'high'); $out[] = 'chain'; } catch (Exception $e) { $out[] = 'chain-fail'; } }
    if ((int)gmdate('G', time() + 19800) >= 21) { try { $out[] = 'tg-bk:' . sj_tg_backup(false); } catch (Exception $e) { $out[] = 'tg-bk-fail'; } try { sj_health_cron(); $out[] = 'health'; } catch (Exception $e) { $out[] = 'health-fail'; } }
    $e = sj_emerg(); if (!empty($e['req']) && empty($e['req']['done']) && empty($e['req']['ready']) && time() >= (int)$e['req']['at'] + (int)$e['hours'] * 3600) { $e['req']['ready'] = time(); sj_jmeta_put('emerg', $e); sj_sec_alert('emergency', 'Emergency access ka intezaar POORA — ' . (isset($e['req']['name']) ? $e['req']['name'] : '') . ' ab Owner ka access le sakte hain', 'high'); }
}

/* ================= v45: staff cannot rewrite box / peti history ================= */
function sj_lot_guard($o, $c, $i, $new) {
    $old = sj_load_doc($c, $i);
    if ($o === 'del') return 'Box / peti / tray sirf Owner / Manager hata sakte hain.';
    if ($c === 'trays') return 'Tray sirf Owner / Manager banate hain.';
    if ($old === null) return $c === 'boxes' ? 'Naya box sirf Owner / Manager banate hain.' : 'Peti sirf Owner / Manager dete hain.';
    if (!is_array($new)) return null;
    if ($c === 'boxes') {
        foreach ($new as $k => $v) if (!in_array($k, ['pcs', 'gross', 'loc', 'updatedAt'], true) && json_encode(isset($old[$k]) ? $old[$k] : null) !== json_encode($v)) return 'Box ki jaankari sirf Manager badal sakta hai.';
        if ((float)(isset($new['pcs']) ? $new['pcs'] : 0) > (float)(isset($old['pcs']) ? $old['pcs'] : 0) || (float)(isset($new['gross']) ? $new['gross'] : 0) > (float)(isset($old['gross']) ? $old['gross'] : 0) + 0.001) return 'Box mein ginti / wazan sirf Manager badha sakta hai.';
        if (isset($new['loc']) && (string)$new['loc'] !== (string)(isset($old['loc']) ? $old['loc'] : '')) return 'Box ki jagah sirf Manager badalta hai.';
        return null;
    }
    foreach (['boxes', 'staffUids', 'tare', 'no', 'date'] as $k) if (json_encode(isset($old[$k]) ? $old[$k] : null) !== json_encode(isset($new[$k]) ? $new[$k] : null)) return 'Peti ki ye jaankari sirf Manager badal sakta hai.';
    foreach (['log', 'sales', 'checks'] as $k) { $a = isset($old[$k]) && is_array($old[$k]) ? $old[$k] : []; $b = isset($new[$k]) && is_array($new[$k]) ? $new[$k] : [];
        if (count($b) < count($a) || json_encode($a) !== json_encode(array_slice($b, 0, count($a)))) return 'Peti ka purana record badla / mitaya nahi ja sakta.'; }
    if (isset($new['status']) && $new['status'] !== (isset($old['status']) ? $old['status'] : '') ) return 'Peti wapas sirf Manager leta hai.';
    return null;
}

/* ================= routes ================= */
function sj_v42_route($a) {
    switch ($a) {
    /* ---- Telegram ---- */
    case 'tg_status': { sj_require_role(['owner']); $c = sj_tg_cfg(); $t = sj_secret_get('tg_tok'); sj_out(['ok' => true, 'cfg' => $c, 'token' => $t !== '' ? '…' . substr($t, -4) : '', 'bkpass' => sj_secret_get('bk_pass') !== '', 'lastBk' => sj_jmeta('tg_bk_last'), 'curl' => function_exists('curl_init')]); }
    case 'tg_cfg': {
        sj_require_role(['owner']); $b = sj_body(); $c = sj_tg_cfg();
        if (isset($b['token'])) { $t = trim((string)$b['token']);
            if ($t !== '') { if (!preg_match('/^\d{5,12}:[A-Za-z0-9_-]{30,60}$/', $t)) sj_fail('bad_token', 400, 'Token galat lag raha hai — BotFather ka poora token copy kijiye (jaise 123456789:AA…).');
                $r = sj_tg_call($t, 'getMe'); if (empty($r['ok'])) sj_fail('tg_fail', 400, 'Telegram ne token nahi maana: ' . (isset($r['description']) ? $r['description'] : '')); $c['bot'] = isset($r['result']['username']) ? $r['result']['username'] : ''; }
            sj_secret_put('tg_tok', $t); if ($t === '') { $c['on'] = false; $c['chat'] = ''; } }
        if (isset($b['level']) && in_array($b['level'], ['high', 'all'], true)) $c['level'] = $b['level'];
        if (isset($b['backup']) && in_array($b['backup'], ['off', 'day', 'week'], true)) $c['backup'] = $b['backup'];
        foreach (['on', 'health'] as $k) if (isset($b[$k])) $c[$k] = !!$b[$k];
        if (isset($b['bkpass'])) { $p = (string)$b['bkpass']; if ($p !== '' && strlen($p) < 8) sj_fail('weak', 400, 'Backup password kam se kam 8 akshar ka rakhiye.'); sj_secret_put('bk_pass', $p); }
        if ($c['on'] && $c['chat'] === '') $c['on'] = false;
        sj_jmeta_put('tg', $c); sj_out(['ok' => true, 'cfg' => $c]);
    }
    case 'tg_find': {   // the owner sent "/start" to the bot → pick that chat
        sj_require_role(['owner']); $t = sj_secret_get('tg_tok'); if ($t === '') sj_fail('no_token', 400, 'Pehle bot ka token daaliye.');
        $r = sj_tg_call($t, 'getUpdates'); $chat = null;
        foreach (isset($r['result']) && is_array($r['result']) ? array_reverse($r['result']) : [] as $up) { $m = isset($up['message']) ? $up['message'] : (isset($up['my_chat_member']) ? $up['my_chat_member'] : null); if (isset($m['chat']['id'])) { $chat = $m['chat']; break; } }
        if (!$chat) sj_fail('no_chat', 404, 'Bot ko abhi koi message nahi mila. Telegram mein apne bot ko kholkar "Start" dabaiye (ya "hi" likhiye), phir yahan dobara dabaiye.');
        $c = sj_tg_cfg(); $c['chat'] = (string)$chat['id']; $c['chatName'] = trim((isset($chat['first_name']) ? $chat['first_name'] : '') . ' ' . (isset($chat['last_name']) ? $chat['last_name'] : '') . (isset($chat['title']) ? $chat['title'] : '')); $c['on'] = true;
        sj_jmeta_put('tg', $c); sj_tg_send('✅ Shivaa Jewels software jud gaya. Ab zaroori alert yahan aayenge.', true);
        sj_out(['ok' => true, 'cfg' => $c]);
    }
    case 'tg_test': { sj_require_role(['owner']); $ok = sj_tg_send('🔔 Test alert — Telegram chalu hai ✓ (' . gmdate('d-m h:i A', time() + 19800) . ')', true); if (!$ok) sj_fail('tg_fail', 502, 'Message nahi gaya — token / chat dobara jodiye, ya hosting par curl chalu kijiye.'); sj_out(['ok' => true]); }
    case 'tg_backup_now': { sj_require_role(['owner']); @set_time_limit(180); $r = sj_tg_backup(true); $msg = ['sent' => 'Backup Telegram par chala gaya ✓', 'no_password' => 'Pehle backup password rakhiye.', 'tg_off' => 'Pehle Telegram jodiye.', 'no_backup' => 'Backup nahi bana.', 'too_big' => 'Backup 45 MB se bada hai — Telegram par nahi jayega.', 'failed' => 'Telegram par nahi gaya — internet / curl dekhiye.']; if ($r !== 'sent') sj_fail('tg_bk', 400, isset($msg[$r]) ? $msg[$r] : $r); sj_out(['ok' => true, 'msg' => $msg[$r]]); }

    /* ---- health / errors / restore ---- */
    case 'health': { sj_require_role(['owner', 'manager']); sj_out(['ok' => true, 'checks' => sj_health(), 'restore' => sj_jmeta('restore_last'), 'last' => sj_jmeta('health_last')]); }
    case 'restore_test': { sj_require_role(['owner']); @set_time_limit(120); sj_out(['ok' => true, 'result' => sj_restore_test()]); }
    case 'err_log': { $u = sj_require_user(); sj_out(['ok' => sj_err_add($u, sj_body())]); }
    case 'err_list': { sj_require_role(['owner', 'manager']); sj_out(['ok' => true, 'list' => array_reverse(sj_jmeta('errlog'))]); }
    case 'err_clear': { sj_require_role(['owner']); sj_jmeta_put('errlog', []); sj_out(['ok' => true]); }

    /* ---- CA / auditor login end date ---- */
    case 'login_until': {
        sj_require_role(['owner']); $b = sj_body(); $id = sj_str($b, 'id', 32);
        $st = sj_db()->prepare('SELECT id, role FROM sj_users WHERE id = ?'); $st->execute([$id]); $r = $st->fetch(); if (!$r) sj_fail('not_found', 404, 'Login nahi mila.');
        if ($id === SJ_OWNER_ID) sj_fail('invalid_argument', 400, 'Owner ke login par end date nahi lagti.');
        $d = sj_str($b, 'until', 10); if ($d !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) sj_fail('invalid_argument', 400, 'Tareekh galat.');
        $x = sj_uext($id); if ($d === '') unset($x['until']); else $x['until'] = $d; if (isset($b['ca'])) $x['ca'] = !!$b['ca']; sj_uext_put($id, $x);
        if ($d !== '' && $d < sj_ist_day()) sj_db()->prepare('DELETE FROM sj_tokens WHERE uid = ?')->execute([$id]);
        sj_out(['ok' => true]);
    }
    case 'login_untils': { sj_require_role(['owner', 'manager']); $o = []; foreach (sj_db()->query('SELECT id FROM sj_users')->fetchAll() as $r) { $x = sj_uext($r['id']); if (!empty($x['until']) || !empty($x['ca'])) $o[$r['id']] = ['until' => isset($x['until']) ? $x['until'] : '', 'ca' => !empty($x['ca'])]; } sj_out(['ok' => true, 'map' => $o]); }

    /* ---- emergency access ---- */
    case 'emerg_status': {
        $u = sj_require_user(); $e = sj_emerg();
        if ($u['role'] !== 'owner' && $u['id'] !== $e['uid']) sj_out(['ok' => true, 'nominee' => false]);
        $r = $e['req']; $ready = $r && empty($r['done']) && time() >= (int)$r['at'] + (int)$e['hours'] * 3600;
        $nm = ''; if ($e['uid']) { $st = sj_db()->prepare('SELECT name FROM sj_users WHERE id = ?'); $st->execute([$e['uid']]); $nm = (string)$st->fetchColumn(); }
        sj_out(['ok' => true, 'nominee' => $u['id'] === $e['uid'], 'uid' => $u['role'] === 'owner' ? $e['uid'] : '', 'name' => $nm, 'hours' => (int)$e['hours'], 'req' => $r ? ['at' => (int)$r['at'], 'why' => isset($r['why']) ? $r['why'] : '', 'done' => !empty($r['done'])] : null, 'ready' => $ready, 'left' => $r && !$ready ? max(0, (int)$r['at'] + (int)$e['hours'] * 3600 - time()) : 0]);
    }
    case 'emerg_cfg': {
        sj_require_role(['owner']); $b = sj_body(); $e = sj_emerg(); $id = sj_str($b, 'uid', 32);
        if ($id !== '') { $st = sj_db()->prepare('SELECT role, active FROM sj_users WHERE id = ?'); $st->execute([$id]); $r = $st->fetch(); if (!$r || $id === SJ_OWNER_ID) sj_fail('invalid_argument', 400, 'Ye login nahi chun sakte.'); if ($r['role'] === 'viewer') sj_fail('invalid_argument', 400, 'View-only login ko emergency access nahi de sakte.'); }
        $e['uid'] = $id; $e['hours'] = max(24, min(168, (int)(isset($b['hours']) ? $b['hours'] : 48))); $e['req'] = null; sj_jmeta_put('emerg', $e);
        sj_out(['ok' => true]);
    }
    case 'emerg_req': {
        $u = sj_require_user(); $e = sj_emerg(); if ($u['id'] !== $e['uid']) sj_fail('forbidden', 403, 'Aap emergency vyakti nahi hain.');
        if (!empty($e['req']) && empty($e['req']['done'])) sj_fail('exists', 409, 'Request pehle se chal rahi hai.');
        $e['req'] = ['at' => time(), 'name' => $u['name'], 'why' => substr(trim((string)(isset(sj_body()['why']) ? sj_body()['why'] : '')), 0, 200)]; sj_jmeta_put('emerg', $e);
        sj_sec_alert('emergency', '🆘 EMERGENCY ACCESS maanga: ' . $u['name'] . ' — ' . $e['hours'] . ' ghante baad ye Owner ka access le sakenge. Aap theek hain to software kholiye — request apne aap radd ho jayegi. Wajah: ' . $e['req']['why'], 'high', $u);
        sj_out(['ok' => true]);
    }
    case 'emerg_cancel': { $u = sj_require_user(); $e = sj_emerg(); if ($u['role'] !== 'owner' && $u['id'] !== $e['uid']) sj_fail('forbidden', 403); $e['req'] = null; sj_jmeta_put('emerg', $e); sj_out(['ok' => true]); }
    case 'emerg_take': {
        $u = sj_require_user(); $e = sj_emerg(); $b = sj_body();
        if ($u['id'] !== $e['uid'] || empty($e['req']) || !empty($e['req']['done'])) sj_fail('forbidden', 403, 'Emergency request nahi hai.');
        if (time() < (int)$e['req']['at'] + (int)$e['hours'] * 3600) sj_fail('wait', 403, 'Abhi intezaar ka samay baaki hai.');
        $st = sj_db()->prepare('SELECT pass FROM sj_users WHERE id = ?'); $st->execute([$u['id']]);
        if (!password_verify(isset($b['mypass']) ? (string)$b['mypass'] : '', (string)$st->fetchColumn())) sj_fail('wrong_password', 403, 'Aapka apna password galat hai.');
        $np = isset($b['newpass']) ? (string)$b['newpass'] : ''; if (strlen($np) < 8) sj_fail('weak', 400, 'Naya password kam se kam 8 akshar.');
        sj_db()->prepare('UPDATE sj_users SET pass = ?, active = 1 WHERE id = ?')->execute([password_hash($np, PASSWORD_DEFAULT), SJ_OWNER_ID]);
        sj_utotp_put(SJ_OWNER_ID, null); sj_db()->prepare('DELETE FROM sj_tokens WHERE uid = ?')->execute([SJ_OWNER_ID]);
        $e['req']['done'] = time(); sj_jmeta_put('emerg', $e);
        $ou = sj_owner();
        sj_sec_alert('emergency', '🔑 EMERGENCY ACCESS LIYA: ' . $u['name'] . ' ne Owner ka password badla (2-step band). Owner ka username: ' . $ou['uname'], 'high', $u);
        sj_out(['ok' => true, 'owner' => $ou['uname']]);
    }

    /* ---- tijori (2 PIN) ---- */
    case 'tijori_open': {
        $u = sj_require_user(); if ($u['role'] === 'viewer') sj_fail('forbidden_role', 403); $b = sj_body();
        if (sj_throttled('tj:' . $u['uname'])) sj_fail('throttled', 429, 'Bahut baar galat PIN — 15 minute baad.');
        $why = substr(trim((string)(isset($b['why']) ? $b['why'] : '')), 0, 120); $kind = in_array(isset($b['kind']) ? $b['kind'] : '', ['open', 'close'], true) ? $b['kind'] : 'open';
        $who = []; foreach ([['uname', 'pin'], ['uname2', 'pin2']] as $k => $f) {
            if ($k === 1 && $kind === 'close') break;
            $un = strtolower(sj_str($b, $f[0], 40)); $st = sj_db()->prepare('SELECT id, uname, name, role, active FROM sj_users WHERE uname = ?'); $st->execute([$un]); $r = $st->fetch();
            $x = $r ? sj_uext($r['id']) : [];
            if (!$r || !(int)$r['active'] || empty($x['pin']) || !password_verify(preg_replace('/\D/', '', (string)(isset($b[$f[1]]) ? $b[$f[1]] : '')), $x['pin'])) { sj_add_fail('tj:' . $u['uname']); sj_fail('wrong_pin', 403, ($k ? 'Doosre' : 'Pehle') . ' vyakti ka username / PIN galat (PIN Setup → Suraksha mein banta hai).'); }
            if ($kind === 'open' && !in_array($r['role'], ['owner', 'manager'], true) && empty($x['keyholder'])) sj_fail('forbidden', 403, $r['name'] . ' tijori ki chaabi wale nahi hain (Owner: Setup → Suraksha → staff → "Tijori chaabi").');
            $who[] = $r;
        }
        if ($kind === 'open' && $who[0]['id'] === $who[1]['id']) sj_fail('same', 400, 'Do alag log chahiye.');
        $id = 'tj_' . base_convert((string)sj_now_ms(), 10, 36) . '_' . bin2hex(random_bytes(2));
        $doc = ['id' => $id, 'kind' => $kind, 'at' => sj_now_ms(), 'date' => sj_ist_day(), 'by' => array_map(function ($r) { return $r['name']; }, $who), 'why' => $why, 'device' => sj_dev_name(), 'night' => sj_ist_hour() >= 21 || sj_ist_hour() < 8];
        sj_put_docs([['tijoriLog', $id, $doc]], $u['id']);
        sj_sec_alert('tijori', ($kind === 'open' ? '🔐 TIJORI KHULI' : '🔒 Tijori band') . ': ' . implode(' + ', $doc['by']) . ($why !== '' ? ' — ' . $why : '') . ($doc['night'] ? ' [dukaan ke samay ke baahar]' : ''), $doc['night'] ? 'high' : ($kind === 'open' ? 'medium' : 'low'), $u);
        sj_out(['ok' => true, 'log' => $doc]);
    }
    case 'keyholder': { sj_require_role(['owner']); $b = sj_body(); $id = sj_str($b, 'id', 32); $x = sj_uext($id); $x['keyholder'] = !empty($b['on']); sj_uext_put($id, $x); sj_out(['ok' => true]); }

    /* ---- v45: chandi peti / tray alert from the phone ---- */
    case 'lot_alert': { $u = sj_require_user(); if ($u['role'] === 'viewer') sj_fail('forbidden_role', 403); $b = sj_body(); $t = trim(substr((string)(isset($b['text']) ? $b['text'] : ''), 0, 400)); if ($t === '') sj_fail('invalid_argument', 400);
        if (sj_throttled('lot:' . $u['id'])) sj_fail('throttled', 429); sj_add_fail('lot:' . $u['id']);
        sj_sec_alert('lot', $t, in_array(isset($b['level']) ? $b['level'] : '', ['high', 'medium'], true) ? $b['level'] : 'high', $u); sj_out(['ok' => true]); }
    /* ---- field: dukaandar ka code ---- */
    case 'conf_hash': { sj_require_user(); $b = sj_body(); $v = sj_str($b, 'v', 40); if (!preg_match('/^[A-Za-z0-9_-]{4,40}$/', $v)) sj_fail('invalid_argument', 400); sj_out(['ok' => true, 'h' => sj_conf_hash(sj_conf_code($v), $v)]); }
    }
    return false;
}
