Shivaa Bullion — Millisecond Update 2026-09-14

WHAT CHANGED:
 - Rates now poll every 1 second when market is LIVE (was 15 sec) and 5 sec off-hours (was 60 sec)
 - Smooth 60fps interpolation makes ticker LOOK like every millisecond (real MCX tick is 1/sec — exchange limit — we lerp between ticks)
 - Stale check now 3 sec live / 10 sec off-hours (was 20/90)

FILES:
  app.js  -> cms/js/app.js patched (only 2 hunks, nothing else touched)
  README.txt -> this file

WHERE TO UPLOAD (like you did for api.php):
  1) File Manager -> Search -> type app.js -> press Enter -> note the path
     Usually: public_html/cms/js/app.js  OR  public_html/js/app.js
     Wherever you found app.js before, that's the live one.
  2) Backup: right-click app.js -> Download
  3) Upload: Upload button -> pick app.js from this zip -> Overwrite -> Done!

VERIFY:
  Open site -> top ticker shows "MCX LIVE · 1s ago" counting up every second
  Gold/Silver numbers will glide smoothly (not jump every 15 sec)
  Open Rates page -> numbers update every 1 sec, with millisecond-smooth motion.

NOTE: True every-1-millisecond from MCX is impossible (exchange sends 1 tick/sec). We poll 1/sec and animate between ticks — looks like millisecond.
