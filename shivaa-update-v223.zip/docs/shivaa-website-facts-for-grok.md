# shivaa-website-facts-for-grok.md — Shivaa Ecom · product & tech facts

**COUNTDOWN: release 223 pending owner review.** Live: **v205** (WWW +
Netlify). Forward-only rule in force — next release number is **v224**.
Updated 2026-10-15 from `arena/e8a470c6-shivaa-ecom` (branched from
`arena/09f3c79f-shivaa-ecom` at its v220 tip `4a9e239`).

**Loading (v222):** the shop serves **one** stylesheet, `/css/shivaa.css`
(stamped `?v=223`), built from the 57 historical layers by
`tools/build-css-bundle.py` using the cascade order in
`tools/css-bundle-order.txt`. It is **58 render-blocking requests → 1**, and
**268 KB → 168 KB gzipped**. The individual layer files still exist under
`cms/css/` (the QA suites read them, and a rollback restores `index.html`
alone), but nothing on the page links them any more. Scripts are unchanged:
21 local files, all `defer` (plus the Cashfree SDK), with `admin.js`/`qr.js`
fetched on demand and `motion.js`/`aurum.js`/`boost.js` injected after first
paint by `v117.js`.

**Smoothness (v223):** the gold-thread films are **poster-first with deferred
media**. Until v222 each film `<video>` set `preload="auto"` and its `src` at
mount, so a fresh home page pulled **all five films (~4.5 MB)** before the
reader had scrolled anywhere near them, and each kept decoding off-screen
frames while the reader passed. Now a film mounts with **no `src`** and
`preload="none"` — a fresh home page requests **0 video bytes** — one
`IntersectionObserver` with a 1200px margin calls `wake()` on the film actually
on screen (attach the file, then play), pauses-but-keeps the near ones, and
`rest()` releases the buffer of a film left well behind (`wake()` is
idempotent, so scrolling back never re-downloads). A released film is never
mistaken for a broken one (the v211 error handler returns early when there is no
`src`), and `prefers-reduced-motion` visitors never fetch a film at all. The
rest of the smoothness surface was measured and is already clean: **23 of 25
scroll/touch listeners are passive** (the only blocking one is the product
gallery's deliberate horizontal drag), idle DOM is **stable at 1897 nodes**, 264
local asset references hold **no 404**, and product cards already reserve their
space so images cannot shift the layout. JS bundling was considered and
rejected (deferred files already parallelise; `app.js` alone is 760 KB with 308
top-level declarations and two files carry top-level `'use strict'`).
`qa/browser/t-v223-smooth.mjs` (39 assertions) now locks all of this.

## 1 · What the site is

Shivaa Jewels — premium gold & silver jewellery e-commerce, rooted in the
owner's family goldsmith history across **Nagaur → Jayal (Nagaur district) →
Jaipur, Rajasthan**. SPA in `index.html` + `cms/js/app.js` (one IIFE,
`window.Shivaa` facade), PHP API in `api.php`, JSON storage, Cashfree
payments, OTP demo login, service-worker PWA (`sw.js`), Netlify + Apache
`.htaccess` dual hosting. All UI copy English.

## 2 · Pricing (live formula)

`price = metal(weight × rate) + making + stone − discount + GST(3%)` —
outlined in `#pdBreakup` on every product page. Rate cards: 22K anchors to
the 24K spot rate (`22K = round(24K × 0.9167) + 398`), 18K `= 18Kspot +
round(premium × 0.75)`, silver `= spot + 3`, Jaipur premium `+55` on 24K.
`?edit=1` in the owner module opens the manual override ("Boss calculator"),
status chips "Spot mode"/"Override active".

## 3 · Memberships & offers

- **Shivaa Black Card** (v184+) — retail-only, six-month, OTP-verified
  personal membership: **20% off making charges** + lifetime keepsake
  **Prestigious Member Certificate** (name + member id, flip card in account,
  zero invented award copy). Partner-tier pricing is separate.
- **Premium card** (v191) — free home delivery for life, free claim.
- Public offers (v190): `MAKING20` (20% off making) + `FREEDEL` (free home
  delivery). v208 presentation: the making offer is labelled **Shivaa Black
  members only, no coupon code shown** (attached at checkout); FREEDEL keeps
  its code. Backend coupons are unchanged.

## 4 · B2B partners (`#/partners`)

Local jewellers/resellers with GSTIN or Udyam; no fabricated customer lists.
Order desk with live-rate table + lock-in timer (HLR/P3 formats), credit
window, invoice/PDF/WhatsApp (`wa.me/919269520140`), buyback & exchange,
festive gold-scheme ("Goddess Laxmi Sona Scheme" — keeping the original name),
1-gram jewellery, refined gold biscuit/coin/sheet ("Gold Biscuit Deal"). The
biscuit is the site's core symbol — historic gold biscuits in copy are safe.

## 5 · Engineering invariants

- Versions stamped in 4 files per release (index.html, sw.js, app.js, api.php).
- `cms/data/db.json` = synthetic fixture, gitignored, never deployed.
- CSS seals: no `filter` on `.bc-card`; flip card is a `div[role=button]`;
  never transform `.c-slide` boxes or their `img` (Ken Burns); v200 gold
  button gradient stays; `background-clip:text` fails on some mobile
  browsers — solid colours for words that must stay legible (`.gold-txt`
  fixed in v208).
- Phantom class warning: **`.shv-hcc` does not exist** — the campaign banner
  wrapper is `.shv-home-campaign-card`. Any rule targeting `.shv-hcc` is dead.
- 3D seals (v209): `filter` on ANY ancestor of the Black Card (including
  `.bc-card-wrap.is-lit`'s old drop-shadow) flattens `preserve-3d` — the flip
  dies. Lights/glows ride on box-shadow/opacity only. Sticky chrome never uses
  `backdrop-filter` (Windows-Chrome scroll flash). No per-frame scroll writers
  on banners (v208's parallax was removed in v209 for this).
- QA: `qa/preview_shim.py` (port 8090, mirrors api.php shapes incl.
  `offers/banner` since v208), `qa/browser/t7-audit.mjs` (route/button/error
  walk), `qa/browser/t-v206-flip.mjs`, `qa/browser/audit-contrast.mjs`.
  jsdom is installed to `/tmp/node_modules` (reinstall after sandbox resets).
- Zips are repo-root `shivaa-update-vNNN.zip` = the `cms/` tree at zip root
  (minus `data/`), drop-in replace for the domain root. Since v210 the zip
  also carries `images/films/film-*` + `thread-*` (the case/thread media) —
  do not trim them; the owner's "videos not working" was missing files. Owner download link
  form: `https://github.com/theunreal8055-coder/Shivaa.ecom/raw/arena/09f3c79f-shivaa-ecom/shivaa-update-vNNN.zip`.

## 6 · Brand mood

Maroon / cream / gold foil, heavy serifs (no modern sans for display),
ornate frames, film reveal, consistent token palette. "5D" = layered
scroll depth (raised cream cards, inner-layer parallax, metallic sweeps) —
implemented calm and reduced-motion-aware in v208, never gimmicky.
