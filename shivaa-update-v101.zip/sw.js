/* Shivaa service worker — network-first shell cache.
   Never serves stale content while online: the network is always tried
   first and the cache is only a fallback (bad connection / offline).
   GET + same-origin requests only; the API and uploads always go live. */
'use strict';
const SHELL = 'shivaa-shell-v101';
/* v99: bot.css/bot.js dropped from the shell (Saathi removed ahead of Gemini).
   admin.js + qr.js are deliberately NOT precached — they are fetched on demand
   by loadStaffBundle() in app.js, and a shopper should never pay for them. */
const SHELL_FILES = ['/', '/index.html', '/css/fonts.css?v=42', '/css/styles.css?v=99',
  '/css/hallmark.css?v=42', '/css/trust.css?v=42', '/css/finale.css?v=44',
  '/css/motion.css?v=99', '/css/mobile.css?v=99', '/css/aurum.css?v=101',
  '/js/app.js?v=101', '/js/motion.js?v=91', '/js/aurum.js?v=100',
  '/js/hallmark.js?v=101', '/js/trust.js?v=101', '/images/icons/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(SHELL_FILES).catch(() => {})).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== SHELL).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const r = e.request;
  if (r.method !== 'GET' || new URL(r.url).origin !== self.location.origin) return;
  const u = new URL(r.url);
  const offlineApi = u.pathname === '/api/products' || u.pathname === '/api/rates';  // v55: offline catalogue
  if (!offlineApi && (u.pathname.startsWith('/api/') || u.pathname.startsWith('/data/') || u.pathname.startsWith('/uploads/'))) return;
  e.respondWith(
    fetch(r).then((res) => {
      if (res && res.ok) { const c = res.clone(); caches.open(SHELL).then((x) => x.put(r, c)); }
      return res;
    }).catch(() => caches.match(r).then((hit) => hit || (u.pathname.startsWith('/api/') ? Response.error() : caches.match('/index.html'))))
  );
});