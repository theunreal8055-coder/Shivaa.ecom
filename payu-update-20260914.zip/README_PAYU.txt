Shivaa.ecom PayU Update - 2026-09-14
Branch: arena/01a0a030-shivaa-ecom

CONTENTS:
1) payu.gateway.fixed.php  -> ISOLATED drop-in PayU fix (260 lines)
2) PAYU_BUGFIX_REPORT.md   -> Full bug audit + PayU setup
3) cms_api_fixed.php         -> Full patched cms/api.php (optional, 4 hunks only)

METHOD 1 - EASY (Recommended):
  Backup your live cms/api.php, then upload cms_api_fixed.php as cms/api.php
  -> In File Manager: public_html/cms/api.php -> Upload -> Overwrite
  -> No other files needed.

METHOD 2 - ISOLATED (Zero disturbance):
  1) Upload payu.gateway.fixed.php to public_html/cms/
  2) Edit public_html/cms/api.php, after line:
       require_once __DIR__ . '/mail.php';
     Add:
       require_once __DIR__ . '/payu.gateway.fixed.php'; // PayU fix 2026-09-14
  3) Save. Old PayU block is auto-overridden (if !function_exists guards).

VERIFY:
  Admin -> Payments -> Provider=PayU, paste Key/Salt, Env=test/prod, Site Base=https://yourdomain.com -> Save -> Test
  Should say: Credentials accepted by PayU (...) - merchant key recognised.
  Place test order -> Pay with PayU -> test.payu.in -> back to /#/order/ORD...?pu=success

PayU Dashboard -> Both Success URL and Failure URL = https://yourdomain.com/api/pay/payu/return

Fixes:
 B1 Address array bug ($o['address']['phone'] not ->phone)
 B2/B3 Key 4-40 [_-]  Salt [^\s|] 8-128 validation
 B4 Reconcile strict txnid only
 B5 Admin Test probe (No Transaction Found handling)

No other gateways/routes touched. PhonePe/Razorpay remain dormant.
