Shivaa — Connect Live Rates Panel -> Bullion Panel 2026-09-14

WHAT IT DOES:
 - Live rates panel now takes data DIRECTLY from bullion panel's MCX live tick
 - Interface unchanged — only data source connected

HOW TO INSTALL (same as last PayU update):
 1) Download this zip, extract -> cms_api_connected.php
 2) On laptop rename cms_api_connected.php to api.php
 3) File Manager -> public_html -> Upload api.php -> Overwrite Yes (you already did this before at public_html/api.php)

VERIFY:
 Open site -> Bullion panel and Live rates show SAME numbers
