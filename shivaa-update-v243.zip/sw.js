/* Shivaa service worker — network-first shell + bounded media cache.
   Never serves stale code while online: the network is always tried first
   for the shell; images get a capped cache-first store for fast repeat
   visits on slow phones; videos/API/private uploads always go to the network.
   v168: scope caches to Shivaa only, reject stale/HTML media, track background
   writes with waitUntil, and never store private documents or API responses.
   v103: media moved into its own quota-aware cache (the v102 single cache
   grew without limit and would eventually exhaust storage on cheap devices).
   v104: shell/media bumped; a SKIP_WAITING message lets the in-app banner
   activate a freshly downloaded release the moment the shopper approves.
 v113b: the precache list finally matches index.html — it had been pinning
 app.js?v=108 and auth.js?v=107 (v108.js/v109.js are not loaded by the page
 at all) and was missing boost.css/boost.js and the whole v113 layer, so a
 returning phone kept a stale shell on its first paint. The offline fallback
 also stopped answering a missing IMAGE with index.html.
 v115: shell bumped again for the categories-back release (app.js?v=115 +
 the v115 css layer). index.html now also stamps window.__SHIVAA_REL, and
 app.js reloads itself once if the paired script is older than the shell it
 was served — a device can no longer run a fresh shell on a stale script.
 v166 · ALWAYS THE LATEST: every asset URL was re-stamped to ?v=<REL>. The
 untouched files had been left at their old numbers (styles.css was still
 ?v=107) while .htaccess serves any ?v= URL as immutable for a YEAR — so a
 device that visited weeks ago kept the old design and the old scripts, which
 is the owner's "people still see the 15-day-old version". New stamps are URLs
 no device has ever cached. This worker also announces its release to every
 open tab on activate (SHV_RELEASE) and honours a page asking it to drop every
 cache before re-entering on the newest release (SHV_PURGE).
 v177: shell re-stamped for the v176-defect rework (scope-honest purge
 preview, crash-proof stats, ledger-true day book). No new assets, no media
 change — the MEDIA generation below deliberately stays at its own number.
 v178: shell re-stamped for the in-footer app band — the PWA install
 nudge (no store, no APK): new assets css/v178.css + js/v178.js, pre-cached.
 The band itself is plain footer HTML; this worker only keeps it fresh.
 The MEDIA generation below stays put.
 v179: bullion rates — the permanent fix. No new shell assets (the relay
 runs on its own host, not the site); the api changes are: the
 MCX-over-spot premium is now auto-learned while both feeds are live, and
 when MCX is down the site prices from spot × that premium (honest
 'mcx-est' label) instead of raw spot; last-good MCX persists; /api/rates
 carries a `health` object; relay pull health lands in a throttled side
 file.
 v183: the Play Store release. No new shell assets and no route a shopper can
 see — the two new surfaces are /api/auth/delete-account (the in-app account
 erasure Google Play now insists on) and the static /.well-known/assetlinks.json
 that proves shivaa.in belongs to the Shivaa Jewels app. The web manifest gained
 a stable "id", so the installed PWA and the Play app are one identity instead
 of two. MEDIA stays at v168.
 v184: one private, temporary page — #/amrita, a thank-you for one guest.
 It is dark by default and renders only while the owner's amritaPage switch is
 on, so it is precached as a shell asset but no shopper can reach it until he
 says yes (and the server refuses to mint its coupon once the switch is off).
 It adds one stylesheet, /css/v184.css. The money change that matters is on the
 server: a coupon may now declare scope 'making', so "20% off making charges"
 finally means the making charges and not the metal — see coupon_scope() in
 api.php. MEDIA stays at v168. v187: Amrita ji's private thank-you page (#/amrita) is restored onto the v187 line,
with its money fix (coupon scope 'making') and kill switch intact. The page's
styles are in /css/v184-amrita.css (precached); the visual polish is in
/css/v187.css (precached, loads last). Copy, flow and every money path are unchanged
by the polish. MEDIA stays at v168.
*/
'use strict';
/* v243 · "the header bar is not a drawer" — shell re-stamped for js/v243.js.
   No route, no price, no money path, no css layer. */
/* v242 · "responsive" — shell re-stamped for js/v242.js (tap rescue, ?tapdiag=1)
   and for the cheap media trim above. No route, no price, no money path. */
/* v241 · "smooth" — shell re-stamped for js/v241.js (card pictures from
   /images/thumbs, the mobile-blur layer inside shivaa.css, ?perf=1). The media
   cache keeps more entries because thumbnails are small: same megabytes, far
   more of the shop stays warm on a cheap phone. No route, no price, no money
   path changed. */
const SHELL = 'shivaa-shell-v243';
/* v166 — the release this worker belongs to. It is announced to every open tab
   the moment the new worker activates, so a page that is running an older
   release can move itself to the newest one (js/v166.js, "always the latest").
   Keep in lockstep with window.__SHIVAA_REL and APP_REL. */
const REL = 243;
/* v120 — MEDIA generation bump: purges pre-v113 poisoned entries (category faces
   that 404'd into the SPA fallback were cached AS images for 30 days) and any
   other stale art. Old caches auto-delete on activate; phones re-fetch once. */
const MEDIA = 'shivaa-media-v168';
const ownedCache = name => /^shivaa-(?:shell|media)-v/.test(name);
const MEDIA_MAX = 160;         // v241 — ~160 small pictures: the 320/560 px
                               // thumbnails are 6–35 KB, so the same handful of
                               // megabytes now covers the home page, the shop grid
                               // and the product a shopper returns to.
const MEDIA_TTL = 1000 * 60 * 60 * 24 * 30;   // 30 days; v168 also checks before returning a cache hit
/* v99: bot.css/bot.js dropped from the shell (Saathi removed ahead of Gemini).
   admin.js + qr.js are deliberately NOT precached — they are fetched on demand
   by loadStaffBundle() in app.js, and a shopper should never pay for them. */
/* v107 — the list matches index.html exactly.
   v116 — categories fix, carousel fix, quick view fix, payment fix layer added.
   v117 — the "butter" release: the base64 webfont stylesheet (354 KB) became
   3 real woff2 files (all precached below); the route-scoped and JS-gated
   stylesheets still cache here even though index.html now loads them with
   the non-blocking preload-swap pattern; aurum/motion/boost.js stay
   precached too — v117.js injects them post-paint, and a warm precache makes
   that injection instant and offline-safe. */
const SHELL_FILES = [
  '/css/shivaa.css?v=243', '/',
  '/index.html',
  '/js/otp-autofill.js?v=243', '/js/app.js?v=243', '/js/hallmark.js?v=243',
  '/js/trust.js?v=243', '/js/auth.js?v=243', '/js/v219.js?v=243', '/js/motion.js?v=243',
  '/js/aurum.js?v=243', '/js/v107.js?v=243', '/js/boost.js?v=243',
  '/js/v116.js?v=243', '/js/v117.js?v=243', '/js/v118.js?v=243', '/js/v119.js?v=243', '/js/v120.js?v=243', '/js/v122.js?v=243', '/js/v125.js?v=243', '/js/v127.js?v=243', '/js/v139.js?v=243', '/js/v140.js?v=243', '/js/v166.js?v=243', '/js/v167.js?v=243',
  '/js/v178.js?v=243', '/js/v194.js?v=243', '/js/v225.js?v=243', '/js/v226.js?v=243', '/js/v227.js?v=243', '/js/v237.js?v=243', '/js/v238.js?v=243', '/js/v239.js?v=243', '/js/v240.js?v=243', '/js/v241.js?v=243', '/js/v242.js?v=243', '/js/v243.js?v=243', '/fonts/jost.woff2?v=243', '/fonts/cormorant-garamond.woff2?v=243', '/fonts/marcellus-400.woff2?v=243',
  '/desk.html', '/desk.webmanifest', '/js/v234.js?v=243',
  '/manifest.webmanifest', '/offline.html',
  '/images/icons/icon-192.png', '/images/icons/icon-512.png',
  '/images/icons/icon-maskable-512.png', '/images/icons/apple-touch-icon.png'];

self.addEventListener('message', (e) => {
  // v107 — accept both the legacy string and the {type} object form
  if (e.data === 'SKIP_WAITING' || (e.data && e.data.type === 'SKIP_WAITING')) self.skipWaiting();
  /* v166 — the page may ask this worker to drop every byte it holds before it
     re-enters the site on a newer release ("always the latest"). Deleting
     caches is safe at any time: the shell is network-first, so the next fetch
     simply goes to the server. */
  if (e.data && e.data.type === 'SHV_PURGE') {
    e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter(ownedCache).map((k) => caches.delete(k))))
      .then(() => { if (e.source && e.source.postMessage) e.source.postMessage({ type: 'SHV_PURGED', rel: REL }); })
      .catch(() => {}));
  }
  if (e.data && e.data.type === 'SHV_WHOAMI') {
    const reply = (e.source && e.source.postMessage) ? e.source.postMessage.bind(e.source) : null;
    if (reply) reply({ type: 'SHV_RELEASE', rel: REL, shell: SHELL });
  }
});
self.addEventListener('install', (e) => {
  /* v107 — per-file precache. addAll() is all-or-nothing: one 404 in the list
     (which is exactly what the missing icon was) zeroed the WHOLE shell cache
     and .catch(()=>{}) hid it. Now each file is fetched and stored on its own;
     a single failure degrades to network-first for that one file. */
  e.waitUntil(caches.open(SHELL).then((c) => Promise.allSettled(SHELL_FILES.map((u) =>
    fetch(u, { cache: 'reload', credentials: 'same-origin' })
      .then((r) => { if (r && r.ok) return c.put(u, r); })
      .catch(() => {})
  ))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  /* v242 — one age sweep per activation, in the background, instead of 160 cache
     reads after every picture (see trimMedia). */
  e.waitUntil(trimMedia().catch(() => {}));
  e.waitUntil(caches.keys().then((ks) => Promise.all(
    ks.filter((k) => ownedCache(k) && k !== SHELL && k !== MEDIA).map((k) => caches.delete(k))
  )).then(() => self.clients.claim()).then(() => {
    /* v166 — announce the new release to every open tab. A page that is still
       running an older release can then move itself to this one instead of
       waiting for the shopper to notice (js/v166.js handles the message). */
    return self.clients.matchAll({ includeUncontrolled: true, type: 'window' }).then((cs) => {
      cs.forEach((c) => { try { c.postMessage({ type: 'SHV_RELEASE', rel: REL, shell: SHELL }); } catch (_) {} });
    });
  }));
});

/* Cap the media cache: drop the oldest entries past MEDIA_MAX, and (v167)
   expire anything past MEDIA_TTL. MEDIA_TTL was declared in the v120 layer and
   read nowhere, so a photo replaced at the same URL kept its old bytes on every
   phone that had already seen it — the cache was trimmed for COUNT, never for
   AGE. Prefer the local insertion timestamp, falling back to the HTTP Date
   only for older entries; revalidated HTTP bodies may retain an old Date. */
/* v242 — trimMedia() used to run BOTH passes on every single image write:
   `c.match()` for every cached entry, i.e. up to 160 CacheStorage reads after
   each of ~100 pictures on the home page. On a phone that is thousands of disk
   reads during the first scroll while the page is trying to feel smooth — and
   it is a big part of why v241 scrolled nicely and then ignored taps. Now:
     · the COUNT trim stays per write, but it is pure deletions of the oldest
       keys, no reads;
     · the AGE sweep (the expensive one) runs at most once an hour, and once on
       activation. Nothing is lost: an entry past MEDIA_TTL is also caught by
       freshMedia() at read time, which already deletes and re-fetches it. */
const TRIM_AGE_EVERY = 1000 * 60 * 60;
let _lastAgeSweep = 0;
async function trimMedia() {
  try {
    const c = await caches.open(MEDIA);
    const keys = await c.keys();
    for (let i = 0; i < Math.max(0, keys.length - MEDIA_MAX); i++) await c.delete(keys[i]);
    if (Date.now() - _lastAgeSweep < TRIM_AGE_EVERY) return;
    _lastAgeSweep = Date.now();
    const cutoff = Date.now() - MEDIA_TTL;
    for (const k of keys) {
      try {
        const res = await c.match(k);
        const stamp = res && (res.headers.get('x-shivaa-cached-at') || res.headers.get('date'));
        const t = stamp ? Date.parse(stamp) : NaN;
        if (isFinite(t) && t < cutoff) await c.delete(k);
      } catch (_) { /* a cache read problem must never break a page */ }
    }
  } catch (_) {}
}
function isImage(u) {
  return /\.(?:png|jpe?g|webp|gif|svg|avif|ico)(?:\?|$)/i.test(u.pathname);
}

/* v168 — CacheStorage is optional. Only public, known assets belong in it;
   payment pages, API answers, KYC and proof uploads never do. */
const shellURLs = new Set(SHELL_FILES);
function freshMedia(res) {
  if (!res || !/^image\//i.test(res.headers.get('content-type') || '')) return false;
  const stamp = res.headers.get('x-shivaa-cached-at') || res.headers.get('date');
  const at = stamp ? Date.parse(stamp) : NaN;
  return Number.isFinite(at) && Date.now() - at < MEDIA_TTL;
}
async function shellFallback(key, documentRequest) {
  try {
    const c = await caches.open(SHELL);
    const hit = await c.match(key);
    if (hit) return hit;
    if (documentRequest) {
      const page = await c.match('/index.html') || await c.match('/offline.html');
      if (page) return page;
    }
  } catch (_) {}
  return documentRequest
    ? new Response('Shivaa is offline. Please reconnect and retry.', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } })
    : Response.error();
}
self.addEventListener('fetch', (e) => {
  const r = e.request;
  const u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== self.location.origin) return;
  // No API is a live success when replayed offline; app.js owns its labelled catalogue fallback.
  if (r.headers.has('authorization') || u.pathname.startsWith('/api/') || u.pathname.startsWith('/data/')) return;
  if (/\.(?:mp4|webm|mov|m4v)$/i.test(u.pathname)) return;

  const publicImage = isImage(u) && (u.pathname.startsWith('/images/') || /^\/uploads\/designs\/[^/]+\//.test(u.pathname));
  if (publicImage) {
    const cache = caches.open(MEDIA).catch(() => null);
    const refreshed = fetch(r).then(async res => {
      // An SPA 200 HTML fallback must NEVER poison an image URL.
      if (res && res.ok && /^image\//i.test(res.headers.get('content-type') || '')) {
        try {
          const c = await cache;
          if (c) {
            const copy = res.clone();
            const headers = new Headers(copy.headers);
            headers.set('x-shivaa-cached-at', new Date().toUTCString());
            await c.put(r, new Response(await copy.blob(), { status: copy.status, statusText: copy.statusText, headers }));
            await trimMedia();
          }
        } catch (_) { /* quota/private mode cannot break the network image */ }
      }
      return res;
    }).catch(() => null);
    // Register during dispatch, not after returning a cached response.
    e.waitUntil(refreshed.then(() => {}));
    e.respondWith((async () => {
      try {
        const c = await cache;
        const hit = c && await c.match(r);
        if (freshMedia(hit)) return hit;
        if (hit) await c.delete(r);
      } catch (_) {}
      return (await refreshed) || Response.error();
    })());
    return;
  }
  // Unlisted URLs (including all private uploads and PHP utilities) bypass the worker.
  const documentRequest = (r.mode === 'navigate' || (r.headers.get('accept') || '').includes('text/html')) &&
    (u.pathname === '/' || u.pathname === '/index.html');
  const key = documentRequest ? '/index.html' : u.pathname + u.search;
  if (!documentRequest && !shellURLs.has(key)) return;
  const response = fetch(r).then(async res => {
    if (res && res.ok) {
      try { const c = await caches.open(SHELL); await c.put(key, res.clone()); } catch (_) {}
    }
    return res;
  }).catch(() => shellFallback(key, documentRequest));
  e.waitUntil(response.then(() => {}, () => {}));
  e.respondWith(response);
});

/* ══════════════════════════════════════════════════════════════════════
   v236 · BEING TOLD — notifications about a rate target
   ──────────────────────────────────────────────────────────────────────
   The desk used to announce a reached target only if the jeweller was
   looking at the page. Three small handlers fix that, and none of them
   changes how a single byte of the site is cached:

     · `message` from the desk page — the page decides WHO and WHAT (the
       server claim decides that, once per alert), this worker only draws
       the notification. Nothing here fetches, prices or writes anything.
     · `push` — the same drawing, from a real push service. It is wired now
       so that the day the owner stands up a VAPID sender (v237, with the
       relay) there is nothing left to change in the client.
     · `notificationclick` — always lands on the desk, never on a random
       tab: a jeweller tapping an alert wants the board, not the shop.

   If a browser supports none of this, the page falls back to its own toast
   and the desk keeps working. Notifications may never be the reason a
   trade cannot be made.
   ══════════════════════════════════════════════════════════════════════ */

self.addEventListener('message', (e) => {
  const d = e.data || {};
  if (d.type !== 'shv-notify') return;
  const opts = {
    body: String(d.body || '').slice(0, 240),
    tag: String(d.tag || 'shv-alert').slice(0, 64),
    renotify: true,
    data: { url: '/desk.html#/partner?view=bullion' },
    icon: '/images/icon-192.png',
    badge: '/images/icon-192.png',
    vibrate: [120, 60, 120],
  };
  e.waitUntil(self.registration.showNotification(String(d.title || 'Shivaa Bullion Desk').slice(0, 80), opts));
});

self.addEventListener('push', (e) => {
  let p = {};
  try { p = e.data ? e.data.json() : {}; } catch (_) { try { p = { body: e.data.text() }; } catch (_) { p = {}; } }
  const title = String(p.title || 'Shivaa Bullion Desk').slice(0, 80);
  const opts = {
    body: String(p.body || 'Your rate target was reached').slice(0, 240),
    tag: String(p.tag || 'shv-push').slice(0, 64),
    data: { url: String(p.url || '/desk.html#/partner?view=bullion') },
    icon: '/images/icon-192.png',
    badge: '/images/icon-192.png',
    vibrate: [120, 60, 120],
  };
  e.waitUntil(self.registration.showNotification(title, opts));
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || '/desk.html#/partner?view=bullion';
  e.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of all) {
      try {
        if (c.url.indexOf('/desk.html') !== -1 || c.url.indexOf('#/partner') !== -1) {
          await c.focus();
          if (c.navigate) await c.navigate(url);
          return;
        }
      } catch (_) {}
    }
    await self.clients.openWindow(url);
  })());
});
