/* Shivaa Jewels — service worker (installable app + fast start)
   - app files: network first (always the newest version), cache only as backup
   - sj-api.php and sj-data are never cached here (data comes from the server; the offline copy lives in IndexedDB, see sj-api.js) */
const V = '47';                     // must match ?v= in index.html
const CACHE = 'sj-app-v' + V;
const SHELL = ['./', 'index.html', 'manifest.json', 'icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png', 'fonts/Lora-Variable.ttf', 'fonts/Lora-Italic-Variable.ttf', 'fonts/Poppins-Light.ttf', 'fonts/Poppins-Regular.ttf', 'fonts/Poppins-Medium.ttf', 'fonts/Poppins-Bold.ttf', 'vision-shop.jpg', 'vision-shop-sm.jpg'].concat(['adv.css', 'sj-royal.css', 'sj-pro.css', 'sj-api.js', 'sj-royal.js', 'adv.js', 'sj-estimates.js', 'sj-stock.js', 'sj-charts.js', 'sj-insights.js', 'sj-pro.js', 'sj-bill.js', 'sj-billx.js', 'sj-estx.js', 'sj-reports.js', 'sj-biz.js', 'sj-jarvis.js', 'sj-2050.js', 'sj-2050b.js', 'sj-2051.js', 'sj-2052.js', 'sj-shaadi.js', 'sj-vision.js', 'sj-roz.js', 'sj-offline.js', 'sj-scan.js', 'sj-guard.js', 'sj-floors.js', 'sj-field.js', 'sj-control.js', 'sj-smart.js', 'sj-dukaan.js', 'sj-tv.js', 'sj-lot.js', 'sj-pwa.js', 'sj-ecom.js'].map(f => f + '?v=' + V));

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => Promise.all(SHELL.map(u => c.add(new Request(u, { cache: 'reload' })).catch(() => null)))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k.startsWith('sj-app-') && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;                       // fonts etc. go straight to the network
  if (/sj-api\.php$/.test(url.pathname) || url.pathname.indexOf('/sj-data/') !== -1 || /\.php$/.test(url.pathname)) return;   // never cache data
  e.respondWith(fetch(req).then(res => {
    if (res && res.ok && res.type === 'basic') { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)).catch(() => null); }
    return res;
  }).catch(() => caches.match(req).then(hit => hit || (req.mode === 'navigate' ? caches.match('index.html').then(h => h || caches.match('./')) : undefined)).then(r => r || new Response('Offline', { status: 503, statusText: 'Offline' }))));
});
self.addEventListener('message', e => { if (e.data === 'skipWaiting') self.skipWaiting(); });
